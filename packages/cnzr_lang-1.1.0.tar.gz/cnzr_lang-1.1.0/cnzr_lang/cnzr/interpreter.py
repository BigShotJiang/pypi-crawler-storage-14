import os
from .tokens import *
from .ast_nodes import *
from .errors import RTError, CnzrNameError, CnzrTypeError
from .environment import Environment


class RTResult:
    def __init__(self):
        self.value = None
        self.error = None
        self.should_return = False

    def register(self, res):
        if res.error: self.error = res.error
        self.should_return = res.should_return
        return res.value

    def success(self, value):
        self.value = value
        return self

    def success_return(self, value):
        self.value = value
        self.should_return = True
        return self

    def failure(self, error):
        self.error = error
        return self

class Value:
    def __init__(self):
        self.pos_start = None
        self.pos_end = None
        self.context = None

    def set_pos(self, pos_start, pos_end):
        self.pos_start = pos_start
        self.pos_end = pos_end
        return self

    def set_context(self, context):
        self.context = context
        return self

    def added_to(self, other):
        return None, self.illegal_operation(other)

    def subbed_by(self, other):
        return None, self.illegal_operation(other)

    def multed_by(self, other):
        return None, self.illegal_operation(other)

    def dived_by(self, other):
        return None, self.illegal_operation(other)
    
    def modded_by(self, other):
        return None, self.illegal_operation(other)

    def get_comparison_eq(self, other):
        return None, self.illegal_operation(other)

    def get_comparison_ne(self, other):
        return None, self.illegal_operation(other)

    def get_comparison_lt(self, other):
        return None, self.illegal_operation(other)

    def get_comparison_gt(self, other):
        return None, self.illegal_operation(other)

    def get_comparison_lte(self, other):
        return None, self.illegal_operation(other)

    def get_comparison_gte(self, other):
        return None, self.illegal_operation(other)

    def is_true(self):
        return False

    def illegal_operation(self, other=None):
        if not other: other = self
        return CnzrTypeError(self.pos_start, self.pos_end, "Operasi ilegal", self.context)

    def copy(self):
        raise Exception('No copy method defined')

class Number(Value):
    def __init__(self, value):
        super().__init__()
        self.value = value

    def added_to(self, other):
        if isinstance(other, Number):
            return Number(self.value + other.value).set_context(self.context), None
        if isinstance(other, String):
            return String(str(self.value) + other.value).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def subbed_by(self, other):
        if isinstance(other, Number):
            return Number(self.value - other.value).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def multed_by(self, other):
        if isinstance(other, Number):
            return Number(self.value * other.value).set_context(self.context), None
        if isinstance(other, String):
             return String(other.value * int(self.value)).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def dived_by(self, other):
        if isinstance(other, Number):
            if other.value == 0: return None, "Division by zero"
            return Number(self.value / other.value).set_context(self.context), None
        return None, Value.illegal_operation(self, other)
    
    def modded_by(self, other):
        if isinstance(other, Number):
            if other.value == 0: return None, "Division by zero"
            return Number(self.value % other.value).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def get_comparison_eq(self, other):
        if isinstance(other, Number):
            return Number(1 if self.value == other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def get_comparison_ne(self, other):
        if isinstance(other, Number):
            return Number(1 if self.value != other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def get_comparison_lt(self, other):
        if isinstance(other, Number):
            return Number(1 if self.value < other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def get_comparison_gt(self, other):
        if isinstance(other, Number):
            return Number(1 if self.value > other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def get_comparison_lte(self, other):
        if isinstance(other, Number):
            return Number(1 if self.value <= other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def get_comparison_gte(self, other):
        if isinstance(other, Number):
            return Number(1 if self.value >= other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def is_true(self):
        return self.value != 0

    def copy(self):
        copy = Number(self.value)
        copy.set_pos(self.pos_start, self.pos_end)
        copy.set_context(self.context)
        return copy

    def __repr__(self):
        return str(self.value)

class String(Value):
    def __init__(self, value):
        super().__init__()
        self.value = value

    def added_to(self, other):
        if isinstance(other, String):
            return String(self.value + other.value).set_context(self.context), None
        return String(self.value + str(other)).set_context(self.context), None

    def multed_by(self, other):
        if isinstance(other, Number):
            return String(self.value * int(other.value)).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def is_true(self):
        return len(self.value) > 0

    def get_comparison_eq(self, other):
        if isinstance(other, String):
            return Number(1 if self.value == other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)
    
    def get_comparison_ne(self, other):
        if isinstance(other, String):
            return Number(1 if self.value != other.value else 0).set_context(self.context), None
        return None, Value.illegal_operation(self, other)

    def copy(self):
        copy = String(self.value)
        copy.set_pos(self.pos_start, self.pos_end)
        copy.set_context(self.context)
        return copy

    def __repr__(self):
        return f'"{self.value}"'

class ModuleValue(Value):
    def __init__(self, module):
        super().__init__()
        self.module = module # Can be dict (stdlib) or Environment (file module)

    def get(self, name):
        if isinstance(self.module, dict):
            val = self.module.get(name)
            if callable(val): return BuiltinMethod(val, name)
            return val
        elif hasattr(self.module, 'get'): # Environment or Module class
            val = self.module.get(name)
            if callable(val) and not isinstance(val, (Function, BuiltinMethod, ClassValue)):
                return BuiltinMethod(val, name)
            return val
        return None

    def copy(self):
        copy = ModuleValue(self.module)
        copy.set_pos(self.pos_start, self.pos_end)
        copy.set_context(self.context)
        return copy

    def __repr__(self):
        name = getattr(self.module, 'name', 'std')
        return f"<module {name}>"

class BuiltinMethod(Value):
    def __init__(self, method, name):
        super().__init__()
        self.method = method
        self.name = name

    def execute(self, args):
        return self.method(args)

    def copy(self):
        copy = BuiltinMethod(self.method, self.name)
        copy.set_pos(self.pos_start, self.pos_end)
        copy.set_context(self.context)
        return copy

    def __repr__(self):
        return f"<method {self.name}>"

class List(Value):
    def __init__(self, elements):
        super().__init__()
        self.elements = elements

    def added_to(self, other):
        if isinstance(other, List):
            new_list = self.copy()
            new_list.elements.extend(other.elements)
            return new_list, None
        return None, Value.illegal_operation(self, other)

    def copy(self):
        copy = List(self.elements)
        copy.set_pos(self.pos_start, self.pos_end)
        copy.set_context(self.context)
        return copy

    def __repr__(self):
        return f"[{', '.join([str(x) for x in self.elements])}]"

class Function(Value):
    def __init__(self, name, body_nodes, arg_names):
        super().__init__()
        self.name = name
        self.body_nodes = body_nodes
        self.arg_names = arg_names

    def execute(self, args):
        res = RTResult()
        interpreter = Interpreter()
        new_context = Environment(self.name, self.context, self.pos_start)
        
        if len(args) != len(self.arg_names):
            return res.failure(RTError(self.pos_start, self.pos_end, f"{self.name} expects {len(self.arg_names)} args, got {len(args)}", self.context))

        for i in range(len(args)):
            arg_name = self.arg_names[i]
            arg_value = args[i]
            arg_value.set_context(new_context)
            new_context.set(arg_name, arg_value)

        value = Number(0)
        for node in self.body_nodes:
            value = res.register(interpreter.visit(node, new_context))
            if res.error: return res
            if res.should_return:
                return res.success(value)
        
        return res.success(Number(0)) # Default return

    def copy(self):
        copy = Function(self.name, self.body_nodes, self.arg_names)
        copy.set_context(self.context)
        copy.set_pos(self.pos_start, self.pos_end)
        return copy

    def __repr__(self):
        return f"<function {self.name}>"

class ClassValue(Value):
    def __init__(self, name, methods):
        super().__init__()
        self.name = name
        self.methods = methods

    def execute(self, args):
        instance = InstanceValue(self)
        init_method = self.methods.get('__init__')
        if init_method:
            res = init_method.execute([instance] + args)
            if res.error: return res.failure(res.error)
        elif len(args) > 0:
             return RTResult().failure(RTError(self.pos_start, self.pos_end, f"Class {self.name} takes no arguments", self.context))
        
        return RTResult().success(instance)

    def copy(self):
        return ClassValue(self.name, self.methods).set_context(self.context).set_pos(self.pos_start, self.pos_end)

    def __repr__(self):
        return f"<class {self.name}>"

class InstanceValue(Value):
    def __init__(self, class_value):
        super().__init__()
        self.class_value = class_value
        self.attributes = {}

    def get_attribute(self, name):
        if name in self.attributes:
            return self.attributes[name]
        
        method = self.class_value.methods.get(name)
        if method:
            return BoundMethod(method, self)
            
        return None

    def set_attribute(self, name, value):
        self.attributes[name] = value

    def copy(self):
        copy = InstanceValue(self.class_value)
        copy.attributes = self.attributes
        return copy.set_context(self.context).set_pos(self.pos_start, self.pos_end)

    def __repr__(self):
        return f"<instance of {self.class_value.name}>"

class BoundMethod(Value):
    def __init__(self, method, instance):
        super().__init__()
        self.method = method
        self.instance = instance

    def execute(self, args):
        return self.method.execute([self.instance] + args)

    def copy(self):
        return BoundMethod(self.method, self.instance).set_context(self.context).set_pos(self.pos_start, self.pos_end)
    
    def __repr__(self):
        return f"<bound method {self.method.name} of {self.instance}>"

class TaskValue(Value):
    def __init__(self, thread, result_container):
        super().__init__()
        self.thread = thread
        self.result_container = result_container # list with 1 item [result] or [error]

    def copy(self):
        return TaskValue(self.thread, self.result_container)

    def __repr__(self):
        return f"<tugas {self.thread.name}>"

class Interpreter:
    def __init__(self, debug=False):
        self.debug = debug

    def debug_log(self, message):
        if self.debug:
            print(f"🐛 [DEBUG] {message}")

    def visit(self, node, context):
        method_name = f'visit_{type(node).__name__}'
        method = getattr(self, method_name, self.no_visit_method)
        
        if self.debug:
            self.debug_log(f"Visiting {type(node).__name__} at Line {node.pos_start.ln + 1}")
            
        return method(node, context)

    def no_visit_method(self, node, context):
        raise Exception(f'No visit_{type(node).__name__} method defined')

    def visit_list(self, node, context):
        res = RTResult()
        elements = []
        for element in node:
            val = res.register(self.visit(element, context))
            if res.should_return: return res
            if res.error: return res
            elements.append(val)
        return res.success(elements)

    def visit_NumberNode(self, node, context):
        return RTResult().success(Number(node.tok.value).set_context(context).set_pos(node.pos_start, node.pos_end))

    def visit_StringNode(self, node, context):
        return RTResult().success(String(node.tok.value).set_context(context).set_pos(node.pos_start, node.pos_end))

    def visit_ListNode(self, node, context):
        res = RTResult()
        elements = []
        for element_node in node.element_nodes:
            elements.append(res.register(self.visit(element_node, context)))
            if res.error: return res
        return RTResult().success(List(elements).set_context(context).set_pos(node.pos_start, node.pos_end))

    def visit_VarAccessNode(self, node, context):
        res = RTResult()
        var_name = node.var_name_tok.value
        value = context.get(var_name)

        if not value:
            return res.failure(CnzrNameError(node.pos_start, node.pos_end, f"Variabel '{var_name}' belum didefinisikan.", context))

        value = value.copy().set_pos(node.pos_start, node.pos_end).set_context(context)
        return res.success(value)

    def visit_VarAssignNode(self, node, context):
        res = RTResult()
        
        # Check if target is MemberAccessNode or VarAccessNode
        if isinstance(node.target_node, MemberAccessNode):
            # Handle attribute assignment: o.attr = val
            left = res.register(self.visit(node.target_node.left_node, context))
            if res.error: return res
            
            if not isinstance(left, InstanceValue):
                return res.failure(RTError(node.target_node.pos_start, node.target_node.pos_end, "Cannot set attribute on non-instance", context))
                
            value = res.register(self.visit(node.value_node, context))
            if res.error: return res
            
            left.set_attribute(node.target_node.member_name_tok.value, value)
            return res.success(value)
            
        elif isinstance(node.target_node, VarAccessNode):
            # Handle variable assignment: var = val
            var_name = node.target_node.var_name_tok.value
            value = res.register(self.visit(node.value_node, context))
            if res.error: return res

            context.set(var_name, value)
            return res.success(value)
        
        return res.failure(RTError(node.pos_start, node.pos_end, "Invalid assignment target", context))

    def visit_BinOpNode(self, node, context):
        res = RTResult()
        left = res.register(self.visit(node.left_node, context))
        if res.error: return res
        right = res.register(self.visit(node.right_node, context))
        if res.error: return res

        if node.op_tok.type == TT_PLUS:
            result, error = left.added_to(right)
        elif node.op_tok.type == TT_MINUS:
            result, error = left.subbed_by(right)
        elif node.op_tok.type == TT_MUL:
            result, error = left.multed_by(right)
        elif node.op_tok.type == TT_DIV:
            result, error = left.dived_by(right)
        elif node.op_tok.type == TT_MOD:
            result, error = left.modded_by(right)
        elif node.op_tok.type == TT_EE:
            result, error = left.get_comparison_eq(right)
        elif node.op_tok.type == TT_NE:
            result, error = left.get_comparison_ne(right)
        elif node.op_tok.type == TT_LT:
            result, error = left.get_comparison_lt(right)
        elif node.op_tok.type == TT_GT:
            result, error = left.get_comparison_gt(right)
        elif node.op_tok.type == TT_LTE:
            result, error = left.get_comparison_lte(right)
        elif node.op_tok.type == TT_GTE:
            result, error = left.get_comparison_gte(right)
        elif node.op_tok.matches(TT_KEYWORD, 'dan'):
             result = Number(1 if left.is_true() and right.is_true() else 0).set_context(context)
             error = None
        elif node.op_tok.matches(TT_KEYWORD, 'atau'):
             result = Number(1 if left.is_true() or right.is_true() else 0).set_context(context)
             error = None
        else:
            error = f"Unknown operator {node.op_tok}"
            result = None

        if error:
            if isinstance(error, str):
                return res.failure(RTError(node.pos_start, node.pos_end, error, context))
            else:
                return res.failure(error)
        else:
            return res.success(result.set_pos(node.pos_start, node.pos_end))

    def visit_UnaryOpNode(self, node, context):
        res = RTResult()
        number = res.register(self.visit(node.node, context))
        if res.error: return res

        error = None
        if node.op_tok.type == TT_MINUS:
            if isinstance(number, Number):
                number = Number(-number.value)
            else:
                error = "Cannot negate non-number"
        elif node.op_tok.matches(TT_KEYWORD, 'tidak'):
            number = Number(0 if number.is_true() else 1)

        if error:
            return res.failure(RTError(node.pos_start, node.pos_end, error, context))
        return res.success(number.set_pos(node.pos_start, node.pos_end))

    def visit_IfNode(self, node, context):
        res = RTResult()

        for condition, statements in node.cases:
            condition_value = res.register(self.visit(condition, context))
            if res.error: return res

            if condition_value.is_true():
                for stmt in statements:
                    val = res.register(self.visit(stmt, context))
                    if res.error: return res
                    if res.should_return: return res.success_return(val)
                return res.success(Number(0))

        if node.else_case:
            for stmt in node.else_case:
                val = res.register(self.visit(stmt, context))
                if res.error: return res
                if res.should_return: return res.success_return(val)

        return res.success(Number(0))

    def visit_WhileNode(self, node, context):
        res = RTResult()

        while True:
            condition = res.register(self.visit(node.condition_node, context))
            if res.error: return res

            if not condition.is_true(): break

            for stmt in node.body_nodes:
                val = res.register(self.visit(stmt, context))
                if res.error: return res
                if res.should_return: return res.success_return(val)

        return res.success(Number(0))

    def visit_ForEachNode(self, node, context):
        res = RTResult()
        iter_val = res.register(self.visit(node.iter_node, context))
        if res.error: return res

        if not isinstance(iter_val, List):
            return res.failure(RTError(node.pos_start, node.pos_end, "Expected list", context))

        for element in iter_val.elements:
            context.set(node.var_name_tok.value, element)
            
            for stmt in node.body_nodes:
                val = res.register(self.visit(stmt, context))
                if res.error: return res
                if res.should_return: return res.success_return(val)

        return res.success(Number(0))

    def visit_FuncDefNode(self, node, context):
        res = RTResult()
        func_name = node.var_name_tok.value if node.var_name_tok else None
        body_nodes = node.body_nodes
        arg_names = [arg_name.value for arg_name in node.arg_name_toks]
        func_value = Function(func_name, body_nodes, arg_names).set_context(context).set_pos(node.pos_start, node.pos_end)

        if func_name:
            context.set(func_name, func_value)

        return res.success(func_value)

    def visit_ClassDefNode(self, node, context):
        res = RTResult()
        class_name = node.var_name_tok.value
        methods = {}

        for stmt in node.body_nodes:
            if isinstance(stmt, FuncDefNode):
                method_name = stmt.var_name_tok.value
                arg_names = [arg.value for arg in stmt.arg_name_toks]
                method = Function(method_name, stmt.body_nodes, arg_names).set_context(context).set_pos(stmt.pos_start, stmt.pos_end)
                methods[method_name] = method
        
        class_value = ClassValue(class_name, methods).set_context(context).set_pos(node.pos_start, node.pos_end)
        context.set(class_name, class_value)
        return res.success(class_value)

    def visit_RepeatNode(self, node, context):
        res = RTResult()
        count = res.register(self.visit(node.count_node, context))
        if res.error: return res

        if not isinstance(count, Number):
            return res.failure(RTError(node.pos_start, node.pos_end, "Repeat count must be a number", context))

        for _ in range(int(count.value)):
            for stmt in node.body_nodes:
                val = res.register(self.visit(stmt, context))
                if res.error: return res
                if res.should_return: return res.success_return(val)
        
        return res.success(Number(0))

    def visit_InputNode(self, node, context):
        res = RTResult()
        prompt = res.register(self.visit(node.prompt_node, context))
        if res.error: return res
        
        text = input(str(prompt.value))
        return RTResult().success(String(text).set_context(context).set_pos(node.pos_start, node.pos_end))

    def visit_ImportNode(self, node, context):
        res = RTResult()
        module_name = node.module_name_tok.value
        
        module = self._load_module(module_name, context, node.pos_start, node.pos_end)
        if isinstance(module, RTError): return res.failure(module)
        module = self._load_module(module_name, node.pos_start, node.pos_end, context)
        if module.error: return module
        
        context.set(module_name, module.value)
        return res.success(Number(0))

    def visit_ImportFromNode(self, node, context):
        res = RTResult()
        module_name = node.module_name_tok.value
        
        # Load module
        module_res = self._load_module(module_name, node.pos_start, node.pos_end, context)
        if module_res.error: return module_res
        module_val = module_res.value
        
        # Import specific names
        for item in node.import_items:
            name = item.value
            val = module_val.get(name)
            if not val:
                return res.failure(RTError(
                    node.pos_start, node.pos_end,
                    f"'{name}' tidak ditemukan di modul '{module_name}'",
                    context
                ))
            context.set(name, val)
            
        return res.success(Number(0))

    def visit_TaskNode(self, node, context):
        res = RTResult()
        
        # Container to hold result or error from thread
        result_container = {"value": None, "error": None}
        
        def task_runner():
            # Create a new context for the thread
            # We need to copy the context or create a new child context?
            # Creating a child context is safer for isolation, but we want access to globals.
            # However, interpreter is not thread-safe if we share mutable state blindly.
            # For this "overkill" feature, we'll try to use a new interpreter instance or
            # just run visit in this thread with a copied context.
            
            # Simplified: Run in same interpreter instance (GIL limits parallelism anyway)
            # But we need to catch errors.
            try:
                # We need to evaluate the expression.
                # Usually node_to_run is a CallNode.
                # We can just visit it.
                val = self.visit(node.node_to_run, context)
                if val.error:
                    result_container["error"] = val.error
                else:
                    result_container["value"] = val.value
            except Exception as e:
                # Catch python exceptions
                result_container["error"] = RTError(
                    node.pos_start, node.pos_end,
                    f"Error internal thread: {str(e)}",
                    context
                )

        import threading
        thread = threading.Thread(target=task_runner)
        thread.start()
        
        return res.success(TaskValue(thread, result_container))

    def visit_AwaitNode(self, node, context):
        res = RTResult()
        task = res.register(self.visit(node.node_to_await, context))
        if res.error: return res
        
        if not isinstance(task, TaskValue):
            return res.failure(RTError(
                node.pos_start, node.pos_end,
                "Hanya bisa menunggu 'tugas'",
                context
            ))
            
        # Join thread
        task.thread.join()
        
        # Check result
        if task.result_container["error"]:
            return res.failure(task.result_container["error"])
            
        return res.success(task.result_container["value"])

    def _load_module(self, module_name, pos_start, pos_end, context):
        from .stdlib import STDLIB
        if module_name in STDLIB:
            return RTResult().success(ModuleValue(STDLIB[module_name]))
        
        filename = f"{module_name}.cnzr"
        if os.path.exists(filename):
             with open(filename, "r", encoding="utf-8") as f:
                 script = f.read()
                 
             from .lexer import Lexer
             from .parser import Parser
             
             lexer = Lexer(filename, script)
             tokens, error = lexer.make_tokens()
             if error: return RTError(pos_start, pos_end, f"Error loading module {module_name}: {error}", context)
             
             parser = Parser(tokens)
             ast = parser.parse()
             if ast.error: return RTError(pos_start, pos_end, f"Error parsing module {module_name}: {ast.error}", context)
             
             # Find root context for builtins
             root = context
             while root.parent:
                 root = root.parent
             
             module_context = Environment(module_name, root, pos_start)
             
             interpreter = Interpreter(self.debug)
             for stmt in ast.node:
                 res = interpreter.visit(stmt, module_context)
                 if res.error: return RTError(pos_start, pos_end, f"Error executing module {module_name}: {res.error}", context)
                 
             return ModuleValue(module_context)

        return RTError(pos_start, pos_end, f"Module '{module_name}' not found", context)

    def visit_MemberAccessNode(self, node, context):
        res = RTResult()
        left = res.register(self.visit(node.left_node, context))
        if res.error: return res

        member_name = node.member_name_tok.value

        if isinstance(left, InstanceValue):
            attr = left.get_attribute(member_name)
            if attr:
                return res.success(attr)
            return res.failure(RTError(node.pos_start, node.pos_end, f"Instance has no attribute '{member_name}'", context))

        if isinstance(left, ModuleValue):
            val = left.get(member_name)
            if not val:
                return res.failure(RTError(node.pos_start, node.pos_end, f"Module has no member '{member_name}'", context))
            return res.success(val)
        
        return res.failure(RTError(node.pos_start, node.pos_end, "Member access only supported for instances and modules", context))

    def visit_CallNode(self, node, context):
        res = RTResult()
        args = []

        value_to_call = res.register(self.visit(node.node_to_call, context))
        if res.error: return res
        value_to_call = value_to_call.copy().set_pos(node.pos_start, node.pos_end)

        for arg_node in node.arg_nodes:
            args.append(res.register(self.visit(arg_node, context)))
            if res.error: return res

        if isinstance(value_to_call, Function) or hasattr(value_to_call, 'execute'):
             return_value = res.register(value_to_call.execute(args))
             if res.error: return res
             return_value = return_value.copy().set_pos(node.pos_start, node.pos_end).set_context(context)
             return res.success(return_value)
        
        # Handle Module Method Call (e.g. teks.kecil)
        # This requires MemberAccessNode? Or just treating 'teks.kecil' as property access?
        # Currently parser treats 'teks.kecil' as... wait.
        # Parser doesn't support dot notation for property access yet!
        # I need to update Parser to support 'atom.prop' or 'atom.method()'.
        
        return res.failure(RTError(node.pos_start, node.pos_end, f"{value_to_call} is not callable", context))

    def visit_ReturnNode(self, node, context):
        res = RTResult()
        if node.node_to_return:
            value = res.register(self.visit(node.node_to_return, context))
            if res.error: return res
        else:
            value = Number(0)
        
        return res.success_return(value)

    def visit_PrintNode(self, node, context):
        res = RTResult()
        value = res.register(self.visit(node.node_to_print, context))
        if res.error: return res
        print(value)
        return res.success(value)

        print(value)
        return res.success(value)

global_symbol_table = Environment("global")
