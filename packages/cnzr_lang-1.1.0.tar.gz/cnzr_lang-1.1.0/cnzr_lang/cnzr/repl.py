from .lexer import Lexer
from .parser import Parser
from .interpreter import Interpreter
from .environment import Environment
from .builtins import BuiltinFunction

def run(fn, text, debug=False):
    # Generate tokens
    lexer = Lexer(fn, text)
    tokens, error = lexer.make_tokens()
    if error: return None, error
    
    # Generate AST
    parser = Parser(tokens)
    ast = parser.parse()
    if ast.error: return None, ast.error.as_string()

    # Run program
    interpreter = Interpreter(debug=debug)
    context = Environment('<program>')
    
    # Register builtins
    context.set("tulis", BuiltinFunction.tulis)
    context.set("panjang", BuiltinFunction.panjang)
    context.set("angka", BuiltinFunction.angka)
    context.set("teks", BuiltinFunction.teks)
    context.set("jenis", BuiltinFunction.jenis)
    context.set("uji_sama", BuiltinFunction.uji_sama)
    context.set("uji_benar", BuiltinFunction.uji_benar)

    # Execute
    # Since AST is a list of statements now
    results = []
    for stmt in ast.node:
        res = interpreter.visit(stmt, context)
        if res.error: return None, res.error.as_string()
        results.append(res.value)

    return results, None

from .help_content import HELP_TEXT, EXAMPLES

def start_repl(mode_pemula=False):
    if mode_pemula:
        print("Selamat datang di CNZR Mode Pemula! 🚀")
        print("Ketik 'bantuan' untuk panduan singkat.")
    else:
        print("CNZR Language v1.0 REPL")
    
    print("Ketik 'keluar' untuk berhenti.")
    
    while True:
        try:
            text = input('cnzr> ')
        except EOFError:
            break
            
        if text.strip() == 'keluar': break
        if not text.strip(): continue

        if mode_pemula:
            if text.strip() == 'bantuan':
                print(HELP_TEXT)
                continue
            if text.strip().startswith('contoh'):
                parts = text.strip().split()
                if len(parts) > 1:
                    topic = parts[1]
                    if topic in EXAMPLES:
                        print(f"\n--- Contoh {topic} ---")
                        print(EXAMPLES[topic])
                        print("--------------------\n")
                    else:
                        print(f"Topik '{topic}' tidak ditemukan. Coba: variabel, percabangan, perulangan, fungsi, berkas")
                else:
                    print("Ketik 'contoh [topik]'. Topik tersedia: variabel, percabangan, perulangan, fungsi, berkas")
                continue

        result, error = run('<stdin>', text)

        if error:
            print(error)
        elif result:
            # Only print the last result if it's not None/Null
            pass
