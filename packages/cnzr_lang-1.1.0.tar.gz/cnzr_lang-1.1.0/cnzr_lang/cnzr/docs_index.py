DOCS_INDEX = {
    # Keywords
    "setel": {
        "jenis": "Kata Kunci",
        "deskripsi": "Mendefinisikan atau mengubah nilai variabel.",
        "contoh": 'setel nama = "Budi"\nsetel umur = 20'
    },
    "tulis": {
        "jenis": "Kata Kunci",
        "deskripsi": "Menampilkan teks atau nilai ke layar (stdout).",
        "contoh": 'tulis "Halo Dunia"'
    },
    "jika": {
        "jenis": "Kata Kunci",
        "deskripsi": "Memulai blok percabangan kondisional.",
        "contoh": 'jika nilai > 70:\n    tulis "Lulus"'
    },
    "jika tidak": {
        "jenis": "Kata Kunci",
        "deskripsi": "Blok alternatif jika kondisi 'jika' tidak terpenuhi.",
        "contoh": 'jika tidak:\n    tulis "Gagal"'
    },
    "selama": {
        "jenis": "Kata Kunci",
        "deskripsi": "Melakukan perulangan selama kondisi bernilai benar.",
        "contoh": 'selama x > 0:\n    tulis x\n    setel x = x - 1'
    },
    "untuk": {
        "jenis": "Kata Kunci",
        "deskripsi": "Melakukan perulangan untuk setiap elemen dalam koleksi.",
        "contoh": 'untuk setiap item di daftar:\n    tulis item'
    },
    "ulang": {
        "jenis": "Kata Kunci",
        "deskripsi": "Melakukan perulangan sejumlah kali tertentu.",
        "contoh": 'ulang 5 kali:\n    tulis "Hore"'
    },
    "fungsi": {
        "jenis": "Kata Kunci",
        "deskripsi": "Mendefinisikan fungsi baru.",
        "contoh": 'fungsi sapa(nama):\n    tulis "Halo " + nama'
    },
    "kelas": {
        "jenis": "Kata Kunci",
        "deskripsi": "Mendefinisikan kelas baru (blueprint objek).",
        "contoh": 'kelas Kucing:\n    fungsi meong(self):\n        tulis "Meong"'
    },
    "kembalikan": {
        "jenis": "Kata Kunci",
        "deskripsi": "Mengembalikan nilai dari dalam fungsi.",
        "contoh": 'kembalikan hasil'
    },
    "pakai": {
        "jenis": "Kata Kunci",
        "deskripsi": "Mengimpor modul.",
        "contoh": 'pakai matematika'
    },
    "dari": {
        "jenis": "Kata Kunci",
        "deskripsi": "Bagian dari sintaks import spesifik.",
        "contoh": 'dari matematika ambil PI'
    },
    "ambil": {
        "jenis": "Kata Kunci",
        "deskripsi": "Bagian dari sintaks import spesifik.",
        "contoh": 'dari matematika ambil PI'
    },
    "tanya": {
        "jenis": "Kata Kunci",
        "deskripsi": "Meminta input dari pengguna.",
        "contoh": 'setel nama = tanya "Siapa nama Anda? "'
    },
    
    # Built-in Functions
    "panjang": {
        "jenis": "Fungsi Bawaan",
        "deskripsi": "Mengembalikan panjang dari string atau list.",
        "contoh": 'tulis panjang("Halo")'
    },
    "angka": {
        "jenis": "Fungsi Bawaan",
        "deskripsi": "Mengubah nilai menjadi tipe angka.",
        "contoh": 'setel x = angka("123")'
    },
    "teks": {
        "jenis": "Fungsi Bawaan",
        "deskripsi": "Mengubah nilai menjadi tipe teks.",
        "contoh": 'setel s = teks(123)'
    },
    "jenis": {
        "jenis": "Fungsi Bawaan",
        "deskripsi": "Mengembalikan tipe data dari nilai.",
        "contoh": 'tulis jenis(123)'
    },
    "uji_sama": {
        "jenis": "Fungsi Bawaan",
        "deskripsi": "Memastikan dua nilai sama (untuk testing).",
        "contoh": 'uji_sama(1+1, 2, "Penjumlahan benar")'
    },
    "uji_benar": {
        "jenis": "Fungsi Bawaan",
        "deskripsi": "Memastikan kondisi bernilai benar (untuk testing).",
        "contoh": 'uji_benar(x > 0, "x harus positif")'
    }
}
