from .tokens import *
from .ast_nodes import *
from .errors import InvalidSyntaxError

class ParseResult:
    def __init__(self):
        self.error = None
        self.node = None
        self.advance_count = 0
        self.to_reverse_count = 0

    def register_advancement(self):
        self.advance_count += 1

    def register(self, res):
        self.advance_count += res.advance_count
        if res.error: self.error = res.error
        return res.node

    def try_register(self, res):
        if res.error:
            self.to_reverse_count = res.advance_count
            return None
        return self.register(res)

    def success(self, node):
        self.node = node
        return self

    def failure(self, error):
        if not self.error or self.advance_count == 0:
            self.error = error
        return self

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.tok_idx = -1
        self.advance()

    def advance(self):
        self.tok_idx += 1
        self.update_current_tok()
        return self.current_tok

    def reverse(self, amount=1):
        self.tok_idx -= amount
        self.update_current_tok()
        return self.current_tok

    def update_current_tok(self):
        if self.tok_idx < len(self.tokens):
            self.current_tok = self.tokens[self.tok_idx]
        return self.current_tok

    def parse(self):
        res = self.statements()
        if not res.error and self.current_tok.type != TT_EOF:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected EOF, found {self.current_tok.type}"))
        return res

    def statements(self):
        res = ParseResult()
        statements = []
        pos_start = self.current_tok.pos_start.copy()

        while self.current_tok.type == TT_NEWLINE:
            res.register_advancement()
            self.advance()

        while self.current_tok.type not in (TT_EOF, TT_DEDENT):
            stmt = res.register(self.statement())
            if res.error: return res
            statements.append(stmt)
            
            newline_count = 0
            while self.current_tok.type == TT_NEWLINE:
                res.register_advancement()
                self.advance()
                newline_count += 1
            
            if newline_count == 0 and self.current_tok.type not in (TT_EOF, TT_DEDENT):
                # Check if the previous statement was a block statement
                # Block statements end with DEDENT, so they don't strictly need a newline separator
                if not isinstance(stmt, (IfNode, WhileNode, ForEachNode, FuncDefNode, RepeatNode, ClassDefNode)):
                    return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected NEWLINE"))
        
        return res.success(statements)

    def statement(self):
        res = ParseResult()
        if self.current_tok.matches(TT_KEYWORD, 'kembalikan'):
            res.register_advancement()
            self.advance()
            expr = res.try_register(self.expr())
            if not expr:
                self.reverse(res.to_reverse_count)
            return res.success(ReturnNode(expr, self.current_tok.pos_start, self.current_tok.pos_end))
        
        if self.current_tok.matches(TT_KEYWORD, 'pakai'):
            res.register_advancement()
            self.advance()
            if self.current_tok.type != TT_IDENTIFIER:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected identifier"))
            module_name = self.current_tok
            res.register_advancement()
            self.advance()
            return res.success(ImportNode(module_name))

        if self.current_tok.matches(TT_KEYWORD, 'dari'):
            from_import_stmt = res.register(self.from_import_stmt())
            if res.error: return res
            return res.success(from_import_stmt)

        if self.current_tok.matches(TT_KEYWORD, 'kelas'):
            class_def = res.register(self.class_def())
            if res.error: return res
            return res.success(class_def)

        if self.current_tok.matches(TT_KEYWORD, 'tulis'):
            res.register_advancement()
            self.advance()
            expr = res.register(self.expr())
            if res.error: return res
            return res.success(PrintNode(expr, self.current_tok.pos_start, self.current_tok.pos_end))

        if self.current_tok.matches(TT_KEYWORD, 'setel'):
            res.register_advancement()
            self.advance()
            
            target = res.register(self.call())
            if res.error: return res

            if not isinstance(target, (VarAccessNode, MemberAccessNode)):
                 return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected identifier or attribute access"))

            if self.current_tok.type != TT_EQ:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected '='"))
            res.register_advancement()
            self.advance()
            expr = res.register(self.expr())
            if res.error: return res
            return res.success(VarAssignNode(target, expr))
            
        expr = res.register(self.expr())
        if res.error:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected statement or expression. Found {self.current_tok}"))
        return res.success(expr)

    def expr(self):
        res = ParseResult()
        if self.current_tok.matches(TT_KEYWORD, 'setel'):
             return self.statement()
             
        if self.current_tok.matches(TT_KEYWORD, 'jika'):
            if_expr = res.register(self.if_expr())
            if res.error: return res
            return res.success(if_expr)

        if self.current_tok.matches(TT_KEYWORD, 'selama'):
            while_expr = res.register(self.while_expr())
            if res.error: return res
            return res.success(while_expr)

        if self.current_tok.matches(TT_KEYWORD, 'untuk'):
            for_expr = res.register(self.for_expr())
            if res.error: return res
            return res.success(for_expr)

        if self.current_tok.matches(TT_KEYWORD, 'ulang'):
            repeat_expr = res.register(self.repeat_expr())
            if res.error: return res
            return res.success(repeat_expr)

        if self.current_tok.matches(TT_KEYWORD, 'tanya'):
            tanya_expr = res.register(self.tanya_expr())
            if res.error: return res
            return res.success(tanya_expr)

        if self.current_tok.matches(TT_KEYWORD, 'fungsi'):
            func_def = res.register(self.func_def())
            if res.error: return res
            return res.success(func_def)

        node = res.register(self.bin_op(self.comp_expr, ((TT_KEYWORD, 'dan'), (TT_KEYWORD, 'atau'))))
        if res.error: return res.failure(res.error)
        return res.success(node)

    def comp_expr(self):
        res = ParseResult()
        if self.current_tok.matches(TT_KEYWORD, 'tidak'):
            op_tok = self.current_tok
            res.register_advancement()
            self.advance()
            node = res.register(self.comp_expr())
            if res.error: return res
            return res.success(UnaryOpNode(op_tok, node))
        
        node = res.register(self.bin_op(self.arith_expr, (TT_EE, TT_NE, TT_LT, TT_GT, TT_LTE, TT_GTE)))
        if res.error:
            return res.failure(res.error)
        return res.success(node)

    def arith_expr(self):
        return self.bin_op(self.term, (TT_PLUS, TT_MINUS))

    def term(self):
        return self.bin_op(self.factor, (TT_MUL, TT_DIV, TT_MOD))

    def factor(self):
        res = ParseResult()
        tok = self.current_tok

        if tok.type in (TT_PLUS, TT_MINUS):
            res.register_advancement()
            self.advance()
            factor = res.register(self.factor())
            if res.error: return res
            return res.success(UnaryOpNode(tok, factor))

        return self.power()

    def power(self):
        return self.bin_op(self.call, (TT_MUL, ), self.factor)

    def call(self):
        res = ParseResult()
        atom = res.register(self.atom())
        if res.error: return res

        while self.current_tok.type in (TT_LPAREN, TT_DOT):
            if self.current_tok.type == TT_LPAREN:
                res.register_advancement()
                self.advance()
                arg_nodes = []

                if self.current_tok.type == TT_RPAREN:
                    res.register_advancement()
                    self.advance()
                else:
                    arg_nodes.append(res.register(self.expr()))
                    if res.error:
                        return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected expression"))

                    while self.current_tok.type == TT_COMMA:
                        res.register_advancement()
                        self.advance()
                        arg_nodes.append(res.register(self.expr()))
                        if res.error: return res

                    if self.current_tok.type != TT_RPAREN:
                        return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected ')'"))
                    res.register_advancement()
                    self.advance()
                atom = CallNode(atom, arg_nodes)
            
            elif self.current_tok.type == TT_DOT:
                res.register_advancement()
                self.advance()

                if self.current_tok.type != TT_IDENTIFIER:
                    return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected identifier after '.'"))
                
                member_name = self.current_tok
                res.register_advancement()
                self.advance()
                atom = MemberAccessNode(atom, member_name)

        return res.success(atom)

    def atom(self):
        res = ParseResult()
        tok = self.current_tok

        if tok.type in (TT_INT, TT_FLOAT):
            res.register_advancement()
            self.advance()
            return res.success(NumberNode(tok))

        elif tok.type == TT_STRING:
            res.register_advancement()
            self.advance()
            return res.success(StringNode(tok))

        elif tok.type == TT_IDENTIFIER:
            res.register_advancement()
            self.advance()
            return res.success(VarAccessNode(tok))

        elif tok.type == TT_KEYWORD:
             if tok.value == 'benar':
                 res.register_advancement()
                 self.advance()
                 return res.success(NumberNode(Token(TT_INT, 1, tok.pos_start, tok.pos_end)))
             elif tok.value == 'salah':
                 res.register_advancement()
                 self.advance()
                 return res.success(NumberNode(Token(TT_INT, 0, tok.pos_start, tok.pos_end)))
             elif tok.value == 'kosong':
                 res.register_advancement()
                 self.advance()
                 return res.success(NumberNode(Token(TT_INT, 0, tok.pos_start, tok.pos_end)))
             elif tok.value == 'tugas':
                 res.register_advancement()
                 self.advance()
                 expr = res.register(self.call())
                 if res.error: return res
                 return res.success(TaskNode(expr))
             elif tok.value == 'tunggu':
                 res.register_advancement()
                 self.advance()
                 expr = res.register(self.atom())
                 if res.error: return res
                 return res.success(AwaitNode(expr))

        elif tok.type == TT_LPAREN:
            res.register_advancement()
            self.advance()
            expr = res.register(self.expr())
            if res.error: return res
            if self.current_tok.type == TT_RPAREN:
                res.register_advancement()
                self.advance()
                return res.success(expr)
            else:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected ')'"))
        
        elif tok.type == TT_LBRACKET:
            list_expr = res.register(self.list_expr())
            if res.error: return res
            return res.success(list_expr)

        return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected int, float, identifier, '+', '-', '(', '[', found {tok}"))

    def list_expr(self):
        res = ParseResult()
        element_nodes = []
        pos_start = self.current_tok.pos_start.copy()

        if self.current_tok.type != TT_LBRACKET:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected '['"))

        res.register_advancement()
        self.advance()

        if self.current_tok.type == TT_RBRACKET:
            res.register_advancement()
            self.advance()
        else:
            element_nodes.append(res.register(self.expr()))
            if res.error:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected expression"))

            while self.current_tok.type == TT_COMMA:
                res.register_advancement()
                self.advance()
                element_nodes.append(res.register(self.expr()))
                if res.error: return res

            if self.current_tok.type != TT_RBRACKET:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected ']'"))
            res.register_advancement()
            self.advance()

        return res.success(ListNode(element_nodes, pos_start, self.current_tok.pos_end.copy()))

    def block(self):
        res = ParseResult()
        if self.current_tok.type != TT_COLON:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected ':'"))
        
        res.register_advancement()
        self.advance()

        if self.current_tok.type != TT_NEWLINE:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected NEWLINE"))
        
        res.register_advancement()
        self.advance()

        if self.current_tok.type != TT_INDENT:
             return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected INDENT"))
        
        res.register_advancement()
        self.advance()

        statements = []
        while self.current_tok.type != TT_DEDENT and self.current_tok.type != TT_EOF:
            stmt = res.register(self.statement())
            if res.error: return res
            statements.append(stmt)
            
            while self.current_tok.type == TT_NEWLINE:
                res.register_advancement()
                self.advance()

        if self.current_tok.type != TT_DEDENT:
             return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected DEDENT"))
        
        res.register_advancement()
        self.advance()
        
        return res.success(statements)

    def if_expr(self):
        res = ParseResult()
        cases = []
        else_case = None

        if not self.current_tok.matches(TT_KEYWORD, 'jika'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'jika'"))

        res.register_advancement()
        self.advance()

        condition = res.register(self.expr())
        if res.error: return res

        statements = res.register(self.block())
        if res.error: return res
        cases.append((condition, statements))

        while self.current_tok.matches(TT_KEYWORD, 'jika'):
             if self.peek_matches(TT_KEYWORD, 'tidak'):
                 if self.peek_matches(TT_KEYWORD, 'jika', 2):
                     # 'jika tidak jika' -> ELIF
                     res.register_advancement()
                     self.advance() # consume jika
                     res.register_advancement()
                     self.advance() # consume tidak
                     res.register_advancement()
                     self.advance() # consume jika
                     
                     condition = res.register(self.expr())
                     if res.error: return res
                     statements = res.register(self.block())
                     if res.error: return res
                     cases.append((condition, statements))
                 else:
                     # 'jika tidak' -> ELSE
                     res.register_advancement()
                     self.advance() # consume jika
                     res.register_advancement()
                     self.advance() # consume tidak

                     # Check for optional 'apa-apa'
                     # 'apa-apa' is tokenized as IDENTIFIER:apa, MINUS, IDENTIFIER:apa
                     if self.current_tok.matches(TT_IDENTIFIER, 'apa') and \
                        self.peek_matches(TT_MINUS, None) and \
                        self.peek_matches(TT_IDENTIFIER, 'apa', 2):
                         res.register_advancement()
                         self.advance() # apa
                         res.register_advancement()
                         self.advance() # -
                         res.register_advancement()
                         self.advance() # apa
                     
                     if self.current_tok.type == TT_COLON:
                         else_case = res.register(self.block())
                         if res.error: return res
                         break
                     else:
                         return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected ':' after 'jika tidak'"))
             else:
                 break

        return res.success(IfNode(cases, else_case))

    def peek_matches(self, type_, value, offset=1):
        if self.tok_idx + offset < len(self.tokens):
            tok = self.tokens[self.tok_idx + offset]
            return tok.type == type_ and tok.value == value
        return False

    def while_expr(self):
        res = ParseResult()
        if not self.current_tok.matches(TT_KEYWORD, 'selama'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'selama'"))

        res.register_advancement()
        self.advance()

        condition = res.register(self.expr())
        if res.error: return res

        statements = res.register(self.block())
        if res.error: return res

        return res.success(WhileNode(condition, statements))

    def for_expr(self):
        res = ParseResult()
        if not self.current_tok.matches(TT_KEYWORD, 'untuk'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'untuk'"))
        res.register_advancement()
        self.advance()

        if not self.current_tok.matches(TT_KEYWORD, 'setiap'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'setiap'"))
        res.register_advancement()
        self.advance()

        if self.current_tok.type != TT_IDENTIFIER:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected identifier"))
        var_name = self.current_tok
        res.register_advancement()
        self.advance()

        if self.current_tok.type == TT_KEYWORD and self.current_tok.value == 'di':
             res.register_advancement()
             self.advance()
        elif self.current_tok.type == TT_IDENTIFIER and self.current_tok.value == 'di':
             res.register_advancement()
             self.advance()
        else:
             return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected 'di'"))

        iter_node = res.register(self.expr())
        if res.error: return res

        statements = res.register(self.block())
        if res.error: return res

        return res.success(ForEachNode(var_name, iter_node, statements))

    def repeat_expr(self):
        res = ParseResult()
        if not self.current_tok.matches(TT_KEYWORD, 'ulang'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected 'ulang'"))
        res.register_advancement()
        self.advance()

        count_node = res.register(self.expr())
        if res.error: return res

        if not self.current_tok.matches(TT_KEYWORD, 'kali'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected 'kali'"))
        res.register_advancement()
        self.advance()

        statements = res.register(self.block())
        if res.error: return res

        return res.success(RepeatNode(count_node, statements))

    def tanya_expr(self):
        res = ParseResult()
        if not self.current_tok.matches(TT_KEYWORD, 'tanya'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, "Expected 'tanya'"))
        res.register_advancement()
        self.advance()

        prompt_node = res.register(self.expr())
        if res.error: return res

        return res.success(InputNode(prompt_node, self.current_tok.pos_start, self.current_tok.pos_end))

    def func_def(self):
        res = ParseResult()
        if not self.current_tok.matches(TT_KEYWORD, 'fungsi'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'fungsi'"))

        res.register_advancement()
        self.advance()

        if self.current_tok.type == TT_IDENTIFIER:
            var_name_tok = self.current_tok
            res.register_advancement()
            self.advance()
            if self.current_tok.type != TT_LPAREN:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected '('"))
        else:
            var_name_tok = None
            if self.current_tok.type != TT_LPAREN:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected identifier or '('"))
        
        res.register_advancement()
        self.advance()
        arg_name_toks = []

        if self.current_tok.type == TT_IDENTIFIER:
            arg_name_toks.append(self.current_tok)
            res.register_advancement()
            self.advance()

            while self.current_tok.type == TT_COMMA:
                res.register_advancement()
                self.advance()

                if self.current_tok.type != TT_IDENTIFIER:
                    return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected identifier"))

                arg_name_toks.append(self.current_tok)
                res.register_advancement()
                self.advance()
        
        if self.current_tok.type != TT_RPAREN:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected ')'"))

        res.register_advancement()
        self.advance()

        body_nodes = res.register(self.block())
        if res.error: return res
        
        docstring = None
        if body_nodes and isinstance(body_nodes[0], StringNode):
            docstring = body_nodes[0].tok.value
        
        return res.success(FuncDefNode(var_name_tok, arg_name_toks, body_nodes, docstring))

    def class_def(self):
        res = ParseResult()
        if not self.current_tok.matches(TT_KEYWORD, 'kelas'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'kelas'"))

        res.register_advancement()
        self.advance()

        if self.current_tok.type != TT_IDENTIFIER:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected identifier"))

        var_name_tok = self.current_tok
        res.register_advancement()
        self.advance()

        body_nodes = res.register(self.block())
        if res.error: return res

        docstring = None
        if body_nodes and isinstance(body_nodes[0], StringNode):
            docstring = body_nodes[0].tok.value

        return res.success(ClassDefNode(var_name_tok, body_nodes, docstring))

    def from_import_stmt(self):
        res = ParseResult()
        if not self.current_tok.matches(TT_KEYWORD, 'dari'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'dari'"))

        res.register_advancement()
        self.advance()

        if self.current_tok.type != TT_IDENTIFIER:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected identifier"))

        module_name_tok = self.current_tok
        res.register_advancement()
        self.advance()

        if not self.current_tok.matches(TT_KEYWORD, 'ambil'):
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected 'ambil'"))

        res.register_advancement()
        self.advance()

        import_name_toks = []
        if self.current_tok.type != TT_IDENTIFIER:
            return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected identifier"))

        import_name_toks.append(self.current_tok)
        res.register_advancement()
        self.advance()

        while self.current_tok.type == TT_COMMA:
            res.register_advancement()
            self.advance()

            if self.current_tok.type != TT_IDENTIFIER:
                return res.failure(InvalidSyntaxError(self.current_tok.pos_start, self.current_tok.pos_end, f"Expected identifier"))

            import_name_toks.append(self.current_tok)
            res.register_advancement()
            self.advance()

        return res.success(ImportFromNode(module_name_tok, import_name_toks))

    def bin_op(self, func_a, ops, func_b=None):
        if func_b == None:
            func_b = func_a
        
        res = ParseResult()
        left = res.register(func_a())
        if res.error: return res

        while self.current_tok.type in ops or (self.current_tok.type == TT_KEYWORD and self.current_tok.value in [op[1] for op in ops if isinstance(op, tuple)]):
            op_tok = self.current_tok
            res.register_advancement()
            self.advance()
            right = res.register(func_b())
            if res.error: return res
            left = BinOpNode(left, op_tok, right)

        return res.success(left)
