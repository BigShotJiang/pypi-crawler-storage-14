from .ast_nodes import *
from .tokens import *

class Formatter:
    def __init__(self):
        self.indent_level = 0
        self.indent_str = "    " # 4 spaces

    def format(self, nodes):
        # nodes is a list of statements
        return self.visit_statements(nodes)

    def visit(self, node):
        method_name = f'visit_{type(node).__name__}'
        method = getattr(self, method_name, self.no_visit_method)
        return method(node)

    def no_visit_method(self, node):
        raise Exception(f'No visit_{type(node).__name__} method defined')

    def _indent(self):
        return self.indent_str * self.indent_level

    def visit_statements(self, nodes):
        result = []
        for node in nodes:
            result.append(self._indent() + self.visit(node))
        return "\n".join(result)

    def visit_NumberNode(self, node):
        return str(node.tok.value)

    def visit_StringNode(self, node):
        return f'"{node.tok.value}"'

    def visit_ListNode(self, node):
        elements = [self.visit(e) for e in node.element_nodes]
        return f"[{', '.join(elements)}]"

    def visit_VarAccessNode(self, node):
        return node.var_name_tok.value

    def visit_VarAssignNode(self, node):
        target = self.visit(node.target_node) if hasattr(node, 'target_node') else node.var_name_tok.value
        value = self.visit(node.value_node)
        return f"setel {target} = {value}"

    def visit_BinOpNode(self, node):
        left = self.visit(node.left_node)
        right = self.visit(node.right_node)
        op = node.op_tok.value if node.op_tok.type == TT_KEYWORD else node.op_tok.type
        
        # Map token types to symbols if needed, but lexer stores type as string for symbols usually?
        # tokens.py: TT_PLUS = 'PLUS'
        # We need to map TT_PLUS to '+'
        op_map = {
            TT_PLUS: '+', TT_MINUS: '-', TT_MUL: '*', TT_DIV: '/', TT_MOD: '%',
            TT_EE: '==', TT_NE: '!=', TT_LT: '<', TT_GT: '>', TT_LTE: '<=', TT_GTE: '>=',
            TT_EQ: '='
        }
        
        op_str = op_map.get(node.op_tok.type, str(node.op_tok.value))
        return f"{left} {op_str} {right}"

    def visit_UnaryOpNode(self, node):
        op_map = {TT_MINUS: '-', TT_KEYWORD: str(node.op_tok.value)}
        op_str = op_map.get(node.op_tok.type, str(node.op_tok.value))
        # Handle 'tidak' with space, '-' without
        if op_str == 'tidak':
            return f"{op_str} {self.visit(node.node)}"
        return f"{op_str}{self.visit(node.node)}"

    def visit_IfNode(self, node):
        result = ""
        for i, (condition, statements) in enumerate(node.cases):
            cond_str = self.visit(condition)
            keyword = "jika" if i == 0 else "jika tidak jika"
            result += f"{keyword} {cond_str}:\n"
            self.indent_level += 1
            result += self.visit_statements(statements)
            self.indent_level -= 1
            if i < len(node.cases) - 1:
                result += "\n" + self._indent()

        if node.else_case:
            result += "\n" + self._indent() + "jika tidak apa-apa:\n"
            self.indent_level += 1
            result += self.visit_statements(node.else_case)
            self.indent_level -= 1
        
        return result

    def visit_WhileNode(self, node):
        cond_str = self.visit(node.condition_node)
        result = f"selama {cond_str}:\n"
        self.indent_level += 1
        result += self.visit_statements(node.body_nodes)
        self.indent_level -= 1
        return result

    def visit_ForEachNode(self, node):
        var_name = node.var_name_tok.value
        iter_str = self.visit(node.iter_node)
        result = f"untuk setiap {var_name} di {iter_str}:\n"
        self.indent_level += 1
        result += self.visit_statements(node.body_nodes)
        self.indent_level -= 1
        return result

    def visit_RepeatNode(self, node):
        count_str = self.visit(node.count_node)
        result = f"ulang {count_str} kali:\n"
        self.indent_level += 1
        result += self.visit_statements(node.body_nodes)
        self.indent_level -= 1
        return result

    def visit_FuncDefNode(self, node):
        name = node.var_name_tok.value if node.var_name_tok else ""
        args = ", ".join([arg.value for arg in node.arg_name_toks])
        result = f"fungsi {name}({args}):\n"
        self.indent_level += 1
        result += self.visit_statements(node.body_nodes)
        self.indent_level -= 1
        return result

    def visit_ClassDefNode(self, node):
        name = node.var_name_tok.value
        result = f"kelas {name}:\n"
        self.indent_level += 1
        result += self.visit_statements(node.body_nodes)
        self.indent_level -= 1
        return result

    def visit_CallNode(self, node):
        func = self.visit(node.node_to_call)
        args = ", ".join([self.visit(arg) for arg in node.arg_nodes])
        return f"{func}({args})"

    def visit_ReturnNode(self, node):
        if node.node_to_return:
            return f"kembalikan {self.visit(node.node_to_return)}"
        return "kembalikan"

    def visit_PrintNode(self, node):
        return f"tulis {self.visit(node.node_to_print)}"

    def visit_InputNode(self, node):
        return f"tanya {self.visit(node.prompt_node)}"

    def visit_ImportNode(self, node):
        return f"pakai {node.module_name_tok.value}"

    def visit_ImportFromNode(self, node):
        names = ", ".join([tok.value for tok in node.import_name_toks])
        return f"dari {node.module_name_tok.value} ambil {names}"

    def visit_MemberAccessNode(self, node):
        return f"{self.visit(node.left_node)}.{node.member_name_tok.value}"
