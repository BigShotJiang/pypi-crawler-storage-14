import os
import toml
import shutil
import subprocess
from .errors import Error

class PackageManager:
    def __init__(self, project_dir="."):
        self.project_dir = project_dir
        self.config_file = os.path.join(project_dir, "cnzr_paket.toml")
        self.vendor_dir = os.path.join(project_dir, "vendor", "cnzr")

    def init_project(self, name):
        if os.path.exists(self.config_file):
            print("⚠️  Proyek sudah diinisialisasi (cnzr_paket.toml sudah ada).")
            return

        config = {
            "proyek": {
                "nama": name,
                "versi": "0.1.0"
            },
            "dependensi": {}
        }

        with open(self.config_file, "w") as f:
            toml.dump(config, f)
        
        print(f"✅ Proyek '{name}' berhasil diinisialisasi.")
        print(f"📄 File konfigurasi: {self.config_file}")

    def add_package(self, name, url):
        if not os.path.exists(self.config_file):
            print("⚠️  File konfigurasi tidak ditemukan. Jalankan 'cnzr paket init' terlebih dahulu.")
            return

        # Load config
        with open(self.config_file, "r") as f:
            config = toml.load(f)

        # Add dependency
        config["dependensi"][name] = url

        # Save config
        with open(self.config_file, "w") as f:
            toml.dump(config, f)

        print(f"📦 Menambahkan paket '{name}'...")
        self._install_package(name, url)
        print(f"✅ Paket '{name}' berhasil ditambahkan.")

    def remove_package(self, name):
        if not os.path.exists(self.config_file):
            print("⚠️  File konfigurasi tidak ditemukan.")
            return

        with open(self.config_file, "r") as f:
            config = toml.load(f)

        if name not in config["dependensi"]:
            print(f"⚠️  Paket '{name}' tidak ditemukan dalam dependensi.")
            return

        del config["dependensi"][name]

        with open(self.config_file, "w") as f:
            toml.dump(config, f)

        # Remove from vendor
        pkg_path = os.path.join(self.vendor_dir, name)
        if os.path.exists(pkg_path):
            shutil.rmtree(pkg_path)

        print(f"✅ Paket '{name}' berhasil dihapus.")

    def list_packages(self):
        if not os.path.exists(self.config_file):
            print("⚠️  File konfigurasi tidak ditemukan.")
            return

        with open(self.config_file, "r") as f:
            config = toml.load(f)

        print(f"📦 Dependensi untuk proyek '{config['proyek'].get('nama', 'tanpa-nama')}':")
        deps = config.get("dependensi", {})
        if not deps:
            print("   (Tidak ada dependensi)")
        else:
            for name, url in deps.items():
                print(f"   - {name}: {url}")

    def _install_package(self, name, url):
        # Create vendor dir if not exists
        os.makedirs(self.vendor_dir, exist_ok=True)
        
        target_dir = os.path.join(self.vendor_dir, name)
        
        if os.path.exists(target_dir):
            shutil.rmtree(target_dir)

        # Clone git repo
        try:
            # Check if url is a git repo
            if url.endswith(".git"):
                subprocess.check_call(["git", "clone", "--depth", "1", url, target_dir], 
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                # Assume local path for testing/simplicity if not git
                # Or just error out for now
                if os.path.exists(url):
                     shutil.copytree(url, target_dir)
                else:
                    print(f"⚠️  URL '{url}' bukan repository git atau path lokal yang valid.")
        except Exception as e:
            print(f"❌ Gagal menginstall paket '{name}': {e}")
