import sys
import os
from .repl import start_repl, run
from .formatter import Formatter
from .lexer import Lexer
from .parser import Parser
from .interpreter import Interpreter, global_symbol_table
from .environment import Environment
from .errors import CnzrError as Error
from .formatter import Formatter
from .linter import Linter

HELP_MESSAGE = """
CNZR Language (v1.0) - Bahasa Pemrograman High-Level Berbahasa Indonesia

Penggunaan:
  cnzr                  : Membuka REPL (Mode Interaktif)
  cnzr run <file.cnzr>  : Menjalankan file script CNZR
  cnzr init <nama>      : Membuat proyek baru
  cnzr fmt <file.cnzr>  : Merapikan kode otomatis
  cnzr test [path]      : Menjalankan unit test
  cnzr spec-test        : Menjalankan spec tests
  cnzr lint <file.cnzr> : Memeriksa kode (linter)
  cnzr style            : Menampilkan panduan gaya kode
  cnzr pemula           : Membuka REPL Mode Pemula
  cnzr --help           : Menampilkan bantuan ini

Contoh:
  cnzr init halo-dunia
  cnzr run contoh/halo.cnzr
  cnzr fmt main.cnzr
  cnzr test
"""

def create_project(project_name, template_type="default"):
    if os.path.exists(project_name):
        print(f"❌ Error: Folder '{project_name}' sudah ada. Pilih nama lain atau hapus folder tersebut.")
        return

    try:
        os.makedirs(project_name)
        
        main_content = ""
        readme_content = ""
        
        if template_type == "cli":
            main_content = """# Aplikasi CLI Sederhana
# Jalankan dengan: cnzr run main.cnzr

tulis "Selamat datang di Aplikasi CLI!"
tulis "Ketik 'bantuan' untuk melihat perintah."

selama benar:
    setel perintah = tanya ">> "
    
    jika perintah == "keluar":
        tulis "Sampai jumpa!"
        keluar
        
    jika perintah == "bantuan":
        tulis "Perintah tersedia:"
        tulis "  - bantuan : Tampilkan pesan ini"
        tulis "  - sapa    : Menyapa pengguna"
        tulis "  - keluar  : Keluar aplikasi"
        
    jika perintah == "sapa":
        setel nama = tanya "Siapa nama Anda? "
        tulis "Halo, " + nama + "!"
"""
            readme_content = f"""# {project_name} (CLI App)

Aplikasi Command Line Interface sederhana dibuat dengan CNZR.

## Cara Menjalankan
```bash
cnzr run main.cnzr
```
"""

        elif template_type == "catatan":
            os.makedirs(os.path.join(project_name, "data"))
            main_content = """# Aplikasi Catatan Sederhana
pakai berkas

fungsi tambah_catatan():
    setel isi = tanya "Tulis catatan Anda: "
    berkas.tulis("data/catatan.txt", isi + "\\n", "tambah")
    tulis "Catatan disimpan!"

fungsi baca_catatan():
    tulis "--- Daftar Catatan ---"
    setel isi = berkas.baca("data/catatan.txt")
    tulis isi
    tulis "----------------------"

selama benar:
    tulis "\\nMenu:"
    tulis "1. Tambah Catatan"
    tulis "2. Baca Catatan"
    tulis "3. Keluar"
    
    setel pilihan = tanya "Pilih menu (1-3): "
    
    jika pilihan == "1":
        tambah_catatan()
    jika pilihan == "2":
        baca_catatan()
    jika pilihan == "3":
        tulis "Sampai jumpa!"
        keluar
"""
            readme_content = f"""# {project_name} (Aplikasi Catatan)

Aplikasi pencatat sederhana yang menyimpan data ke file.

## Struktur
- `main.cnzr`: Logika utama
- `data/`: Folder penyimpanan catatan

## Cara Menjalankan
```bash
cnzr run main.cnzr
```
"""

        elif template_type == "game-teks":
            main_content = """# Game Petualangan Teks
tulis "Anda berada di depan gerbang kastil tua."
tulis "Apa yang ingin Anda lakukan?"

setel lokasi = "gerbang"
setel punya_kunci = salah

selama benar:
    setel aksi = tanya "> "
    
    jika lokasi == "gerbang":
        jika aksi == "lihat":
            tulis "Gerbang besar tertutup rapat. Ada semak-semak di samping."
        jika aksi == "periksa semak":
            tulis "Anda menemukan kunci berkarat!"
            setel punya_kunci = benar
        jika aksi == "buka gerbang":
            jika punya_kunci:
                tulis "Gerbang terbuka! Anda masuk ke dalam."
                setel lokasi = "dalam"
            jika tidak:
                tulis "Gerbang terkunci. Anda butuh kunci."
                
    jika lokasi == "dalam":
        jika aksi == "lihat":
            tulis "Anda berada di aula besar. Ada harta karun!"
        jika aksi == "ambil harta":
            tulis "Selamat! Anda kaya raya!"
            keluar

    jika aksi == "keluar":
        tulis "Permainan berakhir."
        keluar
"""
            readme_content = f"""# {project_name} (Game Teks)

Game petualangan berbasis teks.

## Cara Bermain
Gunakan perintah seperti `lihat`, `periksa ...`, `buka ...`.

## Cara Menjalankan
```bash
cnzr run main.cnzr
```
"""

        else: # Default
            main_content = """# Selamat datang di CNZR Language
# Ini adalah titik awal proyek Anda.

tulis "Halo, dunia dari CNZR!"

fungsi mulai():
    tulis "Fungsi 'mulai' sudah dipanggil."
    tulis "Silakan kembangkan logika program Anda di sini."

mulai()
"""
            readme_content = f"""# Proyek {project_name}

Proyek ini dibuat menggunakan CNZR Language.

## Cara Menjalankan
Jalankan perintah berikut di terminal:

```bash
cnzr run main.cnzr
```

## Ide Pengembangan
1. Tambahkan fungsi baru.
2. Gunakan `tanya` untuk interaksi pengguna.
3. Gunakan modul `pakai berkas` untuk menyimpan data.

Selamat berkarya!
"""
            # Create examples folder for default template only
            examples_dir = os.path.join(project_name, "contoh")
            os.makedirs(examples_dir)
            with open(os.path.join(examples_dir, "contoh_kecil.cnzr"), "w", encoding="utf-8") as f:
                f.write('tulis "Ini adalah contoh skrip tambahan."\n')

        with open(os.path.join(project_name, "main.cnzr"), "w", encoding="utf-8") as f:
            f.write(main_content)

        with open(os.path.join(project_name, "README.md"), "w", encoding="utf-8") as f:
            f.write(readme_content)
            
        print(f"✅ Proyek '{project_name}' berhasil dibuat (Tipe: {template_type})!")
        print(f"Langkah selanjutnya:")
        print(f"  cd {project_name}")
        print(f"  cnzr run main.cnzr")

    except Exception as e:
        print(f"❌ Terjadi kesalahan saat membuat proyek:\n{e}")

def format_file(filename):
    if not os.path.exists(filename):
        print(f"❌ Error: File '{filename}' tidak ditemukan.")
        return

    try:
        with open(filename, "r", encoding="utf-8") as f:
            script = f.read()

        lexer = Lexer(filename, script)
        tokens, error = lexer.make_tokens()
        if error:
            print(f"❌ Error saat membaca file (Lexer):\n{error}")
            return

        parser = Parser(tokens)
        ast = parser.parse()
        if ast.error:
            print(f"❌ Tidak bisa memformat karena ada kesalahan sintaks:\n{ast.error.as_string()}")
            return

        formatter = Formatter()
        formatted_code = formatter.format(ast.node)

        with open(filename, "w", encoding="utf-8") as f:
            f.write(formatted_code)
        
        print(f"✅ File '{filename}' berhasil diformat.")

    except Exception as e:
        print(f"❌ Terjadi kesalahan saat memformat:\n{e}")

def run_tests(path):
    test_files = []
    if os.path.isfile(path):
        if path.endswith("_test.cnzr"):
            test_files.append(path)
    elif os.path.isdir(path):
        for root, dirs, files in os.walk(path):
            for file in files:
                if file.endswith("_test.cnzr"):
                    test_files.append(os.path.join(root, file))
    
    if not test_files:
        print("⚠️  Tidak ditemukan file test (*_test.cnzr).")
        return

    print(f"Menjalankan {len(test_files)} file test...\n")
    
    total_tests = 0
    passed_tests = 0
    failed_tests = 0
    
    for test_file in test_files:
        print(f"📄 {test_file}...")
        try:
            with open(test_file, "r", encoding="utf-8") as f:
                script = f.read()
            
            result, error = run(test_file, script)
            
            if error:
                if isinstance(error, CnzrTestError):
                    print(f"  ❌ GAGAL: {error.details}")
                    failed_tests += 1
                else:
                    err_msg = error.as_string() if hasattr(error, 'as_string') else str(error)
                    print(f"  ❌ ERROR: {err_msg}")
                    failed_tests += 1
            else:
                print("  ✅ LULUS")
                passed_tests += 1
            
            total_tests += 1
            
        except Exception as e:
             print(f"  ❌ CRASH: {e}")
             failed_tests += 1
             total_tests += 1

    print("\n" + "="*30)
    print(f"Total: {total_tests}, Lulus: {passed_tests}, Gagal: {failed_tests}")
    if failed_tests > 0:
        print("❌ Ada test yang gagal.")
    else:
        print("✅ Semua test lulus!")

from .docs_index import DOCS_INDEX
from .ast_nodes import FuncDefNode, ClassDefNode

def print_help():
    print(HELP_MESSAGE)

def print_doc(target):
    # 1. Check built-in docs
    if target in DOCS_INDEX:
        doc = DOCS_INDEX[target]
        print(f"\n📘 Dokumentasi: {target}")
        print(f"   Jenis    : {doc['jenis']}")
        print(f"   Deskripsi: {doc['deskripsi']}")
        print(f"   Contoh   :\n{doc['contoh']}\n")
        return

    # 2. Check file:symbol
    if ":" in target:
        filename, symbol = target.split(":", 1)
        if not filename.endswith(".cnzr"):
            filename += ".cnzr"
            
        if not os.path.exists(filename):
            print(f"❌ Error: File '{filename}' tidak ditemukan.")
            return

        try:
            with open(filename, "r", encoding="utf-8") as f:
                script = f.read()
            
            lexer = Lexer(filename, script)
            tokens, error = lexer.make_tokens()
            if error:
                print(f"❌ Error saat membaca file:\n{error}")
                return
                
            parser = Parser(tokens)
            ast = parser.parse()
            if ast.error:
                print(f"❌ Error parsing file:\n{ast.error.as_string()}")
                return
                
            # Find symbol
            found = False
            for node in ast.node:
                if isinstance(node, (FuncDefNode, ClassDefNode)):
                    if node.var_name_tok.value == symbol:
                        found = True
                        doc = node.docstring if node.docstring else "(Tidak ada dokumentasi)"
                        kind = "Fungsi" if isinstance(node, FuncDefNode) else "Kelas"
                        print(f"\n📘 Dokumentasi: {symbol} (dari {filename})")
                        print(f"   Jenis    : {kind}")
                        print(f"   Deskripsi: {doc}\n")
                        break
            
            if not found:
                print(f"⚠️  Simbol '{symbol}' tidak ditemukan di '{filename}'.")

        except Exception as e:
            print(f"❌ Terjadi kesalahan: {e}")
        return

    print(f"⚠️  Dokumentasi untuk '{target}' tidak ditemukan.")
    print("Coba 'cnzr help' untuk melihat daftar perintah.")

from .compiler import Compiler
from .bytecode_io import save_bytecode, load_bytecode
from .vm import VM

def build_file(filename, debug=False):
    if not filename.endswith(".cnzr"):
        print("❌ Error: File harus berakhiran .cnzr")
        return

    if not os.path.exists(filename):
        print(f"❌ Error: File '{filename}' tidak ditemukan.")
        return

    try:
        with open(filename, "r", encoding="utf-8") as f:
            script = f.read()
        
        lexer = Lexer(filename, script)
        tokens, error = lexer.make_tokens()
        if error:
            print(f"❌ Error saat membaca file:\n{error}")
            return
            
        parser = Parser(tokens)
        ast = parser.parse()
        if ast.error:
            print(f"❌ Error parsing file:\n{ast.error.as_string()}")
            return
            
        compiler = Compiler()
        program = compiler.compile(ast.node)
        
        output_path = filename.replace(".cnzr", ".cnbc")
        save_bytecode(program, output_path)
        
        print(f"✅ Berhasil membangun bytecode: {output_path}")
        
        if debug:
            print("\n--- Bytecode Listing ---")
            print("Konstanta:", program.constants)
            print("Nama:", program.names)
            print("Instruksi:")
            for i, instr in enumerate(program.code):
                print(f"{i:03}: {instr}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan saat build: {e}")
        import traceback
        traceback.print_exc()

def run_file(filename, debug=False):
    if filename.endswith(".cnbc"):
        # Run Bytecode
        try:
            program = load_bytecode(filename)
            vm = VM(program)
            vm.run()
        except Exception as e:
            print(f"❌ Runtime Error (VM): {e}")
            if debug:
                import traceback
                traceback.print_exc()
        return

    if not filename.endswith(".cnzr"):
        print("❌ Error: File harus berakhiran .cnzr atau .cnbc")
        return

    if not os.path.exists(filename):
        print(f"❌ Error: File '{filename}' tidak ditemukan.")
        return

    with open(filename, "r", encoding="utf-8") as f:
        script = f.read()

    if debug:
        print(f"--- Debug Mode: {filename} ---")

    # Lexer
    lexer = Lexer(filename, script)
    tokens, error = lexer.make_tokens()

    if error:
        print(error.as_string())
        return

    if debug:
        print("Tokens:", tokens)

    # Parser
    parser = Parser(tokens)
    ast = parser.parse()

    if ast.error:
        print(ast.error.as_string())
        return

    if debug:
        print("AST:", ast.node)

    # Interpreter
    interpreter = Interpreter()
    context = Environment('<program>')
    context.symbols = global_symbol_table.symbols.copy() # Copy globals
    result = interpreter.visit(ast.node, context)

    if result.error:
        print(result.error.as_string())

def main():
    args = sys.argv[1:]

    if len(args) == 0:
        start_repl()
        return

    command = args[0]

    if command == "init":
        if len(args) < 2:
            print("⚠️  Error: Nama proyek belum ditentukan.")
            print("Gunakan: cnzr init <nama_proyek>")
            return
        # Check for --tipe argument
        template_type = "default"
        project_name = args[1]
        
        if len(args) >= 4 and args[2] == "--tipe":
            template_type = args[3]
            
        create_project(project_name, template_type)
        return

    if command == "fmt":
        if len(args) < 2:
            print("⚠️  Error: Nama file belum ditentukan.")
            print("Gunakan: cnzr fmt <file.cnzr>")
            return
        format_file(args[1])
        return

    if command == "test":
        path = args[1] if len(args) > 1 else "."
        run_tests(path)
        return

    if command == "build":
        if len(args) < 2:
            print("⚠️  Error: Nama file belum ditentukan.")
            print("Gunakan: cnzr build <file.cnzr>")
            return
        
        debug = "--debug" in args
        build_file(args[1], debug)
        return

    if command == "run":
        if len(args) < 2:
            print("⚠️  Error: Nama file belum ditentukan.")
            print("Gunakan: cnzr run <file.cnzr>")
            return
        
        debug = "--debug" in args
        # Filter out flags from filename argument
        filename = args[1]
        if filename.startswith("--"):
             if len(args) > 2: filename = args[2]
        
        run_file(filename, debug)
        return

    if command in ["--help", "-h", "bantuan"]:
        print(HELP_MESSAGE)
        return

    if command == "doc":
        if len(args) < 2:
            print("⚠️  Error: Nama topik belum ditentukan.")
            print("Gunakan: cnzr doc <topik>")
            return
        print_doc(args[1])
        return

    if command == "style":
        print_style_guide()
        return

    if command == "spec-test":
        run_spec_tests()
        return

    if command == "lint":
        if len(args) < 2:
            print("⚠️  Error: Nama file belum ditentukan.")
            print("Gunakan: cnzr lint <file.cnzr>")
            return
        lint_file(args[1])
        return

    if command == "pemula" or command == "--pemula":
        start_repl(mode_pemula=True)
        return
        
    # Default to run if first arg is a file
    if command.endswith(".cnzr") or command.endswith(".cnbc"):
        run_file(command)
        return

    print(f"Perintah tidak dikenal: {command}")
    print("Gunakan 'cnzr --help' untuk bantuan.")

def print_style_guide():
    print("\n🎨 Panduan Gaya Penulisan CNZR (Style Guide) v1.0")
    print("--------------------------------------------------")
    print("1. Penamaan:")
    print("   - Variabel/Fungsi : snake_case (contoh: jumlah_siswa)")
    print("   - Kelas           : PascalCase (contoh: MahasiswaBaru)")
    print("   - Konstanta       : SCREAMING_SNAKE (contoh: MAX_LIMIT)")
    print("\n2. Format:")
    print("   - Indentasi       : 4 spasi (JANGAN pakai Tab)")
    print("   - Spasi Operator  : 1 spasi (contoh: a + b, x == 1)")
    print("   - Blok            : Tidak ada spasi sebelum ':'")
    print("\n📄 Selengkapnya: docs/cnzr_style_guide_v1.md")
    print("--------------------------------------------------\n")

def run_spec_tests():
    import io
    from contextlib import redirect_stdout

    spec_dir = "tests/spec"
    if not os.path.exists(spec_dir):
        print(f"⚠️  Folder '{spec_dir}' tidak ditemukan.")
        return

    print(f"🚀 Menjalankan Spec Tests dari '{spec_dir}'...\n")
    
    test_files = []
    for root, dirs, files in os.walk(spec_dir):
        for file in files:
            if file.endswith(".cnzr"):
                test_files.append(os.path.join(root, file))
    
    total = 0
    passed = 0
    failed = 0
    
    for test_file in sorted(test_files):
        out_file = test_file.replace(".cnzr", ".out")
        if not os.path.exists(out_file):
            continue # Skip if no expected output
            
        total += 1
        print(f"📄 {test_file}...", end=" ")
        
        # Capture output
        f = io.StringIO()
        try:
            with redirect_stdout(f):
                run_file(test_file)
            actual_output = f.getvalue().strip()
        except Exception as e:
            actual_output = f"CRASH: {e}"
            
        with open(out_file, "r", encoding="utf-8") as f:
            expected_output = f.read().strip()
            
        if actual_output == expected_output:
            print("✅ PASS")
            passed += 1
        else:
            print("❌ FAIL")
            print(f"   Expected:\n{expected_output}")
            print(f"   Actual:\n{actual_output}")
            failed += 1
            
    print("\n" + "="*30)
    print(f"Total: {total}, Pass: {passed}, Fail: {failed}")
    if failed > 0:
        print("❌ Ada test yang gagal.")
        sys.exit(1)
    else:
        print("✅ Semua spec test lulus!")

def lint_file(filename):
    if not os.path.exists(filename):
        print(f"❌ Error: File '{filename}' tidak ditemukan.")
        return

    try:
        with open(filename, "r", encoding="utf-8") as f:
            script = f.read()

        lexer = Lexer(filename, script)
        tokens, error = lexer.make_tokens()
        if error:
            print(f"❌ Error saat membaca file (Lexer):\n{error}")
            return

        parser = Parser(tokens)
        ast = parser.parse()
        if ast.error:
            print(f"❌ Tidak bisa linting karena ada kesalahan sintaks:\n{ast.error.as_string()}")
            return

        linter = Linter()
        issues = linter.lint(ast.node)

        if not issues:
            print(f"✅ Tidak ditemukan masalah pada '{filename}'.")
            return

        print(f"⚠️  Ditemukan {len(issues)} masalah pada '{filename}':\n")
        for pos, level, msg in issues:
            print(f"{filename}:{pos.ln + 1}:{pos.col + 1}: [{level}] {msg}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan saat linting:\n{e}")

