from .ast_nodes import *
from .tokens import *

class LintRule:
    def __init__(self, id, message, level="WARNING"):
        self.id = id
        self.message = message
        self.level = level

    def check(self, node):
        return []

class EmptyIfBlockRule(LintRule):
    def __init__(self):
        super().__init__("L001", "Blok 'jika' kosong", "WARNING")

    def check(self, node):
        issues = []
        if isinstance(node, IfNode):
            for condition, statements in node.cases:
                if not statements:
                    issues.append((node.pos_start, self.message))
            if node.else_case is not None and not node.else_case:
                issues.append((node.pos_start, "Blok 'jika tidak' kosong"))
        return issues

class FunctionNameRule(LintRule):
    def __init__(self):
        super().__init__("L002", "Nama fungsi harus snake_case", "WARNING")

    def check(self, node):
        issues = []
        if isinstance(node, FuncDefNode):
            if node.var_name_tok:
                name = node.var_name_tok.value
                if not name.islower() and name != "__init__":
                     issues.append((node.var_name_tok.pos_start, f"Nama fungsi '{name}' sebaiknya snake_case (huruf kecil)"))
        return issues

class Linter:
    def __init__(self):
        self.rules = [
            EmptyIfBlockRule(),
            FunctionNameRule()
        ]

    def lint(self, ast_node):
        issues = []
        self.visit(ast_node, issues)
        return issues

    def visit(self, node, issues):
        for rule in self.rules:
            rule_issues = rule.check(node)
            for pos, msg in rule_issues:
                issues.append((pos, rule.level, msg))

        # Recursively visit children
        # This is a simplified traversal, ideally we should use a visitor pattern
        # matching the interpreter's structure or a generic traversal.
        # For now, let's handle common container nodes.
        
        if isinstance(node, list):
            for child in node:
                self.visit(child, issues)
        elif hasattr(node, '__dict__'):
            for key, value in node.__dict__.items():
                if isinstance(value, (list, tuple)):
                    for item in value:
                        if hasattr(item, 'pos_start'): # heuristic for AST node
                            self.visit(item, issues)
                elif hasattr(value, 'pos_start'):
                    self.visit(value, issues)
