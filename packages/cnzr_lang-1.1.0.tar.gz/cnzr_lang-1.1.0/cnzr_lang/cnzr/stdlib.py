import time
import random
import os
import math
from .interpreter import Number, String, List, RTResult, Value

class Module:
    def __init__(self, name):
        self.name = name
        self.methods = {}

    def get(self, name):
        return self.methods.get(name)

    def __repr__(self):
        return f"<module {self.name}>"

class TeksModule(Module):
    def __init__(self):
        super().__init__('teks')
        self.methods = {
            'kecil': self.kecil,
            'besar': self.besar,
            'ganti': self.ganti,
            'bagi': self.bagi,
            'gabung': self.gabung
        }

    def kecil(self, args):
        if len(args) != 1 or not isinstance(args[0], String): return RTResult().failure("teks.kecil expects 1 string")
        return RTResult().success(String(args[0].value.lower()))

    def besar(self, args):
        if len(args) != 1 or not isinstance(args[0], String): return RTResult().failure("teks.besar expects 1 string")
        return RTResult().success(String(args[0].value.upper()))

    def ganti(self, args):
        if len(args) != 3: return RTResult().failure("teks.ganti expects 3 arguments")
        return RTResult().success(String(args[0].value.replace(args[1].value, args[2].value)))

    def bagi(self, args):
        if len(args) != 2: return RTResult().failure("teks.bagi expects 2 arguments")
        parts = args[0].value.split(args[1].value)
        return RTResult().success(List([String(p) for p in parts]))

    def gabung(self, args):
        if len(args) != 2 or not isinstance(args[0], List): return RTResult().failure("teks.gabung expects list and separator")
        res = args[1].value.join([str(x.value) for x in args[0].elements])
        return RTResult().success(String(res))

class DaftarModule(Module):
    def __init__(self):
        super().__init__('daftar')
        self.methods = {
            'tambah': self.tambah,
            'hapus': self.hapus,
            'urutkan': self.urutkan,
            'panjang': self.panjang
        }

    def tambah(self, args):
        if len(args) != 2 or not isinstance(args[0], List): return RTResult().failure("daftar.tambah expects list and value")
        args[0].elements.append(args[1])
        return RTResult().success(Number(0))

    def hapus(self, args):
        if len(args) != 2 or not isinstance(args[0], List): return RTResult().failure("daftar.hapus expects list and value")
        # Need to find element with same value
        to_remove = None
        for el in args[0].elements:
            if el.value == args[1].value: # Simple value comparison
                to_remove = el
                break
        if to_remove:
            args[0].elements.remove(to_remove)
        return RTResult().success(Number(0))

    def urutkan(self, args):
        if len(args) < 1 or not isinstance(args[0], List): return RTResult().failure("daftar.urutkan expects list")
        reverse = False
        if len(args) > 1 and args[1].is_true(): reverse = True # Assuming args[1] is boolean-like
        
        # Sort based on value
        try:
            args[0].elements.sort(key=lambda x: x.value, reverse=reverse)
        except:
            return RTResult().failure("Cannot sort list with mixed types")
        return RTResult().success(Number(0))

    def panjang(self, args):
        if len(args) != 1 or not isinstance(args[0], List): return RTResult().failure("daftar.panjang expects list")
        return RTResult().success(Number(len(args[0].elements)))

class AngkaModule(Module):
    def __init__(self):
        super().__init__('angka')
        self.methods = {
            'acak': self.acak,
            'bulat': self.bulat,
            'maks': self.maks,
            'min': self.min
        }

    def acak(self, args):
        if len(args) != 2: return RTResult().failure("angka.acak expects min and max")
        return RTResult().success(Number(random.randint(int(args[0].value), int(args[1].value))))

    def bulat(self, args):
        if len(args) != 1: return RTResult().failure("angka.bulat expects number")
        return RTResult().success(Number(round(args[0].value)))

    def maks(self, args):
        if len(args) != 1 or not isinstance(args[0], List): return RTResult().failure("angka.maks expects list")
        if not args[0].elements: return RTResult().success(Number(0)) # Or error?
        return RTResult().success(Number(max([x.value for x in args[0].elements])))

    def min(self, args):
        if len(args) != 1 or not isinstance(args[0], List): return RTResult().failure("angka.min expects list")
        if not args[0].elements: return RTResult().success(Number(0))
        return RTResult().success(Number(min([x.value for x in args[0].elements])))

class WaktuModule(Module):
    def __init__(self):
        super().__init__('waktu')
        self.methods = {
            'sekarang': self.sekarang,
            'tidur': self.tidur
        }

    def sekarang(self, args):
        return RTResult().success(String(time.ctime()))

    def tidur(self, args):
        if len(args) != 1: return RTResult().failure("waktu.tidur expects seconds")
        time.sleep(args[0].value)
        return RTResult().success(Number(0))

class BerkasModule(Module):
    def __init__(self):
        super().__init__('berkas')
        self.methods = {
            'baca': self.baca,
            'tulis': self.tulis,
            'tambah': self.tambah
        }

    def baca(self, args):
        if len(args) != 1: return RTResult().failure("berkas.baca expects path")
        try:
            with open(args[0].value, 'r') as f:
                return RTResult().success(String(f.read()))
        except Exception as e:
            return RTResult().failure(f"Error reading file: {str(e)}")

    def tulis(self, args):
        if len(args) != 2: return RTResult().failure("berkas.tulis expects path and content")
        try:
            with open(args[0].value, 'w') as f:
                f.write(str(args[1].value))
            return RTResult().success(Number(0))
        except Exception as e:
            return RTResult().failure(f"Error writing file: {str(e)}")

    def tambah(self, args):
        if len(args) != 2: return RTResult().failure("berkas.tambah expects path and content")
        try:
            with open(args[0].value, 'a') as f:
                f.write(str(args[1].value))
            return RTResult().success(Number(0))
        except Exception as e:
            return RTResult().failure(f"Error appending file: {str(e)}")

STDLIB = {
    'teks': TeksModule(),
    'daftar': DaftarModule(),
    'angka': AngkaModule(),
    'waktu': WaktuModule(),
    'berkas': BerkasModule()
}
