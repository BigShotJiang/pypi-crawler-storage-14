HELP_TEXT = """
Panduan Singkat CNZR:

1. Variabel
   Gunakan 'setel' untuk membuat variabel.
   Contoh: setel nama = "Budi"

2. Output
   Gunakan 'tulis' untuk menampilkan teks.
   Contoh: tulis "Halo Dunia"

3. Input
   Gunakan 'tanya' untuk meminta input.
   Contoh: setel nama = tanya "Siapa nama Anda?"

4. Percabangan
   Gunakan 'jika' untuk kondisi.
   Contoh:
   jika nilai > 70:
       tulis "Lulus"

5. Perulangan
   Gunakan 'ulang' atau 'selama'.
   Contoh:
   ulang 5 kali:
       tulis "Halo"

Ketik 'contoh [topik]' untuk melihat kode lengkap.
Topik: variabel, percabangan, perulangan, fungsi, berkas
"""

EXAMPLES = {
    'variabel': """
setel nama = "Budi"
setel umur = 20
tulis "Nama: " + nama
tulis "Umur: " + umur
""",
    'percabangan': """
setel nilai = 80
jika nilai >= 75:
    tulis "Selamat, Anda Lulus!"
jika tidak:
    tulis "Belajar lagi ya."
""",
    'perulangan': """
# Ulang 3 kali
ulang 3 kali:
    tulis "Hore!"

# Loop daftar
setel hobi = ["Makan", "Tidur"]
untuk setiap h di hobi:
    tulis "Hobi saya: " + h
""",
    'fungsi': """
fungsi sapa(nama):
    tulis "Halo " + nama + "!"

sapa("Andi")
sapa("Siti")
""",
    'berkas': """
pakai berkas

# Tulis file
berkas.tulis("catatan.txt", "Ini catatan saya.")

# Baca file
setel isi = berkas.baca("catatan.txt")
tulis "Isi file: " + isi
"""
}
