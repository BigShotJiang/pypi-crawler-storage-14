from .interpreter import Number, String, List, RTResult

class BuiltinFunction:
    def __init__(self, name):
        self.name = name
        self.pos_start = None
        self.pos_end = None
        self.context = None

    def set_pos(self, pos_start, pos_end):
        self.pos_start = pos_start
        self.pos_end = pos_end
        return self

    def set_context(self, context):
        self.context = context
        return self

    def execute(self, args):
        method_name = f'execute_{self.name}'
        method = getattr(self, method_name, self.no_execute_method)
        return method(args)

    def no_execute_method(self, args):
        raise Exception(f'No execute_{self.name} method defined')

    def copy(self):
        return BuiltinFunction(self.name)

    def __repr__(self):
        return f"<built-in function {self.name}>"

    def execute_tulis(self, args):
        print(*[arg.value for arg in args])
        return RTResult().success(Number(0)) # Return null/0

    def execute_panjang(self, args):
        if len(args) != 1:
            return RTResult().failure(f"panjang() takes exactly 1 argument")
        
        arg = args[0]
        if isinstance(arg, List):
            return RTResult().success(Number(len(arg.elements)))
        if isinstance(arg, String):
            return RTResult().success(Number(len(arg.value)))
        
        return RTResult().failure(f"Argument must be string or list")

    def execute_angka(self, args):
        if len(args) != 1:
            return RTResult().failure(f"angka() takes exactly 1 argument")
        
        try:
            return RTResult().success(Number(float(args[0].value)))
        except ValueError:
            return RTResult().failure(f"Cannot convert to number")

    def execute_teks(self, args):
        if len(args) != 1:
            return RTResult().failure(f"teks() takes exactly 1 argument")
        
        return RTResult().success(String(str(args[0].value)))

    def execute_jenis(self, args):
        if len(args) != 1:
            return RTResult().failure(f"jenis() takes exactly 1 argument")
        
        return RTResult().success(String(type(args[0]).__name__))

    def execute_uji_sama(self, args):
        if len(args) < 2 or len(args) > 3:
            return RTResult().failure(f"uji_sama() takes 2 or 3 arguments")
        
        actual = args[0]
        expected = args[1]
        message = args[2].value if len(args) == 3 else "Nilai tidak sama"
        
        # Simple equality check based on string representation for simplicity
        is_equal = str(actual) == str(expected)
             
        if not is_equal:
             from .errors import CnzrTestError
             return RTResult().failure(CnzrTestError(self.pos_start, self.pos_end, f"{message}\n   Aktual: {actual}\n   Harapan: {expected}", self.context))
             
        return RTResult().success(Number(1))

    def execute_uji_benar(self, args):
        if len(args) < 1 or len(args) > 2:
            return RTResult().failure(f"uji_benar() takes 1 or 2 arguments")
            
        condition = args[0]
        message = args[1].value if len(args) == 2 else "Kondisi tidak benar"
        
        if not condition.is_true():
             from .errors import CnzrTestError
             return RTResult().failure(CnzrTestError(self.pos_start, self.pos_end, message, self.context))
             
        return RTResult().success(Number(1))

BuiltinFunction.tulis = BuiltinFunction('tulis')
BuiltinFunction.panjang = BuiltinFunction('panjang')
BuiltinFunction.angka = BuiltinFunction('angka')
BuiltinFunction.teks = BuiltinFunction('teks')
BuiltinFunction.jenis = BuiltinFunction('jenis')
BuiltinFunction.uji_sama = BuiltinFunction('uji_sama')
BuiltinFunction.uji_benar = BuiltinFunction('uji_benar')
