class CnzrError:
    def __init__(self, pos_start, pos_end, error_name, details, tip=None, hint=None):
        self.pos_start = pos_start
        self.pos_end = pos_end
        self.error_name = error_name
        self.details = details
        self.tip = tip
        self.hint = hint

    def as_string(self):
        result = f'⚠️  Terjadi kesalahan: {self.error_name}\n'
        result += f'   Penjelasan: {self.details}\n'
        result += f'   Lokasi: Baris {self.pos_start.ln + 1}, Kolom {self.pos_start.col + 1}'
        if self.tip:
            result += f'\n   💡 Tip: {self.tip}'
        if self.hint:
            result += f'\n   🎓 Saran: {self.hint}'
        return result

class CnzrSyntaxError(CnzrError):
    def __init__(self, pos_start, pos_end, details):
        hint = None
        if "Expected ':'" in details:
            hint = "Pastikan Anda menambahkan titik dua ':' di akhir baris pernyataan seperti 'jika', 'selama', atau 'fungsi'."
        elif "Expected INDENT" in details:
            hint = "Baris ini seharusnya menjorok ke dalam (indentasi). Coba tambahkan 4 spasi di awal baris."
            
        super().__init__(pos_start, pos_end, 'Kesalahan Sintaks', details, 
                         "Periksa kembali penulisan kode Anda. Pastikan tanda kurung, kutip, dan indentasi sudah benar.",
                         hint=hint)

class CnzrNameError(CnzrError):
    def __init__(self, pos_start, pos_end, details, context=None):
        hint = "Coba periksa apakah variabel tersebut sudah didefinisikan dengan 'setel' sebelumnya."
        super().__init__(pos_start, pos_end, 'Nama Tidak Ditemukan', details,
                         "Pastikan variabel atau fungsi ini sudah didefinisikan sebelumnya dengan 'setel' atau 'fungsi'.",
                         hint=hint)
        self.context = context

class CnzrTypeError(CnzrError):
    def __init__(self, pos_start, pos_end, details, context=None):
        super().__init__(pos_start, pos_end, 'Kesalahan Tipe Data', details,
                         "Operasi ini tidak bisa dilakukan pada tipe data tersebut.")
        self.context = context

class CnzrRuntimeError(CnzrError):
    def __init__(self, pos_start, pos_end, details, context):
        super().__init__(pos_start, pos_end, 'Kesalahan Runtime', details)
        self.context = context

    def as_string(self):
        result = self.generate_traceback()
        result += f'⚠️  Terjadi kesalahan: {self.error_name}\n'
        result += f'   Penjelasan: {self.details}'
        if self.tip:
             result += f'\n   💡 Tip: {self.tip}'
        return result

    def generate_traceback(self):
        result = ''
        pos = self.pos_start
        ctx = self.context

        while ctx:
            result = f'    di fungsi \'{ctx.display_name}\', file {pos.fn}, baris {str(pos.ln + 1)}\n' + result
            pos = ctx.parent_entry_pos
            ctx = ctx.parent

        return '\nJejak eksekusi:\n' + result

class CnzrTestError(CnzrError):
    def __init__(self, pos_start, pos_end, details, context=None):
        super().__init__(pos_start, pos_end, 'Kegagalan Tes', details,
                         "Periksa nilai aktual dan harapan.")
        self.context = context

# Aliases for backward compatibility during refactor
InvalidSyntaxError = CnzrSyntaxError
RTError = CnzrRuntimeError
