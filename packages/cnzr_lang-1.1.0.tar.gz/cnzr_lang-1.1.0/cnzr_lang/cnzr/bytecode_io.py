import struct
from .bytecode import BytecodeProgram, OpCode, Instruction

MAGIC = b'CNZRBC'
VERSION = 1

def save_bytecode(program: BytecodeProgram, path: str):
    with open(path, 'wb') as f:
        # Header
        f.write(MAGIC)
        f.write(struct.pack('B', VERSION))

        # Constants
        f.write(struct.pack('<I', len(program.constants)))
        for const in program.constants:
            if const is None:
                f.write(b'\x01')
            elif isinstance(const, bool):
                f.write(b'\x02')
                f.write(b'\x01' if const else b'\x00')
            elif isinstance(const, int):
                f.write(b'\x03')
                f.write(struct.pack('<q', const)) # int64
            elif isinstance(const, float):
                f.write(b'\x04')
                f.write(struct.pack('<d', const)) # float64
            elif isinstance(const, str):
                f.write(b'\x05')
                encoded = const.encode('utf-8')
                f.write(struct.pack('<I', len(encoded)))
                f.write(encoded)
            else:
                raise ValueError(f"Unsupported constant type: {type(const)}")

        # Names
        f.write(struct.pack('<I', len(program.names)))
        for name in program.names:
            encoded = name.encode('utf-8')
            f.write(struct.pack('<I', len(encoded)))
            f.write(encoded)

        # Code
        # Flatten instructions to bytes: Opcode (1 byte) + Arg (4 bytes if present)
        # Wait, spec says Opcode is 1 byte.
        # How do we know if arg is present?
        # For simplicity in v1, let's assume ALL instructions have 4 byte arg.
        # If arg is None, write 0.
        # This simplifies VM loop significantly.
        # Or we can check opcode range.
        # Let's stick to fixed size for v1: 1 byte Op + 4 byte Arg = 5 bytes per instr.
        
        code_bytes = bytearray()
        for instr in program.code:
            code_bytes.append(instr.opcode)
            arg = instr.arg if instr.arg is not None else 0
            code_bytes.extend(struct.pack('<I', arg))
            
        f.write(struct.pack('<I', len(code_bytes)))
        f.write(code_bytes)

def load_bytecode(path: str) -> BytecodeProgram:
    with open(path, 'rb') as f:
        magic = f.read(6)
        if magic != MAGIC:
            raise ValueError("Invalid file format")
        
        version = struct.unpack('B', f.read(1))[0]
        if version != VERSION:
            raise ValueError(f"Unsupported bytecode version: {version}")
            
        program = BytecodeProgram()
        program.version = version
        
        # Constants
        num_consts = struct.unpack('<I', f.read(4))[0]
        for _ in range(num_consts):
            tag = f.read(1)
            if tag == b'\x01':
                program.constants.append(None)
            elif tag == b'\x02':
                val = f.read(1) == b'\x01'
                program.constants.append(val)
            elif tag == b'\x03':
                val = struct.unpack('<q', f.read(8))[0]
                program.constants.append(val)
            elif tag == b'\x04':
                val = struct.unpack('<d', f.read(8))[0]
                program.constants.append(val)
            elif tag == b'\x05':
                length = struct.unpack('<I', f.read(4))[0]
                val = f.read(length).decode('utf-8')
                program.constants.append(val)
            else:
                raise ValueError(f"Unknown constant tag: {tag}")
                
        # Names
        num_names = struct.unpack('<I', f.read(4))[0]
        for _ in range(num_names):
            length = struct.unpack('<I', f.read(4))[0]
            val = f.read(length).decode('utf-8')
            program.names.append(val)
            
        # Code
        code_len = struct.unpack('<I', f.read(4))[0]
        code_data = f.read(code_len)
        
        i = 0
        while i < code_len:
            opcode = OpCode(code_data[i])
            arg = struct.unpack('<I', code_data[i+1:i+5])[0]
            program.emit(opcode, arg)
            i += 5
            
        return program
