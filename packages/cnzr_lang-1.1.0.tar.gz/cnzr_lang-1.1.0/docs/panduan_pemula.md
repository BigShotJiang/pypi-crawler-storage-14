# Panduan Pemula Belajar CNZR

Selamat datang di dunia pemrograman dengan **CNZR Language**! Bahasa ini dirancang khusus agar Anda bisa belajar konsep koding dengan mudah menggunakan Bahasa Indonesia.

## 1. Apa itu CNZR?
CNZR adalah bahasa pemrograman yang "berbicara" bahasa Anda. Tidak perlu pusing dengan istilah bahasa Inggris yang rumit. Cukup tulis logika Anda seperti menulis kalimat biasa.

## 2. Memulai
Pastikan Anda sudah menginstal Python. Lalu jalankan perintah ini di terminal:
```bash
python3 main.py --pemula
```
Anda akan masuk ke **Mode Pemula**, di mana Anda bisa mengetik `bantuan` atau `contoh` untuk melihat panduan langsung.

## 3. Belajar CNZR dalam 10 Menit

### Variabel (Wadah Data)
Bayangkan variabel seperti kotak untuk menyimpan sesuatu.
```cnzr
setel nama = "Budi"
setel umur = 20
```

### Output (Menampilkan Teks)
Gunakan `tulis` untuk menampilkan sesuatu ke layar.
```cnzr
tulis "Halo " + nama
```

### Input (Bertanya ke Pengguna)
Gunakan `tanya` untuk meminta input dari keyboard.
```cnzr
setel hobi = tanya "Apa hobi kamu? "
tulis "Wah, aku juga suka " + hobi
```

### Percabangan (Logika Jika-Maka)
Komputer bisa mengambil keputusan.
```cnzr
jika umur >= 17:
    tulis "Sudah boleh punya KTP"
jika tidak apa-apa:
    tulis "Belum cukup umur"
```
*Catatan: Jangan lupa titik dua `:` dan indentasi (spasi di awal baris).*

### Perulangan (Melakukan Sesuatu Berulang Kali)
```cnzr
# Cara paling mudah
ulang 5 kali:
    tulis "Semangat!"

# Cara untuk daftar
setel buah = ["Apel", "Jeruk", "Mangga"]
untuk setiap b di buah:
    tulis "Saya suka " + b
```

### Fungsi (Kumpulan Perintah)
Bungkus kode Anda agar bisa dipakai lagi.
```cnzr
fungsi sapa(nama):
    tulis "Halo " + nama + ", apa kabar?"

sapa("Andi")
sapa("Siti")
```

## 4. Modul Tambahan (Kekuatan Ekstra)
CNZR punya alat bantu bawaan yang bisa Anda `pakai`.

*   `pakai teks`: Untuk mengolah kata (huruf besar/kecil).
*   `pakai angka`: Untuk matematika (angka acak, pembulatan).
*   `pakai waktu`: Untuk jam dan jeda waktu.
*   `pakai berkas`: Untuk membaca/menulis file.

Contoh:
```cnzr
pakai angka
tulis "Dadu: " + angka.acak(1, 6)
```

Selamat belajar! Jangan takut salah, karena pesan error CNZR akan membantu Anda memperbaikinya.
