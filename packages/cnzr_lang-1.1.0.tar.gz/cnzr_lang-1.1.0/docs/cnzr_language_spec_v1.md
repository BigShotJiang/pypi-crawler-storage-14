# Spesifikasi Bahasa CNZR v1.0

## 1. Pendahuluan

CNZR (dibaca: "Senzar") adalah bahasa pemrograman scripting yang dirancang untuk keterbacaan tinggi dan kemudahan penggunaan bagi pemula, dengan menggunakan kata kunci dalam Bahasa Indonesia.

**Filosofi:**
- **Jelas**: Kode harus mudah dibaca seperti kalimat bahasa Indonesia.
- **Sederhana**: Mengurangi boilerplate dan kompleksitas yang tidak perlu.
- **Edukatif**: Memberikan pesan error yang membantu dan mode pemula.

## 2. Kata Kunci (Keywords)

Berikut adalah daftar kata kunci yang dipesan (reserved keywords) dalam CNZR v1.0:

### Deklarasi & Penugasan
- `setel`: Mendeklarasikan atau mengubah nilai variabel.
- `fungsi`: Mendefinisikan fungsi.
- `kelas`: Mendefinisikan kelas.
- `kembalikan`: Mengembalikan nilai dari fungsi.

### Alur Kontrol
- `jika`: Awal percabangan kondisi.
- `jika tidak`: Alternatif kondisi (else).
- `jika tidak jika`: Kondisi alternatif bersyarat (elif).
- `selama`: Perulangan while.
- `ulang`: Perulangan sederhana (repeat N times).
- `kali`: Bagian dari sintaks `ulang`.
- `untuk`: Perulangan for-each.
- `setiap`: Bagian dari sintaks `untuk`.
- `di`: Bagian dari sintaks `untuk`.

### Logika & Nilai
- `benar`: Boolean true.
- `salah`: Boolean false.
- `kosong`: Nilai null/none.
- `dan`: Operator logika AND.
- `atau`: Operator logika OR.
- `tidak`: Operator logika NOT.

### Input/Output & Modul
- `tulis`: Mencetak ke output standar.
- `tanya`: Menerima input dari pengguna.
- `pakai`: Mengimpor modul.
- `dari`: Mengimpor bagian spesifik dari modul.
- `ambil`: Bagian dari sintaks `dari ... ambil ...`.

### Konkurensi (Eksperimental)
- `tugas`: Menandai fungsi asinkron.
- `tunggu`: Menunggu hasil fungsi asinkron.
- `jalan_bersama`: Menjalankan beberapa tugas secara paralel.

## 3. Tipe Data

CNZR mendukung tipe data berikut:
- **Bilangan**: Integer (`10`) dan Float (`3.14`).
- **Teks**: String diapit kutip ganda (`"Halo"`).
- **Boolean**: `benar` dan `salah`.
- **Daftar**: List terurut (`[1, 2, 3]`).
- **Kosong**: Representasi ketiadaan nilai (`kosong`).

## 4. Tata Bahasa (Grammar)

### Penugasan
Variabel harus dideklarasikan dengan `setel`.
```cnzr
setel nama = "Budi"
setel umur = 25
```

### Percabangan
Blok kode ditandai dengan indentasi (4 spasi disarankan).
```cnzr
jika nilai > 70:
    tulis "Lulus"
jika tidak jika nilai > 50:
    tulis "Remedial"
jika tidak:
    tulis "Gagal"
```

### Perulangan
**Selama (While):**
```cnzr
setel i = 0
selama i < 5:
    tulis i
    setel i = i + 1
```

**Ulang (Repeat):**
```cnzr
ulang 5 kali:
    tulis "Halo"
```

**Untuk (For-Each):**
```cnzr
untuk setiap item di [1, 2, 3]:
    tulis item
```

### Fungsi
```cnzr
fungsi tambah(a, b):
    kembalikan a + b

tulis tambah(5, 3)
```

### Kelas
```cnzr
kelas Kucing:
    fungsi __init__(self, nama):
        setel self.nama = nama
    
    fungsi meong(self):
        tulis self.nama + " berkata: Meong!"

setel k = Kucing("Mochi")
k.meong()
```

## 5. Operator

### Aritmatika
- `+`: Penjumlahan / Penggabungan String
- `-`: Pengurangan
- `*`: Perkalian
- `/`: Pembagian
- `%`: Modulo

### Perbandingan
- `==`: Sama dengan
- `!=`: Tidak sama dengan
- `<`: Kurang dari
- `>`: Lebih dari
- `<=`: Kurang dari atau sama dengan
- `>=`: Lebih dari atau sama dengan

### Logika
- `dan`: Logika AND
- `atau`: Logika OR
- `tidak`: Logika NOT

## 6. Aturan Indentasi
CNZR menggunakan indentasi untuk menentukan blok kode.
- Standar: 4 spasi.
- Tab tidak disarankan untuk konsistensi.
- Indentasi yang tidak konsisten akan menyebabkan error sintaks.
