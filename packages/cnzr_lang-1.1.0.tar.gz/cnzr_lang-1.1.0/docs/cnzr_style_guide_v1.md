# Panduan Gaya Penulisan CNZR (Style Guide) v1.0

Panduan ini dibuat agar kode CNZR yang ditulis oleh komunitas memiliki standar yang konsisten, mudah dibaca, dan rapi.

## 1. Penamaan (Naming Convention)

### Variabel & Fungsi
Gunakan `snake_case` (huruf kecil dipisah garis bawah).
- **Benar**: `jumlah_siswa`, `hitung_luas()`, `nama_pengguna`
- **Salah**: `jumlahSiswa`, `HitungLuas()`, `namapengguna`

### Kelas
Gunakan `PascalCase` (huruf kapital di awal setiap kata).
- **Benar**: `Mahasiswa`, `PengelolaData`, `KucingPersia`
- **Salah**: `mahasiswa`, `pengelola_data`, `KUCING`

### Konstanta
Gunakan `SCREAMING_SNAKE_CASE` (huruf kapital semua dipisah garis bawah).
- **Benar**: `PI`, `MAX_LIMIT`, `URL_API`

## 2. Format Kode

### Indentasi
- Gunakan **4 spasi** per tingkat indentasi.
- Jangan gunakan Tab.

### Spasi
- Berikan **satu spasi** di sekitar operator (`=`, `+`, `-`, `==`, dll).
  - **Benar**: `setel a = 1 + 2`
  - **Salah**: `setel a=1+2`
- Berikan satu spasi setelah koma.
  - **Benar**: `[1, 2, 3]`
  - **Salah**: `[1,2,3]`
- Jangan ada spasi sebelum titik dua (`:`) pada definisi blok.
  - **Benar**: `jika benar:`
  - **Salah**: `jika benar :`

### Baris Kosong
- Gunakan baris kosong untuk memisahkan definisi fungsi atau kelas.
- Gunakan baris kosong di dalam fungsi untuk memisahkan blok logika yang berbeda (opsional, untuk keterbacaan).

### Panjang Baris
- Disarankan maksimal 100 karakter per baris.

## 3. Contoh Kode

### Kode yang Baik (Good)
```cnzr
kelas KalkulatorLuas:
    fungsi persegi_panjang(panjang, lebar):
        kembalikan panjang * lebar

setel panjang_tanah = 20
setel lebar_tanah = 10

jika panjang_tanah > 0 dan lebar_tanah > 0:
    setel luas = KalkulatorLuas().persegi_panjang(panjang_tanah, lebar_tanah)
    tulis "Luas tanah: " + luas
```

### Kode yang Buruk (Bad)
```cnzr
kelas kalkulator: # Salah penamaan kelas
    fungsi Hitung(p,l): # Salah penamaan fungsi, kurang spasi
        kembalikan p*l # Kurang spasi operator

setel P=20 # Kurang spasi
setel L=10

jika P>0 dan L>0 : # Spasi sebelum titik dua
    tulis "Luas: "+(P*L)
```
