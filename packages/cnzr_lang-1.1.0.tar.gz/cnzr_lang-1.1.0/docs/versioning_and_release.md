# Versioning & Alur Rilis CNZR

Dokumen ini menjelaskan kebijakan versi dan rilis untuk bahasa pemrograman CNZR dan ekosistemnya.

## 1. Skema Versioning

CNZR menggunakan **Semantic Versioning 2.0.0** (SemVer).
Format versi: `MAJOR.MINOR.PATCH` (contoh: `1.0.0`)

- **MAJOR**: Perubahan yang tidak kompatibel dengan versi sebelumnya (Breaking Changes).
  - Contoh: Menghapus keyword, mengubah sintaks dasar.
- **MINOR**: Penambahan fitur yang kompatibel ke belakang (Backward Compatible).
  - Contoh: Menambah fungsi standar baru, menambah modul baru.
- **PATCH**: Perbaikan bug yang kompatibel ke belakang.
  - Contoh: Memperbaiki pesan error, optimasi performa.

## 2. Kebijakan Breaking Change

### Bahasa & Sintaks
Kami berkomitmen untuk menjaga stabilitas bahasa.
- Perubahan pada grammar atau keyword yang merusak kode lama hanya boleh dilakukan pada rilis **MAJOR**.
- Fitur yang akan dihapus (deprecated) akan diberi peringatan minimal satu versi MINOR sebelum dihapus.

### Standard Library
- Fungsi atau modul standar tidak akan dihapus atau diubah tanda tangannya (signature) tanpa rilis **MAJOR**, kecuali untuk perbaikan bug keamanan yang kritis.

## 3. Checklist Rilis 1.0

Versi 1.0 menandakan bahwa CNZR telah mencapai stabilitas dan siap digunakan untuk pembelajaran dan proyek hobi.

- [x] **Spesifikasi Bahasa**: Dokumen `cnzr_language_spec_v1.md` telah final.
- [x] **Style Guide**: Dokumen `cnzr_style_guide_v1.md` tersedia.
- [x] **Test Suite**: `cnzr spec-test` tersedia dan semua tes dasar lulus.
- [x] **Tooling**: `cnzr fmt`, `cnzr lint`, `cnzr style` berfungsi dengan baik.
- [x] **Dokumentasi**: Panduan pemula dan referensi API tersedia.

## 4. Alur Rilis (Release Flow)

1.  **Development**: Fitur baru dikembangkan di branch `dev` atau feature branch.
2.  **Testing**: Jalankan `cnzr spec-test` dan `cnzr test` untuk memastikan tidak ada regresi.
3.  **Release Candidate (RC)**: Jika fitur stabil, buat tag RC (misal `v1.1.0-rc1`) untuk pengujian komunitas.
4.  **Stable Release**: Jika tidak ada bug kritis, rilis versi stabil (misal `v1.1.0`) dan publikasikan ke PyPI (atau package manager terkait).
5.  **Changelog**: Perbarui `CHANGELOG.md` dengan daftar perubahan.
