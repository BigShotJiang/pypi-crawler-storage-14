# Fitur Lanjutan CNZR Language (v1.0)

Dokumen ini menjelaskan fitur-fitur tingkat lanjut yang diperkenalkan pada versi 1.0, termasuk Pemrograman Berorientasi Objek (OOP), sistem modul yang lebih baik, auto-formatter, dan unit testing.

## 1. Pemrograman Berorientasi Objek (OOP)

CNZR kini mendukung paradigma OOP dengan sintaks yang intuitif.

### Mendefinisikan Kelas
Gunakan kata kunci `kelas` untuk membuat blueprint objek.

```cnzr
kelas Kucing:
    fungsi __init__(self, nama, warna):
        setel self.nama = nama
        setel self.warna = warna

    fungsi meong(self):
        tulis self.nama + " berkata: Meong!"
```

### Membuat Objek (Instansiasi)
Panggil nama kelas seperti memanggil fungsi.

```cnzr
setel k = Kucing("Mochi", "Putih")
k.meong()
```

### Akses Properti
Gunakan notasi titik (`.`) untuk mengakses atau mengubah properti.

```cnzr
tulis "Warna kucing: " + k.warna
setel k.warna = "Abu-abu"
```

---

## 2. Sistem Modul Lanjutan

Selain `pakai <modul>`, kini Anda bisa mengimpor fungsi atau variabel tertentu dari sebuah modul.

### Import Spesifik (`dari ... ambil ...`)

```cnzr
dari matematika ambil PI, hitung_luas

tulis "Nilai PI: " + PI
tulis "Luas: " + hitung_luas(10)
```

### Memuat File Lokal
Anda bisa memuat file `.cnzr` lain sebagai modul. Pastikan file tersebut berada di folder yang sama.

**utils.cnzr**:
```cnzr
fungsi sapa(nama):
    tulis "Halo " + nama
```

**main.cnzr**:
```cnzr
pakai utils
utils.sapa("Budi")
```

---

## 3. Auto-Formatter (`cnzr fmt`)

Tidak perlu pusing dengan indentasi atau spasi. Gunakan `cnzr fmt` untuk merapikan kode Anda secara otomatis.

```bash
cnzr fmt nama_file.cnzr
```

Formatter akan:
*   Mengatur indentasi menjadi 4 spasi.
*   Menambahkan spasi di sekitar operator (misal `a+b` menjadi `a + b`).
*   Merapikan struktur blok kode.

---

## 4. Unit Testing (`cnzr test`)

Pastikan kode Anda berjalan sesuai harapan dengan fitur testing bawaan.

### Membuat File Test
Buat file dengan akhiran `_test.cnzr` (misalnya `hitung_test.cnzr`).

### Fungsi Assert
Gunakan fungsi bawaan berikut untuk memverifikasi nilai:

*   `uji_sama(aktual, harapan, pesan)`: Memastikan dua nilai sama.
*   `uji_benar(kondisi, pesan)`: Memastikan kondisi bernilai `benar`.

**Contoh `hitung_test.cnzr`**:
```cnzr
fungsi tes_penjumlahan():
    setel hasil = 1 + 1
    uji_sama(hasil, 2, "1 + 1 harus 2")

fungsi tes_logika():
    uji_benar(5 > 3, "5 harus lebih besar dari 3")

tes_penjumlahan()
tes_logika()
```

### Menjalankan Test
Jalankan semua test di folder saat ini (dan subfolder) dengan perintah:

```bash
cnzr test
```

Output akan menunjukkan test mana yang lulus dan mana yang gagal.

---

## 5. Dokumentasi & Bantuan

CNZR memiliki sistem dokumentasi bawaan.

### `cnzr help`
Menampilkan daftar perintah dan sintaks dasar.

### `cnzr doc`
Menampilkan dokumentasi untuk kata kunci, fungsi bawaan, atau kode Anda sendiri.

```bash
cnzr doc tulis
cnzr doc nama_file.cnzr:nama_fungsi
```

### Docstring
Tambahkan dokumentasi ke fungsi atau kelas Anda dengan menempatkan string di baris pertama.

```cnzr
fungsi sapa(nama):
    "Fungsi ini menyapa pengguna."
    tulis "Halo " + nama
```

---

## 6. Template Proyek

Mulai proyek dengan struktur yang benar menggunakan template.

```bash
cnzr init nama_proyek --tipe <tipe>
```

Tipe yang tersedia:
*   `default`: Proyek kosong dengan contoh sederhana.
*   `cli`: Aplikasi Command Line Interface.
*   `catatan`: Aplikasi pencatat menggunakan file.
*   `game-teks`: Game petualangan berbasis teks.

---

## 7. Language Server Protocol (LSP)

CNZR menyediakan Language Server untuk integrasi dengan editor seperti VS Code.

### Fitur
*   **Diagnostics**: Menandai error sintaks (garis merah).
*   **Hover**: Menampilkan info saat kursor berada di atas kode.
*   **Completion**: Saran otomatis untuk kata kunci.

### Integrasi VS Code
Ekstensi VS Code CNZR secara otomatis menjalankan server LSP ini jika Python dan package `cnzr_lang` terinstal.
