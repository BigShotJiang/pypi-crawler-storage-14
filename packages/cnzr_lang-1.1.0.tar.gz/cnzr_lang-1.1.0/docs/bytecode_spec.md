# Spesifikasi Bytecode CNZR (.cnbc)

Versi Bytecode: 1

## Format File (.cnbc)

File `.cnbc` adalah format biner yang digunakan untuk menyimpan program CNZR yang telah dikompilasi. Format ini dirancang agar mudah dibaca oleh Virtual Machine (VM).

Semua integer disimpan dalam format **Little Endian**.
String disimpan sebagai UTF-8.

### Struktur Header

| Offset | Ukuran | Deskripsi | Nilai |
| :--- | :--- | :--- | :--- |
| 0 | 6 bytes | Magic Bytes | `CNZRBC` |
| 6 | 1 byte | Versi Bytecode | `0x01` |

### Tabel Konstanta

Menyimpan nilai-nilai literal (angka, string, boolean, null) yang digunakan dalam program.

| Ukuran | Deskripsi |
| :--- | :--- |
| 4 bytes | Jumlah Konstanta (N) |
| ... | N Data Konstanta |

**Format Data Konstanta:**

Setiap konstanta diawali dengan 1 byte penanda tipe (Tag), diikuti datanya.

| Tag (1 byte) | Tipe | Data |
| :--- | :--- | :--- |
| `0x01` | Null | - (Tidak ada data tambahan) |
| `0x02` | Boolean | 1 byte (0=Salah, 1=Benar) |
| `0x03` | Integer | 8 bytes (int64) |
| `0x04` | Float | 8 bytes (float64 IEEE 754) |
| `0x05` | String | 4 bytes (Panjang L) + L bytes (UTF-8) |

### Tabel Nama

Menyimpan nama-nama variabel, fungsi, dan atribut yang digunakan.

| Ukuran | Deskripsi |
| :--- | :--- |
| 4 bytes | Jumlah Nama (M) |
| ... | M Data String (4 bytes Panjang + Bytes UTF-8) |

### Code Object

Berisi instruksi-instruksi bytecode.

| Ukuran | Deskripsi |
| :--- | :--- |
| 4 bytes | Panjang Bytecode (K) |
| K bytes | Stream Instruksi |

---

## Instruksi (Opcode)

Setiap instruksi terdiri dari **1 byte Opcode**. Beberapa instruksi diikuti oleh **Operand**.

### Stack Manipulation
*   `POP_TOP` (0x01): Menghapus nilai teratas dari stack.
*   `DUP_TOP` (0x02): Menduplikasi nilai teratas stack.

### Load & Store
*   `LOAD_CONST` (0x10) + `Index (4 bytes)`: Push konstanta dari tabel konstanta ke stack.
*   `LOAD_NAME` (0x11) + `Index (4 bytes)`: Push nilai variabel (dari tabel nama) ke stack.
*   `STORE_NAME` (0x12) + `Index (4 bytes)`: Pop nilai dari stack dan simpan ke variabel.
*   `LOAD_ATTR` (0x13) + `Index (4 bytes)`: Mengambil atribut objek (Top of stack = objek).
*   `STORE_ATTR` (0x14) + `Index (4 bytes)`: Menyimpan atribut objek (Top = value, Second = objek).

### Arithmetic & Logic
*   `ADD` (0x20): Penjumlahan (Top + Second).
*   `SUB` (0x21): Pengurangan (Second - Top).
*   `MUL` (0x22): Perkalian.
*   `DIV` (0x23): Pembagian.
*   `MOD` (0x24): Modulo.
*   `POW` (0x25): Pangkat.
*   `EQ` (0x26): Sama dengan (==).
*   `NEQ` (0x27): Tidak sama dengan (!=).
*   `LT` (0x28): Kurang dari (<).
*   `GT` (0x29): Lebih dari (>).
*   `LTE` (0x2A): Kurang dari sama dengan (<=).
*   `GTE` (0x2B): Lebih dari sama dengan (>=).
*   `AND` (0x2C): Logika DAN.
*   `OR` (0x2D): Logika ATAU.
*   `NOT` (0x2E): Logika TIDAK (Unary).
*   `NEG` (0x2F): Negasi Angka (Unary -).

### Control Flow
*   `JUMP_FORWARD` (0x30) + `Offset (4 bytes)`: Lompat relatif ke depan.
*   `JUMP_ABSOLUTE` (0x31) + `Target (4 bytes)`: Lompat ke alamat absolut.
*   `POP_JUMP_IF_FALSE` (0x32) + `Target (4 bytes)`: Pop nilai, lompat jika Salah.
*   `POP_JUMP_IF_TRUE` (0x33) + `Target (4 bytes)`: Pop nilai, lompat jika Benar.

### Functions & Calls
*   `MAKE_FUNCTION` (0x40) + `ArgCount (4 bytes)`: Membuat fungsi (Top=CodeObject/Name?). *Catatan: Implementasi awal mungkin disederhanakan.*
*   `CALL_FUNCTION` (0x41) + `ArgCount (4 bytes)`: Memanggil fungsi. Stack: [Func, Arg1, Arg2...].
*   `RETURN_VALUE` (0x42): Mengembalikan nilai dari fungsi.

### Built-ins
*   `PRINT_EXPR` (0x50): Mencetak nilai teratas stack (untuk statement `tulis`).
*   `INPUT_EXPR` (0x51): Meminta input (untuk `tanya`).

---

## Contoh Bytecode

Kode CNZR:
```cnzr
setel x = 10
tulis x + 5
```

Bytecode (Ilustrasi):
```
000 LOAD_CONST 0 (10)
005 STORE_NAME 0 ("x")
010 LOAD_NAME 0 ("x")
015 LOAD_CONST 1 (5)
020 ADD
021 PRINT_EXPR
```
