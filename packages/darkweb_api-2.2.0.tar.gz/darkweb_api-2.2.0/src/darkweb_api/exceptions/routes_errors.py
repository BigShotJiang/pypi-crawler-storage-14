"""Standard Response Exception Responses"""

from typing import Any, Dict, Optional

from fastapi import HTTPException, status


def not_found(resource_type: str, resource_id: Any, details: Optional[Dict]):
    """Helper function to raise Not Found Exception"""
    error_details = details or {}
    error_details.update({"resource_type": resource_type, "resource_id": resource_id})
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail={"message": f"{resource_type} not found", "details": error_details},
    )


def error_request_input(
    error_details: Any, error_code: int = status.HTTP_404_NOT_FOUND
):
    """Helper function to raise Request Input Error"""
    raise HTTPException(
        status_code=error_code,
        detail={"message": error_details},
    )


def error_upstream_connection(
    error_details: Any, error_code: int = status.HTTP_502_BAD_GATEWAY
):
    """Helper function to raise Bad Gateway Exception"""
    raise HTTPException(
        status_code=error_code,
        detail={"message": error_details},
    )


def value_error(error_details: Any, error_code: int = status.HTTP_400_BAD_REQUEST):
    """Helper function to raise Upstream error"""
    raise HTTPException(
        status_code=error_code,
        detail={"message": error_details},
    )


def api_error(error_details: Any, error_code: int = status.HTTP_400_BAD_REQUEST):
    """Helper function to raise any error"""
    raise HTTPException(
        status_code=error_code,
        detail={"message": error_details},
    )
