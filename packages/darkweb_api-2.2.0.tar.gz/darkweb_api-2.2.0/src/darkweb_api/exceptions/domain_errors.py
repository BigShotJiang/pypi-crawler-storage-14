class DomainError(Exception):
    """Base class for Domain Operations"""

    status_code = 500  # Default Status Code

    def __init__(self, message: str, details: dict = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class MandatoryValuesNotFound(DomainError):
    """Raised when mandatory values are not found in request object"""

    status_code = 417


class InValidEmailFormat(DomainError):
    """Raised when invalid email format found in request object"""

    status_code = 415


class InValideDomainName(DomainError):
    """Raised when invalid Domain format found in request object"""

    status_code = 415
