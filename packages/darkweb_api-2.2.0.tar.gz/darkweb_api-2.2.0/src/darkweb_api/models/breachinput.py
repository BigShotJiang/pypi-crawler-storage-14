import os
import re
from datetime import datetime
from enum import StrEnum
from typing import TypeAlias

from dotenv import load_dotenv
from email_validator import EmailNotValidError, validate_email
from pydantic import BaseModel, Field

from ..exceptions.domain_errors import (
    InValideDomainName,
    InValidEmailFormat,
    MandatoryValuesNotFound,
)

load_dotenv()


### -------------------------------------
### Helper Internal Object Classes
### --------------------------------------
class MandatoryValues(BaseModel):
    email: str | None = Field(None)
    email_domain: str | None = Field(None)
    login_domain: str | None = Field(None)


## main class and other values
class SortBy(StrEnum):
    CRAWKEDDATE = "crawled"
    BREACGEDDATE = "breached"


class OrderBy(StrEnum):
    ASC = "asc"
    DESC = "desc"


class DataType(StrEnum):
    ANY = "Any"
    INFOSTEALER = "infostealer"
    DATABREACH = "data_breach"


class YesOrNoChoise(StrEnum):
    ANY = "Any"
    YES = "true"
    NO = "false"


HasPassword: TypeAlias = YesOrNoChoise
IsPremium: TypeAlias = YesOrNoChoise


class SubType(BaseModel):
    DATABASEDUMP: bool = Field(False)
    DATABREACHCOMBO: bool = Field(False)
    STEALERLOGS: bool = Field(False)
    STEALERCOMBO: bool = Field(False)
    COOKIES: bool = Field(False)

    def partURL(self) -> str:
        retVal = ""
        if self.DATABREACHCOMBO:
            retVal = "&sub_type=data_breach_combo_list"
        if self.STEALERLOGS:
            retVal += "&sub_type=stealer_logs"
        if self.DATABASEDUMP:
            retVal += "&sub_type=database_dump"
        if self.STEALERCOMBO:
            retVal += "&sub_type=stealers_combo_list"
        if self.COOKIES:
            retVal += "&sub_type=cookies"
        return retVal


class PasswordType(BaseModel):
    PLAINTEXT: bool = Field(False)
    UNSALTEDHASH: bool = Field(False)
    SALTEDHASH: bool = Field(False)
    ENCRYPTED: bool = Field(False)

    def partURL(self) -> str:
        retVal = ""
        if self.ENCRYPTED:
            retVal = "&password_type=encrypted"
        if self.UNSALTEDHASH:
            retVal += "&password_type=unsalted_hash"
        if self.SALTEDHASH:
            retVal += "&password_type=salted_hash"
        if self.PLAINTEXT:
            retVal += "&password_type=plaintext"
        return retVal


### -------------------------------------
### Core Breach Search Request Class
### --------------------------------------
class BreachSearchInput(BaseModel):
    """breach request object"""

    # token mandatory
    token: str = Field(None, description="Unique API Token")
    ## Main search fields
    email: str = Field(
        None, description="Search compromised data by a specific email address"
    )
    email_domain: str = Field(
        None, description="Search compromised data by email domain"
    )
    login_domain: str = Field(
        None, description="Search compromised data by login domain."
    )
    breach_name: str = Field(
        None,
        description="search whose names match in compromised data. only in data_breach",
    )

    login_url: str = Field(
        None, description="search whose login url match in compromised data"
    )

    ### Filter fields
    data_type: DataType = Field(
        default=DataType.ANY,
        description="Search compromised data by the breach sub type",
    )
    sub_type: SubType = Field(
        None,
        description="Search compromised data by the breach sub type",
    )
    breach_uuid: str = Field(
        None,
        description="Search compromised data by the breach_uuid they are associated with",
    )
    has_password: HasPassword = Field(
        HasPassword.ANY,
        description="Filter compromised data by password existence",
    )
    password_type: PasswordType = Field(
        None,
        description="Filter compromised data by password type",
    )
    is_premium: IsPremium = Field(
        IsPremium.ANY,
        description="Filter infostealer data by premium channels",
    )

    #### Date filters
    crawled_from: str | None = Field(
        None,
        description="Returns entities crawled after date",
        strict=False,
    )
    crawled_to: str | None = Field(
        None,
        description="Returns entities crawled before date",
        strict=False,
    )
    breach_from: str | None = Field(
        None,
        description="Returns entities with an official breach date earlier than this date",
        strict=False,
    )
    breach_to: str | None = Field(
        None,
        description="Returns entities with an official breach date later than this date",
        strict=False,
    )

    ##### Sort and Order fields
    sort_by: SortBy = Field(
        SortBy.CRAWKEDDATE,
        description="Defines the field used for sorting results.",
    )
    order_by: OrderBy = Field(
        OrderBy.ASC,
        description="Defines the sorting direction.",
    )

    def prepareRequestURL(self) -> tuple[str, str]:
        """
        Forms the Valid Request URL to search the WEBZ Darkweb Servers
        """
        retVal = None
        rootURL = os.getenv("BREACH_API_ENDPOINT")
        self.token = os.getenv("WEBZ_KEY")

        # Check for Valid domain values or email mandatory value present
        mvs, err = self.validateQuery()
        if err:
            return retVal, err

        retVal = f"{rootURL}/breaches?token={self.token}&format=json"

        ## mandatory fields
        if mvs.email:
            retVal += f"&email={self.email}"
        if mvs.login_domain:
            retVal += f"&login_domain={self.login_domain}"
        if mvs.email_domain:
            retVal += f"&email_domain={self.email_domain}"

        if self.data_type and self.data_type != DataType.ANY:
            retVal += f"&data_type={self.data_type}"

        ## date wise filtering
        if not self.crawled_from:
            retVal += f"&crawled_from={self.__to_epoch()}"
        if self.crawled_from:
            retVal += f"&crawled_from={self.__to_epoch(self.crawled_from)}"

        if self.crawled_to:
            retVal += f"&crawled_to={self.__to_epoch(self.crawled_to)}"

        if self.breach_from:
            retVal += f"&breach_from={self.__to_epoch(self.breach_from)}"

        if self.breach_to:
            retVal += f"&breach_to={self.__to_epoch(self.breach_to)}"

        # if Breach name or Login URL exists
        if self.breach_name:  # Only useful when the Query is of DATABREACH
            if self.data_type == DataType.DATABREACH:
                retVal += f"&breach_name={self.breach_name}"
        if self.login_url:
            retVal += f"&login_url={self.login_url}"

        if self.sub_type:
            retVal += self.sub_type.partURL()
        if self.password_type:
            retVal += self.password_type.partURL()

        # Optional Fields
        if self.has_password and self.has_password != HasPassword.ANY:
            retVal += f"&has_password={self.has_password}"

        if self.breach_uuid:
            retVal += f"&breach_uuid={self.breach_uuid}"

        if self.is_premium and self.is_premium != IsPremium.ANY:
            retVal += f"&is_premium={self.is_premium}"

        # sorting fields
        retVal += f"&sort_by={self.sort_by}&order_by={self.order_by}"

        return retVal, None

    ### -------------------------------------
    ### Private Helper functions for Breach Request Objects
    ### --------------------------------------
    def validateQuery(self) -> tuple[MandatoryValues, str]:
        mvs = MandatoryValues()

        if not (self.email or self.login_domain or self.email_domain):
            return mvs, MandatoryValuesNotFound(
                "At least one of email, email_domain, or login_domain must be provided"
            )

        if self.login_domain:
            _, err = self.__is_valid_domain(self.login_domain)
            if err:
                return None, InValideDomainName(
                    f"Invalid Login Domain '{self.login_domain}' format: {err}",
                )
            else:
                mvs.login_domain = self.login_domain
        if self.email_domain:
            _, err = self.__is_valid_domain(self.email_domain)
            if err:
                return (
                    None,
                    f"Invalid Email Domain '{self.email_domain}' format: {err}",
                )  # InValideDomainName("Invalid Email Domain Name: {self.email_domain}")
            else:
                mvs.email_domain = self.email_domain
        if self.email:
            _, err = self.__is_valid_email(self.email)
            if err:
                return (
                    None,
                    f"Invalid Email '{self.email}' format: {err}",
                )  # InValidEmailFormat("Invalid Email format: {self.email}")
            else:
                mvs.email = self.email

        return mvs, None

    ### Private Methods
    def __is_valid_email(self, email: str) -> tuple[bool, str]:
        """
        Validates Email format
        """
        try:
            self.email = self.email.strip()
            emailinfo = validate_email(self.email, check_deliverability=False)
            self.email = emailinfo.normalized
            return True, None
        except EmailNotValidError as e:
            return False, InValidEmailFormat(str(e))

    def __is_valid_domain(self, domain: str) -> tuple[bool, str]:
        """
        Validates the Domain format
        """
        regex = r"^((?!-)[A-Za-z0-9-]{1,63}(?<!-)\.)+[A-Za-z]{2,6}$"
        retVal = bool(re.match(regex, domain))
        if retVal:
            return retVal, None
        else:
            return retVal, InValideDomainName("Invalid {domain.__str__}}: {domain}")

    def __to_epoch(self, timestamp: str | None = None) -> int:
        """
        Convert a date or datetime string to epoch seconds in local time.
        If no input is provided, use the current local time.

        Accepted formats:
        - "YYYY-MM-DD"
        - "YYYY-MM-DD HH:MM"
        - "YYYY-MM-DD HH:MM:SS"
        - "DD-MM-YYYY HH:MM"
        - "DD-MM-YYYY HH:MM:SS"
        """

        if timestamp is None:
            t = int(datetime.now().timestamp())
            return t * 1000  # current local epoch

        # Try multiple accepted formats
        formats = [
            "%Y-%m-%d",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d %H:%M:%S",
            "%d-%m-%Y %H:%M",
            "%d-%m-%Y %H:%M:%S",
        ]

        for fmt in formats:
            try:
                dt = datetime.strptime(timestamp, fmt)
                # Convert to epoch assuming local time
                break
            except ValueError:
                dt = None

        return int(dt.timestamp()) * 1000
