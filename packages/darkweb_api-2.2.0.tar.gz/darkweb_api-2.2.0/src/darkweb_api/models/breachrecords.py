from pydantic import BaseModel, Field


### -------------------------------------
### Helper Internal Mandatory Object Classes
### --------------------------------------
class AccountInfo(BaseModel):
    """
    The AccountInfo object provides details about a compromised account
    """

    email: str = Field(None, description="Compromised email address")
    account_name: str = Field(None, description="Compromised account username")
    password: str = Field(None, description="Compromised password")
    password_type: str = Field(
        None,
        description="Available types: plaintext, unsalted hash, salted hash, encrypted",
    )


class PublicationSoureInfo(BaseModel):
    """
    The publication_source_info object includes metadata about the original breach file,
    including its filename, publication date, and the source where Webz detected it.
    """

    file_name: str = Field(None, description="The name of original credentials file")
    file_link: str = Field(
        None, description="The download link of original credentials file"
    )
    post_url: str = Field(
        None,
        description="The original post URL where the credentials file was detected",
    )
    site_domain: str = Field(
        None, description="The site domain where the credentials file was detected"
    )
    is_premium: bool = Field(
        None,
        description="Indicates whether the credentials file was published in a premium channel or not",
    )


### -------------------------------------
### Helper Internal Mandatory Object Classes
### --------------------------------------
class BreachInfo(BaseModel):
    """
    The breach_info object contains contextual information about the data breach in which the credentials were found, including the breach name, breach date, and compromised assets.
    This object is available for records whose type is data_breach.
    """

    uuid: str = Field(None, description="A unique identifier for the data breach")
    breach_date: str = Field(
        None,
        description="The date and time when the data breach occurred or was first publicly disclosed",
    )
    breach_name: str = Field(None, description="The name of the breach")
    compromised_assets: list = Field(
        default_factory=list,
        description="List of all affected asset types in the data breach",
    )


### sub class for Device Info
class Location(BaseModel):
    """
    Location details of the infected device
    """

    country: str = Field(None, description="Country code. e.g. CA")
    city: str = Field(None, description="City name")
    zip_code: str = Field(None, description="Zip code")


class DeviceInfo(BaseModel):
    """
    The device_info object Includes details about the infected device, typically present in infostealer-related events.
    Only available for Infostealer
    """

    infection_uuid: str = Field(
        None, description="A unique identifier for the infection"
    )
    exfiltration_date: str = Field(
        None,
        description="The date and time when the stealer log data was collected and exfiltrated from the infected device",
    )
    log_file_name: str = Field(None, description="Stealer log file name")
    hwid: str = Field(None, description="Hardware ID of infected device")
    ip_address: str = Field(None, description="IP address of infected device")
    location: Location = Field(
        None, description="Location details of the infected device"
    )
    computer_username: str = Field(None, description="Device username")
    os: str = Field(None, description="Operating system")
    antivirus_software: list = Field(
        default_factory=list, description="Installed AVs on the infected device"
    )
    malware_family: str = Field(None, description="Malware family name. e.g. Redline")
    malware_path: str = Field(
        None, description="Path to malicious file on the infected device"
    )


### -------------------------------------
### Root Records Object
### --------------------------------------


class Record(BaseModel):
    """
    The Record provides basic information about the record and the user credentials associated with it
    """

    uuid: str = Field(None, description="A unique identifier for the record")
    craweld_date: str = Field(
        None,
        description="The date and time when the original record was fetched by WEBZ",
    )
    type: str = Field(None, description="Available types: Infostealer, data_breach")
    sub_type: str = Field(
        None,
        description="Available sub type: database_dump, data_breach_combolist, stealers_combolist, stealer_logs, cookies",
    )
    login_url: str = Field(
        None, description="The URL linked to the compromised credentials"
    )
    login_domain: str = Field(
        None,
        description="The domain or IP extracted from the login_url, or the organization’s domain affected by the data breach",
    )
    account_info: AccountInfo = Field(
        None, description="Account Information of the Record"
    )
    device_info: DeviceInfo = Field(
        None, description="Device Information. Only  Infostealer seearch"
    )
    breach_info: BreachInfo = Field(
        None, description="Breach Informatoin. Only Data breach Search"
    )
    publication_source_info: PublicationSoureInfo = Field(
        None, description="Publication Information"
    )


class RecordOutPut(BaseModel):
    """
    The Root Object is the top-level structure of the **Breaches API **response.
    It contains metadata about the query request and an array of matched records entries,
    each representing a distinct compromised user credentials with its associated data.
    """

    records: list[Record] = Field(
        default_factory=list,
        description="A list of compromised credentials, each representing an individual record.",
    )
    toatlResults: int = Field(
        default=0,
        description="The total number of compromised records matching your query.",
    )
    moreResultsAvailable: int = Field(
        default=0,
        description="The number of remaining compromised records matching your query.",
    )
    next: str = Field(
        None, description="A URL to get the next batch of results matching your query."
    )
    requestLeft: int = Field(
        default=0,
        description="How many more requests are available in your current subscription plan",
    )
    totalResultsVerified: bool = Field(None, description="")
