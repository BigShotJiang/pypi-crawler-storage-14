# pylodentitymanager
Legacy Entity Manager

[![pypi](https://img.shields.io/pypi/pyversions/pylodentitymanager)](https://pypi.org/project/pylodentitymanager/)
[![Github Actions Build](https://github.com/WolfgangFahl/pylodentitymanager/actions/workflows/build.yml/badge.svg)](https://github.com/WolfgangFahl/pylodentitymanager/actions/workflows/build.yml)
[![PyPI Status](https://img.shields.io/pypi/v/pylodentitymanager.svg)](https://pypi.python.org/pypi/pylodentitymanager/)
[![GitHub issues](https://img.shields.io/github/issues/WolfgangFahl/pylodentitymanager.svg)](https://github.com/WolfgangFahl/pylodentitymanager/issues)
[![GitHub closed issues](https://img.shields.io/github/issues-closed/WolfgangFahl/pylodentitymanager.svg)](https://github.com/WolfgangFahl/pylodentitymanager/issues/?q=is%3Aissue+is%3Aclosed)
[![API Docs](https://img.shields.io/badge/API-Documentation-blue)](https://WolfgangFahl.github.io/pylodentitymanager/)
[![License](https://img.shields.io/github/license/WolfgangFahl/pylodentitymanager.svg)](https://www.apache.org/licenses/LICENSE-2.0)
