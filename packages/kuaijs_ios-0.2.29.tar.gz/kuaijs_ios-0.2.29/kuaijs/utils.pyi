"""工具函数"""

# 时间格式化（如 "yyyy-MM-dd HH:mm:ss"）
def timeFormat(format: str) -> str:
    """时间格式化（如 "yyyy-MM-dd HH:mm:ss"）"""
    ...

# 生成随机数（闭区间）
def random(min: int, max: int) -> int:
    """生成随机数（闭区间）"""
    ...

# 将应用切到前台
def takeMeToFront() -> bool:
    """将应用切到前台"""
    ...

# 判断应用是否在前台
def isAppForeground() -> bool:
    """判断应用是否在前台"""
    ...
