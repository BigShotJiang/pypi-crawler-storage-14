"""
In this file we will exercise the with statement, especially some awkward cases.

What happens when an exception is raised inside the `__enter__` or `__exit__` methods?

"""


class DummyContextManager:
    def __enter__(self):
        print("Entering the context")
        # Uncomment the next line to simulate an exception in __enter__
        # raise ValueError("Exception in __enter__")
        return "Resource"

    def __exit__(self, exc_type, exc_value, traceback):
        print("Exiting the context")
        if exc_type:
            print(f"An exception occurred: {exc_value}")
            return True  # Suppress the exception, or exception was handled here
        # Uncomment the next line to simulate an exception in __exit__
        # raise RuntimeError("Exception in __exit__")
        return False  # Propagate exceptions


def test_dummy_context_manager():
    try:
        with DummyContextManager() as resource:
            print(f"Using {resource}")
            # Uncomment the next line to simulate an exception inside the with block
            # raise KeyError("Exception inside with block")
    except Exception as exc:
        print(f"Caught an exception: {exc}")


if __name__ == "__main__":
    test_dummy_context_manager()
