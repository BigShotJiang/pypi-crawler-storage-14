"""Quick test to understand version.py behavior"""


def test_with_block_scope():
    """Test that variables assigned in with blocks persist."""

    from pathlib import Path
    from egse.system import chdir

    # Test 1: Variable should persist after with block

    with chdir(Path.cwd()):
        test_var = "hello"

    print(f"test_var after with block: {test_var}")  # Should print "hello"

    # Test 2: What happens in get_version_installed?

    from egse.version import get_version_installed

    result = get_version_installed("nonexistent-package-xyz-123")
    print(f"get_version_installed result: {repr(result)}")

    # Test 3: What happens in get_version_from_git?

    from egse.version import get_version_from_git
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        result = get_version_from_git(tmpdir)
        print(f"get_version_from_git result: {repr(result)}")


if __name__ == "__main__":
    test_with_block_scope()
