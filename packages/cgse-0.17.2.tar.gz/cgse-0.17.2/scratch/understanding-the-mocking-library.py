from unittest.mock import Mock

mock = Mock()
mock


def do_something(json_lib):
    data = {"key": "value"}
    json_str = json_lib.dumps(data)
    print(f"Serialized JSON: {json_str}")
    parsed_data = json_lib.loads(json_str)
    print(f"Parsed Data: {parsed_data}")


# Pass mock as an argument to do_something()
do_something(mock)


# Patch the json library
json = mock


# Access attributes and call methods on the mocked json library
json.some_attribute


# Call a method on the mocked json library
json.do_something()


json = Mock()
json.dumps()

from unittest.mock import Mock

json = Mock()
json.loads('{"key": "value"}')

json.loads.assert_called()
json.loads.assert_called_once()
json.loads.assert_called_with('{"key": "value"}')
json.loads.assert_called_once_with('{"key": "value"}')

json.loads()
json.loads.assert_called_once()


json = Mock()

json.loads(s='{"key": "value"}')


json.loads.assert_called_with('{"key": "value"}')


json.loads.assert_called_with(s='{"key": "value"}')


from unittest.mock import Mock

json = Mock()
json.loads('{"key": "value"}')


# Number of times you called loads():
json.loads.call_count


# The last loads() call:
json.loads.call_args


# List of loads() calls:
json.loads.call_args_list


# List of calls to json's methods (recursively):
json.method_calls

json.loads.assert_called_once()
json.loads.assert_called_once_with('{"key": "value"}')
json.loads.assert_called_with(**{"key": "value"})  # This will fail
