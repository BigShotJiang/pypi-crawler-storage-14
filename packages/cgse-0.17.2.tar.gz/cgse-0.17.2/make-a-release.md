
(also check the docs: [Building and publishing packages](https://ivs-kuleuven.github.io/cgse/dev_guide/uv/#building-and-publishing-all-packages))

## Making a release

- run `uvx ruff format`
- commit all changes with a proper message
- add all notable changes to the CHANGELOG file
  - fix the links in the headers if needed
  - add links to the different pull requests
  - commit the CHANGELOG file
- bump the version number: `uv run bump.py [patch|minor|major]`
- commit all `pyproject.toml` files after the version bump
- push the changes to the dedicated branch (I use PyCharm for this)
- create (and merge) a pull request, use the CHANGELOG as description
- remove the old distributions: `rm -r dist`
- build the packages: `uv build --all-packages`
- publish the packages to PyPI: `uv publish --token $UV_PUBLISH_TOKEN`


## Tag the new release

- create a tag for the commit of the bump: `git tag <version number> <commit hash>`, e.g. `git tag v0.16.0 559bbfc`
- push the tag to upstream: `git push upstream <tag name>`, e.g. `git push upstream v0.16.0`


## Building and publishing the documentation

- see [Building the documentation](https://ivs-kuleuven.github.io/cgse/dev_guide/docs/#building-the-documentation)
