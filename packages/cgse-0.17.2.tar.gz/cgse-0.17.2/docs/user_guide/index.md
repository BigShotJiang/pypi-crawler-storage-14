# User Guide

Welcome to the CGSE user guide! An in-depth reference on how to use the CGSE.
