
# Libraries

The libraries are those packages that make up the CGSE framework.

The libraries are located under the `libs` folder, and we currently find the following packages there:

- `cgse-common`
- `cgse-core`
- `cgse-coordinates`
- `cgse-gui`
