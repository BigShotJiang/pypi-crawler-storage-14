---
title: "egse.bits"
---

!!! info "cgse-common"
    This code is part of the `cgse-common` package.


::: egse.bits
