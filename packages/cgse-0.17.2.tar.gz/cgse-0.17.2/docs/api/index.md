# API

This is a API-level reference to the CGSE API. Click the links to your left (or in the 
:octicons-three-bars-16: menu) to open a reference for each module.

If you are new to the CGSE, you may want to read the [Gettings Started](./../getting_started.md) 
first.
