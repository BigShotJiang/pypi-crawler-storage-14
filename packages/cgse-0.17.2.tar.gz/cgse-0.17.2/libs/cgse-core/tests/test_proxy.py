import pytest

from egse.dummy import DummyProxy
from egse.process import is_process_running


def test_proxy_to_not_running_control_server():
    # This tests a Proxy for which the control server is not running.
    # We will test with the Dummy CS, the Dummy CS is started with" `py -m egse.dummy start-cs`.

    if is_process_running(["egse.dummy", "start-cs"]):
        pytest.xfail("dummy cs is running, this test assumes the dummy cs is not running.")

    with pytest.raises(ConnectionError):
        with DummyProxy() as dummy_proxy:
            assert dummy_proxy.get_endpoint()
