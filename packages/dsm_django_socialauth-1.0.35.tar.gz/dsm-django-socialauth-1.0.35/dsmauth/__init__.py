__title__ = 'Django DigitalStoreMesh Authentication'
__version__ = '1.0.35'
__author__ = 'DigitalStoreMesh Co.,Ltd'
__license__ = 'MIT'

VERSION = __version__

import dsmauth.backend