Contributor Covenant Code of Conduct
=========================================

This project follows Ladybug Tools contributor covenant code of conduct. See our [contributor covenant code of conduct](https://github.com/ladybug-tools/contributing/blob/master/CODE-OF-CONDUCT.md).
