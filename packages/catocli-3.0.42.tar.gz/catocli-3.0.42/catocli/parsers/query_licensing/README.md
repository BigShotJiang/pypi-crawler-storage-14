
## CATO-CLI - query.licensing:
[Click here](https://api.catonetworks.com/documentation/#query-query.licensing) for documentation on this operation.

### Usage for query.licensing:

```bash
catocli query licensing -h

catocli query licensing <json>

catocli query licensing --json-file query.licensing.json

#### Operation Arguments for query.licensing ####

`accountId` [ID] - (required) N/A    
