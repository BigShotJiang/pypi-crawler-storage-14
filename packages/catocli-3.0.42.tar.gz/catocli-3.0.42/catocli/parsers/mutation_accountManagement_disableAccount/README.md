
## CATO-CLI - mutation.accountManagement.disableAccount:
[Click here](https://api.catonetworks.com/documentation/#mutation-mutation.accountManagement.disableAccount) for documentation on this operation.

### Usage for mutation.accountManagement.disableAccount:

```bash
catocli mutation accountManagement disableAccount -h

catocli mutation accountManagement disableAccount <json>

catocli mutation accountManagement disableAccount --json-file mutation.accountManagement.disableAccount.json

#### Operation Arguments for mutation.accountManagement.disableAccount ####

`accountId` [ID] - (required) N/A    
