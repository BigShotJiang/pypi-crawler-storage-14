__version__ = "3.0.42"
__cato_host__ = "https://api.catonetworks.com/api/v1/graphql2"