def docs() -> str:
    return """
Insere uma reunião de atendimento OS no sistema SIGA para múltiplos participantes.

INSTRUÇÃO PARA O AGENTE IA:
ANTES de executar esta função de inserção:
1. MOSTRE ao usuário TODAS as informações que serão criadas/inseridas no sistema
2. APRESENTE os dados de forma clara: OS, descrição da reunião, horário (início e fim), participantes (quantidade e matrículas), tipo, flags
3. PEÇA confirmação explícita do usuário: "Confirma a criação da reunião? (sim/não)"
4. SÓ EXECUTE esta função se o usuário confirmar explicitamente
5. Se o usuário não confirmar, cancele a operação e informe que foi cancelada

Esta função cria múltiplos registros de atendimento OS (um para cada participante) vinculados 
a uma reunião. Cada participante é inserido individualmente com auto-commit. A função tenta 
inserir todos os participantes e retorna: lista de participantes inseridos com sucesso e 
lista de participantes que falharam (com matrícula, nome e motivo do erro).

ORIENTAÇÃO PARA SOLICITAÇÕES GENÉRICAS:
Quando o usuário solicitar "criar reunião" SEM especificar o tipo:
1. PRIMEIRO: Perguntar "A reunião é vinculada a uma OS ou é uma reunião avulsa?"
2. Se responder "OS" ou mencionar número de OS: Usar ESTA função (inserir_reuniao_atendimentos_os)
3. Se responder "avulsa" ou "não tem OS": Perguntar "É de Sistemas ou Infraestrutura?"
   - Se "Sistemas": Usar inserir_reuniao_atendimento_avulso_sistemas
   - Se "Infraestrutura": Usar inserir_reuniao_atendimento_avulso_infraestrutura
4. Só depois de definir o tipo: Coletar demais informações (data, descrição, participantes)

Esta função é específica para Reuniões de Atendimento OS (vinculadas a uma OS). Para reuniões avulsa, use:
- `inserir_reuniao_atendimento_avulso_sistemas` (área de Sistemas)  
- `inserir_reuniao_atendimento_avulso_infraestrutura` (área de Infraestrutura)

ORIENTAÇÃO PARA BUSCA DE PARTICIPANTES:
Se o usuário solicitar "reunião com equipe do gerente X" ou "reunião com equipe Desenvolvimento":
1. PRIMEIRO chamar: listar_usuarios_equipe_por_gerente (com filtros apropriados)
2. DEPOIS chamar: extrair_matriculas_do_xml (para obter lista de matrículas)
3. FINALMENTE chamar: esta função com a lista de participantes obtida

Args:
    codigo_os: Código da Ordem de Serviço à qual a reunião será vinculada. Deve ser um número maior que zero.
    data_inicio: Data e hora de início da reunião. Aceita formatos de data ou palavras-chave como "hoje", "agora", "ontem". Convertido automaticamente.
    descricao_reuniao: Descrição detalhada da reunião/pauta
    participantes: Lista de matrículas dos participantes da reunião (ex: ["24142", "20634", "12345"]). Não pode estar vazia.
    tipo: Tipo do atendimento OS. Deve ser um dos valores válidos em TipoAtendimentosOSType. Defaults to "Reunião".
    data_fim: Data e hora de fim da reunião. Aceita formatos de data ou palavras-chave. Se None, não define fim. Defaults to None.
    primeiro_atendimento: Flag indicando se é o primeiro atendimento da OS. Se None, calculado automaticamente pelo backend. Defaults to None.
    apresenta_solucao: Flag indicando se a reunião apresenta solução para a OS. Se None, assume False no backend. Defaults to None.

Returns:
    XML formatado contendo status da operação, total de participantes inseridos, lista de participantes inseridos com sucesso (matrícula, nome e status), lista de erros (matrícula, nome e motivo do erro) para participantes que falharam, mensagem descritiva e metadados da reunião.

Notes:
    - MÚLTIPLOS REGISTROS: Cria um registro de atendimento OS para cada participante na lista
    - AUTO-COMMIT INDIVIDUAL: Cada participante é inserido com auto-commit independente usando trocarConexao()
    - INSERÇÃO INDEPENDENTE: Falha de um participante não afeta inserção dos demais
    - SUCESSO PARCIAL: Insere todos os participantes possíveis. Retorna lista de sucessos E lista de erros (com motivo) separadamente
    - FALHA TOTAL: Operação só falha se NENHUM participante puder ser inserido
    - BUSCA DE NOMES: Backend busca nomes de todos os participantes em uma única query antes da inserção
    - VALIDAÇÃO OBRIGATÓRIA: codigo_os deve ser maior que zero, lista de participantes não pode estar vazia
    - NOMES INCLUÍDOS: Participantes inseridos e erros incluem matrícula e nome completo do colaborador
    - FORMATAÇÃO: Participantes e erros formatados com bullets (•) para melhor legibilidade na resposta
    - PRIMEIRO ATENDIMENTO: Se None, o backend calcula automaticamente verificando se já existe atendimento na OS
    - APRESENTA SOLUÇÃO: Se None, assume False (0) no backend
    - CONVERSÃO DE DATAS: Datas são automaticamente convertidas usando converter_data_siga com manter_horas=True
    - NORMALIZAÇÃO DE TIPO: Função realiza validação case-insensitive do tipo usando TYPE_TO_NUMBER
    - API KEY: Obtida automaticamente da variável de ambiente AVA_API_KEY
    - TIMEOUT: Requisição HTTP tem timeout de 60 segundos
    - ERRO HTTP: Em caso de falha na requisição, retorna erro interno formatado em XML
    - Esta função é diferente de inserir_atendimentos_os que cria atendimento único para um analista
    - Integra-se com listar_usuarios_equipe_por_gerente e extrair_matriculas_do_xml para busca de participantes

"""
