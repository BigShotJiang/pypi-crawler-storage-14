"""
Basic Network Visualization Example

This example demonstrates how to create a simple network visualization
using the network_visualization utilities.
"""

import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.load_data import load_all_locations, load_all_connections
from utils.graph_builder import build_network_graph, analyze_connectivity
from utils.report_generator import generate_report, save_report


def main():
    # Set your model path here
    MODEL_PATH = r"C:\Users\admin1\Desktop\ricardo's-projects\chile_model"
    
    print("Loading network data...")
    locations = load_all_locations(MODEL_PATH)
    connections = load_all_connections(MODEL_PATH)
    
    print(f"Loaded {len(locations)} locations")
    print(f"Loaded {len(connections)} connections")
    
    # Build graph
    print("\nBuilding network graph...")
    graph = build_network_graph(locations, connections)
    
    # Analyze connectivity
    print("Analyzing connectivity...")
    analysis = analyze_connectivity(graph, locations)
    
    # Print summary
    print("\n" + "=" * 60)
    print("NETWORK SUMMARY")
    print("=" * 60)
    print(f"Total nodes: {analysis['total_nodes']}")
    print(f"Total edges: {analysis['total_edges']}")
    print(f"Connected components: {analysis['num_components']}")
    print(f"Main component size: {analysis['main_component_size']}")
    print(f"Isolated nodes: {analysis['num_isolated']}")
    print(f"Isolated demand substations: {len(analysis['demand_isolated'])}")
    
    if analysis['demand_isolated']:
        print("\nIsolated demand substations:")
        for node in sorted(analysis['demand_isolated']):
            print(f"  - {node}")
    
    # Generate report
    print("\nGenerating report...")
    report = generate_report(locations, connections, analysis, 'text')
    
    # Save report
    report_path = save_report(report, 'example_report.txt')
    print(f"Report saved to: {report_path}")
    
    print("\nDone!")


if __name__ == '__main__':
    main()
