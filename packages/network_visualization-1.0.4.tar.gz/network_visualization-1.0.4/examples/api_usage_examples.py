"""
Simple examples using the network_visualization API.

These examples show how to use the package after installation.
"""

# Example 1: Simple visualization
from network_visualization import plot_network

# Just provide your model path - that's it!
plot_network("path/to/your/calliope/model")


# Example 2: Custom output location
from network_visualization import plot_network

plot_network(
    "path/to/your/model",
    output_file="my_custom_network.html",
    auto_open=False,  # Don't open browser automatically
    title="My Energy Network"
)


# Example 3: Analyze network connectivity
from network_visualization import analyze_network

analysis = analyze_network("path/to/your/model")
print(f"Network has {analysis['num_components']} components")
print(f"Isolated nodes: {analysis['isolated_nodes']}")


# Example 4: Find isolated nodes
from network_visualization import find_isolated_nodes

isolated = find_isolated_nodes("path/to/your/model")
print(f"Nodes with demand that are isolated:")
for node in isolated['isolated_with_demand']:
    print(f"  - {node}")


# Example 5: Get connection suggestions
from network_visualization import suggest_connections

suggestions = suggest_connections(
    "path/to/your/model",
    max_distance_km=100,  # Only suggest connections under 100 km
    top_n=3  # Top 3 suggestions per isolated node
)

print("\nSuggested connections:")
for s in suggestions[:10]:  # Show first 10
    print(f"{s['from']} → {s['to']}: {s['distance_km']:.1f} km")


# Example 6: Quick visualization and analysis in one call
from network_visualization import quick_viz

viz_path, analysis = quick_viz("path/to/your/model")
print(f"Visualization saved to: {viz_path}")
print(f"Found {len(analysis['isolated_nodes'])} isolated nodes")


# Example 7: Analyze and save report
from network_visualization import analyze_network

analysis = analyze_network(
    "path/to/your/model",
    save_report=True,
    output_dir="my_reports"
)


# Example 8: Integration with other code
from network_visualization import plot_network, analyze_network

def check_my_model(model_path):
    """Check model and create visualization."""
    # Analyze first
    analysis = analyze_network(model_path, save_report=False)
    
    # Check for issues
    if analysis['isolated_with_demand']:
        print(f"⚠️  Warning: {len(analysis['isolated_with_demand'])} nodes with demand are isolated!")
        print("These nodes:", analysis['isolated_with_demand'])
    else:
        print("✓ All demand nodes are connected!")
    
    # Create visualization
    viz_path = plot_network(
        model_path,
        output_file=f"network_check.html",
        title=f"Network Check - {len(analysis['isolated_nodes'])} isolated nodes"
    )
    
    return analysis, viz_path

# Use it
results, viz = check_my_model("path/to/your/model")


# Example 9: Batch processing multiple models
from network_visualization import analyze_network
import os

def analyze_all_models(models_dir):
    """Analyze all models in a directory."""
    results = {}
    
    for model_name in os.listdir(models_dir):
        model_path = os.path.join(models_dir, model_name)
        if os.path.isdir(model_path):
            try:
                analysis = analyze_network(model_path, save_report=False)
                results[model_name] = {
                    'components': analysis['num_components'],
                    'isolated': len(analysis['isolated_nodes']),
                    'isolated_demand': len(analysis['isolated_with_demand'])
                }
            except Exception as e:
                print(f"Error analyzing {model_name}: {e}")
    
    return results

# Compare models
# results = analyze_all_models("path/to/models")
# for name, stats in results.items():
#     print(f"{name}: {stats['components']} components, {stats['isolated']} isolated")


# Example 10: Using with pandas for analysis
from network_visualization import suggest_connections
import pandas as pd

suggestions = suggest_connections("path/to/your/model", max_distance_km=150)

# Convert to DataFrame for easier analysis
df = pd.DataFrame(suggestions)

# Find all suggestions for a specific node
specific_node = "SUB_ARICA"
node_suggestions = df[df['from'] == specific_node]
print(f"\nSuggestions for {specific_node}:")
print(node_suggestions[['to', 'distance_km']].head())

# Find shortest connections overall
shortest = df.nsmallest(5, 'distance_km')
print("\nShortest possible connections:")
print(shortest[['from', 'to', 'distance_km']])

# Group by isolated node type
by_type = df.groupby('isolated_node_type')['distance_km'].agg(['count', 'mean', 'min'])
print("\nStatistics by node type:")
print(by_type)
