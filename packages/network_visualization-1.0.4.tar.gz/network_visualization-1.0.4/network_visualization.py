"""
High-level API for network visualization.

Provides simple, convenient functions to visualize and analyze
your Calliope energy model network with minimal code.

Example usage:
    from network_visualization import plot_network, analyze_network
    
    # Simple visualization
    plot_network("path/to/model")
    
    # Get analysis report
    report = analyze_network("path/to/model")
    print(report)
"""

import os
from typing import Dict, List, Optional, Tuple
import plotly.graph_objs as go
import plotly.offline as pyo

from utils.load_data import load_all_locations, load_all_connections
from utils.graph_builder import build_network_graph, analyze_connectivity
from utils.report_generator import generate_report, save_report
from utils.geo_utils import find_nearest_nodes


__version__ = '1.0.0'
__all__ = [
    'plot_network',
    'analyze_network', 
    'find_isolated_nodes',
    'suggest_connections',
    'quick_viz',
]


# Visual styling configuration
COLORS = {
    'power': 'rgb(255, 107, 107)',
    'substation': 'rgb(78, 205, 196)',
    'substation_with_demand': 'rgb(255, 183, 77)',
    'nodo': 'rgb(149, 225, 211)'
}

SIZES = {
    'power': 8,
    'substation': 5,
    'substation_with_demand': 10,
    'nodo': 6
}

LEGEND_NAMES = {
    'power': 'Power Plants',
    'substation': 'Substations',
    'substation_with_demand': 'Substations with Demand',
    'nodo': 'Transmission Nodes'
}


def plot_network(
    model_path: str,
    output_file: str = 'network_visualization.html',
    auto_open: bool = True,
    title: str = 'Energy Network Visualization',
    scenario: Optional[str] = None,
    override_dict: Optional[Dict] = None
) -> str:
    """
    Create an interactive network visualization from your Calliope model.
    
    This is the simplest way to visualize your network - just provide the model path!
    
    Args:
        model_path: Path to your Calliope model directory
        output_file: HTML filename for the visualization (default: 'network_visualization.html')
        auto_open: Whether to open the visualization in browser automatically (default: True)
        title: Title for the visualization (default: 'Energy Network Visualization')
        scenario: Calliope scenario name to apply (default: None)
        override_dict: Dictionary of overrides to apply to the model (default: None)
        
    Returns:
        Path to the generated HTML file
        
    Example:
        >>> plot_network("path/to/my/model")
        'network_visualization.html'
        
        >>> plot_network("path/to/my/model", scenario="high_demand")
        'network_visualization.html'
        
        >>> plot_network("path/to/my/model", override_dict={'locations.region1.techs.ccgt': None})
        'network_visualization.html'
    """
    print(f"Loading model from: {model_path}")
    if scenario:
        print(f"  Applying scenario: {scenario}")
    if override_dict:
        print(f"  Applying {len(override_dict)} overrides")
    
    # Load data
    locations = load_all_locations(model_path, scenario=scenario, override_dict=override_dict)
    connections = load_all_connections(model_path, scenario=scenario, override_dict=override_dict)
    
    print(f"Loaded {len(locations)} locations and {len(connections)} connections")
    
    # Create visualization
    fig = _create_plotly_figure(locations, connections, title)
    
    # Save and optionally open
    output_path = os.path.abspath(output_file)
    pyo.plot(fig, filename=output_path, auto_open=auto_open)
    
    print(f"✓ Visualization saved to: {output_path}")
    return output_path


def analyze_network(
    model_path: str,
    save_report: bool = False,
    scenario: Optional[str] = None,
    override_dict: Optional[Dict] = None,
    output_dir: str = 'outputs/reports'
) -> Dict:
    """
    Analyze network connectivity and identify issues.
    
    Returns detailed information about:
    - Number of components (connected subgraphs)
    - Isolated nodes (not connected to anything)
    - Nodes with demand that are isolated
    - Network statistics
    
    Args:
        model_path: Path to your Calliope model directory
        save_report: Whether to save a text report to file (default: False)
        output_dir: Directory to save report if save_report=True
        
    Returns:
        Dictionary containing analysis results
        
    Example:
        >>> analysis = analyze_network("path/to/model")
        >>> print(f"Found {analysis['num_components']} network components")
        >>> print(f"Isolated nodes: {analysis['isolated_nodes']}")
    """
    print(f"Analyzing network from: {model_path}")
    
    # Load data
    locations = load_all_locations(model_path)
    connections = load_all_connections(model_path)
    
    # Build graph and analyze
    G = build_network_graph(locations, connections)
    analysis = analyze_connectivity(G, locations)
    
    # Generate report
    report_text = generate_report(locations, connections, analysis)
    
    if save_report:
        os.makedirs(output_dir, exist_ok=True)
        report_path = save_report(report_text, output_dir)
        print(f"✓ Report saved to: {report_path}")
    
    print(f"\n{'='*60}")
    print(report_text)
    print(f"{'='*60}\n")
    
    return analysis


def find_isolated_nodes(
    model_path: str,
    scenario: str = None,
    override_dict: Dict = None
) -> Dict[str, List[str]]:
    """
    Find all isolated nodes in the network.
    
    Args:
        model_path: Path to your Calliope model directory
        scenario: Optional Calliope scenario name to apply
        override_dict: Optional dictionary of overrides to apply
        
    Returns:
        Dictionary with 'all_isolated' and 'isolated_with_demand' lists
        
    Example:
        >>> isolated = find_isolated_nodes("path/to/model")
        >>> print(f"Isolated nodes with demand: {isolated['isolated_with_demand']}")
    """
    locations = load_all_locations(model_path, scenario=scenario, override_dict=override_dict)
    connections = load_all_connections(model_path, scenario=scenario, override_dict=override_dict)
    
    G = build_network_graph(locations, connections)
    analysis = analyze_connectivity(G, locations)
    
    return {
        'all_isolated': analysis['isolated_nodes'],
        'isolated_with_demand': analysis['isolated_with_demand']
    }


def suggest_connections(
    model_path: str,
    max_distance_km: float = 50.0,
    top_n: int = 5,
    scenario: str = None,
    override_dict: Dict = None
) -> List[Dict]:
    """
    Suggest connections to fix isolated nodes with demand.
    
    Args:
        model_path: Path to your Calliope model directory
        max_distance_km: Maximum distance for suggested connections (default: 50 km)
        top_n: Number of suggestions per isolated node (default: 5)
        scenario: Optional Calliope scenario name to apply
        override_dict: Optional dictionary of overrides to apply
        
    Returns:
        List of suggested connections with distances
        
    Example:
        >>> suggestions = suggest_connections("path/to/model", max_distance_km=100)
        >>> for s in suggestions[:3]:
        ...     print(f"{s['from']} -> {s['to']}: {s['distance']:.1f} km")
    """
    locations = load_all_locations(model_path, scenario=scenario, override_dict=override_dict)
    connections = load_all_connections(model_path, scenario=scenario, override_dict=override_dict)
    
    G = build_network_graph(locations, connections)
    analysis = analyze_connectivity(G, locations)
    
    suggestions = []
    
    for isolated_node in analysis['isolated_with_demand']:
        if isolated_node not in locations:
            continue
            
        # Find nearest connected nodes
        nearest = find_nearest_nodes(
            isolated_node,
            locations,
            analysis['connected_nodes'],
            n=top_n,
            max_distance_km=max_distance_km
        )
        
        for candidate, distance in nearest:
            suggestions.append({
                'from': isolated_node,
                'to': candidate,
                'distance_km': distance,
                'isolated_node_type': locations[isolated_node]['type'],
                'target_node_type': locations[candidate]['type']
            })
    
    # Sort by distance
    suggestions.sort(key=lambda x: x['distance_km'])
    
    print(f"\nFound {len(suggestions)} possible connections")
    print(f"Isolated nodes with demand: {len(analysis['isolated_with_demand'])}")
    
    return suggestions


def quick_viz(
    model_path: str,
    show_isolated: bool = True,
    show_analysis: bool = True,
    scenario: str = None,
    override_dict: Dict = None
) -> Tuple[str, Dict]:
    """
    Quick visualization and analysis in one call.
    
    Perfect for rapid exploration of your network!
    
    Args:
        model_path: Path to your Calliope model directory
        show_isolated: Highlight isolated nodes in visualization (default: True)
        show_analysis: Print analysis report (default: True)
        scenario: Optional Calliope scenario name to apply
        override_dict: Optional dictionary of overrides to apply
        
    Returns:
        Tuple of (visualization_path, analysis_dict)
        
    Example:
        >>> viz_path, analysis = quick_viz("path/to/model")
        >>> print(f"Network has {analysis['num_components']} components")
    """
    print("🚀 Quick Network Analysis & Visualization\n")
    
    # Load data once
    locations = load_all_locations(model_path, scenario=scenario, override_dict=override_dict)
    connections = load_all_connections(model_path, scenario=scenario, override_dict=override_dict)
    
    # Analyze
    G = build_network_graph(locations, connections)
    analysis = analyze_connectivity(G, locations)
    
    if show_analysis:
        report_text = generate_report(locations, connections, analysis)
        print(f"\n{'='*60}")
        print(report_text)
        print(f"{'='*60}\n")
    
    # Create visualization with isolated nodes highlighted
    title = 'Energy Network - Quick Analysis'
    if show_isolated and analysis['isolated_nodes']:
        title += f" ({len(analysis['isolated_nodes'])} isolated nodes)"
    
    fig = _create_plotly_figure(
        locations, 
        connections, 
        title,
        highlight_isolated=analysis['isolated_nodes'] if show_isolated else None
    )
    
    output_path = 'quick_viz.html'
    pyo.plot(fig, filename=output_path, auto_open=True)
    
    print(f"✓ Visualization saved to: {output_path}")
    
    return output_path, analysis


def _create_plotly_figure(
    locations: Dict,
    connections: List[Dict],
    title: str,
    highlight_isolated: Optional[List[str]] = None
) -> go.Figure:
    """Internal function to create Plotly figure."""
    
    data = []
    
    # Draw power_links
    power_link_lats, power_link_lons = [], []
    for conn in connections:
        if conn['type'] == 'power_link':
            if conn['from'] in locations and conn['to'] in locations:
                from_loc = locations[conn['from']]
                to_loc = locations[conn['to']]
                power_link_lats.extend([from_loc['lat'], to_loc['lat'], None])
                power_link_lons.extend([from_loc['lon'], to_loc['lon'], None])
    
    if power_link_lats:
        data.append(go.Scattergeo(
            lon=power_link_lons,
            lat=power_link_lats,
            mode='lines',
            line=dict(width=1.5, color='rgba(255, 107, 107, 0.3)'),
            name='Power Links',
            hoverinfo='skip',
            showlegend=True
        ))
    
    # Draw transmission_links
    transmission_link_lats, transmission_link_lons = [], []
    for conn in connections:
        if conn['type'] == 'transmission_link':
            if conn['from'] in locations and conn['to'] in locations:
                from_loc = locations[conn['from']]
                to_loc = locations[conn['to']]
                transmission_link_lats.extend([from_loc['lat'], to_loc['lat'], None])
                transmission_link_lons.extend([from_loc['lon'], to_loc['lon'], None])
    
    if transmission_link_lats:
        data.append(go.Scattergeo(
            lon=transmission_link_lons,
            lat=transmission_link_lats,
            mode='lines',
            line=dict(width=0.8, color='rgba(69, 183, 209, 0.2)'),
            name='Transmission Links',
            hoverinfo='skip',
            showlegend=True
        ))
    
    # Group nodes by type
    nodes_by_type = {}
    for name, loc in locations.items():
        node_type = loc['type']
        if node_type not in nodes_by_type:
            nodes_by_type[node_type] = []
        nodes_by_type[node_type].append((name, loc))
    
    # Draw nodes
    for node_type, nodes in nodes_by_type.items():
        lats = [loc['lat'] for _, loc in nodes]
        lons = [loc['lon'] for _, loc in nodes]
        names = [name for name, _ in nodes]
        techs = [', '.join(loc['techs']) if loc['techs'] else 'None' for _, loc in nodes]
        
        hover_texts = [
            f"<b>{name}</b><br>Type: {node_type}<br>Techs: {tech}"
            for name, tech in zip(names, techs)
        ]
        
        data.append(go.Scattergeo(
            lon=lons,
            lat=lats,
            mode='markers',
            marker=dict(
                size=SIZES.get(node_type, 6),
                color=COLORS.get(node_type, 'gray'),
                line=dict(width=0.5, color='white')
            ),
            text=names,
            hovertext=hover_texts,
            hoverinfo='text',
            name=LEGEND_NAMES.get(node_type, node_type),
            showlegend=True
        ))
    
    # Highlight isolated nodes if requested
    if highlight_isolated:
        isolated_lats = []
        isolated_lons = []
        isolated_names = []
        
        for node_name in highlight_isolated:
            if node_name in locations:
                loc = locations[node_name]
                isolated_lats.append(loc['lat'])
                isolated_lons.append(loc['lon'])
                isolated_names.append(node_name)
        
        if isolated_lats:
            data.append(go.Scattergeo(
                lon=isolated_lons,
                lat=isolated_lats,
                mode='markers',
                marker=dict(
                    size=15,
                    color='rgba(255, 0, 0, 0)',
                    line=dict(width=3, color='red')
                ),
                text=isolated_names,
                hovertext=[f"<b>ISOLATED: {name}</b>" for name in isolated_names],
                hoverinfo='text',
                name='⚠️ Isolated Nodes',
                showlegend=True
            ))
    
    # Create figure
    layout = go.Layout(
        title=dict(
            text=title,
            x=0.5,
            xanchor='center',
            font=dict(size=20)
        ),
        geo=dict(
            scope='world',  # World map instead of south america
            projection_type='natural earth',  # Better world projection
            showland=True,
            landcolor='rgb(243, 243, 243)',
            coastlinecolor='rgb(204, 204, 204)',
            showlakes=True,
            lakecolor='rgb(230, 245, 255)',
            showcountries=True,
            countrycolor='rgb(204, 204, 204)'
        ),
        showlegend=True,
        legend=dict(
            x=0.02,
            y=0.98,
            bgcolor='rgba(255, 255, 255, 0.8)',
            bordercolor='gray',
            borderwidth=1
        ),
        hovermode='closest'
    )
    
    return go.Figure(data=data, layout=layout)
