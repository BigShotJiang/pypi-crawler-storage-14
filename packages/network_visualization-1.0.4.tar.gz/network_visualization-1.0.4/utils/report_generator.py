"""
Report generation utilities.
"""

from typing import Dict, List
from datetime import datetime


def generate_report(locations: Dict, connections: List[Dict], 
                   connectivity_analysis: Dict, output_format: str = 'text') -> str:
    """
    Generate a comprehensive network analysis report.
    
    Args:
        locations: Dictionary of locations
        connections: List of connections
        connectivity_analysis: Results from analyze_connectivity()
        output_format: Format ('text', 'markdown', 'html')
        
    Returns:
        Formatted report string
    """
    if output_format == 'markdown':
        return _generate_markdown_report(locations, connections, connectivity_analysis)
    elif output_format == 'html':
        return _generate_html_report(locations, connections, connectivity_analysis)
    else:
        return _generate_text_report(locations, connections, connectivity_analysis)


def _generate_text_report(locations: Dict, connections: List[Dict], 
                         analysis: Dict) -> str:
    """Generate text format report."""
    lines = []
    lines.append("=" * 80)
    lines.append("NETWORK ANALYSIS REPORT - CHILE ENERGY SYSTEM")
    lines.append("=" * 80)
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")
    
    # Summary
    lines.append("1. NETWORK SUMMARY")
    lines.append("-" * 80)
    
    # Count by type (with error handling for malformed data)
    power_count = len([l for l in locations.values() if isinstance(l, dict) and l.get('type') == 'power'])
    demand_count = len([l for l in locations.values() if isinstance(l, dict) and l.get('type') == 'substation_with_demand'])
    substation_count = len([l for l in locations.values() if isinstance(l, dict) and l.get('type') == 'substation'])
    nodo_count = len([l for l in locations.values() if isinstance(l, dict) and l.get('type') == 'nodo'])
    
    lines.append(f"   Total Locations: {len(locations)}")
    lines.append(f"     - Power Plants: {power_count}")
    lines.append(f"     - Substations with Demand: {demand_count}")
    lines.append(f"     - Substations (no demand): {substation_count}")
    lines.append(f"     - Transmission Nodes: {nodo_count}")
    lines.append("")
    
    power_links = len([c for c in connections if c['type'] == 'power_link'])
    trans_links = len([c for c in connections if c['type'] == 'transmission_link'])
    
    lines.append(f"   Total Connections: {len(connections)}")
    lines.append(f"     - Power Links: {power_links}")
    lines.append(f"     - Transmission Links: {trans_links}")
    lines.append("")
    
    # Connectivity
    lines.append("2. CONNECTIVITY ANALYSIS")
    lines.append("-" * 80)
    lines.append(f"   Nodes in Graph: {analysis['total_nodes']}")
    lines.append(f"   Edges in Graph: {analysis['total_edges']}")
    lines.append(f"   Connected Components: {analysis['num_components']}")
    lines.append("")
    
    if analysis['is_fully_connected']:
        lines.append("   [OK] Network is fully connected")
    else:
        lines.append("   [WARNING] Network has disconnected components")
        lines.append("")
        lines.append("   Component Sizes:")
        for i, comp in enumerate(analysis['components'][:10], 1):
            lines.append(f"     Component {i}: {len(comp)} nodes")
    
    lines.append("")
    
    # Isolated nodes
    if analysis['num_isolated'] > 0:
        lines.append(f"   [WARNING] Isolated Nodes: {analysis['num_isolated']}")
        if analysis['num_isolated'] <= 20:
            for node in analysis['isolated_nodes']:
                loc_type = locations[node]['type'] if node in locations else 'unknown'
                lines.append(f"     - {node} ({loc_type})")
    else:
        lines.append("   [OK] No isolated nodes")
    
    lines.append("")
    
    # Demand substations
    lines.append("3. DEMAND SUBSTATIONS STATUS")
    lines.append("-" * 80)
    total_demand = len(analysis['substations_with_demand'])
    connected_demand = len(analysis['demand_in_main'])
    isolated_demand = len(analysis['demand_isolated'])
    
    lines.append(f"   Total Substations with Demand: {total_demand}")
    if total_demand > 0:
        lines.append(f"     - Connected to Main Network: {connected_demand} ({100*connected_demand/total_demand:.1f}%)")
        lines.append(f"     - Isolated: {isolated_demand} ({100*isolated_demand/total_demand:.1f}%)")
    else:
        lines.append(f"     - Connected to Main Network: {connected_demand}")
        lines.append(f"     - Isolated: {isolated_demand}")
    lines.append("")
    
    if isolated_demand > 0:
        lines.append("   [CRITICAL] Isolated Demand Substations:")
        for node in sorted(analysis['demand_isolated']):
            lines.append(f"     - {node}")
    else:
        lines.append("   [OK] All demand substations are connected")
    
    lines.append("")
    lines.append("=" * 80)
    lines.append("END OF REPORT")
    lines.append("=" * 80)
    
    return '\n'.join(lines)


def _generate_markdown_report(locations: Dict, connections: List[Dict], 
                             analysis: Dict) -> str:
    """Generate markdown format report."""
    lines = []
    lines.append("# Network Analysis Report - Chile Energy System")
    lines.append("")
    lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")
    
    # Summary
    lines.append("## 1. Network Summary")
    lines.append("")
    
    power_count = len([l for l in locations.values() if l['type'] == 'power'])
    demand_count = len([l for l in locations.values() if l['type'] == 'substation_with_demand'])
    substation_count = len([l for l in locations.values() if l['type'] == 'substation'])
    nodo_count = len([l for l in locations.values() if l['type'] == 'nodo'])
    
    lines.append(f"- **Total Locations:** {len(locations)}")
    lines.append(f"  - Power Plants: {power_count}")
    lines.append(f"  - Substations with Demand: {demand_count}")
    lines.append(f"  - Substations (no demand): {substation_count}")
    lines.append(f"  - Transmission Nodes: {nodo_count}")
    lines.append("")
    
    power_links = len([c for c in connections if c['type'] == 'power_link'])
    trans_links = len([c for c in connections if c['type'] == 'transmission_link'])
    
    lines.append(f"- **Total Connections:** {len(connections)}")
    lines.append(f"  - Power Links: {power_links}")
    lines.append(f"  - Transmission Links: {trans_links}")
    lines.append("")
    
    # Connectivity
    lines.append("## 2. Connectivity Analysis")
    lines.append("")
    
    status = "✅ Fully Connected" if analysis['is_fully_connected'] else "⚠️ Disconnected"
    lines.append(f"**Status:** {status}")
    lines.append("")
    lines.append(f"- Components: {analysis['num_components']}")
    lines.append(f"- Main Component Size: {analysis['main_component_size']} nodes")
    lines.append(f"- Isolated Nodes: {analysis['num_isolated']}")
    lines.append("")
    
    # Demand substations
    lines.append("## 3. Demand Substations")
    lines.append("")
    
    total_demand = len(analysis['substations_with_demand'])
    connected_demand = len(analysis['demand_in_main'])
    isolated_demand = len(analysis['demand_isolated'])
    
    lines.append(f"- **Total:** {total_demand}")
    lines.append(f"- **Connected:** {connected_demand} ({100*connected_demand/total_demand:.1f}%)")
    lines.append(f"- **Isolated:** {isolated_demand} ({100*isolated_demand/total_demand:.1f}%)")
    lines.append("")
    
    if isolated_demand > 0:
        lines.append("### ⚠️ Isolated Demand Substations")
        lines.append("")
        for node in sorted(analysis['demand_isolated']):
            lines.append(f"- `{node}`")
    
    return '\n'.join(lines)


def _generate_html_report(locations: Dict, connections: List[Dict], 
                         analysis: Dict) -> str:
    """Generate HTML format report."""
    # Simplified HTML report
    return f"""
    <html>
    <head><title>Network Analysis Report</title></head>
    <body>
    <h1>Network Analysis Report</h1>
    <p>Total Locations: {len(locations)}</p>
    <p>Total Connections: {len(connections)}</p>
    <p>Connected Components: {analysis['num_components']}</p>
    </body>
    </html>
    """


def save_report(report: str, filename: str, output_dir: str = 'outputs/reports'):
    """
    Save report to file.
    
    Args:
        report: Report content string
        filename: Output filename
        output_dir: Output directory
    """
    import os
    
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(report)
    
    return filepath
