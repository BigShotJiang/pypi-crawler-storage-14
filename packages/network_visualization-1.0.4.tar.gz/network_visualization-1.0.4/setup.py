"""
Setup configuration for network-visualization package.
"""
from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

# Read requirements
with open(os.path.join(this_directory, 'requirements.txt'), encoding='utf-8') as f:
    requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='network-visualization',
    version='1.0.4',
    author='Ricardo Energy Model Team',
    author_email='your.email@example.com',  # Update with your email
    description='Tools for visualizing and analyzing electrical grid network topology',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://gitlab.com/yourusername/network_visualization',  # Update with your GitLab repo URL
    packages=find_packages(include=['utils', 'utils.*']),
    py_modules=['network_visualization'],
    install_requires=requirements,
    python_requires='>=3.8',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Visualization',
        'Topic :: Scientific/Engineering :: Information Analysis',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    keywords='network, visualization, graph, energy, electrical-grid',
    entry_points={
        'console_scripts': [
            'visualize-network=scripts.visualize_network:main',
            'analyze-isolated=scripts.analyze_isolated:main',
            'suggest-connections=scripts.suggest_connections:main',
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
