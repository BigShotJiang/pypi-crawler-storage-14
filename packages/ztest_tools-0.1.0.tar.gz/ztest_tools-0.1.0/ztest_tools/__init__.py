from .ztests import z_test_one_mean, z_test_two_proportions

__all__ = ["z_test_one_mean", "z_test_two_proportions"]
