import math
from scipy.stats import norm

def z_test_one_mean(xbar, mu0, sigma, n, alpha=0.05):
    """
    Perform a Z-test for one mean.

    Parameters:
    - xbar: sample mean
    - mu0: population mean under H0
    - sigma: population standard deviation
    - n: sample size
    - alpha: significance level (default 0.05)

    Returns:
    - z: Z-statistic
    - p_value: two-sided p-value
    """
    z = (xbar - mu0) / (sigma / math.sqrt(n))
    p_value = 2 * (1 - norm.cdf(abs(z)))
    z_crit = norm.ppf(1 - alpha / 2)

    print("\n--- Z-Test for One Mean ---")
    print(f"Z-statistic = {z:.3f}")
    print(f"p-value = {p_value:.4f}")
    print(f"Critical Region: |Z| > {z_crit:.3f}")

    if abs(z) > z_crit:
        print("Decision: Reject H₀ → Significant difference exists.")
        print("Type I Error (α):", alpha)
    else:
        print("Decision: Fail to reject H₀ → No significant difference.")
        print("Type II Error (β): Not calculated (depends on true mean).")

    return z, p_value


def z_test_two_proportions(n1, x1, n2, x2, alpha=0.05):
    """
    Perform a Z-test for the difference of two proportions.

    Parameters:
    - n1: sample size for group 1
    - x1: number of successes in group 1
    - n2: sample size for group 2
    - x2: number of successes in group 2
    - alpha: significance level (default 0.05)

    Returns:
    - z: Z-statistic
    - p_value: two-sided p-value
    """
    p1 = x1 / n1
    p2 = x2 / n2
    p_pool = (x1 + x2) / (n1 + n2)

    z = (p1 - p2) / math.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))
    p_value = 2 * (1 - norm.cdf(abs(z)))
    z_crit = norm.ppf(1 - alpha / 2)

    print("\n--- Z-Test for Difference of Two Proportions ---")
    print(f"Z-statistic = {z:.3f}")
    print(f"p-value = {p_value:.4f}")
    print(f"Critical Region: |Z| > {z_crit:.3f}")

    if abs(z) > z_crit:
        print("Decision: Reject H₀ → Proportions differ significantly.")
        print("Type I Error (α):", alpha)
    else:
        print("Decision: Fail to reject H₀ → No significant difference.")
        print("Type II Error (β): Not calculated (depends on true p1, p2).")

    return z, p_value
