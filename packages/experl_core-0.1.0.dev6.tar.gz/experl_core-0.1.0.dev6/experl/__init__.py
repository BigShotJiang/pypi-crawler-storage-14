from experl.utils.logging_utils import ExperlLogger


ExperlLogger.initialize()
