from collections.abc import Callable, Iterator
from datetime import datetime
from typing import Any

from datasets import Dataset, Features, Split, load_dataset
from transformers import PreTrainedTokenizer

from experl.config.schema.config_classes import DatasetConfig
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import get_tokenizer_config


log = ExperlLogger.get_logger(__name__)


def fetch_dataset(path: str,
                  name: str | None = None,
                  split: str | Split | list[str] | list[Split] | None = None,
                  process_fn: Callable | None = None,
                  process_fn_kwargs: dict[str, Any] | None = None,
                  remove_columns: list[str] = None,
                  features: Features | None = None,
                  select_columns: list[str] = None,
                  num_proc: int = 8
                  ) -> Dataset:
    dataset = load_dataset(path, name, split=f"{split}", features=features)
    log.debug(f"dataset info : {dataset}")
    if select_columns:
        dataset = dataset.select_columns(select_columns)
    if process_fn:
        dataset = dataset.map(process_fn, fn_kwargs=process_fn_kwargs or {},
                              remove_columns=remove_columns, num_proc=num_proc)
    return dataset


def batch_iter(dataset: Dataset, batch_size: int) -> Iterator[Dataset]:
    for ind in range(0, len(dataset), batch_size):
        yield dataset[ind: ind + batch_size]


def get_dataset_metadata(dataset: Dataset,
                         dataset_config: DatasetConfig,
                         tokenizer_ref: PreTrainedTokenizer,
                         max_samples: int = 5,
                         name: str = "train",

                         ) -> dict:
    tokenizer_config = get_tokenizer_config(tokenizer_ref)
    num_rows = len(dataset)
    columns = dataset.column_names
    preview = dataset.select(range(min(max_samples, num_rows)))
    preview_dict = preview.to_list()

    token_stats = {}
    if "input_ids" in columns:
        avg_len = (
            sum(len(x) for x in dataset["input_ids"]) / len(dataset["input_ids"])
            if len(dataset["input_ids"]) > 0
            else 0
        )
        token_stats[f"dataset.{name}.avg_tokens"] = avg_len

    metadata = {
        "dataset_name": name,
        "num_rows": num_rows,
        "columns": columns,
        "created_at": datetime.now().isoformat(),
        "preview_dict": preview_dict,
        "config": dict(dataset_config),
        **token_stats,
        f"dataset.{name}.columns": ", ".join(columns),
        f"dataset.{name}.type": type(dataset).__name__,
        f"dataset.{name}.num_rows": num_rows,
        f"dataset.{name}.num_columns": len(columns),
    }
    if tokenizer_config:
        metadata["tokenizer"] = tokenizer_config
    return metadata


if __name__ == '__main__':
    ds_path = "HuggingFaceH4/ultrafeedback_binarized"
    ds = fetch_dataset(ds_path, name="", split="train_sft[:1]")
    log.info(f"dataset row = {next(iter(ds))}")
