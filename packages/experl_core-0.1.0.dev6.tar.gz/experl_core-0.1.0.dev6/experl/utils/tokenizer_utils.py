
from transformers import BatchEncoding, PreTrainedTokenizer


def tokenize_input(tokenizer_ref: PreTrainedTokenizer, text: str, max_seq_length: int) -> BatchEncoding:
    encoded = tokenizer_ref(
        text,
        truncation=True,
        max_length=max_seq_length,
        padding=False,
    )
    if tokenizer_ref.eos_token_id is not None and encoded["input_ids"][-1] != tokenizer_ref.eos_token_id:
        encoded["input_ids"] += [tokenizer_ref.eos_token_id]
        encoded["attention_mask"] = encoded["attention_mask"] + [1]

    encoded["input_ids"] = list(encoded["input_ids"])
    encoded["attention_mask"] = list(encoded["attention_mask"])
    encoded["labels"] = encoded["input_ids"].copy()

    return encoded
