import logging
import os
import sys
from logging import Logger, StreamHandler


class ExperlLogger:
    _done = False
    _root_logger = None
    _default_handler: StreamHandler = None

    log_level_str = os.getenv("LOG_LEVEL", "INFO").upper()

    @classmethod
    def _setup_logger(cls) -> None:
        cls._root_logger = logging.getLogger("experl")
        cls._root_logger.setLevel(ExperlLogger._log_level())
        if cls._default_handler is None:
            cls._default_handler = logging.StreamHandler(sys.stdout)
            cls._default_handler.flush = sys.stdout.flush  # type: ignore
            cls._default_handler.setLevel(ExperlLogger._log_level())
            cls._root_logger.addHandler(cls._default_handler)
        cls._root_logger.propagate = False

    @classmethod
    def get_logger(cls, name: str) -> Logger:
        log = logging.getLogger(name)
        log.setLevel(ExperlLogger._log_level())
        if cls._default_handler:
            log.addHandler(cls._default_handler)
        log.propagate = False
        return log

    @classmethod
    def _log_level(cls) -> int:
        level_name = getattr(cls, 'log_level_str', 'INFO')
        if isinstance(level_name, str):
            level_name = level_name.upper()
        if hasattr(logging, 'getLevelNamesMapping'):
            mapping = logging.getLevelNamesMapping()
            return mapping.get(level_name, logging.INFO)
        else:
            return logging.INFO

    @classmethod
    def initialize(cls) -> None:
        if cls._done:
            return
        cls._setup_logger()
        cls._done = True
