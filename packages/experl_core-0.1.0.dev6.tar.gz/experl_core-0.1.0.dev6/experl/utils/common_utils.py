import platform
from pathlib import Path

import hydra
import mlflow
import psutil
import torch
import transformers
import trl
from trl.scripts.utils import get_git_commit_hash

from experl.utils.logging_utils import ExperlLogger


log = ExperlLogger.get_logger(__name__)


def get_file_text(file_path: str, max_lines: int = 100) -> str:
    try:
        with open(file_path, encoding="utf-8") as f:
            lines = []
            for i, line in enumerate(f):
                if i >= max_lines:
                    break
                lines.append(line)
        return "".join(lines).strip()
    except FileNotFoundError as ex:
        log.error(f"File not found: {file_path} — {ex}")
        raise ex
    except Exception as ex:
        log.error(f"Error reading file: {file_path} — {ex}")
        raise ex


def get_sys_info() -> dict:
    sys_info = {
        "python_version": platform.python_version(),
        "cpu_count": psutil.cpu_count(),
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
        "cuda_version": torch.version.cuda if torch.cuda.is_available() else "N/A",
        "torch_version": torch.__version__,
        "transformers_version": transformers.__version__,
        "trl_version": getattr(trl, "__version__", "N/A"),
        "hydra_version": getattr(hydra, "__version__", "N/A"),
        "mlflow_version": getattr(mlflow, "__version__", "N/A"),
        "commit_hash": (get_git_commit_hash("experl")),
        "os": platform.platform(),
        "hostname": platform.node(),
    }
    return sys_info


def _get_project_root(marker: str = "experl") -> str:
    current_path = Path(__file__).resolve()
    for parent in current_path.parents:
        if (parent / marker).is_dir():
            return parent
    raise FileNotFoundError(
        f"Project root could not be found. Searched for a directory containing '{marker}'."
    )


def exists(file_path: str) -> bool:
    return Path(file_path).exists()


if __name__ == "__main__":
    commit = get_git_commit_hash(str(_get_project_root()))
    log.info(f"commit hash = {commit}")
