import datetime
import os
import re
import socket
import sys
from pathlib import Path

import torch
from transformers import AutoTokenizer, PreTrainedModel, PreTrainedTokenizer
from trl import get_kbit_device_map, get_quantization_config

from experl.config.schema.config_classes import OrchestratorConfig
from experl.utils.logging_utils import ExperlLogger


log = ExperlLogger.get_logger(__name__)


def generate_responses(model_ref: PreTrainedModel, tokenizer_ref: PreTrainedTokenizer,
                       prompts: list[str],
                       max_new_tokens: int) -> list[str]:
    inputs = tokenizer_ref(prompts, return_tensors="pt", padding=True).to(
        model_ref.device
    )
    outputs = model_ref.generate(**inputs, max_new_tokens=max_new_tokens)
    return tokenizer_ref.batch_decode(outputs, skip_special_tokens=True)


def get_tracking_path(orch_config: OrchestratorConfig) -> str:
    log.debug(f"experl root dir : {orch_config.root_dir}")
    tracking_path = Path(os.path.join(orch_config.root_dir, "mlflow_runs"))
    log.debug(f"MLFlow tracking_path : {tracking_path}")
    tracking_path.mkdir(parents=True, exist_ok=True)

    return str(tracking_path)


def create_file_path(orch_config: OrchestratorConfig, output_fle: str) -> str:
    return str(
        os.path.join(
            orch_config.run_base_dir,
            f"{output_fle}",
        )
    )


def get_tokenizer(model_id: str, padding_side: str = None) -> PreTrainedTokenizer:
    tokenizer_obj = AutoTokenizer.from_pretrained(model_id, use_fast=True)
    if padding_side is not None:
        tokenizer_obj.padding_side = padding_side

    return tokenizer_obj


def get_tokenizer_config(tokenizer_ref: PreTrainedTokenizer) -> dict:
    tokenizer_config = {
        "name_or_path": tokenizer_ref.name_or_path,
        "padding_side": tokenizer_ref.padding_side,
        "truncation_side": tokenizer_ref.truncation_side,
        "model_max_length": tokenizer_ref.model_max_length,
        "vocab_size": len(tokenizer_ref),
    }
    return tokenizer_config


def generate_run_name(
        base_name: str,
        task: str = None,
        tag: str = None,
        include_timestamp: bool = True,
        include_host: bool = False,
) -> str:
    parts = [get_model_id(base_name)]
    if task:
        parts.append(task)
    if tag:
        parts.append(tag)
    if include_timestamp:
        timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M")
        parts.append(timestamp)
    if include_host:
        hostname = socket.gethostname().split(".")[0]
        parts.append(hostname)
    return "__".join(parts)


def print_tokenizer_details(tokenizer_ref: PreTrainedTokenizer) -> None:
    log.info(f"tokenizer - padding_side: {tokenizer_ref.padding_side}")
    log.info(f"tokenizer - PAD token: {tokenizer_ref.pad_token}")
    log.info(f"tokenizer - PAD token ID: {tokenizer_ref.pad_token_id}")
    log.info(f"tokenizer - EOS token: {tokenizer_ref.eos_token}")
    log.info(f"tokenizer - EOS token ID: {tokenizer_ref.eos_token_id}")
    ids = tokenizer_ref("Beautiful is better than", return_tensors="pt")["input_ids"][0]
    log.info(f"token ids => {ids}")
    log.info(f"token decoded => {tokenizer_ref.decode(ids)} ")


def get_model_id(model_name_or_path: str) -> str:
    """Converts a model ID into a safe directory name."""
    raw_id = model_name_or_path.split("/")[-1]
    return re.sub(r"[^a-zA-Z0-9_-]", "_", raw_id)

def sanitize_model(model_ref: PreTrainedModel, tokenizer_ref: PreTrainedTokenizer) -> None:
    try:
        log.debug(f"tokenizer - bos_token {tokenizer_ref.bos_token}")
        log.debug(f"tokenizer - eos_token {tokenizer_ref.eos_token}")
        log.debug(f"tokenizer - pad_token {tokenizer_ref.pad_token}")
        length_before = len(tokenizer_ref)
        if hasattr(model_ref.config, "bos_token"):
            log.debug(f"model - bos_token {model_ref.config.bos_token}")
        if hasattr(model_ref.config, "eos_token"):
            log.debug(f"model - eos_token {model_ref.config.eos_token}")
        if hasattr(model_ref.config, "pad_token"):
            log.debug(f"model - pad_token {model_ref.config.pad_token}")

        if tokenizer_ref.pad_token is None:
            log.info(f"Tokenizer pad_token {tokenizer_ref.pad_token} and pad_token_id {tokenizer_ref.pad_token_id}")
            tokenizer_ref.pad_token = tokenizer_ref.eos_token
            tokenizer_ref.pad_token_id = tokenizer_ref.eos_token_id

        length_after = len(tokenizer_ref)
        if length_after > length_before:
            log.info(f"Tokenizer length before {length_before} and after {length_after}")
            model_ref.resize_token_embeddings(length_after)
            log.info(f"Model resize_token_embeddings updated to {length_after}")
    except Exception as e:
        log.error(f"Exception in the sanitize_model : {e}")


def get_device() -> str:
    if torch.cuda.is_available():
        log.debug("CUDA (GPU) is available. Using the GPU.")
        return "cuda"
    else:
        log.debug("CUDA (GPU) is not available. Using the CPU.")
        return "cpu"


def get_dtype(dtype: str) -> torch.dtype:
    return dtype if dtype in ["auto", None] else getattr(torch, dtype)


def load_model_init_kwargs(config: OrchestratorConfig) -> dict:
    model_init_kwargs = dict(
        attn_implementation=config.model.attn_implementation,
        use_cache=False,
        dtype=config.model.dtype,
    )
    if config.model.use_peft:
        if config.model.load_in_8bit:
            config.model.load_in_4bit = False
        quantization_config = get_quantization_config(config.model)
        if quantization_config is not None:
            # Passing None would not be treated the same as omitting the argument, so we include it only when valid.
            model_init_kwargs["device_map"] = get_kbit_device_map()
            model_init_kwargs["quantization_config"] = quantization_config
    else:
        config.model.load_in_4bit = False
        config.model.load_in_8bit = False

    return model_init_kwargs or {}


def validate_args() -> str:
    if len(sys.argv) < 2:
        log.info("You must specify one of: ppo | dpo")
        sys.exit(1)
    pipeline_type = sys.argv[1]
    if pipeline_type not in ["ppo", "dpo"]:
        log.info(f"Invalid pipeline: {pipeline_type}. Expected: ppo | dpo")
        sys.exit(1)
    return pipeline_type


def format_chatml(messages: list[dict[str, str]]) -> str:
    """
    Manually converts a list of messages into a ChatML formatted string.

    Input:  [{"role": "user", "content": "Hello"}]
    Output: "<|im_start|>user\nHello<|im_end|>\n"
    """
    formatted_text = ""
    log.debug(f"format_chatml messages == {messages}")

    for msg in messages:
        # Get role and content, defaulting to empty if missing
        log.debug(f"format_chatml msg == {msg}")
        role = msg.get("role", "user")
        content = msg.get("content", "")

        # Append the ChatML tags
        formatted_text += f"<|im_start|>{role}\n{content}<|im_end|>\n"

    return formatted_text
