import os
from argparse import ArgumentParser
from pathlib import Path

from experl.utils.logging_utils import ExperlLogger


log = ExperlLogger.get_logger(__name__)


def get_hydra_config_path(config_file: str) -> tuple[str, str]:
    """
    Convert a filesystem config path into Hydra-friendly:
    1. config_path (directory)
    2. config_name (filename without .yaml)
    Both are RELATIVE to the script directory.
    """
    script_dir = Path(__file__).resolve().parent
    config_full = Path(config_file).resolve()
    rel_path = os.path.relpath(config_full.parent, script_dir)
    rel_dir = rel_path.replace("\\", "/")
    config_name = config_full.stem
    return config_name, rel_dir


class ExperlParser(ArgumentParser):
    def __init__(self) -> None:
        super().__init__()
        self.add_argument(
            "--config-name",
            type=str,
            required=False,
            default="ppo",
            help="RLHF Pipeline to run",
        )
        self.add_argument(
            "--config-path",
            type=str,
            required=False,
            default="yaml",
            help="RLHF Pipeline config path",
        )

    def parse_args_and_configs(self, args: list) -> tuple:
        config_file = None
        config_name = None
        config_path = None
        if "dpo" in args:
            args.pop(args.index("dpo"))
            config_name = "dpo"
        elif "ppo" in args:
            args.pop(args.index("ppo"))
            config_name = "ppo"

        if "--config" in args:
            config_index = args.index("--config")
            args.pop(config_index)
            config_file = args.pop(config_index)
            config_name, config_path = get_hydra_config_path(config_file)

        cli_args, cli_overrides = self.parse_known_args(args)
        cli_args.config_name = config_name
        cli_args.config_path = config_path
        log.debug(f"config file : {config_file}")
        log.debug(f"CLI args = {cli_args}")
        log.debug(f"CLI overrides = {cli_overrides}")
        return config_file, cli_args, cli_overrides
