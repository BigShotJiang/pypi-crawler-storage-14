from typing import Any

from omegaconf import OmegaConf
from transformers import AutoConfig, AutoModelForCausalLM, BatchEncoding
from trl import PPOConfig, PPOTrainer, create_reference_model

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.models.reward_model import RewardModel
from experl.trainer.base_trainer import BaseTrainer
from experl.utils.dataset_utils import fetch_dataset
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import (
    create_file_path,
    get_device,
    get_tokenizer,
    get_tracking_path,
    sanitize_model,
)


log = ExperlLogger.get_logger(__name__)


class PPOModelTrainer(BaseTrainer):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        self.ref_policy = None
        self.value_model = None
        self.reward_model = None
        self.policy_model = None
        super().__init__(
            trainer_name="ppo_model",
            config=config,
            mlflow_logger=mlflow_logger,
        )
        self.trainer_args = PPOConfig(**OmegaConf.to_container(self.config.pipeline.ppo))
        self.trainer_args.sft_model_path = create_file_path(
            self.config,
            f"sft_model/final-sft_model-{self.model_id}",
        )
        self.trainer_args.reward_model_path = create_file_path(
            self.config,
            f"reward_model/final-reward_model-{self.model_id}",
        )

    def process_dataset(self) -> bool:
        """Load json dataset and tokenize 'prompt' (and optional 'response')."""

        def tokenize_fn(example: dict[str, Any]) -> BatchEncoding:
            text = example[self.config.dataset.prompt.prompt_key]
            tokenized = self.tokenizer(
                text=text,
                padding=False,
                truncation=True,
                max_length=self.config.max_seq_length)

            if self.tokenizer.eos_token_id is not None and tokenized["input_ids"][-1] != self.tokenizer.eos_token_id:
                tokenized["input_ids"] += [self.tokenizer.eos_token_id]
                tokenized["attention_mask"] += [1]
            log.info(f"tokenize_fn = {tokenized}")
            return tokenized

        self.train_dataset = self.train_dataset.map(tokenize_fn,
                                                    batched=False,
                                                    remove_columns=[self.config.dataset.prompt.prompt_key],
                                                    num_proc=self.trainer_args.dataset_num_proc
                                                    )
        if self.eval_dataset:
            self.eval_dataset = self.eval_dataset.map(tokenize_fn,
                                                      batched=False,
                                                      remove_columns=[self.config.dataset.prompt.prompt_key],
                                                      num_proc=self.trainer_args.dataset_num_proc
                                                      )
        return True

    def load_train_dataset(self) -> None:
        ds_config = self.config.dataset
        self.train_dataset = fetch_dataset(ds_config.prompt.path,
                                           name=ds_config.prompt.subset,
                                           split=ds_config.prompt.train_split)

    def load_eval_dataset(self) -> None:
        if self.trainer_args.eval_strategy != "no":
            ds_config = self.config.dataset
            self.eval_dataset = fetch_dataset(ds_config.prompt.path,
                                              name=ds_config.prompt.subset,
                                              split=ds_config.prompt.test_split)

    def load_model(self) -> None:
        self.load_policy_model()
        self.load_reward_model()
        self.load_value_model()
        self.load_ref_model()

    def load_ref_model(self) -> None:
        self.ref_policy = create_reference_model(self.policy_model)
        self.ref_policy.to(get_device())

    def load_value_model(self) -> None:
        rm_config = AutoConfig.from_pretrained(
            self.trainer_args.reward_model_path,
            **self.model_kwargs
        )
        self.value_model = RewardModel(rm_config)
        # sanitize_model(self.value_model, self.tokenizer)
        self.value_model.to(get_device())

    def load_reward_model(self) -> None:
        log.debug(f"reward_model_name = {self.trainer_args.reward_model_path}")
        rm_config = AutoConfig.from_pretrained(
            self.trainer_args.reward_model_path,
            **self.model_kwargs
        )
        self.reward_model = RewardModel(rm_config)
        # sanitize_model(self.reward_model, self.tokenizer)
        self.reward_model.to(get_device())

    def load_policy_model(self) -> None:
        self.tokenizer = get_tokenizer(
            self.trainer_args.sft_model_path,
            padding_side="left",
        )
        self.policy_model = AutoModelForCausalLM.from_pretrained(
            self.trainer_args.sft_model_path,
            **self.model_kwargs
        )
        sanitize_model(self.policy_model, self.tokenizer)
        self.policy_model.to(get_device())

    def create_trainer(self) -> None:
        self.trainer = PPOTrainer(
            args=self.trainer_args,
            processing_class=self.tokenizer,
            model=self.policy_model,
            ref_model=self.ref_policy,
            reward_model=self.reward_model,
            value_model=self.value_model,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset
        )

    def train_model(self) -> None:
        self.trainer.train()

    @staticmethod
    def run(main_config: OrchestratorConfig, nested: bool = True) -> None:
        stage = "ppo"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=nested,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                    "task_name": main_config.task_name
                }
        ) as mlogger:
            # mlogger.log_args_and_overrides(args, overrides)
            ppo_model_trainer = PPOModelTrainer(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            ppo_model_trainer.train()


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    PPOModelTrainer.run(orch_config)
