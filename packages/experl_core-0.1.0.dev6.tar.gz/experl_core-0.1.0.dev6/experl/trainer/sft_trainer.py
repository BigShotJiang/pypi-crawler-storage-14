from omegaconf import OmegaConf
from transformers import AutoModelForCausalLM
from trl import SFTConfig, SFTTrainer, get_peft_config

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.trainer.base_trainer import BaseTrainer
from experl.trainer.sft_dataset_formatter import SFTDatasetFormatter
from experl.utils.dataset_utils import fetch_dataset
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import get_device, get_tokenizer, get_tracking_path, sanitize_model


log = ExperlLogger.get_logger(__name__)


class SFTModelTrainer(BaseTrainer):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        super().__init__(
            trainer_name="sft_model",
            config=config,
            mlflow_logger=mlflow_logger,
        )

        self.trainer_args = SFTConfig(**OmegaConf.to_container(self.config.pipeline.sft))
        self.sft_dataset = SFTDatasetFormatter(self.config.dataset)

    def load_model(self) -> None:
        self.model = AutoModelForCausalLM.from_pretrained(
            self.config.base_model_name,
            **self.model_kwargs
        )
        self.tokenizer = get_tokenizer(
            self.config.base_model_name, self.config.padding_side
        )
        sanitize_model(self.model, self.tokenizer)
        self.model.to(get_device())

    def process_dataset(self) -> bool:
        self.train_dataset = self.sft_dataset.format_dataset(self.train_dataset)
        if self.eval_dataset:
            self.eval_dataset = self.sft_dataset.format_dataset(self.eval_dataset)
        return True

    def load_train_dataset(self) -> None:
        select_columns = [self.config.dataset.sft.prompt_key, self.config.dataset.sft.response_key]
        self.train_dataset = fetch_dataset(self.config.dataset.sft.path,
                                           name=self.config.dataset.sft.subset,
                                           split=self.config.dataset.sft.train_split,
                                           select_columns=select_columns
                                           )

    def load_eval_dataset(self) -> None:
        if self.trainer_args.eval_strategy != "no":
            select_columns = [self.config.dataset.sft.prompt_key, self.config.dataset.sft.response_key]

            self.eval_dataset = fetch_dataset(self.config.dataset.sft.path,
                                              name=self.config.dataset.sft.subset,
                                              split=self.config.dataset.sft.test_split,
                                              select_columns=select_columns
                                              )

    def create_trainer(self) -> None:
        peft_config = get_peft_config(self.config.model)
        self.trainer = SFTTrainer(
            model=self.model,
            processing_class=self.tokenizer,
            args=self.trainer_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset,
            peft_config=peft_config
        )

    def train_model(self) -> None:
        self.trainer.train()

    @staticmethod
    def run(main_config: OrchestratorConfig, nested: bool = True) -> None:
        stage = "sft"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=nested,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                    "task_name": main_config.task_name
                }
        ) as mlogger:
            # mlogger.log_args_and_overrides(args, overrides)
            app = SFTModelTrainer(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            app.train()


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    SFTModelTrainer.run(orch_config)
