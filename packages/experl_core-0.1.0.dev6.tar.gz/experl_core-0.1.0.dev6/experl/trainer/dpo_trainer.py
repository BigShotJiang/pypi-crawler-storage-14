from typing import Any

from omegaconf import OmegaConf
from transformers import AutoModelForCausalLM
from trl import DPOConfig, DPOTrainer, create_reference_model

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.trainer.base_trainer import BaseTrainer
from experl.utils.dataset_utils import fetch_dataset
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import (
    create_file_path,
    get_device,
    get_model_id,
    get_tokenizer,
    get_tracking_path,
    sanitize_model,
)


log = ExperlLogger.get_logger(__name__)


class DPOModelTrainer(BaseTrainer):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        self.ref_policy = None
        self.value_model = None
        self.reward_model = None
        self.model = None
        super().__init__(
            trainer_name="dpo_model",
            config=config,
            mlflow_logger=mlflow_logger,
        )
        self.trainer_args = DPOConfig(**OmegaConf.to_container(self.config.pipeline.dpo))

    def create_trainer(self) -> None:
        self.trainer = DPOTrainer(
            self.model,
            self.ref_policy,
            args=self.trainer_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset,
            processing_class=self.tokenizer,
        )

    def load_train_dataset(self) -> None:
        ds_config = self.config.dataset
        select_columns = [ds_config.preference.prompt_key, ds_config.preference.chosen_key,
                          ds_config.preference.rejected_key]
        self.train_dataset = fetch_dataset(ds_config.preference.path,
                                           name=ds_config.preference.subset,
                                           split=ds_config.preference.train_split,
                                           select_columns=select_columns
                                           )

    def load_eval_dataset(self) -> None:
        ds_config = self.config.dataset
        if self.trainer_args.eval_strategy != "no":
            select_columns = [ds_config.preference.prompt_key, ds_config.preference.chosen_key,
                              ds_config.preference.rejected_key]
            self.eval_dataset = fetch_dataset(ds_config.preference.path,
                                              name=ds_config.preference.subset,
                                              split=ds_config.preference.test_split,
                                              select_columns=select_columns
                                              )

    def train_model(self) -> None:
        self.trainer.train()

    def load_model(self) -> None:
        self.load_policy_model()
        self.load_ref_model()

    def load_ref_model(self) -> None:
        self.ref_policy = create_reference_model(self.model)
        self.ref_policy.to(get_device())

    def load_policy_model(self) -> None:
        model_id = get_model_id(self.config.base_model_name)
        sft_model_path = create_file_path(
            self.config,
            f"sft_model/final-sft_model-{model_id}",
        )
        self.tokenizer = get_tokenizer(
            sft_model_path,
            padding_side=self.config.padding_side,
        )
        self.model = AutoModelForCausalLM.from_pretrained(
            sft_model_path,
            **self.model_kwargs
        )
        sanitize_model(self.model, self.tokenizer)
        self.model.to(get_device())

    def process_dataset(self) -> bool:

        def messages_to_text(messages: str | list[dict]) -> str:
            text = ""
            if "content" in messages:
                for m in messages:
                    role = m["role"]
                    content = m["content"]
                    if role == "user":
                        text += f"<|user|>\n{content}\n"
                    elif role == "assistant":
                        text += f"<|assistant|>\n{content}\n"
                    else:
                        text += f"<|{role}|>\n{content}\n"
            elif isinstance(messages, str):
                text = messages.strip()
            elif isinstance(messages, list) and len(messages) == 1:
                text = messages[-1]
            return text

        def tokenize_fn(example: dict[str, Any]) -> dict:

            chosen = self.tokenizer(
                messages_to_text(example["chosen"]),
                truncation=True,
                max_length=self.config.max_seq_length,
                add_special_tokens=True,
            )

            rejected = self.tokenizer(
                messages_to_text(example["rejected"]),
                truncation=True,
                max_length=self.config.max_seq_length,
                add_special_tokens=True,
            )
            for data_row in (chosen, rejected):
                if (self.tokenizer.eos_token_id is not None
                        and data_row["input_ids"][-1] != self.tokenizer.eos_token_id
                ):
                    data_row["input_ids"].append(self.tokenizer.eos_token_id)
                    data_row["attention_mask"].append(1)

            return {
                "chosen_input_ids": chosen["input_ids"],
                "chosen_attention_mask": chosen["attention_mask"],
                "rejected_input_ids": rejected["input_ids"],
                "rejected_attention_mask": rejected["attention_mask"],
            }

        self.train_dataset = self.train_dataset.map(tokenize_fn)
        if self.eval_dataset:
            self.eval_dataset = self.eval_dataset.map(tokenize_fn)
        return True

    @staticmethod
    def run(main_config: OrchestratorConfig, nested: bool = True) -> None:
        stage = "dpo"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=nested,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                    "task_name": main_config.task_name
                }
        ) as mlogger:
            # mlogger.log_args_and_overrides(args, overrides)
            model_trainer = DPOModelTrainer(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            model_trainer.train()


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    DPOModelTrainer.run(orch_config)
