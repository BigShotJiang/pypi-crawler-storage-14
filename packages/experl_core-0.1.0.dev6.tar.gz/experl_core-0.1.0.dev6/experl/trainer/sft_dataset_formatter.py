from typing import Any

from datasets import Dataset

from experl import ExperlLogger
from experl.config.schema.config_classes import DatasetConfig


COLUMN_MAPPINGS = {
    "input": ["prompt", "instruction", "question", "query", "input", "user_input"],
    "output": ["response", "completion", "answer", "output", "assistant_response"],
    "system": ["system", "system_prompt", "sys"]
}

log = ExperlLogger.get_logger(__name__)


class SFTDatasetFormatter:
    def __init__(self, dataset_config: DatasetConfig) -> None:
        self.dataset_config = dataset_config

    @staticmethod
    def get_content(example: dict[str, Any], column_name: str) -> str:
        for key in COLUMN_MAPPINGS[column_name]:
            if key in example and example[key]:
                return str(example[key])
        return ""

    @staticmethod
    def get_formatted_text(messages: list) -> str:
        formatted_text = ""
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            role = role.lower()
            if role == "system":
                formatted_text += f"<|im_start|>system\n{content}<|im_end|>"
            elif role == "user":
                formatted_text += f"<|im_start|>user\n{content}<|im_end|>"
            elif role in ["assistant", "model"]:
                formatted_text += f"<|im_start|>assistant\n{content}<|im_end|>"
        return formatted_text

    @staticmethod
    def format_dataset_row(example: dict[str, Any]) -> dict[str, str]:
        """
        Normalizes any dataset row into a single 'text' column using the target ChatML format.
        """
        messages = []
        """
        if "messages" in example and isinstance(example["messages"], list):
            messages = example["messages"]
        elif "chosen" in example and isinstance(example["chosen"], list):
            messages = example["chosen"]
        else:
        """
        sys_text = SFTDatasetFormatter.get_content(example, "system")
        input_text = SFTDatasetFormatter.get_content(example, "input")
        output_text = SFTDatasetFormatter.get_content(example, "output")

        if len(input_text) == 0 or len(output_text) == 0:
            log.info(f" input_text = {len(input_text)}")
            log.info(f" output_text = {len(output_text)}")
            raise Exception(f"format_dataset_row input text is {input_text} and output text is {output_text}")

        if input_text and output_text:
            if sys_text:
                input_text = f"{sys_text}\n\n{input_text}"
            messages = [
                {"role": "user", "content": input_text},
                {"role": "assistant", "content": output_text}
            ]
        return {"text": SFTDatasetFormatter.get_formatted_text(messages)}

    def format_dataset(self, dataset: Dataset) -> Dataset:
        log.debug(f" Dataset config : {self.dataset_config.sft}")
        log.debug(f" Dataset Info : {dataset}")
        return dataset.map(SFTDatasetFormatter.format_dataset_row, remove_columns=dataset.column_names)
