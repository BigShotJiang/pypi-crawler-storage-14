import os
from abc import abstractmethod
from dataclasses import asdict

from accelerate import PartialState
from mlflow.data.huggingface_dataset import from_huggingface
from omegaconf import OmegaConf
from peft import AutoPeftModelForCausalLM
from transformers import AutoTokenizer
from trl import ModelConfig

from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.utils.common_utils import get_sys_info
from experl.utils.dataset_utils import get_dataset_metadata
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import get_model_id, load_model_init_kwargs


log = ExperlLogger.get_logger(__name__)


class BaseTrainer:
    """
    An abstract base class for all trainers in the RLHF pipeline (SFT, RM, PPO).

    This class handles common functionalities like loading model, load dataset , creating TRL trainer,
    training and saving model into output directory.
    """

    def __init__(
            self,
            trainer_name: str,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        self.model = None
        self.tokenizer = None
        self.config = config
        self.trainer_name = trainer_name
        self.mlflow_logger = mlflow_logger
        self.trainer = None
        self.train_dataset = None
        self.eval_dataset = None
        self.trainer_args = None
        self.output_dir = os.path.join(
            self.config.run_base_dir,
            self.trainer_name,
        )
        self.model_id = get_model_id(self.config.base_model_name)
        self.config.model = ModelConfig(**OmegaConf.to_container(self.config.model))
        self.model_kwargs = load_model_init_kwargs(self.config)
        self.final_model_path = os.path.join(
            self.output_dir, f"final-{self.trainer_name}-{self.model_id}"
        )

    @abstractmethod
    def create_trainer(self) -> None:
        pass

    @abstractmethod
    def train_model(self) -> None:
        pass

    @abstractmethod
    def load_model(self) -> None:
        """Subclasses must implement this to load their specific model."""
        pass

    def load_dataset(self) -> None:
        """Subclasses must implement this to load their specific dataset."""
        self.load_train_dataset()
        self.load_eval_dataset()
        self.log_dataset()
        # self.pre_process_dataset()
        with PartialState().local_main_process_first():
            is_processed = self.process_dataset()
            if is_processed:
                self.log_dataset("processed")

    def pre_process_dataset(self) -> None:
        pass

    @abstractmethod
    def load_train_dataset(self) -> None:
        pass

    @abstractmethod
    def load_eval_dataset(self) -> None:
        pass

    def process_dataset(self) -> bool:
        return True

    def log_dataset(self, prefix: str ="") -> None:
        self.mlflow_logger.log_dataset_metadata(
            get_dataset_metadata(self.train_dataset, self.config.dataset,
                                 self.tokenizer, name=f"{prefix}train",
                                 ))

        self.mlflow_logger.log_dataset(
            from_huggingface(self.train_dataset),
            context=f"{prefix}train",
            model_id=self.model_id,
        )

        if self.eval_dataset:
            self.mlflow_logger.log_dataset_metadata(
                get_dataset_metadata(self.train_dataset, self.config.dataset,
                                     self.tokenizer, name=f"{prefix}test",
                                     ))
            self.mlflow_logger.log_dataset(
                from_huggingface(self.eval_dataset),
                context=f"{prefix}test",
                model_id=self.model_id,
            )

    def prepare_args(self) -> None:
        self.trainer_args.output_dir = self.output_dir
        self.trainer_args.logging_dir = os.path.join(self.output_dir, "runs")

    def train(self) -> None:
        log.info(f"Training output will be saved to: {self.output_dir}")
        self.prepare_args()
        self.mlflow_logger.log_dict(get_sys_info(), "system_info.json")
        self.mlflow_logger.log_dict(asdict(self.trainer_args), "training_args.json")
        self.load_model()
        self.load_dataset()
        self.create_trainer()
        log.debug(f"training args = {self.trainer_args}")
        self.train_model()
        self.trainer.accelerator.print("✅ Training completed.")
        self.save_model()

    def save_model(self) -> None:
        log.debug(f"Model and self.tokenizer saved to {self.final_model_path}")
        self.trainer.accelerator.print(f"💾 Model saved to {self.final_model_path}.")
        self.trainer.save_model(self.final_model_path)
        self.tokenizer.save_pretrained(self.final_model_path)
        if self.config.model.use_peft:
            self.merge_and_save_peft_model()
        # self.log_model(self.model_id, self.final_model_path)

    def merge_and_save_peft_model(self, ) -> None:
        log.debug("Loading LoRA adapter model...")
        peft_model = AutoPeftModelForCausalLM.from_pretrained(
            self.final_model_path,
            dtype=self.config.model.dtype,
        )
        log.debug("Merging LoRA weights into the base model...")
        merged_model = peft_model.merge_and_unload()
        merged_model.save_pretrained(self.final_model_path)
        tokenizer = AutoTokenizer.from_pretrained(self.final_model_path)
        tokenizer.save_pretrained(self.final_model_path)
        log.debug(f"Merge complete. Final model saved at: {self.final_model_path}")

    def log_model(self, final_model_id: str, final_model_path: str) -> None:
        self.mlflow_logger.log_artifact(
            file_path=final_model_path, artifact_path="model"
        )
        self.mlflow_logger.log_model(final_model_path, final_model_id)
