from omegaconf import OmegaConf
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from trl import RewardConfig, RewardTrainer

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.trainer.base_trainer import BaseTrainer
from experl.utils.dataset_utils import fetch_dataset
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import (
    create_file_path,
    get_device,
    get_tracking_path,
    sanitize_model,
)


log = ExperlLogger.get_logger(__name__)


class RewardModelTrainer(BaseTrainer):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        super().__init__(
            trainer_name="reward_model",
            config=config,
            mlflow_logger=mlflow_logger,
        )
        self.sft_model_path = create_file_path(
            self.config,
            f"sft_model/final-sft_model-{self.model_id}",
        )

        self.trainer_args = RewardConfig(**OmegaConf.to_container(self.config.pipeline.reward))

    def load_train_dataset(self) -> None:
        ds_config = self.config.dataset
        self.train_dataset = fetch_dataset(ds_config.preference.path,
                                           name=ds_config.preference.subset,
                                           split=ds_config.preference.train_split)

    def load_eval_dataset(self) -> None:
        if self.trainer_args.eval_strategy != "no":
            ds_config = self.config.dataset
            self.eval_dataset = fetch_dataset(ds_config.preference.path,
                                              name=ds_config.preference.subset,
                                              split=ds_config.preference.test_split)

    def load_model(self) -> None:
        self.tokenizer = AutoTokenizer.from_pretrained(self.sft_model_path)

        self.model = AutoModelForSequenceClassification.from_pretrained(
            self.sft_model_path,
            num_labels=1,
            **self.model_kwargs
        )
        sanitize_model(self.model, self.tokenizer)
        self.model.to(get_device())

    def create_trainer(self) -> None:
        self.trainer = RewardTrainer(
            model=self.model,
            args=self.trainer_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset,
            processing_class=self.tokenizer,
        )

    def train_model(self) -> None:
        self.trainer.train()

    @staticmethod
    def run(main_config: OrchestratorConfig, nested: bool = True) -> None:
        stage = "reward"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=nested,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                    "task_name": main_config.task_name
                }
        ) as mlogger:
            trainer = RewardModelTrainer(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            trainer.train()


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    RewardModelTrainer.run(orch_config)
