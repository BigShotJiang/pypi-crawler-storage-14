import json

import torch
from datasets import Dataset
from tqdm import tqdm
from transformers import PreTrainedModel, PreTrainedTokenizer

from experl.config.schema.config_classes import OrchestratorConfig
from experl.evaluation.evaluator import EvaluationResult
from experl.utils.dataset_utils import batch_iter
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import generate_responses


log = ExperlLogger.get_logger(__name__)


class DPOJudgeEvaluator:
    def __init__(
            self,
            reference_model: PreTrainedModel,
            candidate_model: PreTrainedModel,
            judge_model: PreTrainedModel,
            reference_tokenizer: PreTrainedTokenizer,
            judge_tokenizer: PreTrainedTokenizer,
            config: OrchestratorConfig,
            result_file_path: str,
    ) -> None:
        self.judge_model = judge_model
        self.reference_model = reference_model
        self.candidate_model = candidate_model
        self.reference_tokenizer = reference_tokenizer
        self.judge_tokenizer = judge_tokenizer
        self.config = config
        self.result_file_path = result_file_path

    def evaluate(self, dataset: Dataset, batch_size: int) -> EvaluationResult:
        results = []
        with open(self.result_file_path, "w") as file:
            for batch in tqdm(batch_iter(dataset, batch_size)):
                prompts = batch[self.config.dataset.eval.prompt_key]
                reference_response = batch[self.config.dataset.eval.chosen_key]
                base_responses = generate_responses(
                    self.reference_model,
                    self.reference_tokenizer,
                    prompts,
                    self.config.pipeline.eval.max_new_tokens,
                )
                dpo_responses = generate_responses(
                    self.candidate_model,
                    self.reference_tokenizer,
                    prompts,
                    self.config.pipeline.eval.max_new_tokens,
                )

                for prompt, base_resp, dpo_resp in zip(
                        prompts, base_responses, dpo_responses, strict=False
                ):
                    judge_input = self.config.pipeline.judge.prompt_template.format(
                        prompt=prompt, response_a=base_resp, response_b=dpo_resp, reference=reference_response
                    )
                    verdict = self._query_judge(judge_input)
                    result_item = {
                        "prompt": prompt,
                        "base_model_response": base_resp,
                        "dpo": dpo_resp,
                        "verdict": verdict,
                    }
                    results.append(result_item)
                    file.write(json.dumps(result_item) + "\n")

        wins = sum(1 for r in results if r["verdict"].strip().upper() == "B")
        losses = sum(1 for r in results if r["verdict"].strip().upper() == "A")
        ties = sum(1 for r in results if r["verdict"].strip().lower().startswith("tie"))

        total = len(results)
        metrics = {
            "eval/judge_win_rate": wins / total,
            "eval/judge_tie_rate": ties / total,
            "eval/judge_loss_rate": losses / total,
        }

        return EvaluationResult(wins, losses, ties, total, results, metrics)

    def _query_judge(self, text: str) -> str:
        """
        Query local judge model using transformers pipeline or raw generation.
        The judge model should output a short text like 'A', 'B', or 'Tie'.
        """
        inputs = self.judge_tokenizer(
            text, return_tensors="pt", truncation=True, padding=True
        ).to(self.judge_model.device)

        with torch.no_grad():
            outputs = self.judge_model.generate(
                **inputs,
                max_new_tokens=self.config.pipeline.judge.max_new_tokens,
                temperature=self.config.pipeline.judge.temperature,
                do_sample=self.config.pipeline.judge.do_sample,
                pad_token_id=self.judge_tokenizer.pad_token_id,
                eos_token_id=self.judge_tokenizer.eos_token_id,
                repetition_penalty=self.config.pipeline.judge.repetition_penalty,
                no_repeat_ngram_size=self.config.pipeline.judge.no_repeat_ngram_size,
                top_k=1,
                top_p=1.0,
                use_cache=True,
                early_stopping=True
            )

        response = self.reference_tokenizer.decode(outputs[0], skip_special_tokens=True)
        verdict = response.strip().split()[-1]
        return normalize_verdict(verdict)


def normalize_verdict(text: str) -> str:
    log.info(f"normalize_verdict = {text}")
    text = text.strip().upper()
    if text.startswith("A"):
        return "A"
    if text.startswith("B"):
        return "B"
    if text.startswith("T"):
        return "Tie"

    # fallback
    if "A" in text and "B" not in text:
        return "A"
    if "B" in text and "A" not in text:
        return "B"
    if "TIE" in text:
        return "Tie"

    return text


def extract_answer(input_string: str) -> str:
    if input_string:
        cleaned_string = input_string.replace("\\", "").replace('"', "")
        return cleaned_string
    return input_string
