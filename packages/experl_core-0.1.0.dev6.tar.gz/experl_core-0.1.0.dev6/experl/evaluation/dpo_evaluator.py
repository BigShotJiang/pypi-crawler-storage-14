from mlflow.data.huggingface_dataset import from_huggingface
from omegaconf import OmegaConf
from transformers import AutoModelForCausalLM, AutoTokenizer

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import EvalConfig, OrchestratorConfig
from experl.evaluation.evaluator import BaseEvaluator
from experl.evaluation.judge_evaluator import DPOJudgeEvaluator, EvaluationResult
from experl.logger.mlflow_logger import MLFlowLogger
from experl.utils.dataset_utils import fetch_dataset, get_dataset_metadata
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import (
    create_file_path,
    get_device,
    get_dtype,
    get_tokenizer,
    get_tracking_path,
    sanitize_model,
)


log = ExperlLogger.get_logger(__name__)


class DPOEvaluator(BaseEvaluator):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        self.base_tokenizer = None
        self.base_model = None
        self.dpo_model = None
        self.judge_model = None
        self.judge_tokenizer = None
        self.eval_prompt_dataset = None
        super().__init__(
            trainer_name="eval_dpo",
            config=config,
            mlflow_logger=mlflow_logger,
        )
        self.eval_args = EvalConfig(**OmegaConf.to_container(self.config.pipeline.eval, resolve=True))

    def eval_model(self) -> None:
        judge_evaluator = DPOJudgeEvaluator(
            self.base_model,
            self.dpo_model,
            self.judge_model,
            self.base_tokenizer,
            self.judge_tokenizer,
            self.config,
            self.result_file_path,
        )
        result: EvaluationResult = judge_evaluator.evaluate(
            self.eval_prompt_dataset, self.eval_args.batch_size
        )
        self.mlflow_logger.log_metrics(result.metrics)
        self.mlflow_logger.log_dict(
            result.results, f"eval/{self.config.pipeline.eval.output_file}"
        )
        self.eval_summary(result)

    def load_model(self) -> None:
        base_model_path = create_file_path(
            self.config,
            f"sft_model/final-sft_model-{self.model_id}",
        )
        dpo_model_path = create_file_path(
            self.config,
            f"dpo_model/final-dpo_model-{self.model_id}",
        )
        self.load_judge_model(self.config.pipeline.judge.judge_model_name)
        self.load_base_model(base_model_path)
        self.load_dpo_model(dpo_model_path)

    def load_judge_model(self, judge_model_id: str) -> None:
        log.debug(f"judge_model_id = {judge_model_id}")
        self.judge_tokenizer = AutoTokenizer.from_pretrained(
            judge_model_id, padding_side="left"
        )
        self.judge_model = AutoModelForCausalLM.from_pretrained(
            judge_model_id,
            dtype=get_dtype(self.config.model.dtype),
            use_cache=False,
            attn_implementation=self.config.model.attn_implementation,
        )
        sanitize_model(self.judge_model, self.judge_tokenizer)
        self.judge_model.to(get_device())

    def load_base_model(self, base_model_path: str) -> None:
        log.debug(f"base_model_path = {base_model_path}")
        self.base_model = AutoModelForCausalLM.from_pretrained(
            base_model_path,
            dtype=get_dtype(self.config.model.dtype),
            use_cache=False,
            attn_implementation=self.config.model.attn_implementation,
        )
        self.base_tokenizer = get_tokenizer(base_model_path, "left")
        sanitize_model(self.base_model, self.base_tokenizer)
        self.base_model.to(get_device())

    def load_dpo_model(self, dpo_model_path: str) -> None:
        log.debug(f"[loader] Loading tokenizer from: {dpo_model_path}")
        log.debug(f"[loader] Loading model: {dpo_model_path}")
        self.dpo_model = AutoModelForCausalLM.from_pretrained(
            dpo_model_path,
            dtype=get_dtype(self.config.model.dtype),
            use_cache=False,
            attn_implementation=self.config.model.attn_implementation,
        )
        self.dpo_model.to(get_device())

    def load_dataset(self) -> None:
        log.debug(
            f"Loading evaluation dataset from: {self.config.dataset.eval.path}"
        )
        ds_config = self.config.dataset
        select_columns = [ds_config.eval.prompt_key, ds_config.eval.chosen_key]
        self.eval_prompt_dataset = fetch_dataset(ds_config.eval.path,
                                                 name=ds_config.eval.subset,
                                                 split=ds_config.eval.train_split,
                                                 select_columns=select_columns)

        self.mlflow_logger.log_dataset_metadata(
            get_dataset_metadata(self.eval_prompt_dataset,
                                 self.config.dataset,
                                 self.base_tokenizer,
                                 name="eval", ))

        self.mlflow_logger.log_dataset(
            from_huggingface(self.eval_prompt_dataset),
            context="eval",
            model_id=self.model_id,
        )

    @staticmethod
    def run(main_config: OrchestratorConfig) -> None:
        stage = "eval"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=True,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                },
        ) as mlogger:
            # mlogger.log_args_and_overrides(args, overrides)
            model_evaluator = DPOEvaluator(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            model_evaluator.eval()

if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    DPOEvaluator.run(orch_config)
