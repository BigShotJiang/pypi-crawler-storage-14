import os
import sys
from argparse import Namespace

from hydra import compose, initialize

from experl import ExperlLogger
from experl.config.schema.config_classes import OrchestratorConfig
from experl.utils.parser import ExperlParser


log = ExperlLogger.get_logger(__name__)


class ConfigLoader:

    @staticmethod
    def _compose_config(
            args: Namespace, overrides: list[str] = None
    ) -> OrchestratorConfig:
        config_name = args.config_name
        config_path = "yaml" if args.config_path is None else args.config_path
        log.debug(f"Config path : {config_path} , config_name = {config_name}")
        with initialize(config_path=config_path, version_base=None):
            cfg = compose(config_name=config_name, overrides=overrides or [])
        log.debug(f"initialized config for {config_name} and path : {config_path} ")
        return cfg

    @staticmethod
    def _load_config(args: Namespace, overrides: list[str] = None) -> OrchestratorConfig:
        """Load orchestrator config from yaml or defaults."""
        config = ConfigLoader._compose_config(
            args=args,
            overrides=overrides,
        )
        config.config_name = args.config_name
        config.overrides = overrides
        return config

    @staticmethod
    def build_orchestrator_config() -> OrchestratorConfig:
        parser: ExperlParser = ExperlParser()
        rlhf_config_file, cli_args, cli_overrides = parser.parse_args_and_configs(sys.argv[1:])
        if rlhf_config_file and os.path.isfile(rlhf_config_file):
            orch_config: OrchestratorConfig = ConfigLoader._load_config(cli_args, cli_overrides)
            orch_config.config_file = rlhf_config_file
            return orch_config
        else:
            orch_config: OrchestratorConfig = ConfigLoader._load_config(cli_args, cli_overrides)
            return orch_config


if __name__ == "__main__":
    main_config = ConfigLoader.build_orchestrator_config()
