from dataclasses import dataclass, field

from trl import DPOConfig, ModelConfig, PPOConfig, RewardConfig, SFTConfig


@dataclass
class DatasetConfigItem:
    path: str = "trl-internal-testing/zen"
    subset: str = "test"
    train_split: str = "train"
    test_split: str = "test"
    # For ALL
    prompt_key: str = "prompt"
    # SFT
    response_key: str = "completion"
    # Reward and DPO
    chosen_key: str = "chosen"
    rejected_key: str = "rejected"


@dataclass
class DatasetConfig:
    sft: DatasetConfigItem = field(default_factory=DatasetConfigItem)
    preference: DatasetConfigItem = field(default_factory=DatasetConfigItem)
    prompt: DatasetConfigItem = field(default_factory=DatasetConfigItem)
    eval: DatasetConfigItem = field(default_factory=DatasetConfigItem)


@dataclass
class EvalConfig:
    """Arguments for the evaluation script."""
    output_file: str = "eval_dpo_results.jsonl"
    max_new_tokens: int = 128
    batch_size: int = 4
    summary_file: str = "eval_dpo_summary.txt"


@dataclass
class JudgeEvalConfig:
    judge_model_name: str
    temperature: float
    max_new_tokens: int
    prompt_template: str
    repetition_penalty: float
    no_repeat_ngram_size: int
    do_sample: bool = True


@dataclass
class MLflowConfig:
    """Configuration for MLflow integration."""
    tracking_dir: str = "mlflow_runs"
    enabled: bool = True


@dataclass
class BasePipelineConfig:
    stages: tuple = field(default_factory=tuple)


@dataclass
class PPOPipelineConfig(BasePipelineConfig):
    reward_model_name: str = "gpt2"
    reward: RewardConfig = field(default_factory=RewardConfig)
    sft: SFTConfig = field(default_factory=SFTConfig)
    ppo: PPOConfig = field(default_factory=PPOConfig)
    eval: EvalConfig = field(default_factory=EvalConfig)


@dataclass
class DPOPipelineConfig(BasePipelineConfig):
    sft: SFTConfig = field(default_factory=SFTConfig)
    dpo: DPOConfig = field(default_factory=DPOConfig)
    eval: EvalConfig = field(default_factory=EvalConfig)
    judge: JudgeEvalConfig = field(default_factory=EvalConfig)


@dataclass
class OrchestratorConfig:
    """
        The main configuration dataclass for the entire RLHF Orchestrator.
        This structure directly mirrors the YAML file.
        """
    rlhf_pipeline: str = "ppo"
    base_model_name: str = "gpt2"
    project_name: str = "efault-project"
    task_name: str = "exp-name"
    max_seq_length: int = 128
    run_name: str = None
    state_sleep_interval: int = 5
    report_to: str = "mlflow"
    root_dir: str = "experl_output"
    run_base_dir: str = ""
    seed: int = 42
    padding_side: str = "right"
    overrides: list = None
    config_file: str = None
    config_name: str = None
    """
    The main configuration dataclass for the entire RLHF Orchestrator.
    This structure directly mirrors the YAML file.
    """
    mlflow: MLflowConfig = field(default_factory=MLflowConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    dataset: DatasetConfig = field(default_factory=DatasetConfig)
    pipeline: PPOPipelineConfig | DPOPipelineConfig = field(default_factory=BasePipelineConfig)
