import os
import random
import time

import numpy as np
import torch
from omegaconf import OmegaConf

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.utils.common_utils import get_sys_info
from experl.utils.logging_utils import ExperlLogger
from experl.utils.process_runner import ProcessRunner
from experl.utils.trainer_utils import (
    generate_run_name,
    get_tracking_path,
)


log = ExperlLogger.get_logger(__name__)


class RLHFOrchestrator:

    def __init__(self, config: OrchestratorConfig) -> None:
        torch.manual_seed(config.seed)
        np.random.seed(config.seed)
        random.seed(config.seed)
        self.config: OrchestratorConfig = config

    def run_pipeline(self, overrides: list[str] = None) -> None:

        if self.config.config_file:
            common_args = [
                "--config",
                f"{self.config.config_file}",
                "--config-name",
                f"{self.config.config_name}",
                f"++project_name={self.config.project_name}",
                f"++run_name={self.config.run_name}",
                f"++run_base_dir={self.config.run_base_dir}",
            ]
        else:
            common_args = [
                "--config-name",
                f"{self.config.config_name}",
                f"++project_name={self.config.project_name}",
                f"++run_name={self.config.run_name}",
                f"++run_base_dir={self.config.run_base_dir}",
            ]

        if overrides is not None:
            for argument in overrides:
                log.debug(f"overridden argument : {argument}")
                common_args.append(argument)

        stages = self.config.pipeline.stages

        for stage_name, stage_config in stages.items():
            log.debug(f"stage_name = {stage_name}")
            log.debug(f"stage_config = {stage_config}")
            if stage_config["enabled"]:
                self.execute_stage(common_args, stage_config["script"], stage_name)
            else:
                log.info(f"Stage {stage_name} is disabled. Skipping.")

        log.info(
            f"\nRLHF Pipeline for {str(self.config.rlhf_pipeline).upper()} finished successfully!"
        )

    def execute_stage(self, common_args: list, script_path: str, stage_name: str) -> None:
        log.debug(f"Stage args : {common_args} ")
        ProcessRunner.run_stage(stage_name, script_path, common_args)
        time.sleep(self.config.state_sleep_interval)

    @staticmethod
    def run(config: OrchestratorConfig) -> None:
        log.info("===" * 40)
        log.info(f"{' ' * 40} Starting RLHF for {str(config.rlhf_pipeline).upper()}")
        log.info("===" * 40)

        stage = "orchestrator"
        if not config.run_name:
            config.run_name = generate_run_name(
                base_name=config.base_model_name,
                task=config.task_name,
                tag=config.rlhf_pipeline,
            )
            config.run_base_dir = os.path.join(
                config.root_dir, config.project_name, config.run_name
            )

        with MLFlowLogger(
                experiment_name=config.project_name,
                tracking_uri=get_tracking_path(config),
                run_name=config.run_name,
                nested=False,
                tags={
                    "stage": stage,
                    "task_name": config.task_name,
                    "run_name": config.run_name,
                    "project_name": config.project_name,
                },
        ) as mlflow_logger:
            RLHFOrchestrator.log_configurations(config, mlflow_logger)
            orchestrator = RLHFOrchestrator(config)
            orchestrator.run_pipeline(overrides=config.overrides)

    @staticmethod
    def log_configurations(
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger
    ) -> None:
        try:
            RLHFOrchestrator.log_deptree(mlflow_logger)
            # mlflow_logger.log_args_and_overrides(None, config.overrides)
            mlflow_logger.log_args_and_overrides(None, None)
            mlflow_logger.log_dict(get_sys_info(), "system_info.json")
            mlflow_logger.log_dict(OmegaConf.to_container(config), "config.json", )
        except Exception as e:
            log.error(f"Failed to log configurations - {e}")

    @staticmethod
    def log_deptree(mlflow_logger: MLFlowLogger) -> None:
        if os.path.exists("uv.lock"):
            mlflow_logger.log_artifact("uv.lock")
        elif os.path.exists("poetry.lock"):
            mlflow_logger.log_artifact("poetry.lock")
        elif os.path.exists("requirements.txt"):
            mlflow_logger.log_artifact("requirements.txt")


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    RLHFOrchestrator.run(orch_config)
