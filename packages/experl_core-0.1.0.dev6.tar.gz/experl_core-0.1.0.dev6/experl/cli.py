import sys

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.rlhf_orchestrator import RLHFOrchestrator
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import validate_args


def main() -> None:
    log = ExperlLogger.get_logger(__name__)
    try:
        validate_args()
        orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
        RLHFOrchestrator.run(orch_config)
    except Exception as e:
        log.error(f"Exception during RLHF Orchestrator execution: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
