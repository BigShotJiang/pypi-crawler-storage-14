# z3mcp.py
try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    from fastmcp import FastMCP

try:
    from z3 import *
except ImportError:
    print("Z3 not installed. Please install z3-solver package.")
    import sys
    sys.exit(1)

# Create an MCP server
mcp = FastMCP("Z3 Solver")


# Evaluate SMT commands
@mcp.tool()
def eval(command : str) -> str:
    """Evaluate an SMTLIB2 Command using Z3
    Whenever you are faced with a problem that can be formulated as SMTLIB2 constraints
    always use this function to solve the problem.
    """
    return Z3_eval_smtlib2_string(main_ctx().ctx, command)

def main():
    """Main entry point for the MCP server"""
    mcp.run()

if __name__ == "__main__":
    main()
