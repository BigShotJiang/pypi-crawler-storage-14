# UniORM

**Universal Async ORM for Python**

[![PyPI version](https://badge.fury.io/py/uniorm.svg)](https://badge.fury.io/py/uniorm)
[![Python Version](https://img.shields.io/pypi/pyversions/uniorm.svg)](https://pypi.org/project/uniorm/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

UniORM is a powerful, easy-to-use asynchronous ORM for Python, built on top of TortoiseORM with a Peewee-style API. It combines the best of both worlds: the performance and robustness of TortoiseORM with the simplicity and elegance of Peewee.

## ✨ Features

- **🚀 Fully Async**: Built from the ground up for `asyncio`
- **🎯 Peewee-Style API**: Familiar and intuitive syntax
- **💾 Multi-Database Support**: PostgreSQL, MySQL, and SQLite
- **🔄 Smart Migrations**: Integrated with Aerich for seamless schema management
- **🖥️ Web Editor**: Built-in web interface for database management
- **🌍 Multilingual**: Documentation and code comments in English, Russian, and Uzbek

## 📦 Installation

Install UniORM using pip:

```bash
pip install uniorm
```

For PostgreSQL support:
```bash
pip install uniorm[postgresql]
```

For MySQL support:
```bash
pip install uniorm[mysql]
```

## 🚀 Quick Start

### 1. Define Your Models

```python
from uniorm import Model, CharField, IntField, DateTimeField

class User(Model):
    name = CharField(max_length=100)
    email = CharField(max_length=255, unique=True)
    age = IntField(default=0)
    created_at = DateTimeField(auto_now_add=True)

    class Meta:
        table = "users"
```

### 2. Initialize Database

```python
import asyncio
from uniorm import Database

async def main():
    # Initialize database connection
    db = await Database.init(
        url="sqlite://db.sqlite3",
        modules={"models": ["__main__"]}
    )
    
    # Your code here...
    
    # Close connection
    await db.close()

if __name__ == "__main__":
    asyncio.run(main())
```

### 3. Perform CRUD Operations

```python
# Create
user = await User.create(name="John Doe", email="john@example.com", age=30)

# Read
user = await User.get(id=1)
all_users = await User.select().all()
young_users = await User.filter(age__lt=30)

# Update
await user.update_fields(age=31)

# Delete
await user.delete_instance()
```

### 4. Complex Queries

```python
from uniorm import Q

# Filter with conditions
active_users = await User.filter(is_active=True, age__gte=18)

# Complex queries with Q objects
users = await User.filter(
    (Q(age__gte=18) & Q(is_active=True)) | Q(is_admin=True)
)

# Pagination
result = await User.paginate(page=1, page_size=20)
print(f"Total: {result['total']}, Pages: {result['pages']}")
```

## 🔄 Migrations

UniORM uses Aerich for database migrations.

### Initialize Migrations

```bash
uniorm init --db-url "sqlite://db.sqlite3" --models "myapp.models"
uniorm init-db --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

### Create and Apply Migrations

```bash
# Create a new migration
uniorm migrate --name "add_user_table" --db-url "sqlite://db.sqlite3" --models "myapp.models"

# Apply migrations
uniorm upgrade --db-url "sqlite://db.sqlite3" --models "myapp.models"

# Rollback
uniorm downgrade --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

## 🖥️ Web Editor

UniORM comes with a built-in web editor for database management.

```python
from uniorm.web_editor import start_editor

if __name__ == "__main__":
    start_editor(host="127.0.0.1", port=5000)
```

Then open your browser and navigate to `http://127.0.0.1:5000`

## 📚 Documentation

Full documentation is available in three languages:

- [English Documentation](docs/en/index.md)
- [Русская документация](docs/ru/index.md)
- [O'zbek hujjatlari](docs/uz/index.md)

## 🗃️ Supported Databases

| Database   | URL Format                                    |
|------------|-----------------------------------------------|
| SQLite     | `sqlite://path/to/db.sqlite3`                 |
| PostgreSQL | `postgres://user:password@host:port/dbname`   |
| MySQL      | `mysql://user:password@host:port/dbname`      |

## 🛠️ Field Types

UniORM provides a comprehensive set of field types:

| Field Type        | Description                  |
|-------------------|------------------------------|
| `IntField`        | Integer field                |
| `CharField`       | String field with max length |
| `TextField`       | Long text field              |
| `BooleanField`    | Boolean field                |
| `DateField`       | Date field                   |
| `DateTimeField`   | DateTime field               |
| `FloatField`      | Float field                  |
| `ForeignKeyField` | Foreign key relationship     |
| `ManyToManyField` | Many-to-many relationship    |

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🌟 Acknowledgments

- Built on top of [TortoiseORM](https://tortoise.github.io/)
- Inspired by [Peewee](http://docs.peewee-orm.com/)
- Migrations powered by [Aerich](https://github.com/tortoise/aerich)

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/uniorm/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/uniorm/discussions)

---

Made with ❤️ by the UniORM Team
