'''
# UniORM Hujjatlari

Pythonda asinxron dasturlar uchun mo'ljallangan, TortoiseORM asosida Peewee uslubidagi API bilan yaratilgan kuchli va qulay UniORM kutubxonasining rasmiy hujjatlariga xush kelibsiz.

## 1. Kirish

UniORM Pythonning asinxron dasturlarida ma'lumotlar bazasi bilan ishlashni soddalashtirishga qaratilgan. U TortoiseORMning mustahkamligi va samaradorligidan foydalangan holda intuitiv, Peewee-ga o'xshash interfeysni taqdim etadi.

**Asosiy xususiyatlari:**
- **Asinxronlik:** Boshidan oxirigacha `asyncio` uchun qurilgan.
- **Peewee-ga o'xshash API:** Tanish va ishlatish uchun oson metodlar (`.create()`, `.get()`, `.select()` va hokazo).
- **Ko'p ma'lumotlar bazasini qo'llab-quvvatlash:** PostgreSQL, MySQL va SQLite bilan ishlaydi.
- **Kuchli migratsiyalar:** Sxemani oson boshqarish uchun `aerich` bilan integratsiyalashgan.
- **Veb-muharrir:** Ma'lumotlar bazasini boshqarish uchun o'rnatilgan veb-interfeys bilan birga keladi.

## 2. O'rnatish

UniORMni `pip` yordamida o'rnating:

```bash
pip install uniorm
```

Ushbu bitta buyruq yordamida kutubxona yadrosi, veb-muharrir uchun kerakli bog'liqliklar (Flask) va migratsiya vositasi (aerich) o'rnatiladi.

## 3. Tez boshlash

Quyida modelni qanday aniqlash va asosiy amallarni bajarish bo'yicha tezkor misol keltirilgan.

```python
import asyncio
from uniorm import Database, Model, CharField, IntField

# 1. Modellaringizni aniqlang
class User(Model):
    name = CharField(max_length=100)
    email = CharField(max_length=255, unique=True)
    age = IntField(default=0)

    class Meta:
        table = "users"

async def main():
    # 2. Ma'lumotlar bazasini ishga tushiring
    db = await Database.init(
        url="sqlite://db.sqlite3",
        modules=modules={"models": ["__main__"]} # Yoki ilovangizning modellar moduli
    )

    # 3. Yangi foydalanuvchi yarating
    user = await User.create(name="Ali Valiyev", email="ali.valiyev@example.com", age=30)
    print(f"Yaratilgan foydalanuvchi: {user.name}, ID: {user.id}")

    # 4. Foydalanuvchini oling
    retrieved_user = await User.get(id=user.id)
    print(f"Olingan foydalanuvchi: {retrieved_user.name}")

    # 5. Foydalanuvchilardan so'rov oling
    young_users = await User.filter(age__lt=40)
    for u in young_users:
        print(f"Topilgan yosh foydalanuvchi: {u.name}")

    # 6. Ulanishlarni yoping
    await db.close()

if __name__ == "__main__":
    asyncio.run(main())
```

## 4. Ma'lumotlar bazasiga ulanish

UniORM ma'lumotlar bazasiga ulanishni osonlashtiradi. `Database` klassi ulanishning hayot siklini boshqaradi.

### `Database.init()`

Bu ulanishni boshlashning tavsiya etilgan usuli. U ma'lumotlar bazasini ishga tushiradi va sxemalarni avtomatik ravishda yaratishi mumkin.

```python
db = await Database.init(
    url="postgres://user:pass@host:5432/dbname",
    modules={"models": ["myapp.models"]}
)
```

**Qo'llab-quvvatlanadigan URL formatlari:**
- **SQLite:** `sqlite://path/to/db.sqlite3`
- **PostgreSQL:** `postgres://user:password@host:port/dbname`
- **MySQL:** `mysql://user:password@host:port/dbname`

## 5. Modellarni aniqlash

Modellar `uniorm.Model`dan meros olish orqali aniqlanadi. Maydonlar klass atributlari sifatida qo'shiladi.

```python
from uniorm import Model, CharField, DateTimeField, ForeignKeyField

class Author(Model):
    name = CharField(max_length=255)

class Book(Model):
    title = CharField(max_length=255)
    author = ForeignKeyField("models.Author", related_name="books")
    published_at = DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```

### Mavjud maydonlar

UniORM turli xil maydon turlarini taqdim etadi:

| Maydon turi       | Ta'rif                                   |
|-------------------|-------------------------------------------|
| `IntField`        | Butun son maydoni.                        |
| `CharField`       | Maksimal uzunlikka ega matn maydoni.      |
| `TextField`       | Uzun matnli kontent uchun maydon.         |
| `BooleanField`    | `True` yoki `False` ni saqlaydi.            |
| `DateField`       | `date` obyektini saqlaydi.                |
| `DateTimeField`   | `datetime` obyektini saqlaydi.            |
| `FloatField`      | O'nli kasr soni.                          |
| `ForeignKeyField` | "Ko'pdan-birga" munosabati.                |
| `ManyToManyField` | "Ko'pdan-ko'pga" munosabati.              |

## 6. CRUD amallari

UniORM yozuvlarni yaratish, o'qish, yangilash va o'chirish uchun sodda, Peewee-ga o'xshash API-ni taqdim etadi.

### Yaratish (Create)

- `Model.create(**kwargs)`: Yangi model nusxasini yaratadi va saqlaydi.
- `Model.get_or_create(defaults={}, **kwargs)`: Obyektni oladi yoki mavjud bo'lmasa, uni yaratadi.

```python
# Yangi foydalanuvchi yaratish
user = await User.create(name="Oysha", email="oysha@example.com")

# Olish yoki yaratish
user, created = await User.get_or_create(
    email="oysha@example.com",
    defaults={"name": "Oysha Soliyeva"}
)
```

### O'qish (Read)

- `Model.get(pk)` yoki `Model.get(**kwargs)`: Bitta nusxani oladi.
- `Model.select()`: Bir nechta obyektlarni olish uchun so'rovlar to'plamini qaytaradi. Bajarish uchun `.all()` bilan zanjir hosil qiling.
- `Model.filter(**kwargs)`: Obyektlarni shartlar asosida filtrlaydi.

```python
# Birlamchi kalit bo'yicha olish
user = await User.get(id=1)

# Barcha foydalanuvchilarni olish
all_users = await User.select().all()

# Foydalanuvchilarni filtrlash
active_users = await User.filter(is_active=True)
```

### Yangilash (Update)

- `instance.save()`: Nusxaga kiritilgan har qanday o'zgarishlarni saqlaydi.
- `instance.update_fields(**kwargs)`: Muayyan maydonlarni yangilaydi va nusxani saqlaydi.
- `Model.bulk_update(objects, fields)`: Bir so'rovda bir nechta obyektni yangilaydi.

```python
user = await User.get(id=1)
user.name = "Alijon Valiyev"
await user.save()

# Yoki ma'lum maydonlarni to'g'ridan-to'g'ri yangilash
await user.update_fields(age=31)
```

### O'chirish (Delete)

- `instance.delete_instance()`: Muayyan obyektni ma'lumotlar bazasidan o'chiradi.
- `Model.delete_many(**kwargs)`: Filtrga mos keladigan bir nechta obyektni o'chiradi.

```python
# Bitta foydalanuvchini o'chirish
user = await User.get(id=1)
await user.delete_instance()

# Barcha nofaol foydalanuvchilarni o'chirish
deleted_count = await User.delete_many(is_active=False)
```

## 7. Migratsiyalar

UniORM ma'lumotlar bazasi migratsiyalari uchun `aerich`dan foydalanadi. Migratsiya jarayonini boshqarish uchun buyruq qatori vositasi (CLI) taqdim etiladi.

**1. Migratsiyalarni ishga tushirish**

Avval migratsiya muhitini ishga tushiring. Bu `migrations` katalogini va konfiguratsiya faylini yaratadi.

```bash
uniorm init --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

Keyin ma'lumotlar bazasini ishga tushiring:

```bash
uniorm init-db --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**2. Migratsiya yaratish**

Modellaringizni o'zgartirganingizda, yangi migratsiya faylini yarating.

```bash
uniorm migrate --name "add_age_to_user" --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**3. Migratsiyalarni qo'llash**

Kutilayotgan migratsiyalarni ma'lumotlar bazangizga qo'llang.

```bash
uniorm upgrade --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**Boshqa buyruqlar:**
- `downgrade`: Migratsiyalarni orqaga qaytaradi.
- `history`: Migratsiyalar tarixini ko'rsatadi.

## 8. Veb-muharrir

UniORM ma'lumotlaringizni ko'rib chiqish, xom SQL so'rovlarini bajarish va sxemangizni ko'rish uchun veb-ga asoslangan muharrirni o'z ichiga oladi.

Muharrirni ishga tushirish uchun uni Python kodingizdan ishga tushirishingiz mumkin:

```python
from uniorm.web_editor import start_editor

if __name__ == "__main__":
    # Bu http://127.0.0.1:5000 manzilida veb-serverni ishga tushiradi
    start_editor()
```

Ishga tushirilgandan so'ng, brauzeringizni oching va taqdim etilgan URL manziliga o'ting. Siz quyidagilarni qila olasiz:
- URL va modellar yo'lini ko'rsatib, ma'lumotlar bazangizga ulanish.
- Barcha jadvallarni va ularning ma'lumotlarini ko'rish.
- So'rov muharririda maxsus SQL so'rovlarini bajarish.
- Xavfsiz uzilish.

---

*UniORMdan foydalanganingiz uchun tashakkur! Umid qilamizki, bu sizning dasturlash jarayoningizni soddalashtiradi.*
'''
