'''
# Документация UniORM

Добро пожаловать в официальную документацию UniORM — мощной и простой в использовании асинхронной ORM для Python, созданной на основе TortoiseORM с API в стиле Peewee.

## 1. Введение

UniORM призван упростить взаимодействие с базами данных в асинхронных приложениях на Python. Он предоставляет интуитивно понятный, похожий на Peewee интерфейс, используя при этом надежность и производительность TortoiseORM.

**Ключевые особенности:**
- **Асинхронность:** Разработан с нуля для `asyncio`.
- **API в стиле Peewee:** Знакомые и простые в использовании методы (`.create()`, `.get()`, `.select()` и т.д.).
- **Поддержка нескольких БД:** Работает с PostgreSQL, MySQL и SQLite.
- **Мощные миграции:** Интегрирован с `aerich` для удобного управления схемой.
- **Веб-редактор:** Поставляется со встроенным веб-интерфейсом для управления вашей базой данных.

## 2. Установка

Установите UniORM с помощью `pip`:

```bash
pip install uniorm
```

Эта единственная команда устанавливает основную библиотеку, зависимости веб-редактора (Flask) и инструмент миграций (aerich).

## 3. Быстрый старт

Вот краткий пример того, как определить модель и выполнить основные операции.

```python
import asyncio
from uniorm import Database, Model, CharField, IntField

# 1. Определите ваши модели
class User(Model):
    name = CharField(max_length=100)
    email = CharField(max_length=255, unique=True)
    age = IntField(default=0)

    class Meta:
        table = "users"

async def main():
    # 2. Инициализируйте базу данных
    db = await Database.init(
        url="sqlite://db.sqlite3",
        modules=modules={"models": ["__main__"]} # Или модуль моделей вашего приложения
    )

    # 3. Создайте нового пользователя
    user = await User.create(name="Иван Иванов", email="ivan.ivanov@example.com", age=30)
    print(f"Создан пользователь: {user.name}, ID: {user.id}")

    # 4. Получите пользователя
    retrieved_user = await User.get(id=user.id)
    print(f"Получен пользователь: {retrieved_user.name}")

    # 5. Выполните запрос к пользователям
    young_users = await User.filter(age__lt=40)
    for u in young_users:
        print(f"Найден молодой пользователь: {u.name}")

    # 6. Закройте соединения
    await db.close()

if __name__ == "__main__":
    asyncio.run(main())
```

## 4. Подключение к базе данных

UniORM упрощает подключение к вашей базе данных. Класс `Database` управляет жизненным циклом соединения.

### `Database.init()`

Это рекомендуемый способ для начала соединения. Он инициализирует базу данных и может автоматически генерировать схемы.

```python
db = await Database.init(
    url="postgres://user:pass@host:5432/dbname",
    modules={"models": ["myapp.models"]}
)
```

**Поддерживаемые форматы URL:**
- **SQLite:** `sqlite://path/to/db.sqlite3`
- **PostgreSQL:** `postgres://user:password@host:port/dbname`
- **MySQL:** `mysql://user:password@host:port/dbname`

## 5. Определение моделей

Модели определяются путем наследования от `uniorm.Model`. Поля добавляются как атрибуты класса.

```python
from uniorm import Model, CharField, DateTimeField, ForeignKeyField

class Author(Model):
    name = CharField(max_length=255)

class Book(Model):
    title = CharField(max_length=255)
    author = ForeignKeyField("models.Author", related_name="books")
    published_at = DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```

### Доступные поля

UniORM предоставляет различные типы полей:

| Тип поля          | Описание                                  |
|-------------------|-------------------------------------------|
| `IntField`        | Целочисленное поле.                       |
| `CharField`       | Строковое поле с максимальной длиной.     |
| `TextField`       | Поле для длинного текстового содержимого. |
| `BooleanField`    | Хранит `True` или `False`.                |
| `DateField`       | Хранит объект `date`.                     |
| `DateTimeField`   | Хранит объект `datetime`.                 |
| `FloatField`      | Число с плавающей точкой.                 |
| `ForeignKeyField` | Отношение "многие-к-одному".              |
| `ManyToManyField` | Отношение "многие-ко-многим".             |

## 6. Операции CRUD

UniORM предоставляет простой, похожий на Peewee API для создания, чтения, обновления и удаления записей.

### Создание (Create)

- `Model.create(**kwargs)`: Создает и сохраняет новый экземпляр модели.
- `Model.get_or_create(defaults={}, **kwargs)`: Получает объект или создает его, если он не существует.

```python
# Создать нового пользователя
user = await User.create(name="Анна", email="anna@example.com")

# Получить или создать
user, created = await User.get_or_create(
    email="anna@example.com",
    defaults={"name": "Анна Петрова"}
)
```

### Чтение (Read)

- `Model.get(pk)` или `Model.get(**kwargs)`: Получает один экземпляр.
- `Model.select()`: Возвращает набор запросов для получения нескольких объектов. Используйте `.all()` для выполнения.
- `Model.filter(**kwargs)`: Фильтрует объекты по условиям.

```python
# Получить по первичному ключу
user = await User.get(id=1)

# Получить всех пользователей
all_users = await User.select().all()

# Отфильтровать пользователей
active_users = await User.filter(is_active=True)
```

### Обновление (Update)

- `instance.save()`: Сохраняет любые изменения, внесенные в экземпляр.
- `instance.update_fields(**kwargs)`: Обновляет определенные поля и сохраняет экземпляр.
- `Model.bulk_update(objects, fields)`: Обновляет несколько объектов одним запросом.

```python
user = await User.get(id=1)
user.name = "Иван Смирнов"
await user.save()

# Или обновить определенные поля напрямую
await user.update_fields(age=31)
```

### Удаление (Delete)

- `instance.delete_instance()`: Удаляет конкретный объект из базы данных.
- `Model.delete_many(**kwargs)`: Удаляет несколько объектов, соответствующих фильтру.

```python
# Удалить одного пользователя
user = await User.get(id=1)
await user.delete_instance()

# Удалить всех неактивных пользователей
deleted_count = await User.delete_many(is_active=False)
```

## 7. Миграции

UniORM использует `aerich` для миграций базы данных. Для управления процессом миграции предоставляется инструмент командной строки (CLI).

**1. Инициализация миграций**

Сначала инициализируйте среду миграций. Это создаст каталог `migrations` и файл конфигурации.

```bash
uniorm init --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

Затем инициализируйте базу данных:

```bash
uniorm init-db --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**2. Создание миграции**

Когда вы изменяете свои модели, создайте новый файл миграции.

```bash
uniorm migrate --name "add_age_to_user" --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**3. Применение миграций**

Примените ожидающие миграции к вашей базе данных.

```bash
uniorm upgrade --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**Другие команды:**
- `downgrade`: Откатывает миграции.
- `history`: Показывает историю миграций.

## 8. Веб-редактор

UniORM включает в себя веб-редактор для просмотра ваших данных, выполнения необработанных SQL-запросов и просмотра вашей схемы.

Чтобы запустить редактор, вы можете запустить его из своего кода Python:

```python
from uniorm.web_editor import start_editor

if __name__ == "__main__":
    # Это запустит веб-сервер на http://127.0.0.1:5000
    start_editor()
```

После запуска откройте браузер и перейдите по указанному URL. Вы сможете:
- Подключаться к вашей базе данных, указав URL и путь к моделям.
- Просматривать все таблицы и их данные.
- Выполнять пользовательские SQL-запросы в редакторе запросов.
- Безопасно отключаться.

---

*Спасибо за использование UniORM! Мы надеемся, что это упростит ваш процесс разработки.*
'''
