'''
# UniORM Documentation

Welcome to the official documentation for UniORM, a powerful and easy-to-use asynchronous ORM for Python, built on top of TortoiseORM with a Peewee-style API.

## 1. Introduction

UniORM aims to simplify database interactions in asynchronous Python applications. It provides an intuitive, Peewee-like interface while leveraging the robustness and performance of TortoiseORM. 

**Key Features:**
- **Asynchronous:** Built from the ground up for `asyncio`.
- **Peewee-like API:** Familiar and easy-to-use methods (`.create()`, `.get()`, `.select()`, etc.).
- **Multi-database Support:** Works with PostgreSQL, MySQL, and SQLite.
- **Powerful Migrations:** Integrated with `aerich` for smooth schema management.
- **Web Editor:** Comes with a built-in web interface to manage your database.

## 2. Installation

Install UniORM using `pip`:

```bash
pip install uniorm
```

This single command installs the core library, the web editor dependencies (Flask), and the migration tool (aerich).

## 3. Quick Start

Here's a quick example of how to define a model and perform basic operations.

```python
import asyncio
from uniorm import Database, Model, CharField, IntField

# 1. Define your models
class User(Model):
    name = CharField(max_length=100)
    email = CharField(max_length=255, unique=True)
    age = IntField(default=0)

    class Meta:
        table = "users"

async def main():
    # 2. Initialize the database
    db = await Database.init(
        url="sqlite://db.sqlite3",
        modules={"models": ["__main__"]} # Or your app's models module
    )

    # 3. Create a new user
    user = await User.create(name="John Doe", email="john.doe@example.com", age=30)
    print(f"Created User: {user.name}, ID: {user.id}")

    # 4. Retrieve a user
    retrieved_user = await User.get(id=user.id)
    print(f"Retrieved User: {retrieved_user.name}")

    # 5. Query users
    young_users = await User.filter(age__lt=40)
    for u in young_users:
        print(f"Found young user: {u.name}")

    # 6. Close connections
    await db.close()

if __name__ == "__main__":
    asyncio.run(main())
```

## 4. Database Connection

UniORM makes it easy to connect to your database. The `Database` class manages the connection lifecycle.

### `Database.init()`

This is the recommended way to start a connection. It initializes the database and can automatically generate schemas.

```python
db = await Database.init(
    url="postgres://user:pass@host:5432/dbname",
    modules={"models": ["myapp.models"]}
)
```

**Supported URL formats:**
- **SQLite:** `sqlite://path/to/db.sqlite3`
- **PostgreSQL:** `postgres://user:password@host:port/dbname`
- **MySQL:** `mysql://user:password@host:port/dbname`

## 5. Defining Models

Models are defined by inheriting from `uniorm.Model`. Fields are added as class attributes.

```python
from uniorm import Model, CharField, DateTimeField, ForeignKeyField

class Author(Model):
    name = CharField(max_length=255)

class Book(Model):
    title = CharField(max_length=255)
    author = ForeignKeyField("models.Author", related_name="books")
    published_at = DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```

### Available Fields

UniORM provides a variety of field types:

| Field Type        | Description                               |
|-------------------|-------------------------------------------|
| `IntField`        | Integer field.                            |
| `CharField`       | String field with a max length.           |
| `TextField`       | Field for long text content.              |
| `BooleanField`    | Stores `True` or `False`.                 |
| `DateField`       | Stores a `date` object.                   |
| `DateTimeField`   | Stores a `datetime` object.               |
| `FloatField`      | Floating-point number.                    |
| `ForeignKeyField` | A many-to-one relationship.               |
| `ManyToManyField` | A many-to-many relationship.              |

## 6. CRUD Operations

UniORM provides a simple, Peewee-like API for creating, reading, updating, and deleting records.

### Create

- `Model.create(**kwargs)`: Creates and saves a new model instance.
- `Model.get_or_create(defaults={}, **kwargs)`: Retrieves an object or creates it if it doesn't exist.

```python
# Create a new user
user = await User.create(name="Jane", email="jane@example.com")

# Get or create
user, created = await User.get_or_create(
    email="jane@example.com",
    defaults={"name": "Jane Doe"}
)
```

### Read

- `Model.get(pk)` or `Model.get(**kwargs)`: Retrieves a single instance.
- `Model.select()`: Returns a query set to fetch multiple objects. Chain with `.all()` to execute.
- `Model.filter(**kwargs)`: Filters objects based on conditions.

```python
# Get by primary key
user = await User.get(id=1)

# Get all users
all_users = await User.select().all()

# Filter users
active_users = await User.filter(is_active=True)
```

### Update

- `instance.save()`: Saves any changes made to the instance.
- `instance.update_fields(**kwargs)`: Updates specific fields and saves the instance.
- `Model.bulk_update(objects, fields)`: Updates multiple objects in one query.

```python
user = await User.get(id=1)
user.name = "John Smith"
await user.save()

# Or update specific fields directly
await user.update_fields(age=31)
```

### Delete

- `instance.delete_instance()`: Deletes a specific object from the database.
- `Model.delete_many(**kwargs)`: Deletes multiple objects matching the filter.

```python
# Delete a single user
user = await User.get(id=1)
await user.delete_instance()

# Delete all inactive users
deleted_count = await User.delete_many(is_active=False)
```

## 7. Migrations

UniORM uses `aerich` for database migrations. A CLI tool is provided to manage the migration process.

**1. Initialize Migrations**

First, initialize the migration environment. This creates a `migrations` directory and a configuration file.

```bash
uniorm init --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

Then, initialize the database:

```bash
uniorm init-db --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**2. Create a Migration**

When you change your models, create a new migration file.

```bash
uniorm migrate --name "add_age_to_user" --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**3. Apply Migrations**

Apply the pending migrations to your database.

```bash
uniorm upgrade --db-url "sqlite://db.sqlite3" --models "myapp.models"
```

**Other Commands:**
- `downgrade`: Reverts migrations.
- `history`: Shows the migration history.

## 8. Web Editor

UniORM includes a web-based editor to browse your data, run raw SQL queries, and view your schema.

To start the editor, you can run it from your Python code:

```python
from uniorm.web_editor import start_editor

if __name__ == "__main__":
    # This will start a web server on http://127.0.0.1:5000
    start_editor()
```

Once started, open your browser and navigate to the provided URL. You will be able to:
- Connect to your database by providing the URL and models path.
- View all tables and their data.
- Execute custom SQL queries in the query editor.
- Disconnect safely.

---

*Thank you for using UniORM! We hope it simplifies your development process.*
'''
