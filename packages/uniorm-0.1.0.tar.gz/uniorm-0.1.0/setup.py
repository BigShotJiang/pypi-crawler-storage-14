"""
UniORM Setup Configuration
===========================

Setup script for PyPI package distribution.
Скрипт установки для распространения пакета PyPI.
PyPI paketi tarqatish uchun o'rnatish skripti.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file / Чтение содержимого README / README ni o'qish
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name="uniorm",
    version="0.1.0",
    author="UniORM Team",
    author_email="contact@uniorm.dev",
    description="Universal async ORM for Python with Peewee-style syntax, built on TortoiseORM",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/uniorm",
    project_urls={
        "Bug Tracker": "https://github.com/yourusername/uniorm/issues",
        "Documentation": "https://uniorm.dev/docs",
        "Source Code": "https://github.com/yourusername/uniorm",
    },
    packages=find_packages(exclude=["tests", "tests.*", "docs", "landing_page"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Database",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: AsyncIO",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "tortoise-orm>=0.20.0",
        "aerich>=0.7.2",
        "flask>=2.3.0",
        "asyncio>=3.4.3",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
        "postgresql": ["asyncpg>=0.28.0"],
        "mysql": ["aiomysql>=0.2.0"],
    },
    entry_points={
        "console_scripts": [
            "uniorm=uniorm.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "uniorm.web_editor": [
            "templates/*.html",
            "static/css/*.css",
            "static/js/*.js",
        ],
    },
    keywords=[
        "orm",
        "async",
        "asyncio",
        "database",
        "tortoise",
        "peewee",
        "postgresql",
        "mysql",
        "sqlite",
        "migrations",
    ],
    zip_safe=False,
)
