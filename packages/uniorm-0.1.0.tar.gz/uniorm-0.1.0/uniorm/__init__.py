"""
UniORM - Universal ORM Library
===============================

A powerful, easy-to-use async ORM library based on TortoiseORM with Peewee-style syntax.
Supports SQLite, MySQL, and PostgreSQL with full CRUD operations and migrations.

Универсальная библиотека ORM
============================

Мощная и простая в использовании асинхронная библиотека ORM на основе TortoiseORM 
с синтаксисом в стиле Peewee. Поддерживает SQLite, MySQL и PostgreSQL с полными 
операциями CRUD и миграциями.

Universal ORM kutubxonasi
=========================

TortoiseORM asosida yaratilgan, Peewee uslubidagi sintaksisga ega, kuchli va 
foydalanish uchun oson asinxron ORM kutubxonasi. SQLite, MySQL va PostgreSQL 
ma'lumotlar bazalarini qo'llab-quvvatlaydi, to'liq CRUD operatsiyalari va 
migratsiyalar bilan.
"""

__version__ = "0.1.0"
__author__ = "UniORM Team"
__license__ = "MIT"

from uniorm.core.model import Model
from uniorm.core.fields import (
    IntField,
    CharField,
    TextField,
    BooleanField,
    DateField,
    DateTimeField,
    FloatField,
    ForeignKeyField,
    ManyToManyField,
)
from uniorm.core.database import Database
from uniorm.core.query import Q

__all__ = [
    "Model",
    "Database",
    "IntField",
    "CharField",
    "TextField",
    "BooleanField",
    "DateField",
    "DateTimeField",
    "FloatField",
    "ForeignKeyField",
    "ManyToManyField",
    "Q",
]
