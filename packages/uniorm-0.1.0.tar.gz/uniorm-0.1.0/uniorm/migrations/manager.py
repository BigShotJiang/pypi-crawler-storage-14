"""
Migration Manager / Менеджер миграций / Migratsiya menejeri
============================================================

Manages database migrations using Aerich (TortoiseORM migration tool).
Управляет миграциями базы данных с использованием Aerich.
Aerich yordamida ma'lumotlar bazasi migratsiyalarini boshqaradi.
"""

import os
import asyncio
import subprocess
import logging
from pathlib import Path
from typing import Optional, Dict, List
import json

logger = logging.getLogger(__name__)


class MigrationManager:
    """
    Migration manager for database schema changes / Менеджер миграций для изменений схемы БД / Ma'lumotlar bazasi sxemasi o'zgarishlari uchun migratsiya menejeri
    """
    
    def __init__(self, project_dir: str, db_url: str, models_path: str):
        """
        Initialize migration manager / Инициализация менеджера миграций / Migratsiya menejerini boshlash
        
        Args:
            project_dir: Project directory / Директория проекта / Loyiha katalogi
            db_url: Database URL / URL базы данных / Ma'lumotlar bazasi URL
            models_path: Path to models module / Путь к модулю моделей / Modellar moduli yo'li
        
        Example / Пример / Misol:
            manager = MigrationManager(
                project_dir="/path/to/project",
                db_url="sqlite://db.sqlite3",
                models_path="myapp.models"
            )
        """
        self.project_dir = Path(project_dir)
        self.db_url = db_url
        self.models_path = models_path
        self.migrations_dir = self.project_dir / "migrations"
        self.config_file = self.project_dir / "pyproject.toml"
    
    def _create_config(self) -> None:
        """
        Create Aerich configuration / Создать конфигурацию Aerich / Aerich konfiguratsiyasini yaratish
        """
        config_content = f"""[tool.aerich]
tortoise_orm = "uniorm_config.TORTOISE_ORM"
location = "./migrations"
src_folder = "./."

[tool.aerich.models]
models = "{self.models_path}"
"""
        
        # Create config file / Создать файл конфигурации / Konfiguratsiya faylini yaratish
        with open(self.config_file, 'w', encoding='utf-8') as f:
            f.write(config_content)
        
        # Create ORM config file / Создать файл конфигурации ORM / ORM konfiguratsiya faylini yaratish
        orm_config = f"""
TORTOISE_ORM = {{
    "connections": {{"default": "{self.db_url}"}},
    "apps": {{
        "models": {{
            "models": ["{self.models_path}", "aerich.models"],
            "default_connection": "default",
        }},
    }},
}}
"""
        
        config_py_file = self.project_dir / "uniorm_config.py"
        with open(config_py_file, 'w', encoding='utf-8') as f:
            f.write(orm_config)
        
        logger.info("Configuration created / Конфигурация создана / Konfiguratsiya yaratildi")
    
    def init(self) -> bool:
        """
        Initialize migrations / Инициализировать миграции / Migratsiyalarni boshlash
        
        Returns: Success status / Статус успеха / Muvaffaqiyat holati
        
        Example / Пример / Misol:
            manager.init()
        """
        try:
            # Create configuration / Создать конфигурацию / Konfiguratsiya yaratish
            self._create_config()
            
            # Initialize Aerich / Инициализировать Aerich / Aerich ni boshlash
            result = subprocess.run(
                ["aerich", "init", "-t", "uniorm_config.TORTOISE_ORM"],
                cwd=self.project_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                logger.info("Migrations initialized / Миграции инициализированы / Migratsiyalar boshlandi")
                return True
            else:
                logger.error(f"Failed to initialize migrations / Не удалось инициализировать / Boshlash amalga oshmadi: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"Error initializing migrations / Ошибка инициализации / Boshlashda xatolik: {e}")
            return False
    
    def init_db(self) -> bool:
        """
        Initialize database / Инициализировать базу данных / Ma'lumotlar bazasini boshlash
        
        Returns: Success status / Статус успеха / Muvaffaqiyat holati
        
        Example / Пример / Misol:
            manager.init_db()
        """
        try:
            result = subprocess.run(
                ["aerich", "init-db"],
                cwd=self.project_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                logger.info("Database initialized / База данных инициализирована / Ma'lumotlar bazasi boshlandi")
                return True
            else:
                logger.error(f"Failed to initialize database / Не удалось инициализировать БД / Ma'lumotlar bazasini boshlash amalga oshmadi: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"Error initializing database / Ошибка инициализации БД / Ma'lumotlar bazasini boshlashda xatolik: {e}")
            return False
    
    def make_migration(self, name: Optional[str] = None) -> bool:
        """
        Create a new migration / Создать новую миграцию / Yangi migratsiya yaratish
        
        Args:
            name: Migration name / Имя миграции / Migratsiya nomi
        
        Returns: Success status / Статус успеха / Muvaffaqiyat holati
        
        Example / Пример / Misol:
            manager.make_migration("add_user_table")
        """
        try:
            cmd = ["aerich", "migrate"]
            if name:
                cmd.extend(["--name", name])
            
            result = subprocess.run(
                cmd,
                cwd=self.project_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                logger.info(f"Migration created / Миграция создана / Migratsiya yaratildi: {name or 'auto'}")
                return True
            else:
                logger.error(f"Failed to create migration / Не удалось создать миграцию / Migratsiya yaratish amalga oshmadi: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"Error creating migration / Ошибка создания миграции / Migratsiya yaratishda xatolik: {e}")
            return False
    
    def migrate(self) -> bool:
        """
        Apply migrations / Применить миграции / Migratsiyalarni qo'llash
        
        Returns: Success status / Статус успеха / Muvaffaqiyat holati
        
        Example / Пример / Misol:
            manager.migrate()
        """
        try:
            result = subprocess.run(
                ["aerich", "upgrade"],
                cwd=self.project_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                logger.info("Migrations applied / Миграции применены / Migratsiyalar qo'llandi")
                return True
            else:
                logger.error(f"Failed to apply migrations / Не удалось применить миграции / Migratsiyalarni qo'llash amalga oshmadi: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"Error applying migrations / Ошибка применения миграций / Migratsiyalarni qo'llashda xatolik: {e}")
            return False
    
    def downgrade(self, version: int = -1) -> bool:
        """
        Rollback migrations / Откатить миграции / Migratsiyalarni qaytarish
        
        Args:
            version: Version to downgrade to / Версия для отката / Qaytariladigan versiya
        
        Returns: Success status / Статус успеха / Muvaffaqiyat holati
        
        Example / Пример / Misol:
            manager.downgrade()  # Rollback last migration / Откатить последнюю / Oxirgi migratsiyani qaytarish
        """
        try:
            result = subprocess.run(
                ["aerich", "downgrade", str(version)],
                cwd=self.project_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                logger.info(f"Migration rolled back / Миграция откачена / Migratsiya qaytarildi: {version}")
                return True
            else:
                logger.error(f"Failed to rollback migration / Не удалось откатить / Qaytarish amalga oshmadi: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"Error rolling back migration / Ошибка отката / Qaytarishda xatolik: {e}")
            return False
    
    def history(self) -> Optional[List[Dict]]:
        """
        Get migration history / Получить историю миграций / Migratsiyalar tarixini olish
        
        Returns: List of migrations / Список миграций / Migratsiyalar ro'yxati
        
        Example / Пример / Misol:
            history = manager.history()
        """
        try:
            result = subprocess.run(
                ["aerich", "history"],
                cwd=self.project_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                logger.info("Migration history retrieved / История получена / Tarix olindi")
                return result.stdout
            else:
                logger.error(f"Failed to get history / Не удалось получить историю / Tarixni olish amalga oshmadi: {result.stderr}")
                return None
        except Exception as e:
            logger.error(f"Error getting history / Ошибка получения истории / Tarixni olishda xatolik: {e}")
            return None


# Export / Экспорт / Eksport
__all__ = ['MigrationManager']
