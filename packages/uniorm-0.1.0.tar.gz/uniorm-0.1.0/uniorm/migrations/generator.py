"""
Migration Generator / Генератор миграций / Migratsiya generatori
=================================================================

Helper for generating migration files.
Помощник для генерации файлов миграций.
Migratsiya fayllarini yaratish uchun yordamchi.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class MigrationGenerator:
    """
    Generate migration files / Генерация файлов миграций / Migratsiya fayllarini yaratish
    """
    
    @staticmethod
    def generate_migration_file(
        migrations_dir: str,
        name: str,
        up_sql: str,
        down_sql: str
    ) -> Optional[str]:
        """
        Generate a migration file / Создать файл миграции / Migratsiya faylini yaratish
        
        Args:
            migrations_dir: Migrations directory / Директория миграций / Migratsiyalar katalogi
            name: Migration name / Имя миграции / Migratsiya nomi
            up_sql: SQL for upgrade / SQL для обновления / Yangilash uchun SQL
            down_sql: SQL for downgrade / SQL для отката / Qaytarish uchun SQL
        
        Returns: Path to created file / Путь к созданному файлу / Yaratilgan fayl yo'li
        
        Example / Пример / Misol:
            generator = MigrationGenerator()
            path = generator.generate_migration_file(
                migrations_dir="./migrations",
                name="add_users_table",
                up_sql="CREATE TABLE users (...)",
                down_sql="DROP TABLE users"
            )
        """
        try:
            # Create migrations directory / Создать директорию / Katalog yaratish
            Path(migrations_dir).mkdir(parents=True, exist_ok=True)
            
            # Generate timestamp / Создать временную метку / Vaqt belgisini yaratish
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{timestamp}_{name}.sql"
            filepath = Path(migrations_dir) / filename
            
            # Create migration content / Создать содержимое / Tarkibni yaratish
            content = f"""-- Migration: {name}
-- Created: {datetime.now().isoformat()}
-- Миграция: {name}
-- Создано: {datetime.now().isoformat()}
-- Migratsiya: {name}
-- Yaratildi: {datetime.now().isoformat()}

-- Upgrade / Обновление / Yangilash
-- upgrade --
{up_sql}

-- Downgrade / Откат / Qaytarish
-- downgrade --
{down_sql}
"""
            
            # Write file / Записать файл / Faylni yozish
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            logger.info(f"Migration file created / Файл миграции создан / Migratsiya fayli yaratildi: {filepath}")
            return str(filepath)
        
        except Exception as e:
            logger.error(f"Failed to generate migration file / Не удалось создать файл / Fayl yaratish amalga oshmadi: {e}")
            return None
    
    @staticmethod
    def generate_model_migration(
        migrations_dir: str,
        model_name: str,
        fields: dict
    ) -> Optional[str]:
        """
        Generate migration for a new model / Создать миграцию для новой модели / Yangi model uchun migratsiya yaratish
        
        Args:
            migrations_dir: Migrations directory / Директория миграций / Migratsiyalar katalogi
            model_name: Model name / Имя модели / Model nomi
            fields: Field definitions / Определения полей / Maydon ta'riflari
        
        Returns: Path to created file / Путь к созданному файлу / Yaratilgan fayl yo'li
        
        Example / Пример / Misol:
            generator = MigrationGenerator()
            path = generator.generate_model_migration(
                migrations_dir="./migrations",
                model_name="User",
                fields={
                    "id": "INTEGER PRIMARY KEY",
                    "name": "VARCHAR(100)",
                    "email": "VARCHAR(255) UNIQUE"
                }
            )
        """
        try:
            # Generate CREATE TABLE SQL / Создать SQL CREATE TABLE / CREATE TABLE SQL yaratish
            field_definitions = ",\n    ".join([f"{name} {definition}" for name, definition in fields.items()])
            
            up_sql = f"""CREATE TABLE {model_name.lower()}s (
    {field_definitions}
);"""
            
            down_sql = f"DROP TABLE {model_name.lower()}s;"
            
            return MigrationGenerator.generate_migration_file(
                migrations_dir=migrations_dir,
                name=f"create_{model_name.lower()}s_table",
                up_sql=up_sql,
                down_sql=down_sql
            )
        
        except Exception as e:
            logger.error(f"Failed to generate model migration / Не удалось создать миграцию модели / Model migratsiyasini yaratish amalga oshmadi: {e}")
            return None


# Export / Экспорт / Eksport
__all__ = ['MigrationGenerator']
