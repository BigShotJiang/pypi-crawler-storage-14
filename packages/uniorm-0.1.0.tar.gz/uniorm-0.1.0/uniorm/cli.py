#!/usr/bin/env python3
"""
UniORM CLI Tool / Инструмент командной строки UniORM / UniORM buyruq qatori vositasi
====================================================================================

Command-line interface for UniORM operations.
Интерфейс командной строки для операций UniORM.
UniORM operatsiyalari uchun buyruq qatori interfeysi.
"""

import sys
import argparse
import asyncio
from pathlib import Path
from uniorm.migrations.manager import MigrationManager


def main():
    """
    Main CLI entry point / Главная точка входа CLI / Asosiy CLI kirish nuqtasi
    """
    parser = argparse.ArgumentParser(
        description='UniORM CLI - Database migration and management tool'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands / Доступные команды / Mavjud buyruqlar')
    
    # Init command / Команда инициализации / Boshlash buyrug'i
    init_parser = subparsers.add_parser('init', help='Initialize migrations / Инициализировать миграции / Migratsiyalarni boshlash')
    init_parser.add_argument('--db-url', required=True, help='Database URL / URL базы данных / Ma\'lumotlar bazasi URL')
    init_parser.add_argument('--models', required=True, help='Models module path / Путь к модулю моделей / Modellar moduli yo\'li')
    init_parser.add_argument('--dir', default='.', help='Project directory / Директория проекта / Loyiha katalogi')
    
    # Init-db command / Команда инициализации БД / Ma'lumotlar bazasini boshlash buyrug'i
    initdb_parser = subparsers.add_parser('init-db', help='Initialize database / Инициализировать БД / Ma\'lumotlar bazasini boshlash')
    initdb_parser.add_argument('--db-url', required=True, help='Database URL')
    initdb_parser.add_argument('--models', required=True, help='Models module path')
    initdb_parser.add_argument('--dir', default='.', help='Project directory')
    
    # Migrate command / Команда миграции / Migratsiya buyrug'i
    migrate_parser = subparsers.add_parser('migrate', help='Create migration / Создать миграцию / Migratsiya yaratish')
    migrate_parser.add_argument('--name', help='Migration name / Имя миграции / Migratsiya nomi')
    migrate_parser.add_argument('--db-url', required=True, help='Database URL')
    migrate_parser.add_argument('--models', required=True, help='Models module path')
    migrate_parser.add_argument('--dir', default='.', help='Project directory')
    
    # Upgrade command / Команда обновления / Yangilash buyrug'i
    upgrade_parser = subparsers.add_parser('upgrade', help='Apply migrations / Применить миграции / Migratsiyalarni qo\'llash')
    upgrade_parser.add_argument('--db-url', required=True, help='Database URL')
    upgrade_parser.add_argument('--models', required=True, help='Models module path')
    upgrade_parser.add_argument('--dir', default='.', help='Project directory')
    
    # Downgrade command / Команда отката / Qaytarish buyrug'i
    downgrade_parser = subparsers.add_parser('downgrade', help='Rollback migration / Откатить миграцию / Migratsiyani qaytarish')
    downgrade_parser.add_argument('--version', type=int, default=-1, help='Version to downgrade to / Версия для отката / Qaytariladigan versiya')
    downgrade_parser.add_argument('--db-url', required=True, help='Database URL')
    downgrade_parser.add_argument('--models', required=True, help='Models module path')
    downgrade_parser.add_argument('--dir', default='.', help='Project directory')
    
    # History command / Команда истории / Tarix buyrug'i
    history_parser = subparsers.add_parser('history', help='Show migration history / Показать историю / Tarixni ko\'rsatish')
    history_parser.add_argument('--db-url', required=True, help='Database URL')
    history_parser.add_argument('--models', required=True, help='Models module path')
    history_parser.add_argument('--dir', default='.', help='Project directory')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Create migration manager / Создать менеджер миграций / Migratsiya menejerini yaratish
    manager = MigrationManager(
        project_dir=args.dir,
        db_url=args.db_url,
        models_path=args.models
    )
    
    # Execute command / Выполнить команду / Buyruqni bajarish
    if args.command == 'init':
        success = manager.init()
        if success:
            print("✓ Migrations initialized successfully / Миграции инициализированы / Migratsiyalar muvaffaqiyatli boshlandi")
        else:
            print("✗ Failed to initialize migrations / Не удалось инициализировать / Boshlash amalga oshmadi")
            sys.exit(1)
    
    elif args.command == 'init-db':
        success = manager.init_db()
        if success:
            print("✓ Database initialized successfully / База данных инициализирована / Ma'lumotlar bazasi muvaffaqiyatli boshlandi")
        else:
            print("✗ Failed to initialize database / Не удалось инициализировать БД / Ma'lumotlar bazasini boshlash amalga oshmadi")
            sys.exit(1)
    
    elif args.command == 'migrate':
        success = manager.make_migration(args.name)
        if success:
            print(f"✓ Migration created: {args.name or 'auto'} / Миграция создана / Migratsiya yaratildi")
        else:
            print("✗ Failed to create migration / Не удалось создать миграцию / Migratsiya yaratish amalga oshmadi")
            sys.exit(1)
    
    elif args.command == 'upgrade':
        success = manager.migrate()
        if success:
            print("✓ Migrations applied successfully / Миграции применены / Migratsiyalar muvaffaqiyatli qo'llandi")
        else:
            print("✗ Failed to apply migrations / Не удалось применить / Qo'llash amalga oshmadi")
            sys.exit(1)
    
    elif args.command == 'downgrade':
        success = manager.downgrade(args.version)
        if success:
            print(f"✓ Migration rolled back to version {args.version} / Откачено / Qaytarildi")
        else:
            print("✗ Failed to rollback migration / Не удалось откатить / Qaytarish amalga oshmadi")
            sys.exit(1)
    
    elif args.command == 'history':
        history = manager.history()
        if history:
            print("Migration History / История миграций / Migratsiyalar tarixi:")
            print(history)
        else:
            print("✗ Failed to get history / Не удалось получить историю / Tarixni olish amalga oshmadi")
            sys.exit(1)


if __name__ == '__main__':
    main()
