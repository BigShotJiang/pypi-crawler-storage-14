"""
Query Helpers / Помощники запросов / So'rov yordamchilari
==========================================================

This module provides query helpers like Q objects for complex queries.
Этот модуль предоставляет помощники запросов, такие как объекты Q для сложных запросов.
Ushbu modul murakkab so'rovlar uchun Q obyektlari kabi yordamchilarni taqdim etadi.
"""

from tortoise.queryset import Q as TortoiseQ


class Q(TortoiseQ):
    """
    Query object for complex queries / Объект запроса для сложных запросов / Murakkab so'rovlar uchun so'rov obyekti
    
    Allows combining filters with AND, OR, NOT operations.
    Позволяет комбинировать фильтры с операциями AND, OR, NOT.
    AND, OR, NOT operatsiyalari bilan filtrlarni birlashtirish imkonini beradi.
    
    Example / Пример / Misol:
        # OR condition / ИЛИ условие / YOKI shart
        users = await User.filter(Q(age__gte=18) | Q(is_verified=True))
        
        # AND condition / И условие / VA shart
        users = await User.filter(Q(age__gte=18) & Q(is_active=True))
        
        # NOT condition / НЕ условие / EMAS shart
        users = await User.filter(~Q(is_deleted=True))
        
        # Complex combinations / Сложные комбинации / Murakkab kombinatsiyalar
        users = await User.filter(
            (Q(age__gte=18) & Q(is_active=True)) | Q(is_admin=True)
        )
    """
    pass


# Export / Экспорт / Eksport
__all__ = ['Q']
