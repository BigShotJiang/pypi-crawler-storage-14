"""
Database Connection / Подключение к базе данных / Ma'lumotlar bazasiga ulanish
===============================================================================

This module handles database connections and initialization.
Этот модуль обрабатывает подключения к базе данных и инициализацию.
Ushbu modul ma'lumotlar bazasiga ulanishni va ishga tushirishni boshqaradi.
"""

from tortoise import Tortoise
from typing import List, Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


class Database:
    """
    Database connection manager / Менеджер подключения к БД / Ma'lumotlar bazasi ulanish menejeri
    
    Supports SQLite, MySQL, PostgreSQL
    Поддерживает SQLite, MySQL, PostgreSQL
    SQLite, MySQL, PostgreSQL ni qo'llab-quvvatlaydi
    """
    
    def __init__(self, url: str, modules: Optional[Dict[str, List[str]]] = None):
        """
        Initialize database connection / Инициализация подключения / Ulanishni boshlash
        
        Args:
            url: Database URL / URL базы данных / Ma'lumotlar bazasi URL manzili
                Examples / Примеры / Misollar:
                - SQLite: "sqlite://db.sqlite3"
                - MySQL: "mysql://user:password@localhost:3306/dbname"
                - PostgreSQL: "postgres://user:password@localhost:5432/dbname"
            
            modules: Model modules / Модули моделей / Model modullari
                Example / Пример / Misol:
                {"models": ["myapp.models"]}
        """
        self.url = url
        self.modules = modules or {"models": []}
        self._initialized = False
    
    async def connect(self):
        """
        Connect to database / Подключиться к базе данных / Ma'lumotlar bazasiga ulanish
        """
        if self._initialized:
            logger.warning("Database already initialized / База данных уже инициализирована / Ma'lumotlar bazasi allaqachon ishga tushirilgan")
            return
        
        try:
            await Tortoise.init(
                db_url=self.url,
                modules=self.modules
            )
            self._initialized = True
            logger.info(f"Connected to database: {self.url} / Подключено к базе данных / Ma'lumotlar bazasiga ulandi")
        except Exception as e:
            logger.error(f"Failed to connect to database / Не удалось подключиться / Ulanish amalga oshmadi: {e}")
            raise
    
    async def generate_schemas(self, safe: bool = True):
        """
        Generate database schemas / Создать схемы базы данных / Ma'lumotlar bazasi sxemalarini yaratish
        
        Args:
            safe: Don't drop existing tables / Не удалять существующие таблицы / Mavjud jadvallarni o'chirmaslik
        """
        try:
            await Tortoise.generate_schemas(safe=safe)
            logger.info("Database schemas generated / Схемы базы данных созданы / Ma'lumotlar bazasi sxemalari yaratildi")
        except Exception as e:
            logger.error(f"Failed to generate schemas / Не удалось создать схемы / Sxemalarni yaratish amalga oshmadi: {e}")
            raise
    
    async def close(self):
        """
        Close database connection / Закрыть подключение / Ulanishni yopish
        """
        if not self._initialized:
            return
        
        try:
            await Tortoise.close_connections()
            self._initialized = False
            logger.info("Database connection closed / Подключение закрыто / Ulanish yopildi")
        except Exception as e:
            logger.error(f"Failed to close connection / Не удалось закрыть подключение / Ulanishni yopish amalga oshmadi: {e}")
            raise
    
    @staticmethod
    async def init(
        url: str,
        modules: Optional[Dict[str, List[str]]] = None,
        generate_schemas: bool = True,
        safe: bool = True
    ):
        """
        Quick initialization / Быстрая инициализация / Tez ishga tushirish
        
        Args:
            url: Database URL / URL базы данных / Ma'lumotlar bazasi URL
            modules: Model modules / Модули моделей / Model modullari
            generate_schemas: Auto-generate schemas / Автоматически создать схемы / Sxemalarni avtomatik yaratish
            safe: Safe mode for schema generation / Безопасный режим / Xavfsiz rejim
        
        Example / Пример / Misol:
            await Database.init(
                url="sqlite://db.sqlite3",
                modules={"models": ["myapp.models"]}
            )
        """
        db = Database(url, modules)
        await db.connect()
        
        if generate_schemas:
            await db.generate_schemas(safe=safe)
        
        return db


# Export / Экспорт / Eksport
__all__ = ['Database']
