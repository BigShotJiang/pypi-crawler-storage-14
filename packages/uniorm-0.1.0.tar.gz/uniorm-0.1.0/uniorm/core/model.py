"""
Model Base Class / Базовый класс модели / Model asosiy klassi
==============================================================

This module provides the base Model class with Peewee-style syntax.
Этот модуль предоставляет базовый класс Model с синтаксисом в стиле Peewee.
Ushbu modul Peewee uslubidagi sintaksisga ega asosiy Model klassini taqdim etadi.
"""

from tortoise.models import Model as TortoiseModel
from tortoise.queryset import QuerySet
from typing import Optional, List, Any, Dict, Type, TypeVar
import logging

logger = logging.getLogger(__name__)

T = TypeVar('T', bound='Model')


class Model(TortoiseModel):
    """
    Base model class with Peewee-style methods / Базовый класс с методами в стиле Peewee / Peewee uslubidagi metodlarga ega asosiy klass
    
    Example / Пример / Misol:
        class User(Model):
            name = CharField(max_length=100)
            email = CharField(max_length=255, unique=True)
            age = IntField(default=0)
            
            class Meta:
                table = "users"
    """
    
    class Meta:
        abstract = True
    
    # CREATE operations / Операции создания / Yaratish operatsiyalari
    
    @classmethod
    async def create(cls: Type[T], **kwargs) -> T:
        """
        Create a new record / Создать новую запись / Yangi yozuv yaratish
        
        Example / Пример / Misol:
            user = await User.create(name="John", email="john@example.com", age=25)
        """
        try:
            instance = await super(Model, cls).create(**kwargs)
            logger.info(f"Created {cls.__name__} record / Создана запись / Yozuv yaratildi")
            return instance
        except Exception as e:
            logger.error(f"Failed to create {cls.__name__} / Не удалось создать / Yaratish amalga oshmadi: {e}")
            raise
    
    @classmethod
    async def get_or_create(cls: Type[T], defaults: Optional[Dict] = None, **kwargs) -> tuple[T, bool]:
        """
        Get or create a record / Получить или создать запись / Yozuvni olish yoki yaratish
        
        Returns: (instance, created) / Возвращает: (экземпляр, создан) / Qaytaradi: (obyekt, yaratildi)
        
        Example / Пример / Misol:
            user, created = await User.get_or_create(
                email="john@example.com",
                defaults={"name": "John", "age": 25}
            )
        """
        try:
            return await cls.get_or_create(defaults=defaults, **kwargs)
        except Exception as e:
            logger.error(f"Failed to get_or_create {cls.__name__} / Не удалось получить или создать / Olish yoki yaratish amalga oshmadi: {e}")
            raise
    
    # READ operations / Операции чтения / O'qish operatsiyalari
    
    @classmethod
    async def get(cls: Type[T], *args, **kwargs) -> Optional[T]:
        """
        Get a single record / Получить одну запись / Bitta yozuvni olish
        
        Example / Пример / Misol:
            user = await User.get(id=1)
            user = await User.get(email="john@example.com")
        """
        try:
            return await super(Model, cls).get(*args, **kwargs)
        except Exception as e:
            if 'DoesNotExist' in str(type(e).__name__):
                logger.warning(f"{cls.__name__} not found / Не найден / Topilmadi")
                return None
            logger.error(f"Failed to get {cls.__name__} / Не удалось получить / Olish amalga oshmadi: {e}")
            raise
    
    @classmethod
    async def get_by_id(cls: Type[T], id: Any) -> Optional[T]:
        """
        Get record by ID / Получить запись по ID / ID bo'yicha yozuvni olish
        
        Example / Пример / Misol:
            user = await User.get_by_id(1)
        """
        return await cls.get(id=id)
    
    @classmethod
    async def select(cls: Type[T]) -> QuerySet:
        """
        Get all records / Получить все записи / Barcha yozuvlarni olish
        
        Example / Пример / Misol:
            users = await User.select().all()
            active_users = await User.select().filter(is_active=True).all()
        """
        return cls.all()
    
    @classmethod
    async def filter(cls: Type[T], **kwargs) -> List[T]:
        """
        Filter records / Фильтровать записи / Yozuvlarni filtrlash
        
        Example / Пример / Misol:
            users = await User.filter(age__gte=18)
            users = await User.filter(name__icontains="john")
        """
        try:
            return await super(Model, cls).filter(**kwargs).all()
        except Exception as e:
            logger.error(f"Failed to filter {cls.__name__} / Не удалось отфильтровать / Filtrlash amalga oshmadi: {e}")
            raise
    
    @classmethod
    async def first(cls: Type[T]) -> Optional[T]:
        """
        Get first record / Получить первую запись / Birinchi yozuvni olish
        
        Example / Пример / Misol:
            user = await User.first()
        """
        return await cls.first()
    
    @classmethod
    async def count(cls) -> int:
        """
        Count records / Подсчитать записи / Yozuvlarni sanash
        
        Example / Пример / Misol:
            total = await User.count()
        """
        return await cls.all().count()
    
    @classmethod
    async def exists(cls, **kwargs) -> bool:
        """
        Check if record exists / Проверить существование записи / Yozuv mavjudligini tekshirish
        
        Example / Пример / Misol:
            exists = await User.exists(email="john@example.com")
        """
        return await cls.filter(**kwargs).exists()
    
    # UPDATE operations / Операции обновления / Yangilash operatsiyalari
    
    async def update_fields(self, **kwargs) -> None:
        """
        Update specific fields / Обновить определенные поля / Muayyan maydonlarni yangilash
        
        Example / Пример / Misol:
            await user.update_fields(name="Jane", age=26)
        """
        try:
            for key, value in kwargs.items():
                setattr(self, key, value)
            await self.save()
            logger.info(f"Updated {self.__class__.__name__} fields / Поля обновлены / Maydonlar yangilandi")
        except Exception as e:
            logger.error(f"Failed to update fields / Не удалось обновить поля / Maydonlarni yangilash amalga oshmadi: {e}")
            raise
    
    @classmethod
    async def bulk_update(cls, objects: List[T], fields: List[str]) -> None:
        """
        Bulk update records / Массовое обновление записей / Ommaviy yangilash
        
        Example / Пример / Misol:
            users = await User.filter(is_active=False)
            for user in users:
                user.is_active = True
            await User.bulk_update(users, fields=["is_active"])
        """
        try:
            await cls.bulk_update(objects, fields=fields)
            logger.info(f"Bulk updated {len(objects)} {cls.__name__} records / Массово обновлено / Ommaviy yangilandi")
        except Exception as e:
            logger.error(f"Failed to bulk update / Не удалось массово обновить / Ommaviy yangilash amalga oshmadi: {e}")
            raise
    
    # DELETE operations / Операции удаления / O'chirish operatsiyalari
    
    async def delete_instance(self) -> None:
        """
        Delete this instance / Удалить этот экземпляр / Ushbu obyektni o'chirish
        
        Example / Пример / Misol:
            user = await User.get(id=1)
            await user.delete_instance()
        """
        try:
            await self.delete()
            logger.info(f"Deleted {self.__class__.__name__} instance / Экземпляр удален / Obyekt o'chirildi")
        except Exception as e:
            logger.error(f"Failed to delete instance / Не удалось удалить / O'chirish amalga oshmadi: {e}")
            raise
    
    @classmethod
    async def delete_many(cls, **kwargs) -> int:
        """
        Delete multiple records / Удалить несколько записей / Bir nechta yozuvni o'chirish
        
        Returns: Number of deleted records / Возвращает: Количество удаленных записей / Qaytaradi: O'chirilgan yozuvlar soni
        
        Example / Пример / Misol:
            deleted = await User.delete_many(is_active=False)
        """
        try:
            count = await cls.filter(**kwargs).delete()
            logger.info(f"Deleted {count} {cls.__name__} records / Удалено записей / Yozuvlar o'chirildi")
            return count
        except Exception as e:
            logger.error(f"Failed to delete records / Не удалось удалить записи / Yozuvlarni o'chirish amalga oshmadi: {e}")
            raise
    
    # Utility methods / Вспомогательные методы / Yordamchi metodlar
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary / Преобразовать в словарь / Lug'atga aylantirish
        
        Example / Пример / Misol:
            user_dict = user.to_dict()
        """
        return {field: getattr(self, field) for field in self._meta.fields_map.keys()}
    
    @classmethod
    async def paginate(cls: Type[T], page: int = 1, page_size: int = 10) -> Dict[str, Any]:
        """
        Paginate records / Постраничный вывод / Sahifalash
        
        Returns: {"items": [...], "total": int, "page": int, "page_size": int, "pages": int}
        
        Example / Пример / Misol:
            result = await User.paginate(page=1, page_size=20)
        """
        try:
            offset = (page - 1) * page_size
            items = await cls.all().offset(offset).limit(page_size)
            total = await cls.count()
            pages = (total + page_size - 1) // page_size
            
            return {
                "items": items,
                "total": total,
                "page": page,
                "page_size": page_size,
                "pages": pages
            }
        except Exception as e:
            logger.error(f"Failed to paginate / Не удалось выполнить постраничный вывод / Sahifalash amalga oshmadi: {e}")
            raise


# Export / Экспорт / Eksport
__all__ = ['Model']
