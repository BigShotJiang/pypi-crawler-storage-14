"""
Field Types / Типы полей / Maydon turlari
==========================================

This module defines all field types for UniORM models.
Этот модуль определяет все типы полей для моделей UniORM.
Ushbu modul UniORM modellari uchun barcha maydon turlarini belgilaydi.
"""

from tortoise import fields
from typing import Optional, Any


class IntField(fields.IntField):
    """
    Integer field / Целочисленное поле / Butun son maydoni
    
    Example / Пример / Misol:
        age = IntField()
        age = IntField(default=0)
    """
    pass


class CharField(fields.CharField):
    """
    Character field for strings / Символьное поле для строк / Matn maydoni
    
    Example / Пример / Misol:
        name = CharField(max_length=100)
        email = CharField(max_length=255, unique=True)
    """
    pass


class TextField(fields.TextField):
    """
    Text field for long strings / Текстовое поле для длинных строк / Uzun matn maydoni
    
    Example / Пример / Misol:
        description = TextField()
        content = TextField(null=True)
    """
    pass


class BooleanField(fields.BooleanField):
    """
    Boolean field / Логическое поле / Mantiqiy maydon
    
    Example / Пример / Misol:
        is_active = BooleanField(default=True)
        is_deleted = BooleanField(default=False)
    """
    pass


class DateField(fields.DateField):
    """
    Date field / Поле даты / Sana maydoni
    
    Example / Пример / Misol:
        birth_date = DateField()
        created_date = DateField(auto_now_add=True)
    """
    pass


class DateTimeField(fields.DatetimeField):
    """
    DateTime field / Поле даты и времени / Sana va vaqt maydoni
    
    Example / Пример / Misol:
        created_at = DateTimeField(auto_now_add=True)
        updated_at = DateTimeField(auto_now=True)
    """
    pass


class FloatField(fields.FloatField):
    """
    Float field / Поле с плавающей точкой / O'nlik son maydoni
    
    Example / Пример / Misol:
        price = FloatField()
        rating = FloatField(default=0.0)
    """
    pass


def ForeignKeyField(model_name: str, related_name=None, on_delete='CASCADE', **kwargs):
    """
    Foreign key field / Поле внешнего ключа / Tashqi kalit maydoni
    
    Example / Пример / Misol:
        user = ForeignKeyField('models.User', related_name='posts')
        category = ForeignKeyField('models.Category', related_name='products', on_delete='CASCADE')
    """
    return fields.ForeignKeyField(model_name, related_name=related_name, on_delete=on_delete, **kwargs)


def ManyToManyField(model_name: str, related_name=None, **kwargs):
    """
    Many-to-many field / Поле многие-ко-многим / Ko'pdan-ko'pga maydon
    
    Example / Пример / Misol:
        tags = ManyToManyField('models.Tag', related_name='posts')
        students = ManyToManyField('models.Student', related_name='courses')
    """
    return fields.ManyToManyField(model_name, related_name=related_name, **kwargs)


# Export all fields / Экспорт всех полей / Barcha maydonlarni eksport qilish
__all__ = [
    'IntField',
    'CharField',
    'TextField',
    'BooleanField',
    'DateField',
    'DateTimeField',
    'FloatField',
    'ForeignKeyField',
    'ManyToManyField',
]
