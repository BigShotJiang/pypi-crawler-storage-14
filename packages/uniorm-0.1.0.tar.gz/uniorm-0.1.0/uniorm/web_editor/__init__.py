"""
UniORM Web Editor / Веб-редактор UniORM / UniORM veb-muharrir
==============================================================

Flask-based web interface for database management.
Веб-интерфейс на основе Flask для управления базами данных.
Ma'lumotlar bazalarini boshqarish uchun Flask asosidagi veb-interfeys.
"""

from uniorm.web_editor.app import start_editor

__all__ = ['start_editor']
