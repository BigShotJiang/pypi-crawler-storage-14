// UniORM Web Editor JavaScript
// Веб-редактор UniORM JavaScript
// UniORM Veb-muharrir JavaScript

// Translations / Переводы / Tarjimalar
const translations = {
    en: {
        header_subtitle: "Database Management Tool",
        connection_title: "Database Connection",
        db_url: "Database URL",
        models_path: "Models Path",
        connect_btn: "Connect",
        disconnect_btn: "Disconnect",
        status_connected: "Connected",
        status_disconnected: "Disconnected",
        tab_query: "Query Editor",
        tab_tables: "Tables",
        tab_schema: "Schema",
        query_editor_title: "SQL Query Editor",
        execute_btn: "Execute Query",
        tables_title: "Database Tables",
        schema_title: "Database Schema",
        schema_placeholder: "Connect to a database to view schema information",
        footer_text: "All rights reserved",
        success: "Success",
        error: "Error",
        rows_affected: "Rows affected",
        no_results: "No results found",
        loading: "Loading..."
    },
    ru: {
        header_subtitle: "Инструмент управления базами данных",
        connection_title: "Подключение к базе данных",
        db_url: "URL базы данных",
        models_path: "Путь к моделям",
        connect_btn: "Подключиться",
        disconnect_btn: "Отключиться",
        status_connected: "Подключено",
        status_disconnected: "Отключено",
        tab_query: "Редактор запросов",
        tab_tables: "Таблицы",
        tab_schema: "Схема",
        query_editor_title: "Редактор SQL-запросов",
        execute_btn: "Выполнить запрос",
        tables_title: "Таблицы базы данных",
        schema_title: "Схема базы данных",
        schema_placeholder: "Подключитесь к базе данных для просмотра схемы",
        footer_text: "Все права защищены",
        success: "Успешно",
        error: "Ошибка",
        rows_affected: "Затронуто строк",
        no_results: "Результаты не найдены",
        loading: "Загрузка..."
    },
    uz: {
        header_subtitle: "Ma'lumotlar bazalarini boshqarish vositasi",
        connection_title: "Ma'lumotlar bazasiga ulanish",
        db_url: "Ma'lumotlar bazasi URL",
        models_path: "Modellar yo'li",
        connect_btn: "Ulanish",
        disconnect_btn: "Uzilish",
        status_connected: "Ulangan",
        status_disconnected: "Ulanmagan",
        tab_query: "So'rov muharriri",
        tab_tables: "Jadvallar",
        tab_schema: "Sxema",
        query_editor_title: "SQL so'rov muharriri",
        execute_btn: "So'rovni bajarish",
        tables_title: "Ma'lumotlar bazasi jadvallari",
        schema_title: "Ma'lumotlar bazasi sxemasi",
        schema_placeholder: "Sxemani ko'rish uchun ma'lumotlar bazasiga ulaning",
        footer_text: "Barcha huquqlar himoyalangan",
        success: "Muvaffaqiyatli",
        error: "Xatolik",
        rows_affected: "Ta'sirlangan qatorlar",
        no_results: "Natijalar topilmadi",
        loading: "Yuklanmoqda..."
    }
};

let currentLanguage = 'en';
let isConnected = false;

// Set language / Установить язык / Tilni o'rnatish
function setLanguage(lang) {
    currentLanguage = lang;
    localStorage.setItem('uniorm_language', lang);
    
    // Update UI / Обновить интерфейс / Interfeysni yangilash
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (translations[lang][key]) {
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = translations[lang][key];
            } else {
                element.textContent = translations[lang][key];
            }
        }
    });
    
    // Update language buttons / Обновить кнопки языка / Til tugmalarini yangilash
    document.querySelectorAll('.language-btn').forEach(btn => {
        if (btn.getAttribute('data-lang') === lang) {
            btn.classList.add('language-btn-active');
        } else {
            btn.classList.remove('language-btn-active');
        }
    });
}

// Switch tabs / Переключение вкладок / Yorliqlarni almashtirish
function switchTab(tabName) {
    // Hide all tabs / Скрыть все вкладки / Barcha yorliqlarni yashirish
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.add('hidden');
    });
    
    // Remove active class from all tab buttons / Убрать активный класс / Faol klassni olib tashlash
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('tab-active');
    });
    
    // Show selected tab / Показать выбранную вкладку / Tanlangan yorliqni ko'rsatish
    document.getElementById(`${tabName}-tab`).classList.remove('hidden');
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('tab-active');
    
    // Load data for specific tabs / Загрузить данные / Ma'lumotlarni yuklash
    if (tabName === 'tables' && isConnected) {
        loadTables();
    }
}

// Connect to database / Подключение к БД / Ma'lumotlar bazasiga ulanish
async function connectDatabase() {
    const dbUrl = document.getElementById('db-url').value;
    const modelsPath = document.getElementById('models-path').value;
    
    if (!dbUrl) {
        alert(translations[currentLanguage].error + ': Database URL is required');
        return;
    }
    
    const models = modelsPath ? modelsPath.split(',').map(m => m.trim()) : [];
    
    try {
        const response = await fetch('/api/connect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ db_url: dbUrl, models: models })
        });
        
        const result = await response.json();
        
        if (result.success) {
            isConnected = true;
            updateConnectionStatus(true);
            showNotification(translations[currentLanguage].success, result.message, 'success');
        } else {
            showNotification(translations[currentLanguage].error, result.error, 'error');
        }
    } catch (error) {
        showNotification(translations[currentLanguage].error, error.message, 'error');
    }
}

// Disconnect from database / Отключение от БД / Ma'lumotlar bazasidan uzilish
async function disconnectDatabase() {
    try {
        const response = await fetch('/api/disconnect', {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success) {
            isConnected = false;
            updateConnectionStatus(false);
            showNotification(translations[currentLanguage].success, result.message, 'success');
        }
    } catch (error) {
        showNotification(translations[currentLanguage].error, error.message, 'error');
    }
}

// Update connection status / Обновить статус подключения / Ulanish holatini yangilash
function updateConnectionStatus(connected) {
    const statusElement = document.getElementById('connection-status');
    if (connected) {
        statusElement.textContent = translations[currentLanguage].status_connected;
        statusElement.className = 'px-4 py-2 rounded-lg bg-green-100 text-green-700 font-medium';
    } else {
        statusElement.textContent = translations[currentLanguage].status_disconnected;
        statusElement.className = 'px-4 py-2 rounded-lg bg-gray-100 text-gray-600 font-medium';
    }
}

// Execute SQL query / Выполнить SQL-запрос / SQL so'rovini bajarish
async function executeQuery() {
    if (!isConnected) {
        alert('Please connect to a database first');
        return;
    }
    
    const query = document.getElementById('sql-query').value;
    
    if (!query.trim()) {
        alert('Please enter a query');
        return;
    }
    
    const resultsDiv = document.getElementById('query-results');
    resultsDiv.innerHTML = `<p class="text-gray-600">${translations[currentLanguage].loading}</p>`;
    
    try {
        const response = await fetch('/api/query', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query: query })
        });
        
        const result = await response.json();
        
        if (result.success) {
            if (result.data && result.data.length > 0) {
                displayQueryResults(result.data);
            } else {
                resultsDiv.innerHTML = `
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <p class="text-blue-700">${translations[currentLanguage].success}: ${result.rows_affected} ${translations[currentLanguage].rows_affected}</p>
                    </div>
                `;
            }
        } else {
            resultsDiv.innerHTML = `
                <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p class="text-red-700">${translations[currentLanguage].error}: ${result.error}</p>
                </div>
            `;
        }
    } catch (error) {
        resultsDiv.innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                <p class="text-red-700">${translations[currentLanguage].error}: ${error.message}</p>
            </div>
        `;
    }
}

// Display query results / Отобразить результаты / Natijalarni ko'rsatish
function displayQueryResults(data) {
    if (!data || data.length === 0) {
        document.getElementById('query-results').innerHTML = `<p class="text-gray-600">${translations[currentLanguage].no_results}</p>`;
        return;
    }
    
    const columns = Object.keys(data[0]);
    
    let html = `
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 border border-gray-300 rounded-lg">
                <thead class="bg-gray-100">
                    <tr>
                        ${columns.map(col => `<th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">${col}</th>`).join('')}
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    ${data.map(row => `
                        <tr class="hover:bg-gray-50">
                            ${columns.map(col => `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${row[col] !== null ? row[col] : '<span class="text-gray-400">NULL</span>'}</td>`).join('')}
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
        <p class="mt-4 text-sm text-gray-600">${data.length} ${translations[currentLanguage].rows_affected}</p>
    `;
    
    document.getElementById('query-results').innerHTML = html;
}

// Load tables / Загрузить таблицы / Jadvallarni yuklash
async function loadTables() {
    const tablesDiv = document.getElementById('tables-list');
    tablesDiv.innerHTML = `<p class="text-gray-600 col-span-full">${translations[currentLanguage].loading}</p>`;
    
    try {
        const response = await fetch('/api/tables');
        const result = await response.json();
        
        if (result.success && result.tables.length > 0) {
            tablesDiv.innerHTML = result.tables.map(table => `
                <div class="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition cursor-pointer" onclick="viewTable('${table}')">
                    <h4 class="font-semibold text-lg text-gray-800">${table}</h4>
                    <p class="text-sm text-gray-600 mt-1">Click to view data</p>
                </div>
            `).join('');
        } else {
            tablesDiv.innerHTML = `<p class="text-gray-600 col-span-full">${translations[currentLanguage].no_results}</p>`;
        }
    } catch (error) {
        tablesDiv.innerHTML = `<p class="text-red-600 col-span-full">${translations[currentLanguage].error}: ${error.message}</p>`;
    }
}

// View table data / Просмотр данных таблицы / Jadval ma'lumotlarini ko'rish
async function viewTable(tableName) {
    switchTab('query');
    document.getElementById('sql-query').value = `SELECT * FROM ${tableName} LIMIT 100`;
    await executeQuery();
}

// Show notification / Показать уведомление / Bildirishnoma ko'rsatish
function showNotification(title, message, type) {
    const color = type === 'success' ? 'green' : 'red';
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 bg-${color}-100 border border-${color}-300 text-${color}-700 px-6 py-4 rounded-lg shadow-lg z-50`;
    notification.innerHTML = `
        <h4 class="font-semibold">${title}</h4>
        <p class="text-sm mt-1">${message}</p>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Initialize / Инициализация / Boshlash
document.addEventListener('DOMContentLoaded', () => {
    // Load saved language / Загрузить сохраненный язык / Saqlangan tilni yuklash
    const savedLang = localStorage.getItem('uniorm_language') || 'en';
    setLanguage(savedLang);
});
