"""
UniORM Web Editor / Веб-редактор UniORM / UniORM veb-muharrir
==============================================================

Flask-based web editor for UniORM database management.
Веб-редактор на основе Flask для управления базами данных UniORM.
UniORM ma'lumotlar bazalarini boshqarish uchun Flask asosidagi veb-muharrir.
"""

from flask import Flask, render_template, request, jsonify, session
import asyncio
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
import sys
import os

# Add parent directory to path / Добавить родительский каталог / Asosiy katalogni qo'shish
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from uniorm.core.database import Database
from tortoise import Tortoise

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = 'uniorm-secret-key-change-in-production'

# Global database connection / Глобальное подключение / Global ulanish
db_connection: Optional[Database] = None


@app.route('/')
def index():
    """
    Main page / Главная страница / Asosiy sahifa
    """
    return render_template('index.html')


@app.route('/api/connect', methods=['POST'])
async def connect_database():
    """
    Connect to database / Подключиться к БД / Ma'lumotlar bazasiga ulanish
    
    Request body:
        {
            "db_url": "sqlite://db.sqlite3",
            "models": ["myapp.models"]
        }
    """
    try:
        data = request.get_json()
        db_url = data.get('db_url')
        models = data.get('models', [])
        
        if not db_url:
            return jsonify({'error': 'Database URL is required / URL обязателен / URL talab qilinadi'}), 400
        
        # Initialize database / Инициализация БД / Ma'lumotlar bazasini boshlash
        global db_connection
        db_connection = await Database.init(
            url=db_url,
            modules={'models': models},
            generate_schemas=True
        )
        
        session['db_url'] = db_url
        session['models'] = models
        
        return jsonify({
            'success': True,
            'message': 'Connected successfully / Подключено успешно / Muvaffaqiyatli ulandi'
        })
    
    except Exception as e:
        logger.error(f"Connection error / Ошибка подключения / Ulanish xatosi: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/tables', methods=['GET'])
async def get_tables():
    """
    Get list of tables / Получить список таблиц / Jadvallar ro'yxatini olish
    """
    try:
        if not db_connection or not db_connection._initialized:
            return jsonify({'error': 'Not connected to database / Не подключено / Ulanmagan'}), 400
        
        # Get all models / Получить все модели / Barcha modellarni olish
        models = Tortoise.apps.get('models', {})
        tables = [model._meta.db_table for model_name, model in models.items() if hasattr(model, '_meta')]
        
        return jsonify({
            'success': True,
            'tables': tables
        })
    
    except Exception as e:
        logger.error(f"Error getting tables / Ошибка получения таблиц / Jadvallarni olishda xatolik: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/query', methods=['POST'])
async def execute_query():
    """
    Execute SQL query / Выполнить SQL-запрос / SQL so'rovini bajarish
    
    Request body:
        {
            "query": "SELECT * FROM users"
        }
    """
    try:
        if not db_connection or not db_connection._initialized:
            return jsonify({'error': 'Not connected to database / Не подключено / Ulanmagan'}), 400
        
        data = request.get_json()
        query = data.get('query', '').strip()
        
        if not query:
            return jsonify({'error': 'Query is required / Запрос обязателен / So\'rov talab qilinadi'}), 400
        
        # Execute raw SQL / Выполнить сырой SQL / Xom SQL ni bajarish
        conn = Tortoise.get_connection('default')
        
        # Check if it's a SELECT query / Проверка SELECT запроса / SELECT so'rovini tekshirish
        if query.upper().startswith('SELECT'):
            result = await conn.execute_query_dict(query)
            return jsonify({
                'success': True,
                'data': result,
                'rows_affected': len(result)
            })
        else:
            # For INSERT, UPDATE, DELETE / Для INSERT, UPDATE, DELETE / INSERT, UPDATE, DELETE uchun
            rows_affected = await conn.execute_query(query)
            return jsonify({
                'success': True,
                'message': f'Query executed successfully / Запрос выполнен / So\'rov bajarildi',
                'rows_affected': rows_affected
            })
    
    except Exception as e:
        logger.error(f"Query error / Ошибка запроса / So'rov xatosi: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/table/<table_name>', methods=['GET'])
async def get_table_data(table_name: str):
    """
    Get table data / Получить данные таблицы / Jadval ma'lumotlarini olish
    """
    try:
        if not db_connection or not db_connection._initialized:
            return jsonify({'error': 'Not connected to database / Не подключено / Ulanmagan'}), 400
        
        page = request.args.get('page', 1, type=int)
        page_size = request.args.get('page_size', 50, type=int)
        
        # Execute query / Выполнить запрос / So'rovni bajarish
        conn = Tortoise.get_connection('default')
        offset = (page - 1) * page_size
        
        # Get data / Получить данные / Ma'lumotlarni olish
        query = f"SELECT * FROM {table_name} LIMIT {page_size} OFFSET {offset}"
        data = await conn.execute_query_dict(query)
        
        # Get total count / Получить общее количество / Umumiy sonni olish
        count_query = f"SELECT COUNT(*) as count FROM {table_name}"
        count_result = await conn.execute_query_dict(count_query)
        total = count_result[0]['count'] if count_result else 0
        
        return jsonify({
            'success': True,
            'data': data,
            'total': total,
            'page': page,
            'page_size': page_size,
            'pages': (total + page_size - 1) // page_size
        })
    
    except Exception as e:
        logger.error(f"Error getting table data / Ошибка получения данных / Ma'lumotlarni olishda xatolik: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/disconnect', methods=['POST'])
async def disconnect_database():
    """
    Disconnect from database / Отключиться от БД / Ma'lumotlar bazasidan uzilish
    """
    try:
        global db_connection
        if db_connection:
            await db_connection.close()
            db_connection = None
        
        session.clear()
        
        return jsonify({
            'success': True,
            'message': 'Disconnected successfully / Отключено успешно / Muvaffaqiyatli uzildi'
        })
    
    except Exception as e:
        logger.error(f"Disconnect error / Ошибка отключения / Uzilish xatosi: {e}")
        return jsonify({'error': str(e)}), 500


def run_async(coro):
    """
    Helper to run async functions / Помощник для запуска async функций / Async funksiyalarni ishga tushirish yordamchisi
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# Wrap async routes / Обернуть async маршруты / Async marshrutlarni o'rash
for rule in app.url_map.iter_rules():
    view_func = app.view_functions.get(rule.endpoint)
    if view_func and asyncio.iscoroutinefunction(view_func):
        app.view_functions[rule.endpoint] = lambda *args, _f=view_func, **kwargs: run_async(_f(*args, **kwargs))


def start_editor(host: str = '127.0.0.1', port: int = 5000, debug: bool = True):
    """
    Start web editor / Запустить веб-редактор / Veb-muharrirni ishga tushirish
    
    Args:
        host: Host address / Адрес хоста / Host manzili
        port: Port number / Номер порта / Port raqami
        debug: Debug mode / Режим отладки / Debug rejimi
    
    Example / Пример / Misol:
        from uniorm.web_editor.app import start_editor
        start_editor(port=8000)
    """
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║                    UniORM Web Editor                         ║
║              Веб-редактор UniORM                             ║
║              UniORM Veb-muharrir                             ║
╠══════════════════════════════════════════════════════════════╣
║  URL: http://{host}:{port}                                 ║
║  Press Ctrl+C to stop / Нажмите Ctrl+C / Ctrl+C bosing      ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    app.run(host=host, port=port, debug=debug)


if __name__ == '__main__':
    start_editor()
