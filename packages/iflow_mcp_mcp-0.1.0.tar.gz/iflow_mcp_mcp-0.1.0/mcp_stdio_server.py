#!/usr/bin/env python3
"""
MCP Server for jobs and employee feedback management using stdio transport
"""
from mcp.server.fastmcp import FastMCP
import requests
import asyncio
import json

# Create a combined server for both jobs and employee functionality
app = FastMCP("mcp-server")

@app.tool()
async def find_similar_jobs(requirements: str):
    """
    Given a prompt describing a job requisition (requirements, skills, location, etc.),
    return a list of similar jobs from the local jobs API.
    
    Args:
        requirements: Job requirements description including skills, location, experience level
    
    Returns:
        List of matching job postings
    """
    try:
        # Call the dummy jobs API
        resp = requests.get("http://127.0.0.1:8001/jobs", timeout=10)
        jobs = resp.json().get("jobs", [])
        
        # Simple matching: check if requirements words appear in job fields
        req = requirements.lower()
        matches = []
        for job in jobs:
            text = f"{job['title']} {job['location']} {job['experience']} {' '.join(job['skills'])} {job['description']}".lower()
            if any(word in text for word in req.split()):
                matches.append(job)
        
        # If no matches, return all jobs
        return matches if matches else jobs
    except Exception as e:
        return {"error": f"Failed to fetch jobs: {str(e)}"}

@app.tool()
async def summarize_employee_feedback(name: str):
    """
    Given an employee name, return a summary of their feedback for the current year.
    
    Args:
        name: Employee name to get feedback for
    
    Returns:
        Summary of employee feedback for the current year
    """
    try:
        resp = requests.get(f"http://127.0.0.1:8001/employees/{name}", timeout=10)
        emp = resp.json()
        
        if "error" in emp:
            return emp["error"]
        
        feedbacks = emp.get("feedback", [])
        # Filter for current year (2024)
        year = 2024
        summary = []
        for fb in feedbacks:
            if fb["year"] == year:
                summary.append(f"[{fb['type']}] {fb['text']}")
        
        if not summary:
            return f"No feedback found for {name} in {year}."
        
        return f"Feedback summary for {name} ({year}):\n" + "\n".join(summary)
    except Exception as e:
        return {"error": f"Failed to fetch employee feedback: {str(e)}"}

def main():
    """Main entry point for stdio transport"""
    app.run(transport="stdio")

if __name__ == "__main__":
    main()