"""utt-project-summary: A utt plugin to show projects sorted by time spent."""

__version__ = "0.1.0-rc.1"
