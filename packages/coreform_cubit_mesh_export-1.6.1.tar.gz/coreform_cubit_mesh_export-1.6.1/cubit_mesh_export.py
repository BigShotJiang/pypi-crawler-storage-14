########################################################################
###	Gmsh format version 2
########################################################################

def export_Gmsh_ver2(cubit, FileName: str):
	"""Export mesh to Gmsh format version 2.2.

	Exports 1D, 2D, and 3D mesh elements from Cubit to Gmsh v2.2 format.
	Supports both first-order and second-order elements.

	Args:
		cubit: Cubit Python interface object
		FileName: Output file path for the .msh file

	Returns:
		cubit: The cubit object (for method chaining)

	Supported elements:
		- 1st order: Point, Line, Triangle, Quad, Tetrahedron, Hexahedron, Wedge, Pyramid
		- 2nd order: Line3, Triangle6, Quad8/9, Tetrahedron10/11, Hexahedron20, Wedge15, Pyramid13
	"""
	with open(FileName, 'w') as fid:

		fid.write("$MeshFormat\n")
		fid.write("2.2 0 8\n")
		fid.write("$EndMeshFormat\n")

		fid.write("$PhysicalNames\n")
		fid.write(f'{cubit.get_block_count()}\n')
		for block_id in cubit.get_block_id_list():
			name = cubit.get_exodus_entity_name("block", block_id)
			if len(cubit.get_block_nodes(block_id)) > 0:
				fid.write(f'0 {block_id} "{name}"\n')
			elif len(cubit.get_block_edges(block_id)) > 0:
				fid.write(f'1 {block_id} "{name}"\n')
			elif len(cubit.get_block_tris(block_id)) + len(cubit.get_block_faces(block_id)) > 0:
				fid.write(f'2 {block_id} "{name}"\n')
			else:
				fid.write(f'3 {block_id} "{name}"\n')
		fid.write('$EndPhysicalNames\n')

		fid.write("$Nodes\n")
		node_list = set()
		for block_id in cubit.get_block_id_list():
			elem_types = ["hex", "tet", "wedge", "pyramid", "tri", "face", "edge", "node"]
			for elem_type in elem_types:
				if elem_type == "hex":
					func = getattr(cubit, f"get_block_{elem_type}es")
				else:
					func = getattr(cubit, f"get_block_{elem_type}s")
				for element_id in func(block_id):
					node_ids = cubit.get_expanded_connectivity(elem_type, element_id)
					node_list.update(node_ids)

		fid.write(f'{len(node_list)}\n')
		for node_id in node_list:
			coord = cubit.get_nodal_coordinates(node_id)
			fid.write(f'{node_id} {coord[0]} {coord[1]} {coord[2]}\n')
		fid.write('$EndNodes\n')

		hex_list = set()
		tet_list = set()
		wedge_list = set()
		pyramid_list = set()
		tri_list = set()
		quad_list = set()
		edge_list = set()
		node_list = set()

		for block_id in cubit.get_block_id_list():
			tet_list.update(cubit.get_block_tets(block_id))
			hex_list.update(cubit.get_block_hexes(block_id))
			wedge_list.update(cubit.get_block_wedges(block_id))
			pyramid_list.update(cubit.get_block_pyramids(block_id))
			tri_list.update(cubit.get_block_tris(block_id))
			quad_list.update(cubit.get_block_faces(block_id))
			edge_list.update(cubit.get_block_edges(block_id))
			node_list.update(cubit.get_block_nodes(block_id))

		element_id = 0
		fid.write('$Elements\n')
		fid.write(f'{len(hex_list) + len(tet_list) + len(wedge_list) + len(pyramid_list) + len(tri_list) + len(quad_list) + len(edge_list) + len(node_list)}\n')

		for block_id in cubit.get_block_id_list():

			tet_list = cubit.get_block_tets(block_id)
			for tet_id in tet_list:
				element_id += 1
				node_list = cubit.get_expanded_connectivity("tet", tet_id)
				if len(node_list)==4:
					fid.write(f'{element_id} { 4} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]}\n')
				elif len(node_list)==10:
					fid.write(f'{element_id} {11} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[7]} {node_list[9]} {node_list[8]}\n')
				elif len(node_list)==11:
					fid.write(f'{element_id} {35} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[7]} {node_list[9]} {node_list[8]} {node_list[10]}\n')

			hex_list = cubit.get_block_hexes(block_id)
			for hex_id in hex_list:
				element_id += 1
				node_list = cubit.get_expanded_connectivity("hex", hex_id)
				if len(node_list)==8:
					fid.write(f'{element_id} { 5} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[7]}\n')
				elif len(node_list)==20:
					fid.write(f'{element_id} {17} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[7]} {node_list[8]} {node_list[11]} {node_list[12]} {node_list[9]} {node_list[13]} {node_list[10]} {node_list[14]} {node_list[15]} {node_list[16]} {node_list[19]} {node_list[17]} {node_list[18]}\n')

			wedge_list = cubit.get_block_wedges(block_id)
			for wedge_id in wedge_list:
				element_id += 1
				node_list = cubit.get_expanded_connectivity("wedge", wedge_id)
				if len(node_list)==6:
					fid.write(f'{element_id} { 6} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]}\n')
				elif len(node_list)==15:
					fid.write(f'{element_id} {18} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[8]} {node_list[9]} {node_list[7]} {node_list[10]} {node_list[11]} {node_list[12]} {node_list[14]} {node_list[13]}\n')

			pyramid_list = cubit.get_block_pyramids(block_id)
			for pyramid_id in pyramid_list:
				element_id += 1
				node_list = cubit.get_expanded_connectivity("pyramid", pyramid_id)
				if len(node_list)==5:
					fid.write(f'{element_id} { 7} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]}\n')
				elif len(node_list)==13:
					fid.write(f'{element_id} {19} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[8]} {node_list[9]} {node_list[6]} {node_list[10]} {node_list[7]} {node_list[11]} {node_list[12]} \n')

			tri_list = cubit.get_block_tris(block_id)
			for tri_id in tri_list:
				element_id += 1
				node_list = cubit.get_expanded_connectivity("tri", tri_id)
				if len(node_list)==3:
					fid.write(f'{element_id} { 2} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]}\n')
				elif len(node_list)==6:
					fid.write(f'{element_id} { 9} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]}\n')
				elif len(node_list)==7:
					fid.write(f'{element_id} {42} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]}\n')

			quad_list = cubit.get_block_faces(block_id)
			for quad_id in quad_list:
				element_id += 1
				node_list = cubit.get_expanded_connectivity("quad", quad_id)
				if len(node_list)==4:
					fid.write(f'{element_id} { 3} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]}\n')
				elif len(node_list)==8:
					fid.write(f'{element_id} {16} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[7]}\n')
				elif len(node_list)==9:
					fid.write(f'{element_id} {10} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[7]} {node_list[8]}\n')

			edge_list = cubit.get_block_edges(block_id)
			for edge_id in edge_list:
				element_id += 1
				node_list = cubit.get_expanded_connectivity("edge", edge_id)
				if len(node_list)==2:
					fid.write(f'{element_id} {1} {2} {block_id} {block_id} {node_list[0]} {node_list[1]}\n')
				elif len(node_list)==3:
					fid.write(f'{element_id} {8} {2} {block_id} {block_id} {node_list[0]} {node_list[1]} {node_list[2]}\n')

			node_list = cubit.get_block_nodes(block_id)
			for node_id in node_list:
				element_id += 1
				fid.write(f'{element_id} {15} {2} {block_id} {block_id} {node_id}\n')

		fid.write('$EndElements\n')
	return cubit

########################################################################
###	Nastran file
########################################################################

def export_Nastran(cubit, FileName: str, DIM: str = "3D", PYRAM: bool = True):
	"""Export mesh to Nastran format.

	Exports mesh elements from Cubit to NX Nastran bulk data format.
	Supports 2D and 3D meshes with first-order elements only.

	Args:
		cubit: Cubit Python interface object
		FileName: Output file path for the .nas or .bdf file
		DIM: Dimension mode - "2D" for 2D meshes, "3D" for 3D meshes (default: "3D")
		PYRAM: If True, export pyramids as CPYRAM; if False, convert to degenerate hex (default: True)

	Returns:
		cubit: The cubit object (for method chaining)

	Supported elements:
		- 3D: CTETRA (tet4), CHEXA (hex8), CPENTA (wedge6), CPYRAM (pyramid5)
		- 2D: CTRIA3 (tri3), CQUAD4 (quad4)
		- 1D: CROD (edge/bar)
		- 0D: CMASS (point mass)

	Note:
		Only first-order elements are supported. Second-order elements are not exported.
	"""
	import datetime
	formatted_date_time = datetime.datetime.now().strftime("%d-%b-%y at %H:%M:%S")
	with open(FileName,'w',encoding='UTF-8') as fid:
		fid.write("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n")
		fid.write("$\n")
		fid.write("$                         CUBIT NX Nastran Translator\n")
		fid.write("$\n")
		fid.write(f"$            File: {FileName}\n")
		fid.write(f"$      Time Stamp: {formatted_date_time}\n")
		fid.write("$\n")
		fid.write("$\n")
		fid.write("$                        PLEASE CHECK YOUR MODEL FOR UNITS CONSISTENCY.\n")
		fid.write("$\n")
		fid.write("$       It should be noted that load ID's from CUBIT may NOT correspond to Nastran SID's\n")
		fid.write("$ The SID's for the load and restraint sets start at one and increment by one:i.e.,1,2,3,4...\n")
		fid.write("$\n")
		fid.write("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n")
		fid.write("$\n")
		fid.write("$\n")
		fid.write("$ -------------------------\n")
		fid.write("$ Executive Control Section\n")
		fid.write("$ -------------------------\n")
		fid.write("$\n")
		fid.write("SOL 101\n")
		fid.write("CEND\n")
		fid.write("$\n")
		fid.write("$\n")
		fid.write("$ --------------------\n")
		fid.write("$ Case Control Section\n")
		fid.write("$ --------------------\n")
		fid.write("$\n")
		fid.write("ECHO = SORT\n")
		fid.write("$\n")
		fid.write("$\n")
		fid.write("$ Name: Initial\n")
		fid.write("$\n")
		fid.write("$\n")
		fid.write("$ Name: Default Set\n")
		fid.write("$\n")
		fid.write("SUBCASE = 1\n")
		fid.write("$\n")
		fid.write("LABEL = Default Set\n")
		fid.write("$\n")
		fid.write("$ -----------------\n")
		fid.write("$ Bulk Data Section\n")
		fid.write("$ -----------------\n")
		fid.write("$\n")
		fid.write("BEGIN BULK\n")
		fid.write("$\n")
		fid.write("$ Params\n")
		fid.write("$\n")
		fid.write("$\n")
		fid.write("$ Node cards\n")
		fid.write("$\n")

		node_list = set()
		for block_id in cubit.get_block_id_list():
			elem_types = ["hex", "tet", "wedge", "pyramid", "tri", "face", "edge", "node"]
			for elem_type in elem_types:
				if elem_type == "hex":
					func = getattr(cubit, f"get_block_{elem_type}es")
				else:
					func = getattr(cubit, f"get_block_{elem_type}s")
				for element_id in func(block_id):
					node_ids = cubit.get_connectivity(elem_type, element_id)
					node_list.update(node_ids)
		for node_id in node_list:
			coord = cubit.get_nodal_coordinates(node_id)
			if DIM == "3D":
				fid.write(f"GRID*   {node_id:>16}{0:>16}{coord[0]:>16.5f}{coord[1]:>16.5f}\n*       {coord[2]:>16.5f}\n")
			else:
				fid.write(f"GRID*   {node_id:>16}{0:>16}{coord[0]:>16.5f}{coord[1]:>16.5f}\n*       {0}\n")

		element_id = 0
		fid.write("$\n")
		fid.write("$ Element cards\n")
		fid.write("$\n")
		for block_id in cubit.get_block_id_list():
			name = cubit.get_exodus_entity_name("block",block_id)
			fid.write("$\n")
			fid.write(f"$ Name: {name}\n")
			fid.write("$\n")
			tet_list = cubit.get_block_tets(block_id)

			if DIM=="3D":
				for tet_id in tet_list:
					node_list = cubit.get_connectivity('tet',tet_id)
					element_id += 1
					fid.write(f"CTETRA  {element_id:>8}{block_id:>8}{node_list[0]:>8}{node_list[1]:>8}{node_list[2]:>8}{node_list[3]:>8}\n")
				hex_list = cubit.get_block_hexes(block_id)
				for hex_id in hex_list:
					node_list = cubit.get_connectivity('hex',hex_id)
					element_id += 1
					fid.write(f"CHEXA   {element_id:>8}{block_id:>8}{node_list[0]:>8}{node_list[1]:>8}{node_list[2]:>8}{node_list[3]:>8}{node_list[4]:>8}{node_list[5]:>8}+\n+       {node_list[6]:>8}{node_list[7]:>8}\n")
				wedge_list = cubit.get_block_wedges(block_id)
				for wedge_id in wedge_list:
					node_list = cubit.get_connectivity('wedge',wedge_id)
					element_id += 1
					fid.write(f"CPENTA  {element_id:>8}{block_id:>8}{node_list[0]:>8}{node_list[1]:>8}{node_list[2]:>8}{node_list[3]:>8}{node_list[4]:>8}{node_list[5]:>8}\n")
				pyramid_list = cubit.get_block_pyramids(block_id)
				for pyramid_id in pyramid_list:
					node_list = cubit.get_connectivity('pyramid',pyramid_id)
					if PYRAM:
						element_id += 1
						fid.write(f"CPYRAM  {element_id:>8}{block_id:>8}{node_list[0]:>8}{node_list[1]:>8}{node_list[2]:>8}{node_list[3]:>8}{node_list[4]:>8}\n")
					else:
						element_id += 1
						fid.write(f"CHEXA   {element_id:>8}{block_id:>8}{node_list[0]:>8}{node_list[1]:>8}{node_list[2]:>8}{node_list[3]:>8}{node_list[4]:>8}{node_list[4]:>8}+\n+       {node_list[4]:>8}{node_list[4]:>8}\n")

			tri_list = cubit.get_block_tris(block_id)
			for tri_id in tri_list:
				node_list = cubit.get_connectivity('tri',tri_id)
				element_id += 1
				if DIM=="3D":
					fid.write(f"CTRIA3  {element_id:<8}{block_id:<8}{node_list[0]:<8}{node_list[1]:<8}{node_list[2]:<8}\n")
				else:
					surface_id = int(cubit.get_geometry_owner("tri", tri_id).split()[1])
					normal = cubit.get_surface_normal(surface_id)
					if normal[2] > 0:
						fid.write(f"CTRIA3  {element_id:<8}{block_id:<8}{node_list[0]:<8}{node_list[1]:<8}{node_list[2]:<8}\n")
					else:
						fid.write(f"CTRIA3  {element_id:<8}{block_id:<8}{node_list[0]:<8}{node_list[2]:<8}{node_list[1]:<8}\n")
			quad_list = cubit.get_block_faces(block_id)
			for quad_id in quad_list:
				node_list = cubit.get_connectivity('quad',quad_id)
				element_id += 1
				if DIM=="3D":
					fid.write(f"CQUAD4  {element_id:<8}{block_id:<8}{node_list[0]:<8}{node_list[1]:<8}{node_list[2]:<8}{node_list[3]:<8}\n")
				else:
					surface_id = int(cubit.get_geometry_owner("quad", quad_id).split()[1])
					normal = cubit.get_surface_normal(surface_id)
					node_list = cubit.get_connectivity('quad',quad_id)
					if normal[2] > 0:
						fid.write(f"CQUAD4  {element_id:<8}{block_id:<8}{node_list[0]:<8}{node_list[1]:<8}{node_list[2]:<8}{node_list[3]:<8}\n")
					else:
						fid.write(f"CQUAD4  {element_id:<8}{block_id:<8}{node_list[0]:<8}{node_list[3]:<8}{node_list[2]:<8}{node_list[1]:<8}\n")
			edge_list = cubit.get_block_edges(block_id)
			for edge_id in edge_list:
				element_id += 1
				node_list = cubit.get_connectivity('edge', edge_id)
				fid.write(f"CROD    {element_id:<8}{block_id:<8}{node_list[0]:<8}{node_list[1]:<8}\n")
			node_list = cubit.get_block_nodes(block_id)
			for node_id in node_list:
				element_id += 1
				fid.write(f"CMASS   {element_id:<8}{block_id:<8}{node_id:<8}\n")
		fid.write("$\n")
		fid.write("$ Property cards\n")
		fid.write("$\n")

		for block_id in cubit.get_block_id_list():
			name = cubit.get_exodus_entity_name("block",block_id)
			fid.write("$\n")
			fid.write(f"$ Name: {name}\n")
			if len(cubit.get_block_nodes(block_id)) > 0:
				fid.write(f"PMASS    {block_id:< 8}{block_id:< 8}\n")
			elif len(cubit.get_block_edges(block_id)) > 0:
				fid.write(f"PROD     {block_id:< 8}{block_id:< 8}\n")
			elif len(cubit.get_block_tris(block_id)) + len(cubit.get_block_faces(block_id)) > 0:
				fid.write(f"PSHELL   {block_id:< 8}{block_id:< 8}\n")
			else:
				fid.write(f"PSOLID   {block_id:< 8}{block_id:< 8}\n")
			fid.write("$\n")

		fid.write("ENDDATA\n")
	return cubit

########################################################################
###	ELF meg file
########################################################################

def export_meg(cubit, FileName: str, DIM: str = 'T', MGR2=None):
	"""Export mesh to ELF/MESH MEG format.

	Exports mesh elements from Cubit to ELF/MAGIC MEG format for finite element analysis.

	Args:
		cubit: Cubit Python interface object
		FileName: Output file path for the .meg file
		DIM: Dimension mode - 'T' for 3D, 'R' for axisymmetric, 'K' for 2D (default: 'T')
		MGR2: Optional list of spatial nodes [[x1,y1,z1], [x2,y2,z2], ...] (default: None)

	Returns:
		cubit: The cubit object (for method chaining)

	Supported elements:
		- 3D: Tetrahedron, Hexahedron, Wedge, Pyramid
		- 2D: Triangle, Quadrilateral
		- 1D: Edge
		- 0D: Node
	"""
	if MGR2 is None:
		MGR2 = []

	with open(FileName,'w',encoding='UTF-8') as fid:
		fid.write("BOOK  MEP  3.50\n")
		fid.write("* ELF/MESH VERSION 7.3.0\n")
		fid.write("* SOLVER = ELF/MAGIC\n")
		fid.write("MGSC 0.001\n")
		fid.write("* NODE\n")

		node_list = set()
		for block_id in cubit.get_block_id_list():
			elem_types = ["hex", "tet", "wedge", "pyramid", "tri", "face", "edge"]
			for elem_type in elem_types:
				if elem_type == "hex":
					func = getattr(cubit, f"get_block_{elem_type}es")
				else:
					func = getattr(cubit, f"get_block_{elem_type}s")
				for element_id in func(block_id):
					node_ids = cubit.get_connectivity(elem_type, element_id)
					node_list.update(node_ids)
		for node_id in node_list:
			coord = cubit.get_nodal_coordinates(node_id)
			if DIM=='T':
				fid.write(f"MGR1 {node_id} 0 {coord[0]} {coord[1]} {coord[2]}\n")
			if DIM=='K':
				fid.write(f"MGR1 {node_id} 0 {coord[0]} {coord[1]} {0}\n")
			if DIM=='R':
				fid.write(f"MGR1 {node_id} 0 {coord[0]} {0} {coord[2]}\n")

		element_id = 0
		fid.write("* ELEMENT K\n")
		for block_id in cubit.get_block_id_list():
			name = cubit.get_exodus_entity_name("block",block_id)

			if DIM=='T':
				tet_list = cubit.get_block_tets(block_id)
				for tet_id in tet_list:
					node_list = cubit.get_connectivity('tet',tet_id)
					element_id += 1
					fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]}\n")

				hex_list = cubit.get_block_hexes(block_id)
				for hex_id in hex_list:
					node_list = cubit.get_connectivity('hex',hex_id)
					element_id += 1
					fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]} {node_list[6]} {node_list[7]}\n")

				wedge_list = cubit.get_block_wedges(block_id)
				for wedge_id in wedge_list:
					node_list = cubit.get_connectivity('wedge',wedge_id)
					element_id += 1
					fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[5]}\n")

				pyramid_list = cubit.get_block_pyramids(block_id)
				for pyramid_id in pyramid_list:
					node_list = cubit.get_connectivity('pyramid',pyramid_id)
					element_id += 1
					fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]} {node_list[4]} {node_list[4]} {node_list[4]} {node_list[4]}\n")

			tri_list = cubit.get_block_tris(block_id)
			for tri_id in tri_list:
				node_list = cubit.get_connectivity('tri',tri_id)
				element_id += 1
				fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_list[0]} {node_list[1]} {node_list[2]}\n")

			quad_list = cubit.get_block_faces(block_id)
			for quad_id in quad_list:
				node_list = cubit.get_connectivity('quad',quad_id)
				element_id += 1
				fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_list[0]} {node_list[1]} {node_list[2]} {node_list[3]}\n")

			edge_list = cubit.get_block_edges(block_id)
			for edge_id in edge_list:
				node_list = cubit.get_connectivity('edge',edge_id)
				element_id += 1
				fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_list[0]} {node_list[1]}\n")

			node_list = cubit.get_block_nodes(block_id)
			for node_id in node_list:
				element_id += 1
				fid.write(f"{name[0:4]}{DIM} {element_id} 0 {block_id} {node_id}\n")

		fid.write("* NODE\n")
		for node_id in range(len(MGR2)):
			fid.write(f"MGR2 {node_id+1} 0 {MGR2[node_id][0]} {MGR2[node_id][1]} {MGR2[node_id][2]}\n")
		fid.write("BOOK  END\n")
	return cubit

########################################################################
###	vtk format
########################################################################

def export_vtk(cubit, FileName: str):
	"""Export mesh to Legacy VTK format.

	Exports mesh elements from Cubit to VTK (Visualization Toolkit) Legacy format.
	Automatically detects element order (1st or 2nd) based on node count.
	Supports mixed-order meshes (1st and 2nd order elements in same file).

	Args:
		cubit: Cubit Python interface object
		FileName: Output file path for the .vtk file

	Returns:
		cubit: The cubit object (for method chaining)

	Supported elements:
		- 1st order: Tet4, Hex8, Wedge6, Pyramid5, Triangle3, Quad4, Line2, Point
		- 2nd order: Tet10, Hex20, Wedge15, Pyramid13, Triangle6, Quad8, Line3

	Note:
		VTK cell data includes scalar values to distinguish element types.
		Element order is automatically detected from node count per element.
	"""
	with open(FileName,'w') as fid:
		fid.write('# vtk DataFile Version 3.0\n')
		fid.write(f'Unstructured Grid {FileName}\n')
		fid.write('ASCII\n')
		fid.write('DATASET UNSTRUCTURED_GRID\n')
		# First, collect all unique node IDs from all elements
		node_list = set()
		hex_list = set()
		tet_list = set()
		wedge_list = set()
		pyramid_list = set()
		tri_list = set()
		quad_list = set()
		edge_list = set()
		nodes_list = set()

		for block_id in cubit.get_block_id_list():
			tet_list.update(cubit.get_block_tets(block_id))
			hex_list.update(cubit.get_block_hexes(block_id))
			wedge_list.update(cubit.get_block_wedges(block_id))
			pyramid_list.update(cubit.get_block_pyramids(block_id))
			tri_list.update(cubit.get_block_tris(block_id))
			quad_list.update(cubit.get_block_faces(block_id))
			edge_list.update(cubit.get_block_edges(block_id))
			nodes_list.update(cubit.get_block_nodes(block_id))

		# Collect all node IDs from all element types
		elem_types = ["hex", "tet", "wedge", "pyramid", "tri", "face", "edge", "node"]
		for block_id in cubit.get_block_id_list():
			for elem_type in elem_types:
				if elem_type == "hex":
					func = getattr(cubit, f"get_block_{elem_type}es")
				else:
					func = getattr(cubit, f"get_block_{elem_type}s")
				for element_id in func(block_id):
					node_ids = cubit.get_expanded_connectivity(elem_type, element_id)
					node_list.update(node_ids)

		# Write POINTS header
		fid.write(f'POINTS {len(node_list)} float\n')

		# Create mapping from Cubit node ID to VTK index (0-indexed)
		# Write coordinates in sorted order for consistency
		node_id_to_vtk_index = {}
		vtk_index = 0
		for node_id in sorted(node_list):
			coord = cubit.get_nodal_coordinates(node_id)
			fid.write(f'{coord[0]} {coord[1]} {coord[2]}\n')
			node_id_to_vtk_index[node_id] = vtk_index
			vtk_index += 1

		# Pre-scan all elements to get node counts for each element
		# This enables auto-detection of element order and mixed-order support
		tet_node_counts = {tet_id: len(cubit.get_expanded_connectivity("tet", tet_id)) for tet_id in tet_list}
		hex_node_counts = {hex_id: len(cubit.get_expanded_connectivity("hex", hex_id)) for hex_id in hex_list}
		wedge_node_counts = {wedge_id: len(cubit.get_expanded_connectivity("wedge", wedge_id)) for wedge_id in wedge_list}
		pyramid_node_counts = {pyramid_id: len(cubit.get_expanded_connectivity("pyramid", pyramid_id)) for pyramid_id in pyramid_list}
		tri_node_counts = {tri_id: len(cubit.get_expanded_connectivity("tri", tri_id)) for tri_id in tri_list}
		quad_node_counts = {quad_id: len(cubit.get_expanded_connectivity("quad", quad_id)) for quad_id in quad_list}
		edge_node_counts = {edge_id: len(cubit.get_expanded_connectivity("edge", edge_id)) for edge_id in edge_list}

		# Calculate total CELLS size: sum of (1 + node_count) for each element
		num_cells = len(tet_list) + len(hex_list) + len(wedge_list) + len(pyramid_list) + len(tri_list) + len(quad_list) + len(edge_list) + len(nodes_list)
		cells_size = (
			sum(1 + n for n in tet_node_counts.values()) +
			sum(1 + n for n in hex_node_counts.values()) +
			sum(1 + n for n in wedge_node_counts.values()) +
			sum(1 + n for n in pyramid_node_counts.values()) +
			sum(1 + n for n in tri_node_counts.values()) +
			sum(1 + n for n in quad_node_counts.values()) +
			sum(1 + n for n in edge_node_counts.values()) +
			2 * len(nodes_list)  # Each node: 1 (count) + 1 (node_id)
		)
		fid.write(f'CELLS {num_cells} {cells_size}\n')

		for tet_id in tet_list:
			node_list = cubit.get_expanded_connectivity("tet", tet_id)
			if len(node_list)==4:
				fid.write(f'4 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]}\n')
			elif len(node_list)==10:
				fid.write(f'10 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} {node_id_to_vtk_index[node_list[6]]} {node_id_to_vtk_index[node_list[7]]} {node_id_to_vtk_index[node_list[8]]} {node_id_to_vtk_index[node_list[9]]}\n')
		for hex_id in hex_list:
			node_list = cubit.get_expanded_connectivity("hex", hex_id)
			if len(node_list)==8:
				fid.write(f'8 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} {node_id_to_vtk_index[node_list[6]]} {node_id_to_vtk_index[node_list[7]]}\n')
			elif len(node_list)==20:
				fid.write(f'20 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} {node_id_to_vtk_index[node_list[6]]} {node_id_to_vtk_index[node_list[7]]} {node_id_to_vtk_index[node_list[8]]} {node_id_to_vtk_index[node_list[9]]} {node_id_to_vtk_index[node_list[10]]} {node_id_to_vtk_index[node_list[11]]} {node_id_to_vtk_index[node_list[16]]} {node_id_to_vtk_index[node_list[17]]} {node_id_to_vtk_index[node_list[18]]} {node_id_to_vtk_index[node_list[19]]} {node_id_to_vtk_index[node_list[12]]} {node_id_to_vtk_index[node_list[13]]} {node_id_to_vtk_index[node_list[14]]} {node_id_to_vtk_index[node_list[15]]}\n')
		for wedge_id in wedge_list:
			node_list = cubit.get_expanded_connectivity("wedge", wedge_id)
			if len(node_list)==6:
				fid.write(f'6 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} \n')
			elif len(node_list)==15:
				fid.write(f'15 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} {node_id_to_vtk_index[node_list[6]]} {node_id_to_vtk_index[node_list[7]]} {node_id_to_vtk_index[node_list[8]]} {node_id_to_vtk_index[node_list[12]]} {node_id_to_vtk_index[node_list[13]]} {node_id_to_vtk_index[node_list[14]]} {node_id_to_vtk_index[node_list[9]]} {node_id_to_vtk_index[node_list[10]]} {node_id_to_vtk_index[node_list[11]]} \n')

		for pyramid_id in pyramid_list:
			node_list = cubit.get_expanded_connectivity("pyramid", pyramid_id)
			if len(node_list)==5:
				fid.write(f'5 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} \n')
			elif len(node_list)==13:
				fid.write(f'13 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} {node_id_to_vtk_index[node_list[6]]} {node_id_to_vtk_index[node_list[7]]} {node_id_to_vtk_index[node_list[8]]} {node_id_to_vtk_index[node_list[9]]} {node_id_to_vtk_index[node_list[10]]} {node_id_to_vtk_index[node_list[11]]} {node_id_to_vtk_index[node_list[12]]} \n')
		for tri_id in tri_list:
			node_list = cubit.get_expanded_connectivity("tri", tri_id)
			if len(node_list)==3:
				fid.write(f'3 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} \n')
			elif len(node_list)==6:
				fid.write(f'6 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} \n')
		for quad_id in quad_list:
			node_list = cubit.get_expanded_connectivity("quad", quad_id)
			if len(node_list)==4:
				fid.write(f'4 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} \n')
			elif len(node_list)==8:
				fid.write(f'8 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} {node_id_to_vtk_index[node_list[3]]} {node_id_to_vtk_index[node_list[4]]} {node_id_to_vtk_index[node_list[5]]} {node_id_to_vtk_index[node_list[6]]} {node_id_to_vtk_index[node_list[7]]}\n')
		for edge_id in edge_list:
			node_list = cubit.get_expanded_connectivity("edge", edge_id)
			if len(node_list)==2:
				fid.write(f'2 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} \n')
			elif len(node_list)==3:
				fid.write(f'3 {node_id_to_vtk_index[node_list[0]]} {node_id_to_vtk_index[node_list[1]]} {node_id_to_vtk_index[node_list[2]]} \n')
		for node_id in nodes_list:
			fid.write(f'1 {node_id_to_vtk_index[node_id]} \n')

		fid.write(f'CELL_TYPES {num_cells}\n')
		# VTK cell types based on node count (auto-detection)
		# 1st order: TET=10, HEX=12, WEDGE=13, PYRAMID=14, TRI=5, QUAD=9, LINE=3, POINT=1
		# 2nd order: TET=24, HEX=25, WEDGE=26, PYRAMID=27, TRI=22, QUAD=23, LINE=21
		for tet_id in tet_list:
			fid.write('24\n' if tet_node_counts[tet_id] == 10 else '10\n')
		for hex_id in hex_list:
			fid.write('25\n' if hex_node_counts[hex_id] == 20 else '12\n')
		for wedge_id in wedge_list:
			fid.write('26\n' if wedge_node_counts[wedge_id] == 15 else '13\n')
		for pyramid_id in pyramid_list:
			fid.write('27\n' if pyramid_node_counts[pyramid_id] == 13 else '14\n')
		for tri_id in tri_list:
			fid.write('22\n' if tri_node_counts[tri_id] == 6 else '5\n')
		for quad_id in quad_list:
			fid.write('23\n' if quad_node_counts[quad_id] == 8 else '9\n')
		for edge_id in edge_list:
			fid.write('21\n' if edge_node_counts[edge_id] == 3 else '3\n')
		for node_id in nodes_list:
			fid.write('1\n')
		fid.write(f'CELL_DATA {num_cells}\n')
		fid.write('SCALARS scalars float\n')
		fid.write('LOOKUP_TABLE default\n')
		for tet_id in tet_list:
			fid.write('1\n')
		for hex_id in hex_list:
			fid.write('2\n')
		for wedge_id in wedge_list:
			fid.write('3\n')
		for pyramid_id in pyramid_list:
			fid.write('4\n')
		for tri_id in tri_list:
			fid.write('5\n')
		for quad_id in quad_list:
			fid.write('6\n')
		for edge_id in edge_list:
			fid.write('0\n')
		for node_id in nodes_list:
			fid.write('-1\n')
	return cubit

########################################################################
###	NGSolve/Netgen format
########################################################################

def export_NetgenMesh(cubit, geometry_file: str = None):
	"""Export Cubit mesh to Netgen mesh format.

	Creates a netgen.meshing.Mesh object directly from Cubit mesh data.
	When a geometry file is provided, the mesh can be curved using
	ngsolve.Mesh.Curve(order) for high-order geometry approximation.

	Note: netgen.meshing.Mesh is the core mesh data structure.
	      ngsolve.Mesh is a wrapper/view for FEM analysis.

	Args:
		cubit: Cubit Python interface object
		geometry_file: Path to geometry file (.step, .stp, .brep, .iges) for
		               mesh.Curve() support. If None, mesh is created without
		               geometry reference (Curve() will not work).

	Returns:
		netgen.meshing.Mesh: Netgen mesh object ready for use with NGSolve

	Supported elements:
		- 3D: Tetrahedron (4-node), Hexahedron (8-node), Wedge (6-node), Pyramid (5-node)
		- 2D boundary: Triangle (3-node), Quadrilateral (4-node)
		- 1D boundary: Edge (2-node)

	Usage:
		# Basic usage (1st order mesh with high-order curving)
		ngmesh = export_Netgen(cubit, "geometry.step")
		mesh = ngsolve.Mesh(ngmesh)
		mesh.Curve(3)  # Apply 3rd order curving to boundaries

		# Without geometry (no Curve support)
		ngmesh = export_Netgen(cubit)
		mesh = ngsolve.Mesh(ngmesh)

	Note:
		- Only 1st order elements are transferred; use mesh.Curve(order) for
		  high-order geometry approximation
		- The geometry file should match the geometry used to create the mesh
		- Block names are used as Materials/Boundaries in NGSolve
	"""
	from netgen.meshing import Mesh, MeshPoint, Element3D, Element2D, Element1D, FaceDescriptor
	from netgen.csg import Pnt

	# ============================================================
	# Node ordering conversion tables: Cubit -> Netgen
	# ============================================================

	# Tetrahedron: Cubit [0,1,2,3] -> Netgen [0,1,2,3]
	TET_ORDERING = [0, 1, 2, 3]

	# Hexahedron: Cubit [0,1,2,3,4,5,6,7] -> Netgen [0,1,5,4,3,2,6,7]
	HEX_ORDERING = [0, 1, 5, 4, 3, 2, 6, 7]

	# Wedge/Prism: Cubit [0,1,2,3,4,5] -> Netgen [0,2,1,3,5,4]
	WEDGE_ORDERING = [0, 2, 1, 3, 5, 4]

	# Pyramid: Cubit [0,1,2,3,4] -> Netgen [3,2,1,0,4]
	PYRAMID_ORDERING = [3, 2, 1, 0, 4]

	# Triangle: Cubit [0,1,2] -> Netgen [0,1,2]
	TRI_ORDERING = [0, 1, 2]

	# Quadrilateral: Cubit [0,1,2,3] -> Netgen [0,1,2,3]
	QUAD_ORDERING = [0, 1, 2, 3]

	# ============================================================
	# Create netgen mesh
	# ============================================================

	ngmesh = Mesh(dim=3)

	# Load and attach geometry if provided
	if geometry_file is not None:
		from netgen.occ import OCCGeometry
		geo = OCCGeometry(geometry_file)
		ngmesh.SetGeometry(geo)

	# ============================================================
	# Collect all nodes from blocks
	# ============================================================

	node_map = {}  # Cubit node ID -> netgen point index
	all_nodes = set()

	for block_id in cubit.get_block_id_list():
		elem_types = ["hex", "tet", "wedge", "pyramid", "tri", "face", "edge", "node"]
		for elem_type in elem_types:
			if elem_type == "hex":
				func = getattr(cubit, f"get_block_{elem_type}es")
			else:
				func = getattr(cubit, f"get_block_{elem_type}s")
			for element_id in func(block_id):
				# Use get_connectivity for 1st order nodes only
				node_ids = cubit.get_connectivity(elem_type, element_id)
				all_nodes.update(node_ids)

	# Add nodes to netgen mesh
	for node_id in sorted(all_nodes):
		coord = cubit.get_nodal_coordinates(node_id)
		pnt_idx = ngmesh.Add(MeshPoint(Pnt(coord[0], coord[1], coord[2])))
		node_map[node_id] = pnt_idx

	# ============================================================
	# Add 3D volume elements
	# ============================================================

	material_index = 0

	for block_id in cubit.get_block_id_list():
		block_name = cubit.get_exodus_entity_name("block", block_id)

		tet_list = cubit.get_block_tets(block_id)
		hex_list = cubit.get_block_hexes(block_id)
		wedge_list = cubit.get_block_wedges(block_id)
		pyramid_list = cubit.get_block_pyramids(block_id)

		# Only process blocks with 3D elements
		if len(tet_list) + len(hex_list) + len(wedge_list) + len(pyramid_list) > 0:
			material_index += 1
			ngmesh.SetMaterial(material_index, block_name)

			# Add tetrahedra
			for tet_id in tet_list:
				nodes = cubit.get_connectivity("tet", tet_id)
				ng_nodes = [node_map[nodes[i]] for i in TET_ORDERING]
				ngmesh.Add(Element3D(material_index, ng_nodes))

			# Add hexahedra
			for hex_id in hex_list:
				nodes = cubit.get_connectivity("hex", hex_id)
				ng_nodes = [node_map[nodes[i]] for i in HEX_ORDERING]
				ngmesh.Add(Element3D(material_index, ng_nodes))

			# Add wedges/prisms
			for wedge_id in wedge_list:
				nodes = cubit.get_connectivity("wedge", wedge_id)
				ng_nodes = [node_map[nodes[i]] for i in WEDGE_ORDERING]
				ngmesh.Add(Element3D(material_index, ng_nodes))

			# Add pyramids
			for pyramid_id in pyramid_list:
				nodes = cubit.get_connectivity("pyramid", pyramid_id)
				ng_nodes = [node_map[nodes[i]] for i in PYRAMID_ORDERING]
				ngmesh.Add(Element3D(material_index, ng_nodes))

	# ============================================================
	# Add 2D surface elements (boundary faces)
	# ============================================================

	fd_index = 0

	for block_id in cubit.get_block_id_list():
		block_name = cubit.get_exodus_entity_name("block", block_id)

		tri_list = cubit.get_block_tris(block_id)
		quad_list = cubit.get_block_faces(block_id)

		# Only process blocks with 2D elements
		if len(tri_list) + len(quad_list) > 0:
			fd_index += 1
			fd = FaceDescriptor(bc=fd_index, surfnr=fd_index)
			fd.bcname = block_name
			ngmesh.Add(fd)
			ngmesh.SetBCName(fd_index - 1, block_name)

			# Add triangles
			for tri_id in tri_list:
				nodes = cubit.get_connectivity("tri", tri_id)
				if all(n in node_map for n in nodes):
					ng_nodes = [node_map[nodes[i]] for i in TRI_ORDERING]
					ngmesh.Add(Element2D(fd_index, ng_nodes))

			# Add quadrilaterals
			for quad_id in quad_list:
				nodes = cubit.get_connectivity("quad", quad_id)
				if all(n in node_map for n in nodes):
					ng_nodes = [node_map[nodes[i]] for i in QUAD_ORDERING]
					ngmesh.Add(Element2D(fd_index, ng_nodes))

	# ============================================================
	# Add 1D edge elements (if any)
	# ============================================================

	for block_id in cubit.get_block_id_list():
		block_name = cubit.get_exodus_entity_name("block", block_id)
		edge_list = cubit.get_block_edges(block_id)

		if len(edge_list) > 0:
			fd_index += 1
			fd = FaceDescriptor(bc=fd_index, surfnr=fd_index)
			fd.bcname = block_name
			ngmesh.Add(fd)

			for edge_id in edge_list:
				nodes = cubit.get_connectivity("edge", edge_id)
				if all(n in node_map for n in nodes):
					ng_nodes = [node_map[n] for n in nodes]
					ngmesh.Add(Element1D(ng_nodes, index=fd_index))

	return ngmesh

########################################################################
###	VTK XML format (VTU)
########################################################################

def export_vtu(cubit, FileName: str, binary: bool = False):
	"""Export mesh to VTK XML format (VTU - Unstructured Grid).

	Exports mesh elements from Cubit to VTK XML format (.vtu).
	This is the modern VTK format recommended for ParaView and other tools.
	Automatically detects element order (1st or 2nd) based on node count.

	Args:
		cubit: Cubit Python interface object
		FileName: Output file path for the .vtu file
		binary: If True, write binary data (appended format). Default: False (ASCII)

	Returns:
		cubit: The cubit object (for method chaining)

	Supported elements:
		- 1st order: Tet4, Hex8, Wedge6, Pyramid5, Triangle3, Quad4, Line2, Point
		- 2nd order: Tet10, Hex20, Wedge15, Pyramid13, Triangle6, Quad8, Line3

	VTK XML vs Legacy:
		- XML format is more efficient and extensible
		- Supports compression (when binary=True)
		- Better metadata support
		- Recommended format for modern workflows

	Example:
		cubit_mesh_export.export_vtu(cubit, "mesh.vtu")
		cubit_mesh_export.export_vtu(cubit, "mesh.vtu", binary=True)  # Binary mode
	"""
	import base64
	import struct

	# VTK cell type codes
	VTK_VERTEX = 1
	VTK_LINE = 3
	VTK_QUADRATIC_EDGE = 21
	VTK_TRIANGLE = 5
	VTK_QUADRATIC_TRIANGLE = 22
	VTK_QUAD = 9
	VTK_QUADRATIC_QUAD = 23
	VTK_TETRA = 10
	VTK_QUADRATIC_TETRA = 24
	VTK_HEXAHEDRON = 12
	VTK_QUADRATIC_HEXAHEDRON = 25
	VTK_WEDGE = 13
	VTK_QUADRATIC_WEDGE = 26
	VTK_PYRAMID = 14
	VTK_QUADRATIC_PYRAMID = 27

	# Collect all elements from blocks
	hex_list = set()
	tet_list = set()
	wedge_list = set()
	pyramid_list = set()
	tri_list = set()
	quad_list = set()
	edge_list = set()
	nodes_list = set()
	node_set = set()

	for block_id in cubit.get_block_id_list():
		tet_list.update(cubit.get_block_tets(block_id))
		hex_list.update(cubit.get_block_hexes(block_id))
		wedge_list.update(cubit.get_block_wedges(block_id))
		pyramid_list.update(cubit.get_block_pyramids(block_id))
		tri_list.update(cubit.get_block_tris(block_id))
		quad_list.update(cubit.get_block_faces(block_id))
		edge_list.update(cubit.get_block_edges(block_id))
		nodes_list.update(cubit.get_block_nodes(block_id))

	# Collect all node IDs
	elem_types = ["hex", "tet", "wedge", "pyramid", "tri", "face", "edge", "node"]
	for block_id in cubit.get_block_id_list():
		for elem_type in elem_types:
			if elem_type == "hex":
				func = getattr(cubit, f"get_block_{elem_type}es")
			else:
				func = getattr(cubit, f"get_block_{elem_type}s")
			for element_id in func(block_id):
				node_ids = cubit.get_expanded_connectivity(elem_type, element_id)
				node_set.update(node_ids)

	# Create node ID to VTK index mapping
	node_id_to_vtk_index = {}
	vtk_index = 0
	sorted_nodes = sorted(node_set)
	for node_id in sorted_nodes:
		node_id_to_vtk_index[node_id] = vtk_index
		vtk_index += 1

	# Pre-scan elements for node counts (for auto order detection)
	tet_node_counts = {tet_id: len(cubit.get_expanded_connectivity("tet", tet_id)) for tet_id in tet_list}
	hex_node_counts = {hex_id: len(cubit.get_expanded_connectivity("hex", hex_id)) for hex_id in hex_list}
	wedge_node_counts = {wedge_id: len(cubit.get_expanded_connectivity("wedge", wedge_id)) for wedge_id in wedge_list}
	pyramid_node_counts = {pyramid_id: len(cubit.get_expanded_connectivity("pyramid", pyramid_id)) for pyramid_id in pyramid_list}
	tri_node_counts = {tri_id: len(cubit.get_expanded_connectivity("tri", tri_id)) for tri_id in tri_list}
	quad_node_counts = {quad_id: len(cubit.get_expanded_connectivity("quad", quad_id)) for quad_id in quad_list}
	edge_node_counts = {edge_id: len(cubit.get_expanded_connectivity("edge", edge_id)) for edge_id in edge_list}

	num_points = len(sorted_nodes)
	num_cells = len(tet_list) + len(hex_list) + len(wedge_list) + len(pyramid_list) + len(tri_list) + len(quad_list) + len(edge_list) + len(nodes_list)

	# Build connectivity and offsets arrays
	connectivity = []
	offsets = []
	cell_types = []
	block_ids = []
	current_offset = 0

	# Helper to get VTK type based on element type and node count
	def get_vtk_type(elem_type, node_count):
		if elem_type == "tet":
			return VTK_QUADRATIC_TETRA if node_count == 10 else VTK_TETRA
		elif elem_type == "hex":
			return VTK_QUADRATIC_HEXAHEDRON if node_count == 20 else VTK_HEXAHEDRON
		elif elem_type == "wedge":
			return VTK_QUADRATIC_WEDGE if node_count == 15 else VTK_WEDGE
		elif elem_type == "pyramid":
			return VTK_QUADRATIC_PYRAMID if node_count == 13 else VTK_PYRAMID
		elif elem_type == "tri":
			return VTK_QUADRATIC_TRIANGLE if node_count == 6 else VTK_TRIANGLE
		elif elem_type == "quad":
			return VTK_QUADRATIC_QUAD if node_count == 8 else VTK_QUAD
		elif elem_type == "edge":
			return VTK_QUADRATIC_EDGE if node_count == 3 else VTK_LINE
		else:
			return VTK_VERTEX

	# Process tetrahedra
	for tet_id in tet_list:
		nodes = cubit.get_expanded_connectivity("tet", tet_id)
		vtk_nodes = [node_id_to_vtk_index[n] for n in nodes]
		connectivity.extend(vtk_nodes)
		current_offset += len(nodes)
		offsets.append(current_offset)
		cell_types.append(get_vtk_type("tet", len(nodes)))
		# Find block ID for this element
		for block_id in cubit.get_block_id_list():
			if tet_id in cubit.get_block_tets(block_id):
				block_ids.append(block_id)
				break

	# Process hexahedra
	for hex_id in hex_list:
		nodes = cubit.get_expanded_connectivity("hex", hex_id)
		# HEX20 node reordering: Cubit -> VTK
		if len(nodes) == 20:
			vtk_nodes = [node_id_to_vtk_index[nodes[i]] for i in [0,1,2,3,4,5,6,7,8,9,10,11,16,17,18,19,12,13,14,15]]
		else:
			vtk_nodes = [node_id_to_vtk_index[n] for n in nodes]
		connectivity.extend(vtk_nodes)
		current_offset += len(nodes)
		offsets.append(current_offset)
		cell_types.append(get_vtk_type("hex", len(nodes)))
		for block_id in cubit.get_block_id_list():
			if hex_id in cubit.get_block_hexes(block_id):
				block_ids.append(block_id)
				break

	# Process wedges
	for wedge_id in wedge_list:
		nodes = cubit.get_expanded_connectivity("wedge", wedge_id)
		# WEDGE15 node reordering: Cubit -> VTK
		if len(nodes) == 15:
			vtk_nodes = [node_id_to_vtk_index[nodes[i]] for i in [0,1,2,3,4,5,6,7,8,12,13,14,9,10,11]]
		else:
			vtk_nodes = [node_id_to_vtk_index[n] for n in nodes]
		connectivity.extend(vtk_nodes)
		current_offset += len(nodes)
		offsets.append(current_offset)
		cell_types.append(get_vtk_type("wedge", len(nodes)))
		for block_id in cubit.get_block_id_list():
			if wedge_id in cubit.get_block_wedges(block_id):
				block_ids.append(block_id)
				break

	# Process pyramids
	for pyramid_id in pyramid_list:
		nodes = cubit.get_expanded_connectivity("pyramid", pyramid_id)
		vtk_nodes = [node_id_to_vtk_index[n] for n in nodes]
		connectivity.extend(vtk_nodes)
		current_offset += len(nodes)
		offsets.append(current_offset)
		cell_types.append(get_vtk_type("pyramid", len(nodes)))
		for block_id in cubit.get_block_id_list():
			if pyramid_id in cubit.get_block_pyramids(block_id):
				block_ids.append(block_id)
				break

	# Process triangles
	for tri_id in tri_list:
		nodes = cubit.get_expanded_connectivity("tri", tri_id)
		vtk_nodes = [node_id_to_vtk_index[n] for n in nodes]
		connectivity.extend(vtk_nodes)
		current_offset += len(nodes)
		offsets.append(current_offset)
		cell_types.append(get_vtk_type("tri", len(nodes)))
		for block_id in cubit.get_block_id_list():
			if tri_id in cubit.get_block_tris(block_id):
				block_ids.append(block_id)
				break

	# Process quads
	for quad_id in quad_list:
		nodes = cubit.get_expanded_connectivity("quad", quad_id)
		vtk_nodes = [node_id_to_vtk_index[n] for n in nodes]
		connectivity.extend(vtk_nodes)
		current_offset += len(nodes)
		offsets.append(current_offset)
		cell_types.append(get_vtk_type("quad", len(nodes)))
		for block_id in cubit.get_block_id_list():
			if quad_id in cubit.get_block_faces(block_id):
				block_ids.append(block_id)
				break

	# Process edges
	for edge_id in edge_list:
		nodes = cubit.get_expanded_connectivity("edge", edge_id)
		vtk_nodes = [node_id_to_vtk_index[n] for n in nodes]
		connectivity.extend(vtk_nodes)
		current_offset += len(nodes)
		offsets.append(current_offset)
		cell_types.append(get_vtk_type("edge", len(nodes)))
		for block_id in cubit.get_block_id_list():
			if edge_id in cubit.get_block_edges(block_id):
				block_ids.append(block_id)
				break

	# Process point elements
	for node_id in nodes_list:
		connectivity.append(node_id_to_vtk_index[node_id])
		current_offset += 1
		offsets.append(current_offset)
		cell_types.append(VTK_VERTEX)
		for block_id in cubit.get_block_id_list():
			if node_id in cubit.get_block_nodes(block_id):
				block_ids.append(block_id)
				break

	# Write VTU file
	with open(FileName, 'w', encoding='UTF-8') as fid:
		fid.write('<?xml version="1.0"?>\n')
		fid.write('<VTKFile type="UnstructuredGrid" version="1.0" byte_order="LittleEndian">\n')
		fid.write('  <UnstructuredGrid>\n')
		fid.write(f'    <Piece NumberOfPoints="{num_points}" NumberOfCells="{num_cells}">\n')

		# Points
		fid.write('      <Points>\n')
		fid.write('        <DataArray type="Float64" NumberOfComponents="3" format="ascii">\n')
		for node_id in sorted_nodes:
			coord = cubit.get_nodal_coordinates(node_id)
			fid.write(f'          {coord[0]} {coord[1]} {coord[2]}\n')
		fid.write('        </DataArray>\n')
		fid.write('      </Points>\n')

		# Cells
		fid.write('      <Cells>\n')

		# Connectivity
		fid.write('        <DataArray type="Int64" Name="connectivity" format="ascii">\n')
		fid.write('          ')
		for i, c in enumerate(connectivity):
			fid.write(f'{c} ')
			if (i + 1) % 20 == 0:
				fid.write('\n          ')
		fid.write('\n')
		fid.write('        </DataArray>\n')

		# Offsets
		fid.write('        <DataArray type="Int64" Name="offsets" format="ascii">\n')
		fid.write('          ')
		for i, o in enumerate(offsets):
			fid.write(f'{o} ')
			if (i + 1) % 20 == 0:
				fid.write('\n          ')
		fid.write('\n')
		fid.write('        </DataArray>\n')

		# Cell types
		fid.write('        <DataArray type="UInt8" Name="types" format="ascii">\n')
		fid.write('          ')
		for i, t in enumerate(cell_types):
			fid.write(f'{t} ')
			if (i + 1) % 20 == 0:
				fid.write('\n          ')
		fid.write('\n')
		fid.write('        </DataArray>\n')

		fid.write('      </Cells>\n')

		# Cell Data (Block IDs)
		fid.write('      <CellData Scalars="BlockID">\n')
		fid.write('        <DataArray type="Int32" Name="BlockID" format="ascii">\n')
		fid.write('          ')
		for i, b in enumerate(block_ids):
			fid.write(f'{b} ')
			if (i + 1) % 20 == 0:
				fid.write('\n          ')
		fid.write('\n')
		fid.write('        </DataArray>\n')
		fid.write('      </CellData>\n')

		# Point Data (Node IDs)
		fid.write('      <PointData Scalars="NodeID">\n')
		fid.write('        <DataArray type="Int32" Name="NodeID" format="ascii">\n')
		fid.write('          ')
		for i, node_id in enumerate(sorted_nodes):
			fid.write(f'{node_id} ')
			if (i + 1) % 20 == 0:
				fid.write('\n          ')
		fid.write('\n')
		fid.write('        </DataArray>\n')
		fid.write('      </PointData>\n')

		fid.write('    </Piece>\n')
		fid.write('  </UnstructuredGrid>\n')
		fid.write('</VTKFile>\n')

	return cubit
