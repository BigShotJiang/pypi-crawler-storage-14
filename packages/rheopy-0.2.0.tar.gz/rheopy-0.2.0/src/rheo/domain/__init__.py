"""Domain layer - core business models and exceptions."""

from .downloads import DownloadInfo, DownloadStats, DownloadStatus
from .exceptions import (
    DownloadError,
    DownloadManagerError,
    FileAccessError,
    FileValidationError,
    HashMismatchError,
    ManagerNotInitializedError,
    ProcessQueueError,
    QueueError,
    RetryError,
    ValidationError,
    WorkerError,
)
from .file_config import FileConfig
from .hash_validation import (
    HashAlgorithm,
    HashConfig,
    ValidationState,
    ValidationStatus,
)
from .retry import ErrorCategory, RetryConfig, RetryPolicy

__all__ = [
    # Download Models
    "FileConfig",
    "DownloadInfo",
    "DownloadStatus",
    "ValidationStatus",
    "ValidationState",
    "DownloadStats",
    "HashAlgorithm",
    "HashConfig",
    # Retry Models
    "ErrorCategory",
    "RetryConfig",
    "RetryPolicy",
    # Exceptions
    "DownloadError",
    "DownloadManagerError",
    "ManagerNotInitializedError",
    "ProcessQueueError",
    "QueueError",
    "RetryError",
    "ValidationError",
    "WorkerError",
    "FileValidationError",
    "FileAccessError",
    "HashMismatchError",
]
