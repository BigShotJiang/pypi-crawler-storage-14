# 🚀 upload-socials

Streamline your content workflow by automating video uploads to YouTube with this Python library.

---

## ⚠️ Prerequisites

This is a GUI automation library and **requires a specific setup to function**:

1.  **Screen Resolution:** Your screen resolution should ideally be 1920x1080. The browser window should be maximized.
2.  **Reference Images:** GUI automation works by finding images on the screen. You **must** provide your own folders of reference images (e.g., screenshots of the 'Upload', 'Next', and 'Publish' buttons for YouTube).
3.  **Platform Language:** The YouTube website must be set to English for the default image names to match.

This library is best suited for developers comfortable with tuning GUI automation scripts.

## Installation

```bash
pip install upload-socials
```

## Quick Start

Create a folder for your automation images. For example: `C:\my_automation_images\youtube`. Then, take screenshots of the buttons needed for the upload process and save them in that folder (e.g., `create.png`, `next.png`, `publish.png`).

```python
from upload_socials import upload_youtube

# The absolute path to your folder of reference images for YouTube
YT_IMAGE_PATH = r"C:\\my_automation_images\\youtube"

# Video details
video_file = r"C:\\path\\to\\my_awesome_video.mp4"
video_title = "My First Automated Upload!"
video_desc = "This was uploaded using the upload-socials Python library."
thumb_file = r"C:\\path\\to\\my_thumbnail.png"
video_tags = "python,automation,coding"

# Call the function
upload_youtube(
    filepath=video_file,
    title=video_title,
    image_path=YT_IMAGE_PATH,
    description=video_desc,
    thumbnail=thumb_file,
    tags=video_tags
)
```

## API Overview

-   `upload_youtube(filepath, title, image_path, ...)`

Each function requires an `image_path` argument pointing to a folder containing the necessary `.png` screenshots for its automation tasks.

## License

This project is licensed under the MIT License.

