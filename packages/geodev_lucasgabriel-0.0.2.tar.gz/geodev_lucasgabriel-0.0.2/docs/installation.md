# Installation

## Stable release

To install geodev, run this command in your terminal:

```
pip install geodev
```

This is the preferred method to install geodev, as it will always install the most recent stable release.

If you don't have [pip](https://pip.pypa.io) installed, this [Python installation guide](http://docs.python-guide.org/en/latest/starting/installation/) can guide you through the process.

## From sources

To install geodev from sources, run this command in your terminal:

```
pip install git+https://github.com/lucasgabrielglez-lang/geodev
```
