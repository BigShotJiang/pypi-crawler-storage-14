# AuroCX

AuroCX is a modular Python toolkit that provides:

- Communication services (SMS, Email, Lambda integration)
- AWS helper utilities
- DynamoDB repository base classes
- ID hashing & obfuscation utilities
- URL shortening service
- Common infrastructure modules

AuroCX is designed for scalable backend systems and microservices that need
communication, storage, hashing, and AWS integrations in a consistent structure.

---

## 🚀 Features

### **Communication**
- Base communication service for message handling  
- Extendable for SMS, email, and Lambda-based messaging    

### **AWS Helpers**
- Supports AWS SSM, STS, Lambda, Dynamodb utilities  
- Simplifies common AWS operations  

### **Hashing**
- ID obfuscation using Hashids  
- Extendable hashing service  

### **DynamoDB**
- Base repository pattern  
- Reusable DynamoDB interaction wrapper  

### **URL Shortener**
- Simple URL shortening service  
- Extendable for storage-based or stateless shorteners  

---

## 📦 Installation

Once published to PyPI:

```bash
pip install AuroCX
