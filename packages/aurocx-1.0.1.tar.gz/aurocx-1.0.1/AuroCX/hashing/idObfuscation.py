from aws.services.AWSSSM import SSM
from config.SSMParameters import ssmParameter
from hashids import Hashids

# Replace this with your actual async SSM wrapper
# Example:
class IdObfuscationService:
    def __init__(self):
        self.ssm_service = SSM()
        self.ssm_param = ssmParameter
        self.hash = None
        self.config = None

    async def _load_hashids(self):
        """Loads SSM config and initializes Hashids instance."""
        if self.config and "Salt" in self.config:
            return  # Already loaded

        self.config = await self.ssm_service.get_ssm_parameter(self.ssm_param)

        salt = self.config.get("Salt")
        min_len = int(self.config.get("MinHashLength", 0))

        self.hash = Hashids(salt=salt, min_length=min_len)

    async def encode(self, id_str: str) -> str:
        """
        Encodes a string ID.
        """
        await self._load_hashids()
        return self.hash.encode(int(id_str))  # Hashids needs int

    async def decode(self, encoded_id: str) -> int:
        """
        Decodes an encoded Hashid.
        """
        await self._load_hashids()
        decoded = self.hash.decode(encoded_id)
        return decoded[0] if decoded else None

# Example initialization (adapt to your structure)
hashIds = IdObfuscationService()
