from cfig import Configuration

config = Configuration()


@config.optional()
def DISCORD_COMMAND_PREFIX(value: str = "!") -> str:
	"""
	The command prefix to use for non-slash commands.
	Defaults to `!`.
	"""
	return value


@config.required()
def DISCORD_BOT_TOKEN(value: str) -> str:
	"""
	The token to use to log into the bot.
	Get one at: https://discord.com/developers/applications
	"""
	return value


if __name__ == "__main__":
	config.cli()
