<div align="center">
<img alt="" src="https://forge.steffo.eu/steffo/nortrom/raw/branch/main/.media/icon-512.png" height="128" style="border-radius: 100%;">
<hgroup>
<h1>Nortrom</h1>
<p>Discord bot to mute or deafen entire channels at once</p>
</hgroup>
</div>

## Links

### Use

<a href="https://discord.com/oauth2/authorize?client_id=1282746699772727488">
    <img alt="Add on Discord" title="Add on Discord" src="https://img.shields.io/badge/discord-Nortrom-5865f2" height="30px">
</a>

### Tools

<a href="https://www.python.org/">
	<img alt="Written in Python" title="Written in Python" src="https://img.shields.io/badge/language-python-3775a9" height="30px">
</a>
&hairsp;
<a href="https://discordpy.readthedocs.io/en/stable/">
	<img alt="Uses Discord.py" title="Uses Discord.py" src="https://img.shields.io/badge/discord+api-discord.py-376fa1" height="30px">
</a>

### Packaging

<a href="https://pypi.org/project/nortrom">
	<img alt="Available on PyPI" title="Available on PyPI" src="https://img.shields.io/pypi/v/nortrom?label=pypi&color=ffd242" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/-/packages/pypi/nortrom">
	<img alt="Available on Forgejo Packages" title="Available on Forgejo Packages" src="https://img.shields.io/badge/forgejo%20packages-latest-ff6600" height="30px">
</a>

### Documentation

<a href="https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12">
	<img alt="Licensed under EUPL-1.2" title="Licensed under EUPL-1.2" src="https://img.shields.io/badge/license-EUPL--1.2-003399" height="30px">
</a>

### Development

<a href="https://forge.steffo.eu/steffo/nortrom">
	<img alt="Code repository" title="Code repository" src="https://img.shields.io/gitea/last-commit/steffo/nortrom?gitea_url=https%3A%2F%2Fforge.steffo.eu&color=374351" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/nortrom/releases">
	<img alt="Releases" title="Releases" src="https://img.shields.io/gitea/v/release/steffo/nortrom?gitea_url=https%3A%2F%2Fforge.steffo.eu&label=last+release&color=374351" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/nortrom/issues">
	<img alt="Issues" title="Issues" src="https://img.shields.io/gitea/issues/open/steffo/nortrom?gitea_url=https%3A%2F%2Fforge.steffo.eu&label=issues&color=374351" height="30px">
</a>
&hairsp;
<a href="https://forge.steffo.eu/steffo/nortrom/pulls">
	<img alt="Pull requests" title="Pull requests" src="https://img.shields.io/gitea/pull-requests/open/steffo/nortrom?gitea_url=https%3A%2F%2Fforge.steffo.eu&color=374351" height="30px">
</a>

## Commands

| Command | Effect | Permissions required |
|---------|--------|--------------|
| `/mute` | Server-mutes all users in the channel you're currently in. | Mute Members |
| `/unmute` | Server-unmutes all users in the channel you're currently in. | Mute Members |
| `/deafen` | Server-deafen all users in the channel you're currently in. | Deafen Members |
| `/undeafen` | Server-undeafen all users in the channel you're currently in. | Deafen Members |

## Hosting

Set the `DISCORD_BOT_TOKEN` environment variable to your Discord bot token.

Requires the privileged intents *Presence Intent*, *Server Members Intent* and *Message Content Intent* to be enabled, even if they're not used. Haven't looked into why.
