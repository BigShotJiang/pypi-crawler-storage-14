.. image:: https://img.shields.io/pypi/v/fedora_messaging_the_new_hotness_schema.svg
  :target: https://pypi.org/project/fedora_messaging_the_new_hotness_schema/

.. image:: https://readthedocs.org/projects/the-new-hotness-messaging-schema/badge/?version=latest
  :alt: Documentation Status
  :target: https://the-new-hotness-messaging-schema.readthedocs.io/en/latest/?badge=latest

the-new-hotness Message Schema
==============================

JSON schema definitions for messages published by
`the-new-hotness <https://github.com/fedora-infra/the-new-hotness>`_.

Documentation for the-new-hotness Message Schema could be found
`here <https://the-new-hotness-messaging-schema.readthedocs.io/en/latest>`_.

See http://json-schema.org/ for documentation on the schema format. See
https://fedora-messaging.readthedocs.io/en/latest/messages.html for
documentation on fedora-messaging.
