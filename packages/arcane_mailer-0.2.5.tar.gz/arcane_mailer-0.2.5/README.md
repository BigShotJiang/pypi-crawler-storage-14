# Arcane mailer

This package helps us to send mails