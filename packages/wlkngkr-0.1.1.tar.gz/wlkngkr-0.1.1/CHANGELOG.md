<|start_of_focus|># Changelog

All notable changes will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-11-25

### Added
- Initial release of `wlkngkr` with system + user probes.
- CLI commands for listing and running probes via Typer.
- `ProbeRunner`, Pydantic models, and registry utilities.
- Basic documentation (`docs/`) and pytest smoke tests.

[0.1.0]: https://github.com/cprima-forge/wlkngkr/releases/tag/v0.1.0<|end_of_focus|>
