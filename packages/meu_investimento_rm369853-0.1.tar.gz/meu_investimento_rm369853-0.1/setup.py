from setuptools import setup, find_packages

setup(
   name='meu_investimento_rm369853',
   version='0.1',
   packages=find_packages(),
   install_requires=[],
   author='Paulo Sobral',
   author_email='paulo@paulosobral.com.br',
   description='Uma biblioteca para cálculos de investimentos.',
   url='https://github.com/paulosobral/fiap-pos-tech-ia-para-devs/tree/02-fundamentos-de-ia-e-machine-learning/03-criacao-de-modulos-e-bibliotecas/02-fundamentos-de-ia-e-machine-learning/03-criacao-de-modulos-e-bibliotecas/meu_investimento',
   classifiers=[
       'Programming Language :: Python :: 3',
       'License :: OSI Approved :: MIT License',
       'Operating System :: OS Independent',
   ],
   python_requires='>=3.6',
)