class CzechFabricError(Exception):
    """Base exception for all SDK errors."""


class InvalidAPIKeyError(CzechFabricError):
    """Invalid or unauthorized API key."""


class RateLimitExceededError(CzechFabricError):
    """Rate limit exceeded."""


class ToolExecutionError(CzechFabricError):
    """Generic tool execution failure."""


class NetworkError(CzechFabricError):
    """Networking-related error."""


class InvalidStopNameError(CzechFabricError):
    """Raised when a stop name could not be matched."""


class ValidationError(CzechFabricError):
    """Raised when input validation fails."""


class IncompatibleVersionError(CzechFabricError):
    """Raised when SDK and backend versions are incompatible."""
    def __init__(self, sdk_version: str, backend_version: str, message: str = None):
        self.sdk_version = sdk_version
        self.backend_version = backend_version
        if message is None:
            message = (
                f"SDK version {sdk_version} is incompatible with backend version {backend_version}. "
                f"Please upgrade the SDK to match the backend version."
            )
        super().__init__(message)


class SchemaDriftError(CzechFabricError):
    """Raised when schema drift is detected between SDK and backend."""
    def __init__(self, drift_summary: str, message: str = None):
        self.drift_summary = drift_summary
        if message is None:
            message = f"Schema drift detected: {drift_summary}. Please upgrade the SDK."
        super().__init__(message)