"""
CzechFabric SDK Models - Exact mirror of backend schemas.

All models match the backend definitions in czfb_server/model/schemas.py
and czfb_server/tools/air_quality/services/air_quality_schemas.py
"""
from datetime import datetime
from enum import Enum
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field, computed_field


# ============================================================================
# Core Models - Shared across all tools
# ============================================================================

class Coordinates(BaseModel):
    """Coordinates in decimal degrees (WGS84)."""
    latitude: float = Field(..., description="Latitude in decimal degrees", ge=-90, le=90)
    longitude: float = Field(..., description="Longitude in decimal degrees", ge=-180, le=180)


class TransportMode(str, Enum):
    """Canonical transport mode used across CzechFabric tools."""
    TRAM = "tram"
    METRO = "metro"
    BUS = "bus"
    TRAIN = "train"
    FERRY = "ferry"
    FUNICULAR = "funicular"
    CABLE_CAR = "cable_car"
    GONDOLA = "gondola"
    ALL = "all"  # Optional fallback for 'no filtering'


# ============================================================================
# Geocoding Models
# ============================================================================

class GeocodeResponse(BaseModel):
    """Response from geocoding a place or stop name."""
    coordinates: Optional[Coordinates] = Field(
        None,
        description="Coordinates resolved from the place name, or None if not found"
    )
    speech_response: str = Field(..., description="Natural language summary of the geocoding result")
    fallback: Optional[bool] = Field(None, description="True if fallback method (e.g. Nominatim) was used")


class ReverseGeocodeResult(BaseModel):
    """Detailed reverse geocoding result."""
    road: str = Field(..., description="Name of the road, path, or pedestrian area")
    suburb: str = Field(..., description="Name of the suburb or neighborhood")
    district: str = Field(..., description="Administrative district or city district")
    city: str = Field(..., description="City name")
    state: str = Field(..., description="State or region")
    country: str = Field(..., description="Country name")
    display_name: str = Field(..., description="Full human-readable address for display")
    coordinates: Coordinates = Field(..., description="Coordinates of the reverse-geocoded location")


class ReverseGeocodeResponse(BaseModel):
    """Response from reverse geocoding coordinates."""
    place_name: Optional[str] = Field(None, description="Name of the nearest stop or place")
    coordinates: Optional[Coordinates] = Field(None, description="Coordinates of the resolved location")
    distance_meters: Optional[int] = Field(None, description="Distance from input location to nearest stop (in meters)")
    speech_response: str = Field(..., description="Natural language summary of the reverse geocoding result")


# ============================================================================
# Transport - Stop Models
# ============================================================================

class StopBasic(BaseModel):
    """Basic stop information."""
    stop_id: str = Field(..., description="GTFS stop ID")
    stop_name: str = Field(..., description="Name of the public transport stop")
    coordinates: Coordinates = Field(..., description="Location of the stop")
    zone_id: Optional[str] = Field(None, description="Fare or operational zone ID")


class StopMatch(BaseModel):
    """Detailed stop match information."""
    stop_id: str = Field(..., description="GTFS stop ID (e.g., 'U1234')")
    stop_name: str = Field(..., description="Name of the stop (e.g., 'Dejvická')")
    latitude: Optional[float] = Field(None, description="Latitude of the stop")
    longitude: Optional[float] = Field(None, description="Longitude of the stop")
    zone_id: Optional[str] = Field(None, description="Fare zone ID the stop belongs to")
    stop_url: Optional[str] = Field(None, description="URL with more information about the stop")
    location_type: Optional[int] = Field(None, description="Location type: 0=stop, 1=station, etc.")
    parent_station: Optional[str] = Field(None, description="GTFS ID of parent station, if applicable")
    wheelchair_boarding: Optional[int] = Field(None, description="0=unknown, 1=accessible, 2=not accessible")
    level_id: Optional[str] = Field(None, description="Level ID (for platforms in stations)")
    platform_code: Optional[str] = Field(None, description="Platform identifier (e.g., '2A')")
    asw_node_id: Optional[int] = Field(None, description="Optional internal ID used in ASW systems")
    asw_stop_id: Optional[str] = Field(None, description="Optional ASW stop ID reference")
    zone_region_type: Optional[str] = Field(None, description="Zone region categorization (e.g., 'urban')")
    distance: Optional[float] = Field(None, description="Distance in meters to target point (for sorting)")
    modes: Optional[List[str]] = Field(
        default=None,
        description="List of transport modes available at this stop (e.g., ['tram', 'metro', 'bus'])"
    )


class StopMetadata(BaseModel):
    """Detailed stop metadata."""
    stop_id: str = Field(..., description="GTFS stop ID")
    stop_name: str = Field(..., description="Name of the public transport stop")
    coordinates: Coordinates = Field(..., description="Location of the stop")
    zone_id: Optional[str] = Field(None, description="Zone or fare ID")
    platform_code: Optional[str] = Field(None, description="Platform or track code (if available)")
    stop_desc: Optional[str] = Field(None, description="Additional stop description (if available)")
    location_type: Optional[str] = Field(None, description="Type of location, e.g., stop or station")


class StopMetadataResponse(BaseModel):
    """Response containing stop metadata."""
    metadata: Optional[StopMetadata] = Field(
        None,
        description="Detailed metadata for the requested stop (or None if not found)"
    )
    speech_response: str = Field(..., description="Summary suitable for conversational responses")


class StopListResponse(BaseModel):
    """Response containing a list of stops."""
    count: int = Field(..., description="Total number of matching stops found")
    stops: List[StopBasic] = Field(..., description="List of basic stop information")
    speech_response: str = Field(..., description="Summary for voice/chat output")


class NearbyStop(BaseModel):
    """Information about a nearby stop."""
    stop_id: str = Field(..., description="GTFS stop ID")
    stop_name: str = Field(..., description="Name of the nearby stop")
    coordinates: Coordinates = Field(..., description="Location of the stop")
    distance_meters: Optional[int] = Field(None, description="Distance from the query location in meters")
    modes_available: Optional[List[str]] = Field(
        default=None,
        description="List of available transport modes at the stop (e.g. tram, metro, bus)"
    )
    wheelchair_accessible: Optional[bool] = Field(
        default=None,
        description="Whether the stop supports wheelchair boarding"
    )
    platform_code: Optional[str] = Field(
        default=None,
        description="Platform code or identifier for the stop"
    )


class NearbyStopsResponse(BaseModel):
    """Response containing nearby stops."""
    count: int = Field(..., description="Number of nearby stops found")
    stops: List[NearbyStop] = Field(..., description="List of stops within the search radius")
    speech_response: str = Field(..., description="Natural summary of search results")


# ============================================================================
# Transport - Departure Models
# ============================================================================

class DepartureRequest(BaseModel):
    """Request parameters for departure queries."""
    stop_name: str = Field(..., description="Name of the stop or place")
    when: Optional[str] = Field(None, description="When the user wants to depart (e.g. 'now', 'in 10 minutes')")
    arrive_by: Optional[str] = Field(None, description="Arrival deadline (e.g. 'by 8am')")
    timezone: Optional[str] = Field(None, description="Timezone for interpreting time input (e.g. 'Europe/Prague')")
    mode: Optional[TransportMode] = Field(TransportMode.ALL, description="Transport mode to filter by")
    max_results: Optional[int] = Field(20, ge=1, le=50, description="Maximum number of results to return")


class DepartureTimestamp(BaseModel):
    """Structured departure time information."""
    scheduled: Optional[datetime] = Field(
        None, description="Scheduled departure time in ISO 8601 format"
    )
    predicted: Optional[datetime] = Field(
        None, description="Predicted real-time departure time, if available"
    )
    minutes: Optional[str] = Field(
        None, description="String like '<1' or '5' indicating minutes until departure"
    )


class DepartureItem(BaseModel):
    """Individual departure information."""
    line: str = Field(..., description="Route line number or name (e.g. 191, A, C)")
    headsign: str = Field(..., description="Destination or headsign of the vehicle")
    mode: TransportMode = Field(..., description="Type of transport (e.g. bus, tram, metro)")
    departure_timestamp: DepartureTimestamp = Field(
        ..., description="Structured scheduled/predicted departure times"
    )
    delay_minutes: Optional[int] = Field(
        None, description="Estimated delay in minutes, if known"
    )
    platform: Optional[str] = Field(
        None, description="Platform or stop position (e.g. '2A')"
    )
    coordinates: Optional[Coordinates] = Field(
        None, description="Exact departure location if available"
    )


class SpeechResponse(BaseModel):
    """Structured output for LLMs or UI rendering."""
    structured: List[str] = Field(default_factory=list, description="List of individual departure lines or notes.")
    announcements: List[str] = Field(default_factory=list, description="Extra messages like warnings, tips, or errors.")


class StructuredDepartureResponse(BaseModel):
    """Structured response for departure queries."""
    stop_name: str = Field(..., description="Resolved or matched stop name")
    departures: List[DepartureItem] = Field(
        ..., description="List of upcoming departures from the stop"
    )
    fallback: bool = Field(
        False, description="True if geocoding or API fallback method was used"
    )
    infotexts: Optional[List[str]] = Field(
        default_factory=list,
        description="Optional alerts, notices, or info texts related to the stop"
    )
    alternative_stops: Optional[List[NearbyStop]] = Field(
        default=None,
        description="Structured list of alternative nearby stops with available departures"
    )


# ============================================================================
# Transport - Routing Models
# ============================================================================

class RouteStep(BaseModel):
    """Individual step in a route."""
    text: str = Field(..., description="Human-readable instruction (optional; can be empty if LLM will format)")
    instruction_type: str = Field(
        ...,
        description="Type of navigation instruction, e.g., 'start', 'turn_left', 'continue', 'end'"
    )
    location: Coordinates = Field(..., description="Location coordinates where this step takes place")
    distance_meters: Optional[int] = Field(None, description="Distance covered in this step, in meters")
    estimated_time_seconds: Optional[int] = Field(None, description="Estimated time to complete this step, in seconds")


class MapyRouteStructuredResponse(BaseModel):
    """Structured route response from Mapy.cz."""
    instructions: Optional[List[RouteStep]] = Field(..., description="Structured step-by-step navigation instructions")
    duration_seconds: int = Field(..., description="Total estimated duration of the route in seconds")
    length_meters: int = Field(..., description="Total estimated length of the route in meters")
    geometry: Optional[dict] = Field(None, description="Raw GeoJSON geometry of the route (optional)")
    start_address: Optional[str] = Field(None, description="Resolved name of the starting location (if available)")
    end_address: Optional[str] = Field(None, description="Resolved name of the destination (if available)")
    mapy_url: str = Field(..., description="Mapy.cz shareable URL for visualizing the route")


# ============================================================================
# Air Quality Models
# ============================================================================

class AirQualityComponent(BaseModel):
    """Air quality component measurement."""
    averaged_time: Dict[str, Any] = Field(..., description="Averaging period and value")
    type: str = Field(..., description="Component type code")


class AirQualityMeasurement(BaseModel):
    """Air quality measurement data."""
    AQ_hourly_index: Optional[Union[int, str]] = Field(
        None, description="Air quality index (may be numeric or coded string)"
    )
    components: List[AirQualityComponent] = Field(default_factory=list)


class AirQualityStationProperties(BaseModel):
    """Properties of an air quality station."""
    id: str = Field(..., description="Station identifier")
    district: Optional[str] = Field(None, description="Prague district")
    measurement: Optional[AirQualityMeasurement] = Field(None, description="Current measurements")
    name: str = Field(..., description="Station name")
    updated_at: datetime = Field(..., description="Last update timestamp")


class FeaturePoint(BaseModel):
    """GeoJSON feature point for air quality station."""
    geometry: Dict[str, Any] = Field(..., description="GeoJSON geometry")
    properties: AirQualityStationProperties = Field(..., description="Station properties")
    type: str = Field("Feature", description="GeoJSON type")


class AirQualityStationsResponse(BaseModel):
    """Response containing air quality stations."""
    type: str = Field("FeatureCollection", description="GeoJSON type")
    features: List[FeaturePoint] = Field(..., description="List of air quality stations")


class AirQualityStationComponentType(BaseModel):
    """Component type definition."""
    id: int = Field(..., description="Component type ID")
    component_code: str = Field(..., description="Component code")
    unit: str = Field(..., description="Measurement unit")
    description_cs: str = Field(..., description="Czech description")
    description_en: str = Field(..., description="English description")


class AirQualityStationIndexType(BaseModel):
    """Index type definition."""
    id: int = Field(..., description="Index type ID")
    index_code: str = Field(..., description="Index code")
    limit_gte: float = Field(..., description="Lower bound")
    limit_lt: float = Field(..., description="Upper bound")
    color: str = Field(..., description="Color code")
    color_text: str = Field(..., description="Text color")
    description_cs: str = Field(..., description="Czech description")
    description_en: str = Field(..., description="English description")


class AirQualityStationHistory(BaseModel):
    """Historical air quality measurement."""
    id: str = Field(..., description="Station ID")
    measurement: AirQualityMeasurement = Field(..., description="Historical measurement")
    updated_at: datetime = Field(..., description="Measurement timestamp")


class AirQualitySpeechResponse(BaseModel):
    """Structured speech response for air quality."""
    structured: List[str] = Field(default_factory=list)
    announcements: List[str] = Field(default_factory=list)


class AirQualityStationSummary(BaseModel):
    """Summary of an air quality station."""
    station_id: str = Field(..., description="Station identifier")
    station_name: str = Field(..., description="Station name")
    coordinates: Coordinates = Field(..., description="Station location")
    air_quality_index: Optional[Union[int, str]] = Field(
        None, description="Current AQI (may be numeric or coded string)"
    )
    dominant_pollutant: Optional[str] = Field(None, description="Main pollutant")
    last_updated: datetime = Field(..., description="Last measurement time")
    district: Optional[str] = Field(None, description="Prague district")


class AirQualityResponse(BaseModel):
    """Response containing air quality data."""
    stations: List[AirQualityStationSummary] = Field(..., description="List of air quality stations")
    speech_response: AirQualitySpeechResponse = Field(..., description="Structured response")
    fallback: bool = Field(False, description="True if fallback methods were used")


# ============================================================================
# Request Models (for SDK convenience)
# ============================================================================

class GeocodeRequest(BaseModel):
    """Request for geocoding."""
    name: str = Field(..., description="Name of the place or public transport stop")
    format: str = Field("tone", description="Response format: 'tone', 'json', or 'both'")


class DeparturesByCoordinatesRequest(BaseModel):
    """Request for departures by coordinates."""
    latitude: float = Field(..., ge=-90, le=90, description="Latitude in decimal degrees")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude in decimal degrees")
    search_radius: Optional[float] = Field(500, ge=50, le=2000, description="Maximum search distance in meters")
    max_results: int = Field(20, ge=20, le=50, description="Maximum number of departures to return")
    mode: Optional[TransportMode] = Field(TransportMode.ALL, description="Filter by transport mode")
    when: Optional[str] = Field(None, description="Time you want to depart")
    arrive_by: Optional[str] = Field(None, description="Use this instead of 'when' if you want to arrive *by* a certain time")
    timezone: Optional[str] = Field(None, description="Timezone for interpreting times")
    format: str = Field("tone", description="Response format: 'tone', 'json', or 'both'")


class SuggestDepartureStopsRequest(BaseModel):
    """Request for suggesting nearby departure stops."""
    latitude: float = Field(..., ge=-90, le=90, description="Latitude in decimal degrees")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude in decimal degrees")
    radius: int = Field(500, ge=100, le=2000, description="Search radius in meters")
    mode: Optional[TransportMode] = Field(TransportMode.ALL, description="Transport mode to prioritize")
    when: Optional[str] = Field(None, description="When to depart")
    arrive_by: Optional[str] = Field(None, description="Arrive by time")
    max_suggestions: int = Field(3, ge=1, le=10, description="Maximum number of stops to return")


class PlanRouteRequest(BaseModel):
    """Request for planning a route."""
    from_place: str = Field(..., description="Start location (name or address)")
    to_place: str = Field(..., description="End location (name or address)")
    mode: str = Field("car_fast", description="Routing type (car_fast, foot_fast, etc.)")
    avoid_toll: bool = Field(False, description="Avoid toll roads")
    waypoints: Optional[List[str]] = Field(None, description="Optional waypoints")
    lang: str = Field("cs", description="Output language for metadata (cs or en)")
    format: str = Field("tone", description="Response format: 'tone', 'json', or 'both'")


class AirQualityNearLocationRequest(BaseModel):
    """Request for air quality near a location."""
    location: str = Field(..., description="Location name, address, or landmark in Prague")
    radius_meters: Optional[int] = Field(2000, ge=500, le=10000, description="Search radius in meters")
    format: str = Field("tone", description="Response format: 'tone', 'json', or 'both'")


class AirQualityByDistrictRequest(BaseModel):
    """Request for air quality by district."""
    district: str = Field(..., description="Prague district name or number")
    format: str = Field("tone", description="Response format: 'tone', 'json', or 'both'")


class AirQualityHistoryRequest(BaseModel):
    """Request for air quality history."""
    location: Optional[str] = Field(None, description="Location name or station area")
    station_id: Optional[str] = Field(None, description="Specific station ID if known")
    days_back: Optional[int] = Field(7, ge=1, le=30, description="Number of days to look back")
    format: str = Field("tone", description="Response format: 'tone', 'json', or 'both'")
