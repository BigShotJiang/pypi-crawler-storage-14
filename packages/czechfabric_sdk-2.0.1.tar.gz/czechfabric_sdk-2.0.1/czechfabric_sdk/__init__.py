"""
CzechFabric SDK - Complete Python SDK for CzechFabric MCP tools.

This SDK provides a complete, type-safe interface to all CzechFabric backend tools.
All models and methods match the backend exactly.
"""

from czechfabric_sdk.client import CzechFabricClient, SyncCzechFabricClient
from czechfabric_sdk.exceptions import (
    CzechFabricError,
    InvalidAPIKeyError,
    RateLimitExceededError,
    ToolExecutionError,
    NetworkError,
    InvalidStopNameError,
    ValidationError,
)

# Core models
from czechfabric_sdk.models import (
    Coordinates,
    TransportMode,
    GeocodeResponse,
    ReverseGeocodeResult,
    ReverseGeocodeResponse,
    StopBasic,
    StopMatch,
    StopMetadata,
    StopMetadataResponse,
    StopListResponse,
    NearbyStop,
    NearbyStopsResponse,
    DepartureRequest,
    DepartureTimestamp,
    DepartureItem,
    SpeechResponse,
    StructuredDepartureResponse,
    RouteStep,
    MapyRouteStructuredResponse,
    AirQualityComponent,
    AirQualityMeasurement,
    AirQualityStationProperties,
    FeaturePoint,
    AirQualityStationsResponse,
    AirQualityStationComponentType,
    AirQualityStationIndexType,
    AirQualityStationHistory,
    AirQualitySpeechResponse,
    AirQualityStationSummary,
    AirQualityResponse,
)

from czechfabric_sdk.version import __version__

__version__ = __version__
__all__ = [
    # Client classes
    "CzechFabricClient",
    "SyncCzechFabricClient",
    # Exceptions
    "CzechFabricError",
    "InvalidAPIKeyError",
    "RateLimitExceededError",
    "ToolExecutionError",
    "NetworkError",
    "InvalidStopNameError",
    "ValidationError",
    # Core models
    "Coordinates",
    "TransportMode",
    # Geocoding models
    "GeocodeResponse",
    "ReverseGeocodeResult",
    "ReverseGeocodeResponse",
    # Stop models
    "StopBasic",
    "StopMatch",
    "StopMetadata",
    "StopMetadataResponse",
    "StopListResponse",
    "NearbyStop",
    "NearbyStopsResponse",
    # Departure models
    "DepartureRequest",
    "DepartureTimestamp",
    "DepartureItem",
    "SpeechResponse",
    "StructuredDepartureResponse",
    # Routing models
    "RouteStep",
    "MapyRouteStructuredResponse",
    # Air quality models
    "AirQualityComponent",
    "AirQualityMeasurement",
    "AirQualityStationProperties",
    "FeaturePoint",
    "AirQualityStationsResponse",
    "AirQualityStationComponentType",
    "AirQualityStationIndexType",
    "AirQualityStationHistory",
    "AirQualitySpeechResponse",
    "AirQualityStationSummary",
    "AirQualityResponse",
]

