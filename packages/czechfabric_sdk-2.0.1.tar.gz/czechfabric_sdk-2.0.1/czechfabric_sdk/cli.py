"""
CLI utilities for CzechFabric SDK.
"""
import sys
from czechfabric_sdk.version import __version__


def version():
    """Print SDK version."""
    print(f"CzechFabric SDK v{__version__}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "version":
        version()
    else:
        print("Usage: czechfabric-sdk-version")

