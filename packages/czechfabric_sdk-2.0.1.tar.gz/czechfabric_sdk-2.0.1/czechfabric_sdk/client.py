"""
CzechFabric SDK Client - Complete implementation of all backend tools.

This client provides both sync and async interfaces for all CzechFabric MCP tools.
All methods match the backend tool signatures exactly.
"""
import asyncio
import json
from typing import Optional, List, Dict, Any, Union
from functools import wraps

from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport
from fastmcp.client.auth import BearerAuth
from fastmcp.exceptions import ToolError
from mcp import Tool

import httpx

from czechfabric_sdk.exceptions import (
    NetworkError,
    InvalidAPIKeyError,
    RateLimitExceededError,
    ToolExecutionError,
    ValidationError,
    IncompatibleVersionError,
    SchemaDriftError,
)
from czechfabric_sdk.version import (
    __version__ as SDK_VERSION,
    SDK_BACKEND_COMPAT_VERSION,
    MIN_BACKEND_VERSION,
)
from czechfabric_sdk.logging_config import logger
from czechfabric_sdk.models import (
    # Core models
    Coordinates,
    TransportMode,
    # Request models
    GeocodeRequest,
    DepartureRequest,
    DeparturesByCoordinatesRequest,
    SuggestDepartureStopsRequest,
    PlanRouteRequest,
    AirQualityNearLocationRequest,
    AirQualityByDistrictRequest,
    AirQualityHistoryRequest,
    # Response models
    GeocodeResponse,
    ReverseGeocodeResponse,
    StructuredDepartureResponse,
    NearbyStop,
    NearbyStopsResponse,
    StopMetadataResponse,
    StopListResponse,
    MapyRouteStructuredResponse,
)


def retry(max_attempts: int = 3, backoff_factor: float = 0.5):
    """Retry decorator for network operations."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            delay = backoff_factor
            attempt = 1
            while True:
                try:
                    return await func(*args, **kwargs)
                except (httpx.HTTPError, ToolError) as e:
                    if attempt >= max_attempts:
                        logger.error(f"Exceeded max retries ({max_attempts}).")
                        raise NetworkError(f"Operation failed after {max_attempts} attempts.") from e
                    logger.warning(f"Attempt {attempt} failed ({e}); retrying in {delay}s...")
                    await asyncio.sleep(delay)
                    delay *= 2
                    attempt += 1
        return wrapper
    return decorator


class CzechFabricClient:
    """
    Async client for CzechFabric MCP tools.
    
    Provides complete access to all backend tools with proper validation,
    error handling, and typed responses.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: float = 30.0,
        default_format: str = "tone",
        check_version: bool = True,
        strict_mode: bool = False
    ) -> None:
        """
        Initialize the CzechFabric client.
        
        Args:
            api_key: Your CzechFabric API key
            base_url: Base URL of the CzechFabric MCP server
            timeout: Request timeout in seconds
            default_format: Default response format ("tone", "json", or "both")
            check_version: Whether to check backend version compatibility on init
            strict_mode: If True, refuse to run if version mismatch or schema drift detected
        """
        if not api_key:
            raise ValueError("API key required.")
        if not base_url:
            raise ValueError("Base URL required.")
        if default_format not in ("tone", "json", "both"):
            raise ValueError("default_format must be 'tone', 'json', or 'both'")

        self._transport = StreamableHttpTransport(
            url=base_url,
            auth=BearerAuth(api_key),
        )
        self._client = Client(self._transport, timeout=timeout)
        self._default_format = default_format
        self._base_url = base_url
        self._api_key = api_key
        self._strict_mode = strict_mode
        self._backend_version = None
        self._version_checked = False
        
        # Initialize helper tools (lazy import to avoid circular dependencies)
        try:
            from czechfabric_sdk.tools.transport import TransportTools, RoutingTools
            from czechfabric_sdk.tools.air_quality import AirQualityTools
            self.tools = type('Tools', (), {
                'transport': TransportTools(self),
                'routing': RoutingTools(self),
                'air_quality': AirQualityTools(self),
            })()
        except ImportError:
            # Fallback if tools module not available
            self.tools = None
        
        if check_version:
            # Version check will be done lazily on first tool call
            # to avoid blocking initialization
            pass

    async def _check_version_compatibility(self) -> None:
        """Check backend version compatibility."""
        if self._version_checked:
            return
        
        try:
            # Try to get backend version from metadata endpoint
            # If not available, we'll check tool list for compatibility
            async with self._client:
                tools = await self._client.list_tools()
                # For now, we'll use tool count as a proxy for version
                # In future, backend should expose /version endpoint
                expected_tool_count = 13
                actual_tool_count = len(tools)
                
                if actual_tool_count != expected_tool_count:
                    drift_msg = (
                        f"Tool count mismatch: SDK expects {expected_tool_count} tools, "
                        f"backend has {actual_tool_count} tools. "
                        f"This may indicate a version mismatch."
                    )
                    
                    if self._strict_mode:
                        raise SchemaDriftError(drift_msg)
                    else:
                        logger.warning(drift_msg)
                        logger.warning(
                            f"SDK version {SDK_VERSION} may not be fully compatible. "
                            f"Consider upgrading the SDK."
                        )
                
                self._version_checked = True
                
        except Exception as e:
            if self._strict_mode:
                raise IncompatibleVersionError(
                    SDK_VERSION,
                    "unknown",
                    f"Could not verify backend compatibility: {e}"
                )
            else:
                logger.warning(f"Version check failed: {e}. Continuing anyway.")

    async def _check_schema_drift(self) -> None:
        """Check for schema drift by comparing tool signatures."""
        try:
            async with self._client:
                tools = await self._client.list_tools()
                tool_names = {tool.name for tool in tools}
                
                # Expected tools from ground truth audit
                expected_tools = {
                    "get_departures",
                    "departures_by_coordinates",
                    "suggest_departure_stops_nearby",
                    "geocode",
                    "reverse_geocode",
                    "list_all_stops",
                    "get_stop_metadata",
                    "find_all_stops_near",
                    "plan_route_mapycz",
                    "get_air_quality_near_location",
                    "get_air_quality_by_district",
                    "get_air_quality_history",
                    "list_air_quality_components",
                }
                
                missing_tools = expected_tools - tool_names
                extra_tools = tool_names - expected_tools
                
                drift_summary_parts = []
                if missing_tools:
                    drift_summary_parts.append(f"Missing tools: {', '.join(missing_tools)}")
                if extra_tools:
                    drift_summary_parts.append(f"Extra tools: {', '.join(extra_tools)}")
                
                if drift_summary_parts:
                    drift_summary = "; ".join(drift_summary_parts)
                    if self._strict_mode:
                        raise SchemaDriftError(drift_summary)
                    else:
                        logger.warning(f"Schema drift detected: {drift_summary}")
                        logger.warning("Consider upgrading the SDK to match the backend.")
                        
        except SchemaDriftError:
            raise
        except Exception as e:
            if self._strict_mode:
                raise SchemaDriftError(f"Could not check schema drift: {e}")
            else:
                logger.warning(f"Schema drift check failed: {e}. Continuing anyway.")

    @retry(max_attempts=3, backoff_factor=0.75)
    async def _call_tool(
        self,
        name: str,
        params: dict,
        cache: bool = False
    ) -> dict:
        """Internal method to call an MCP tool."""
        # Perform version and schema checks on first call
        if not self._version_checked:
            await self._check_version_compatibility()
            await self._check_schema_drift()
        
        if cache:
            from czechfabric_sdk.cache import cache_tool_call
            return await cache_tool_call(name, tuple(sorted(params.items())))

        async with self._client:
            try:
                logger.info(f"Calling tool '{name}' with {params}")
                result = await self._client.call_tool(name, params)
                logger.debug(f"Tool '{name}' response: {result.data}")
                return result.data
            except ToolError as e:
                msg = str(e).lower()
                if "unauthorized" in msg or "forbidden" in msg:
                    raise InvalidAPIKeyError("Invalid API key.") from e
                if "rate limit" in msg or "too many requests" in msg:
                    raise RateLimitExceededError("Rate limit exceeded.") from e
                raise ToolExecutionError(f"Tool '{name}' failed: {e}") from e

    # ========================================================================
    # Transport Tools - Departures
    # ========================================================================

    async def get_departures(
        self,
        stop_name: str,
        when: Optional[str] = None,
        arrive_by: Optional[str] = None,
        mode: Optional[TransportMode] = None,
        max_results: Optional[int] = 20,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], StructuredDepartureResponse]:
        """
        Get real-time public transport departures with advanced options.
        
        Args:
            stop_name: Stop name or landmark (e.g. 'Anděl metro', 'Main Station')
            when: Departure time (e.g. 'now', 'in 30 mins', 'at 8pm')
            arrive_by: Arrival deadline (e.g. 'by 9am', 'at 14:30', 'in 1 hour')
            mode: Filter by transport mode
            max_results: Maximum number of departures to return (1–50)
            format: Response format: 'tone', 'json', or 'both' (defaults to client default)
        
        Returns:
            StructuredDepartureResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if max_results is not None and (max_results < 1 or max_results > 50):
            raise ValidationError("max_results must be between 1 and 50")
        
        params = {
            "stop_name": stop_name.strip(),
            "format": format
        }
        
        if when is not None:
            params["when"] = when
        if arrive_by is not None:
            params["arrive_by"] = arrive_by
        if mode is not None:
            params["mode"] = mode.value if isinstance(mode, TransportMode) else mode
        if max_results is not None:
            params["max_results"] = max_results
        
        result = await self._call_tool("get_departures", params)
        
        # Parse response based on format
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return StructuredDepartureResponse(**result) if isinstance(result, dict) else result

    async def departures_by_coordinates(
        self,
        latitude: float,
        longitude: float,
        search_radius: Optional[float] = 500,
        max_results: int = 20,
        mode: Optional[TransportMode] = None,
        when: Optional[str] = None,
        arrive_by: Optional[str] = None,
        timezone: Optional[str] = None,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], StructuredDepartureResponse]:
        """
        Find nearest public transport stop by GPS coordinates and show upcoming departures.
        
        Args:
            latitude: Latitude in decimal degrees (WGS84)
            longitude: Longitude in decimal degrees (WGS84)
            search_radius: Maximum search distance in meters (default 500m, max 2000m)
            max_results: Maximum number of departures to return (20–50)
            mode: Filter by transport mode (e.g. bus, tram, metro, train)
            when: Time you want to depart (e.g. '5 PM', 'now', 'in 10 minutes')
            arrive_by: Use this instead of 'when' if you want to arrive *by* a certain time
            timezone: Timezone for interpreting times (default is Europe/Prague)
            format: Response format: 'tone', 'json', or 'both'
        
        Returns:
            StructuredDepartureResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not (-90 <= latitude <= 90):
            raise ValidationError("latitude must be between -90 and 90")
        if not (-180 <= longitude <= 180):
            raise ValidationError("longitude must be between -180 and 180")
        if search_radius is not None and (search_radius < 50 or search_radius > 2000):
            raise ValidationError("search_radius must be between 50 and 2000 meters")
        if not (20 <= max_results <= 50):
            raise ValidationError("max_results must be between 20 and 50")
        
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "max_results": max_results,
            "format": format
        }
        
        if search_radius is not None:
            params["search_radius"] = search_radius
        if mode is not None:
            params["mode"] = mode.value if isinstance(mode, TransportMode) else mode
        if when is not None:
            params["when"] = when
        if arrive_by is not None:
            params["arrive_by"] = arrive_by
        if timezone is not None:
            params["timezone"] = timezone
        
        result = await self._call_tool("departures_by_coordinates", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return StructuredDepartureResponse(**result) if isinstance(result, dict) else result

    async def suggest_departure_stops_nearby(
        self,
        latitude: float,
        longitude: float,
        radius: int = 500,
        mode: Optional[TransportMode] = None,
        when: Optional[str] = None,
        arrive_by: Optional[str] = None,
        max_suggestions: int = 3
    ) -> List[NearbyStop]:
        """
        Suggest nearby stops with departures and metadata like modes, accessibility, and distance.
        
        Args:
            latitude: Latitude in decimal degrees
            longitude: Longitude in decimal degrees
            radius: Search radius in meters (default: 500, max: 2000)
            mode: Transport mode to prioritize (e.g. tram, bus)
            when: When to depart (e.g. 'now', 'in 10 minutes')
            arrive_by: Arrive by time (e.g. 'at 9:00')
            max_suggestions: Maximum number of stops to return (1-10)
        
        Returns:
            List of NearbyStop objects
        """
        if not (-90 <= latitude <= 90):
            raise ValidationError("latitude must be between -90 and 90")
        if not (-180 <= longitude <= 180):
            raise ValidationError("longitude must be between -180 and 180")
        if not (100 <= radius <= 2000):
            raise ValidationError("radius must be between 100 and 2000 meters")
        if not (1 <= max_suggestions <= 10):
            raise ValidationError("max_suggestions must be between 1 and 10")
        
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "radius": radius,
            "max_suggestions": max_suggestions
        }
        
        if mode is not None:
            params["mode"] = mode.value if isinstance(mode, TransportMode) else mode
        if when is not None:
            params["when"] = when
        if arrive_by is not None:
            params["arrive_by"] = arrive_by
        
        result = await self._call_tool("suggest_departure_stops_nearby", params)
        
        # Parse list of NearbyStop objects
        if isinstance(result, list):
            return [NearbyStop(**item) if isinstance(item, dict) else item for item in result]
        return []

    # ========================================================================
    # Transport Tools - Geocoding
    # ========================================================================

    async def geocode(
        self,
        name: str,
        format: Optional[str] = None,
        use_cache: bool = True
    ) -> Union[str, Dict[str, Any], GeocodeResponse]:
        """
        Convert a place or stop name into coordinates using GTFS matching or OpenStreetMap fallback.
        
        Args:
            name: Name of the place or public transport stop (e.g., 'Florenc')
            format: Response format: 'tone', 'json', or 'both' (defaults to client default)
            use_cache: Whether to use cached results
        
        Returns:
            GeocodeResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not name or not name.strip():
            raise ValidationError("name cannot be empty")
        
        params = {
            "name": name.strip(),
            "format": format
        }
        
        result = await self._call_tool("geocode", params, cache=use_cache)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return GeocodeResponse(**result) if isinstance(result, dict) else result

    async def reverse_geocode(
        self,
        latitude: float,
        longitude: float,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "ReverseGeocodeResponse"]:
        """
        Find the nearest known public transport stop to a given coordinate.
        
        Args:
            latitude: Latitude in decimal degrees
            longitude: Longitude in decimal degrees
            format: Response format: 'tone', 'json', or 'both' (defaults to client default)
        
        Returns:
            ReverseGeocodeResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not (-90 <= latitude <= 90):
            raise ValidationError("latitude must be between -90 and 90")
        if not (-180 <= longitude <= 180):
            raise ValidationError("longitude must be between -180 and 180")
        
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "format": format
        }
        
        result = await self._call_tool("reverse_geocode", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            from czechfabric_sdk.models import ReverseGeocodeResponse
            return ReverseGeocodeResponse(**result) if isinstance(result, dict) else result

    # ========================================================================
    # Transport Tools - Stop Management
    # ========================================================================

    async def find_all_stops_near(
        self,
        latitude: float,
        longitude: float,
        radius: int = 500,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "NearbyStopsResponse"]:
        """
        Find all public transport stops within a radius around coordinates.
        
        Args:
            latitude: Latitude in decimal degrees
            longitude: Longitude in decimal degrees
            radius: Search radius in meters (default 500)
            format: Response format: 'tone', 'json', or 'both' (defaults to client default)
        
        Returns:
            NearbyStopsResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not (-90 <= latitude <= 90):
            raise ValidationError("latitude must be between -90 and 90")
        if not (-180 <= longitude <= 180):
            raise ValidationError("longitude must be between -180 and 180")
        if radius < 0:
            raise ValidationError("radius must be non-negative")
        
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "radius": radius,
            "format": format
        }
        
        result = await self._call_tool("find_all_stops_near", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            from czechfabric_sdk.models import NearbyStopsResponse
            return NearbyStopsResponse(**result) if isinstance(result, dict) else result

    async def get_stop_metadata(
        self,
        stop_id: Optional[str] = None,
        stop_name: Optional[str] = None,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "StopMetadataResponse"]:
        """
        Retrieve metadata for a specific stop by GTFS stop ID or name.
        
        Args:
            stop_id: Exact GTFS stop ID (e.g., 'U1234')
            stop_name: Fuzzy name match (e.g., 'Dejvická')
            format: Response format: 'tone', 'json', or 'both' (defaults to client default)
        
        Returns:
            StopMetadataResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not stop_id and not stop_name:
            raise ValidationError("Either stop_id or stop_name must be provided")
        
        params = {
            "format": format
        }
        
        if stop_id is not None:
            params["stop_id"] = stop_id.strip()
        if stop_name is not None:
            params["stop_name"] = stop_name.strip()
        
        result = await self._call_tool("get_stop_metadata", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            from czechfabric_sdk.models import StopMetadataResponse
            return StopMetadataResponse(**result) if isinstance(result, dict) else result

    async def list_all_stops(
        self,
        name_contains: Optional[str] = None,
        zone: Optional[str] = None,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "StopListResponse"]:
        """
        List all known public transport stops, optionally filtered by name or zone.
        
        Args:
            name_contains: Partial match of stop name
            zone: Exact zone ID to filter by
            format: Response format: 'tone', 'json', or 'both' (defaults to client default)
        
        Returns:
            StopListResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        params = {
            "format": format
        }
        
        if name_contains is not None:
            params["name_contains"] = name_contains.strip()
        if zone is not None:
            params["zone"] = zone.strip()
        
        result = await self._call_tool("list_all_stops", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            from czechfabric_sdk.models import StopListResponse
            return StopListResponse(**result) if isinstance(result, dict) else result

    # ========================================================================
    # Transport Tools - Routing
    # ========================================================================

    async def plan_route_mapycz(
        self,
        from_place: str,
        to_place: str,
        mode: str = "car_fast",
        avoid_toll: bool = False,
        waypoints: Optional[List[str]] = None,
        lang: str = "cs",
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], MapyRouteStructuredResponse]:
        """
        Plan a route using Mapy.cz and get fully structured step-by-step instructions.
        
        Args:
            from_place: Start location (name or address)
            to_place: End location (name or address)
            mode: Routing type (car_fast, car_fast_traffic, car_short, bike_road, bike_mountain, foot_fast)
            avoid_toll: Avoid toll roads
            waypoints: Optional list of waypoint addresses
            lang: Output language for metadata (cs or en)
            format: Response format: 'tone', 'json', or 'both'
        
        Returns:
            MapyRouteStructuredResponse or formatted string/dict based on format parameter
        """
        if format is None:
            format = self._default_format
        
        valid_modes = {
            "car_fast", "car_fast_traffic", "car_short",
            "bike_road", "bike_mountain", "foot_fast"
        }
        if mode not in valid_modes:
            raise ValidationError(f"mode must be one of {valid_modes}")
        
        if lang not in ("cs", "en"):
            raise ValidationError("lang must be 'cs' or 'en'")
        
        params = {
            "from_place": from_place.strip(),
            "to_place": to_place.strip(),
            "mode": mode,
            "avoid_toll": avoid_toll,
            "lang": lang,
            "format": format
        }
        
        if waypoints is not None:
            params["waypoints"] = waypoints
        
        result = await self._call_tool("plan_route_mapycz", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return MapyRouteStructuredResponse(**result) if isinstance(result, dict) else result

    # ========================================================================
    # Air Quality Tools
    # ========================================================================

    async def get_air_quality_near_location(
        self,
        location: str,
        radius_meters: Optional[int] = 2000,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """
        Get current air quality index and main pollutants near a specific location in Prague.
        
        Args:
            location: Location name, address, or landmark in Prague
            radius_meters: Search radius in meters (default: 2000m = 2km, min: 500, max: 10000)
            format: Response format: 'tone', 'json', or 'both'
        
        Returns:
            Dict with air quality data or formatted string based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not location or not location.strip():
            raise ValidationError("location cannot be empty")
        if radius_meters is not None and (radius_meters < 500 or radius_meters > 10000):
            raise ValidationError("radius_meters must be between 500 and 10000 meters")
        
        params = {
            "location": location.strip(),
            "format": format
        }
        
        if radius_meters is not None:
            params["radius_meters"] = radius_meters
        
        result = await self._call_tool("get_air_quality_near_location", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return result

    async def get_air_quality_by_district(
        self,
        district: str,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """
        Get aggregated air quality information for a specific Prague district.
        
        Args:
            district: Prague district name or number (e.g., 'Praha 1', 'Praha 11', 'Vinohrady')
            format: Response format: 'tone', 'json', or 'both'
        
        Returns:
            Dict with air quality data or formatted string based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not district or not district.strip():
            raise ValidationError("district cannot be empty")
        
        params = {
            "district": district.strip(),
            "format": format
        }
        
        result = await self._call_tool("get_air_quality_by_district", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return result

    async def get_air_quality_history(
        self,
        location: Optional[str] = None,
        station_id: Optional[str] = None,
        days_back: Optional[int] = 7,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """
        Get historical air quality data and pollution trends for analysis.
        
        Args:
            location: Location name or station area (e.g., 'Chodov', 'Anděl')
            station_id: Specific station ID if known (e.g., 'ACHOA')
            days_back: Number of days to look back (default: 7, min: 1, max: 30)
            format: Response format: 'tone', 'json', or 'both'
        
        Returns:
            Dict with historical air quality data or formatted string based on format parameter
        """
        if format is None:
            format = self._default_format
        
        if not location and not station_id:
            raise ValidationError("Either location or station_id must be provided")
        if days_back is not None and (days_back < 1 or days_back > 30):
            raise ValidationError("days_back must be between 1 and 30")
        
        params = {
            "format": format
        }
        
        if location is not None:
            params["location"] = location.strip()
        if station_id is not None:
            params["station_id"] = station_id.strip()
        if days_back is not None:
            params["days_back"] = days_back
        
        result = await self._call_tool("get_air_quality_history", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return result

    async def list_air_quality_components(
        self,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """
        Get information about all pollutants measured in Prague's air quality monitoring.
        
        Args:
            format: Response format: 'tone', 'json', or 'both'
        
        Returns:
            Dict with pollutant information or formatted string based on format parameter
        """
        if format is None:
            format = self._default_format
        
        params = {
            "format": format
        }
        
        result = await self._call_tool("list_air_quality_components", params)
        
        if format == "json":
            return result
        elif format == "tone":
            return result if isinstance(result, str) else json.dumps(result)
        else:  # both
            return result

    # ========================================================================
    # Tool Discovery and Metadata
    # ========================================================================

    @retry(max_attempts=3, backoff_factor=0.75)
    async def list_tools(self) -> List[Tool]:
        """
        List all available tools from the MCP server.
        
        Returns:
            List of Tool objects with metadata
        """
        async with self._client:
            try:
                tools = await self._client.list_tools()
                logger.info(f"Fetched {len(tools)} tools.")
                return tools
            except Exception as e:
                logger.error(f"Tool listing failed: {e}")
                raise NetworkError("Failed to fetch list of tools.") from e

    async def get_tool_names(self) -> List[str]:
        """
        Get list of available tool names.
        
        Returns:
            List of tool name strings
        """
        tools = await self.list_tools()
        return [tool.name for tool in tools]

    async def get_tool_prompt_summary(self) -> str:
        """
        Get a formatted summary of all available tools for LLM prompts.
        
        Returns:
            Formatted string with tool descriptions
        """
        tools = await self.list_tools()
        if not tools:
            return "No tools available."

        summary = "🧰 Available Tools:\n"
        for tool in tools:
            description = tool.description or "No description available."
            summary += f"• **{tool.name}**: {description}\n"
        return summary

    async def get_tool_by_name(self, name: str) -> Optional[Tool]:
        """
        Get a specific tool by name.
        
        Args:
            name: Tool name to look up
        
        Returns:
            Tool object if found, None otherwise
        """
        tools = await self.list_tools()
        for tool in tools:
            if tool.name == name:
                return tool
        return None


# ============================================================================
# Sync Wrapper (for convenience)
# ============================================================================

class SyncCzechFabricClient:
    """
    Synchronous wrapper around CzechFabricClient.
    
    Uses asyncio.run() to execute async methods in a sync context.
    Note: This creates a new event loop for each call, which may not be optimal
    for high-performance use cases. Prefer the async client when possible.
    """
    
    def __init__(self, *args, **kwargs):
        """Initialize with same parameters as CzechFabricClient."""
        self._client = CzechFabricClient(*args, **kwargs)
    
    def __getattr__(self, name):
        """Delegate all method calls to async client with sync wrapper."""
        attr = getattr(self._client, name)
        if not callable(attr):
            return attr
        
        def sync_wrapper(*args, **kwargs):
            return asyncio.run(attr(*args, **kwargs))
        
        return sync_wrapper
