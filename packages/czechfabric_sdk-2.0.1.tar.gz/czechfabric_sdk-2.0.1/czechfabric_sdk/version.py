"""
Version information and compatibility tracking.
"""
# SDK version - increment according to semantic versioning
__version__ = "2.0.1"

# Backend compatibility version
# This should match the minimum backend version this SDK supports
SDK_BACKEND_COMPAT_VERSION = "2.0.0"

# Minimum backend version required
MIN_BACKEND_VERSION = "2.0.0"

# Maximum backend version tested (for compatibility warnings)
MAX_BACKEND_VERSION_TESTED = "2.0.0"

