"""
Developer-friendly tool helpers organized by domain.

These helpers provide convenient access to tools grouped by functionality.
All helpers wrap the real backend tools - no fake functionality.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from czechfabric_sdk.client import CzechFabricClient

# Import tool helper classes
from czechfabric_sdk.tools.transport import TransportTools, RoutingTools
from czechfabric_sdk.tools.air_quality import AirQualityTools

__all__ = [
    "TransportTools",
    "RoutingTools",
    "AirQualityTools",
]

