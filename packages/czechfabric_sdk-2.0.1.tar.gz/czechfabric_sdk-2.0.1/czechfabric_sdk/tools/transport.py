"""
Transport tools helper - convenient access to transport-related tools.
"""
from typing import TYPE_CHECKING, Optional, List, Union, Dict, Any

if TYPE_CHECKING:
    from czechfabric_sdk.client import CzechFabricClient
    from czechfabric_sdk.models import (
        TransportMode,
        StructuredDepartureResponse,
        NearbyStop,
        GeocodeResponse,
        ReverseGeocodeResponse,
        StopListResponse,
        StopMetadataResponse,
        NearbyStopsResponse,
        MapyRouteStructuredResponse,
    )


class TransportTools:
    """Helper class for transport-related tools."""
    
    def __init__(self, client: "CzechFabricClient"):
        self._client = client
    
    async def get_departures(
        self,
        stop_name: str,
        when: Optional[str] = None,
        arrive_by: Optional[str] = None,
        mode: Optional["TransportMode"] = None,
        max_results: Optional[int] = 20,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "StructuredDepartureResponse"]:
        """Get real-time departures from a stop."""
        return await self._client.get_departures(
            stop_name=stop_name,
            when=when,
            arrive_by=arrive_by,
            mode=mode,
            max_results=max_results,
            format=format
        )
    
    async def get_departures_by_location(
        self,
        latitude: float,
        longitude: float,
        search_radius: Optional[float] = 500,
        max_results: int = 20,
        mode: Optional["TransportMode"] = None,
        when: Optional[str] = None,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "StructuredDepartureResponse"]:
        """Get departures from nearest stop to coordinates."""
        return await self._client.departures_by_coordinates(
            latitude=latitude,
            longitude=longitude,
            search_radius=search_radius,
            max_results=max_results,
            mode=mode,
            when=when,
            format=format
        )
    
    async def find_nearby_stops(
        self,
        latitude: float,
        longitude: float,
        radius: int = 500,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "NearbyStopsResponse"]:
        """Find all stops within a radius."""
        return await self._client.find_all_stops_near(
            latitude=latitude,
            longitude=longitude,
            radius=radius,
            format=format
        )
    
    async def suggest_stops(
        self,
        latitude: float,
        longitude: float,
        radius: int = 500,
        mode: Optional["TransportMode"] = None,
        max_suggestions: int = 3
    ) -> List["NearbyStop"]:
        """Suggest nearby stops with departures."""
        return await self._client.suggest_departure_stops_nearby(
            latitude=latitude,
            longitude=longitude,
            radius=radius,
            mode=mode,
            max_suggestions=max_suggestions
        )
    
    async def geocode(self, name: str, format: Optional[str] = None) -> Union[str, Dict[str, Any], "GeocodeResponse"]:
        """Convert place name to coordinates."""
        return await self._client.geocode(name=name, format=format)
    
    async def reverse_geocode(
        self,
        latitude: float,
        longitude: float,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "ReverseGeocodeResponse"]:
        """Find nearest stop to coordinates."""
        return await self._client.reverse_geocode(latitude=latitude, longitude=longitude, format=format)
    
    async def get_stop_info(
        self,
        stop_id: Optional[str] = None,
        stop_name: Optional[str] = None,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "StopMetadataResponse"]:
        """Get detailed stop metadata."""
        return await self._client.get_stop_metadata(stop_id=stop_id, stop_name=stop_name, format=format)
    
    async def list_stops(
        self,
        name_contains: Optional[str] = None,
        zone: Optional[str] = None,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "StopListResponse"]:
        """List all stops with optional filters."""
        return await self._client.list_all_stops(name_contains=name_contains, zone=zone, format=format)


class RoutingTools:
    """Helper class for routing tools."""
    
    def __init__(self, client: "CzechFabricClient"):
        self._client = client
    
    async def plan_route(
        self,
        from_place: str,
        to_place: str,
        mode: str = "car_fast",
        avoid_toll: bool = False,
        waypoints: Optional[List[str]] = None,
        lang: str = "cs",
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any], "MapyRouteStructuredResponse"]:
        """Plan a route using Mapy.cz."""
        return await self._client.plan_route_mapycz(
            from_place=from_place,
            to_place=to_place,
            mode=mode,
            avoid_toll=avoid_toll,
            waypoints=waypoints,
            lang=lang,
            format=format
        )


class AirQualityTools:
    """Helper class for air quality tools."""
    
    def __init__(self, client: "CzechFabricClient"):
        self._client = client
    
    async def current(
        self,
        location: str,
        radius_meters: Optional[int] = 2000,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """Get current air quality near a location."""
        return await self._client.get_air_quality_near_location(
            location=location,
            radius_meters=radius_meters,
            format=format
        )
    
    async def by_district(
        self,
        district: str,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """Get air quality by district."""
        return await self._client.get_air_quality_by_district(district=district, format=format)
    
    async def history(
        self,
        location: Optional[str] = None,
        station_id: Optional[str] = None,
        days_back: Optional[int] = 7,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """Get historical air quality data."""
        return await self._client.get_air_quality_history(
            location=location,
            station_id=station_id,
            days_back=days_back,
            format=format
        )
    
    async def components(
        self,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """List all measured pollutants."""
        return await self._client.list_air_quality_components(format=format)

