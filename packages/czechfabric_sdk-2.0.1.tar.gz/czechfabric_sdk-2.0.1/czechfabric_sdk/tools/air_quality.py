"""
Air quality tools helper - convenient access to air quality tools.
"""
from typing import TYPE_CHECKING, Optional, Union, Dict, Any

if TYPE_CHECKING:
    from czechfabric_sdk.client import CzechFabricClient


class AirQualityTools:
    """Helper class for air quality tools."""
    
    def __init__(self, client: "CzechFabricClient"):
        self._client = client
    
    async def current(
        self,
        location: str,
        radius_meters: Optional[int] = 2000,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """Get current air quality near a location."""
        return await self._client.get_air_quality_near_location(
            location=location,
            radius_meters=radius_meters,
            format=format
        )
    
    async def by_district(
        self,
        district: str,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """Get air quality by district."""
        return await self._client.get_air_quality_by_district(district=district, format=format)
    
    async def history(
        self,
        location: Optional[str] = None,
        station_id: Optional[str] = None,
        days_back: Optional[int] = 7,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """Get historical air quality data."""
        return await self._client.get_air_quality_history(
            location=location,
            station_id=station_id,
            days_back=days_back,
            format=format
        )
    
    async def components(
        self,
        format: Optional[str] = None
    ) -> Union[str, Dict[str, Any]]:
        """List all measured pollutants."""
        return await self._client.list_air_quality_components(format=format)

