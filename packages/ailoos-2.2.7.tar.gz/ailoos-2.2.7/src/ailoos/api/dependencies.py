"""
Sistema de Inyección de Dependencias para AILOOS API Gateway
==========================================================

Este módulo maneja la carga y gestión de todos los modelos y servicios
que necesita el API Gateway para funcionar.

Componentes principales:
- EmpoorioLM: Modelo de lenguaje principal
- EmpoorioVision: Modelo de visión (placeholder por ahora)
- WorkflowEngine: Motor de workflows complejos
"""

import asyncio
import logging
import os
from typing import Optional, Any
from dataclasses import dataclass
from pathlib import Path

from ..core.logging import get_logger
from ..models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig
from ..models.empoorio_lm.expert_system import ExpertManager
from ..models.vision.lvlm_wrapper import LVLMWrapper
from ..models.vision import VisionConfig
from ..inference.api import EmpoorioLMInferenceAPI, InferenceConfig
from ..workflows.engine import WorkflowEngine

logger = get_logger(__name__)

@dataclass
class ModelDependencies:
    """Contenedor para todas las dependencias de modelos."""
    empoorio_lm: Optional[EmpoorioLM] = None
    empoorio_vision: Optional[Any] = None  # Placeholder para visión
    workflow_engine: Optional[WorkflowEngine] = None

    def is_ready(self) -> bool:
        """Verifica si todas las dependencias críticas están disponibles."""
        return (
            self.empoorio_lm is not None and
            self.workflow_engine is not None
        )

async def load_empoorio_lm() -> Optional[EmpoorioLM]:
    """Carga el modelo EmpoorioLM."""
    try:
        logger.info("📥 Loading EmpoorioLM model...")

        # Crear configuración básica
        config = EmpoorioLMConfig()

        # Intentar crear el modelo
        model = EmpoorioLM(config).float()

        # Aquí iría la lógica para cargar pesos pre-entrenados
        # Por ahora, solo inicializamos el modelo
        logger.info("✅ EmpoorioLM model loaded successfully")
        return model

    except Exception as e:
        logger.warning(f"⚠️ Failed to load EmpoorioLM: {e}")
        logger.warning("🚀 Continuing without EmpoorioLM - API will work in mock mode")
        return None

async def load_empoorio_vision() -> Optional[Any]:
    """Carga el modelo EmpoorioVision usando LVLMWrapper."""
    try:
        logger.info("📥 Loading EmpoorioVision model...")

        # Cargar modelo base EmpoorioLM primero
        empoorio_lm = await load_empoorio_lm()
        if empoorio_lm is None:
            logger.warning("⚠️ Cannot load EmpoorioVision: EmpoorioLM not available")
            logger.warning("🚀 Continuing without EmpoorioVision")
            return None

        # Crear configuración de visión
        vision_config = VisionConfig()

        # Instanciar LVLMWrapper con el modelo base
        vision_model = LVLMWrapper(
            base_model=empoorio_lm,
            vision_config=vision_config
        )

        logger.info("✅ EmpoorioVision loaded successfully")
        return vision_model

    except Exception as e:
        logger.warning(f"⚠️ Failed to load EmpoorioVision: {e}")
        logger.warning("🚀 Continuing without EmpoorioVision")
        return None

async def load_workflow_engine() -> Optional[WorkflowEngine]:
    """Carga el WorkflowEngine con sus dependencias."""
    try:
        logger.info("📥 Loading WorkflowEngine...")

        # Crear directorio de expertos si no existe
        experts_dir = Path(os.getcwd()) / "models" / "experts"
        experts_dir.mkdir(parents=True, exist_ok=True)

        # Cargar dependencias del WorkflowEngine
        expert_manager = ExpertManager(experts_dir=str(experts_dir))
        inference_config = InferenceConfig()
        inference_api = EmpoorioLMInferenceAPI(inference_config)

        # Crear instancia del WorkflowEngine
        engine = WorkflowEngine(expert_manager, inference_api)

        # Aquí iría cualquier inicialización adicional del engine
        logger.info("✅ WorkflowEngine loaded successfully")
        return engine

    except Exception as e:
        logger.warning(f"⚠️ Failed to load WorkflowEngine: {e}")
        logger.warning("🚀 Continuing without WorkflowEngine")
        return None

async def get_model_dependencies() -> ModelDependencies:
    """
    Carga todas las dependencias de modelos de forma asíncrona.

    Esta función se ejecuta una sola vez al inicio del servidor
    para evitar recargar modelos en cada request.
    """
    logger.info("🔄 Starting model dependencies initialization...")

    # Cargar todos los modelos en paralelo para optimizar el tiempo de startup
    tasks = [
        load_empoorio_lm(),
        load_empoorio_vision(),
        load_workflow_engine()
    ]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Procesar resultados
    empoorio_lm = results[0] if not isinstance(results[0], Exception) else None
    empoorio_vision = results[1] if not isinstance(results[1], Exception) else None
    workflow_engine = results[2] if not isinstance(results[2], Exception) else None

    # Crear contenedor de dependencias
    deps = ModelDependencies(
        empoorio_lm=empoorio_lm,
        empoorio_vision=empoorio_vision,
        workflow_engine=workflow_engine
    )

    # Verificar estado
    if deps.is_ready():
        logger.info("🎉 All critical model dependencies loaded successfully!")
    else:
        logger.warning("⚠️ Some model dependencies failed to load - API will work in degraded mode")
        logger.warning(f"   EmpoorioLM: {'✅' if empoorio_lm else '❌'}")
        logger.warning(f"   EmpoorioVision: {'✅' if empoorio_vision else '❌'}")
        logger.warning(f"   WorkflowEngine: {'✅' if workflow_engine else '❌'}")

    return deps

# Instancia global para desarrollo/testing
_global_deps: Optional[ModelDependencies] = None

async def get_global_dependencies() -> ModelDependencies:
    """Obtiene las dependencias globales (para testing)."""
    global _global_deps

    if _global_deps is None:
        _global_deps = await get_model_dependencies()

    return _global_deps

def reset_global_dependencies():
    """Resetea las dependencias globales (para testing)."""
    global _global_deps
    _global_deps = None