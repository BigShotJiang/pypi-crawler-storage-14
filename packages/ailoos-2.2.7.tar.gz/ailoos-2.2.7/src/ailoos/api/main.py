"""
Main FastAPI Backend Server for AILOOS Dashboard
===============================================

This is the unified backend server that connects the dashboard to all AILOOS components:
- Dashboard API (hardware monitoring, federated learning, wallets, refinery)
- Wallet API (blockchain integration)
- Federated Learning API (distributed training coordination)
- Gateway API (external AI services)

Endpoints:
- /health: Server health check
- /dashboard/*: Dashboard-specific endpoints
- /wallet/*: Wallet and blockchain operations
- /federated/*: Federated learning management
- /api/*: External API gateway (chat, vision, workflows)
"""

import asyncio
import time
from typing import Dict, Any
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

from ..core.logging import get_logger
from .dashboard_api import create_dashboard_app
from .wallet_api import create_wallet_app
from .federated_api import create_federated_app
from .gateway import create_app as create_gateway_app

logger = get_logger(__name__)

# Server startup time for uptime calculation
server_start_time = time.time()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    logger.info("🚀 Starting AILOOS Unified Backend Server")

    # Startup tasks
    logger.info("📦 Loading API components...")

    try:
        # Mount dashboard API
        dashboard_app = create_dashboard_app()
        app.mount("/dashboard", dashboard_app, name="dashboard")

        # Mount wallet API
        wallet_app = create_wallet_app()
        app.mount("/wallet", wallet_app, name="wallet")

        # Mount federated API
        federated_app = create_federated_app()
        app.mount("/federated", federated_app, name="federated")

        # Mount gateway API
        gateway_app = create_gateway_app()
        app.mount("/api", gateway_app, name="gateway")

        logger.info("✅ All API components mounted successfully")

    except Exception as e:
        logger.error(f"❌ Failed to load API components: {e}")
        raise

    yield

    # Shutdown tasks
    logger.info("🛑 Shutting down AILOOS Unified Backend Server")


def create_main_app() -> FastAPI:
    """Create the main FastAPI application."""

    app = FastAPI(
        title="AILOOS Unified Backend Server",
        description="Main backend server connecting dashboard to all AILOOS components",
        version="1.0.0",
        lifespan=lifespan
    )

    # CORS middleware for dashboard integration
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:3000",  # React dev server
            "http://localhost:8000",  # Local dashboard
            "https://dashboard.ailoos.com",  # Production dashboard
            "https://www.ailoos.com",  # Main site
            "*"  # Allow all for development (restrict in production)
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Trusted host middleware (relaxed for development)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["*"])

    # Request logging middleware
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        """Log all requests."""
        start_time = time.time()

        response = await call_next(request)

        process_time = time.time() - start_time

        logger.info(
            "Request",
            extra={
                "method": request.method,
                "url": str(request.url),
                "status_code": response.status_code,
                "process_time": f"{process_time:.3f}s",
                "client_ip": request.client.host if request.client else "unknown"
            }
        )

        return response

    # Main health check endpoint
    @app.get("/health", tags=["health"])
    async def health_check():
        """Main server health check."""
        uptime_seconds = time.time() - server_start_time
        uptime_hours = uptime_seconds / 3600

        return {
            "status": "healthy",
            "server": "ailoos-unified-backend",
            "version": "1.0.0",
            "uptime_hours": f"{uptime_hours:.1f}",
            "timestamp": time.time(),
            "components": {
                "dashboard_api": "loaded",
                "wallet_api": "loaded",
                "federated_api": "loaded",
                "gateway_api": "loaded"
            }
        }

    # Root endpoint
    @app.get("/", tags=["root"])
    async def root():
        """Root endpoint with API information."""
        return {
            "message": "AILOOS Unified Backend Server",
            "version": "1.0.0",
            "docs": "/docs",
            "redoc": "/redoc",
            "health": "/health",
            "apis": {
                "dashboard": "/dashboard",
                "wallet": "/wallet",
                "federated": "/federated",
                "gateway": "/api"
            }
        }

    return app


# Create the main application instance
app = create_main_app()


if __name__ == "__main__":
    logger.info("🚀 Starting AILOOS Unified Backend Server...")
    uvicorn.run(
        "src.ailoos.api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )