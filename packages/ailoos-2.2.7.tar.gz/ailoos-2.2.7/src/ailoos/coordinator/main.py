"""
Minimal AILOOS Coordinator API - Basic endpoints only.
This is a simplified version that avoids complex dependencies.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .api.routes import api_router

# Create FastAPI app
app = FastAPI(
    title="AILOOS Coordinator API",
    description="Minimal AILOOS API with basic endpoints",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all API routers
app.include_router(api_router, prefix="/api")

# Health check endpoint
@app.get("/health")
async def health_check():
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "service": "ailoos-coordinator",
        "version": "1.0.0"
    }

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "Welcome to AILOOS Coordinator API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

def create_application() -> FastAPI:
    """Create and return the FastAPI application."""
    return app


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)