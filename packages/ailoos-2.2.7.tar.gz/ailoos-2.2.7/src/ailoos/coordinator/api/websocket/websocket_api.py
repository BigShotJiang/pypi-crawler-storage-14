"""
Main WebSocket API router for real-time state communication.
Provides bidirectional WebSocket connections for frontend-backend communication.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from pydantic import BaseModel
import asyncio
import json
from datetime import datetime

from ...database.connection import get_db
from ...auth.dependencies import get_current_user, require_admin
from ...websocket.manager import manager
from ...websocket.room_manager import room_manager
from ...websocket.message_broker import message_broker
from ...models.schemas import WebSocketMessage
from ...websocket.message_types import WebSocketMessageFactory


# Pydantic models for API responses
class WebSocketConnectionInfo(BaseModel):
    connection_id: str
    session_id: str
    node_id: str
    connected_at: str
    last_activity: str
    status: str

class WebSocketRoomInfo(BaseModel):
    room_id: str
    room_type: str
    active_connections: int
    created_at: str
    metadata: Dict[str, Any]

class WebSocketStats(BaseModel):
    total_connections: int
    active_sessions: int
    active_rooms: int
    message_queue_size: int
    uptime_seconds: int

class BroadcastMessage(BaseModel):
    message_type: str
    data: Dict[str, Any]
    target_type: str = "broadcast"  # broadcast, room, session, node
    target_ids: Optional[List[str]] = None
    priority: str = "normal"  # low, normal, high, critical


# Create router
router = APIRouter()


@router.get("/connections", response_model=List[WebSocketConnectionInfo],
            summary="Listar conexiones WebSocket activas",
            description="""
            Obtiene una lista de todas las conexiones WebSocket activas en el sistema.

            **Información incluida:**
            - ID de conexión (session_id + node_id)
            - ID de sesión y nodo
            - Timestamp de conexión y última actividad
            - Estado de la conexión

            **Uso típico:**
            - Monitoreo del sistema
            - Debugging de conexiones
            - Administración de recursos

            **Permisos requeridos:** Usuario autenticado
            """,
            responses={
                200: {
                    "description": "Lista de conexiones obtenida exitosamente",
                    "content": {
                        "application/json": {
                            "example": [
                                {
                                    "connection_id": "session_123_node_456",
                                    "session_id": "session_123",
                                    "node_id": "node_456",
                                    "connected_at": "2023-11-10T15:00:00Z",
                                    "last_activity": "2023-11-10T15:05:00Z",
                                    "status": "active"
                                }
                            ]
                        }
                    }
                }
            })
async def list_websocket_connections(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """List all active WebSocket connections."""
    connections = []

    for session_id, session_connections in manager.active_connections.items():
        for node_id, websocket in session_connections.items():
            metadata = manager.connection_metadata.get(session_id, {}).get(node_id, {})
            connections.append(WebSocketConnectionInfo(
                connection_id=f"{session_id}_{node_id}",
                session_id=session_id,
                node_id=node_id,
                connected_at=metadata.get("connected_at", datetime.utcnow()).isoformat(),
                last_activity=metadata.get("last_activity", datetime.utcnow()).isoformat(),
                status="active"
            ))

    return connections


@router.get("/connections/{connection_id}", response_model=WebSocketConnectionInfo)
async def get_websocket_connection_info(
    connection_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get detailed information about a WebSocket connection."""
    session_id, node_id = connection_id.rsplit("_", 1)

    if session_id not in manager.active_connections or node_id not in manager.active_connections[session_id]:
        raise HTTPException(status_code=404, detail="Connection not found")

    metadata = manager.connection_metadata.get(session_id, {}).get(node_id, {})

    return WebSocketConnectionInfo(
        connection_id=connection_id,
        session_id=session_id,
        node_id=node_id,
        connected_at=metadata.get("connected_at", datetime.utcnow()).isoformat(),
        last_activity=metadata.get("last_activity", datetime.utcnow()).isoformat(),
        status="active"
    )


@router.get("/stats", response_model=WebSocketStats)
async def get_websocket_stats(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get WebSocket system statistics."""
    broker_stats = await message_broker.get_stats()

    # Calculate uptime (simplified - in production this would track actual start time)
    uptime_seconds = 0  # TODO: Implement proper uptime tracking

    return WebSocketStats(
        total_connections=sum(len(connections) for connections in manager.active_connections.values()),
        active_sessions=len(manager.active_connections),
        active_rooms=len(room_manager.room_subscriptions),
        message_queue_size=broker_stats.get("queue_size", 0),
        uptime_seconds=uptime_seconds
    )


@router.get("/rooms", response_model=List[WebSocketRoomInfo])
async def list_websocket_rooms(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """List all WebSocket rooms."""
    rooms = []
    for room_id, metadata in room_manager.room_metadata.items():
        rooms.append(WebSocketRoomInfo(
            room_id=room_id,
            room_type=metadata["type"],
            active_connections=metadata["active_connections"],
            created_at=metadata["created_at"].isoformat(),
            metadata=metadata["metadata"]
        ))

    return rooms


@router.post("/broadcast",
             summary="Enviar mensaje broadcast a WebSocket",
             description="""
             Envía un mensaje broadcast a todos los clientes WebSocket conectados (solo administradores).

             **Tipos de broadcast soportados:**
             - `broadcast`: A todos los clientes conectados
             - `room`: A un room específico
             - `session`: A una sesión específica
             - `node`: A un nodo específico

             **Niveles de prioridad:**
             - `low`: Mensajes informativos
             - `normal`: Actualizaciones regulares
             - `high`: Cambios importantes
             - `critical`: Alertas críticas

             **Uso típico:**
             - Anuncios del sistema
             - Actualizaciones de estado global
             - Alertas de mantenimiento
             - Notificaciones de emergencia

             **Permisos requeridos:** Administrador
             """,
             responses={
                 200: {
                     "description": "Broadcast enviado exitosamente",
                     "content": {
                         "application/json": {
                             "example": {
                                 "status": "success",
                                 "message": "Broadcast sent successfully"
                             }
                         }
                     }
                 },
                 403: {
                     "description": "Permisos insuficientes",
                     "content": {
                         "application/json": {
                             "example": {"detail": "Not enough permissions"}
                         }
                     }
                 }
             })
async def broadcast_websocket_message(
    message: BroadcastMessage,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    """Broadcast a message to WebSocket clients (admin only)."""
    try:
        # Create message using factory
        ws_message = WebSocketMessageFactory.create_system_broadcast(
            broadcast_type=message.message_type,
            message="Admin broadcast",
            data=message.data,
            priority=message.priority
        )

        # Publish message
        await message_broker.publish(
            message=ws_message,
            target_type=message.target_type,
            target_ids=message.target_ids
        )

        return {"status": "success", "message": "Broadcast sent successfully"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Broadcast failed: {str(e)}")


@router.delete("/connections/{connection_id}")
async def disconnect_websocket_connection(
    connection_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    """Force disconnect a WebSocket connection (admin only)."""
    session_id, node_id = connection_id.rsplit("_", 1)

    if session_id not in manager.active_connections or node_id not in manager.active_connections[session_id]:
        raise HTTPException(status_code=404, detail="Connection not found")

    manager.disconnect(session_id, node_id)

    return {
        "status": "success",
        "message": f"Disconnected connection {connection_id}"
    }


@router.post("/cleanup")
async def cleanup_stale_websocket_connections(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    """Clean up stale WebSocket connections (admin only)."""
    try:
        await manager.cleanup_stale_connections()
        await message_broker._cleanup_empty_rooms()

        return {"status": "success", "message": "Stale connections cleaned up"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


@router.post("/health-check")
async def websocket_health_check(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Perform a health check on WebSocket system."""
    try:
        # Check manager health
        manager_healthy = len(manager.active_connections) >= 0

        # Check broker health
        broker_stats = await message_broker.get_stats()
        broker_healthy = broker_stats.get("status") != "error"

        # Check room manager health
        room_healthy = len(room_manager.room_subscriptions) >= 0

        overall_healthy = manager_healthy and broker_healthy and room_healthy

        return {
            "healthy": overall_healthy,
            "components": {
                "manager": {"healthy": manager_healthy, "connections": len(manager.active_connections)},
                "broker": {"healthy": broker_healthy, "queue_size": broker_stats.get("queue_size", 0)},
                "rooms": {"healthy": room_healthy, "active_rooms": len(room_manager.room_subscriptions)}
            }
        }

    except Exception as e:
        return {
            "healthy": False,
            "error": str(e)
        }