"""
WebSocket APIs for real-time state communication in the coordinator service.
Provides bidirectional WebSocket connections for frontend-backend communication,
including session state updates, active rounds, node metrics, system alerts,
and federated event notifications.
"""

from .websocket_api import router as websocket_api_router
from .session_websocket import router as session_websocket_router
from .metrics_websocket import router as metrics_websocket_router
from .alerts_websocket import router as alerts_websocket_router
from .federated_websocket import router as federated_websocket_router

__all__ = [
    "websocket_api_router",
    "session_websocket_router",
    "metrics_websocket_router",
    "alerts_websocket_router",
    "federated_websocket_router",
]