"""
WebSocket endpoints for real-time metrics streaming.
Provides live updates of system metrics, node performance, and federated learning statistics.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any, List
import json
import asyncio
from datetime import datetime, timedelta

from ...database.connection import get_db
from ...auth.dependencies import get_current_user, require_admin
from ...websocket.room_manager import room_manager
from ...websocket.message_types import WebSocketMessageFactory
from ailoos.monitoring.metrics_api import MetricsAPI


# Create router
router = APIRouter()


@router.websocket("/ws/metrics/live")
async def live_metrics_websocket(
    websocket: WebSocket,
    token: str = Query(..., description="JWT access token"),
    metrics_filter: Optional[str] = Query(None, description="Comma-separated list of metric types to stream"),
    update_interval: int = Query(5, description="Update interval in seconds (1-60)"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for live metrics streaming.
    Streams real-time system metrics, node performance, and federated learning statistics.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["user", "admin", "coordinator"]:
            await websocket.close(code=1008, reason="Insufficient permissions for metrics websocket")
            return

        user_id = token_data.sub

        # Validate update interval
        update_interval = max(1, min(60, update_interval))

        # Parse metrics filter
        if metrics_filter:
            requested_metrics = set(metrics_filter.split(","))
        else:
            requested_metrics = None

        await websocket.accept()

        # Join metrics room
        room_id = "metrics_live"
        await room_manager.join_room(room_id, websocket, user_id, room_type="metrics")

        # Send initial metrics snapshot
        await _send_initial_metrics_snapshot(websocket, requested_metrics, db)

        # Start live streaming
        await _start_metrics_streaming(websocket, user_id, requested_metrics, update_interval, db)

    except Exception as e:
        print(f"Live metrics WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal server error")


@router.websocket("/ws/metrics/dashboard")
async def dashboard_metrics_websocket(
    websocket: WebSocket,
    token: str = Query(..., description="JWT access token"),
    dashboard_type: str = Query("overview", description="Type of dashboard: overview, detailed, admin"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for dashboard metrics.
    Provides comprehensive metrics for dashboard visualization.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if dashboard_type == "admin" and token_data.type not in ["admin", "coordinator"]:
            await websocket.close(code=1008, reason="Admin access required for admin dashboard")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join dashboard room
        room_id = f"dashboard_{dashboard_type}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="dashboard")

        # Send initial dashboard data
        await _send_initial_dashboard_data(websocket, dashboard_type, db)

        # Start dashboard updates
        await _start_dashboard_streaming(websocket, user_id, dashboard_type, db)

    except Exception as e:
        print(f"Dashboard metrics WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal server error")


@router.websocket("/ws/metrics/node/{node_id}")
async def node_metrics_websocket(
    websocket: WebSocket,
    node_id: str,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for specific node metrics.
    Streams real-time metrics for a particular node.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["admin", "coordinator"] and token_data.sub != node_id:
            await websocket.close(code=1008, reason="Access denied for node metrics")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join node-specific room
        room_id = f"node_metrics_{node_id}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="node_metrics")

        # Send initial node metrics
        await _send_initial_node_metrics(websocket, node_id, db)

        # Start node metrics streaming
        await _start_node_metrics_streaming(websocket, user_id, node_id, db)

    except Exception as e:
        print(f"Node metrics WebSocket error for node {node_id}: {e}")
        await websocket.close(code=1011, reason="Internal server error")


async def _send_initial_metrics_snapshot(websocket: WebSocket, requested_metrics: Optional[set], db: Session):
    """Send initial metrics snapshot to client."""
    try:
        # Get current metrics
        metrics_api = MetricsAPI()
        current_metrics = await metrics_api.get_current_metrics()

        # Filter metrics if requested
        if requested_metrics:
            filtered_metrics = {}
            for category, category_metrics in current_metrics.items():
                if category in requested_metrics:
                    filtered_metrics[category] = category_metrics
                elif isinstance(category_metrics, dict):
                    # Check for sub-metrics
                    filtered_sub = {k: v for k, v in category_metrics.items() if k in requested_metrics}
                    if filtered_sub:
                        filtered_metrics[category] = filtered_sub
            metrics_data = filtered_metrics
        else:
            metrics_data = current_metrics

        # Create metrics message
        message = WebSocketMessageFactory.create_metrics_update(
            metrics_type="initial_snapshot",
            data={
                "timestamp": datetime.utcnow().isoformat(),
                "metrics": metrics_data
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial metrics snapshot: {e}")


async def _start_metrics_streaming(websocket: WebSocket, user_id: str, requested_metrics: Optional[set], update_interval: int, db: Session):
    """Start live metrics streaming."""
    try:
        while True:
            await asyncio.sleep(update_interval)

            # Get updated metrics
            metrics_api = MetricsAPI()
            current_metrics = await metrics_api.get_current_metrics()

            # Filter metrics if requested
            if requested_metrics:
                filtered_metrics = {}
                for category, category_metrics in current_metrics.items():
                    if category in requested_metrics:
                        filtered_metrics[category] = category_metrics
                    elif isinstance(category_metrics, dict):
                        filtered_sub = {k: v for k, v in category_metrics.items() if k in requested_metrics}
                        if filtered_sub:
                            filtered_metrics[category] = filtered_sub
                metrics_data = filtered_metrics
            else:
                metrics_data = current_metrics

            # Send update
            message = WebSocketMessageFactory.create_metrics_update(
                metrics_type="live_update",
                data={
                    "timestamp": datetime.utcnow().isoformat(),
                    "metrics": metrics_data
                }
            )

            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from live metrics")
    except Exception as e:
        print(f"Error in metrics streaming: {e}")


async def _send_initial_dashboard_data(websocket: WebSocket, dashboard_type: str, db: Session):
    """Send initial dashboard data."""
    try:
        metrics_api = MetricsAPI()

        if dashboard_type == "overview":
            # Basic overview metrics
            data = await metrics_api.get_dashboard_overview()
        elif dashboard_type == "detailed":
            # Detailed metrics
            data = await metrics_api.get_dashboard_detailed()
        elif dashboard_type == "admin":
            # Admin-level metrics
            data = await metrics_api.get_dashboard_admin()
        else:
            data = {"error": "Unknown dashboard type"}

        message = WebSocketMessageFactory.create_metrics_update(
            metrics_type="dashboard_initial",
            data={
                "dashboard_type": dashboard_type,
                "timestamp": datetime.utcnow().isoformat(),
                "data": data
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial dashboard data: {e}")


async def _start_dashboard_streaming(websocket: WebSocket, user_id: str, dashboard_type: str, db: Session):
    """Start dashboard metrics streaming."""
    try:
        while True:
            await asyncio.sleep(10)  # Dashboard updates every 10 seconds

            metrics_api = MetricsAPI()

            if dashboard_type == "overview":
                data = await metrics_api.get_dashboard_overview()
            elif dashboard_type == "detailed":
                data = await metrics_api.get_dashboard_detailed()
            elif dashboard_type == "admin":
                data = await metrics_api.get_dashboard_admin()
            else:
                data = {"error": "Unknown dashboard type"}

            message = WebSocketMessageFactory.create_metrics_update(
                metrics_type="dashboard_update",
                data={
                    "dashboard_type": dashboard_type,
                    "timestamp": datetime.utcnow().isoformat(),
                    "data": data
                }
            )

            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from dashboard {dashboard_type}")
    except Exception as e:
        print(f"Error in dashboard streaming: {e}")


async def _send_initial_node_metrics(websocket: WebSocket, node_id: str, db: Session):
    """Send initial metrics for a specific node."""
    try:
        metrics_api = MetricsAPI()
        node_metrics = await metrics_api.get_node_metrics(node_id)

        message = WebSocketMessageFactory.create_metrics_update(
            metrics_type="node_initial",
            data={
                "node_id": node_id,
                "timestamp": datetime.utcnow().isoformat(),
                "metrics": node_metrics
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial node metrics: {e}")


async def _start_node_metrics_streaming(websocket: WebSocket, user_id: str, node_id: str, db: Session):
    """Start streaming metrics for a specific node."""
    try:
        while True:
            await asyncio.sleep(5)  # Node metrics updates every 5 seconds

            metrics_api = MetricsAPI()
            node_metrics = await metrics_api.get_node_metrics(node_id)

            message = WebSocketMessageFactory.create_metrics_update(
                metrics_type="node_update",
                data={
                    "node_id": node_id,
                    "timestamp": datetime.utcnow().isoformat(),
                    "metrics": node_metrics
                }
            )

            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from node {node_id} metrics")
    except Exception as e:
        print(f"Error in node metrics streaming: {e}")


# Broadcast functions for external use
async def broadcast_metrics_update(metrics_type: str, data: Dict[str, Any]):
    """Broadcast metrics update to all clients in metrics room."""
    room_id = "metrics_live"
    message = WebSocketMessageFactory.create_metrics_update(
        metrics_type=metrics_type,
        data=data
    )

    await room_manager.broadcast_to_room(room_id, message)


async def broadcast_dashboard_update(dashboard_type: str, data: Dict[str, Any]):
    """Broadcast dashboard update to specific dashboard room."""
    room_id = f"dashboard_{dashboard_type}"
    message = WebSocketMessageFactory.create_metrics_update(
        metrics_type=f"dashboard_{dashboard_type}_update",
        data=data
    )

    await room_manager.broadcast_to_room(room_id, message)