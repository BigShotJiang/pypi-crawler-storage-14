"""
Example Usage - Ejemplo de uso del sistema de gestión de modelos FASE 4
Demostración completa del flujo de trabajo de gestión de modelos.
"""

import asyncio
import json
from datetime import datetime

from ...core.logging import get_logger
from .model_management_integration import model_management_system
from .model_quality_monitor import QualityMetrics
from ..models.schemas import ModelCreate

logger = get_logger(__name__)


async def demo_model_management_system():
    """
    Demostración completa del sistema de gestión de modelos FASE 4.
    """
    print("🚀 Iniciando demostración del Sistema de Gestión de Modelos FASE 4")
    print("=" * 60)

    try:
        # 1. Inicializar el sistema
        print("\n📋 Paso 1: Inicializando sistema...")
        success = await model_management_system.initialize()
        if not success:
            print("❌ Falló la inicialización del sistema")
            return

        print("✅ Sistema inicializado correctamente")

        # 2. Iniciar el sistema
        print("\n▶️ Paso 2: Iniciando sistema...")
        success = await model_management_system.start()
        if not success:
            print("❌ Falló el inicio del sistema")
            return

        print("✅ Sistema iniciado correctamente")

        # 3. Registrar un nuevo modelo
        print("\n📝 Paso 3: Registrando nuevo modelo...")

        model_data = ModelCreate(
            name="ailoos_nutrition_model",
            model_type="federated_nutrition",
            description="Modelo de nutrición federado para recomendaciones personalizadas",
            tags=["nutrition", "federated", "health"],
            config={
                "architecture": "transformer",
                "layers": 12,
                "hidden_size": 768
            },
            metrics={
                "accuracy": 0.85,
                "precision": 0.82,
                "recall": 0.88
            }
        )

        # Simular datos del modelo (en producción vendrían del entrenamiento)
        dummy_model_data = b"dummy_model_data_placeholder"

        version_id = await model_management_system.register_model(
            model_data=model_data,
            creator_node="coordinator_node_1"
        )

        print(f"✅ Modelo registrado con versión inicial: {version_id}")

        # 4. Crear una nueva versión
        print("\n🆕 Paso 4: Creando nueva versión del modelo...")

        version_metadata = {
            'model_name': 'ailoos_nutrition_model',
            'version_name': '1.1.0',
            'description': 'Versión mejorada con más datos de entrenamiento',
            'federated_info': {
                'participants': 5,
                'total_samples': 50000,
                'rounds': 10
            },
            'quality_metrics': {
                'accuracy': 0.88,
                'precision': 0.85,
                'recall': 0.90,
                'f1_score': 0.87
            },
            'config': {
                'architecture': 'transformer',
                'layers': 12,
                'hidden_size': 768,
                'improvements': ['more_training_data', 'fine_tuning']
            }
        }

        new_version_id = await model_management_system.create_version(
            model_name="ailoos_nutrition_model",
            version_data=dummy_model_data,
            metadata=version_metadata,
            creator_node="coordinator_node_1"
        )

        print(f"✅ Nueva versión creada: {new_version_id}")

        # 5. Simular validación colectiva (en producción sería automática)
        print("\n🎯 Paso 5: Iniciando validación colectiva...")
        await model_management_system.version_controller.validate_version(
            model_name="ailoos_nutrition_model",
            version_id=new_version_id,
            validated_by="admin"
        )
        print("✅ Validación colectiva iniciada")

        # 6. Promover a producción
        print("\n🚀 Paso 6: Promoviendo versión a producción...")
        success = await model_management_system.promote_to_production(
            model_name="ailoos_nutrition_model",
            version_id=new_version_id,
            user="admin"
        )

        if success:
            print("✅ Versión promovida a producción")
        else:
            print("❌ Falló la promoción a producción")

        # 7. Reportar métricas de calidad
        print("\n📊 Paso 7: Reportando métricas de calidad...")

        quality_metrics = QualityMetrics(
            timestamp=int(datetime.now().timestamp()),
            accuracy=0.88,
            precision=0.85,
            recall=0.90,
            f1_score=0.87,
            latency_ms=45.2,
            throughput=1250.5,
            error_rate=0.02
        )

        success = await model_management_system.report_quality_metrics(
            model_name="ailoos_nutrition_model",
            metrics=quality_metrics
        )

        if success:
            print("✅ Métricas de calidad reportadas")
        else:
            print("❌ Falló el reporte de métricas")

        # 8. Obtener estado del modelo
        print("\n📈 Paso 8: Obteniendo estado del modelo...")
        status = await model_management_system.get_model_status("ailoos_nutrition_model")
        print(f"Estado del modelo: {json.dumps(status, indent=2)}")

        # 9. Obtener estado del sistema
        print("\n🔍 Paso 9: Obteniendo estado del sistema...")
        system_status = model_management_system.get_system_status()
        print(f"Estado del sistema: {json.dumps(system_status, indent=2)}")

        # 10. Verificación de salud
        print("\n🏥 Paso 10: Verificación de salud del sistema...")
        health = await model_management_system.health_check()
        print(f"Estado de salud: {health['overall_health']}")
        if health['issues']:
            print(f"Issues encontrados: {health['issues']}")

        print("\n✅ Demostración completada exitosamente!")

    except Exception as e:
        logger.error(f"❌ Error en la demostración: {e}")
        print(f"❌ Error en la demostración: {e}")

    finally:
        # Cleanup
        print("\n🛑 Deteniendo sistema...")
        await model_management_system.stop()
        print("✅ Sistema detenido")


async def demo_drift_detection():
    """
    Demostración de detección de drift.
    """
    print("\n🔍 Demostración de Detección de Drift")
    print("=" * 40)

    try:
        # Inicializar sistema
        await model_management_system.initialize()
        await model_management_system.start()

        # Reportar métricas normales
        print("📊 Reportando métricas normales...")
        for i in range(20):
            metrics = QualityMetrics(
                timestamp=int(datetime.now().timestamp()) + i * 60,  # Cada minuto
                accuracy=0.88 + (i * 0.001),  # Ligera mejora
                precision=0.85,
                recall=0.90,
                latency_ms=45.0,
                error_rate=0.02
            )
            await model_management_system.report_quality_metrics("ailoos_nutrition_model", metrics)
            await asyncio.sleep(0.1)

        print("✅ Métricas normales reportadas")

        # Simular degradación (drift)
        print("📉 Simulando degradación de rendimiento...")
        for i in range(10):
            metrics = QualityMetrics(
                timestamp=int(datetime.now().timestamp()) + (20 + i) * 60,
                accuracy=0.88 - (i * 0.01),  # Degradación progresiva
                precision=0.85 - (i * 0.005),
                recall=0.90,
                latency_ms=45.0 + (i * 2),  # Latencia creciente
                error_rate=0.02 + (i * 0.005)  # Más errores
            )
            await model_management_system.report_quality_metrics("ailoos_nutrition_model", metrics)
            await asyncio.sleep(0.1)

        print("✅ Degradación simulada")

        # Forzar check de calidad
        print("🔍 Ejecutando check de calidad...")
        result = await model_management_system.quality_monitor.force_quality_check("ailoos_nutrition_model")
        print(f"Resultado del check: {result}")

        # Obtener alertas activas
        alerts = await model_management_system.quality_monitor.get_active_alerts("ailoos_nutrition_model")
        print(f"Alertas activas: {len(alerts)}")
        for alert in alerts:
            print(f"  - {alert.severity.value}: {alert.message}")

    except Exception as e:
        logger.error(f"❌ Error en demo de drift: {e}")

    finally:
        await model_management_system.stop()


if __name__ == "__main__":
    # Ejecutar demostración completa
    asyncio.run(demo_model_management_system())

    # O ejecutar solo demo de drift
    # asyncio.run(demo_drift_detection())