"""
Model Validator - Validación de integridad y calidad de modelos
Extiende el sistema de validación federada con validaciones específicas de modelos.
"""

import asyncio
import hashlib
import json
import time
import torch
import torch.nn as nn
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum

from ...core.logging import get_logger
from ...federated.version_validator import VersionValidator, ValidationResult, ValidationType, ValidationStatus
from .model_registry import ModelRegistry

logger = get_logger(__name__)


class ModelValidationType(Enum):
    """Tipos específicos de validación para modelos."""
    ARCHITECTURE_INTEGRITY = "architecture_integrity"
    PERFORMANCE_CONSISTENCY = "performance_consistency"
    DATA_COMPATIBILITY = "data_compatibility"
    GRADIENT_STABILITY = "gradient_stability"
    OVERFITTING_CHECK = "overfitting_check"
    FAIRNESS_AUDIT = "fairness_audit"
    ROBUSTNESS_TEST = "robustness_test"


@dataclass
class ModelValidationResult:
    """Resultado de validación específica de modelo."""
    validation_type: ModelValidationType
    status: ValidationStatus
    score: float
    details: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None
    execution_time: float = 0.0
    timestamp: int = field(default_factory=lambda: int(time.time()))

    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario."""
        return {
            'validation_type': self.validation_type.value,
            'status': self.status.value,
            'score': self.score,
            'details': self.details,
            'error_message': self.error_message,
            'execution_time': self.execution_time,
            'timestamp': self.timestamp
        }


class ModelValidator:
    """
    Validador especializado para modelos de ML.
    Extiende las validaciones federadas con checks específicos de integridad y calidad.
    """

    def __init__(self, base_validator: VersionValidator, registry: ModelRegistry):
        """
        Inicializar el validador de modelos.

        Args:
            base_validator: Validador base de versiones federadas
            registry: Registro de modelos
        """
        self.base_validator = base_validator
        self.registry = registry

        # Validadores específicos de modelo
        self.model_validators: Dict[ModelValidationType, Callable] = {}
        self._register_model_validators()

        # Historial de validaciones
        self.validation_history: Dict[str, List[ModelValidationResult]] = {}  # model_name -> results

        # Configuración de validaciones
        self.validation_config = {
            'architecture_integrity': {'enabled': True, 'strict': True},
            'performance_consistency': {'enabled': True, 'threshold': 0.05},
            'data_compatibility': {'enabled': True, 'sample_size': 1000},
            'gradient_stability': {'enabled': True, 'max_gradient_norm': 10.0},
            'overfitting_check': {'enabled': True, 'train_val_ratio_threshold': 0.1},
            'fairness_audit': {'enabled': False, 'bias_threshold': 0.1},  # Deshabilitado por defecto
            'robustness_test': {'enabled': True, 'adversarial_epsilon': 0.1}
        }

        logger.info("🚀 ModelValidator initialized")

    def _register_model_validators(self):
        """Registrar validadores específicos de modelo."""
        self.register_model_validator(ModelValidationType.ARCHITECTURE_INTEGRITY, self._validate_architecture_integrity)
        self.register_model_validator(ModelValidationType.PERFORMANCE_CONSISTENCY, self._validate_performance_consistency)
        self.register_model_validator(ModelValidationType.DATA_COMPATIBILITY, self._validate_data_compatibility)
        self.register_model_validator(ModelValidationType.GRADIENT_STABILITY, self._validate_gradient_stability)
        self.register_model_validator(ModelValidationType.OVERFITTING_CHECK, self._validate_overfitting)
        self.register_model_validator(ModelValidationType.FAIRNESS_AUDIT, self._validate_fairness)
        self.register_model_validator(ModelValidationType.ROBUSTNESS_TEST, self._validate_robustness)

    def register_model_validator(self, validation_type: ModelValidationType, validator_func: Callable):
        """
        Registrar una función validadora específica de modelo.

        Args:
            validation_type: Tipo de validación
            validator_func: Función que toma (model_data, metadata, context) y retorna ModelValidationResult
        """
        self.model_validators[validation_type] = validator_func
        logger.info(f"📝 Registered model validator for {validation_type.value}")

    async def validate_model(self, model_name: str, version_id: str = None,
                           node_context: Dict[str, Any] = None) -> List[ModelValidationResult]:
        """
        Ejecutar todas las validaciones activas para un modelo.

        Args:
            model_name: Nombre del modelo
            version_id: ID específico de versión (opcional, usa activa por defecto)
            node_context: Contexto del nodo validador

        Returns:
            Lista de resultados de validación
        """
        try:
            # Obtener versión a validar
            if version_id:
                version = await self.base_validator.version_manager.get_version(version_id)
            else:
                version = await self.registry.get_active_version(model_name)

            if not version:
                raise ValueError(f"Version not found for model {model_name}")

            # Descargar datos del modelo
            model_data = await self.base_validator.version_manager.ipfs_manager.get_data(version.model_cid)
            metadata = await self.base_validator.version_manager.ipfs_manager.get_data(version.metadata_cid)
            metadata = json.loads(metadata.decode())

            # Ejecutar validaciones activas
            validation_results = []
            for validation_type, config in self.validation_config.items():
                if not config.get('enabled', False):
                    continue

                try:
                    validator_func = self.model_validators.get(ModelValidationType(validation_type))
                    if validator_func:
                        result = await validator_func(model_data, metadata, node_context or {})
                        validation_results.append(result)
                        logger.debug(f"✅ {validation_type} validation completed: {result.status.value} ({result.score:.2f})")
                    else:
                        logger.warning(f"No validator function for {validation_type}")

                except Exception as e:
                    logger.error(f"❌ {validation_type} validation failed: {e}")
                    # Crear resultado de error
                    error_result = ModelValidationResult(
                        validation_type=ModelValidationType(validation_type),
                        status=ValidationStatus.REJECTED,
                        score=0.0,
                        error_message=str(e),
                        execution_time=0.0
                    )
                    validation_results.append(error_result)

            # Almacenar en historial
            if model_name not in self.validation_history:
                self.validation_history[model_name] = []
            self.validation_history[model_name].extend(validation_results)

            return validation_results

        except Exception as e:
            logger.error(f"❌ Model validation failed for {model_name}: {e}")
            raise

    async def _validate_architecture_integrity(self, model_data: bytes, metadata: Dict[str, Any],
                                             context: Dict[str, Any]) -> ModelValidationResult:
        """Validar integridad de la arquitectura del modelo."""
        start_time = time.time()

        try:
            # Verificar que el modelo se puede cargar
            try:
                # Intentar cargar como modelo PyTorch (placeholder)
                # En producción, esto sería más específico según el framework
                if len(model_data) == 0:
                    raise ValueError("Empty model data")

                # Verificar tamaño razonable
                model_size_mb = len(model_data) / (1024 * 1024)
                if model_size_mb > 1000:  # 1GB límite
                    return ModelValidationResult(
                        validation_type=ModelValidationType.ARCHITECTURE_INTEGRITY,
                        status=ValidationStatus.REJECTED,
                        score=0.0,
                        error_message=f"Model too large: {model_size_mb:.1f}MB",
                        execution_time=time.time() - start_time
                    )

                # Verificar arquitectura declarada vs real
                declared_arch = metadata.get('architecture', {})
                if not declared_arch:
                    return ModelValidationResult(
                        validation_type=ModelValidationType.ARCHITECTURE_INTEGRITY,
                        status=ValidationStatus.REJECTED,
                        score=0.5,
                        error_message="No architecture information provided",
                        execution_time=time.time() - start_time
                    )

            except Exception as load_error:
                return ModelValidationResult(
                    validation_type=ModelValidationType.ARCHITECTURE_INTEGRITY,
                    status=ValidationStatus.REJECTED,
                    score=0.0,
                    error_message=f"Model loading failed: {str(load_error)}",
                    execution_time=time.time() - start_time
                )

            return ModelValidationResult(
                validation_type=ModelValidationType.ARCHITECTURE_INTEGRITY,
                status=ValidationStatus.APPROVED,
                score=1.0,
                details={'model_size_mb': model_size_mb, 'architecture': declared_arch},
                execution_time=time.time() - start_time
            )

        except Exception as e:
            return ModelValidationResult(
                validation_type=ModelValidationType.ARCHITECTURE_INTEGRITY,
                status=ValidationStatus.REJECTED,
                score=0.0,
                error_message=str(e),
                execution_time=time.time() - start_time
            )

    async def _validate_performance_consistency(self, model_data: bytes, metadata: Dict[str, Any],
                                              context: Dict[str, Any]) -> ModelValidationResult:
        """Validar consistencia de rendimiento entre versiones."""
        start_time = time.time()

        try:
            current_metrics = metadata.get('quality_metrics', {})
            model_name = metadata.get('model_name', '')

            # Obtener versiones anteriores para comparación
            versions = await self.registry.get_model_versions(model_name)
            if len(versions) < 2:
                # Primera versión, no hay comparación posible
                return ModelValidationResult(
                    validation_type=ModelValidationType.PERFORMANCE_CONSISTENCY,
                    status=ValidationStatus.APPROVED,
                    score=1.0,
                    details={'reason': 'First version, no comparison available'},
                    execution_time=time.time() - start_time
                )

            # Comparar con versión anterior
            previous_version = versions[-2]  # Penúltima versión
            previous_metrics = previous_version.quality_metrics

            # Calcular diferencias
            consistency_score = 1.0
            issues = []

            for metric in ['accuracy', 'loss', 'f1_score']:
                if metric in current_metrics and metric in previous_metrics:
                    current_val = current_metrics[metric]
                    previous_val = previous_metrics[metric]

                    if metric == 'loss':
                        # Para loss, menor es mejor
                        diff = abs(current_val - previous_val) / max(previous_val, 0.001)
                        if diff > self.validation_config['performance_consistency']['threshold']:
                            consistency_score *= 0.8
                            issues.append(f"Loss changed by {diff:.2%}")
                    else:
                        # Para accuracy/f1, mayor es mejor
                        diff = abs(current_val - previous_val)
                        if diff > self.validation_config['performance_consistency']['threshold']:
                            consistency_score *= 0.8
                            issues.append(f"{metric} changed by {diff:.2%}")

            status = ValidationStatus.APPROVED if consistency_score >= 0.7 else ValidationStatus.REJECTED

            return ModelValidationResult(
                validation_type=ModelValidationType.PERFORMANCE_CONSISTENCY,
                status=status,
                score=consistency_score,
                details={
                    'compared_with_version': previous_version.version_id,
                    'issues': issues,
                    'current_metrics': current_metrics,
                    'previous_metrics': previous_metrics
                },
                execution_time=time.time() - start_time
            )

        except Exception as e:
            return ModelValidationResult(
                validation_type=ModelValidationType.PERFORMANCE_CONSISTENCY,
                status=ValidationStatus.REJECTED,
                score=0.0,
                error_message=str(e),
                execution_time=time.time() - start_time
            )

    async def _validate_data_compatibility(self, model_data: bytes, metadata: Dict[str, Any],
                                        context: Dict[str, Any]) -> ModelValidationResult:
        """Validar compatibilidad con datos de entrada."""
        start_time = time.time()

        try:
            # Obtener información de datos del metadata
            data_info = metadata.get('data_info', {})
            input_shape = data_info.get('input_shape')
            data_type = data_info.get('data_type')

            if not input_shape:
                return ModelValidationResult(
                    validation_type=ModelValidationType.DATA_COMPATIBILITY,
                    status=ValidationStatus.REJECTED,
                    score=0.5,
                    error_message="No input shape information provided",
                    execution_time=time.time() - start_time
                )

            # Verificar compatibilidad básica
            # En producción, esto probaría con datos de muestra
            compatibility_score = 1.0
            issues = []

            # Verificar dimensiones razonables
            if len(input_shape) < 1 or len(input_shape) > 4:
                compatibility_score *= 0.7
                issues.append("Unusual input dimensions")

            # Verificar tipos de datos soportados
            supported_types = ['float32', 'int32', 'uint8']
            if data_type and data_type not in supported_types:
                compatibility_score *= 0.8
                issues.append(f"Unsupported data type: {data_type}")

            status = ValidationStatus.APPROVED if compatibility_score >= 0.8 else ValidationStatus.REJECTED

            return ModelValidationResult(
                validation_type=ModelValidationType.DATA_COMPATIBILITY,
                status=status,
                score=compatibility_score,
                details={
                    'input_shape': input_shape,
                    'data_type': data_type,
                    'issues': issues
                },
                execution_time=time.time() - start_time
            )

        except Exception as e:
            return ModelValidationResult(
                validation_type=ModelValidationType.DATA_COMPATIBILITY,
                status=ValidationStatus.REJECTED,
                score=0.0,
                error_message=str(e),
                execution_time=time.time() - start_time
            )

    async def _validate_gradient_stability(self, model_data: bytes, metadata: Dict[str, Any],
                                        context: Dict[str, Any]) -> ModelValidationResult:
        """Validar estabilidad de gradientes."""
        start_time = time.time()

        try:
            # En producción, esto requeriría cargar el modelo y verificar gradientes
            # Por ahora, placeholder basado en metadata
            training_info = metadata.get('training_info', {})
            gradient_stats = training_info.get('gradient_stats', {})

            if not gradient_stats:
                return ModelValidationResult(
                    validation_type=ModelValidationType.GRADIENT_STABILITY,
                    status=ValidationStatus.APPROVED,
                    score=0.8,  # Asumir estable si no hay info
                    details={'reason': 'No gradient stats available'},
                    execution_time=time.time() - start_time
                )

            max_norm = gradient_stats.get('max_norm', 0)
            stability_score = 1.0

            if max_norm > self.validation_config['gradient_stability']['max_gradient_norm']:
                stability_score *= 0.6

            status = ValidationStatus.APPROVED if stability_score >= 0.7 else ValidationStatus.REJECTED

            return ModelValidationResult(
                validation_type=ModelValidationType.GRADIENT_STABILITY,
                status=status,
                score=stability_score,
                details={'max_gradient_norm': max_norm},
                execution_time=time.time() - start_time
            )

        except Exception as e:
            return ModelValidationResult(
                validation_type=ModelValidationType.GRADIENT_STABILITY,
                status=ValidationStatus.REJECTED,
                score=0.0,
                error_message=str(e),
                execution_time=time.time() - start_time
            )

    async def _validate_overfitting(self, model_data: bytes, metadata: Dict[str, Any],
                                 context: Dict[str, Any]) -> ModelValidationResult:
        """Verificar sobreajuste."""
        start_time = time.time()

        try:
            metrics = metadata.get('quality_metrics', {})
            train_accuracy = metrics.get('train_accuracy')
            val_accuracy = metrics.get('validation_accuracy')

            if train_accuracy is None or val_accuracy is None:
                return ModelValidationResult(
                    validation_type=ModelValidationType.OVERFITTING_CHECK,
                    status=ValidationStatus.APPROVED,
                    score=0.8,
                    details={'reason': 'Train/val metrics not available'},
                    execution_time=time.time() - start_time
                )

            gap = train_accuracy - val_accuracy
            threshold = self.validation_config['overfitting_check']['train_val_ratio_threshold']

            overfitting_score = max(0.0, 1.0 - (gap / threshold))

            status = ValidationStatus.APPROVED if overfitting_score >= 0.6 else ValidationStatus.REJECTED

            return ModelValidationResult(
                validation_type=ModelValidationType.OVERFITTING_CHECK,
                status=status,
                score=overfitting_score,
                details={
                    'train_accuracy': train_accuracy,
                    'validation_accuracy': val_accuracy,
                    'accuracy_gap': gap
                },
                execution_time=time.time() - start_time
            )

        except Exception as e:
            return ModelValidationResult(
                validation_type=ModelValidationType.OVERFITTING_CHECK,
                status=ValidationStatus.REJECTED,
                score=0.0,
                error_message=str(e),
                execution_time=time.time() - start_time
            )

    async def _validate_fairness(self, model_data: bytes, metadata: Dict[str, Any],
                               context: Dict[str, Any]) -> ModelValidationResult:
        """Auditar fairness del modelo."""
        start_time = time.time()

        try:
            # Placeholder - en producción implementaría métricas de fairness
            fairness_metrics = metadata.get('fairness_metrics', {})

            if not fairness_metrics:
                return ModelValidationResult(
                    validation_type=ModelValidationType.FAIRNESS_AUDIT,
                    status=ValidationStatus.APPROVED,
                    score=0.9,  # Asumir fair si no hay métricas específicas
                    details={'reason': 'No fairness metrics available'},
                    execution_time=time.time() - start_time
                )

            # Calcular score de fairness basado en disparidades
            bias_score = fairness_metrics.get('bias_score', 0.0)
            fairness_score = max(0.0, 1.0 - bias_score)

            status = ValidationStatus.APPROVED if fairness_score >= 0.8 else ValidationStatus.REJECTED

            return ModelValidationResult(
                validation_type=ModelValidationType.FAIRNESS_AUDIT,
                status=status,
                score=fairness_score,
                details=fairness_metrics,
                execution_time=time.time() - start_time
            )

        except Exception as e:
            return ModelValidationResult(
                validation_type=ModelValidationType.FAIRNESS_AUDIT,
                status=ValidationStatus.REJECTED,
                score=0.0,
                error_message=str(e),
                execution_time=time.time() - start_time
            )

    async def _validate_robustness(self, model_data: bytes, metadata: Dict[str, Any],
                                context: Dict[str, Any]) -> ModelValidationResult:
        """Probar robustez contra adversarios."""
        start_time = time.time()

        try:
            # Placeholder - en producción probaría ataques adversarios
            robustness_metrics = metadata.get('robustness_metrics', {})

            if not robustness_metrics:
                return ModelValidationResult(
                    validation_type=ModelValidationType.ROBUSTNESS_TEST,
                    status=ValidationStatus.APPROVED,
                    score=0.8,
                    details={'reason': 'No robustness metrics available'},
                    execution_time=time.time() - start_time
                )

            adversarial_accuracy = robustness_metrics.get('adversarial_accuracy', 1.0)
            epsilon = self.validation_config['robustness_test']['adversarial_epsilon']

            robustness_score = adversarial_accuracy

            status = ValidationStatus.APPROVED if robustness_score >= 0.7 else ValidationStatus.REJECTED

            return ModelValidationResult(
                validation_type=ModelValidationType.ROBUSTNESS_TEST,
                status=status,
                score=robustness_score,
                details={
                    'adversarial_accuracy': adversarial_accuracy,
                    'epsilon': epsilon
                },
                execution_time=time.time() - start_time
            )

        except Exception as e:
            return ModelValidationResult(
                validation_type=ModelValidationType.ROBUSTNESS_TEST,
                status=ValidationStatus.REJECTED,
                score=0.0,
                error_message=str(e),
                execution_time=time.time() - start_time
            )

    def configure_validation(self, validation_type: str, enabled: bool, **config):
        """Configurar una validación específica."""
        if validation_type in self.validation_config:
            self.validation_config[validation_type]['enabled'] = enabled
            self.validation_config[validation_type].update(config)
            logger.info(f"⚙️ Configured {validation_type}: enabled={enabled}")

    async def get_validation_history(self, model_name: str) -> List[ModelValidationResult]:
        """Obtener historial de validaciones de un modelo."""
        return self.validation_history.get(model_name, [])

    def get_validation_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas de validaciones."""
        total_validations = sum(len(results) for results in self.validation_history.values())

        type_counts = {}
        for results in self.validation_history.values():
            for result in results:
                vtype = result.validation_type.value
                type_counts[vtype] = type_counts.get(vtype, 0) + 1

        return {
            'total_models_validated': len(self.validation_history),
            'total_validations': total_validations,
            'validations_by_type': type_counts,
            'active_validations': [k for k, v in self.validation_config.items() if v.get('enabled', False)]
        }


# Instancia global del servicio
model_validator = ModelValidator(None, None)