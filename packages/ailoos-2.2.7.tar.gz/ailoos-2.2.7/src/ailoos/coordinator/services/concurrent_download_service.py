"""
Servicio de descarga concurrente para modelos federados.
Gestiona descargas simultáneas de modelos iniciales a nodos registrados,
con notificación automática, reintentos, validación de integridad y logging.
"""

import asyncio
import hashlib
import logging
import time
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import aiohttp
import requests

from ..core.config import Config
from ..core.exceptions import CoordinatorException
# Lazy import to avoid circular dependency
_event_broadcaster = None
_notification_service = None
from ..models.base import Model, FederatedSession
from ..database.connection import get_db_session


def _get_event_broadcaster():
    """Lazy import of event_broadcaster to avoid circular imports."""
    global _event_broadcaster
    if _event_broadcaster is None:
        from ..websocket.event_broadcaster import event_broadcaster
        _event_broadcaster = event_broadcaster
    return _event_broadcaster


def _get_notification_service():
    """Lazy import of notification_service to avoid circular imports."""
    global _notification_service
    if _notification_service is None:
        from ..websocket.notification_service import notification_service
        _notification_service = notification_service
    return _notification_service

logger = logging.getLogger(__name__)


@dataclass
class DownloadTask:
    """Tarea de descarga para un nodo específico."""
    node_id: str
    model_id: str
    session_id: str
    download_url: str
    expected_hash: str
    max_retries: int = 3
    retry_delay: float = 1.0
    timeout: int = 300  # 5 minutos

    # Estado
    status: str = "pending"  # pending, downloading, completed, failed
    attempts: int = 0
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    downloaded_bytes: int = 0
    total_bytes: int = 0
    error_message: Optional[str] = None
    validation_passed: bool = False

    # Callbacks
    progress_callback: Optional[callable] = None
    completion_callback: Optional[callable] = None


@dataclass
class ConcurrentDownloadResult:
    """Resultado de una operación de descarga concurrente."""
    session_id: str
    total_nodes: int
    successful_downloads: int
    failed_downloads: int
    total_time: float
    node_results: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None


class ConcurrentDownloadService:
    """
    Servicio para gestionar descargas simultáneas de modelos a nodos federados.
    """

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.active_downloads: Dict[str, DownloadTask] = {}
        self.executor = ThreadPoolExecutor(max_workers=10)
        self.session = requests.Session()

        # Configurar sesión HTTP con timeouts
        self.session.timeout = aiohttp.ClientTimeout(total=300)

        # Estadísticas
        self.stats = {
            'total_downloads': 0,
            'successful_downloads': 0,
            'failed_downloads': 0,
            'total_bytes_downloaded': 0,
            'average_download_speed': 0.0
        }

    async def start_concurrent_download(
        self,
        session_id: str,
        model_id: str,
        node_ids: List[str],
        download_url: Optional[str] = None
    ) -> ConcurrentDownloadResult:
        """
        Iniciar descarga simultánea del modelo inicial a todos los nodos registrados.

        Args:
            session_id: ID de la sesión federada
            model_id: ID del modelo a descargar
            node_ids: Lista de IDs de nodos participantes
            download_url: URL de descarga (opcional, se obtiene del modelo si no se proporciona)

        Returns:
            Resultado de la operación de descarga concurrente
        """
        start_time = time.time()
        logger.info(f"🚀 Iniciando descarga concurrente para sesión {session_id}, modelo {model_id}")

        # Obtener información del modelo
        model_info = await self._get_model_info(model_id)
        if not model_info:
            raise CoordinatorException(f"Model {model_id} not found")

        download_url = download_url or model_info.get('download_url')
        if not download_url:
            # Construir URL de descarga usando el endpoint existente
            download_url = f"{self.config.coordinator_url}/api/models/download/{model_id}"

        expected_hash = model_info.get('file_hash', '')
        if not expected_hash:
            logger.warning(f"No hash available for model {model_id}, validation will be skipped")

        # Crear tareas de descarga
        download_tasks = []
        for node_id in node_ids:
            task = DownloadTask(
                node_id=node_id,
                model_id=model_id,
                session_id=session_id,
                download_url=download_url,
                expected_hash=expected_hash,
                progress_callback=lambda task: self._on_download_progress(task, _get_event_broadcaster()),
                completion_callback=lambda task: self._on_download_completed(task, _get_event_broadcaster())
            )
            download_tasks.append(task)
            self.active_downloads[f"{session_id}_{node_id}"] = task

        # Notificar a nodos vía WebSocket
        await self._notify_nodes_download_start(session_id, model_id, node_ids, download_url, _get_event_broadcaster())

        # Ejecutar descargas concurrentemente
        result = await self._execute_concurrent_downloads(session_id, download_tasks)

        result.start_time = start_time
        result.end_time = time.time()
        result.total_time = result.end_time - start_time

        # Actualizar estadísticas
        self._update_stats(result)

        # Broadcast resultado final
        await self._broadcast_download_result(result, _get_event_broadcaster())

        logger.info(f"✅ Descarga concurrente completada: {result.successful_downloads}/{result.total_nodes} nodos exitosos en {result.total_time:.2f}s")
        return result

    async def _execute_concurrent_downloads(
        self,
        session_id: str,
        tasks: List[DownloadTask]
    ) -> ConcurrentDownloadResult:
        """Ejecutar descargas de manera concurrente."""
        result = ConcurrentDownloadResult(
            session_id=session_id,
            total_nodes=len(tasks),
            successful_downloads=0,
            failed_downloads=0,
            total_time=0.0
        )

        # Crear tareas asyncio
        download_coroutines = []
        for task in tasks:
            coroutine = self._download_model_for_node(task)
            download_coroutines.append(coroutine)

        # Ejecutar todas las descargas concurrentemente
        results = await asyncio.gather(*download_coroutines, return_exceptions=True)

        # Procesar resultados
        for i, task_result in enumerate(results):
            task = tasks[i]
            node_result = {
                'node_id': task.node_id,
                'status': task.status,
                'attempts': task.attempts,
                'downloaded_bytes': task.downloaded_bytes,
                'total_bytes': task.total_bytes,
                'validation_passed': task.validation_passed,
                'error_message': task.error_message,
                'duration': (task.end_time - task.start_time) if task.end_time and task.start_time else 0
            }

            result.node_results[task.node_id] = node_result

            if task.status == 'completed':
                result.successful_downloads += 1
            else:
                result.failed_downloads += 1

            # Limpiar tarea activa
            task_key = f"{session_id}_{task.node_id}"
            if task_key in self.active_downloads:
                del self.active_downloads[task_key]

        return result

    async def _download_model_for_node(self, task: DownloadTask) -> bool:
        """
        Descargar modelo para un nodo específico con reintentos.
        """
        task.start_time = time.time()

        for attempt in range(task.max_retries):
            task.attempts = attempt + 1
            task.status = 'downloading'

            try:
                logger.info(f"📥 Descargando modelo {task.model_id} para nodo {task.node_id} (intento {attempt + 1})")

                # Realizar descarga con timeout y manejo de errores
                success = await self._perform_download(task)

                if success and task.validation_passed:
                    task.status = 'completed'
                    task.end_time = time.time()
                    logger.info(f"✅ Descarga exitosa para nodo {task.node_id} en {task.end_time - task.start_time:.2f}s")
                    return True
                else:
                    logger.warning(f"❌ Validación fallida para nodo {task.node_id}")
                    task.error_message = "Hash validation failed"

            except Exception as e:
                logger.error(f"❌ Error en descarga para nodo {task.node_id} (intento {attempt + 1}): {str(e)}")
                task.error_message = str(e)

                if attempt < task.max_retries - 1:
                    await asyncio.sleep(task.retry_delay * (2 ** attempt))  # Exponential backoff
                else:
                    task.status = 'failed'
                    task.end_time = time.time()

        return False

    async def _perform_download(self, task: DownloadTask) -> bool:
        """Realizar la descarga HTTP del modelo."""
        try:
            # Usar aiohttp para descarga asíncrona
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=task.timeout)) as session:
                async with session.get(task.download_url) as response:
                    if response.status != 200:
                        raise Exception(f"HTTP {response.status}: {response.reason}")

                    # Obtener tamaño total si disponible
                    task.total_bytes = int(response.headers.get('Content-Length', 0))

                    # Descargar en chunks para progreso
                    downloaded_data = b''
                    chunk_size = 8192

                    async for chunk in response.content.iter_chunked(chunk_size):
                        if not chunk:
                            continue

                        downloaded_data += chunk
                        task.downloaded_bytes = len(downloaded_data)

                        # Callback de progreso
                        if task.progress_callback:
                            await task.progress_callback(task)

                    # Validar hash si está disponible
                    if task.expected_hash:
                        actual_hash = hashlib.sha256(downloaded_data).hexdigest()
                        if actual_hash != task.expected_hash:
                            logger.error(f"Hash mismatch for node {task.node_id}: expected {task.expected_hash}, got {actual_hash}")
                            task.validation_passed = False
                            return False

                    task.validation_passed = True

                    # Aquí se debería guardar el archivo localmente en el nodo
                    # En una implementación real, se enviaría el archivo al nodo vía API/WebSocket
                    # Por ahora, simulamos el guardado
                    await self._save_model_to_node(task.node_id, downloaded_data)

                    return True

        except asyncio.TimeoutError:
            raise Exception("Download timeout")
        except aiohttp.ClientError as e:
            raise Exception(f"Network error: {str(e)}")

    async def _save_model_to_node(self, node_id: str, model_data: bytes):
        """Guardar el modelo descargado en el nodo (simulado)."""
        # En implementación real, esto enviaría el archivo al nodo vía API
        # o WebSocket, o el nodo lo descargaría directamente
        logger.info(f"💾 Modelo guardado para nodo {node_id} ({len(model_data)} bytes)")

        # Simular guardado
        await asyncio.sleep(0.1)  # Simular I/O

    async def _get_model_info(self, model_id: str) -> Optional[Dict[str, Any]]:
        """Obtener información del modelo desde la base de datos."""
        try:
            db = next(get_db_session())
            model = db.query(Model).filter(Model.id == model_id).first()
            db.close()

            if not model:
                return None

            return {
                'id': model.id,
                'name': model.name,
                'file_hash': model.file_hash,
                'file_size': model.file_size,
                'storage_location': model.storage_location,
                'download_url': f"{self.config.coordinator_url}/api/models/download/{model_id}"
            }
        except Exception as e:
            logger.error(f"Error getting model info: {e}")
            return None

    async def _notify_nodes_download_start(
        self,
        session_id: str,
        model_id: str,
        node_ids: List[str],
        download_url: str,
        event_broadcaster
    ):
        """Notificar a nodos que inicien la descarga vía WebSocket."""
        try:
            # Broadcast a cada nodo vía WebSocket
            for node_id in node_ids:
                await event_broadcaster.notify_node_event(
                    node_id=node_id,
                    event_type="model_download_start",
                    data={
                        "session_id": session_id,
                        "model_id": model_id,
                        "download_url": download_url,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )

            # También broadcast general
            await event_broadcaster.notify_session_event(
                session_id=session_id,
                event_type="concurrent_download_started",
                data={
                    "model_id": model_id,
                    "node_count": len(node_ids),
                    "download_url": download_url,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )

            logger.info(f"📢 Notificación de descarga enviada a {len(node_ids)} nodos")

        except Exception as e:
            logger.error(f"Error notifying nodes: {e}")

    async def _on_download_progress(self, task: DownloadTask, event_broadcaster):
        """Callback para progreso de descarga."""
        try:
            progress = (task.downloaded_bytes / task.total_bytes * 100) if task.total_bytes > 0 else 0

            # Broadcast progreso cada 10%
            if int(progress) % 10 == 0 and progress > 0:
                await event_broadcaster.notify_node_event(
                    node_id=task.node_id,
                    event_type="download_progress",
                    data={
                        "session_id": task.session_id,
                        "model_id": task.model_id,
                        "progress": progress,
                        "downloaded_bytes": task.downloaded_bytes,
                        "total_bytes": task.total_bytes,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )

        except Exception as e:
            logger.error(f"Error in progress callback: {e}")

    async def _on_download_completed(self, task: DownloadTask, event_broadcaster):
        """Callback para finalización de descarga."""
        try:
            await event_broadcaster.notify_node_event(
                node_id=task.node_id,
                event_type="download_completed",
                data={
                    "session_id": task.session_id,
                    "model_id": task.model_id,
                    "status": task.status,
                    "validation_passed": task.validation_passed,
                    "downloaded_bytes": task.downloaded_bytes,
                    "duration": task.end_time - task.start_time if task.end_time and task.start_time else 0,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )

        except Exception as e:
            logger.error(f"Error in completion callback: {e}")

    async def _broadcast_download_result(self, result: ConcurrentDownloadResult, event_broadcaster):
        """Broadcast resultado final de descargas."""
        try:
            await event_broadcaster.notify_session_event(
                session_id=result.session_id,
                event_type="concurrent_download_completed",
                data={
                    "total_nodes": result.total_nodes,
                    "successful_downloads": result.successful_downloads,
                    "failed_downloads": result.failed_downloads,
                    "total_time": result.total_time,
                    "success_rate": result.successful_downloads / result.total_nodes if result.total_nodes > 0 else 0,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )

        except Exception as e:
            logger.error(f"Error broadcasting download result: {e}")

    def _update_stats(self, result: ConcurrentDownloadResult):
        """Actualizar estadísticas globales."""
        self.stats['total_downloads'] += result.total_nodes
        self.stats['successful_downloads'] += result.successful_downloads
        self.stats['failed_downloads'] += result.failed_downloads

        # Calcular bytes totales descargados
        total_bytes = sum(node_result['downloaded_bytes'] for node_result in result.node_results.values())
        self.stats['total_bytes_downloaded'] += total_bytes

        # Calcular velocidad promedio
        if result.total_time > 0:
            speed = total_bytes / result.total_time / 1024 / 1024  # MB/s
            self.stats['average_download_speed'] = (
                (self.stats['average_download_speed'] + speed) / 2
            )

    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del servicio."""
        return self.stats.copy()

    def get_active_downloads(self) -> Dict[str, Dict[str, Any]]:
        """Obtener descargas activas."""
        return {
            task_key: {
                'node_id': task.node_id,
                'model_id': task.model_id,
                'session_id': task.session_id,
                'status': task.status,
                'progress': (task.downloaded_bytes / task.total_bytes * 100) if task.total_bytes > 0 else 0,
                'attempts': task.attempts,
                'start_time': task.start_time
            }
            for task_key, task in self.active_downloads.items()
        }

    async def cancel_download(self, session_id: str, node_id: str) -> bool:
        """Cancelar descarga para un nodo específico."""
        task_key = f"{session_id}_{node_id}"
        if task_key in self.active_downloads:
            task = self.active_downloads[task_key]
            task.status = 'cancelled'
            task.end_time = time.time()
            del self.active_downloads[task_key]
            logger.info(f"🚫 Descarga cancelada para nodo {node_id} en sesión {session_id}")
            return True
        return False


# Instancia global del servicio
_concurrent_download_service = None

def get_concurrent_download_service(config: Config = None) -> ConcurrentDownloadService:
    """Obtener instancia global del servicio de descarga concurrente."""
    global _concurrent_download_service
    if _concurrent_download_service is None:
        _concurrent_download_service = ConcurrentDownloadService(config)
    return _concurrent_download_service