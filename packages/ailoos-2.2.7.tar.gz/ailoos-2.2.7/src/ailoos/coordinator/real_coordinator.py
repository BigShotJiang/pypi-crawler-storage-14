"""
Coordinador real para entrenamiento federado masivo de AILOOS.
Servidor completo con APIs REST, WebSocket y base de datos para producción.
"""

import asyncio
import json
import logging
import time
import uuid
from typing import Dict, List, Any, Optional
from pathlib import Path
import sqlite3
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import websockets
from websockets.exceptions import ConnectionClosedError
import torch
import torch.nn as nn

from ..models.empoorio_lm import EmpoorioLM
from ..federated.aggregator import FedAvgAggregator
from ..models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig
from ..utils.logging import setup_logging
from .state_sync import StateSync, ConflictResolutionStrategy
from .consensus_manager import ConsensusManager
from .state_validator import StateValidator

logger = logging.getLogger(__name__)


class DatabaseManager:
    """Gestor de base de datos para el coordinador."""

    def __init__(self, db_path: str = "./coordinator.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_database()

    @contextmanager
    def get_connection(self):
        """Context manager para conexiones de base de datos."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    def init_database(self):
        """Inicializa las tablas de la base de datos."""
        with self.get_connection() as conn:
            # Tabla de sesiones de entrenamiento
            conn.execute('''
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    model_version TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    total_rounds INTEGER DEFAULT 0,
                    current_round INTEGER DEFAULT 0,
                    global_accuracy REAL DEFAULT 0.0
                )
            ''')

            # Tabla de nodos registrados
            conn.execute('''
                CREATE TABLE IF NOT EXISTS nodes (
                    node_id TEXT PRIMARY KEY,
                    hardware_type TEXT NOT NULL,
                    ip_address TEXT,
                    status TEXT NOT NULL,
                    registered_at REAL NOT NULL,
                    last_seen REAL NOT NULL,
                    total_contributions INTEGER DEFAULT 0,
                    total_rewards REAL DEFAULT 0.0
                )
            ''')

            # Tabla de rondas de entrenamiento
            conn.execute('''
                CREATE TABLE IF NOT EXISTS rounds (
                    round_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    round_number INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    started_at REAL NOT NULL,
                    completed_at REAL,
                    participating_nodes TEXT,  -- JSON array
                    aggregated_accuracy REAL DEFAULT 0.0,
                    FOREIGN KEY (session_id) REFERENCES sessions (session_id)
                )
            ''')

            # Tabla de contribuciones por ronda
            conn.execute('''
                CREATE TABLE IF NOT EXISTS contributions (
                    contribution_id TEXT PRIMARY KEY,
                    round_id TEXT NOT NULL,
                    node_id TEXT NOT NULL,
                    submitted_at REAL NOT NULL,
                    local_accuracy REAL NOT NULL,
                    local_loss REAL NOT NULL,
                    training_time REAL NOT NULL,
                    samples_processed INTEGER NOT NULL,
                    reward_earned REAL DEFAULT 0.0,
                    FOREIGN KEY (round_id) REFERENCES rounds (round_id),
                    FOREIGN KEY (node_id) REFERENCES nodes (node_id)
                )
            ''')

            conn.commit()

    def create_session(self, model_version: str) -> str:
        """Crea una nueva sesión de entrenamiento."""
        session_id = str(uuid.uuid4())
        now = time.time()

        with self.get_connection() as conn:
            conn.execute('''
                INSERT INTO sessions (session_id, model_version, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (session_id, model_version, 'waiting_for_nodes', now, now))
            conn.commit()

        return session_id

    def register_node(self, node_id: str, hardware_type: str, ip_address: str = None) -> bool:
        """Registra un nuevo nodo."""
        now = time.time()

        with self.get_connection() as conn:
            # Verificar si el nodo ya existe
            existing = conn.execute(
                'SELECT node_id FROM nodes WHERE node_id = ?', (node_id,)
            ).fetchone()

            if existing:
                # Actualizar last_seen
                conn.execute('''
                    UPDATE nodes SET last_seen = ?, status = 'active'
                    WHERE node_id = ?
                ''', (now, node_id))
            else:
                # Insertar nuevo nodo
                conn.execute('''
                    INSERT INTO nodes (node_id, hardware_type, ip_address, status, registered_at, last_seen)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (node_id, hardware_type, ip_address, 'active', now, now))

            conn.commit()
            return True

    def start_round(self, session_id: str, round_number: int, participating_nodes: List[str]) -> str:
        """Inicia una nueva ronda de entrenamiento."""
        round_id = str(uuid.uuid4())
        now = time.time()
        nodes_json = json.dumps(participating_nodes)

        with self.get_connection() as conn:
            conn.execute('''
                INSERT INTO rounds (round_id, session_id, round_number, status, started_at, participating_nodes)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (round_id, session_id, round_number, 'active', now, nodes_json))

            # Actualizar sesión
            conn.execute('''
                UPDATE sessions SET current_round = ?, updated_at = ?
                WHERE session_id = ?
            ''', (round_number, now, session_id))

            conn.commit()

        return round_id

    def submit_contribution(self, round_id: str, node_id: str, metrics: Dict[str, Any]) -> bool:
        """Registra una contribución de un nodo."""
        contribution_id = str(uuid.uuid4())
        now = time.time()

        with self.get_connection() as conn:
            conn.execute('''
                INSERT INTO contributions
                (contribution_id, round_id, node_id, submitted_at, local_accuracy, local_loss, training_time, samples_processed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                contribution_id, round_id, node_id, now,
                metrics['accuracy'], metrics['loss'], metrics['training_time'], metrics['samples_processed']
            ))

            # Actualizar estadísticas del nodo
            conn.execute('''
                UPDATE nodes SET
                    total_contributions = total_contributions + 1,
                    last_seen = ?
                WHERE node_id = ?
            ''', (now, node_id))

            conn.commit()

        return True

    def complete_round(self, round_id: str, aggregated_accuracy: float) -> bool:
        """Completa una ronda de entrenamiento."""
        now = time.time()

        with self.get_connection() as conn:
            conn.execute('''
                UPDATE rounds SET
                    status = 'completed',
                    completed_at = ?,
                    aggregated_accuracy = ?
                WHERE round_id = ?
            ''', (now, aggregated_accuracy, round_id))

            conn.commit()

        return True

    def get_session_status(self, session_id: str) -> Dict[str, Any]:
        """Obtiene el estado de una sesión."""
        with self.get_connection() as conn:
            session = conn.execute(
                'SELECT * FROM sessions WHERE session_id = ?', (session_id,)
            ).fetchone()

            if not session:
                return None

            # Obtener rondas de la sesión
            rounds = conn.execute(
                'SELECT * FROM rounds WHERE session_id = ? ORDER BY round_number',
                (session_id,)
            ).fetchall()

            return {
                'session_id': session['session_id'],
                'model_version': session['model_version'],
                'status': session['status'],
                'current_round': session['current_round'],
                'total_rounds': session['total_rounds'],
                'global_accuracy': session['global_accuracy'],
                'rounds': [dict(round) for round in rounds]
            }

    def get_active_nodes(self) -> List[Dict[str, Any]]:
        """Obtiene lista de nodos activos."""
        with self.get_connection() as conn:
            nodes = conn.execute(
                'SELECT * FROM nodes WHERE status = ? AND last_seen > ?',
                ('active', time.time() - 300)  # Activos en los últimos 5 minutos
            ).fetchall()

            return [dict(node) for node in nodes]


class RealFederatedCoordinator:
    """
    Coordinador real para entrenamiento federado masivo.
    Servidor completo con APIs REST y WebSocket.
    """

    def __init__(self, host: str = "0.0.0.0", port: int = 8000, node_id: str = None):
        self.host = host
        self.port = port
        self.node_id = node_id or f"coord_{uuid.uuid4().hex[:8]}"
        self.db = DatabaseManager()

        # Estado en memoria
        self.active_sessions: Dict[str, Dict[str, Any]] = {}
        self.connected_nodes: Dict[str, Any] = {}
        self.global_weights: Optional[Dict[str, torch.Tensor]] = None

        # Modelo y agregador
        self.model = EmpoorioLM(EmpoorioLMConfig())
        self.aggregator = FedAvgAggregator()

        # Inicializar modelo global
        self._initialize_global_model()

        # Inicializar sincronización de estado distribuido
        self.state_sync = StateSync(
            node_id=self.node_id,
            conflict_strategy=ConflictResolutionStrategy.VECTOR_CLOCK_PRIORITY
        )

        # Inicializar gestor de consenso
        self.consensus_manager = ConsensusManager(
            node_id=self.node_id,
            total_nodes=3  # Configurable, por defecto 3 para tolerancia a fallos
        )

        # Inicializar validador de estado
        self.state_validator = StateValidator()

        # Configurar FastAPI
        self.app = FastAPI(title="AILOOS Federated Coordinator", version="2.0.0")
        self._setup_cors()
        self._setup_routes()

        # WebSocket connections
        self.websocket_connections: Dict[str, Any] = {}

        logger.info(f"🚀 Coordinador distribuido inicializado en {host}:{port} (node_id: {self.node_id})")

    def _initialize_global_model(self):
        """Inicializa el modelo global."""
        self.global_weights = self.model.state_dict()
        logger.info("🎯 Modelo global inicializado")

    def _setup_cors(self):
        """Configura CORS para el servidor."""
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],  # En producción, especificar orígenes
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_routes(self):
        """Configura las rutas de la API."""

        @self.app.get("/")
        async def root():
            """Endpoint raíz con información del coordinador."""
            return {
                "name": "AILOOS Federated Coordinator",
                "version": "2.0.0",
                "status": "active",
                "active_nodes": len(self.db.get_active_nodes()),
                "active_sessions": len(self.active_sessions)
            }

        @self.app.post("/api/v1/nodes/register")
        async def register_node(node_data: Dict[str, Any]):
            """Registra un nuevo nodo en la red."""
            try:
                node_id = node_data.get("node_id")
                hardware_type = node_data.get("hardware_info", {}).get("cpu", "unknown")
                ip_address = node_data.get("ip_address")

                if not node_id:
                    raise HTTPException(status_code=400, detail="node_id requerido")

                # Proponer operación crítica de registro de nodo para consenso
                consensus_data = {
                    "node_id": node_id,
                    "hardware_type": hardware_type,
                    "ip_address": ip_address,
                    "operation": "register_node"
                }

                success, message = await self.consensus_manager.propose_critical_operation(
                    "register_node", consensus_data
                )

                if not success:
                    logger.warning(f"❌ Consenso fallido para registro de nodo {node_id}: {message}")
                    # Continuar sin consenso por ahora (fallback)
                    pass

                # Registrar nodo en base de datos local
                db_success = self.db.register_node(node_id, hardware_type, ip_address)

                if db_success:
                    # Sincronizar registro con otros coordinadores
                    self.state_sync.update_local_state(f"node_{node_id}", {
                        "node_id": node_id,
                        "hardware_type": hardware_type,
                        "ip_address": ip_address,
                        "status": "active",
                        "registered_at": time.time()
                    }, "create")

                    # Notificar a otros nodos
                    await self._broadcast_node_registration(node_id, hardware_type)

                    return {
                        "status": "success",
                        "message": f"Nodo {node_id} registrado exitosamente",
                        "node_id": node_id,
                        "consensus_reached": success
                    }
                else:
                    raise HTTPException(status_code=500, detail="Error registrando nodo")

            except Exception as e:
                logger.error(f"Error registrando nodo: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.post("/api/v1/sessions/create")
        async def create_session(session_data: Dict[str, Any]):
            """Crea una nueva sesión de entrenamiento."""
            try:
                model_version = session_data.get("model_version", "empoorio_lm_v1.0")

                # Proponer operación crítica de creación de sesión para consenso
                consensus_data = {
                    "model_version": model_version,
                    "operation": "create_session"
                }

                success, message = await self.consensus_manager.propose_critical_operation(
                    "create_session", consensus_data
                )

                if not success:
                    logger.warning(f"❌ Consenso fallido para creación de sesión: {message}")
                    # Continuar sin consenso por ahora (fallback)
                    pass

                session_id = self.db.create_session(model_version)

                session_info = {
                    "model_version": model_version,
                    "status": "active",
                    "created_at": time.time(),
                    "current_round": 0,
                    "nodes": []
                }

                self.active_sessions[session_id] = session_info

                # Sincronizar creación de sesión con otros coordinadores
                self.state_sync.update_local_state(f"session_{session_id}", session_info, "create")

                # Broadcast nueva sesión
                await self._broadcast_session_created(session_id, model_version)

                return {
                    "status": "success",
                    "session_id": session_id,
                    "model_version": model_version,
                    "consensus_reached": success
                }

            except Exception as e:
                logger.error(f"Error creando sesión: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/v1/sessions/{session_id}/status")
        async def get_session_status(session_id: str):
            """Obtiene el estado de una sesión."""
            session_data = self.db.get_session_status(session_id)
            if not session_data:
                raise HTTPException(status_code=404, detail="Sesión no encontrada")

            return session_data

        @self.app.post("/api/v1/sessions/{session_id}/start-round")
        async def start_round(session_id: str, round_data: Dict[str, Any]):
            """Inicia una nueva ronda de entrenamiento."""
            try:
                if session_id not in self.active_sessions:
                    raise HTTPException(status_code=404, detail="Sesión no encontrada")

                round_number = round_data.get("round_number", 1)
                participating_nodes = round_data.get("participating_nodes", [])

                # Proponer operación crítica de inicio de ronda para consenso
                consensus_data = {
                    "session_id": session_id,
                    "round_number": round_number,
                    "participating_nodes": participating_nodes,
                    "operation": "start_round"
                }

                success, message = await self.consensus_manager.propose_critical_operation(
                    "start_round", consensus_data
                )

                if not success:
                    logger.warning(f"❌ Consenso fallido para inicio de ronda {round_number}: {message}")
                    # Continuar sin consenso por ahora (fallback)
                    pass

                round_id = self.db.start_round(session_id, round_number, participating_nodes)

                # Actualizar estado en memoria
                self.active_sessions[session_id]["current_round"] = round_number

                # Sincronizar cambio de ronda con otros coordinadores
                round_info = {
                    "round_id": round_id,
                    "round_number": round_number,
                    "participating_nodes": participating_nodes,
                    "started_at": time.time()
                }
                self.state_sync.update_local_state(f"round_{round_id}", round_info, "create")

                # Broadcast inicio de ronda
                await self._broadcast_round_started(session_id, round_number, participating_nodes)

                return {
                    "status": "success",
                    "round_id": round_id,
                    "round_number": round_number,
                    "global_weights_available": self.global_weights is not None,
                    "consensus_reached": success
                }

            except Exception as e:
                logger.error(f"Error iniciando ronda: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/v1/sessions/{session_id}/global-weights")
        async def get_global_weights(session_id: str):
            """Obtiene los pesos globales actuales."""
            if session_id not in self.active_sessions:
                raise HTTPException(status_code=404, detail="Sesión no encontrada")

            if self.global_weights is None:
                raise HTTPException(status_code=404, detail="Pesos globales no disponibles")

            # Serializar pesos para envío
            weights_serialized = {}
            for key, tensor in self.global_weights.items():
                weights_serialized[key] = tensor.detach().cpu().numpy().tolist()

            return {
                "session_id": session_id,
                "global_weights": weights_serialized,
                "model_version": self.active_sessions[session_id]["model_version"]
            }

        @self.app.post("/api/v1/rounds/{round_id}/submit-weights")
        async def submit_weights(round_id: str, submission_data: Dict[str, Any]):
            """Recibe pesos locales de un nodo."""
            try:
                node_id = submission_data.get("node_id")
                local_weights = submission_data.get("local_weights")
                metrics = submission_data.get("metrics", {})

                if not node_id or not local_weights:
                    raise HTTPException(status_code=400, detail="node_id y local_weights requeridos")

                # Convertir pesos serializados de vuelta a tensores
                weights_tensors = {}
                for key, tensor_data in local_weights.items():
                    weights_tensors[key] = torch.tensor(tensor_data)

                # Registrar contribución
                success = self.db.submit_contribution(round_id, node_id, metrics)

                if success:
                    # Validar integridad antes de procesar
                    validation_issues = await self._validate_contribution_integrity(
                        round_id, node_id, weights_tensors, metrics
                    )

                    if validation_issues:
                        logger.warning(f"⚠️ Issues de validación en contribución de {node_id}: {len(validation_issues)}")
                        # Continuar pero loggear issues

                    # Proponer operación crítica de agregación de modelo para consenso
                    consensus_data = {
                        "round_id": round_id,
                        "node_id": node_id,
                        "operation": "aggregate_model",
                        "metrics": metrics
                    }

                    consensus_success, message = await self.consensus_manager.propose_critical_operation(
                        "update_global_model", consensus_data
                    )

                    if not consensus_success:
                        logger.warning(f"❌ Consenso fallido para agregación de modelo: {message}")
                        # Continuar sin consenso por ahora (fallback)

                    # Agregar a la cola de agregación (simplificado)
                    # En producción, esto sería más sofisticado
                    await self._handle_weight_submission(round_id, node_id, weights_tensors, metrics)

                    return {
                        "status": "success",
                        "message": f"Contribución de {node_id} recibida",
                        "round_id": round_id,
                        "validation_issues": len(validation_issues),
                        "consensus_reached": consensus_success
                    }
                else:
                    raise HTTPException(status_code=500, detail="Error procesando contribución")

            except Exception as e:
                logger.error(f"Error procesando pesos: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/api/v1/nodes/active")
        async def get_active_nodes():
            """Obtiene lista de nodos activos."""
            nodes = self.db.get_active_nodes()
            return {
                "active_nodes": nodes,
                "total_count": len(nodes)
            }

        @self.app.get("/api/v1/stats")
        async def get_coordinator_stats():
            """Obtiene estadísticas generales del coordinador."""
            sync_status = self.state_sync.get_sync_status()
            consensus_status = self.consensus_manager.get_status()
            validator_report = self.state_validator.get_integrity_report()

            return {
                "active_nodes": len(self.db.get_active_nodes()),
                "active_sessions": len(self.active_sessions),
                "total_sessions_ever": len(self.db.get_all_sessions()),
                "uptime": time.time() - self.start_time if hasattr(self, 'start_time') else 0,
                "sync_status": sync_status,
                "consensus_status": consensus_status,
                "integrity_report": validator_report,
                "node_id": self.node_id
            }

        @self.app.get("/api/v1/sync/status")
        async def get_sync_status():
            """Obtiene el estado de sincronización distribuida."""
            return self.state_sync.get_sync_status()

        @self.app.post("/api/v1/sync/state")
        async def sync_state(sync_data: Dict[str, Any]):
            """Endpoint para sincronización de estado con otros coordinadores."""
            try:
                peer_id = sync_data.get("peer_id")
                peer_state = sync_data.get("state", {})
                peer_updates = sync_data.get("updates", [])

                if not peer_id:
                    raise HTTPException(status_code=400, detail="peer_id requerido")

                # Agregar peer si no existe
                if peer_id not in self.state_sync.peers:
                    self.state_sync.add_peer(peer_id)

                # Verificar consenso antes de sincronizar estado crítico
                critical_operations = ['session_', 'node_', 'round_']
                has_critical_updates = any(
                    any(update.get('key', '').startswith(op) for op in critical_operations)
                    for update in peer_updates
                )

                if has_critical_updates:
                    # Proponer consenso para sincronización crítica
                    consensus_data = {
                        "peer_id": peer_id,
                        "operation": "sync_critical_state",
                        "updates_count": len(peer_updates)
                    }

                    consensus_success, message = await self.consensus_manager.propose_critical_operation(
                        "merge_models", consensus_data  # Usando merge_models como operación crítica genérica
                    )

                    if not consensus_success:
                        logger.warning(f"❌ Consenso fallido para sincronización crítica con {peer_id}: {message}")
                        # Continuar pero con precaución

                # Realizar sincronización
                success, conflicts = await self.state_sync.synchronize_with_peer(
                    peer_id, peer_state, peer_updates
                )

                # Notificar resolución de conflictos si los hubo
                if conflicts:
                    logger.info(f"⚖️ Resueltos {len(conflicts)} conflictos en sincronización con {peer_id}")

                return {
                    "status": "success" if success else "partial_success",
                    "conflicts_resolved": len(conflicts),
                    "local_state": self.state_sync.get_state_snapshot(),
                    "consensus_applied": has_critical_updates and consensus_success
                }

            except Exception as e:
                logger.error(f"Error en sincronización: {e}")
                raise HTTPException(status_code=500, detail=str(e))

    async def _handle_weight_submission(self, round_id: str, node_id: str,
                                       weights: Dict[str, torch.Tensor], metrics: Dict[str, Any]):
        """Maneja la recepción de pesos de un nodo."""
        # En una implementación completa, aquí se haría:
        # 1. Almacenar pesos temporalmente
        # 2. Esperar a que todos los nodos participen
        # 3. Agregar pesos usando FedAvg
        # 4. Actualizar pesos globales
        # 5. Notificar a nodos sobre nueva ronda

        logger.info(f"📥 Pesos recibidos de {node_id} para ronda {round_id}")
        logger.info(f"   📊 Accuracy local: {metrics.get('accuracy', 0):.2f}%")
        logger.info(f"   ⏱️ Tiempo de entrenamiento: {metrics.get('training_time', 0):.2f}s")

        # Sincronizar contribución con otros coordinadores
        contribution_info = {
            "round_id": round_id,
            "node_id": node_id,
            "metrics": metrics,
            "submitted_at": time.time()
        }
        self.state_sync.update_local_state(f"contribution_{round_id}_{node_id}", contribution_info, "create")

        # Broadcast actualización a todos los nodos conectados
        await self._broadcast_weight_received(node_id, round_id, metrics)

    async def _validate_contribution_integrity(self, round_id: str, node_id: str,
                                             weights: Dict[str, torch.Tensor], metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Valida la integridad de una contribución."""
        issues = []

        try:
            # Validar métricas básicas
            if 'accuracy' not in metrics or not isinstance(metrics['accuracy'], (int, float)):
                issues.append({
                    'type': 'invalid_metrics',
                    'description': f'Métricas inválidas para contribución de {node_id}',
                    'severity': 'warning'
                })

            # Validar pesos (checksum básico)
            if weights:
                total_params = sum(tensor.numel() for tensor in weights.values())
                if total_params == 0:
                    issues.append({
                        'type': 'empty_weights',
                        'description': f'Pesos vacíos en contribución de {node_id}',
                        'severity': 'error'
                    })

            # Aquí se podrían agregar más validaciones:
            # - Verificar que el nodo esté autorizado para la ronda
            # - Validar rangos de métricas
            # - Verificar integridad criptográfica si está disponible

        except Exception as e:
            logger.error(f"Error validando contribución de {node_id}: {e}")
            issues.append({
                'type': 'validation_error',
                'description': f'Error validando contribución: {str(e)}',
                'severity': 'error'
            })

        return issues

    async def _broadcast_node_registration(self, node_id: str, hardware_type: str):
        """Broadcast registro de nuevo nodo."""
        message = {
            "type": "node_registered",
            "node_id": node_id,
            "hardware_type": hardware_type,
            "timestamp": time.time()
        }

        await self._broadcast_to_all_nodes(message)

    async def _broadcast_session_created(self, session_id: str, model_version: str):
        """Broadcast creación de nueva sesión."""
        message = {
            "type": "session_created",
            "session_id": session_id,
            "model_version": model_version,
            "timestamp": time.time()
        }

        await self._broadcast_to_all_nodes(message)

    async def _broadcast_round_started(self, session_id: str, round_number: int, nodes: List[str]):
        """Broadcast inicio de nueva ronda."""
        message = {
            "type": "round_started",
            "session_id": session_id,
            "round_number": round_number,
            "participating_nodes": nodes,
            "timestamp": time.time()
        }

        await self._broadcast_to_all_nodes(message)

    async def _broadcast_weight_received(self, node_id: str, round_id: str, metrics: Dict[str, Any]):
        """Broadcast recepción de pesos."""
        message = {
            "type": "weight_received",
            "node_id": node_id,
            "round_id": round_id,
            "metrics": metrics,
            "timestamp": time.time()
        }

        await self._broadcast_to_all_nodes(message)

    async def _broadcast_to_all_nodes(self, message: Dict[str, Any]):
        """Envía mensaje a todos los nodos conectados via WebSocket."""
        disconnected = []

        for node_id, websocket in self.websocket_connections.items():
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.warning(f"Error enviando mensaje a {node_id}: {e}")
                disconnected.append(node_id)

        # Limpiar conexiones desconectadas
        for node_id in disconnected:
            del self.websocket_connections[node_id]

    async def _start_periodic_state_validation(self):
        """Inicia validación periódica del estado global."""
        while True:
            try:
                await asyncio.sleep(300)  # Validar cada 5 minutos

                # Validar estado global (simplificado - en producción usar DB real)
                logger.info("🔍 Ejecutando validación periódica del estado global")
                # Nota: La validación completa requiere acceso a DB, implementado en subclases

            except Exception as e:
                logger.error(f"❌ Error en validación periódica: {e}")

    async def handle_websocket(self, websocket, path):
        """Maneja conexiones WebSocket."""
        try:
            # Recibir mensaje inicial con node_id
            initial_message = await websocket.recv()
            data = json.loads(initial_message)

            node_id = data.get("node_id")
            if not node_id:
                await websocket.close()
                return

            # Registrar conexión
            self.websocket_connections[node_id] = websocket
            logger.info(f"🔌 Nodo {node_id} conectado via WebSocket")

            # Mantener conexión viva
            while True:
                try:
                    # Esperar mensajes del nodo (ping/pong, etc.)
                    message = await asyncio.wait_for(websocket.recv(), timeout=30.0)
                    # Procesar mensaje si es necesario
                except asyncio.TimeoutError:
                    # Enviar ping para mantener viva la conexión
                    await websocket.ping()
                except ConnectionClosedError:
                    break

        except Exception as e:
            logger.error(f"Error en WebSocket: {e}")
        finally:
            # Limpiar conexión
            if node_id in self.websocket_connections:
                del self.websocket_connections[node_id]
                logger.info(f"🔌 Nodo {node_id} desconectado")

    async def start_async(self):
        """Inicia el servidor del coordinador de forma asíncrona."""
        self.start_time = time.time()

        logger.info(f"🚀 Iniciando coordinador distribuido en {self.host}:{self.port}")

        # Iniciar servicio de sincronización
        await self.state_sync.start_sync_service()

        # Iniciar servicio de consenso
        await self.consensus_manager.start_consensus_service()

        # Iniciar validación periódica del estado
        asyncio.create_task(self._start_periodic_state_validation())

        # Configurar servidor WebSocket
        websocket_server = websockets.serve(
            self.handle_websocket,
            self.host,
            self.port + 1,  # Puerto WebSocket (8001)
            ping_interval=20,
            ping_timeout=10
        )

        # Iniciar ambos servidores
        loop = asyncio.get_event_loop()
        loop.create_task(websocket_server)

        # Iniciar servidor FastAPI
        config = uvicorn.Config(
            self.app,
            host=self.host,
            port=self.port,
            log_level="info"
        )
        server = uvicorn.Server(config)
        await server.serve()

    def start(self):
        """Inicia el servidor del coordinador."""
        asyncio.run(self.start_async())

    def get_status(self) -> Dict[str, Any]:
        """Obtiene el estado actual del coordinador."""
        return {
            "active_nodes": len(self.db.get_active_nodes()),
            "active_sessions": len(self.active_sessions),
            "websocket_connections": len(self.websocket_connections),
            "global_model_initialized": self.global_weights is not None,
            "uptime": time.time() - self.start_time if hasattr(self, 'start_time') else 0,
            "node_id": self.node_id,
            "sync_status": self.state_sync.get_sync_status(),
            "consensus_status": self.consensus_manager.get_status(),
            "integrity_health": self.state_validator.get_integrity_report()['health_status']
        }


# Funciones de conveniencia
def create_coordinator(host: str = "0.0.0.0", port: int = 8000) -> RealFederatedCoordinator:
    """Crea una instancia del coordinador."""
    return RealFederatedCoordinator(host, port)


def start_coordinator(host: str = "0.0.0.0", port: int = 8000):
    """Inicia el coordinador."""
    coordinator = create_coordinator(host, port)
    coordinator.start()


if __name__ == "__main__":
    # Iniciar coordinador para pruebas
    print("🚀 Iniciando Coordinador Federado de AILOOS...")
    print("📡 API REST: http://localhost:8000")
    print("🔌 WebSocket: ws://localhost:8001")
    print("📊 Dashboard: http://localhost:8000/docs")
    print()

    start_coordinator()