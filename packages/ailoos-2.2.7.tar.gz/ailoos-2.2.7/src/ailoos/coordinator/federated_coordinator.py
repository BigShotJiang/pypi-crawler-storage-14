#!/usr/bin/env python3
"""
Coordinador federado operativo con API REST para gestión de sesiones.
Implementa coordinación real de aprendizaje federado con endpoints HTTP.
"""

import asyncio
import time
import uuid
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from ..core.logging import get_logger
from ..core.config import get_config
from ..federated.coordinator import FederatedCoordinator
from ..federated.session import FederatedSession

logger = get_logger(__name__)


# Modelos Pydantic para API
class CreateSessionRequest(BaseModel):
    """Request para crear sesión federada."""
    model_name: str = Field(..., description="Nombre del modelo")
    min_nodes: int = Field(3, description="Mínimo número de nodos")
    max_nodes: int = Field(100, description="Máximo número de nodos")
    rounds: int = Field(5, description="Número de rondas")
    dataset_requirements: Optional[Dict[str, Any]] = Field(None, description="Requisitos del dataset")


class SessionResponse(BaseModel):
    """Response con información de sesión."""
    session_id: str
    model_name: str
    status: str
    participants: List[str]
    current_round: int
    total_rounds: int
    created_at: str
    min_nodes: int
    max_nodes: int


class NodeRegistrationRequest(BaseModel):
    """Request para registrar nodo."""
    node_id: str
    capabilities: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ModelUpdateRequest(BaseModel):
    """Request para enviar actualización de modelo."""
    node_id: str
    model_weights: Dict[str, List[float]]
    samples_used: int
    round_number: int
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CoordinatorStatusResponse(BaseModel):
    """Response con estado del coordinador."""
    active_sessions: int
    registered_nodes: int
    total_sessions: int
    uptime_seconds: float
    timestamp: str


@dataclass
class FederatedCoordinatorService:
    """Servicio de coordinador federado con API REST."""

    coordinator: FederatedCoordinator = None
    app: FastAPI = None
    config: Any = None
    start_time: float = field(default_factory=time.time)

    def __post_init__(self):
        if self.config is None:
            self.config = get_config()
        if self.coordinator is None:
            self.coordinator = FederatedCoordinator(self.config)
        if self.app is None:
            self.app = self._create_app()

        logger.info("🚀 Federated Coordinator Service initialized with real REST API")

    def _create_app(self) -> FastAPI:
        """Crear aplicación FastAPI."""

        @asynccontextmanager
        async def lifespan(app: FastAPI):
            # Startup
            logger.info("Starting Federated Coordinator API")
            yield
            # Shutdown
            logger.info("Shutting down Federated Coordinator API")

        app = FastAPI(
            title="AILOOS Federated Coordinator API",
            description="API REST para coordinación de aprendizaje federado",
            version="1.0.0",
            lifespan=lifespan
        )

        # CORS
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Routes
        @app.post("/sessions", response_model=SessionResponse)
        async def create_session(request: CreateSessionRequest):
            """Crear nueva sesión federada."""
            try:
                session = self.coordinator.create_session(
                    session_id=f"session_{uuid.uuid4().hex[:8]}",
                    model_name=request.model_name,
                    min_nodes=request.min_nodes,
                    max_nodes=request.max_nodes,
                    rounds=request.rounds
                )

                return SessionResponse(
                    session_id=session.session_id,
                    model_name=session.model_name,
                    status=session.status,
                    participants=list(session.participants),
                    current_round=session.current_round,
                    total_rounds=session.total_rounds,
                    created_at=getattr(session, 'created_at', datetime.now().isoformat()),
                    min_nodes=session.min_nodes,
                    max_nodes=session.max_nodes
                )
            except Exception as e:
                logger.error(f"Failed to create session: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/sessions", response_model=List[SessionResponse])
        async def list_sessions():
            """Listar todas las sesiones."""
            sessions = self.coordinator.get_active_sessions()
            return [
                SessionResponse(
                    session_id=s["session_id"],
                    model_name=s["model_name"],
                    status=s["status"],
                    participants=[],  # TODO: Add participants
                    current_round=s["current_round"],
                    total_rounds=s["total_rounds"],
                    created_at=datetime.now().isoformat(),  # TODO: Add real created_at
                    min_nodes=3,  # TODO: Add real values
                    max_nodes=100
                )
                for s in sessions
            ]

        @app.get("/sessions/{session_id}", response_model=SessionResponse)
        async def get_session(session_id: str):
            """Obtener información de sesión específica."""
            try:
                session = self.coordinator.get_session(session_id)
                if not session:
                    raise HTTPException(status_code=404, detail="Session not found")

                return SessionResponse(
                    session_id=session.session_id,
                    model_name=session.model_name,
                    status=session.status,
                    participants=list(session.participants),
                    current_round=session.current_round,
                    total_rounds=session.total_rounds,
                    created_at=getattr(session, 'created_at', datetime.now().isoformat()),
                    min_nodes=session.min_nodes,
                    max_nodes=session.max_nodes
                )
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to get session {session_id}: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/sessions/{session_id}/nodes")
        async def add_node_to_session(session_id: str, request: NodeRegistrationRequest):
            """Agregar nodo a sesión."""
            try:
                success = self.coordinator.add_node_to_session(session_id, request.node_id)
                if not success:
                    raise HTTPException(status_code=400, detail="Failed to add node to session")

                # Registrar nodo si no existe
                if not self.coordinator.get_node_info(request.node_id):
                    self.coordinator.register_node(request.node_id)

                return {"message": f"Node {request.node_id} added to session {session_id}"}
            except Exception as e:
                logger.error(f"Failed to add node to session: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/sessions/{session_id}/start")
        async def start_training(session_id: str, background_tasks: BackgroundTasks):
            """Iniciar entrenamiento federado."""
            try:
                result = self.coordinator.start_training(session_id)

                # Iniciar proceso de entrenamiento en background
                background_tasks.add_task(self._run_federated_training, session_id)

                return result
            except Exception as e:
                logger.error(f"Failed to start training for session {session_id}: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/sessions/{session_id}/updates")
        async def submit_model_update(session_id: str, request: ModelUpdateRequest):
            """Enviar actualización de modelo."""
            try:
                success = self.coordinator.submit_model_update(
                    session_id,
                    request.node_id,
                    {
                        "weights": request.model_weights,
                        "samples_used": request.samples_used
                    }
                )

                if not success:
                    raise HTTPException(status_code=400, detail="Failed to submit model update")

                return {"message": "Model update submitted successfully"}
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to submit model update: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/sessions/{session_id}/aggregate")
        async def aggregate_models(session_id: str):
            """Agregar modelos de la ronda actual."""
            try:
                result = self.coordinator.aggregate_models(session_id)
                return result
            except Exception as e:
                logger.error(f"Failed to aggregate models for session {session_id}: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/nodes")
        async def register_node(request: NodeRegistrationRequest):
            """Registrar nuevo nodo."""
            try:
                node_info = self.coordinator.register_node(request.node_id)
                return node_info
            except Exception as e:
                logger.error(f"Failed to register node {request.node_id}: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/nodes/{node_id}")
        async def get_node_info(node_id: str):
            """Obtener información de nodo."""
            try:
                node_info = self.coordinator.get_node_info(node_id)
                if not node_info:
                    raise HTTPException(status_code=404, detail="Node not found")
                return node_info
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to get node info for {node_id}: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/status", response_model=CoordinatorStatusResponse)
        async def get_status():
            """Obtener estado del coordinador."""
            try:
                global_status = self.coordinator.get_global_status()
                return CoordinatorStatusResponse(
                    active_sessions=global_status["active_sessions"],
                    registered_nodes=global_status["registered_nodes"],
                    total_sessions=global_status["total_sessions"],
                    uptime_seconds=time.time() - self.start_time,
                    timestamp=global_status["timestamp"]
                )
            except Exception as e:
                logger.error(f"Failed to get coordinator status: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.delete("/sessions/{session_id}")
        async def remove_session(session_id: str):
            """Remover sesión."""
            try:
                success = self.coordinator.remove_session(session_id)
                if not success:
                    raise HTTPException(status_code=404, detail="Session not found")
                return {"message": f"Session {session_id} removed"}
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to remove session {session_id}: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        return app

    async def _run_federated_training(self, session_id: str):
        """Ejecutar entrenamiento federado en background."""
        try:
            logger.info(f"Starting federated training for session {session_id}")

            session = self.coordinator.get_session(session_id)
            if not session:
                logger.error(f"Session {session_id} not found")
                return

            # Simular rondas de entrenamiento (en implementación real, esperar updates)
            for round_num in range(session.total_rounds):
                logger.info(f"Session {session_id}: Starting round {round_num + 1}")

                # Esperar actualizaciones de nodos (simulado)
                await asyncio.sleep(5)  # Simular tiempo de entrenamiento

                # Agregar modelos cuando haya suficientes updates
                if len(getattr(session, 'model_updates', {})) >= session.min_nodes:
                    result = self.coordinator.aggregate_models(session_id)
                    logger.info(f"Session {session_id}: Round {round_num + 1} completed")
                else:
                    logger.warning(f"Session {session_id}: Not enough model updates for round {round_num + 1}")

            logger.info(f"Federated training completed for session {session_id}")

        except Exception as e:
            logger.error(f"Error in federated training for session {session_id}: {e}")

    def start_server(self, host: str = "0.0.0.0", port: int = 8001):
        """Iniciar servidor API."""
        logger.info(f"Starting Federated Coordinator API on {host}:{port}")
        uvicorn.run(
            self.app,
            host=host,
            port=port,
            log_level="info"
        )

    async def start_async(self, host: str = "0.0.0.0", port: int = 8001):
        """Iniciar servidor de forma asíncrona."""
        config = uvicorn.Config(
            self.app,
            host=host,
            port=port,
            log_level="info"
        )
        server = uvicorn.Server(config)
        await server.serve()


# Instancia global
_coordinator_service: Optional[FederatedCoordinatorService] = None


def get_federated_coordinator_service() -> FederatedCoordinatorService:
    """Obtener instancia global del servicio de coordinador."""
    global _coordinator_service

    if _coordinator_service is None:
        _coordinator_service = FederatedCoordinatorService()

    return _coordinator_service


def start_coordinator_api(host: str = "0.0.0.0", port: int = 8001):
    """Función de conveniencia para iniciar la API."""
    service = get_federated_coordinator_service()
    service.start_server(host, port)


if __name__ == "__main__":
    # Ejecutar servidor directamente
    start_coordinator_api()