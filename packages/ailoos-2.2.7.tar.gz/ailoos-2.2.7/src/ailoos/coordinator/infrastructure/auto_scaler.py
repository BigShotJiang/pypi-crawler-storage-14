"""
Auto Scaler for Coordinator Infrastructure
Automatic scaling based on system metrics and training demand.
"""

import asyncio
import logging
import time
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
import psutil
import threading

logger = logging.getLogger(__name__)


@dataclass
class ScalingConfig:
    """Configuration for auto-scaling."""
    min_nodes: int = 1
    max_nodes: int = 10
    cpu_threshold_high: float = 80.0  # Scale up if CPU > 80%
    cpu_threshold_low: float = 20.0   # Scale down if CPU < 20%
    memory_threshold_high: float = 85.0
    memory_threshold_low: float = 30.0
    queue_threshold_high: int = 50    # Pending training jobs
    cooldown_period: int = 300         # 5 minutes between scaling actions
    scale_up_factor: float = 1.5       # Scale up by 50%
    scale_down_factor: float = 0.7     # Scale down to 70%
    enable_predictive: bool = True


@dataclass
class ScalingMetrics:
    """Current scaling metrics."""
    current_nodes: int = 0
    target_nodes: int = 0
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    queue_size: int = 0
    last_scaling_time: float = 0.0
    scaling_actions: List[Dict[str, Any]] = field(default_factory=list)


class AutoScaler:
    """
    Automatic scaling controller for federated training nodes.

    Monitors system metrics and training demand to automatically
    scale the number of active training nodes.
    """

    def __init__(self, config: ScalingConfig = None):
        self.config = config or ScalingConfig()
        self.metrics = ScalingMetrics()
        self.metrics.current_nodes = self.config.min_nodes
        self.metrics.target_nodes = self.config.min_nodes

        # Monitoring
        self.monitoring_active = False
        self.monitoring_thread: Optional[threading.Thread] = None
        self._lock = asyncio.Lock()

        logger.info(f"🚀 AutoScaler initialized with {self.config.min_nodes}-{self.config.max_nodes} nodes")

    async def start_monitoring(self) -> None:
        """Start the monitoring loop."""
        async with self._lock:
            if self.monitoring_active:
                return

            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitoring_thread.start()

            logger.info("📊 Auto-scaling monitoring started")

    async def stop_monitoring(self) -> None:
        """Stop the monitoring loop."""
        async with self._lock:
            self.monitoring_active = False
            if self.monitoring_thread:
                self.monitoring_thread.join(timeout=5.0)

            logger.info("🛑 Auto-scaling monitoring stopped")

    def _monitoring_loop(self) -> None:
        """Main monitoring loop."""
        while self.monitoring_active:
            try:
                self._update_metrics()
                self._check_scaling_conditions()
                time.sleep(30)  # Check every 30 seconds
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(10)

    def _update_metrics(self) -> None:
        """Update current system metrics."""
        try:
            # CPU usage
            self.metrics.cpu_usage = psutil.cpu_percent(interval=1)

            # Memory usage
            memory = psutil.virtual_memory()
            self.metrics.memory_usage = memory.percent

            # Queue size (simulated - would come from actual queue)
            self.metrics.queue_size = 0  # Placeholder

        except Exception as e:
            logger.warning(f"Error updating metrics: {e}")

    def _check_scaling_conditions(self) -> None:
        """Check if scaling is needed."""
        current_time = time.time()

        # Check cooldown period
        if current_time - self.metrics.last_scaling_time < self.config.cooldown_period:
            return

        # Determine target nodes
        target_nodes = self.metrics.current_nodes

        # Scale up conditions
        if (self.metrics.cpu_usage > self.config.cpu_threshold_high or
            self.metrics.memory_usage > self.config.memory_threshold_high or
            self.metrics.queue_size > self.config.queue_threshold_high):
            target_nodes = min(
                int(self.metrics.current_nodes * self.config.scale_up_factor),
                self.config.max_nodes
            )

        # Scale down conditions
        elif (self.metrics.cpu_usage < self.config.cpu_threshold_low and
              self.metrics.memory_usage < self.config.memory_threshold_low and
              self.metrics.queue_size < 10):  # Low queue threshold
            target_nodes = max(
                int(self.metrics.current_nodes * self.config.scale_down_factor),
                self.config.min_nodes
            )

        # Apply scaling if needed
        if target_nodes != self.metrics.current_nodes:
            asyncio.run(self._apply_scaling(target_nodes))

    async def _apply_scaling(self, target_nodes: int) -> None:
        """Apply scaling action."""
        async with self._lock:
            action = {
                'timestamp': time.time(),
                'from_nodes': self.metrics.current_nodes,
                'to_nodes': target_nodes,
                'reason': self._get_scaling_reason(),
                'cpu_usage': self.metrics.cpu_usage,
                'memory_usage': self.metrics.memory_usage,
                'queue_size': self.metrics.queue_size
            }

            self.metrics.target_nodes = target_nodes
            self.metrics.last_scaling_time = time.time()
            self.metrics.scaling_actions.append(action)

            # In a real implementation, this would trigger actual scaling
            # For now, just update the metrics
            self.metrics.current_nodes = target_nodes

            logger.info(f"⚖️ Auto-scaling: {action['from_nodes']} → {action['to_nodes']} nodes "
                       f"(CPU: {action['cpu_usage']:.1f}%, Memory: {action['memory_usage']:.1f}%)")

    def _get_scaling_reason(self) -> str:
        """Get the reason for scaling."""
        reasons = []
        if self.metrics.cpu_usage > self.config.cpu_threshold_high:
            reasons.append("high_cpu")
        if self.metrics.memory_usage > self.config.memory_threshold_high:
            reasons.append("high_memory")
        if self.metrics.queue_size > self.config.queue_threshold_high:
            reasons.append("high_queue")
        if self.metrics.cpu_usage < self.config.cpu_threshold_low:
            reasons.append("low_cpu")
        if self.metrics.memory_usage < self.config.memory_threshold_low:
            reasons.append("low_memory")

        return ", ".join(reasons) if reasons else "predictive"

    async def get_scaling_status(self) -> Dict[str, Any]:
        """Get current scaling status."""
        async with self._lock:
            return {
                'current_nodes': self.metrics.current_nodes,
                'target_nodes': self.metrics.target_nodes,
                'cpu_usage': self.metrics.cpu_usage,
                'memory_usage': self.metrics.memory_usage,
                'queue_size': self.metrics.queue_size,
                'last_scaling_time': self.metrics.last_scaling_time,
                'scaling_actions': self.metrics.scaling_actions[-10:],  # Last 10 actions
                'config': {
                    'min_nodes': self.config.min_nodes,
                    'max_nodes': self.config.max_nodes,
                    'cpu_threshold_high': self.config.cpu_threshold_high,
                    'cpu_threshold_low': self.config.cpu_threshold_low,
                    'cooldown_period': self.config.cooldown_period
                }
            }

    async def manual_scale(self, target_nodes: int) -> bool:
        """Manually scale to specific number of nodes."""
        if target_nodes < self.config.min_nodes or target_nodes > self.config.max_nodes:
            logger.error(f"Target nodes {target_nodes} out of range [{self.config.min_nodes}, {self.config.max_nodes}]")
            return False

        await self._apply_scaling(target_nodes)
        return True

    async def reset_to_minimum(self) -> None:
        """Reset to minimum number of nodes."""
        await self.manual_scale(self.config.min_nodes)


# Global instance
_auto_scaler = AutoScaler()


def get_auto_scaler() -> AutoScaler:
    """Get global auto scaler instance."""
    return _auto_scaler