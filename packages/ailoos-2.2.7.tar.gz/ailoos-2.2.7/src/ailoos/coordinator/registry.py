"""
Data Registry - Registro centralizado de datos y nodos en la red AILOOS
Mantiene el inventario de qué datasets tiene cada nodo y coordina la distribución.
"""

import json
import sqlite3
import threading
from typing import Dict, List, Any, Optional, Set
from datetime import datetime, timedelta
from pathlib import Path

from ..core.logging import get_logger

logger = get_logger(__name__)


class NodeInfo:
    """
    Información de un nodo en la red.
    """

    def __init__(self, node_id: str, capabilities: Optional[Dict[str, Any]] = None):
        self.node_id = node_id
        self.capabilities = capabilities or {}
        self.last_seen = datetime.now()
        self.status = "active"  # active, inactive, offline
        self.trust_score = 0.5  # 0-1, basado en comportamiento
        self.contribution_score = 0  # Puntos de contribución

    def to_dict(self) -> Dict[str, Any]:
        return {
            'node_id': self.node_id,
            'capabilities': self.capabilities,
            'last_seen': self.last_seen.isoformat(),
            'status': self.status,
            'trust_score': self.trust_score,
            'contribution_score': self.contribution_score
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NodeInfo':
        node = cls(data['node_id'], data.get('capabilities', {}))
        node.last_seen = datetime.fromisoformat(data['last_seen'])
        node.status = data.get('status', 'active')
        node.trust_score = data.get('trust_score', 0.5)
        node.contribution_score = data.get('contribution_score', 0)
        return node


class DatasetEntry:
    """
    Entrada de dataset en el registro.
    """

    def __init__(self, dataset_name: str, owner_node: str,
                 shard_cids: List[str], metadata: Optional[Dict[str, Any]] = None):
        self.dataset_name = dataset_name
        self.owner_node = owner_node
        self.shard_cids = shard_cids
        self.metadata = metadata or {}
        self.created_at = datetime.now()
        self.last_accessed = datetime.now()
        self.access_count = 0
        self.replica_nodes: Set[str] = set()  # Nodos que tienen réplicas
        self.quality_score = metadata.get('quality_score', 0.5) if metadata else 0.5

    def to_dict(self) -> Dict[str, Any]:
        return {
            'dataset_name': self.dataset_name,
            'owner_node': self.owner_node,
            'shard_cids': list(self.shard_cids),
            'metadata': self.metadata,
            'created_at': self.created_at.isoformat(),
            'last_accessed': self.last_accessed.isoformat(),
            'access_count': self.access_count,
            'replica_nodes': list(self.replica_nodes),
            'quality_score': self.quality_score
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DatasetEntry':
        entry = cls(
            data['dataset_name'],
            data['owner_node'],
            data['shard_cids'],
            data.get('metadata', {})
        )
        entry.created_at = datetime.fromisoformat(data['created_at'])
        entry.last_accessed = datetime.fromisoformat(data['last_accessed'])
        entry.access_count = data.get('access_count', 0)
        entry.replica_nodes = set(data.get('replica_nodes', []))
        entry.quality_score = data.get('quality_score', 0.5)
        return entry


class DataRegistry:
    """
    Registro centralizado que mantiene:
    - Inventario de datasets disponibles
    - Ubicación de shards en nodos
    - Información de nodos activos
    - Estadísticas de red
    """

    def __init__(self, db_path: str = "./data_cache/registry.db"):
        """
        Inicializa el registro de datos.

        Args:
            db_path: Ruta a la base de datos SQLite
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        # Caches en memoria para rendimiento
        self.nodes_cache: Dict[str, NodeInfo] = {}
        self.datasets_cache: Dict[str, DatasetEntry] = {}

        # Lock para thread safety
        self.lock = threading.RLock()

        # Inicializar base de datos
        self._init_database()
        self._load_from_database()

        logger.info(f"📋 DataRegistry inicializado con DB en {db_path}")

    def _init_database(self) -> None:
        """Inicializa las tablas de la base de datos."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            # Tabla de nodos
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS nodes (
                    node_id TEXT PRIMARY KEY,
                    capabilities TEXT,
                    last_seen TEXT,
                    status TEXT,
                    trust_score REAL,
                    contribution_score INTEGER,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Tabla de datasets
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS datasets (
                    dataset_name TEXT PRIMARY KEY,
                    owner_node TEXT,
                    shard_cids TEXT,
                    metadata TEXT,
                    created_at TEXT,
                    last_accessed TEXT,
                    access_count INTEGER,
                    replica_nodes TEXT,
                    quality_score REAL,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Tabla de shard locations (qué nodos tienen qué shards)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS shard_locations (
                    cid TEXT,
                    node_id TEXT,
                    dataset_name TEXT,
                    added_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (cid, node_id)
                )
            ''')

            conn.commit()

    def _load_from_database(self) -> None:
        """Carga datos desde la base de datos a los caches en memoria."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            # Cargar nodos
            cursor.execute('SELECT * FROM nodes')
            for row in cursor.fetchall():
                node_id, capabilities_json, last_seen, status, trust_score, contribution_score, _ = row
                capabilities = json.loads(capabilities_json) if capabilities_json else {}
                node_info = NodeInfo(node_id, capabilities)
                node_info.last_seen = datetime.fromisoformat(last_seen)
                node_info.status = status
                node_info.trust_score = trust_score
                node_info.contribution_score = contribution_score
                self.nodes_cache[node_id] = node_info

            # Cargar datasets
            cursor.execute('SELECT * FROM datasets')
            for row in cursor.fetchall():
                dataset_name, owner_node, shard_cids_json, metadata_json, created_at, last_accessed, access_count, replica_nodes_json, quality_score, _ = row
                shard_cids = json.loads(shard_cids_json) if shard_cids_json else []
                metadata = json.loads(metadata_json) if metadata_json else {}
                replica_nodes = set(json.loads(replica_nodes_json) if replica_nodes_json else [])

                dataset = DatasetEntry(dataset_name, owner_node, shard_cids, metadata)
                dataset.created_at = datetime.fromisoformat(created_at)
                dataset.last_accessed = datetime.fromisoformat(last_accessed)
                dataset.access_count = access_count
                dataset.replica_nodes = replica_nodes
                dataset.quality_score = quality_score
                self.datasets_cache[dataset_name] = dataset

        logger.info(f"📋 Cargados {len(self.nodes_cache)} nodos y {len(self.datasets_cache)} datasets desde DB")

    def register_node(self, node_id: str, capabilities: Optional[Dict[str, Any]] = None) -> None:
        """
        Registra o actualiza un nodo en la red.

        Args:
            node_id: ID único del nodo
            capabilities: Capacidades del nodo (GPU, RAM, etc.)
        """
        with self.lock:
            if node_id not in self.nodes_cache:
                self.nodes_cache[node_id] = NodeInfo(node_id, capabilities)
                logger.info(f"➕ Nuevo nodo registrado: {node_id}")
            else:
                self.nodes_cache[node_id].capabilities.update(capabilities or {})
                self.nodes_cache[node_id].last_seen = datetime.now()
                self.nodes_cache[node_id].status = "active"
                logger.debug(f"🔄 Nodo actualizado: {node_id}")

            # Guardar en DB
            self._save_node_to_db(self.nodes_cache[node_id])

    def unregister_node(self, node_id: str) -> bool:
        """
        Desregistra un nodo de la red.

        Args:
            node_id: ID del nodo a remover

        Returns:
            True si se removió correctamente
        """
        with self.lock:
            if node_id in self.nodes_cache:
                # Marcar como offline en lugar de eliminar completamente
                self.nodes_cache[node_id].status = "offline"
                self._save_node_to_db(self.nodes_cache[node_id])
                logger.info(f"📴 Nodo marcado como offline: {node_id}")
                return True
            return False

    def register_dataset(self, dataset_name: str, owner_node: str,
                        shard_cids: List[str], metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Registra un nuevo dataset en la red.

        Args:
            dataset_name: Nombre único del dataset
            owner_node: Nodo propietario
            shard_cids: Lista de CIDs de los shards
            metadata: Metadatos adicionales
        """
        with self.lock:
            if dataset_name in self.datasets_cache:
                logger.warning(f"Dataset ya existe: {dataset_name}")
                return

            dataset = DatasetEntry(dataset_name, owner_node, shard_cids, metadata)
            self.datasets_cache[dataset_name] = dataset

            # Registrar ubicaciones de shards
            for cid in shard_cids:
                self._add_shard_location(cid, owner_node, dataset_name)

            # Guardar en DB
            self._save_dataset_to_db(dataset)

            logger.info(f"📦 Dataset registrado: {dataset_name} ({len(shard_cids)} shards)")

    def update_node_heartbeat(self, node_id: str) -> None:
        """
        Actualiza el último visto de un nodo (heartbeat).

        Args:
            node_id: ID del nodo
        """
        with self.lock:
            if node_id in self.nodes_cache:
                self.nodes_cache[node_id].last_seen = datetime.now()
                self.nodes_cache[node_id].status = "active"
                self._save_node_to_db(self.nodes_cache[node_id])

    def record_shard_access(self, cid: str, node_id: str) -> None:
        """
        Registra que un nodo accedió a un shard.

        Args:
            cid: CID del shard
            node_id: ID del nodo que accedió
        """
        with self.lock:
            # Añadir como réplica si no estaba
            dataset_name = self._get_dataset_for_shard(cid)
            if dataset_name and dataset_name in self.datasets_cache:
                self.datasets_cache[dataset_name].replica_nodes.add(node_id)
                self.datasets_cache[dataset_name].last_accessed = datetime.now()
                self.datasets_cache[dataset_name].access_count += 1

                # Añadir ubicación del shard
                self._add_shard_location(cid, node_id, dataset_name)

                # Actualizar DB
                self._save_dataset_to_db(self.datasets_cache[dataset_name])

    def find_nodes_with_shard(self, cid: str) -> List[str]:
        """
        Encuentra nodos que tienen un shard específico.

        Args:
            cid: CID del shard

        Returns:
            Lista de IDs de nodos
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT node_id FROM shard_locations WHERE cid = ?', (cid,))
            return [row[0] for row in cursor.fetchall()]

    def find_best_nodes_for_shard(self, cid: str, max_nodes: int = 5) -> List[str]:
        """
        Encuentra los mejores nodos para descargar un shard (por confianza y cercanía).

        Args:
            cid: CID del shard
            max_nodes: Máximo número de nodos a retornar

        Returns:
            Lista ordenada de IDs de nodos (mejores primero)
        """
        nodes_with_shard = self.find_nodes_with_shard(cid)

        if not nodes_with_shard:
            return []

        # Ordenar por trust_score y last_seen
        node_scores = []
        for node_id in nodes_with_shard:
            if node_id in self.nodes_cache:
                node = self.nodes_cache[node_id]
                # Score basado en confianza y actividad reciente
                recency_hours = (datetime.now() - node.last_seen).total_seconds() / 3600
                recency_score = max(0, 1 - (recency_hours / 24))  # Degradación en 24h
                score = (node.trust_score * 0.7) + (recency_score * 0.3)
                node_scores.append((node_id, score))

        # Ordenar por score descendente
        node_scores.sort(key=lambda x: x[1], reverse=True)
        return [node_id for node_id, _ in node_scores[:max_nodes]]

    def get_dataset_info(self, dataset_name: str) -> Optional[Dict[str, Any]]:
        """
        Obtiene información completa de un dataset.

        Args:
            dataset_name: Nombre del dataset

        Returns:
            Información del dataset o None
        """
        with self.lock:
            if dataset_name not in self.datasets_cache:
                return None

            dataset = self.datasets_cache[dataset_name]
            return {
                'dataset_name': dataset.dataset_name,
                'owner_node': dataset.owner_node,
                'shard_cids': dataset.shard_cids,
                'metadata': dataset.metadata,
                'created_at': dataset.created_at.isoformat(),
                'last_accessed': dataset.last_accessed.isoformat(),
                'access_count': dataset.access_count,
                'replica_count': len(dataset.replica_nodes),
                'quality_score': dataset.quality_score,
                'available_shards': self._count_available_shards(dataset.shard_cids)
            }

    def search_datasets(self, query: str = "", category: str = "",
                       min_quality: float = 0.0, owner: str = "") -> List[Dict[str, Any]]:
        """
        Busca datasets por criterios.

        Args:
            query: Término de búsqueda en nombre/descripción
            category: Categoría específica
            min_quality: Calidad mínima
            owner: Propietario específico

        Returns:
            Lista de datasets que coinciden
        """
        results = []

        with self.lock:
            for dataset in self.datasets_cache.values():
                # Filtros
                if query and query.lower() not in dataset.dataset_name.lower():
                    continue
                if category and dataset.metadata.get('category') != category:
                    continue
                if dataset.quality_score < min_quality:
                    continue
                if owner and dataset.owner_node != owner:
                    continue

                results.append(self.get_dataset_info(dataset.dataset_name))

        # Ordenar por calidad y acceso reciente
        results.sort(key=lambda x: (x['quality_score'], x['access_count']), reverse=True)
        return results

    def get_network_stats(self) -> Dict[str, Any]:
        """
        Obtiene estadísticas generales de la red.

        Returns:
            Diccionario con estadísticas
        """
        with self.lock:
            total_nodes = len(self.nodes_cache)
            active_nodes = sum(1 for n in self.nodes_cache.values() if n.status == "active")
            total_datasets = len(self.datasets_cache)

            total_shards = sum(len(d.shard_cids) for d in self.datasets_cache.values())
            total_replicas = sum(len(d.replica_nodes) for d in self.datasets_cache.values())

            # Calcular distribución por categorías
            categories = {}
            for dataset in self.datasets_cache.values():
                cat = dataset.metadata.get('category', 'uncategorized')
                categories[cat] = categories.get(cat, 0) + 1

            return {
                'total_nodes': total_nodes,
                'active_nodes': active_nodes,
                'total_datasets': total_datasets,
                'total_shards': total_shards,
                'total_replicas': total_replicas,
                'categories': categories,
                'avg_quality_score': sum(d.quality_score for d in self.datasets_cache.values()) / max(total_datasets, 1),
                'last_updated': datetime.now().isoformat()
            }

    def _save_node_to_db(self, node: NodeInfo) -> None:
        """Guarda información de nodo en la base de datos."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO nodes
                (node_id, capabilities, last_seen, status, trust_score, contribution_score)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                node.node_id,
                json.dumps(node.capabilities),
                node.last_seen.isoformat(),
                node.status,
                node.trust_score,
                node.contribution_score
            ))
            conn.commit()

    def _save_dataset_to_db(self, dataset: DatasetEntry) -> None:
        """Guarda información de dataset en la base de datos."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO datasets
                (dataset_name, owner_node, shard_cids, metadata, created_at, last_accessed,
                 access_count, replica_nodes, quality_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                dataset.dataset_name,
                dataset.owner_node,
                json.dumps(dataset.shard_cids),
                json.dumps(dataset.metadata),
                dataset.created_at.isoformat(),
                dataset.last_accessed.isoformat(),
                dataset.access_count,
                json.dumps(list(dataset.replica_nodes)),
                dataset.quality_score
            ))
            conn.commit()

    def _add_shard_location(self, cid: str, node_id: str, dataset_name: str) -> None:
        """Registra la ubicación de un shard."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR IGNORE INTO shard_locations (cid, node_id, dataset_name)
                VALUES (?, ?, ?)
            ''', (cid, node_id, dataset_name))
            conn.commit()

    def _get_dataset_for_shard(self, cid: str) -> Optional[str]:
        """Encuentra el dataset que contiene un shard."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT dataset_name FROM shard_locations WHERE cid = ? LIMIT 1', (cid,))
            row = cursor.fetchone()
            return row[0] if row else None

    def _count_available_shards(self, shard_cids: List[str]) -> int:
        """Cuenta cuántos shards están disponibles en la red."""
        available = 0
        for cid in shard_cids:
            if self.find_nodes_with_shard(cid):
                available += 1
        return available


# Instancia global del registro
data_registry = DataRegistry()