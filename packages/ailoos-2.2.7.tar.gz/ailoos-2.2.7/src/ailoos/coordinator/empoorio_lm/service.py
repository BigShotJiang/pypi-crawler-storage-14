"""
EmpoorioLM Service
Servicio completo que integra todos los componentes de EmpoorioLM.
"""

import asyncio
import json
from typing import Dict, List, Any, Optional, Tuple, AsyncGenerator
from dataclasses import dataclass, field
import logging
from contextlib import asynccontextmanager

from .model_manager import ModelManager, ModelManagerConfig, create_model_manager
from .inference_engine import InferenceEngine, InferenceEngineConfig, create_inference_engine
from .version_controller import VersionController, VersionControllerConfig, create_version_controller
from .performance_optimizer import PerformanceOptimizer, PerformanceOptimizerConfig, create_performance_optimizer
from .version_manager import EmpoorioLMVersionManager

logger = logging.getLogger(__name__)


@dataclass
class EmpoorioLMServiceConfig:
    """Configuración completa del servicio EmpoorioLM."""

    # Configuración del servicio
    service_name: str = "empoorio_lm_service"
    enable_health_checks: bool = True
    enable_metrics: bool = True

    # Configuración de componentes
    model_manager: ModelManagerConfig = field(default_factory=ModelManagerConfig)
    inference_engine: InferenceEngineConfig = field(default_factory=InferenceEngineConfig)
    version_controller: VersionControllerConfig = field(default_factory=VersionControllerConfig)
    performance_optimizer: PerformanceOptimizerConfig = field(default_factory=PerformanceOptimizerConfig)

    # Configuración de versiones
    models_dir: str = "./models/empoorio_lm"
    auto_initialize_base_model: bool = True
    default_model_version: str = "v1.0.0"


class EmpoorioLMService:
    """
    Servicio completo de EmpoorioLM que integra todos los componentes.

    Este servicio proporciona:
    - API unificada para inferencia
    - Gestión automática de modelos y versiones
    - Optimización de rendimiento en tiempo real
    - Monitoreo y métricas completas
    - A/B testing y canary deployments
    """

    def __init__(self, config: EmpoorioLMServiceConfig):
        self.config = config

        # Componentes principales
        self.version_manager = EmpoorioLMVersionManager(models_dir=config.models_dir)
        self.model_manager = create_model_manager(self.version_manager, config.model_manager)
        self.inference_engine = create_inference_engine(self.model_manager, config.inference_engine)
        self.version_controller = create_version_controller(self.version_manager, config.version_controller)
        self.performance_optimizer = create_performance_optimizer(config.performance_optimizer)

        # Estado del servicio
        self.is_initialized = False
        self.is_running = False

        # Estadísticas del servicio
        self.service_stats = {
            "start_time": None,
            "total_requests": 0,
            "total_tokens_generated": 0,
            "uptime_seconds": 0
        }

        logger.info(f"🚀 EmpoorioLM Service creado: {config.service_name}")

    async def initialize(self) -> bool:
        """
        Inicializar el servicio completo.

        Returns:
            True si la inicialización fue exitosa
        """
        try:
            logger.info("🔧 Inicializando EmpoorioLM Service...")

            # Conectar componentes al optimizador de rendimiento
            self.performance_optimizer.set_components(
                inference_engine=self.inference_engine,
                model_manager=self.model_manager,
                version_controller=self.version_controller
            )

            # Inicializar modelo base si está configurado
            if self.config.auto_initialize_base_model:
                success = await self._initialize_base_model()
                if not success:
                    logger.error("❌ Falló inicialización del modelo base")
                    return False

            # Activar versión por defecto
            if self.config.default_model_version:
                success = await self._activate_default_version()
                if not success:
                    logger.warning(f"⚠️ No se pudo activar versión por defecto: {self.config.default_model_version}")

            # Marcar como inicializado
            self.is_initialized = True
            self.service_stats["start_time"] = asyncio.get_event_loop().time()

            logger.info("✅ EmpoorioLM Service inicializado correctamente")
            return True

        except Exception as e:
            logger.error(f"❌ Error inicializando servicio: {e}")
            return False

    async def start(self) -> bool:
        """
        Iniciar el servicio.

        Returns:
            True si el inicio fue exitoso
        """
        if not self.is_initialized:
            logger.error("❌ Servicio no inicializado")
            return False

        if self.is_running:
            return True

        try:
            logger.info("▶️ Iniciando EmpoorioLM Service...")

            # Iniciar Inference Engine
            await self.inference_engine.start()

            # Iniciar Performance Optimizer
            await self.performance_optimizer.start()

            # Marcar como running
            self.is_running = True

            logger.info("✅ EmpoorioLM Service iniciado correctamente")
            return True

        except Exception as e:
            logger.error(f"❌ Error iniciando servicio: {e}")
            return False

    async def stop(self):
        """Detener el servicio."""
        if not self.is_running:
            return

        logger.info("⏹️ Deteniendo EmpoorioLM Service...")

        try:
            # Detener componentes
            await self.inference_engine.stop()
            await self.performance_optimizer.stop()

            # Detener monitoreo de componentes
            self.model_manager.stop_monitoring()
            self.version_controller.stop_monitoring()

            self.is_running = False
            logger.info("✅ EmpoorioLM Service detenido correctamente")

        except Exception as e:
            logger.error(f"❌ Error deteniendo servicio: {e}")

    async def _initialize_base_model(self) -> bool:
        """Inicializar modelo base."""
        try:
            from ...models.empoorio_lm import EmpoorioLMConfig

            # Crear configuración básica
            model_config = EmpoorioLMConfig()

            # Inicializar modelo base
            success = await self.version_manager.initialize_base_model(model_config)
            if success:
                logger.info("📚 Modelo base EmpoorioLM inicializado")
                return True
            else:
                logger.error("❌ Falló inicialización del modelo base")
                return False

        except Exception as e:
            logger.error(f"❌ Error inicializando modelo base: {e}")
            return False

    async def _activate_default_version(self) -> bool:
        """Activar versión por defecto."""
        try:
            # Buscar versión por defecto
            versions = self.version_manager.list_versions()
            default_version = None

            for version in versions:
                if version["version_name"] == self.config.default_model_version:
                    default_version = version["version_id"]
                    break

            if not default_version:
                logger.warning(f"⚠️ Versión por defecto no encontrada: {self.config.default_model_version}")
                # Intentar usar la versión más reciente
                if versions:
                    default_version = versions[0]["version_id"]
                    logger.info(f"🔄 Usando versión más reciente como default: {default_version}")

            if default_version:
                success = await self.version_controller.activate_version(
                    version_id=default_version,
                    is_default=True
                )
                if success:
                    logger.info(f"🎯 Versión por defecto activada: {default_version}")
                    return True

            return False

        except Exception as e:
            logger.error(f"❌ Error activando versión por defecto: {e}")
            return False

    # API Methods

    async def generate_text(
        self,
        prompt: str,
        parameters: Optional[Dict[str, Any]] = None,
        model_preference: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Generar texto usando EmpoorioLM.

        Args:
            prompt: Texto de entrada
            parameters: Parámetros de generación
            model_preference: Preferencia de versión específica

        Returns:
            Resultado de generación o None si falló
        """
        if not self.is_running:
            logger.error("❌ Servicio no está ejecutándose")
            return None

        try:
            # Routing inteligente
            version_id = self.version_controller.route_request(model_preference)
            if not version_id:
                logger.error("❌ No hay versiones activas disponibles")
                return None

            # Enviar a Inference Engine
            request_id = await self.inference_engine.submit_request(
                model_version=version_id,
                input_text=prompt,
                parameters=parameters
            )

            # Obtener resultado (simplificado - en producción usar eventos)
            result = await self.inference_engine.get_result(request_id, timeout=30.0)

            if result:
                # Registrar métricas
                self.version_controller.record_request_metrics(
                    version_id=version_id,
                    response_time=result.processing_time,
                    success=True
                )

                # Actualizar estadísticas del servicio
                self.service_stats["total_requests"] += 1
                self.service_stats["total_tokens_generated"] += result.tokens_generated

                return {
                    "request_id": result.request_id,
                    "generated_text": result.output_text,
                    "model_version": result.model_version,
                    "tokens_generated": result.tokens_generated,
                    "processing_time": result.processing_time,
                    "metadata": result.metadata
                }
            else:
                # Registrar error
                self.version_controller.record_request_metrics(
                    version_id=version_id,
                    response_time=30.0,  # Timeout
                    success=False,
                    error_type="timeout"
                )
                return None

        except Exception as e:
            logger.error(f"❌ Error generando texto: {e}")
            return None

    async def stream_generate_text(
        self,
        prompt: str,
        parameters: Optional[Dict[str, Any]] = None,
        model_preference: Optional[str] = None
    ) -> Optional[AsyncGenerator[str, None]]:
        """
        Generar texto con streaming.

        Args:
            prompt: Texto de entrada
            parameters: Parámetros de generación
            model_preference: Preferencia de versión específica

        Returns:
            Generator de chunks de texto o None si falló
        """
        if not self.is_running:
            logger.error("❌ Servicio no está ejecutándose")
            return None

        try:
            # Routing inteligente
            version_id = self.version_controller.route_request(model_preference)
            if not version_id:
                logger.error("❌ No hay versiones activas disponibles")
                return None

            # Retornar generator del Inference Engine
            return self.inference_engine.stream_inference(
                model_version=version_id,
                input_text=prompt,
                parameters=parameters
            )

        except Exception as e:
            logger.error(f"❌ Error iniciando streaming: {e}")
            return None

    async def generate_batch(
        self,
        requests: List[Tuple[str, Optional[Dict[str, Any]]]],
        model_preference: Optional[str] = None
    ) -> Optional[str]:
        """
        Generar texto por lotes.

        Args:
            requests: Lista de (prompt, parameters)
            model_preference: Preferencia de versión específica

        Returns:
            ID del batch o None si falló
        """
        if not self.is_running:
            logger.error("❌ Servicio no está ejecutándose")
            return None

        try:
            # Routing inteligente (usar misma versión para todo el batch)
            version_id = self.version_controller.route_request(model_preference)
            if not version_id:
                logger.error("❌ No hay versiones activas disponibles")
                return None

            # Preparar requests para batch
            batch_requests = [
                (version_id, prompt, params)
                for prompt, params in requests
            ]

            # Enviar batch
            batch_id = await self.inference_engine.submit_batch_request(batch_requests)
            return batch_id

        except Exception as e:
            logger.error(f"❌ Error enviando batch: {e}")
            return None

    # Management API Methods

    async def activate_model_version(
        self,
        version_id: str,
        is_default: bool = False,
        traffic_percentage: Optional[float] = None
    ) -> bool:
        """
        Activar una versión del modelo.

        Args:
            version_id: ID de la versión
            is_default: Si debe ser la versión por defecto
            traffic_percentage: Porcentaje de tráfico

        Returns:
            True si se activó correctamente
        """
        return await self.version_controller.activate_version(
            version_id=version_id,
            is_default=is_default,
            traffic_percentage=traffic_percentage
        )

    async def deactivate_model_version(self, version_id: str) -> bool:
        """
        Desactivar una versión del modelo.

        Args:
            version_id: ID de la versión

        Returns:
            True si se desactivó correctamente
        """
        return await self.version_controller.deactivate_version(version_id)

    def get_service_status(self) -> Dict[str, Any]:
        """Obtener estado del servicio."""
        current_time = asyncio.get_event_loop().time()
        uptime = current_time - self.service_stats["start_time"] if self.service_stats["start_time"] else 0

        return {
            "service_name": self.config.service_name,
            "is_initialized": self.is_initialized,
            "is_running": self.is_running,
            "uptime_seconds": uptime,
            "total_requests": self.service_stats["total_requests"],
            "total_tokens_generated": self.service_stats["total_tokens_generated"],
            "active_versions": self.version_controller.get_active_versions_info(),
            "performance_metrics": self.performance_optimizer.get_performance_report(),
            "inference_stats": self.inference_engine.get_stats(),
            "model_cache_stats": self.model_manager.get_stats()
        }

    def get_service_health(self) -> Dict[str, Any]:
        """Obtener estado de salud del servicio."""
        health_status = {
            "status": "healthy",
            "checks": {}
        }

        # Verificar componentes principales
        health_status["checks"]["service_initialized"] = {
            "status": "pass" if self.is_initialized else "fail",
            "message": "Service is initialized" if self.is_initialized else "Service not initialized"
        }

        health_status["checks"]["service_running"] = {
            "status": "pass" if self.is_running else "fail",
            "message": "Service is running" if self.is_running else "Service not running"
        }

        # Verificar Inference Engine
        ie_stats = self.inference_engine.get_stats()
        ie_healthy = ie_stats.get("is_running", False)
        health_status["checks"]["inference_engine"] = {
            "status": "pass" if ie_healthy else "fail",
            "message": f"Inference Engine healthy ({ie_stats.get('active_requests', 0)} active requests)"
        }

        # Verificar Model Manager
        mm_stats = self.model_manager.get_stats()
        mm_healthy = mm_stats.get("current_models_loaded", 0) >= 0
        health_status["checks"]["model_manager"] = {
            "status": "pass" if mm_healthy else "fail",
            "message": f"Model Manager healthy ({mm_stats.get('current_models_loaded', 0)} models loaded)"
        }

        # Verificar Version Controller
        vc_info = self.version_controller.get_active_versions_info()
        vc_healthy = vc_info.get("total_active", 0) > 0
        health_status["checks"]["version_controller"] = {
            "status": "pass" if vc_healthy else "warn",
            "message": f"Version Controller healthy ({vc_info.get('total_active', 0)} active versions)"
        }

        # Determinar estado general
        if any(check["status"] == "fail" for check in health_status["checks"].values()):
            health_status["status"] = "unhealthy"
        elif any(check["status"] == "warn" for check in health_status["checks"].values()):
            health_status["status"] = "warning"

        return health_status

    def get_performance_report(self) -> Dict[str, Any]:
        """Obtener reporte de rendimiento completo."""
        return self.performance_optimizer.get_performance_report()

    def get_optimization_recommendations(self) -> List[Dict[str, Any]]:
        """Obtener recomendaciones de optimización."""
        return self.performance_optimizer.get_optimization_recommendations()

    def get_batch_status(self, batch_id: str) -> Dict[str, Any]:
        """Obtener estado de un batch desde el Inference Engine."""
        return self.inference_engine.get_batch_status(batch_id)


# Funciones de conveniencia
def create_empoorio_lm_service(
    config: Optional[EmpoorioLMServiceConfig] = None
) -> EmpoorioLMService:
    """Crear instancia del servicio EmpoorioLM."""
    if config is None:
        config = EmpoorioLMServiceConfig()

    return EmpoorioLMService(config)


@asynccontextmanager
async def lifespan_manager(service: EmpoorioLMService):
    """Context manager para lifespan del servicio."""
    try:
        # Inicializar y iniciar
        await service.initialize()
        await service.start()
        yield service
    finally:
        # Limpiar
        await service.stop()