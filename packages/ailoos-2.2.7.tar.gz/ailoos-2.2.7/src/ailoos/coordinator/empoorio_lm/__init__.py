"""
EmpoorioLM Coordinator Package
Sistema de coordinación para el entrenamiento federado de EmpoorioLM v1.0.
"""

from .coordinator import EmpoorioLMCoordinator, EmpoorioLMCoordinatorConfig
from .aggregator import EmpoorioLMAggregator
from .version_manager import EmpoorioLMVersionManager
from .model_manager import ModelManager, ModelManagerConfig, create_model_manager
from .inference_engine import InferenceEngine, InferenceEngineConfig, create_inference_engine
from .version_controller import VersionController, VersionControllerConfig, create_version_controller
from .performance_optimizer import PerformanceOptimizer, PerformanceOptimizerConfig, create_performance_optimizer
from .service import EmpoorioLMService, EmpoorioLMServiceConfig, create_empoorio_lm_service

__all__ = [
    # Legacy components
    'EmpoorioLMCoordinator',
    'EmpoorioLMCoordinatorConfig',
    'EmpoorioLMAggregator',
    'EmpoorioLMVersionManager',

    # New service components
    'ModelManager',
    'ModelManagerConfig',
    'create_model_manager',
    'InferenceEngine',
    'InferenceEngineConfig',
    'create_inference_engine',
    'VersionController',
    'VersionControllerConfig',
    'create_version_controller',
    'PerformanceOptimizer',
    'PerformanceOptimizerConfig',
    'create_performance_optimizer',
    'EmpoorioLMService',
    'EmpoorioLMServiceConfig',
    'create_empoorio_lm_service'
]