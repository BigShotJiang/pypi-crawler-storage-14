"""
EmpoorioLM Version Manager
Sistema de versionado y gestión del ciclo de vida de modelos EmpoorioLM.
"""

import json
import hashlib
import time
import torch
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import logging
from dataclasses import dataclass, field
from datetime import datetime
import asyncio

from ...models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig

logger = logging.getLogger(__name__)


@dataclass
class ModelVersion:
    """Información de una versión específica del modelo."""

    version_id: str
    version_name: str
    model_path: str
    config_path: str
    created_at: float
    description: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Información de calidad
    quality_metrics: Dict[str, float] = field(default_factory=dict)

    # Información de federated learning
    federated_info: Dict[str, Any] = field(default_factory=dict)

    # Estado
    is_active: bool = True
    deprecated_at: Optional[float] = None

    # Hash para integridad
    model_hash: Optional[str] = None
    config_hash: Optional[str] = None


@dataclass
class VersionComparison:
    """Resultado de comparación entre versiones."""

    version_a: str
    version_b: str
    parameter_changes: Dict[str, Tuple[float, float]]
    performance_changes: Dict[str, Tuple[float, float]]
    federated_improvements: Dict[str, Any]


class EmpoorioLMVersionManager:
    """
    Gestor de versiones para modelos EmpoorioLM.

    Funcionalidades:
    - Versionado semántico (v1.0.0, v1.0.1, etc.)
    - Almacenamiento de modelos con metadatos
    - Comparación de versiones
    - Gestión del ciclo de vida
    - Integridad de modelos
    """

    def __init__(self, models_dir: str = "./models/empoorio_lm/versions", enable_regression_testing: bool = True):
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)

        # Configuración de regression testing
        self.enable_regression_testing = enable_regression_testing
        self.regression_test_api_url = "http://localhost:8000/inference"

        # Estado interno
        self.versions: Dict[str, ModelVersion] = {}
        self.version_history: List[str] = []
        self.latest_version: Optional[str] = None

        # Archivo de índice
        self.index_file = self.models_dir / "version_index.json"

        # Cargar versiones existentes
        self._load_version_index_sync()

        logger.info(f"📚 Version Manager inicializado con {len(self.versions)} versiones")
        if self.enable_regression_testing:
            logger.info("🧪 Regression testing habilitado")

    async def initialize_base_model(self, model_config: EmpoorioLMConfig) -> bool:
        """
        Inicializar modelo base del sistema.

        Args:
            model_config: Configuración del modelo base

        Returns:
            True si se inicializó correctamente
        """
        try:
            # Crear modelo base con configuración proporcionada
            model = EmpoorioLM(model_config)

            # Crear versión base
            version_id = await self.create_version(
                model=model,
                version_name="v1.0.0",
                description="Modelo base del sistema AILOOS",
                metadata={"is_base_model": True, "initialized_at": time.time()}
            )

            if version_id:
                logger.info("📚 Modelo base inicializado correctamente")
                return True
            else:
                logger.error("❌ Falló creación de versión base")
                return False

        except Exception as e:
            logger.error(f"❌ Error inicializando modelo base: {e}")
            return False

    async def create_version(
        self,
        model: Optional[EmpoorioLM] = None,
        model_weights: Optional[Dict[str, Any]] = None,
        model_config: Optional[Dict[str, Any]] = None,
        version_name: str = None,
        description: str = "",
        metadata: Dict[str, Any] = None
    ) -> Optional[str]:
        """
        Crear una nueva versión del modelo.

        Args:
            model: Instancia de EmpoorioLM (opcional)
            model_weights: Pesos del modelo como diccionario (opcional)
            model_config: Configuración del modelo como diccionario (opcional)
            version_name: Nombre de versión (auto-generado si None)
            description: Descripción de la versión
            metadata: Metadatos adicionales

        Returns:
            ID de la versión creada o None si falló
        """
        try:
            # Generar ID único
            timestamp = int(time.time())
            if version_name is None:
                # Auto-generar versión basada en la última
                version_name = self._generate_next_version()

            version_id = f"empoorio_lm_{version_name}_{timestamp}"

            # Crear directorio de versión
            version_dir = self.models_dir / version_id
            version_dir.mkdir(exist_ok=True)

            # Guardar modelo
            model_path = version_dir / "pytorch_model.bin"
            config_path = version_dir / "config.json"
            metadata_path = version_dir / "version_metadata.json"

            if model is not None:
                # Guardar desde instancia de modelo
                await self._save_model_instance(model, version_dir)
                model_weights = model.state_dict()
            elif model_weights is not None:
                # Guardar desde pesos
                await self._save_model_weights(model_weights, model_config, version_dir)
            else:
                logger.error("❌ Se requiere modelo o pesos para crear versión")
                return None

            # Calcular hashes para integridad
            model_hash = self._calculate_file_hash(model_path)
            config_hash = self._calculate_file_hash(config_path)

            # Crear objeto de versión
            version = ModelVersion(
                version_id=version_id,
                version_name=version_name,
                model_path=str(model_path),
                config_path=str(config_path),
                created_at=timestamp,
                description=description,
                metadata=metadata or {},
                model_hash=model_hash,
                config_hash=config_hash
            )

            # Guardar metadatos
            await self._save_version_metadata(version, metadata_path)

            # Registrar versión
            self.versions[version_id] = version
            self.version_history.append(version_id)
            self.latest_version = version_id

            # Guardar índice actualizado
            await self._save_version_index()

            logger.info(f"✅ Versión creada: {version_name} ({version_id})")

            # Ejecutar regression testing automáticamente si está habilitado
            if self.enable_regression_testing:
                try:
                    await self._run_regression_testing(version_id)
                except Exception as e:
                    logger.error(f"❌ Error en regression testing para {version_id}: {e}")
                    # No fallar la creación de versión por error en testing

            return version_id

        except Exception as e:
            logger.error(f"❌ Error creando versión: {e}")
            return None

    def _generate_next_version(self) -> str:
        """Generar siguiente número de versión."""
        if not self.version_history:
            return "v1.0.0"

        # Obtener última versión
        last_version = self.versions[self.latest_version].version_name

        try:
            # Parsear versión semántica
            parts = last_version.lstrip('v').split('.')
            major, minor, patch = map(int, parts)

            # Incrementar patch por defecto
            patch += 1

            return f"v{major}.{minor}.{patch}"

        except (ValueError, IndexError):
            # Fallback: añadir timestamp
            return f"v1.0.{int(time.time())}"

    async def _save_model_instance(self, model: EmpoorioLM, version_dir: Path):
        """Guardar instancia completa del modelo."""
        model_path = version_dir / "pytorch_model.bin"
        config_path = version_dir / "config.json"

        # Guardar pesos
        torch.save(model.state_dict(), model_path)

        # Guardar configuración
        config_dict = model.config.to_dict()
        with open(config_path, 'w') as f:
            json.dump(config_dict, f, indent=2)

    async def _save_model_weights(self, weights: Dict[str, Any], config_dict: Optional[Dict[str, Any]], version_dir: Path):
        """Guardar pesos del modelo."""
        import torch

        model_path = version_dir / "pytorch_model.bin"
        config_path = version_dir / "config.json"

        # Guardar pesos
        torch.save(weights, model_path)

        if config_dict is None:
            # Crear configuración básica con valores por defecto
            logger.warning("No se proporcionó configuración del modelo. Usando configuración por defecto.")
            config = EmpoorioLMConfig()
            config_dict = config.to_dict()

        with open(config_path, 'w') as f:
            json.dump(config_dict, f, indent=2)

    async def _save_version_metadata(self, version: ModelVersion, metadata_path: Path):
        """Guardar metadatos de la versión."""
        metadata = {
            "version_id": version.version_id,
            "version_name": version.version_name,
            "created_at": version.created_at,
            "description": version.description,
            "metadata": version.metadata,
            "quality_metrics": version.quality_metrics,
            "federated_info": version.federated_info,
            "model_hash": version.model_hash,
            "config_hash": version.config_hash,
            "is_active": version.is_active
        }

        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2, default=str)

    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calcular hash SHA256 de un archivo."""
        if not file_path.exists():
            return ""

        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()

    async def load_version(self, version_id: str) -> Optional[EmpoorioLM]:
        """
        Cargar una versión específica del modelo.

        Args:
            version_id: ID de la versión

        Returns:
            Instancia del modelo o None si no existe
        """
        if version_id not in self.versions:
            logger.error(f"❌ Versión no encontrada: {version_id}")
            return None

        version = self.versions[version_id]

        try:
            # Verificar integridad
            if not await self._verify_version_integrity(version):
                logger.error(f"❌ Integridad comprometida para versión: {version_id}")
                return None

            # Cargar modelo
            model = EmpoorioLM.from_pretrained(str(Path(version.model_path).parent))
            logger.info(f"✅ Versión cargada: {version.version_name}")
            return model

        except Exception as e:
            logger.error(f"❌ Error cargando versión {version_id}: {e}")
            return None

    async def _verify_version_integrity(self, version: ModelVersion) -> bool:
        """Verificar integridad de una versión."""
        try:
            # Verificar hashes
            current_model_hash = self._calculate_file_hash(Path(version.model_path))
            current_config_hash = self._calculate_file_hash(Path(version.config_path))

            model_integrity = current_model_hash == version.model_hash
            config_integrity = current_config_hash == version.config_hash

            if not model_integrity:
                logger.warning(f"⚠️ Hash del modelo no coincide para {version.version_id}")

            if not config_integrity:
                logger.warning(f"⚠️ Hash de config no coincide para {version.version_id}")

            return model_integrity and config_integrity

        except Exception as e:
            logger.error(f"Error verificando integridad: {e}")
            return False

    def get_latest_version(self) -> Optional[str]:
        """Obtener la versión más reciente."""
        return self.latest_version

    def get_version_info(self, version_id: str) -> Optional[Dict[str, Any]]:
        """Obtener información de una versión."""
        if version_id not in self.versions:
            return None

        version = self.versions[version_id]
        return {
            "version_id": version.version_id,
            "version_name": version.version_name,
            "created_at": datetime.fromtimestamp(version.created_at).isoformat(),
            "description": version.description,
            "metadata": version.metadata,
            "quality_metrics": version.quality_metrics,
            "federated_info": version.federated_info,
            "is_active": version.is_active,
            "model_hash": version.model_hash,
            "config_hash": version.config_hash
        }

    def list_versions(self, active_only: bool = True) -> List[Dict[str, Any]]:
        """Listar todas las versiones."""
        versions = []
        for version in self.versions.values():
            if active_only and not version.is_active:
                continue

            versions.append(self.get_version_info(version.version_id))

        # Ordenar por fecha de creación (más reciente primero)
        versions.sort(key=lambda x: x["created_at"], reverse=True)
        return versions

    async def compare_versions(
        self,
        version_a: str,
        version_b: str
    ) -> Optional[VersionComparison]:
        """
        Comparar dos versiones del modelo.

        Args:
            version_a: ID de la primera versión
            version_b: ID de la segunda versión

        Returns:
            Comparación detallada o None si falló
        """
        if version_a not in self.versions or version_b not in self.versions:
            logger.error("❌ Una o ambas versiones no existen")
            return None

        try:
            # Cargar modelos
            model_a = await self.load_version(version_a)
            model_b = await self.load_version(version_b)

            if model_a is None or model_b is None:
                return None

            # Comparar parámetros
            param_changes = {}
            for (name_a, param_a), (name_b, param_b) in zip(
                model_a.named_parameters(),
                model_b.named_parameters()
            ):
                if name_a == name_b:
                    mean_a = param_a.mean().item()
                    mean_b = param_b.mean().item()
                    param_changes[name_a] = (mean_a, mean_b)

            # Comparar rendimiento desde métricas de calidad guardadas
            version_a_info = self.versions[version_a]
            version_b_info = self.versions[version_b]
            metrics_a = version_a_info.quality_metrics
            metrics_b = version_b_info.quality_metrics
            
            performance_changes = {}
            all_keys = set(metrics_a.keys()) | set(metrics_b.keys())
            for key in all_keys:
                performance_changes[key] = (metrics_a.get(key), metrics_b.get(key))

            if not performance_changes:
                logger.warning("No hay métricas de calidad para comparar rendimiento. Los resultados de rendimiento estarán vacíos.")

            # Información federada
            federated_improvements = {
                "rounds_improved": version_b_info.metadata.get("round", 0) - version_a_info.metadata.get("round", 0),
                "nodes_increased": version_b_info.federated_info.get("num_contributions", 0) - version_a_info.federated_info.get("num_contributions", 0)
            }

            return VersionComparison(
                version_a=version_a,
                version_b=version_b,
                parameter_changes=param_changes,
                performance_changes=performance_changes,
                federated_improvements=federated_improvements
            )

        except Exception as e:
            logger.error(f"❌ Error comparando versiones: {e}")
            return None

    async def deprecate_version(self, version_id: str, reason: str = ""):
        """Marcar una versión como obsoleta."""
        if version_id in self.versions:
            self.versions[version_id].is_active = False
            self.versions[version_id].deprecated_at = time.time()
            self.versions[version_id].metadata["deprecation_reason"] = reason

            await self._save_version_index()
            logger.info(f"📋 Versión deprecada: {version_id}")

    async def cleanup_old_versions(self, keep_last: int = 10):
        """Limpiar versiones antiguas, manteniendo las más recientes."""
        if len(self.version_history) <= keep_last:
            return

        # Obtener versiones a eliminar
        versions_to_remove = self.version_history[:-keep_last]

        for version_id in versions_to_remove:
            if version_id in self.versions:
                version = self.versions[version_id]

                # Eliminar archivos
                try:
                    version_dir = Path(version.model_path).parent
                    import shutil
                    shutil.rmtree(version_dir)
                    logger.info(f"🗑️ Eliminada versión: {version_id}")
                except Exception as e:
                    logger.error(f"Error eliminando versión {version_id}: {e}")

                # Remover de registros
                del self.versions[version_id]

        # Actualizar historial
        self.version_history = self.version_history[-keep_last:]

        await self._save_version_index()

    def _load_version_index_sync(self):
        """Cargar índice de versiones desde disco (sincrónico)."""
        if not self.index_file.exists():
            return

        try:
            with open(self.index_file, 'r') as f:
                index_data = json.load(f)

            # Reconstruir versiones
            for version_data in index_data.get("versions", []):
                version = ModelVersion(**version_data)
                self.versions[version.version_id] = version

            self.version_history = index_data.get("history", [])
            self.latest_version = index_data.get("latest_version")

            logger.info(f"📚 Cargado índice con {len(self.versions)} versiones")

        except Exception as e:
            logger.error(f"Error cargando índice de versiones: {e}")

    async def _load_version_index(self):
        """Cargar índice de versiones desde disco."""
        if not self.index_file.exists():
            return

        try:
            with open(self.index_file, 'r') as f:
                index_data = json.load(f)

            # Reconstruir versiones
            for version_data in index_data.get("versions", []):
                version = ModelVersion(**version_data)
                self.versions[version.version_id] = version

            self.version_history = index_data.get("history", [])
            self.latest_version = index_data.get("latest_version")

            logger.info(f"📚 Cargado índice con {len(self.versions)} versiones")

        except Exception as e:
            logger.error(f"Error cargando índice de versiones: {e}")

    async def _save_version_index(self):
        """Guardar índice de versiones en disco."""
        index_data = {
            "versions": [vars(v) for v in self.versions.values()],
            "history": self.version_history,
            "latest_version": self.latest_version,
            "last_updated": time.time()
        }

        with open(self.index_file, 'w') as f:
            json.dump(index_data, f, indent=2, default=str)

    async def _run_regression_testing(self, version_id: str):
        """Ejecuta regression testing para una nueva versión."""
        try:
            # Importar aquí para evitar dependencias circulares
            from tests.test_accuracy_regression_suite import run_post_federated_update_evaluation

            logger.info(f"🧪 Ejecutando regression testing para versión {version_id}")

            # Ejecutar evaluación
            report = await run_post_federated_update_evaluation(
                version_id,
                api_url=self.regression_test_api_url
            )

            # Actualizar metadatos de la versión con resultados de testing
            if version_id in self.versions:
                self.versions[version_id].quality_metrics.update({
                    "regression_test_accuracy": report.overall_accuracy,
                    "regression_test_forgetting_detected": report.forgetting_detected,
                    "regression_test_forgetting_categories": report.forgetting_categories,
                    "regression_test_timestamp": report.evaluation_timestamp
                })

                # Guardar metadatos actualizados
                await self._save_version_metadata(
                    self.versions[version_id],
                    Path(self.versions[version_id].model_path).parent / "version_metadata.json"
                )

            logger.info(f"✅ Regression testing completado: {report.overall_accuracy:.3f} accuracy")

            # Lanzar excepción si hay forgetting crítico (bloquea deployment)
            if report.forgetting_detected:
                critical_categories = ["architecture", "security", "machine_learning"]
                critical_forgetting = [
                    cat for cat in report.forgetting_categories
                    if cat in critical_categories
                ]
                if critical_forgetting:
                    raise Exception(f"Deployment bloqueado: forgetting crítico en {critical_forgetting}")

        except ImportError:
            logger.warning("⚠️ Módulos de regression testing no disponibles, omitiendo evaluación")
        except Exception as e:
            logger.error(f"❌ Error en regression testing: {e}")
            # Re-lanzar para que el caller pueda manejar el bloqueo de deployment
            raise

    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del version manager."""
        return {
            "total_versions": len(self.versions),
            "active_versions": len([v for v in self.versions.values() if v.is_active]),
            "latest_version": self.latest_version,
            "versions_created_today": len([
                v for v in self.versions.values()
                if datetime.fromtimestamp(v.created_at).date() == datetime.now().date()
            ])
        }


# Funciones de conveniencia
def create_version_name(major: int = 1, minor: int = 0, patch: int = 0) -> str:
    """Crear nombre de versión semántico."""
    return f"v{major}.{minor}.{patch}"


def parse_version(version_name: str) -> Tuple[int, int, int]:
    """Parsear versión semántica."""
    parts = version_name.lstrip('v').split('.')
    return tuple(map(int, parts))