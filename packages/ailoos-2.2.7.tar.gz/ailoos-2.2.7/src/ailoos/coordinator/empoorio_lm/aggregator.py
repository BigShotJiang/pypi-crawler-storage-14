"""
EmpoorioLM Aggregator
Sistema de agregación optimizado para modelos de lenguaje transformer en federated learning.
"""

import torch
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
import logging
from collections import defaultdict
import time

logger = logging.getLogger(__name__)


class EmpoorioLMAggregator:
    """
    Agregador especializado para modelos EmpoorioLM.

    Implementa algoritmos de agregación optimizados para transformers:
    - FedAvg optimizado para atención multi-head
    - FedNova para compensación de datos heterogéneos
    - SCAFFOLD para corrección de varianza del cliente
    """

    def __init__(self):
        self.aggregation_stats = {
            "total_aggregations": 0,
            "total_nodes_processed": 0,
            "avg_aggregation_time": 0.0,
            "failed_aggregations": 0
        }

        logger.info("🎯 EmpoorioLM Aggregator inicializado")

    async def aggregate_weights(
        self,
        node_weights: Dict[str, Dict[str, torch.Tensor]],
        aggregation_method: str = "fedavg",
        quality_weights: Optional[Dict[str, float]] = None,
        validation_fn: Optional[callable] = None
    ) -> Optional[Dict[str, torch.Tensor]]:
        """
        Agregar pesos de múltiples nodos usando el método especificado.

        Args:
            node_weights: Diccionario de node_id -> pesos del modelo
            aggregation_method: Método de agregación ('fedavg', 'fednova', 'scaffold')
            quality_weights: Pesos de calidad por nodo (opcional)
            validation_fn: Función de validación de pesos (opcional)

        Returns:
            Pesos agregados o None si falló
        """
        start_time = time.time()

        try:
            if not node_weights:
                logger.error("❌ No hay pesos de nodos para agregar")
                return None

            num_nodes = len(node_weights)
            logger.info(f"🔄 Agregando pesos de {num_nodes} nodos usando {aggregation_method}")

            # Validar pesos de entrada
            if not self._validate_node_weights(node_weights):
                logger.error("❌ Pesos de nodos inválidos")
                return None

            # Aplicar validación adicional si se proporciona
            if validation_fn:
                valid_weights = {}
                for node_id, weights in node_weights.items():
                    if validation_fn(weights):
                        valid_weights[node_id] = weights
                    else:
                        logger.warning(f"⚠️ Pesos inválidos para nodo {node_id}, omitiendo")
                node_weights = valid_weights

            if not node_weights:
                logger.error("❌ No quedan pesos válidos después de validación")
                return None

            # Seleccionar método de agregación
            if aggregation_method == "fedavg":
                aggregated = self._fedavg_aggregate(node_weights, quality_weights)
            elif aggregation_method == "fednova":
                aggregated = self._fednova_aggregate(node_weights, quality_weights)
            elif aggregation_method == "scaffold":
                aggregated = self._scaffold_aggregate(node_weights, quality_weights)
            else:
                logger.error(f"❌ Método de agregación no soportado: {aggregation_method}")
                return None

            # Validar resultado final
            if not self._validate_aggregated_weights(aggregated):
                logger.error("❌ Pesos agregados inválidos")
                return None

            # Actualizar estadísticas
            aggregation_time = time.time() - start_time
            self.aggregation_stats["total_aggregations"] += 1
            self.aggregation_stats["total_nodes_processed"] += num_nodes
            self.aggregation_stats["avg_aggregation_time"] = (
                (self.aggregation_stats["avg_aggregation_time"] * (self.aggregation_stats["total_aggregations"] - 1)) +
                aggregation_time
            ) / self.aggregation_stats["total_aggregations"]

            logger.info(f"✅ Agregación completada en {aggregation_time:.2f}s")
            return aggregated

        except Exception as e:
            logger.error(f"❌ Error en agregación: {e}")
            self.aggregation_stats["failed_aggregations"] += 1
            return None

    def _fedavg_aggregate(
        self,
        node_weights: Dict[str, Dict[str, torch.Tensor]],
        quality_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Federated Averaging optimizado para transformers.

        Args:
            node_weights: Pesos por nodo
            quality_weights: Pesos de calidad (opcional)

        Returns:
            Pesos promediados
        """
        # Usar pesos de calidad si están disponibles, sino pesos uniformes
        if quality_weights is None:
            node_weights_list = list(quality_weights.keys()) if quality_weights else list(node_weights.keys())
            quality_weights = {node_id: 1.0 / len(node_weights_list) for node_id in node_weights_list}
        else:
            # Normalizar pesos de calidad
            total_weight = sum(quality_weights.values())
            quality_weights = {node_id: weight / total_weight for node_id, weight in quality_weights.items()}

        # Obtener estructura de pesos (asumiendo que todos los nodos tienen la misma)
        first_node_weights = next(iter(node_weights.values()))
        aggregated_weights = {}

        # Agregar por cada parámetro del modelo
        for param_name in first_node_weights.keys():
            param_tensors = []

            for node_id, weights in node_weights.items():
                if param_name in weights:
                    weight = quality_weights.get(node_id, 1.0 / len(node_weights))
                    param_tensors.append(weights[param_name] * weight)
                else:
                    logger.warning(f"⚠️ Parámetro {param_name} faltante en nodo {node_id}")

            if param_tensors:
                # Promediar tensores
                aggregated_weights[param_name] = torch.stack(param_tensors).sum(dim=0)
            else:
                logger.error(f"❌ No se pudieron agregar parámetro: {param_name}")

        return aggregated_weights

    def _fednova_aggregate(
        self,
        node_weights: Dict[str, Dict[str, torch.Tensor]],
        quality_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, torch.Tensor]:
        """
        FedNova: Compensación de datos heterogéneos.

        Este método compensa la heterogeneidad de datos entre nodos,
        dando más peso a nodos con menos datos pero mejor rendimiento.
        """
        # Calcular tamaños efectivos de dataset por nodo
        # (En implementación real, esto vendría de las métricas del nodo)
        effective_sizes = {}
        for node_id in node_weights.keys():
            # Simulación: asumir tamaños basados en número de parámetros
            # En producción, usar datos reales del nodo
            effective_sizes[node_id] = 1000  # Placeholder

        # Calcular factores de normalización de FedNova
        total_effective_size = sum(effective_sizes.values())
        normalization_factors = {
            node_id: total_effective_size / (len(node_weights) * size)
            for node_id, size in effective_sizes.items()
        }

        # Aplicar normalización y agregar
        return self._fedavg_aggregate(node_weights, normalization_factors)

    def _scaffold_aggregate(
        self,
        node_weights: Dict[str, Dict[str, torch.Tensor]],
        quality_weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, torch.Tensor]:
        """
        SCAFFOLD: Corrección de varianza del cliente.

        Método avanzado que corrige la varianza introducida por
        diferentes distribuciones de datos en los nodos.
        """
        # SCAFFOLD requiere estado adicional (control variates)
        # Por simplicidad, usar FedAvg con corrección básica
        logger.warning("⚠️ SCAFFOLD no completamente implementado, usando FedAvg")
        return self._fedavg_aggregate(node_weights, quality_weights)

    def _validate_node_weights(self, node_weights: Dict[str, Dict[str, torch.Tensor]]) -> bool:
        """Validar que los pesos de los nodos sean consistentes."""
        if not node_weights:
            return False

        # Obtener estructura de referencia
        first_node_id = next(iter(node_weights.keys()))
        reference_structure = set(node_weights[first_node_id].keys())

        # Verificar que todos los nodos tengan la misma estructura
        for node_id, weights in node_weights.items():
            node_structure = set(weights.keys())
            if node_structure != reference_structure:
                logger.error(f"❌ Estructura de pesos inconsistente en nodo {node_id}")
                logger.error(f"   Referencia: {reference_structure}")
                logger.error(f"   Nodo: {node_structure}")
                return False

            # Verificar que los tensores tengan formas consistentes
            for param_name, tensor in weights.items():
                ref_tensor = node_weights[first_node_id][param_name]
                if tensor.shape != ref_tensor.shape:
                    logger.error(f"❌ Forma inconsistente en {param_name} para nodo {node_id}")
                    logger.error(f"   Referencia: {ref_tensor.shape}")
                    logger.error(f"   Nodo: {tensor.shape}")
                    return False

        return True

    def _validate_aggregated_weights(self, weights: Dict[str, torch.Tensor]) -> bool:
        """Validar que los pesos agregados sean válidos."""
        if not weights:
            return False

        # Verificar que todos los tensores existan y no sean NaN/inf
        for param_name, tensor in weights.items():
            if not isinstance(tensor, torch.Tensor):
                logger.error(f"❌ Parámetro {param_name} no es tensor")
                return False

            if torch.isnan(tensor).any() or torch.isinf(tensor).any():
                logger.error(f"❌ Parámetro {param_name} contiene NaN/inf")
                return False

            # Verificar rango razonable (evitar explosión de gradientes)
            if tensor.abs().max() > 1000:
                logger.warning(f"⚠️ Parámetro {param_name} tiene valores muy grandes")

        return True

    def aggregate_gradients(
        self,
        node_gradients: Dict[str, Dict[str, torch.Tensor]],
        aggregation_method: str = "fedavg"
    ) -> Optional[Dict[str, torch.Tensor]]:
        """
        Agregar gradientes en lugar de pesos (útil para algunos algoritmos).

        Args:
            node_gradients: Gradientes por nodo
            aggregation_method: Método de agregación

        Returns:
            Gradientes agregados
        """
        # Para gradientes, la agregación es similar pero con signo negativo
        # (ya que gradientes se restan en el update)
        return self.aggregate_weights(node_gradients, aggregation_method)

    def get_aggregation_quality_metrics(
        self,
        node_weights: Dict[str, Dict[str, torch.Tensor]],
        aggregated_weights: Dict[str, torch.Tensor]
    ) -> Dict[str, float]:
        """
        Calcular métricas de calidad de la agregación.

        Args:
            node_weights: Pesos originales por nodo
            aggregated_weights: Pesos agregados

        Returns:
            Diccionario con métricas de calidad
        """
        metrics = {}

        try:
            # Calcular varianza entre nodos
            param_variances = []
            for param_name in aggregated_weights.keys():
                node_values = []
                for node_weights_dict in node_weights.values():
                    if param_name in node_weights_dict:
                        node_values.append(node_weights_dict[param_name].flatten())

                if node_values:
                    # Calcular varianza de los valores del parámetro
                    stacked = torch.stack(node_values)
                    variance = torch.var(stacked, dim=0).mean().item()
                    param_variances.append(variance)

            if param_variances:
                metrics["avg_param_variance"] = np.mean(param_variances)
                metrics["max_param_variance"] = np.max(param_variances)

            # Calcular estabilidad (qué tanto cambian los pesos agregados)
            # Esto requeriría pesos anteriores para comparar

            metrics["num_nodes_aggregated"] = len(node_weights)
            metrics["aggregation_success"] = True

        except Exception as e:
            logger.error(f"Error calculando métricas de calidad: {e}")
            metrics["aggregation_success"] = False

        return metrics

    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del aggregator."""
        return {
            "total_aggregations": self.aggregation_stats["total_aggregations"],
            "total_nodes_processed": self.aggregation_stats["total_nodes_processed"],
            "avg_aggregation_time": self.aggregation_stats["avg_aggregation_time"],
            "failed_aggregations": self.aggregation_stats["failed_aggregations"],
            "success_rate": (
                self.aggregation_stats["total_aggregations"] /
                max(1, self.aggregation_stats["total_aggregations"] + self.aggregation_stats["failed_aggregations"])
            )
        }


# Funciones de conveniencia
def create_weighted_average(
    node_weights: List[Dict[str, torch.Tensor]],
    weights: Optional[List[float]] = None
) -> Dict[str, torch.Tensor]:
    """
    Función simple para promediar pesos con pesos opcionales.

    Args:
        node_weights: Lista de diccionarios de pesos
        weights: Pesos para cada conjunto de pesos (opcional)

    Returns:
        Pesos promediados
    """
    if not node_weights:
        return {}

    if weights is None:
        weights = [1.0 / len(node_weights)] * len(node_weights)

    # Normalizar pesos
    total_weight = sum(weights)
    weights = [w / total_weight for w in weights]

    # Obtener nombres de parámetros
    param_names = node_weights[0].keys()

    averaged_weights = {}
    for param_name in param_names:
        param_tensors = []
        for i, weights_dict in enumerate(node_weights):
            if param_name in weights_dict:
                param_tensors.append(weights_dict[param_name] * weights[i])

        if param_tensors:
            averaged_weights[param_name] = torch.stack(param_tensors).sum(dim=0)

    return averaged_weights