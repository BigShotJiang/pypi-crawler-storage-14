"""
Test configuration and fixtures for EmpoorioLM tests.
Provides realistic test data and fixtures to replace simple mocks.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock
from datetime import datetime, timedelta
import uuid

from ..service import EmpoorioLMService, EmpoorioLMServiceConfig
from ..inference_engine import InferenceEngineConfig
from ..model_manager import ModelManagerConfig
from ..version_controller import VersionControllerConfig
from ..performance_optimizer import PerformanceOptimizerConfig


@pytest.fixture
def realistic_service_config():
    """Create a realistic service configuration for testing."""
    return EmpoorioLMServiceConfig(
        service_name="test_empoorio_lm_service",
        enable_health_checks=True,
        enable_metrics=True,
        models_dir="./test_models",
        auto_initialize_base_model=False,
        default_model_version="v1.0.0-test",
        model_manager=ModelManagerConfig(
            max_memory_gb=4.0,
            max_models_in_memory=3,
            cache_ttl_seconds=600,
            prefer_gpu=False,
            enable_monitoring=True,
        ),
        inference_engine=InferenceEngineConfig(
            max_concurrent_requests=10,
            max_batch_size=4,
            request_timeout_seconds=60,
            enable_streaming=True,
            enable_dynamic_batching=True,
            max_workers=4,
            enable_gpu_optimization=False,
        ),
        version_controller=VersionControllerConfig(
            max_active_versions=5,
            enable_ab_testing=True,
            enable_canary_deployments=True,
            enable_performance_monitoring=True,
        ),
        performance_optimizer=PerformanceOptimizerConfig(
            enable_auto_scaling=True,
            enable_cache_optimization=True,
            metrics_collection_interval_seconds=30,
            optimization_check_interval_seconds=120,
        )
    )


@pytest.fixture
def realistic_generation_request():
    """Create a realistic text generation request."""
    return {
        "prompt": "Explain the concept of federated learning in simple terms.",
        "max_tokens": 150,
        "temperature": 0.7,
        "top_p": 0.9,
        "frequency_penalty": 0.0,
        "presence_penalty": 0.0,
        "model_version": "v1.0.0",
        "stream": False
    }


@pytest.fixture
def realistic_generation_response():
    """Create a realistic text generation response."""
    request_id = str(uuid.uuid4())
    return {
        "request_id": request_id,
        "generated_text": "Federated learning is a machine learning approach where multiple devices or servers collaboratively train a shared model without exchanging their raw data. Instead of sending data to a central server, each participant trains the model locally on their own data and only shares model updates (like gradients) with the central coordinator. This preserves privacy while still benefiting from collective intelligence.",
        "model_version": "v1.0.0-test",
        "tokens_generated": 87,
        "processing_time": 1.234,
        "metadata": {
            "input_tokens": 12,
            "finish_reason": "stop",
            "total_tokens": 99
        }
    }


@pytest.fixture
def realistic_batch_request():
    """Create a realistic batch generation request."""
    return {
        "requests": [
            {
                "prompt": "What is blockchain technology?",
                "max_tokens": 100,
                "temperature": 0.5
            },
            {
                "prompt": "Explain zero-knowledge proofs",
                "max_tokens": 120,
                "temperature": 0.6
            },
            {
                "prompt": "How does AI work?",
                "max_tokens": 80,
                "temperature": 0.8
            }
        ],
        "model_version": "v1.0.0",
        "priority": "normal"
    }


@pytest.fixture
def realistic_service_status():
    """Create a realistic service status response."""
    uptime = 3600.0 + (datetime.utcnow().timestamp() % 86400)  # 1 hour + some random time
    return {
        "service_name": "test_empoorio_lm_service",
        "is_initialized": True,
        "is_running": True,
        "uptime_seconds": uptime,
        "total_requests": 1247,
        "total_tokens_generated": 45632,
        "active_versions": {
            "total_active": 3,
            "default_version": "v1.0.0",
            "versions": ["v1.0.0", "v1.1.0-beta", "v0.9.0"]
        },
        "performance_metrics": {
            "status": "healthy",
            "avg_response_time": 1.2,
            "requests_per_second": 2.8,
            "error_rate": 0.02
        },
        "inference_stats": {
            "active_requests": 2,
            "queued_requests": 1,
            "completed_requests": 1245
        },
        "model_cache_stats": {
            "current_models_loaded": 2,
            "cache_hit_rate": 0.85,
            "memory_usage_gb": 2.3
        }
    }


@pytest.fixture
def realistic_health_check():
    """Create a realistic health check response."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "checks": {
            "service_initialized": {
                "status": "pass",
                "message": "Service is initialized and ready",
                "timestamp": datetime.utcnow().isoformat()
            },
            "service_running": {
                "status": "pass",
                "message": "Service is running and accepting requests",
                "timestamp": datetime.utcnow().isoformat()
            },
            "inference_engine": {
                "status": "pass",
                "message": "Inference Engine healthy - 2/2 workers active",
                "timestamp": datetime.utcnow().isoformat()
            },
            "model_manager": {
                "status": "pass",
                "message": "Model Manager healthy - 2 models loaded",
                "timestamp": datetime.utcnow().isoformat()
            },
            "version_controller": {
                "status": "pass",
                "message": "Version Controller healthy - 3 versions active",
                "timestamp": datetime.utcnow().isoformat()
            },
            "database_connection": {
                "status": "pass",
                "message": "Database connection healthy",
                "timestamp": datetime.utcnow().isoformat()
            }
        }
    }


@pytest.fixture
def realistic_performance_report():
    """Create a realistic performance report."""
    return {
        "current_metrics": {
            "cpu_usage": 67.5,
            "memory_usage": 3.2,
            "gpu_usage": 45.0,
            "disk_io": 120.5,
            "network_io": 89.3
        },
        "averages_last_10": {
            "response_time": 1.15,
            "requests_per_second": 3.2,
            "tokens_per_second": 245.8,
            "memory_usage": 3.1,
            "cpu_usage": 65.2
        },
        "averages_last_hour": {
            "response_time": 1.08,
            "requests_per_second": 2.9,
            "tokens_per_second": 238.4,
            "error_rate": 0.015
        },
        "peak_metrics": {
            "max_response_time": 5.2,
            "max_requests_per_second": 8.5,
            "max_memory_usage": 4.1
        }
    }


@pytest.fixture
def realistic_optimization_recommendations():
    """Create realistic optimization recommendations."""
    return [
        {
            "type": "cache_optimization",
            "priority": "medium",
            "description": "Cache hit rate could be improved by increasing max_models_in_memory",
            "current_value": "78%",
            "recommended_value": "85%",
            "recommended_action": "Increase max_models_in_memory from 3 to 4",
            "estimated_impact": "15% improvement in response time",
            "implementation_effort": "low"
        },
        {
            "type": "memory_optimization",
            "priority": "low",
            "description": "Memory usage is within acceptable limits",
            "current_value": "3.2GB",
            "recommended_value": "3.0GB",
            "recommended_action": "Enable memory defragmentation",
            "estimated_impact": "5% reduction in memory usage",
            "implementation_effort": "medium"
        },
        {
            "type": "concurrency_optimization",
            "priority": "high",
            "description": "Concurrent request handling could be improved",
            "current_value": "10 max concurrent",
            "recommended_value": "15 max concurrent",
            "recommended_action": "Increase max_concurrent_requests and max_workers",
            "estimated_impact": "25% improvement in throughput",
            "implementation_effort": "medium"
        }
    ]


@pytest.fixture
async def realistic_mock_service(realistic_service_config, realistic_generation_response,
                                realistic_service_status, realistic_health_check,
                                realistic_performance_report, realistic_optimization_recommendations):
    """Create a mock service with realistic responses."""
    service = Mock(spec=EmpoorioLMService)

    # Configure realistic responses
    service.generate_text = AsyncMock(return_value=realistic_generation_response)

    # Streaming generator with realistic chunks
    async def realistic_stream_generator():
        text = realistic_generation_response["generated_text"]
        words = text.split()
        for i, word in enumerate(words):
            chunk = word + " " if i < len(words) - 1 else word
            yield chunk
            await asyncio.sleep(0.02)  # Realistic streaming delay

    service.stream_generate_text = AsyncMock(return_value=realistic_stream_generator())
    service.generate_batch = AsyncMock(return_value=str(uuid.uuid4()))

    service.activate_model_version = AsyncMock(return_value=True)
    service.deactivate_model_version = AsyncMock(return_value=True)

    service.get_service_status = Mock(return_value=realistic_service_status)
    service.get_service_health = Mock(return_value=realistic_health_check)
    service.get_performance_report = Mock(return_value=realistic_performance_report)
    service.get_optimization_recommendations = Mock(return_value=realistic_optimization_recommendations)

    return service


@pytest.fixture
def realistic_user():
    """Create a realistic user for testing."""
    return {
        "id": 1,
        "username": "test_user",
        "email": "test@example.com",
        "role": "user",
        "permissions": ["read", "write"],
        "is_active": True,
        "created_at": datetime.utcnow() - timedelta(days=30),
        "last_login": datetime.utcnow() - timedelta(hours=2)
    }


@pytest.fixture
def realistic_model_versions():
    """Create realistic model version data."""
    base_time = datetime.utcnow() - timedelta(days=7)
    return [
        {
            "version_id": "empoorio_lm_v1.0.0_1234567890",
            "version_name": "v1.0.0",
            "created_at": base_time.isoformat(),
            "description": "Stable production version",
            "is_active": True,
            "is_default": True,
            "traffic_percentage": 0.8,
            "performance_metrics": {
                "accuracy": 0.92,
                "response_time": 1.1,
                "tokens_per_second": 250
            }
        },
        {
            "version_id": "empoorio_lm_v1.1.0-beta_1234567891",
            "version_name": "v1.1.0-beta",
            "created_at": (base_time + timedelta(days=3)).isoformat(),
            "description": "Beta version with improved performance",
            "is_active": True,
            "is_default": False,
            "traffic_percentage": 0.2,
            "performance_metrics": {
                "accuracy": 0.94,
                "response_time": 0.9,
                "tokens_per_second": 280
            }
        },
        {
            "version_id": "empoorio_lm_v0.9.0_1234567889",
            "version_name": "v0.9.0",
            "created_at": (base_time - timedelta(days=2)).isoformat(),
            "description": "Legacy version for compatibility",
            "is_active": False,
            "is_default": False,
            "traffic_percentage": 0.0,
            "performance_metrics": {
                "accuracy": 0.89,
                "response_time": 1.4,
                "tokens_per_second": 220
            }
        }
    ]
