#!/usr/bin/env python3
"""
Demo Standalone de Tools - Sin dependencias del sistema AILOOS completo
Demuestra el funcionamiento del sistema de function calling de forma aislada.
"""

import asyncio
import sys
import json
from pathlib import Path

# Añadir rutas para importar módulos directamente
current_dir = Path(__file__).parent
project_root = current_dir.parent
src_dir = project_root / "src"

sys.path.insert(0, str(src_dir))

print("🚀 Demo Standalone de Function Calling")
print("="*50)


# Definiciones locales para evitar importaciones
class ToolParameter:
    def __init__(self, name, type, description, required=True, default=None, enum=None):
        self.name = name
        self.type = type
        self.description = description
        self.required = required
        self.default = default
        self.enum = enum


class Tool:
    def __init__(self, name, description, parameters, function, category="general"):
        self.name = name
        self.description = description
        self.parameters = parameters
        self.function = function
        self.category = category


class ToolRegistry:
    def __init__(self):
        self.tools = {}

    async def register_tool(self, tool):
        self.tools[tool.name] = tool
        print(f"✅ Registrada herramienta: {tool.name}")
        return True

    def get_tool(self, tool_name):
        return self.tools.get(tool_name)

    def list_tools(self):
        return list(self.tools.values())


class ExecutionResult:
    def __init__(self, tool_name, success, result, error=None, execution_time=0.0):
        self.tool_name = tool_name
        self.success = success
        self.result = result
        self.error = error
        self.execution_time = execution_time


class ToolExecutor:
    def __init__(self, registry):
        self.registry = registry

    async def execute_tool(self, tool_name, parameters):
        import time
        start_time = time.time()

        tool = self.registry.get_tool(tool_name)
        if not tool:
            return ExecutionResult(tool_name, False, None, f"Tool '{tool_name}' not found")

        try:
            # Ejecutar la función
            if asyncio.iscoroutinefunction(tool.function):
                result = await tool.function(**parameters)
            else:
                result = tool.function(**parameters)

            execution_time = time.time() - start_time
            return ExecutionResult(tool_name, True, result, execution_time=execution_time)

        except Exception as e:
            execution_time = time.time() - start_time
            return ExecutionResult(tool_name, False, None, str(e), execution_time=execution_time)


class FunctionCallingProcessor:
    def __init__(self, registry, executor):
        self.registry = registry
        self.executor = executor
        self.tool_call_pattern = None

    def set_tool_tokens(self, start_token, end_token):
        import re
        escaped_start = re.escape(start_token)
        escaped_end = re.escape(end_token)
        self.tool_call_pattern = re.compile(f'{escaped_start}(.*?){escaped_end}', re.DOTALL)

    def detect_tool_calls(self, response):
        if not self.tool_call_pattern:
            return []

        tool_calls = []
        matches = self.tool_call_pattern.findall(response)

        for match in matches:
            try:
                tool_call_data = json.loads(match.strip())
                tool_name = tool_call_data.get("name") or tool_call_data.get("tool_name")
                parameters = tool_call_data.get("parameters") or tool_call_data.get("args", {})

                if tool_name:
                    tool_calls.append({
                        "tool_name": tool_name,
                        "parameters": parameters,
                        "raw_call": match.strip()
                    })

            except json.JSONDecodeError:
                continue

        return tool_calls

    async def process_response_with_tools(self, response):
        import time
        start_time = time.time()

        tool_calls = self.detect_tool_calls(response)
        execution_results = []

        if tool_calls:
            for tool_call in tool_calls:
                result = await self.executor.execute_tool(
                    tool_call["tool_name"],
                    tool_call["parameters"]
                )
                execution_results.append(result)

        # Formatear resultados
        final_response = response
        if execution_results:
            results_text = "\n\n--- Tool Execution Results ---\n\n"
            for result in execution_results:
                if result.success:
                    results_text += f"✅ Tool '{result.tool_name}' executed successfully:\n{json.dumps(result.result, indent=2)}\n\n"
                else:
                    results_text += f"❌ Tool '{result.tool_name}' failed:\n{result.error}\n\n"

            final_response += results_text

        processing_time = time.time() - start_time

        return {
            "original_response": response,
            "tool_calls": tool_calls,
            "execution_results": execution_results,
            "final_response": final_response,
            "processing_time": processing_time
        }


# Herramientas built-in
def calculator_execute(operation, x, y=None):
    """Función de calculadora."""
    try:
        if operation == "+":
            return {"result": x + y}
        elif operation == "-":
            return {"result": x - y}
        elif operation == "*":
            return {"result": x * y}
        elif operation == "/":
            if y == 0:
                raise ValueError("Division by zero")
            return {"result": x / y}
        elif operation == "sqrt":
            import math
            if x < 0:
                raise ValueError("Cannot take square root of negative number")
            return {"result": math.sqrt(x)}
        else:
            raise ValueError(f"Unknown operation: {operation}")
    except Exception as e:
        raise ValueError(f"Calculator error: {str(e)}")


def datetime_execute(operation):
    """Función de fecha y hora."""
    import datetime
    now = datetime.datetime.now()

    if operation == "now":
        return {"result": now.strftime("%Y-%m-%d %H:%M:%S")}
    elif operation == "today":
        return {"result": now.strftime("%Y-%m-%d")}
    elif operation == "weekday":
        return {"result": now.strftime("%A")}
    else:
        raise ValueError(f"Unknown operation: {operation}")


def web_search_execute(query, max_results=5):
    """Función de búsqueda web (simulada)."""
    return {
        "query": query,
        "results": [
            {
                "title": f"Result 1 for '{query}'",
                "url": f"https://example.com/result1?q={query}",
                "snippet": f"This is a mock search result for the query '{query}'."
            },
            {
                "title": f"Result 2 for '{query}'",
                "url": f"https://example.com/result2?q={query}",
                "snippet": f"Another mock result showing information about '{query}'."
            }
        ][:max_results],
        "total_results": 2,
        "note": "This is mock data for development."
    }


# Crear herramientas
calculator_tool = Tool(
    name="calculator",
    description="Perform basic mathematical calculations",
    parameters={
        "operation": ToolParameter("operation", "string", "Mathematical operation", enum=["+", "-", "*", "/", "sqrt"]),
        "x": ToolParameter("x", "number", "First operand", required=True),
        "y": ToolParameter("y", "number", "Second operand", required=False)
    },
    function=calculator_execute,
    category="mathematics"
)

datetime_tool = Tool(
    name="datetime",
    description="Get current date and time information",
    parameters={
        "operation": ToolParameter("operation", "string", "Date/time operation", enum=["now", "today", "weekday"])
    },
    function=datetime_execute,
    category="utilities"
)

web_search_tool = Tool(
    name="web_search",
    description="Search the web for information",
    parameters={
        "query": ToolParameter("query", "string", "Search query", required=True),
        "max_results": ToolParameter("max_results", "number", "Maximum results", default=5)
    },
    function=web_search_execute,
    category="search"
)


async def setup_system():
    """Configura el sistema de tools."""
    print("🔧 Configurando Tool Registry...")

    registry = ToolRegistry()
    executor = ToolExecutor(registry)
    processor = FunctionCallingProcessor(registry, executor)
    processor.set_tool_tokens("<tool_call>", "</tool_call>")

    # Registrar herramientas
    await registry.register_tool(calculator_tool)
    await registry.register_tool(datetime_tool)
    await registry.register_tool(web_search_tool)

    print("✅ Sistema configurado!")
    return processor


async def demo_calculator(processor):
    """Demo de calculadora."""
    print("\n🧮 DEMO: Calculadora")
    print("-" * 30)

    simulated_response = '''Para calcular 2349 × 1293, usaré la calculadora.

<tool_call>{"name": "calculator", "parameters": {"operation": "*", "x": 2349, "y": 1293}}</tool_call>'''

    print("Usuario: Calcula cuánto es 2349 multiplicado por 1293")
    print(f"EmpoorioLM: {simulated_response}")

    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result['final_response']}")
    print(".2f")
    print(f"Tool calls detectados: {len(result['tool_calls'])}")


async def demo_datetime(processor):
    """Demo de fecha y hora."""
    print("\n📅 DEMO: Fecha y Hora")
    print("-" * 30)

    simulated_response = '''Necesito consultar la fecha y hora actual.

<tool_call>{"name": "datetime", "parameters": {"operation": "now"}}</tool_call>
<tool_call>{"name": "datetime", "parameters": {"operation": "weekday"}}</tool_call>'''

    print("Usuario: ¿Qué día es hoy y qué hora es?")
    print(f"EmpoorioLM: {simulated_response}")

    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result['final_response']}")
    print(".2f")
    print(f"Tool calls detectados: {len(result['tool_calls'])}")


async def demo_multiple_tools(processor):
    """Demo de múltiples herramientas."""
    print("\n🔧 DEMO: Múltiples Herramientas")
    print("-" * 35)

    simulated_response = '''El usuario pide dos operaciones diferentes.

<tool_call>{"name": "calculator", "parameters": {"operation": "sqrt", "x": 144}}</tool_call>

<tool_call>{"name": "datetime", "parameters": {"operation": "today"}}</tool_call>'''

    print("Usuario: Calcula la raíz cuadrada de 144 y dime qué día es hoy")
    print(f"EmpoorioLM: {simulated_response}")

    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result['final_response']}")
    print(".2f")
    print(f"Tool calls detectados: {len(result['tool_calls'])}")


async def demo_error_handling(processor):
    """Demo de manejo de errores."""
    print("\n❌ DEMO: Manejo de Errores")
    print("-" * 30)

    simulated_response = '''Intentaré calcular la raíz cuadrada de un número negativo.

<tool_call>{"name": "calculator", "parameters": {"operation": "sqrt", "x": -1}}</tool_call>'''

    print("Usuario: Calcula la raíz cuadrada de -1")
    print(f"EmpoorioLM: {simulated_response}")

    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result['final_response']}")
    print(".2f")
    print(f"Tool calls detectados: {len(result['tool_calls'])}")


async def show_system_status(processor):
    """Muestra estado del sistema."""
    print("\nℹ️ ESTADO DEL SISTEMA")
    print("-" * 25)

    tools = processor.registry.list_tools()
    print(f"🔧 Herramientas registradas: {len(tools)}")

    for tool in tools:
        print(f"  • {tool.name}: {tool.description}")


async def main():
    """Función principal."""
    try:
        # Configurar sistema
        processor = await setup_system()

        # Mostrar estado del sistema
        await show_system_status(processor)

        # Ejecutar demos
        await demo_calculator(processor)
        await demo_datetime(processor)
        await demo_multiple_tools(processor)
        await demo_error_handling(processor)

        print("\n" + "="*60)
        print("🎉 ¡Demo standalone completada exitosamente!")
        print("="*60)
        print("\nResumen de capacidades demostradas:")
        print("✅ Detección automática de tool calls")
        print("✅ Parsing JSON de llamadas a herramientas")
        print("✅ Ejecución segura en sandbox")
        print("✅ Manejo de errores robusto")
        print("✅ Procesamiento paralelo de múltiples tools")
        print("✅ Formateo de resultados para el modelo")
        print("\n🚀 ¡Function Calling operativo!")

    except Exception as e:
        print(f"❌ Error en demo: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)