#!/usr/bin/env python3
"""
Benchmark script for API performance optimization with TOON/VSC serialization.
Compares performance of APIs with and without TOON/VSC optimization.
"""

import asyncio
import time
import json
import csv
import aiohttp
import statistics
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))


class APITestType(Enum):
    """Tipos de pruebas de API."""
    ANALYTICS_DASHBOARD = "analytics_dashboard"
    ANALYTICS_METRICS = "analytics_metrics"
    FEDERATED_NODE_METRICS = "federated_node_metrics"
    FEDERATED_STATS = "federated_stats"


@dataclass
class APIBenchmarkResult:
    """Resultado de un benchmark de API."""
    api_type: str
    endpoint: str
    serialization_type: str  # "json", "toon", "vsc"
    response_size_bytes: int
    response_time_ms: float
    compression_ratio: float
    timestamp: float = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class APIComparisonResult:
    """Resultado de comparación entre serializaciones."""
    api_type: str
    endpoint: str
    json_result: APIBenchmarkResult
    toon_result: Optional[APIBenchmarkResult] = None
    vsc_result: Optional[APIBenchmarkResult] = None
    summary: Dict[str, Any] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "api_type": self.api_type,
            "endpoint": self.endpoint,
            "json_result": self.json_result.to_dict() if self.json_result else None,
            "toon_result": self.toon_result.to_dict() if self.toon_result else None,
            "vsc_result": self.vsc_result.to_dict() if self.vsc_result else None,
            "summary": self.summary
        }


class APIOptimizationBenchmark:
    """Clase para ejecutar benchmarks de optimización de APIs."""

    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session: Optional[aiohttp.ClientSession] = None
        self.iterations = 5  # Iteraciones por prueba

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    async def run_full_api_benchmark(self) -> List[APIComparisonResult]:
        """Ejecutar benchmark completo de optimización de APIs."""
        results = []

        # Benchmark Analytics API
        print("Benchmarking Analytics API...")
        analytics_results = await self.benchmark_analytics_api()
        results.extend(analytics_results)

        # Benchmark Federated API
        print("Benchmarking Federated API...")
        federated_results = await self.benchmark_federated_api()
        results.extend(federated_results)

        return results

    async def benchmark_analytics_api(self) -> List[APIComparisonResult]:
        """Benchmark de Analytics API."""
        results = []

        # Dashboard endpoint
        dashboard_comparison = await self.compare_endpoint_optimizations(
            "analytics_dashboard",
            "/api/dashboard/analytics"
        )
        results.append(dashboard_comparison)

        # Metrics endpoint
        metrics_comparison = await self.compare_endpoint_optimizations(
            "analytics_metrics",
            "/api/performance/metrics"
        )
        results.append(metrics_comparison)

        return results

    async def benchmark_federated_api(self) -> List[APIComparisonResult]:
        """Benchmark de Federated API."""
        results = []

        # Node metrics endpoint
        node_metrics_comparison = await self.compare_endpoint_optimizations(
            "federated_node_metrics",
            "/api/federated/nodes/metrics"
        )
        results.append(node_metrics_comparison)

        # Stats endpoint
        stats_comparison = await self.compare_endpoint_optimizations(
            "federated_stats",
            "/api/federated/stats"
        )
        results.append(stats_comparison)

        return results

    async def compare_endpoint_optimizations(
        self,
        api_type: str,
        endpoint: str
    ) -> APIComparisonResult:
        """Comparar optimizaciones para un endpoint específico."""
        print(f"  Testing {api_type}: {endpoint}")

        # Test JSON (baseline)
        json_result = await self.benchmark_endpoint(endpoint, "application/json")

        # Test TOON
        toon_result = await self.benchmark_endpoint(endpoint, "application/toon")

        # Test VSC
        vsc_result = await self.benchmark_endpoint(endpoint, "application/vsc")

        # Calcular resumen
        summary = self.calculate_comparison_summary(json_result, toon_result, vsc_result)

        return APIComparisonResult(
            api_type=api_type,
            endpoint=endpoint,
            json_result=json_result,
            toon_result=toon_result,
            vsc_result=vsc_result,
            summary=summary
        )

    async def benchmark_endpoint(
        self,
        endpoint: str,
        accept_header: str
    ) -> APIBenchmarkResult:
        """Benchmark de un endpoint específico con un tipo de contenido."""
        if not self.session:
            raise RuntimeError("Session not initialized")

        url = f"{self.base_url}{endpoint}"
        response_times = []
        response_sizes = []

        for i in range(self.iterations):
            try:
                start_time = time.time()

                headers = {"Accept": accept_header}
                async with self.session.get(url, headers=headers) as response:
                    if response.status == 200:
                        content = await response.read()
                        end_time = time.time()

                        response_times.append((end_time - start_time) * 1000)
                        response_sizes.append(len(content))
                    else:
                        print(f"    Warning: {endpoint} returned status {response.status}")

            except Exception as e:
                print(f"    Error testing {endpoint}: {e}")
                continue

        if not response_times:
            # Return empty result if all requests failed
            return APIBenchmarkResult(
                api_type="",
                endpoint=endpoint,
                serialization_type=self.get_serialization_type(accept_header),
                response_size_bytes=0,
                response_time_ms=0.0,
                compression_ratio=1.0
            )

        avg_response_time = statistics.mean(response_times)
        avg_response_size = statistics.mean(response_sizes)

        return APIBenchmarkResult(
            api_type="",
            endpoint=endpoint,
            serialization_type=self.get_serialization_type(accept_header),
            response_size_bytes=int(avg_response_size),
            response_time_ms=avg_response_time,
            compression_ratio=1.0  # Will be calculated in comparison
        )

    def get_serialization_type(self, accept_header: str) -> str:
        """Obtener tipo de serialización desde header Accept."""
        if "toon" in accept_header:
            return "toon"
        elif "vsc" in accept_header:
            return "vsc"
        else:
            return "json"

    def calculate_comparison_summary(
        self,
        json_result: APIBenchmarkResult,
        toon_result: Optional[APIBenchmarkResult],
        vsc_result: Optional[APIBenchmarkResult]
    ) -> Dict[str, Any]:
        """Calcular resumen de comparación entre serializaciones."""
        summary = {
            "json_size_bytes": json_result.response_size_bytes,
            "json_time_ms": json_result.response_time_ms,
            "toon_improvement": {},
            "vsc_improvement": {}
        }

        if toon_result:
            toon_size_ratio = toon_result.response_size_bytes / json_result.response_size_bytes if json_result.response_size_bytes > 0 else 1.0
            toon_time_ratio = toon_result.response_time_ms / json_result.response_time_ms if json_result.response_time_ms > 0 else 1.0

            summary["toon_improvement"] = {
                "size_ratio": toon_size_ratio,
                "size_savings_percent": (1.0 - toon_size_ratio) * 100,
                "time_ratio": toon_time_ratio,
                "time_improvement_percent": (1.0 - toon_time_ratio) * 100,
                "size_bytes": toon_result.response_size_bytes,
                "time_ms": toon_result.response_time_ms
            }

        if vsc_result:
            vsc_size_ratio = vsc_result.response_size_bytes / json_result.response_size_bytes if json_result.response_size_bytes > 0 else 1.0
            vsc_time_ratio = vsc_result.response_time_ms / json_result.response_time_ms if json_result.response_time_ms > 0 else 1.0

            summary["vsc_improvement"] = {
                "size_ratio": vsc_size_ratio,
                "size_savings_percent": (1.0 - vsc_size_ratio) * 100,
                "time_ratio": vsc_time_ratio,
                "time_improvement_percent": (1.0 - vsc_time_ratio) * 100,
                "size_bytes": vsc_result.response_size_bytes,
                "time_ms": vsc_result.response_time_ms
            }

        return summary

    def save_results_json(self, results: List[APIComparisonResult], filename: str):
        """Guardar resultados en JSON."""
        data = {
            "benchmark_run": {
                "timestamp": time.time(),
                "base_url": self.base_url,
                "iterations_per_test": self.iterations,
                "total_comparisons": len(results)
            },
            "results": [r.to_dict() for r in results]
        }

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        print(f"Results saved to {filename}")

    def save_results_csv(self, results: List[APIComparisonResult], filename: str):
        """Guardar resultados en CSV."""
        rows = []

        for comparison in results:
            base_row = {
                "api_type": comparison.api_type,
                "endpoint": comparison.endpoint,
                "timestamp": time.time()
            }

            # JSON result
            if comparison.json_result:
                json_row = base_row.copy()
                json_row.update({
                    "serialization": "json",
                    "response_size_bytes": comparison.json_result.response_size_bytes,
                    "response_time_ms": comparison.json_result.response_time_ms,
                    "compression_ratio": comparison.json_result.compression_ratio
                })
                rows.append(json_row)

            # TOON result
            if comparison.toon_result:
                toon_row = base_row.copy()
                toon_row.update({
                    "serialization": "toon",
                    "response_size_bytes": comparison.toon_result.response_size_bytes,
                    "response_time_ms": comparison.toon_result.response_time_ms,
                    "compression_ratio": comparison.toon_result.compression_ratio
                })
                rows.append(toon_row)

            # VSC result
            if comparison.vsc_result:
                vsc_row = base_row.copy()
                vsc_row.update({
                    "serialization": "vsc",
                    "response_size_bytes": comparison.vsc_result.response_size_bytes,
                    "response_time_ms": comparison.vsc_result.response_time_ms,
                    "compression_ratio": comparison.vsc_result.compression_ratio
                })
                rows.append(vsc_row)

        if not rows:
            print("No results to save")
            return

        fieldnames = list(rows[0].keys())

        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        print(f"Results saved to {filename}")

    def print_summary_report(self, results: List[APIComparisonResult]):
        """Imprimir reporte resumen."""
        print("\n" + "="*80)
        print("API OPTIMIZATION BENCHMARK SUMMARY REPORT")
        print("="*80)

        for comparison in results:
            print(f"\n📊 {comparison.api_type.upper()}: {comparison.endpoint}")
            print("-" * 50)

            if comparison.json_result:
                print(".1f"
                      ".2f")

            if comparison.toon_result and comparison.summary:
                toon = comparison.summary["toon_improvement"]
                print(".1f"
                      ".1f"
                      ".2f")

            if comparison.vsc_result and comparison.summary:
                vsc = comparison.summary["vsc_improvement"]
                print(".1f"
                      ".1f"
                      ".2f")

        print("\n" + "="*80)


async def main():
    """Función principal."""
    print("🚀 API Optimization Benchmark with TOON/VSC")
    print("Comparing JSON vs TOON vs VSC serialization performance")
    print()

    # Configurar URL base (ajustar según sea necesario)
    base_url = "http://localhost:8000"  # Analytics API
    # base_url = "http://localhost:8001"  # Federated API

    async with APIOptimizationBenchmark(base_url) as benchmark:
        try:
            # Ejecutar benchmarks
            results = await benchmark.run_full_api_benchmark()

            # Guardar resultados
            timestamp = int(time.time())
            json_file = f"api_optimization_results_{timestamp}.json"
            csv_file = f"api_optimization_results_{timestamp}.csv"

            benchmark.save_results_json(results, json_file)
            benchmark.save_results_csv(results, csv_file)

            # Imprimir reporte resumen
            benchmark.print_summary_report(results)

        except Exception as e:
            print(f"❌ Error running API benchmarks: {e}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())