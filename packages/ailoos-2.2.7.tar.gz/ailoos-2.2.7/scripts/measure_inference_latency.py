#!/usr/bin/env python3
"""
Script para medir latencia de inferencia en RAG + CAG con EmpoorioLM.

Este script compara el rendimiento de inferencia con cache habilitado vs deshabilitado,
midiendo:
- Latencia promedio de respuesta
- Throughput (consultas por segundo)
- Latencia P50, P95, P99
- Impacto del cache en diferentes escenarios

Uso:
    python scripts/measure_inference_latency.py --num_queries 100 --warmup_queries 10
"""

import argparse
import asyncio
import json
import logging
import statistics
import time
from pathlib import Path
from typing import Dict, List, Any, Tuple
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.rag.cache_augmented.cache_augmented_rag import CacheAugmentedRAG
from ailoos.rag.techniques.naive_rag import NaiveRAG
from ailoos.rag.core.generators import EmpoorioLMGenerator
from ailoos.rag.core.retrievers import VectorRetriever
from ailoos.rag.core.evaluators import BasicRAGEvaluator

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class InferenceLatencyMeasurer:
    """Medidor de latencia de inferencia para RAG con/sin cache."""

    def __init__(self, config: Dict[str, Any]):
        """
        Inicializar el medidor.

        Args:
            config: Configuración del experimento
        """
        self.config = config
        self.results = {
            'experiment_config': config,
            'with_cache': {},
            'without_cache': {},
            'comparison': {},
            'timestamp': time.time()
        }

    def setup_rag_system(self, cache_enabled: bool = True) -> CacheAugmentedRAG:
        """Configurar el sistema RAG con o sin cache."""
        cache_status = "con" if cache_enabled else "sin"
        logger.info(f"Configurando sistema RAG {cache_status} cache...")

        # Configuración común
        retriever_config = {
            'embedding_model': 'sentence-transformers/all-MiniLM-L6-v2',
            'vector_store': {
                'type': 'chroma',
                'collection_name': f'test_latency_{cache_status}_cache',
                'persist_directory': f'./data/latency_test_{cache_status}_cache'
            }
        }

        generator_config = {
            'empoorio_api_config': {
                'model_path': self.config.get('model_path', './models/empoorio_lm/v1.0.0'),
                'device': 'cpu',
                'max_tokens': 512,
                'temperature': 0.7
            },
            'generation_config': {
                'max_new_tokens': 256,
                'temperature': 0.7,
                'do_sample': True
            },
            'caching': {
                'max_size': 100,
                'ttl_seconds': 3600
            }
        }

        evaluator_config = {}

        base_rag_config = {
            'retriever_class': VectorRetriever,
            'retriever_config': retriever_config,
            'generator_class': EmpoorioLMGenerator,
            'generator_config': generator_config,
            'evaluator_class': BasicRAGEvaluator,
            'evaluator_config': evaluator_config
        }

        if cache_enabled:
            # Configuración del cache aumentado
            cache_config = {
                'model_name': 'all-MiniLM-L6-v2',
                'similarity_threshold': self.config.get('similarity_threshold', 0.8),
                'max_size': self.config.get('cache_max_size', 1000),
                'eviction_policy': self.config.get('eviction_policy', 'LRU'),
                'cache_file': f'./cache/latency_test_with_cache_{int(time.time())}.pkl'
            }

            cag_config = {
                'base_rag_class': NaiveRAG,
                'base_rag_config': base_rag_config,
                'cache_config': cache_config,
                'cache_enabled': True,
                'quality_config': {}
            }

            rag_system = CacheAugmentedRAG(cag_config)
        else:
            # Sistema sin cache - usar NaiveRAG directamente
            rag_system = NaiveRAG(base_rag_config)

        logger.info(f"Sistema RAG {cache_status} cache configurado exitosamente")
        return rag_system

    def generate_test_queries(self) -> List[str]:
        """Generar consultas de prueba diversas."""
        queries = [
            "¿Qué es la inteligencia artificial y cómo funciona?",
            "¿Cuáles son las principales aplicaciones de la IA en medicina?",
            "¿Cómo se entrena un modelo de aprendizaje automático?",
            "¿Qué diferencia hay entre aprendizaje supervisado y no supervisado?",
            "¿Cómo funciona el procesamiento de lenguaje natural?",
            "¿Qué es el aprendizaje profundo y cuáles son sus ventajas?",
            "¿Cuáles son los desafíos éticos en el desarrollo de IA?",
            "¿Cómo se implementa la visión por computadora en aplicaciones reales?",
            "¿Qué técnicas existen para el reconocimiento de voz?",
            "¿Cómo funciona el aprendizaje por refuerzo en juegos?",
            "¿Qué es la computación cuántica y su relación con la IA?",
            "¿Cómo se mide la calidad de un modelo de IA?",
            "¿Qué son las redes neuronales convolucionales?",
            "¿Cómo se aplica la IA en el análisis de datos financieros?",
            "¿Qué es el procesamiento de imágenes médicas con IA?",
            "¿Cómo funciona la traducción automática neuronal?",
            "¿Qué técnicas existen para la detección de anomalías con IA?",
            "¿Cómo se implementa la IA en sistemas de recomendación?",
            "¿Qué es el aprendizaje federado y sus beneficios?",
            "¿Cómo se evalúa el sesgo en modelos de IA?"
        ]

        # Repetir queries para simular carga realista
        num_repetitions = max(1, self.config.get('num_queries', 50) // len(queries))
        repeated_queries = queries * num_repetitions

        # Tomar solo las queries necesarias
        final_queries = repeated_queries[:self.config.get('num_queries', 50)]

        logger.info(f"Generadas {len(final_queries)} consultas de prueba")
        return final_queries

    async def warmup_system(self, rag_system: Any, warmup_queries: List[str]):
        """Realizar warmup del sistema."""
        logger.info(f"Realizando warmup con {len(warmup_queries)} consultas...")

        for i, query in enumerate(warmup_queries):
            try:
                logger.debug(f"Warmup {i+1}/{len(warmup_queries)}: {query[:30]}...")
                if hasattr(rag_system, 'run'):
                    await asyncio.sleep(0.1)  # Simular procesamiento
                    result = rag_system.run(query)
                else:
                    await asyncio.sleep(0.1)
            except Exception as e:
                logger.warning(f"Error en warmup query {i}: {e}")

        logger.info("Warmup completado")

    async def measure_latency(self, rag_system: Any, queries: List[str],
                            cache_enabled: bool) -> Dict[str, Any]:
        """Medir latencia de inferencia."""
        cache_status = "con" if cache_enabled else "sin"
        logger.info(f"Midiendo latencia {cache_status} cache...")

        latencies = []
        errors = 0
        start_time = time.time()

        for i, query in enumerate(queries):
            try:
                query_start = time.time()

                if hasattr(rag_system, 'run'):
                    result = rag_system.run(query)
                else:
                    # Fallback para sistemas sin run method
                    await asyncio.sleep(0.01)

                query_end = time.time()
                latency = query_end - query_start
                latencies.append(latency)

                if (i + 1) % 10 == 0:
                    logger.info(f"  Progreso {cache_status} cache: {i+1}/{len(queries)} consultas")

            except Exception as e:
                errors += 1
                logger.warning(f"Error en consulta {i}: {e}")
                latencies.append(0.0)  # Placeholder

        total_time = time.time() - start_time

        # Calcular estadísticas
        if latencies:
            valid_latencies = [l for l in latencies if l > 0]
            stats = {
                'total_queries': len(queries),
                'successful_queries': len(valid_latencies),
                'errors': errors,
                'total_time': total_time,
                'throughput_qps': len(valid_latencies) / total_time if total_time > 0 else 0,
                'avg_latency': statistics.mean(valid_latencies) if valid_latencies else 0,
                'median_latency': statistics.median(valid_latencies) if valid_latencies else 0,
                'min_latency': min(valid_latencies) if valid_latencies else 0,
                'max_latency': max(valid_latencies) if valid_latencies else 0,
                'p95_latency': self.calculate_percentile(valid_latencies, 95) if valid_latencies else 0,
                'p99_latency': self.calculate_percentile(valid_latencies, 99) if valid_latencies else 0,
                'std_dev_latency': statistics.stdev(valid_latencies) if len(valid_latencies) > 1 else 0
            }
        else:
            stats = {
                'total_queries': len(queries),
                'successful_queries': 0,
                'errors': errors,
                'total_time': total_time,
                'throughput_qps': 0,
                'avg_latency': 0,
                'median_latency': 0,
                'min_latency': 0,
                'max_latency': 0,
                'p95_latency': 0,
                'p99_latency': 0,
                'std_dev_latency': 0
            }

        logger.info(f"Medición {cache_status} cache completada:")
        logger.info(f"  Throughput: {stats['throughput_qps']:.2f} QPS")
        logger.info(f"  Latencia promedio: {stats['avg_latency']:.3f}s")
        logger.info(f"  Latencia P95: {stats['p95_latency']:.3f}s")

        return stats

    def calculate_percentile(self, data: List[float], percentile: float) -> float:
        """Calcular percentil de una lista de datos."""
        if not data:
            return 0.0
        data_sorted = sorted(data)
        index = int(len(data_sorted) * percentile / 100)
        return data_sorted[min(index, len(data_sorted) - 1)]

    async def run_experiment(self) -> Dict[str, Any]:
        """Ejecutar experimento completo de medición de latencia."""
        logger.info("Iniciando experimento de medición de latencia de inferencia...")

        # Generar consultas de prueba
        all_queries = self.generate_test_queries()
        warmup_queries = all_queries[:self.config.get('warmup_queries', 5)]
        test_queries = all_queries[self.config.get('warmup_queries', 5):]

        # Experimento 1: Con cache
        logger.info("=== EXPERIMENTO 1: CON CACHE ===")
        rag_with_cache = self.setup_rag_system(cache_enabled=True)
        await self.warmup_system(rag_with_cache, warmup_queries)
        results_with_cache = await self.measure_latency(rag_with_cache, test_queries, cache_enabled=True)
        self.results['with_cache'] = results_with_cache

        # Limpiar cache entre experimentos
        await asyncio.sleep(1)

        # Experimento 2: Sin cache
        logger.info("=== EXPERIMENTO 2: SIN CACHE ===")
        rag_without_cache = self.setup_rag_system(cache_enabled=False)
        await self.warmup_system(rag_without_cache, warmup_queries)
        results_without_cache = await self.measure_latency(rag_without_cache, test_queries, cache_enabled=False)
        self.results['without_cache'] = results_without_cache

        # Calcular comparación
        self.calculate_comparison()

        logger.info("Experimento completado")
        return self.results

    def calculate_comparison(self):
        """Calcular métricas de comparación entre con/sin cache."""
        with_cache = self.results['with_cache']
        without_cache = self.results['without_cache']

        comparison = {
            'latency_improvement_percent': self.calculate_improvement(
                without_cache.get('avg_latency', 0),
                with_cache.get('avg_latency', 0)
            ),
            'throughput_improvement_percent': self.calculate_improvement(
                without_cache.get('throughput_qps', 0),
                with_cache.get('throughput_qps', 0)
            ),
            'p95_improvement_percent': self.calculate_improvement(
                without_cache.get('p95_latency', 0),
                with_cache.get('p95_latency', 0)
            ),
            'cache_benefit_score': self.calculate_cache_benefit_score()
        }

        self.results['comparison'] = comparison

        logger.info("Comparación calculada:")
        logger.info(f"  Mejora de latencia: {comparison['latency_improvement_percent']:.1f}%")
        logger.info(f"  Mejora de throughput: {comparison['throughput_improvement_percent']:.1f}%")

    def calculate_improvement(self, baseline: float, improved: float) -> float:
        """Calcular porcentaje de mejora."""
        if baseline == 0:
            return 0.0
        return ((baseline - improved) / baseline) * 100

    def calculate_cache_benefit_score(self) -> float:
        """Calcular puntuación de beneficio del cache (0-100)."""
        with_cache = self.results['with_cache']
        without_cache = self.results['without_cache']

        # Factores que contribuyen al beneficio del cache
        latency_weight = 0.4
        throughput_weight = 0.4
        consistency_weight = 0.2

        latency_score = min(100, self.calculate_improvement(
            without_cache.get('avg_latency', 0),
            with_cache.get('avg_latency', 0)
        ) * 2)  # Multiplicar por 2 para escalar

        throughput_score = min(100, self.calculate_improvement(
            without_cache.get('throughput_qps', 0),
            with_cache.get('throughput_qps', 0)
        ) * 2)

        # Consistencia: reducción en desviación estándar
        without_std = without_cache.get('std_dev_latency', 0)
        with_std = with_cache.get('std_dev_latency', 0)
        consistency_score = self.calculate_improvement(without_std, with_std) if without_std > 0 else 0
        consistency_score = min(100, consistency_score)

        total_score = (
            latency_score * latency_weight +
            throughput_score * throughput_weight +
            consistency_score * consistency_weight
        )

        return total_score

    def save_results(self, output_file: str):
        """Guardar resultados en archivo JSON."""
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)

        logger.info(f"Resultados guardados en {output_path}")

    def print_summary(self):
        """Imprimir resumen de resultados."""
        with_cache = self.results['with_cache']
        without_cache = self.results['without_cache']
        comparison = self.results['comparison']

        print("\n" + "="*80)
        print("RESUMEN DEL EXPERIMENTO - LATENCIA DE INFERENCIA")
        print("="*80)

        print("\nCON CACHE:")
        print(f"  Throughput: {with_cache.get('throughput_qps', 0):.2f} QPS")
        print(f"  Latencia promedio: {with_cache.get('avg_latency', 0):.3f}s")
        print(f"  Latencia P95: {with_cache.get('p95_latency', 0):.3f}s")
        print(f"  Latencia P99: {with_cache.get('p99_latency', 0):.3f}s")

        print("\nSIN CACHE:")
        print(f"  Throughput: {without_cache.get('throughput_qps', 0):.2f} QPS")
        print(f"  Latencia promedio: {without_cache.get('avg_latency', 0):.3f}s")
        print(f"  Latencia P95: {without_cache.get('p95_latency', 0):.3f}s")
        print(f"  Latencia P99: {without_cache.get('p99_latency', 0):.3f}s")

        print("\nCOMPARACIÓN:")
        print(f"  Mejora de latencia: {comparison.get('latency_improvement_percent', 0):.1f}%")
        print(f"  Mejora de throughput: {comparison.get('throughput_improvement_percent', 0):.1f}%")
        print(f"  Mejora P95 latencia: {comparison.get('p95_improvement_percent', 0):.1f}%")
        print(f"  Puntuación beneficio cache: {comparison.get('cache_benefit_score', 0):.1f}/100")

        print("="*80)


async def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Medir latencia de inferencia en RAG + CAG')
    parser.add_argument('--num_queries', type=int, default=50,
                       help='Número de consultas a ejecutar por experimento')
    parser.add_argument('--warmup_queries', type=int, default=5,
                       help='Número de consultas de warmup')
    parser.add_argument('--similarity_threshold', type=float, default=0.8,
                       help='Umbral de similitud para cache hits')
    parser.add_argument('--cache_max_size', type=int, default=1000,
                       help='Tamaño máximo del cache')
    parser.add_argument('--model_path', type=str, default='./models/empoorio_lm/v1.0.0',
                       help='Ruta al modelo EmpoorioLM')
    parser.add_argument('--output_file', type=str, default='benchmark_results/inference_latency_results.json',
                       help='Archivo de salida para resultados')
    parser.add_argument('--eviction_policy', type=str, default='LRU', choices=['LRU', 'LFU'],
                       help='Política de eviction del cache')

    args = parser.parse_args()

    # Configuración del experimento
    config = {
        'num_queries': args.num_queries,
        'warmup_queries': args.warmup_queries,
        'similarity_threshold': args.similarity_threshold,
        'cache_max_size': args.cache_max_size,
        'model_path': args.model_path,
        'eviction_policy': args.eviction_policy
    }

    # Crear medidor
    measurer = InferenceLatencyMeasurer(config)

    try:
        # Ejecutar experimento
        results = await measurer.run_experiment()

        # Guardar resultados
        measurer.save_results(args.output_file)

        # Imprimir resumen
        measurer.print_summary()

        logger.info(f"Experimento completado. Resultados guardados en {args.output_file}")

    except Exception as e:
        logger.error(f"Error en el experimento: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())