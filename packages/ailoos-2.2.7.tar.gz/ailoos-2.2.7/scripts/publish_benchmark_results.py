#!/usr/bin/env python3
"""
Script para publicar resultados de benchmarks en CI/CD.
Maneja publicación a GitHub Pages, releases, y notificaciones.
"""

import os
import sys
import json
import shutil
import argparse
from pathlib import Path
from typing import Dict, Any, Optional
import subprocess
import tempfile

class BenchmarkResultsPublisher:
    """Publicador de resultados de benchmarks para CI/CD."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.results_dir = Path(config.get('results_dir', '/app/benchmark_results'))
        self.reports_dir = Path(config.get('reports_dir', '/app/performance_reports'))
        self.charts_dir = Path(config.get('charts_dir', '/app/marketing_charts'))
        self.publish_dir = Path(config.get('publish_dir', '/tmp/benchmark_publish'))

        # Configuración de GitHub
        self.github_repo = os.environ.get('GITHUB_REPOSITORY', '')
        self.github_sha = os.environ.get('GITHUB_SHA', '')
        self.github_ref = os.environ.get('GITHUB_REF', '')
        self.github_run_id = os.environ.get('GITHUB_RUN_ID', '')

        self.publish_dir.mkdir(exist_ok=True)

    def collect_results(self) -> Dict[str, Any]:
        """Recopilar todos los resultados de benchmarks."""
        results = {
            'metadata': {
                'repo': self.github_repo,
                'sha': self.github_sha,
                'ref': self.github_ref,
                'run_id': self.github_run_id,
                'timestamp': self.config.get('timestamp', ''),
                'config': self.config
            },
            'benchmarks': {}
        }

        # Buscar archivos JSON de resultados
        result_files = []
        for directory in [self.results_dir, self.reports_dir]:
            if directory.exists():
                result_files.extend(directory.glob('**/*.json'))

        for file_path in result_files:
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)

                # Determinar tipo de benchmark basado en el nombre del archivo
                filename = file_path.name.lower()
                if 'accuracy' in filename:
                    benchmark_type = 'accuracy'
                elif 'latency' in filename:
                    benchmark_type = 'latency'
                elif 'energy' in filename:
                    benchmark_type = 'energy'
                elif 'mobile' in filename or 'edge' in filename:
                    benchmark_type = 'mobile_edge'
                elif 'rag' in filename:
                    benchmark_type = 'rag'
                elif 'comprehensive' in filename or 'summary' in filename:
                    benchmark_type = 'summary'
                else:
                    benchmark_type = 'other'

                if benchmark_type not in results['benchmarks']:
                    results['benchmarks'][benchmark_type] = []

                results['benchmarks'][benchmark_type].append({
                    'file': str(file_path.relative_to(self.results_dir.parent)),
                    'data': data
                })

            except Exception as e:
                print(f"Error loading {file_path}: {e}")
                continue

        return results

    def generate_html_report(self, results: Dict[str, Any]) -> str:
        """Generar reporte HTML para publicación."""
        html = f"""
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AILOOS Benchmark Results - {self.github_sha[:8]}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }}
        .benchmark-card {{
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .metric {{
            display: inline-block;
            background: #f0f0f0;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            font-family: monospace;
        }}
        .metric.success {{ background: #d4edda; color: #155724; }}
        .metric.warning {{ background: #fff3cd; color: #856404; }}
        .metric.error {{ background: #f8d7da; color: #721c24; }}
        .chart-container {{
            text-align: center;
            margin: 20px 0;
        }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}
        .summary-item {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .status {{
            padding: 5px 10px;
            border-radius: 15px;
            font-weight: bold;
        }}
        .status.success {{ background: #d4edda; color: #155724; }}
        .status.failure {{ background: #f8d7da; color: #721c24; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🚀 AILOOS Benchmark Results</h1>
        <p>Commit: <code>{self.github_sha[:8]}</code> | Run: #{self.github_run_id}</p>
        <p>Generated: {results['metadata']['timestamp']}</p>
    </div>

    <div class="summary">
"""

        # Resumen general
        total_benchmarks = sum(len(benchmarks) for benchmarks in results['benchmarks'].values())
        successful_benchmarks = sum(
            1 for benchmark_list in results['benchmarks'].values()
            for benchmark in benchmark_list
            if 'error' not in benchmark['data']
        )

        html += f"""
        <div class="summary-item">
            <h3>Total Benchmarks</h3>
            <div class="status success">{total_benchmarks}</div>
        </div>
        <div class="summary-item">
            <h3>Successful</h3>
            <div class="status success">{successful_benchmarks}</div>
        </div>
        <div class="summary-item">
            <h3>Failed</h3>
            <div class="status {'error' if total_benchmarks - successful_benchmarks > 0 else 'success'}">{total_benchmarks - successful_benchmarks}</div>
        </div>
        """

        html += """
    </div>
"""

        # Detalles por tipo de benchmark
        for benchmark_type, benchmarks in results['benchmarks'].items():
            html += f"""
    <div class="benchmark-card">
        <h2>{benchmark_type.upper()} Benchmarks</h2>
"""

            for benchmark in benchmarks:
                data = benchmark['data']

                if 'error' in data:
                    html += f"""
        <div class="metric error">
            ❌ Error: {data['error']}
        </div>
"""
                else:
                    # Métricas específicas por tipo
                    if benchmark_type == 'accuracy':
                        if 'overall_accuracy' in data:
                            html += f"""
        <div class="metric success">
            Overall Accuracy: {data['overall_accuracy']:.3f}
        </div>
"""
                    elif benchmark_type == 'latency':
                        if 'avg_latency_ms' in data:
                            html += f"""
        <div class="metric success">
            Avg Latency: {data['avg_latency_ms']:.2f}ms
        </div>
"""
                        if 'p95_latency_ms' in data:
                            html += f"""
        <div class="metric success">
            P95 Latency: {data['p95_latency_ms']:.2f}ms
        </div>
"""
                    elif benchmark_type == 'energy':
                        if 'total_energy_joules' in data:
                            html += f"""
        <div class="metric success">
            Energy: {data['total_energy_joules']:.2f}J
        </div>
"""
                        if 'joules_per_token' in data:
                            html += f"""
        <div class="metric success">
            J/Token: {data['joules_per_token']:.4f}
        </div>
"""

            html += """
    </div>
"""

        # Incluir gráficos si existen
        if self.charts_dir.exists():
            chart_files = list(self.charts_dir.glob('*.png'))
            if chart_files:
                html += """
    <div class="benchmark-card">
        <h2>📊 Benchmark Charts</h2>
        <div class="chart-container">
"""
                for chart_file in chart_files[:6]:  # Limitar a 6 gráficos
                    chart_name = chart_file.name
                    html += f"""
            <img src="charts/{chart_name}" alt="{chart_name}" style="max-width: 100%; height: auto; margin: 10px;">
"""
                html += """
        </div>
    </div>
"""

        html += """
    <div class="benchmark-card">
        <h3>📋 Raw Results</h3>
        <pre>""" + json.dumps(results, indent=2) + """</pre>
    </div>
</body>
</html>
"""

        return html

    def publish_to_github_pages(self, html_content: str, results: Dict[str, Any]):
        """Publicar resultados a GitHub Pages."""
        try:
            # Crear estructura de directorio
            index_path = self.publish_dir / 'index.html'
            with open(index_path, 'w') as f:
                f.write(html_content)

            # Copiar gráficos
            if self.charts_dir.exists():
                charts_dest = self.publish_dir / 'charts'
                charts_dest.mkdir(exist_ok=True)
                for chart_file in self.charts_dir.glob('*.png'):
                    shutil.copy2(chart_file, charts_dest / chart_file.name)

            # Copiar reportes JSON
            json_dest = self.publish_dir / 'data'
            json_dest.mkdir(exist_ok=True)
            for directory in [self.results_dir, self.reports_dir]:
                if directory.exists():
                    for json_file in directory.glob('**/*.json'):
                        shutil.copy2(json_file, json_dest / json_file.name)

            print(f"✅ Results prepared for GitHub Pages in {self.publish_dir}")

        except Exception as e:
            print(f"❌ Error preparing GitHub Pages content: {e}")
            raise

    def create_release(self, results: Dict[str, Any]):
        """Crear un release de GitHub con los resultados."""
        try:
            # Crear archivo ZIP con resultados
            zip_name = f"benchmark-results-{self.github_sha[:8]}.zip"
            zip_path = self.publish_dir / zip_name

            shutil.make_archive(
                str(zip_path.with_suffix('')),
                'zip',
                str(self.publish_dir)
            )

            print(f"✅ Release archive created: {zip_path}")

            # Aquí se podría integrar con GitHub CLI para crear el release
            # gh release create ...

        except Exception as e:
            print(f"❌ Error creating release: {e}")
            raise

    def send_notifications(self, results: Dict[str, Any]):
        """Enviar notificaciones (Slack, Discord, etc.)."""
        # Implementar notificaciones según sea necesario
        print("📢 Notifications would be sent here")

    def publish(self):
        """Método principal para publicar resultados."""
        print("🚀 Starting benchmark results publication...")

        # Recopilar resultados
        results = self.collect_results()
        print(f"📊 Collected results from {len(results['benchmarks'])} benchmark types")

        # Generar reporte HTML
        html_content = self.generate_html_report(results)
        print("📄 Generated HTML report")

        # Publicar según configuración
        if self.config.get('publish_to_github_pages', True):
            self.publish_to_github_pages(html_content, results)

        if self.config.get('create_release', False):
            self.create_release(results)

        if self.config.get('send_notifications', False):
            self.send_notifications(results)

        print("✅ Benchmark results publication completed")


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Publish AILOOS Benchmark Results')
    parser.add_argument('--results-dir', type=str, default='/app/benchmark_results',
                       help='Directory containing benchmark results')
    parser.add_argument('--reports-dir', type=str, default='/app/performance_reports',
                       help='Directory containing benchmark reports')
    parser.add_argument('--charts-dir', type=str, default='/app/marketing_charts',
                       help='Directory containing benchmark charts')
    parser.add_argument('--publish-dir', type=str, default='/tmp/benchmark_publish',
                       help='Directory for publishing content')
    parser.add_argument('--publish-to-pages', action='store_true', default=True,
                       help='Publish to GitHub Pages')
    parser.add_argument('--create-release', action='store_true', default=False,
                       help='Create GitHub release')
    parser.add_argument('--send-notifications', action='store_true', default=False,
                       help='Send notifications')

    args = parser.parse_args()

    config = {
        'results_dir': args.results_dir,
        'reports_dir': args.reports_dir,
        'charts_dir': args.charts_dir,
        'publish_dir': args.publish_dir,
        'publish_to_github_pages': args.publish_to_pages,
        'create_release': args.create_release,
        'send_notifications': args.send_notifications,
        'timestamp': subprocess.run(['date', '+%Y-%m-%d %H:%M:%S UTC'],
                                   capture_output=True, text=True).stdout.strip()
    }

    publisher = BenchmarkResultsPublisher(config)

    try:
        publisher.publish()
        return 0
    except Exception as e:
        print(f"❌ Publication failed: {e}")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)