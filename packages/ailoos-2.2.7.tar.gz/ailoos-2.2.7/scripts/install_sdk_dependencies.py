#!/usr/bin/env python3
"""
AILOOS SDK Dependencies Installer
Instala todas las dependencias necesarias para el funcionamiento completo del SDK.
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(cmd, description):
    """Ejecuta un comando y maneja errores."""
    print(f"📦 {description}...")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completado")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error en {description}: {e}")
        print(f"STDOUT: {e.stdout}")
        print(f"STDERR: {e.stderr}")
        return False

def check_python_version():
    """Verifica la versión de Python."""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"❌ Python {version.major}.{version.minor} no es compatible. Se requiere Python 3.8+")
        return False
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} detectado")
    return True

def install_core_dependencies():
    """Instala dependencias core del SDK."""
    dependencies = [
        "cryptography>=3.4.0",  # Para criptografía blockchain
        "aiohttp>=3.8.0",      # Para HTTP async
        "websockets>=10.0",    # Para WebSocket connections
        "pydantic>=1.8.0",     # Para validación de datos
        "python-dotenv>=0.19.0", # Para configuración
    ]

    cmd = f"{sys.executable} -m pip install {' '.join(dependencies)}"
    return run_command(cmd, "Instalando dependencias core")

def install_blockchain_dependencies():
    """Instala dependencias para blockchain y tokens."""
    dependencies = [
        "web3>=6.0.0",         # Para Ethereum/Web3
        "eth-account>=0.8.0",  # Para cuentas Ethereum
    ]

    # Intentar instalar web3 - puede fallar en algunos sistemas
    cmd = f"{sys.executable} -m pip install {' '.join(dependencies)}"
    success = run_command(cmd, "Instalando dependencias blockchain")

    if not success:
        print("⚠️  Web3 no se pudo instalar. El modo real blockchain no estará disponible.")
        print("   Se usará el modo simulado por defecto.")

    return True  # No fallar si web3 no se instala

def install_ipfs_dependencies():
    """Instala dependencias para IPFS."""
    dependencies = [
        "ipfshttpclient>=0.8.0", # Para IPFS
        "requests>=2.25.0",     # Para HTTP requests
    ]

    cmd = f"{sys.executable} -m pip install {' '.join(dependencies)}"
    success = run_command(cmd, "Instalando dependencias IPFS")

    if not success:
        print("⚠️  IPFS client no se pudo instalar. Solo modo gateway estará disponible.")

    return True  # No fallar si IPFS no se instala

def install_ui_dependencies():
    """Instala dependencias para la interfaz de usuario."""
    dependencies = [
        "rich>=12.0.0",        # Para terminal rica
        "questionary>=1.10.0", # Para prompts interactivos
        "click>=8.0.0",        # Para CLI
    ]

    cmd = f"{sys.executable} -m pip install {' '.join(dependencies)}"
    return run_command(cmd, "Instalando dependencias UI")

def install_ml_dependencies():
    """Instala dependencias para machine learning."""
    dependencies = [
        "torch>=1.9.0",        # PyTorch
        "transformers>=4.15.0", # Transformers
        "datasets>=2.0.0",     # Datasets de HuggingFace
        "accelerate>=0.10.0",  # Para GPU acceleration
    ]

    cmd = f"{sys.executable} -m pip install {' '.join(dependencies)}"
    success = run_command(cmd, "Instalando dependencias ML")

    if not success:
        print("⚠️  Dependencias ML no se pudieron instalar.")
        print("   El entrenamiento federado tendrá funcionalidad limitada.")

    return True

def install_monitoring_dependencies():
    """Instala dependencias para monitoreo del sistema."""
    dependencies = [
        "psutil>=5.8.0",       # Para monitoreo del sistema
        "GPUtil>=1.4.0",       # Para GPUs
    ]

    cmd = f"{sys.executable} -m pip install {' '.join(dependencies)}"
    success = run_command(cmd, "Instalando dependencias de monitoreo")

    if not success:
        print("⚠️  Dependencias de monitoreo no disponibles.")
        print("   Algunas métricas del sistema no estarán disponibles.")

    return True

def install_database_dependencies():
    """Instala dependencias para bases de datos."""
    # SQLite viene con Python, pero podemos necesitar otros
    dependencies = []

    if dependencies:
        cmd = f"{sys.executable} -m pip install {' '.join(dependencies)}"
        return run_command(cmd, "Instalando dependencias de base de datos")

    return True

def create_directories():
    """Crea directorios necesarios."""
    directories = [
        "data_cache",
        "data_cache/datasets",
        "data_cache/shards",
        "data_cache/registry",
        "wallets",
        "models",
        "logs"
    ]

    for dir_path in directories:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
        print(f"📁 Directorio creado: {dir_path}")

    return True

def create_config_files():
    """Crea archivos de configuración por defecto."""
    # Archivo .env por defecto
    env_content = """# AILOOS Configuration
# Copy this file to .env and modify as needed

# Node Configuration
NODE_ID=default_node
COORDINATOR_URL=http://localhost:8000

# Blockchain Configuration
DRACMA_PRIVATE_KEY=
BLOCKCHAIN_NETWORK=local
RPC_URL=http://localhost:8545

# IPFS Configuration
IPFS_HOST=/ip4/127.0.0.1/tcp/5001/http
IPFS_GATEWAY=https://ipfs.io/ipfs/

# Security
ENCRYPTION_KEY=
JWT_SECRET=your_jwt_secret_here

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/ailoos.log

# Performance
MAX_WORKERS=4
BATCH_SIZE=32
"""

    env_path = Path(".env.example")
    if not env_path.exists():
        with open(env_path, 'w') as f:
            f.write(env_content)
        print("📄 Archivo de configuración creado: .env.example")

    return True

def run_post_install_checks():
    """Ejecuta verificaciones post-instalación."""
    print("\n🔍 Ejecutando verificaciones post-instalación...")

    checks = []

    # Verificar imports críticos
    try:
        import aiohttp
        checks.append(("✅ aiohttp", True))
    except ImportError:
        checks.append(("❌ aiohttp", False))

    try:
        import cryptography
        checks.append(("✅ cryptography", True))
    except ImportError:
        checks.append(("❌ cryptography", False))

    try:
        import rich
        checks.append(("✅ rich", True))
    except ImportError:
        checks.append(("❌ rich", False))

    try:
        import torch
        checks.append(("✅ torch", True))
    except ImportError:
        checks.append(("❌ torch", False))

    try:
        import ipfshttpclient
        checks.append(("✅ ipfshttpclient", True))
    except ImportError:
        checks.append(("❌ ipfshttpclient", False))

    try:
        import psutil
        checks.append(("✅ psutil", True))
    except ImportError:
        checks.append(("❌ psutil", False))

    # Mostrar resultados
    print("\n📋 Estado de dependencias:")
    for check, status in checks:
        print(f"   {check}")

    # Resumen
    successful = sum(1 for _, status in checks if status)
    total = len(checks)

    print(f"\n📊 Resumen: {successful}/{total} dependencias instaladas correctamente")

    if successful == total:
        print("🎉 ¡Todas las dependencias están instaladas!")
        return True
    elif successful >= total * 0.7:  # Al menos 70%
        print("⚠️  La mayoría de dependencias están instaladas. Algunas funcionalidades pueden estar limitadas.")
        return True
    else:
        print("❌ Muchas dependencias faltan. El SDK puede no funcionar correctamente.")
        return False

def main():
    """Función principal de instalación."""
    print("🚀 AILOOS SDK Dependencies Installer")
    print("=" * 50)

    # Verificar Python
    if not check_python_version():
        sys.exit(1)

    # Instalar dependencias por categorías
    steps = [
        ("Core dependencies", install_core_dependencies),
        ("Blockchain dependencies", install_blockchain_dependencies),
        ("IPFS dependencies", install_ipfs_dependencies),
        ("UI dependencies", install_ui_dependencies),
        ("ML dependencies", install_ml_dependencies),
        ("Monitoring dependencies", install_monitoring_dependencies),
        ("Database dependencies", install_database_dependencies),
    ]

    success_count = 0
    for name, installer in steps:
        if installer():
            success_count += 1
        print()

    # Crear estructura de directorios
    if create_directories():
        success_count += 1

    # Crear archivos de configuración
    if create_config_files():
        success_count += 1

    # Verificaciones finales
    if run_post_install_checks():
        success_count += 1

    # Resumen final
    print("\n" + "=" * 50)
    if success_count >= len(steps) + 2:  # +2 por directorios y config
        print("🎉 ¡Instalación completada exitosamente!")
        print("\n📚 Próximos pasos:")
        print("   1. Copia .env.example a .env y configura tus claves")
        print("   2. Ejecuta: python scripts/ailoos_terminal.py")
        print("   3. ¡Disfruta de AILOOS!")
    else:
        print(f"⚠️  Instalación completada con {success_count} pasos exitosos.")
        print("   Revisa los errores arriba y ejecuta el instalador nuevamente si es necesario.")

    return success_count >= len(steps) + 2

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n❌ Instalación cancelada por el usuario")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error fatal durante instalación: {e}")
        sys.exit(1)