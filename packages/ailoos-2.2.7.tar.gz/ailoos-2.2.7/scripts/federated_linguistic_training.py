#!/usr/bin/env python3
"""
FASE REAL-7: ENTRENAMIENTO FEDERADO LINGÜÍSTICO
Conecta el aprendizaje lingüístico validado con el sistema federado P2P.
Muestra cómo múltiples nodos colaboran para reducir la Loss lingüística.
"""

import asyncio
import logging
import torch
import torch.nn as nn
from typing import Dict, List, Any, Optional
from pathlib import Path
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Importar componentes federados
from ailoos.federated.real_federated_training_loop import (
    RealFederatedTrainingLoop,
    FederatedTrainingConfig,
    create_real_federated_training_loop
)

# Importar componentes lingüísticos
from ailoos.models.empoorio_lm_real import EmpoorioLM, EmpoorioLMConfig, EmpoorioLMTokenizer

logger = logging.getLogger(__name__)


class LinguisticFederatedNode:
    """
    Nodo federado especializado en aprendizaje lingüístico.
    Ejecuta el aprendizaje lingüístico local validado en FASE REAL-6.
    """

    def __init__(self, node_id: str, model_config: EmpoorioLMConfig):
        self.node_id = node_id
        self.model_config = model_config

        # Modelo y tokenizer
        self.model = EmpoorioLM(model_config)
        self.tokenizer = EmpoorioLMTokenizer(vocab_size=model_config.vocab_size)

        # Optimizador
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=0.001)

        # Datos locales (simulados - en producción vendrían de datasets reales)
        self.local_texts = self._generate_local_texts()
        self.local_data = self._prepare_training_data()

        # Estado del entrenamiento local
        self.local_loss_history = []
        self.local_accuracy_history = []

        logger.info(f"🎯 LinguisticFederatedNode {node_id} initialized with {len(self.local_texts)} texts")

    def _generate_local_texts(self) -> List[str]:
        """Genera textos locales para simular datos distribuidos."""
        # Cada nodo tiene textos ligeramente diferentes para simular distribución real
        base_texts = [
            "hello world machine learning",
            "artificial intelligence neural networks",
            "deep learning transformers attention",
            "natural language processing nlp",
            "computer vision image recognition",
            "reinforcement learning agents",
            "federated learning privacy preserving",
            "blockchain decentralized systems",
            "quantum computing algorithms",
            "autonomous driving vehicles"
        ]

        # Personalizar por nodo (simular distribución de datos)
        node_specific_texts = []
        for i, text in enumerate(base_texts):
            # Añadir variaciones basadas en node_id
            variation = hash(self.node_id + str(i)) % 3
            if variation == 0:
                node_specific_texts.append(f"advanced {text}")
            elif variation == 1:
                node_specific_texts.append(f"modern {text}")
            else:
                node_specific_texts.append(f"future {text}")

        return base_texts + node_specific_texts

    def _prepare_training_data(self) -> List[Dict[str, torch.Tensor]]:
        """Prepara datos de entrenamiento desde textos locales."""
        training_data = []

        for text in self.local_texts:
            tokens = self.tokenizer.encode(text)
            if len(tokens) > 1:
                # Language modeling: predecir siguiente token
                inputs = torch.tensor(tokens[:-1], dtype=torch.long)
                targets = torch.tensor(tokens[1:], dtype=torch.long)
                training_data.append({
                    'input_ids': inputs,
                    'labels': targets
                })

        logger.info(f"📚 Prepared {len(training_data)} training samples for {self.node_id}")
        return training_data

    async def train_local_round(self, global_weights: Dict[str, torch.Tensor],
                              num_epochs: int = 5) -> Dict[str, Any]:
        """
        Entrena localmente usando el aprendizaje lingüístico validado.
        Similar al script linguistic_fire_standalone.py pero con pesos globales.
        """
        # Cargar pesos globales
        self.model.load_state_dict(global_weights)

        # Configurar modo entrenamiento
        self.model.train()
        criterion = nn.CrossEntropyLoss(ignore_index=-100)

        total_loss = 0.0
        total_correct = 0
        total_samples = 0

        logger.info(f"🚀 {self.node_id} starting local linguistic training...")

        # Entrenamiento local (similar a FASE REAL-6)
        for epoch in range(num_epochs):
            epoch_loss = 0.0
            epoch_correct = 0
            epoch_samples = 0

            for batch in self.local_data:
                input_ids = batch['input_ids'].unsqueeze(0)  # Añadir dimensión batch
                labels = batch['labels'].unsqueeze(0)

                self.optimizer.zero_grad()

                # Forward pass (igual que en linguistic_fire_standalone.py)
                outputs = self.model(input_ids, labels=labels)
                loss = outputs["loss"]

                # Backward pass
                loss.backward()
                self.optimizer.step()

                # Estadísticas
                epoch_loss += loss.item()

                # Calcular accuracy (predicción de siguiente token)
                with torch.no_grad():
                    logits = outputs["logits"]
                    predictions = logits.argmax(dim=-1)
                    correct = (predictions == labels).sum().item()
                    epoch_correct += correct
                    epoch_samples += labels.numel()

            # Promedios de la época
            avg_epoch_loss = epoch_loss / len(self.local_data)
            epoch_accuracy = epoch_correct / epoch_samples if epoch_samples > 0 else 0

            logger.info(f"   {self.node_id} Epoch {epoch+1}/{num_epochs}: Loss={avg_epoch_loss:.4f}, Acc={epoch_accuracy:.4f}")

            # Acumuladores globales
            total_loss += avg_epoch_loss
            total_correct += epoch_correct
            total_samples += epoch_samples

        # Resultados finales del entrenamiento local
        avg_loss = total_loss / num_epochs
        final_accuracy = total_correct / total_samples if total_samples > 0 else 0

        # Guardar en historial
        self.local_loss_history.append(avg_loss)
        self.local_accuracy_history.append(final_accuracy)

        # Preparar actualización para el coordinador
        local_update = {
            "node_id": self.node_id,
            "weights": self.model.state_dict(),
            "samples_processed": len(self.local_data),
            "accuracy": final_accuracy,
            "loss": avg_loss,
            "training_time": num_epochs * 0.1,  # Simulado
            "gradient_norm": 1.0,  # Simulado
            "public_key": f"public_key_{self.node_id}"
        }

        logger.info(f"✅ {self.node_id} local training completed: Loss={avg_loss:.4f}, Acc={final_accuracy:.4f}")

        return local_update


class FederatedLinguisticTrainingDemo:
    """
    Demo que muestra cómo múltiples nodos colaboran en aprendizaje lingüístico.
    Integra el aprendizaje validado en FASE REAL-6 con el sistema federado.
    """

    def __init__(self, num_nodes: int = 3, rounds: int = 5):
        self.num_nodes = num_nodes
        self.rounds = rounds

        # Configuración del modelo lingüístico
        self.model_config = EmpoorioLMConfig(
            vocab_size=1000,
            hidden_size=128,
            num_layers=2,
            num_heads=4,
            max_position_embeddings=32
        )

        # Nodos federados
        self.nodes = []
        self.node_ids = [f"linguistic_node_{i+1}" for i in range(num_nodes)]

        # Coordinador federado
        self.training_loop = None

        # Historial de progreso
        self.global_loss_history = []
        self.global_accuracy_history = []

    async def initialize_demo(self):
        """Inicializa la demo federada lingüística."""
        print("🔥 FASE REAL-7: ENTRENAMIENTO FEDERADO LINGÜÍSTICO")
        print("=" * 60)
        print("Conectando aprendizaje lingüístico validado con sistema P2P")
        print("Múltiples nodos colaborando para reducir Loss lingüística")
        print()

        # Crear nodos
        print(f"🎯 Creando {self.num_nodes} nodos lingüísticos...")
        for node_id in self.node_ids:
            node = LinguisticFederatedNode(node_id, self.model_config)
            self.nodes.append(node)
            print(f"   ✅ {node_id}: {len(node.local_texts)} textos locales")

        # Configurar coordinador federado
        config = FederatedTrainingConfig(
            num_rounds=self.rounds,
            min_participants_per_round=self.num_nodes,
            use_tenseal=False,  # Deshabilitar para demo
            enable_blockchain_rewards=True,
            datasets=["linguistic_demo"]
        )

        self.training_loop = create_real_federated_training_loop("federated_linguistic_demo", config)

        # Inicializar entrenamiento
        print("\n🔧 Inicializando coordinador federado...")
        if not await self.training_loop.initialize_training():
            raise RuntimeError("Error inicializando coordinador")

        # Registrar nodos
        print(f"📝 Registrando {len(self.nodes)} nodos...")
        for node in self.nodes:
            wallet = await self.training_loop.register_participant(
                node.node_id,
                {"hardware": "cpu", "data_type": "text", "samples": len(node.local_texts)}
            )
            print(f"   ✅ {node.node_id} -> wallet: {wallet[:20]}...")

        print("\n🚀 ¡Demo federada lingüística lista!")
        print("Cada nodo entrenará localmente con aprendizaje lingüístico,")
        print("luego compartirán conocimiento para mejorar globalmente.")
        print()

    async def run_federated_linguistic_training(self):
        """Ejecuta el entrenamiento federado lingüístico."""
        print("🎯 INICIANDO ENTRENAMIENTO FEDERADO LINGÜÍSTICO")
        print("=" * 60)

        # Estado inicial
        initial_global_weights = self.training_loop.model.state_dict()

        for round_num in range(1, self.rounds + 1):
            print(f"\n🎯 RONDA {round_num}/{self.rounds}: APRENDIZAJE LINGÜÍSTICO COLABORATIVO")
            print("-" * 60)

            # Iniciar ronda
            round_config = await self.training_loop.start_round(round_num, self.node_ids)
            print(f"✅ Ronda {round_num} iniciada con {len(self.node_ids)} nodos lingüísticos")

            # Cada nodo entrena localmente con aprendizaje lingüístico
            print("\n🔄 Entrenamiento local en cada nodo:")
            node_updates = {}

            for node in self.nodes:
                print(f"   🚀 Entrenando {node.node_id}...")
                local_update = await node.train_local_round(initial_global_weights, num_epochs=3)
                node_updates[node.node_id] = local_update

                print(f"      📊 Loss local: {local_update['loss']:.4f}, Accuracy: {local_update['accuracy']:.4f}")

            # Recopilar actualizaciones en el coordinador
            print("\n📦 Recopilando actualizaciones lingüísticas...")
            if await self.training_loop.collect_node_updates(node_updates):
                print("✅ Actualizaciones recopiladas - agregando conocimiento...")

                # Agregar y actualizar modelo global
                round_result = await self.training_loop.aggregate_and_update_global_model()

                # Registrar progreso
                self.global_loss_history.append(round_result.global_loss)
                self.global_accuracy_history.append(round_result.global_accuracy)

                print("\n🎉 RESULTADO DE RONDA:")
                print(f"   Loss global: {round_result.global_loss:.4f}")
                print(f"   Accuracy global: {round_result.global_accuracy:.2f}")
                print(f"   Convergencia: {round_result.convergence_score:.4f}")
                print(f"   Progreso: {round_result.learning_progress:.4f}")
                print(f"💰 Recompensas distribuidas: {sum(round_result.rewards_distributed.values()):.2f} DRACMA")

                # Actualizar pesos globales para siguiente ronda
                initial_global_weights = self.training_loop.model.state_dict()

                # Verificar si continuar
                should_continue, reason = self.training_loop.should_continue_training()
                if not should_continue:
                    print(f"\n🛑 Entrenamiento detenido: {reason}")
                    break
            else:
                print("❌ Error recopilando actualizaciones")
                break

        # Resultados finales
        await self._show_final_results()

    async def _show_final_results(self):
        """Muestra resultados finales del entrenamiento federado lingüístico."""
        print("\n" + "=" * 60)
        print("🎊 RESULTADOS FINALES - APRENDIZAJE FEDERADO LINGÜÍSTICO")
        print("=" * 60)

        if self.global_loss_history:
            initial_loss = self.global_loss_history[0]
            final_loss = self.global_loss_history[-1]
            improvement = (initial_loss - final_loss) / initial_loss * 100

            print("📊 MÉTRICAS GLOBALES:")
            print(".4f"            print(".4f"            print(".1f"
            # Mostrar progreso por ronda
            print("
📈 PROGRESO POR RONDA:"            for i, (loss, acc) in enumerate(zip(self.global_loss_history, self.global_accuracy_history)):
                print("4d"
            # Estadísticas de nodos
            print("
🎯 CONTRIBUCIÓN DE NODOS:"            total_rewards = 0
            for node in self.nodes:
                if node.local_loss_history:
                    initial_local = node.local_loss_history[0]
                    final_local = node.local_loss_history[-1]
                    local_improvement = (initial_local - final_local) / initial_local * 100
                    print(".4f"                    print(".4f"                    print(".1f"
            # Estadísticas del sistema
            stats = self.training_loop.get_training_stats()
            print("
🏆 ESTADÍSTICAS DEL SISTEMA FEDERADO:"            print(f"✅ Rondas completadas: {len(self.global_loss_history)}")
            print(f"💰 Total DRACMA distribuido: {stats['rewards_stats']['total_distributed']:.2f}")
            print(f"🔗 Transacciones blockchain: {sum(len(r.blockchain_transactions) for r in self.training_loop.round_results)}")
            print(f"📂 Checkpoints guardados: {stats['sync_stats']['checkpoints_available']}")

            # Verificación de aprendizaje lingüístico federado
            linguistic_learning_achieved = final_loss < 2.0 and improvement > 50

            if linguistic_learning_achieved:
                print("
🎉 ¡APRENDIZAJE FEDERADO LINGÜÍSTICO CONFIRMADO!"                print("✅ Múltiples nodos colaboraron exitosamente")
                print("✅ Loss lingüística reducida significativamente")
                print("✅ Conocimiento distribuido fusionado correctamente")
                print("✅ Recompensas tokenizadas por contribución real")
                print("\n🏆 FASE REAL-7: ÉXITO TOTAL")
                print("💡 El sistema federado APRENDE LENGUAJE COLECTIVAMENTE")
                print("🚀 LISTO PARA ESCALADO GLOBAL CON EMPOORIOLM")
            else:
                print("\n⚠️ Aprendizaje federado limitado")
        else:
            print("❌ No se completaron rondas de entrenamiento")


async def main():
    """Función principal - Demo de entrenamiento federado lingüístico."""
    # Configurar logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

    # Crear demo
    demo = FederatedLinguisticTrainingDemo(num_nodes=3, rounds=4)

    try:
        # Inicializar
        await demo.initialize_demo()

        # Ejecutar entrenamiento federado lingüístico
        await demo.run_federated_linguistic_training()

    except Exception as e:
        logger.error(f"❌ Error en demo federada lingüística: {e}")
        return 1

    return 0


if __name__ == "__main__":
    exit(asyncio.run(main()))