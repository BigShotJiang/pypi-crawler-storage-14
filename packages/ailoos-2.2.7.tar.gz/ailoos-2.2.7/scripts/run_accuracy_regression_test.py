#!/usr/bin/env python3
"""
Script para ejecutar pruebas de regression testing de precisión contra catastrophic forgetting.
Se ejecuta automáticamente después de updates federados.
"""

import asyncio
import argparse
import logging
import sys
import os
from pathlib import Path

# Añadir el directorio src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from tests.test_accuracy_regression_suite import (
    AccuracyRegressionSuite,
    RegressionTestConfig,
    run_post_federated_update_evaluation
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def parse_arguments():
    """Parsea argumentos de línea de comandos."""
    parser = argparse.ArgumentParser(
        description="Ejecuta pruebas de regression testing de precisión para EmpoorioLM"
    )

    parser.add_argument(
        "--model-version",
        required=True,
        help="Versión del modelo siendo evaluada"
    )

    parser.add_argument(
        "--api-url",
        default="http://localhost:8000/inference",
        help="URL de la API de inferencia de EmpoorioLM"
    )

    parser.add_argument(
        "--gold-dataset",
        default="tests/gold_standard_dataset.json",
        help="Path al dataset de oro"
    )

    parser.add_argument(
        "--reports-dir",
        default="reports/accuracy_regression",
        help="Directorio para guardar reportes"
    )

    parser.add_argument(
        "--trigger",
        choices=["federated_update", "manual", "scheduled", "deployment"],
        default="manual",
        help="Qué disparó la evaluación"
    )

    parser.add_argument(
        "--blocking",
        action="store_true",
        help="Si está habilitado, bloquea deployment en caso de forgetting crítico"
    )

    parser.add_argument(
        "--baseline-path",
        help="Path específico a reporte baseline para comparación"
    )

    parser.add_argument(
        "--output-format",
        choices=["json", "text", "both"],
        default="both",
        help="Formato de salida del reporte"
    )

    return parser.parse_args()


async def run_evaluation(args):
    """Ejecuta la evaluación de regression testing."""
    logger.info(f"🚀 Iniciando regression testing para {args.model_version}")

    # Configurar suite
    config = RegressionTestConfig(
        api_url=args.api_url,
        gold_dataset_path=args.gold_dataset,
        reports_dir=args.reports_dir
    )

    suite = AccuracyRegressionSuite(config)

    try:
        # Ejecutar evaluación
        if args.trigger == "federated_update" and args.blocking:
            # Usar función de integración con federated learning
            report = await run_post_federated_update_evaluation(
                args.model_version,
                api_url=args.api_url
            )
        else:
            # Evaluación estándar
            report = await suite.run_regression_test(args.model_version, args.trigger)

        # Generar salida
        await generate_output(report, args)

        # Verificar condiciones de bloqueo
        if args.blocking and should_block_deployment(report):
            logger.error("🚫 DEPLOYMENT BLOQUEADO debido a forgetting crítico")
            return 1  # Código de error

        logger.info("✅ Regression testing completado exitosamente")
        return 0

    except Exception as e:
        logger.error(f"❌ Error durante regression testing: {e}")
        return 1


async def generate_output(report, args):
    """Genera salida del reporte en los formatos solicitados."""
    if args.output_format in ["json", "both"]:
        # El reporte JSON ya se guardó automáticamente por la suite
        logger.info(f"📄 Reporte JSON guardado en {args.reports_dir}")

    if args.output_format in ["text", "both"]:
        # Generar reporte de texto legible
        text_report = generate_text_report(report)
        text_path = Path(args.reports_dir) / f"regression_report_{args.model_version}_text.txt"

        with open(text_path, 'w', encoding='utf-8') as f:
            f.write(text_report)

        logger.info(f"📄 Reporte de texto guardado en {text_path}")

        # Imprimir resumen en consola
        print("\n" + "="*80)
        print("RESUMEN DE REGRESSION TESTING")
        print("="*80)
        print(text_report)


def generate_text_report(report):
    """Genera reporte en formato de texto legible."""
    lines = []

    lines.append(f"Modelo Evaluado: {report.model_version}")
    lines.append(f"Timestamp: {report.evaluation_timestamp}")
    lines.append(f"Total de Tareas: {report.total_tasks}")
    lines.append(".3f")
    lines.append(".2f")
    lines.append("")

    if report.forgetting_detected:
        lines.append("🚨 FORGETTING DETECTADO")
        lines.append(f"Categorías Afectadas: {', '.join(report.forgetting_categories)}")
        lines.append("")

    lines.append("PRECISIÓN POR CATEGORÍA:")
    lines.append("-" * 60)

    for cat, metrics in report.categories.items():
        status = "✅" if metrics.avg_score >= 0.8 else "⚠️" if metrics.avg_score >= 0.6 else "❌"
        lines.append("30")

    lines.append("")
    lines.append("COMPARACIÓN CON BASELINE:")
    lines.append("-" * 40)

    if report.baseline_comparison:
        comp = report.baseline_comparison
        lines.append(".3f")
        lines.append(f"Tareas Mejoradas: {comp.get('tasks_improved', 0)}")
        lines.append(f"Tareas Declinadas: {comp.get('tasks_declined', 0)}")
        lines.append(f"Tareas Sin Cambio: {comp.get('tasks_unchanged', 0)}")

        if comp.get('category_changes'):
            lines.append("")
            lines.append("Cambios por Categoría:")
            for cat, changes in comp['category_changes'].items():
                change = changes.get('change', 0)
                lines.append("15")
    else:
        lines.append("No hay baseline para comparación")

    return "\n".join(lines)


def should_block_deployment(report):
    """Determina si el deployment debe ser bloqueado."""
    # Bloquear si hay forgetting crítico en categorías críticas
    critical_categories = ["architecture", "security", "machine_learning"]

    if report.forgetting_detected:
        critical_forgetting = [
            cat for cat in report.forgetting_categories
            if cat in critical_categories
        ]
        if critical_forgetting:
            return True

    # Bloquear si la precisión global es muy baja
    if report.overall_accuracy < 0.5:
        return True

    return False


async def run_scheduled_monitoring(interval_hours=24):
    """Ejecuta monitoreo programado de la calidad del modelo."""
    logger.info(f"📅 Iniciando monitoreo programado cada {interval_hours} horas")

    config = RegressionTestConfig()
    suite = AccuracyRegressionSuite(config)

    while True:
        try:
            model_version = f"scheduled_monitoring_{int(asyncio.get_event_loop().time())}"
            await suite.run_regression_test(model_version, trigger="scheduled")

            logger.info(f"⏰ Próxima evaluación en {interval_hours} horas")
            await asyncio.sleep(interval_hours * 3600)

        except KeyboardInterrupt:
            logger.info("📅 Monitoreo programado detenido por usuario")
            break
        except Exception as e:
            logger.error(f"❌ Error en monitoreo programado: {e}")
            await asyncio.sleep(300)  # Reintentar en 5 minutos


def main():
    """Función principal."""
    args = parse_arguments()

    # Configurar logging basado en argumentos
    if args.trigger == "federated_update":
        logging.getLogger().setLevel(logging.WARNING)  # Menos verbose para CI/CD
    else:
        logging.getLogger().setLevel(logging.INFO)

    # Ejecutar evaluación
    if hasattr(args, 'scheduled') and args.scheduled:
        # Modo de monitoreo programado
        asyncio.run(run_scheduled_monitoring(getattr(args, 'interval', 24)))
    else:
        # Evaluación única
        exit_code = asyncio.run(run_evaluation(args))
        sys.exit(exit_code)


if __name__ == "__main__":
    main()