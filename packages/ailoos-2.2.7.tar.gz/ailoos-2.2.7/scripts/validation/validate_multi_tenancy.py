#!/usr/bin/env python3
"""
Script de validación para Multi-Tenancy System FASE 8
====================================================

Valida que todos los componentes del sistema de multi-tenancy
se importen correctamente y no tengan errores de sintaxis.
"""

import sys
import traceback
from datetime import datetime

def validate_import(module_name, class_name=None):
    """Valida la importación de un módulo"""
    try:
        module = __import__(module_name, fromlist=[class_name] if class_name else [])
        if class_name:
            cls = getattr(module, class_name)
            print(f"✅ {module_name}.{class_name} - OK")
            return True, cls
        else:
            print(f"✅ {module_name} - OK")
            return True, module
    except Exception as e:
        print(f"❌ {module_name}" + (f".{class_name}" if class_name else "") + f" - ERROR: {e}")
        return False, None

def validate_instantiation(cls, *args, **kwargs):
    """Valida la instanciación de una clase"""
    try:
        instance = cls(*args, **kwargs)
        print(f"✅ {cls.__name__}() - OK")
        return True, instance
    except Exception as e:
        print(f"❌ {cls.__name__}() - ERROR: {e}")
        return False, None

def main():
    """Función principal de validación"""
    print("🔍 Validando Multi-Tenancy System FASE 8")
    print("=" * 50)
    print(f"Timestamp: {datetime.now().isoformat()}")
    print()

    results = []

    # 1. Validar imports principales
    print("📦 Validando imports principales...")

    success, tenant_manager_cls = validate_import("src.ailoos.multi_tenancy.tenant_manager", "TenantManager")
    results.append(("TenantManager import", success))

    success, tenant_isolation_cls = validate_import("src.ailoos.multi_tenancy.tenant_isolation", "TenantIsolationMiddleware")
    results.append(("TenantIsolationMiddleware import", success))

    success, tenant_database_cls = validate_import("src.ailoos.multi_tenancy.tenant_database", "TenantDatabase")
    results.append(("TenantDatabase import", success))

    success, tenant_security_cls = validate_import("src.ailoos.multi_tenancy.tenant_security", "TenantSecurity")
    results.append(("TenantSecurity import", success))

    success, tenant_billing_cls = validate_import("src.ailoos.multi_tenancy.tenant_billing", "TenantBilling")
    results.append(("TenantBilling import", success))

    success, tenant_migration_cls = validate_import("src.ailoos.multi_tenancy.tenant_migration", "TenantMigration")
    results.append(("TenantMigration import", success))

    # 2. Validar import del módulo completo
    print("\n📦 Validando import del módulo multi_tenancy...")
    success, multi_tenancy_module = validate_import("src.ailoos.multi_tenancy")
    results.append(("multi_tenancy module import", success))

    # 3. Validar instanciación básica (sin dependencias complejas)
    print("\n🏗️ Validando instanciación básica...")

    if tenant_manager_cls:
        success, tenant_manager = validate_instantiation(tenant_manager_cls)
        results.append(("TenantManager instantiation", success))

        if success:
            # Probar creación básica de tenant
            try:
                import asyncio
                tenant = asyncio.run(tenant_manager.create_tenant("ValidationTenant", "validation@test.com"))
                print("✅ Tenant creation - OK")
                results.append(("Tenant creation", True))
            except Exception as e:
                print(f"❌ Tenant creation - ERROR: {e}")
                results.append(("Tenant creation", False))

    # 4. Validar enums y constantes
    print("\n🔧 Validando enums y constantes...")

    try:
        from src.ailoos.multi_tenancy.tenant_manager import TenantStatus, TenantPlan
        assert TenantStatus.ACTIVE.value == "active"
        assert TenantPlan.BASIC.value == "basic"
        print("✅ Tenant enums - OK")
        results.append(("Tenant enums", True))
    except Exception as e:
        print(f"❌ Tenant enums - ERROR: {e}")
        results.append(("Tenant enums", False))

    try:
        from src.ailoos.multi_tenancy.tenant_security import Permission, Role
        assert Permission.READ.value == "read"
        assert Role.ADMIN.value == "admin"
        print("✅ Security enums - OK")
        results.append(("Security enums", True))
    except Exception as e:
        print(f"❌ Security enums - ERROR: {e}")
        results.append(("Security enums", False))

    try:
        from src.ailoos.multi_tenancy.tenant_billing import BillingCycle, PaymentMethod
        assert BillingCycle.MONTHLY.value == "monthly"
        assert PaymentMethod.CREDIT_CARD.value == "credit_card"
        print("✅ Billing enums - OK")
        results.append(("Billing enums", True))
    except Exception as e:
        print(f"❌ Billing enums - ERROR: {e}")
        results.append(("Billing enums", False))

    # 5. Resumen final
    print("\n" + "=" * 50)
    print("📊 RESUMEN DE VALIDACIÓN")
    print("=" * 50)

    total_tests = len(results)
    passed_tests = sum(1 for _, success in results if success)

    for test_name, success in results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}")

    print(f"\nResultados: {passed_tests}/{total_tests} tests pasaron")

    if passed_tests == total_tests:
        print("🎉 ¡VALIDACIÓN COMPLETA! El sistema Multi-Tenancy está listo.")
        return 0
    else:
        print("⚠️ Algunos componentes tienen problemas. Revisar logs arriba.")
        return 1

if __name__ == "__main__":
    sys.exit(main())