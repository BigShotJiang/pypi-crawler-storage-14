"""
Framework exhaustivo de testing de rendimiento de inferencia para AILOOS.
Enfocado en métricas de latencia, throughput y cache para inferencia de modelos.
"""

import asyncio
import json
import time
import random
import sys
import os
import statistics
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

# Añadir el directorio raíz al path para importar módulos
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Importaciones opcionales
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    print("WARNING: NumPy no disponible, algunas métricas serán limitadas")

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    print("WARNING: PyTorch no disponible, simulando inferencia")

# Importaciones de AILOOS
from src.ailoos.inference.api import InferenceConfig, EmpoorioLMInferenceAPI, InferenceRequest
from src.ailoos.rag.cache_augmented.cache_augmented_rag import CacheAugmentedRAG
from src.ailoos.rag.techniques.naive_rag import NaiveRAG

logger = logging.getLogger(__name__)


@dataclass
class InferencePerformanceTestConfig:
    """Configuración para tests de rendimiento de inferencia."""

    # Configuración de carga de trabajo
    num_concurrent_requests: int = 10
    num_requests_per_test: int = 100
    test_duration_seconds: int = 60

    # Configuración de prompts y contextos
    prompt_templates: List[str] = field(default_factory=lambda: [
        "¿Cuál es la capital de {country}?",
        "Explica el concepto de {concept} en machine learning",
        "Escribe un resumen de {topic} en 100 palabras",
        "¿Cómo funciona {technology}?",
        "Traduce '{phrase}' del inglés al español"
    ])

    context_lengths: List[int] = field(default_factory=lambda: [100, 500, 1000, 2000])
    prompt_lengths: List[int] = field(default_factory=lambda: [10, 50, 100, 200])

    # Configuración de cache
    enable_cache_testing: bool = True
    cache_similarity_thresholds: List[float] = field(default_factory=lambda: [0.7, 0.8, 0.9])

    # Configuración de warm-up
    warmup_requests: int = 5
    warmup_delay: float = 0.1

    # Configuración de percentiles y métricas
    latency_percentiles: List[float] = field(default_factory=lambda: [50.0, 90.0, 95.0, 99.0, 99.9])

    # Configuración de validaciones
    enable_drift_check: bool = False
    enable_memory_monitoring: bool = True

    # Configuración de reporting
    results_file: str = "inference_performance_results.json"
    enable_detailed_logging: bool = True


@dataclass
class InferenceRequestData:
    """Datos de una solicitud de inferencia para testing."""

    request_id: str
    prompt: str
    context: Optional[str] = None
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    response: Optional[str] = None
    error: Optional[str] = None
    cache_hit: bool = False
    tokens_generated: int = 0
    response_time: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            'request_id': self.request_id,
            'prompt_length': len(self.prompt.split()),
            'context_length': len(self.context.split()) if self.context else 0,
            'response_time': self.response_time,
            'cache_hit': self.cache_hit,
            'tokens_generated': self.tokens_generated,
            'error': self.error,
            'timestamp': self.start_time
        }


class InferencePerformanceTestSuite:
    """
    Suite de tests para evaluar rendimiento de inferencia de modelos AILOOS.

    Tests incluidos:
    - Latencia P99 con percentiles detallados
    - Throughput bajo carga concurrente
    - Cache Hit Rate para CAG
    - Warm-up del modelo
    - Métricas detalladas y reporting
    """

    def __init__(self, config: InferencePerformanceTestConfig):
        self.config = config

        # Componentes de inferencia
        self.inference_api: Optional[EmpoorioLMInferenceAPI] = None
        self.cag_system: Optional[CacheAugmentedRAG] = None

        # Estado del test
        self.test_results: Dict[str, Any] = {}
        self.request_history: List[InferenceRequestData] = []
        self.is_warmed_up: bool = False

        # Ejecutores para concurrencia
        self.executor = ThreadPoolExecutor(max_workers=config.num_concurrent_requests)

        # Métricas acumuladas
        self.metrics = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_response_time': 0.0,
            'response_times': [],
            'cache_hits': 0,
            'cache_misses': 0,
            'total_tokens_generated': 0,
            'throughput_requests_per_sec': 0.0,
            'throughput_tokens_per_sec': 0.0,
            'memory_usage_mb': 0.0,
            'cpu_usage_percent': 0.0
        }

        # Configuración de logging
        if config.enable_detailed_logging:
            logging.basicConfig(level=logging.INFO)
        else:
            logging.basicConfig(level=logging.WARNING)

    async def setup_test_environment(self) -> bool:
        """
        Configurar entorno de testing con API de inferencia y CAG.

        Returns:
            True si la configuración fue exitosa
        """
        print("🚀 Setting up inference performance test environment...")

        try:
            # Configurar API de inferencia
            inference_config = InferenceConfig(
                enable_cache=self.config.enable_cache_testing,
                enable_drift_monitoring=self.config.enable_drift_check,
                max_concurrent_requests=self.config.num_concurrent_requests
            )

            self.inference_api = EmpoorioLMInferenceAPI(inference_config)

            # Cargar modelo
            model_loaded = await self.inference_api.load_model()
            if not model_loaded:
                print("❌ Failed to load inference model")
                return False

            # Configurar CAG si está habilitado
            if self.config.enable_cache_testing:
                base_rag_config = {
                    'vector_store_config': {'type': 'chroma', 'persist_directory': './test_cache'},
                    'embedding_config': {'model_name': 'all-MiniLM-L6-v2'},
                    'chunking_config': {'chunk_size': 512, 'chunk_overlap': 50}
                }

                base_rag = NaiveRAG(base_rag_config)

                cag_config = {
                    'base_rag_class': type(base_rag),
                    'base_rag_config': base_rag_config,
                    'cache_config': {
                        'model_name': 'all-MiniLM-L6-v2',
                        'similarity_threshold': 0.8,
                        'max_size': 1000,
                        'eviction_policy': 'LRU'
                    },
                    'cache_enabled': True
                }

                self.cag_system = CacheAugmentedRAG(cag_config)

            print("✅ Test environment ready")
            return True

        except Exception as e:
            print(f"❌ Error setting up test environment: {e}")
            return False

    async def teardown_test_environment(self):
        """Limpiar entorno de testing."""
        print("🛑 Tearing down test environment...")

        if self.inference_api:
            # Aquí podríamos guardar métricas o limpiar recursos
            pass

        if self.executor:
            self.executor.shutdown(wait=True)

        print("✅ Test environment cleaned up")

    def generate_test_prompts(self, count: int, prompt_length: int = 50) -> List[str]:
        """Generar prompts de test variados."""
        prompts = []

        # Datos para templates
        countries = ["Francia", "Alemania", "Italia", "España", "Reino Unido", "Japón", "Brasil", "Canadá"]
        concepts = ["regresión lineal", "redes neuronales", "aprendizaje profundo", "procesamiento de lenguaje natural"]
        topics = ["inteligencia artificial", "cambio climático", "historia de la computación", "física cuántica"]
        technologies = ["blockchain", "machine learning", "cloud computing", "internet de las cosas"]
        phrases = ["Hello world", "How are you", "Thank you very much", "Good morning"]

        for i in range(count):
            template = random.choice(self.config.prompt_templates)

            # Rellenar template
            if "{country}" in template:
                template = template.format(country=random.choice(countries))
            elif "{concept}" in template:
                template = template.format(concept=random.choice(concepts))
            elif "{topic}" in template:
                template = template.format(topic=random.choice(topics))
            elif "{technology}" in template:
                template = template.format(technology=random.choice(technologies))
            elif "{phrase}" in template:
                template = template.format(phrase=random.choice(phrases))

            # Ajustar longitud si es necesario
            words = template.split()
            if len(words) < prompt_length:
                # Añadir contexto adicional
                extra_context = f" Por favor, proporciona una respuesta detallada y bien estructurada. Considera los siguientes aspectos: definición, importancia, aplicaciones prácticas y ejemplos concretos. Asegúrate de que la respuesta sea comprehensiva pero concisa."
                template += extra_context

            prompts.append(template)

        return prompts

    def generate_test_contexts(self, count: int, context_length: int = 500) -> List[str]:
        """Generar contextos de test con diferentes longitudes."""
        contexts = []

        base_texts = [
            "La inteligencia artificial es una rama de la informática que se ocupa de crear máquinas capaces de realizar tareas que normalmente requieren inteligencia humana. Estas tareas incluyen el aprendizaje, el razonamiento, la resolución de problemas, la percepción, el entendimiento del lenguaje natural y hasta el aprendizaje automático.",
            "El machine learning es un subcampo de la inteligencia artificial que se centra en el desarrollo de algoritmos y modelos estadísticos que permiten a las computadoras aprender de los datos sin ser programadas explícitamente para cada tarea específica.",
            "Las redes neuronales artificiales están inspiradas en el funcionamiento del cerebro humano. Consisten en capas de nodos interconectados que procesan información y aprenden patrones a través de la exposición repetida a datos de entrenamiento.",
            "El procesamiento de lenguaje natural combina lingüística computacional, inteligencia artificial y aprendizaje automático para permitir que las computadoras entiendan, interpreten y generen lenguaje humano de manera natural."
        ]

        for i in range(count):
            base_text = random.choice(base_texts)

            # Repetir o truncar para alcanzar la longitud deseada
            words = base_text.split()
            target_words = context_length

            if len(words) < target_words:
                # Repetir el texto
                repetitions = (target_words // len(words)) + 1
                extended_text = (base_text + " ") * repetitions
                context = " ".join(extended_text.split()[:target_words])
            else:
                context = " ".join(words[:target_words])

            contexts.append(context)

        return contexts

    async def warmup_model(self) -> Dict[str, Any]:
        """Realizar warm-up del modelo antes de los tests de rendimiento."""
        print(f"🔥 Warming up model with {self.config.warmup_requests} requests...")

        start_time = time.time()
        warmup_requests = []

        # Generar requests de warm-up
        prompts = self.generate_test_prompts(self.config.warmup_requests, 20)

        for i, prompt in enumerate(prompts):
            request_data = InferenceRequestData(
                request_id=f"warmup_{i}",
                prompt=prompt
            )
            warmup_requests.append(request_data)

        # Ejecutar requests de warm-up
        tasks = []
        for request_data in warmup_requests:
            task = self._execute_single_inference_request(request_data, is_warmup=True)
            tasks.append(task)

        await asyncio.gather(*tasks, return_exceptions=True)

        warmup_time = time.time() - start_time
        self.is_warmed_up = True

        result = {
            'warmup_duration': warmup_time,
            'requests_completed': len([r for r in warmup_requests if r.error is None]),
            'avg_response_time': statistics.mean([r.response_time for r in warmup_requests if r.response_time > 0]) if warmup_requests else 0
        }

        print(f"✅ Warm-up completed in {warmup_time:.2f}s")
        return result

    async def _execute_single_inference_request(self, request_data: InferenceRequestData, is_warmup: bool = False) -> InferenceRequestData:
        """Ejecutar una sola solicitud de inferencia."""
        try:
            request_data.start_time = time.time()

            # Crear request para la API
            inference_request = InferenceRequest(
                prompt=request_data.prompt,
                max_tokens=100,  # Limitar para tests de rendimiento
                temperature=0.7,
                stream=False
            )

            # Ejecutar inferencia
            if self.cag_system and not is_warmup:
                # Usar CAG para testing de cache
                context_docs = [{"content": request_data.context or "", "metadata": {}}] if request_data.context else []
                response = self.cag_system.generate(request_data.prompt, context_docs)
                cache_hit = self.cag_system._last_generation_metadata.get('cache_hit', False)
                request_data.cache_hit = cache_hit
            else:
                # Usar API directa
                response = await self.inference_api.generate(inference_request)
                request_data.cache_hit = False

            request_data.end_time = time.time()
            request_data.response_time = request_data.end_time - request_data.start_time

            if hasattr(response, 'text'):
                request_data.response = response.text
                request_data.tokens_generated = len(response.text.split())
            else:
                request_data.response = str(response)
                request_data.tokens_generated = len(str(response).split())

            # Actualizar métricas
            self._update_metrics(request_data)

        except Exception as e:
            request_data.error = str(e)
            request_data.end_time = time.time()
            request_data.response_time = request_data.end_time - request_data.start_time
            self.metrics['failed_requests'] += 1

        return request_data

    def _update_metrics(self, request_data: InferenceRequestData):
        """Actualizar métricas globales con datos de una request."""
        self.metrics['total_requests'] += 1

        if request_data.error is None:
            self.metrics['successful_requests'] += 1
            self.metrics['total_response_time'] += request_data.response_time
            self.metrics['response_times'].append(request_data.response_time)
            self.metrics['total_tokens_generated'] += request_data.tokens_generated

            if request_data.cache_hit:
                self.metrics['cache_hits'] += 1
            else:
                self.metrics['cache_misses'] += 1
        else:
            self.metrics['failed_requests'] += 1

    async def test_latency_percentiles(self) -> Dict[str, Any]:
        """Test de latencia con percentiles detallados (P50, P90, P95, P99, P99.9)."""
        print(f"📊 Testing latency percentiles with {self.config.num_requests_per_test} requests...")

        start_time = time.time()

        # Generar requests de test
        prompts = self.generate_test_prompts(self.config.num_requests_per_test)
        test_requests = []

        for i, prompt in enumerate(prompts):
            request_data = InferenceRequestData(
                request_id=f"latency_{i}",
                prompt=prompt
            )
            test_requests.append(request_data)

        # Ejecutar requests secuencialmente para medir latencia pura
        for request_data in test_requests:
            await self._execute_single_inference_request(request_data)
            self.request_history.append(request_data)

        # Calcular percentiles
        response_times = [r.response_time for r in test_requests if r.error is None]

        if not response_times:
            print("❌ No successful requests for latency calculation")
            return {'error': 'No successful requests'}

        # Calcular percentiles usando numpy si está disponible
        if HAS_NUMPY:
            percentiles = {}
            for p in self.config.latency_percentiles:
                percentiles[f'p{int(p) if p.is_integer() else str(p).replace(".", "_")}'] = float(np.percentile(response_times, p))
        else:
            # Fallback usando statistics
            percentiles = {}
            sorted_times = sorted(response_times)
            for p in self.config.latency_percentiles:
                if p == 50.0:
                    percentiles['p50'] = statistics.median(sorted_times)
                elif p == 90.0:
                    idx = int(len(sorted_times) * 0.9)
                    percentiles['p90'] = sorted_times[min(idx, len(sorted_times) - 1)]
                elif p == 95.0:
                    idx = int(len(sorted_times) * 0.95)
                    percentiles['p95'] = sorted_times[min(idx, len(sorted_times) - 1)]
                elif p == 99.0:
                    idx = int(len(sorted_times) * 0.99)
                    percentiles['p99'] = sorted_times[min(idx, len(sorted_times) - 1)]
                elif p == 99.9:
                    idx = int(len(sorted_times) * 0.999)
                    percentiles['p999'] = sorted_times[min(idx, len(sorted_times) - 1)]

        # Estadísticas adicionales
        test_duration = time.time() - start_time

        result = {
            'test_name': 'latency_percentiles',
            'duration': test_duration,
            'total_requests': len(test_requests),
            'successful_requests': len(response_times),
            'success_rate': len(response_times) / len(test_requests),
            'min_latency': min(response_times),
            'max_latency': max(response_times),
            'mean_latency': statistics.mean(response_times),
            'median_latency': statistics.median(response_times),
            'std_dev_latency': statistics.stdev(response_times) if len(response_times) > 1 else 0,
            'percentiles': percentiles
        }

        print(f"✅ Latency test completed in {test_duration:.2f}s")
        return result

    async def test_throughput_concurrent_load(self) -> Dict[str, Any]:
        """Test de throughput bajo carga concurrente."""
        print(f"⚡ Testing throughput with {self.config.num_concurrent_requests} concurrent requests...")

        start_time = time.time()
        test_requests = []

        # Generar requests de test
        prompts = self.generate_test_prompts(self.config.num_requests_per_test)

        for i, prompt in enumerate(prompts):
            request_data = InferenceRequestData(
                request_id=f"throughput_{i}",
                prompt=prompt
            )
            test_requests.append(request_data)

        # Ejecutar requests concurrentemente
        semaphore = asyncio.Semaphore(self.config.num_concurrent_requests)

        async def execute_with_semaphore(request_data):
            async with semaphore:
                return await self._execute_single_inference_request(request_data)

        tasks = [execute_with_semaphore(request_data) for request_data in test_requests]
        completed_requests = await asyncio.gather(*tasks, return_exceptions=True)

        # Procesar resultados
        successful_requests = [r for r in completed_requests if isinstance(r, InferenceRequestData) and r.error is None]
        failed_requests = [r for r in completed_requests if isinstance(r, InferenceRequestData) and r.error is not None]

        test_duration = time.time() - start_time

        # Calcular métricas de throughput
        total_requests_completed = len(successful_requests)
        total_tokens_generated = sum(r.tokens_generated for r in successful_requests)

        throughput_requests_per_sec = total_requests_completed / test_duration if test_duration > 0 else 0
        throughput_tokens_per_sec = total_tokens_generated / test_duration if test_duration > 0 else 0

        # Actualizar métricas globales
        self.metrics['throughput_requests_per_sec'] = throughput_requests_per_sec
        self.metrics['throughput_tokens_per_sec'] = throughput_tokens_per_sec

        result = {
            'test_name': 'throughput_concurrent_load',
            'duration': test_duration,
            'total_requests': len(test_requests),
            'successful_requests': total_requests_completed,
            'failed_requests': len(failed_requests),
            'success_rate': total_requests_completed / len(test_requests),
            'throughput_requests_per_sec': throughput_requests_per_sec,
            'throughput_tokens_per_sec': throughput_tokens_per_sec,
            'concurrent_clients': self.config.num_concurrent_requests,
            'avg_response_time': statistics.mean([r.response_time for r in successful_requests]) if successful_requests else 0
        }

        print(f"✅ Latency test completed in {test_duration:.2f}s")
        return result

    async def test_cache_hit_rate_cag(self) -> Dict[str, Any]:
        """Test de Cache Hit Rate para Cache Augmented Generation."""
        if not self.cag_system:
            print("⚠️ CAG system not available, skipping cache hit rate test")
            return {'test_name': 'cache_hit_rate_cag', 'skipped': True, 'reason': 'CAG not enabled'}

        print("💾 Testing Cache Hit Rate for CAG...")

        start_time = time.time()

        # Fase 1: Poblar cache con requests iniciales
        print("   📥 Populating cache...")
        populate_requests = self.generate_test_prompts(20, 30)
        cache_population_requests = []

        for i, prompt in enumerate(populate_requests):
            request_data = InferenceRequestData(
                request_id=f"cache_populate_{i}",
                prompt=prompt,
                context=self.generate_test_contexts(1, 200)[0]
            )
            cache_population_requests.append(request_data)

        # Ejecutar requests para poblar cache
        for request_data in cache_population_requests:
            await self._execute_single_inference_request(request_data)

        # Fase 2: Test de cache hits con queries similares
        print("   🔍 Testing cache hits with similar queries...")
        test_requests = []

        # Crear queries similares a las del cache
        for i, original_prompt in enumerate(populate_requests[:10]):
            # Crear variación similar
            similar_prompt = original_prompt.replace("Explica", "Describe").replace("¿Cuál", "¿Qué")
            request_data = InferenceRequestData(
                request_id=f"cache_test_{i}",
                prompt=similar_prompt,
                context=self.generate_test_contexts(1, 200)[0]
            )
            test_requests.append(request_data)

        # Ejecutar test de cache
        for request_data in test_requests:
            await self._execute_single_inference_request(request_data)
            self.request_history.append(request_data)

        # Calcular métricas de cache
        cache_hits = sum(1 for r in test_requests if r.cache_hit)
        cache_misses = len(test_requests) - cache_hits
        cache_hit_rate = cache_hits / len(test_requests) if test_requests else 0

        test_duration = time.time() - start_time

        result = {
            'test_name': 'cache_hit_rate_cag',
            'duration': test_duration,
            'cache_population_requests': len(cache_population_requests),
            'cache_test_requests': len(test_requests),
            'cache_hits': cache_hits,
            'cache_misses': cache_misses,
            'cache_hit_rate': cache_hit_rate,
            'cache_similarity_threshold': self.cag_system.cache_manager.similarity_threshold if self.cag_system.cache_manager else None,
            'cache_size': len(self.cag_system.cache_manager) if self.cag_system.cache_manager else 0
        }

        print(f"✅ Cache test completed with {cache_hit_rate:.1%} hit rate")
        return result

    async def run_comprehensive_performance_test(self) -> Dict[str, Any]:
        """Ejecutar test completo de rendimiento de inferencia."""
        print("🎯 Running comprehensive inference performance test...")

        start_time = time.time()
        test_results = {}

        try:
            # 1. Warm-up
            warmup_result = await self.warmup_model()
            test_results['warmup'] = warmup_result

            # 2. Test de latencia
            latency_result = await self.test_latency_percentiles()
            test_results['latency_percentiles'] = latency_result

            # 3. Test de throughput
            throughput_result = await self.test_throughput_concurrent_load()
            test_results['throughput'] = throughput_result

            # 4. Test de cache (si está habilitado)
            if self.config.enable_cache_testing:
                cache_result = await self.test_cache_hit_rate_cag()
                test_results['cache_performance'] = cache_result

            # Calcular métricas globales finales
            total_duration = time.time() - start_time
            overall_success_rate = self.metrics['successful_requests'] / self.metrics['total_requests'] if self.metrics['total_requests'] > 0 else 0

            # Validaciones exhaustivas
            validations = self._perform_exhaustive_validations(test_results)

            comprehensive_result = {
                'test_name': 'comprehensive_inference_performance',
                'total_duration': total_duration,
                'overall_success_rate': overall_success_rate,
                'individual_test_results': test_results,
                'global_metrics': self.metrics.copy(),
                'validations': validations,
                'test_config': {
                    'num_concurrent_requests': self.config.num_concurrent_requests,
                    'num_requests_per_test': self.config.num_requests_per_test,
                    'cache_enabled': self.config.enable_cache_testing,
                    'drift_monitoring_enabled': self.config.enable_drift_check
                },
                'timestamp': time.time()
            }

            print(f"🎯 Comprehensive test completed in {total_duration:.2f}s")
            return comprehensive_result

        except Exception as e:
            print(f"❌ Error during comprehensive test: {e}")
            # Calcular métricas disponibles hasta el momento del error
            total_duration = time.time() - start_time
            overall_success_rate = self.metrics['successful_requests'] / self.metrics['total_requests'] if self.metrics['total_requests'] > 0 else 0

            return {
                'test_name': 'comprehensive_inference_performance',
                'total_duration': total_duration,
                'overall_success_rate': overall_success_rate,
                'error': str(e),
                'partial_results': test_results
            }

        except Exception as e:
            print(f"❌ Comprehensive test failed: {e}")
            return {
                'test_name': 'comprehensive_inference_performance',
                'error': str(e),
                'partial_results': test_results
            }

    def _perform_exhaustive_validations(self, test_results: Dict[str, Any]) -> Dict[str, Any]:
        """Realizar validaciones exhaustivas de los resultados."""
        validations = {
            'latency_requirements': {},
            'throughput_requirements': {},
            'cache_requirements': {},
            'overall_health': {}
        }

        # Validar latencia
        latency_result = test_results.get('latency_percentiles', {})
        if 'percentiles' in latency_result:
            p99 = latency_result['percentiles'].get('p99', float('inf'))
            p999 = latency_result['percentiles'].get('p999', float('inf'))

            # Requisitos típicos: P99 < 5s, P99.9 < 10s para inferencia
            validations['latency_requirements'] = {
                'p99_under_5s': p99 < 5.0,
                'p999_under_10s': p999 < 10.0,
                'success_rate_above_95': latency_result.get('success_rate', 0) > 0.95
            }

        # Validar throughput
        throughput_result = test_results.get('throughput', {})
        throughput_rps = throughput_result.get('throughput_requests_per_sec', 0)

        # Requisitos típicos: > 10 RPS para carga concurrente
        validations['throughput_requirements'] = {
            'throughput_above_10_rps': throughput_rps > 10.0,
            'success_rate_above_90': throughput_result.get('success_rate', 0) > 0.90
        }

        # Validar cache
        cache_result = test_results.get('cache_performance', {})
        if not cache_result.get('skipped', False):
            cache_hit_rate = cache_result.get('cache_hit_rate', 0)

            # Requisitos típicos: Cache hit rate > 30% para queries similares
            validations['cache_requirements'] = {
                'cache_hit_rate_above_30': cache_hit_rate > 0.30,
                'cache_functional': cache_result.get('cache_hits', 0) > 0
            }

        # Validación general de salud
        overall_success = all([
            all(validations['latency_requirements'].values()) if validations['latency_requirements'] else True,
            all(validations['throughput_requirements'].values()),
            all(validations['cache_requirements'].values()) if validations['cache_requirements'] else True
        ])

        validations['overall_health'] = {
            'all_tests_passed': overall_success,
            'critical_failures': sum(1 for req_group in validations.values()
                                   if isinstance(req_group, dict) and not all(req_group.values()))
        }

        return validations

    def save_results(self, results: Dict[str, Any], filename: Optional[str] = None):
        """Guardar resultados de test en archivo JSON."""
        if filename is None:
            filename = self.config.results_file

        try:
            # Preparar datos para serialización
            serializable_results = json.loads(json.dumps(results, default=str))

            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(serializable_results, f, indent=2, ensure_ascii=False)

            print(f"💾 Results saved to {filename}")
            return True

        except Exception as e:
            print(f"❌ Error saving results: {e}")
            return False

    def print_detailed_report(self, results: Dict[str, Any]):
        """Imprimir reporte detallado de resultados."""
        print("\n" + "="*80)
        print("📊 INFERENCE PERFORMANCE TEST REPORT")
        print("="*80)

        # Resultados generales
        if 'total_duration' in results:
            print(f"   Total Duration: {results['total_duration']:.2f}s")
        if 'overall_success_rate' in results:
            print(f"   Overall Success Rate: {results['overall_success_rate']:.1%}")

        # Resultados individuales
        individual_results = results.get('individual_test_results', {})
        for test_name, test_result in individual_results.items():
            print(f"\n🔍 {test_name.replace('_', ' ').title()}")
            print("-" * 50)

            if test_result.get('skipped'):
                print(f"   ⚠️ Skipped: {test_result.get('reason', 'N/A')}")
                continue

            if 'error' in test_result:
                print(f"   ❌ Error: {test_result['error']}")
                continue

            # Métricas específicas por test
            if test_name == 'latency_percentiles':
                p = test_result.get('percentiles', {})
                print(f"   P50 Latency: {p.get('p50', 0):.3f}s")
                print(f"   P90 Latency: {p.get('p90', 0):.3f}s")
                print(f"   P95 Latency: {p.get('p95', 0):.3f}s")
                print(f"   P99 Latency: {p.get('p99', 0):.3f}s")
                print(f"   Success Rate: {test_result.get('success_rate', 0):.1%}")

            elif test_name == 'throughput':
                print(f"   Throughput: {test_result.get('throughput_requests_per_sec', 0):.2f} req/s")
                print(f"   Token Throughput: {test_result.get('throughput_tokens_per_sec', 0):.2f} tok/s")
                print(f"   Success Rate: {test_result.get('success_rate', 0):.1%}")

            elif test_name == 'cache_performance':
                print(f"   Cache Hit Rate: {test_result.get('cache_hit_rate', 0):.1%}")
                print(f"   Cache Hits: {test_result.get('cache_hits', 0)}")
                print(f"   Cache Misses: {test_result.get('cache_misses', 0)}")

            elif test_name == 'warmup':
                print(f"   Warm-up Duration: {test_result.get('warmup_duration', 0):.2f}s")
                print(f"   Requests: {test_result.get('requests_completed', 0)}")

        # Validaciones
        validations = results.get('validations', {})
        if validations:
            print("\n🔍 VALIDATIONS")
            print("-" * 50)

            for category, checks in validations.items():
                if isinstance(checks, dict):
                    passed = sum(checks.values())
                    total = len(checks)
                    status = "✅" if passed == total else "❌"
                    print(f"   {status} {category}: {passed}/{total} passed")

        print("\n" + "="*80)


async def run_inference_performance_test(
    num_concurrent_requests: int = 10,
    num_requests_per_test: int = 100,
    enable_cache_testing: bool = True
) -> Dict[str, Any]:
    """
    Ejecutar test de rendimiento de inferencia con configuración adaptada.

    Args:
        num_concurrent_requests: Número de requests concurrentes
        num_requests_per_test: Número de requests por test
        enable_cache_testing: Habilitar testing de cache CAG

    Returns:
        Resultados completos del test
    """
    print(f'🚀 Ejecutando test de rendimiento de inferencia con {num_concurrent_requests} requests concurrentes...')

    # Configuración adaptada
    config = InferencePerformanceTestConfig(
        num_concurrent_requests=num_concurrent_requests,
        num_requests_per_test=num_requests_per_test,
        enable_cache_testing=enable_cache_testing
    )

    suite = InferencePerformanceTestSuite(config)
    results = {}

    try:
        # Setup
        setup_success = await suite.setup_test_environment()
        if not setup_success:
            return {'error': 'Setup failed'}

        # Ejecutar test completo
        results = await suite.run_comprehensive_performance_test()

        # Guardar resultados
        suite.save_results(results)

        # Imprimir reporte
        suite.print_detailed_report(results)

        return results

    except Exception as e:
        print(f'❌ Test falló con error: {e}')
        import traceback
        traceback.print_exc()
        return {'error': str(e), 'partial_results': results}

    finally:
        await suite.teardown_test_environment()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Ejecutar tests de rendimiento de inferencia AILOOS')
    parser.add_argument('--concurrent', type=int, default=10,
                       help='Número de requests concurrentes (default: 10)')
    parser.add_argument('--requests', type=int, default=100,
                       help='Número de requests por test (default: 100)')
    parser.add_argument('--cache', action='store_true', default=True,
                       help='Habilitar testing de cache CAG')
    parser.add_argument('--no-cache', action='store_true',
                       help='Deshabilitar testing de cache CAG')

    args = parser.parse_args()

    # Ejecutar test
    enable_cache = args.cache and not args.no_cache
    success_result = asyncio.run(run_inference_performance_test(
        num_concurrent_requests=args.concurrent,
        num_requests_per_test=args.requests,
        enable_cache_testing=enable_cache
    ))

    if 'error' not in success_result:
        print('\n🎉 Tests de rendimiento completados exitosamente!')
    else:
        print(f'\n❌ Tests fallaron: {success_result["error"]}')