"""
Tests standalone para la FASE 2: Entrenamiento Asíncrono
Tests que no dependen del sistema de módulos del proyecto.
"""

import asyncio
import sys
import os
import tempfile
import shutil
import torch
import torch.nn as nn
import torch.optim as optim
from pathlib import Path
from unittest.mock import Mock, AsyncMock
import json
import time


# Añadir el directorio de training al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'ailoos', 'training'))

# Importar módulos directamente
from training_state_manager import TrainingStateManager, TrainingStatus
from checkpoint_manager import CheckpointManager, CheckpointConfig, CompressionType
from training_progress_tracker import TrainingProgressTracker


class SimpleModel(nn.Module):
    """Modelo simple para tests."""
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(10, 2)

    def forward(self, x):
        return self.linear(x)


def test_training_state_manager():
    """Test básico de TrainingStateManager."""
    print("🧪 Testing TrainingStateManager...")

    # Crear directorio temporal
    temp_dir = tempfile.mkdtemp()

    try:
        # Crear manager
        manager = TrainingStateManager(temp_dir)

        # Test crear sesión
        async def test_create():
            session = await manager.create_session(
                session_id="test_session",
                model_version="v1.0",
                training_config={"epochs": 10},
                model_config={"type": "test"}
            )
            assert session.session_id == "test_session"
            assert session.status == TrainingStatus.NOT_STARTED
            print("✅ Create session test passed")

            # Test obtener sesión
            retrieved = await manager.get_session("test_session")
            assert retrieved.session_id == "test_session"
            print("✅ Get session test passed")

            # Test actualizar progreso
            await manager.update_session_progress(
                session_id="test_session",
                epoch=1,
                batch=10,
                loss=0.5,
                accuracy=0.8,
                learning_rate=0.001,
                optimizer_state={}
            )

            session = await manager.get_session("test_session")
            assert session.current_epoch == 1
            assert session.loss_history == [0.5]
            print("✅ Update progress test passed")

            # Test estados
            await manager.pause_session("test_session")
            session = await manager.get_session("test_session")
            assert session.status == TrainingStatus.PAUSED

            resumed = await manager.resume_session("test_session")
            assert resumed.status == TrainingStatus.RUNNING

            await manager.complete_session("test_session")
            session = await manager.get_session("test_session")
            assert session.status == TrainingStatus.COMPLETED
            print("✅ State transitions test passed")

        # Ejecutar tests
        asyncio.run(test_create())
        print("✅ TrainingStateManager tests PASSED")

    finally:
        shutil.rmtree(temp_dir)


def test_checkpoint_manager():
    """Test básico de CheckpointManager."""
    print("🧪 Testing CheckpointManager...")

    temp_dir = tempfile.mkdtemp()

    try:
        config = CheckpointConfig(compression=CompressionType.NONE)
        manager = CheckpointManager(temp_dir, config)

        async def test_checkpoint():
            model = SimpleModel()
            optimizer = optim.SGD(model.parameters(), lr=0.01)

            # Guardar checkpoint
            checkpoint_id = await manager.save_checkpoint(
                session_id="test_session",
                model=model,
                optimizer=optimizer,
                epoch=1,
                batch=10,
                global_step=100,
                metrics={"loss": 0.5, "accuracy": 0.8}
            )

            assert checkpoint_id is not None
            print("✅ Save checkpoint test passed")

            # Cargar checkpoint
            data = await manager.load_checkpoint(checkpoint_id)
            assert data["epoch"] == 1
            assert data["metrics"]["loss"] == 0.5
            assert "model_state" in data
            print("✅ Load checkpoint test passed")

            # Listar checkpoints
            checkpoints = await manager.list_checkpoints("test_session")
            assert len(checkpoints) == 1
            print("✅ List checkpoints test passed")

            # Limpiar checkpoints
            deleted = await manager.cleanup_checkpoints("test_session", keep_last=0)
            assert deleted == 1

            checkpoints = await manager.list_checkpoints("test_session")
            assert len(checkpoints) == 0
            print("✅ Cleanup checkpoints test passed")

        asyncio.run(test_checkpoint())
        print("✅ CheckpointManager tests PASSED")

    finally:
        shutil.rmtree(temp_dir)


def test_progress_tracker():
    """Test básico de TrainingProgressTracker."""
    print("🧪 Testing TrainingProgressTracker...")

    async def test_tracker():
        tracker = TrainingProgressTracker()

        # Inicializar
        await tracker.initialize_session(
            session_id="test_session",
            total_epochs=10,
            batches_per_epoch=100
        )

        progress = await tracker.get_progress()
        assert progress.session_id == "test_session"
        assert progress.total_epochs == 10
        print("✅ Initialize session test passed")

        # Actualizar progreso
        await tracker.update_batch_progress(
            batch_idx=5,
            batch_time=0.1,
            loss=0.5,
            accuracy=0.8,
            learning_rate=0.001
        )

        progress = await tracker.get_progress()
        assert progress.current_batch == 5
        assert progress.loss == 0.5
        print("✅ Update batch progress test passed")

        # Actualizar época
        await tracker.update_epoch_progress(1, {"epoch_time": 10.0})

        progress = await tracker.get_progress()
        assert progress.current_epoch == 1
        print("✅ Update epoch progress test passed")

        # Reanudar desde checkpoint
        checkpoint_data = {
            "loss_history": [0.8, 0.6],
            "accuracy_history": [0.7, 0.8]
        }

        await tracker.resume_from_checkpoint(
            current_epoch=2,
            global_step=200,
            checkpoint_metrics=checkpoint_data
        )

        progress = await tracker.get_progress()
        assert progress.current_epoch == 2
        assert progress.loss_history == [0.8, 0.6]
        print("✅ Resume from checkpoint test passed")

    asyncio.run(test_tracker())
    print("✅ TrainingProgressTracker tests PASSED")


def test_integration():
    """Test de integración entre componentes."""
    print("🧪 Testing integration...")

    temp_dir = tempfile.mkdtemp()

    try:
        async def test_integration():
            # Crear componentes
            state_manager = TrainingStateManager(temp_dir)
            checkpoint_manager = CheckpointManager(temp_dir)

            # Crear sesión
            session = await state_manager.create_session(
                session_id="integration_test",
                model_version="v1.0",
                training_config={"max_epochs": 5},
                model_config={"type": "test"}
            )
            assert session.session_id == "integration_test"
            print("✅ Integration: Create session passed")

            # Crear checkpoint
            model = SimpleModel()
            optimizer = optim.SGD(model.parameters(), lr=0.01)

            checkpoint_id = await checkpoint_manager.save_checkpoint(
                session_id="integration_test",
                model=model,
                optimizer=optimizer,
                epoch=1,
                batch=10,
                global_step=100,
                metrics={"loss": 0.5}
            )
            print("✅ Integration: Save checkpoint passed")

            # Actualizar estado
            await state_manager.update_session_progress(
                session_id="integration_test",
                epoch=1,
                batch=10,
                loss=0.5,
                accuracy=0.8,
                learning_rate=0.01,
                optimizer_state={}
            )

            # Verificar estado
            updated_session = await state_manager.get_session("integration_test")
            assert updated_session.current_epoch == 1
            assert updated_session.loss_history == [0.5]
            print("✅ Integration: Update state passed")

            # Listar checkpoints
            checkpoints = await checkpoint_manager.list_checkpoints("integration_test")
            assert len(checkpoints) == 1
            print("✅ Integration: List checkpoints passed")

        asyncio.run(test_integration())
        print("✅ Integration tests PASSED")

    finally:
        shutil.rmtree(temp_dir)


def main():
    """Ejecutar todos los tests."""
    print("🚀 Ejecutando tests standalone para FASE 2: Entrenamiento Asíncrono")
    print("=" * 70)

    try:
        test_training_state_manager()
        print()

        test_checkpoint_manager()
        print()

        test_progress_tracker()
        print()

        test_integration()
        print()

        print("🎉 TODOS LOS TESTS PASARON EXITOSAMENTE!")
        print("=" * 70)

    except Exception as e:
        print(f"❌ ERROR en tests: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == "__main__":
    exit(main())