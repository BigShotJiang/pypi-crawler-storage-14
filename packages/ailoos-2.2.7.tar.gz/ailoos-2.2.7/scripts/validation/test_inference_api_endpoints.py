"""
Pruebas unitarias exhaustivas para endpoints de API de inferencia FASE 4.
Ejecuta pruebas HTTP contra la API FastAPI de EmpoorioLM.
"""

import asyncio
import json
import time
import sys
import os
import signal
import threading
from typing import Dict, List, Any, Optional
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Añadir el directorio raíz al path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Importaciones directas para evitar problemas de dependencias circulares
try:
    from src.ailoos.inference.api import InferenceConfig, EmpoorioLMInferenceAPI
except ImportError as e:
    print(f"Error importando módulos: {e}")
    print("Intentando importación directa...")
    # Importación directa del archivo
    import importlib.util
    spec = importlib.util.spec_from_file_location("api", "src/ailoos/inference/api.py")
    api_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(api_module)
    InferenceConfig = api_module.InferenceConfig
    EmpoorioLMInferenceAPI = api_module.EmpoorioLMInferenceAPI


class InferenceAPIEndpointTester:
    """
    Tester exhaustivo para endpoints de API de inferencia.
    """

    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url.rstrip('/')
        self.session = self._create_session()
        self.test_results = []
        self.server_process = None

    def _create_session(self) -> requests.Session:
        """Crear sesión HTTP con retry strategy."""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.3,
            status_forcelist=[500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def start_server(self) -> bool:
        """Iniciar servidor FastAPI en thread separado."""
        try:
            def run_server():
                try:
                    config = InferenceConfig(port=8001)
                    api = EmpoorioLMInferenceAPI(config)
                    api.start_server()
                except Exception as e:
                    print(f"Error iniciando servidor: {e}")

            self.server_thread = threading.Thread(target=run_server, daemon=True)
            self.server_thread.start()

            # Esperar que el servidor inicie
            time.sleep(5)

            # Verificar que el servidor esté corriendo
            try:
                response = self.session.get(f"{self.base_url}/health", timeout=10)
                return response.status_code == 200
            except:
                return False

        except Exception as e:
            print(f"Error iniciando servidor: {e}")
            return False

    def stop_server(self):
        """Detener servidor."""
        if self.server_thread and self.server_thread.is_alive():
            # Intentar graceful shutdown
            try:
                os.kill(os.getpid(), signal.SIGTERM)
            except:
                pass

    def run_test(self, test_name: str, test_func) -> Dict[str, Any]:
        """Ejecutar un test individual."""
        print(f"🧪 Ejecutando test: {test_name}")

        start_time = time.time()
        result = {
            'test_name': test_name,
            'status': 'pending',
            'duration': 0,
            'error': None,
            'details': {}
        }

        try:
            test_result = test_func()
            result.update(test_result)
            result['status'] = 'passed'
            print(f"✅ {test_name}: PASSED")

        except Exception as e:
            result['status'] = 'failed'
            result['error'] = str(e)
            print(f"❌ {test_name}: FAILED - {e}")

        result['duration'] = time.time() - start_time
        self.test_results.append(result)
        return result

    def test_health_endpoint(self) -> Dict[str, Any]:
        """Test endpoint /health."""
        response = self.session.get(f"{self.base_url}/health", timeout=10)

        assert response.status_code == 200, f"Status code: {response.status_code}"

        data = response.json()
        assert 'status' in data, "Missing status field"
        assert data['status'] in ['healthy', 'unhealthy'], f"Invalid status: {data['status']}"

        # Verificar campos de Maturity 2
        if 'maturity2' in data:
            maturity2 = data['maturity2']
            assert 'quantization' in maturity2, "Missing quantization info"
            assert 'drift_monitoring' in maturity2, "Missing drift monitoring info"
            assert 'vllm_batching' in maturity2, "Missing vLLM batching info"
            assert 'guidance_structured_output' in maturity2, "Missing guidance info"

        return {
            'details': {
                'status_code': response.status_code,
                'response_size': len(response.content),
                'has_maturity2': 'maturity2' in data
            }
        }

    def test_models_endpoint(self) -> Dict[str, Any]:
        """Test endpoint /models."""
        response = self.session.get(f"{self.base_url}/models", timeout=10)

        assert response.status_code == 200, f"Status code: {response.status_code}"

        data = response.json()
        assert 'models' in data, "Missing models field"
        assert isinstance(data['models'], list), "Models should be a list"
        assert len(data['models']) > 0, "Should have at least one model"

        # Verificar estructura del modelo
        model = data['models'][0]
        assert 'id' in model, "Model missing id field"
        assert 'object' in model, "Model missing object field"
        assert model['object'] == 'model', f"Invalid object type: {model['object']}"

        return {
            'details': {
                'status_code': response.status_code,
                'model_count': len(data['models']),
                'model_ids': [m['id'] for m in data['models']]
            }
        }

    def test_generate_endpoint_basic(self) -> Dict[str, Any]:
        """Test endpoint /generate con request básico."""
        payload = {
            "prompt": "Hola, ¿cómo estás?",
            "max_tokens": 50,
            "temperature": 0.7
        }

        response = self.session.post(
            f"{self.base_url}/generate",
            json=payload,
            timeout=30
        )

        assert response.status_code == 200, f"Status code: {response.status_code}"

        data = response.json()
        assert 'text' in data, "Missing text field"
        assert 'usage' in data, "Missing usage field"
        assert 'model_version' in data, "Missing model_version field"
        assert 'generated_at' in data, "Missing generated_at field"

        # Verificar uso
        usage = data['usage']
        assert 'prompt_tokens' in usage, "Missing prompt_tokens"
        assert 'completion_tokens' in usage, "Missing completion_tokens"
        assert 'total_tokens' in usage, "Missing total_tokens"
        assert usage['total_tokens'] == usage['prompt_tokens'] + usage['completion_tokens']

        return {
            'details': {
                'status_code': response.status_code,
                'response_length': len(data['text']),
                'prompt_tokens': usage['prompt_tokens'],
                'completion_tokens': usage['completion_tokens'],
                'total_tokens': usage['total_tokens']
            }
        }

    def test_generate_endpoint_streaming(self) -> Dict[str, Any]:
        """Test endpoint /generate con streaming."""
        payload = {
            "prompt": "Escribe un poema corto sobre la naturaleza",
            "max_tokens": 100,
            "temperature": 0.8,
            "stream": True
        }

        response = self.session.post(
            f"{self.base_url}/generate",
            json=payload,
            timeout=60,
            stream=True
        )

        assert response.status_code == 200, f"Status code: {response.status_code}"

        # Verificar que es streaming (Server-Sent Events)
        content_type = response.headers.get('content-type', '')
        assert 'text/plain' in content_type, f"Expected text/plain, got {content_type}"

        # Leer algunas líneas del stream
        lines = []
        for line in response.iter_lines():
            if line:
                lines.append(line.decode('utf-8'))
            if len(lines) >= 5:  # Leer solo primeras 5 líneas
                break

        assert len(lines) > 0, "No streaming data received"

        # Verificar formato SSE
        for line in lines:
            if line.startswith('data: '):
                try:
                    json_data = json.loads(line[6:])  # Remover 'data: '
                    assert 'token' in json_data or 'text_so_far' in json_data, f"Invalid SSE format: {json_data}"
                except json.JSONDecodeError:
                    # Puede ser una línea de control
                    pass

        return {
            'details': {
                'status_code': response.status_code,
                'content_type': content_type,
                'lines_received': len(lines),
                'is_sse_format': any('data: ' in line for line in lines)
            }
        }

    def test_generate_endpoint_structured_output(self) -> Dict[str, Any]:
        """Test endpoint /generate con salida estructurada."""
        payload = {
            "prompt": "Genera información sobre un producto de software",
            "max_tokens": 200,
            "temperature": 0.7,
            "structured_output": True,
            "output_format": "inference"
        }

        response = self.session.post(
            f"{self.base_url}/generate",
            json=payload,
            timeout=45
        )

        assert response.status_code == 200, f"Status code: {response.status_code}"

        data = response.json()
        assert 'text' in data, "Missing text field"

        # Verificar campos de salida estructurada
        assert 'structured_output' in data, "Missing structured_output field"
        assert 'guidance_used' in data, "Missing guidance_used field"

        return {
            'details': {
                'status_code': response.status_code,
                'structured_output': data.get('structured_output', False),
                'guidance_used': data.get('guidance_used', False),
                'has_schema_used': 'schema_used' in data,
                'validation_passed': data.get('validation_passed')
            }
        }

    def test_generate_endpoint_custom_schema(self) -> Dict[str, Any]:
        """Test endpoint /generate con esquema JSON personalizado."""
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "description": {"type": "string"},
                "version": {"type": "string"}
            },
            "required": ["name", "description"]
        }

        payload = {
            "prompt": "Describe un modelo de lenguaje",
            "max_tokens": 150,
            "temperature": 0.7,
            "structured_output": True,
            "schema": schema,
            "validation_enabled": True
        }

        response = self.session.post(
            f"{self.base_url}/generate",
            json=payload,
            timeout=45
        )

        assert response.status_code == 200, f"Status code: {response.status_code}"

        data = response.json()
        assert 'text' in data, "Missing text field"

        # Verificar que se usó el esquema personalizado
        assert 'schema_used' in data, "Missing schema_used field"
        if data.get('schema_used'):
            assert data['schema_used'] == schema, "Schema not used correctly"

        return {
            'details': {
                'status_code': response.status_code,
                'custom_schema_used': data.get('schema_used') is not None,
                'validation_passed': data.get('validation_passed')
            }
        }

    def test_quantize_endpoint(self) -> Dict[str, Any]:
        """Test endpoint /quantize."""
        payload = {
            "quantization_type": "int8",
            "output_path": "/tmp/test_quantized_model"
        }

        response = self.session.post(
            f"{self.base_url}/quantize",
            json=payload,
            timeout=120  # Cuantización puede ser lenta
        )

        # Puede fallar si cuantización no está habilitada o modelo no existe
        if response.status_code == 400:
            # Verificar que es por configuración, no por error del endpoint
            data = response.json()
            assert 'detail' in data, "Missing error detail"
            return {
                'details': {
                    'status_code': response.status_code,
                    'error_reason': data['detail'],
                    'quantization_disabled': 'no habilitada' in data['detail'].lower()
                }
            }

        assert response.status_code == 200, f"Status code: {response.status_code}"

        data = response.json()
        assert 'status' in data, "Missing status field"
        assert data['status'] == 'success', f"Quantization failed: {data}"

        return {
            'details': {
                'status_code': response.status_code,
                'quantization_success': True,
                'result_info': data.get('result', {})
            }
        }

    def test_drift_endpoints(self) -> Dict[str, Any]:
        """Test endpoints de monitoreo de deriva."""
        results = {}

        # Test /drift/status
        response = self.session.get(f"{self.base_url}/drift/status", timeout=10)
        if response.status_code == 200:
            data = response.json()
            results['status_endpoint'] = {
                'enabled': data.get('enabled', False),
                'alerts': data.get('alerts', 0)
            }
        else:
            results['status_endpoint'] = {'error': response.status_code}

        # Test /drift/check
        response = self.session.post(f"{self.base_url}/drift/check", timeout=30)
        if response.status_code == 200:
            data = response.json()
            results['check_endpoint'] = {
                'status': data.get('status'),
                'has_result': 'result' in data
            }
        elif response.status_code == 400:
            results['check_endpoint'] = {'disabled': True}
        else:
            results['check_endpoint'] = {'error': response.status_code}

        return {'details': results}

    def test_performance_endpoint(self) -> Dict[str, Any]:
        """Test endpoint /performance."""
        response = self.session.get(f"{self.base_url}/performance", timeout=10)

        assert response.status_code == 200, f"Status code: {response.status_code}"

        data = response.json()

        # Verificar métricas básicas
        required_metrics = ['total_requests', 'successful_requests', 'avg_response_time']
        for metric in required_metrics:
            assert metric in data, f"Missing metric: {metric}"

        # Verificar métricas de Maturity 2 si están presentes
        maturity2_metrics = ['quantization_memory_savings', 'drift_alerts', 'vllm_throughput', 'guidance_success_rate']
        maturity2_present = any(metric in data for metric in maturity2_metrics)

        return {
            'details': {
                'status_code': response.status_code,
                'metrics_count': len(data),
                'has_maturity2_metrics': maturity2_present,
                'total_requests': data.get('total_requests', 0)
            }
        }

    def test_attestation_endpoints(self) -> Dict[str, Any]:
        """Test endpoints de attestación TEE."""
        results = {}

        # Test /attestation/health
        response = self.session.get(f"{self.base_url}/attestation/health", timeout=10)
        if response.status_code == 200:
            data = response.json()
            results['health_endpoint'] = {
                'status': data.get('status'),
                'gcp_connectivity': data.get('gcp_connectivity'),
                'reference_measurements_count': data.get('reference_measurements_count', 0)
            }
        else:
            results['health_endpoint'] = {'error': response.status_code}

        # Test /attestation/reference-measurements
        response = self.session.get(f"{self.base_url}/attestation/reference-measurements", timeout=10)
        if response.status_code == 200:
            data = response.json()
            results['reference_measurements'] = {
                'has_measurements': 'reference_measurements' in data,
                'measurements_count': len(data.get('reference_measurements', {}))
            }
        else:
            results['reference_measurements'] = {'error': response.status_code}

        return {'details': results}

    def test_error_handling(self) -> Dict[str, Any]:
        """Test manejo de errores."""
        results = {}

        # Test con prompt vacío
        payload = {"prompt": ""}
        response = self.session.post(f"{self.base_url}/generate", json=payload, timeout=10)
        results['empty_prompt'] = {
            'status_code': response.status_code,
            'is_error': response.status_code >= 400
        }

        # Test con parámetros inválidos
        payload = {"prompt": "test", "temperature": 10.0}  # Temperature inválida
        response = self.session.post(f"{self.base_url}/generate", json=payload, timeout=10)
        results['invalid_temperature'] = {
            'status_code': response.status_code,
            'is_error': response.status_code >= 400
        }

        # Test endpoint inexistente
        response = self.session.get(f"{self.base_url}/nonexistent", timeout=10)
        results['nonexistent_endpoint'] = {
            'status_code': response.status_code,
            'is_404': response.status_code == 404
        }

        return {'details': results}

    def run_all_tests(self) -> Dict[str, Any]:
        """Ejecutar todas las pruebas de endpoints."""
        print("🚀 Iniciando pruebas exhaustivas de endpoints de API de inferencia...")

        # Lista de tests a ejecutar
        tests = [
            ("Health Endpoint", self.test_health_endpoint),
            ("Models Endpoint", self.test_models_endpoint),
            ("Generate Basic", self.test_generate_endpoint_basic),
            ("Generate Streaming", self.test_generate_endpoint_streaming),
            ("Generate Structured Output", self.test_generate_endpoint_structured_output),
            ("Generate Custom Schema", self.test_generate_endpoint_custom_schema),
            ("Quantize Endpoint", self.test_quantize_endpoint),
            ("Drift Endpoints", self.test_drift_endpoints),
            ("Performance Endpoint", self.test_performance_endpoint),
            ("Attestation Endpoints", self.test_attestation_endpoints),
            ("Error Handling", self.test_error_handling),
        ]

        # Ejecutar tests
        for test_name, test_func in tests:
            self.run_test(test_name, test_func)

        # Calcular estadísticas
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r['status'] == 'passed'])
        failed_tests = len([r for r in self.test_results if r['status'] == 'failed'])

        summary = {
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'failed_tests': failed_tests,
            'success_rate': passed_tests / total_tests if total_tests > 0 else 0,
            'total_duration': sum(r['duration'] for r in self.test_results),
            'test_results': self.test_results
        }

        print("\n📊 RESULTADOS FINALES:")
        print(f"   Total tests: {total_tests}")
        print(f"   Passed: {passed_tests}")
        print(f"   Failed: {failed_tests}")
        print(f"   Success rate: {success_rate:.1f}")
        return summary


async def run_inference_api_tests() -> Dict[str, Any]:
    """
    Ejecutar pruebas completas de API de inferencia.
    """
    tester = InferenceAPIEndpointTester()

    try:
        # Iniciar servidor
        print("🌐 Iniciando servidor de API de inferencia...")
        server_started = tester.start_server()

        if not server_started:
            return {
                'error': 'No se pudo iniciar el servidor de API',
                'details': 'Verificar configuración del modelo y dependencias'
            }

        print("✅ Servidor iniciado correctamente")

        # Ejecutar pruebas
        results = tester.run_all_tests()

        return results

    except Exception as e:
        return {
            'error': f'Error durante las pruebas: {str(e)}',
            'partial_results': getattr(tester, 'test_results', [])
        }

    finally:
        tester.stop_server()
        print("🛑 Servidor detenido")


if __name__ == "__main__":
    # Ejecutar pruebas
    results = asyncio.run(run_inference_api_tests())

    # Guardar resultados
    with open('inference_api_test_results.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False, default=str)

    # Imprimir resumen
    if 'error' in results:
        print(f"❌ Error: {results['error']}")
        sys.exit(1)
    else:
        success_rate = results.get('success_rate', 0)
        if success_rate >= 0.8:  # 80% de éxito mínimo
            print("🎉 Pruebas de API completadas exitosamente!")
            sys.exit(0)
        else:
            print(f"⚠️  Pruebas completadas con tasa de éxito baja: {success_rate:.1%}")
            sys.exit(1)