#!/usr/bin/env python3
"""
Script principal para ejecutar pruebas de carga federadas en AILOOS.
Simula miles de usuarios concurrentes consultando EmpoorioLM mientras
el entrenamiento federado está activo.
"""

import asyncio
import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Optional

# Añadir el directorio src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.federated.federated_load_tester import (
    FederatedLoadTester,
    LoadTestConfig,
    run_federated_load_test
)


def parse_arguments():
    """Parsear argumentos de línea de comandos."""
    parser = argparse.ArgumentParser(
        description="Ejecutar pruebas de carga federadas para AILOOS",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:

# Test básico con configuración por defecto
python run_federated_load_test.py

# Test con 1000 usuarios concurrentes por 5 minutos
python run_federated_load_test.py --users 1000 --duration 300

# Test con demoras de red deshabilitadas
python run_federated_load_test.py --no-network-delays

# Test personalizado con archivo de configuración
python run_federated_load_test.py --config my_config.json

# Test de estrés extremo
python run_federated_load_test.py --users 5000 --federated-nodes 100 --duration 600
        """
    )

    parser.add_argument(
        "--users", "-u",
        type=int,
        default=1000,
        help="Número de usuarios concurrentes (default: 1000)"
    )

    parser.add_argument(
        "--federated-nodes", "-f",
        type=int,
        default=50,
        help="Número de nodos federados (default: 50)"
    )

    parser.add_argument(
        "--duration", "-d",
        type=int,
        default=300,
        help="Duración del test en segundos (default: 300)"
    )

    parser.add_argument(
        "--inference-api",
        type=str,
        default="http://localhost:8000",
        help="URL de la API de inferencia (default: http://localhost:8000)"
    )

    parser.add_argument(
        "--no-network-delays",
        action="store_true",
        help="Deshabilitar simulación de demoras de red"
    )

    parser.add_argument(
        "--network-delay",
        type=float,
        default=50.0,
        help="Demora base de red en ms (default: 50.0)"
    )

    parser.add_argument(
        "--packet-loss",
        type=float,
        default=0.02,
        help="Tasa de pérdida de paquetes (default: 0.02)"
    )

    parser.add_argument(
        "--config",
        type=str,
        help="Archivo JSON con configuración personalizada"
    )

    parser.add_argument(
        "--output", "-o",
        type=str,
        default="federated_load_test_results.json",
        help="Archivo de salida para resultados (default: federated_load_test_results.json)"
    )

    parser.add_argument(
        "--log-level",
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help="Nivel de logging (default: INFO)"
    )

    parser.add_argument(
        "--no-sparsification",
        action="store_true",
        help="Deshabilitar sparsificación en federated learning"
    )

    parser.add_argument(
        "--ramp-up",
        type=float,
        default=30.0,
        help="Tiempo de ramp-up en segundos (default: 30.0)"
    )

    return parser.parse_args()


def load_config_from_file(filename: str) -> LoadTestConfig:
    """Cargar configuración desde archivo JSON."""
    try:
        with open(filename, 'r') as f:
            config_data = json.load(f)

        # Crear configuración desde datos
        config = LoadTestConfig()

        # Actualizar atributos desde el JSON
        for key, value in config_data.items():
            if hasattr(config, key):
                setattr(config, key, value)
            else:
                logging.warning(f"Ignorando configuración desconocida: {key}")

        logging.info(f"Configuración cargada desde {filename}")
        return config

    except Exception as e:
        logging.error(f"Error cargando configuración desde {filename}: {e}")
        sys.exit(1)


def create_config_from_args(args) -> LoadTestConfig:
    """Crear configuración desde argumentos de línea de comandos."""
    config = LoadTestConfig()

    # Configuración básica
    config.num_concurrent_users = args.users
    config.num_federated_nodes = args.federated_nodes
    config.test_duration_seconds = args.duration
    config.inference_api_url = args.inference_api
    config.user_ramp_up_time = args.ramp_up

    # Configuración de red
    config.network_delay_enabled = not args.no_network_delays
    config.base_network_delay_ms = args.network_delay
    config.packet_loss_rate = args.packet_loss

    # Configuración de federated learning
    config.sparsification_enabled = not args.no_sparsification

    return config


def validate_environment():
    """Validar que el entorno esté listo para las pruebas."""
    logging.info("🔍 Validando entorno de pruebas...")

    # Verificar que la API de inferencia esté disponible
    import aiohttp
    import asyncio

    async def check_api():
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("http://localhost:8000/health", timeout=5) as response:
                    if response.status == 200:
                        logging.info("✅ API de inferencia disponible")
                        return True
                    else:
                        logging.warning(f"⚠️ API de inferencia respondió con status {response.status}")
                        return False
        except Exception as e:
            logging.error(f"❌ API de inferencia no disponible: {e}")
            logging.error("Asegúrate de que la API de inferencia esté ejecutándose en http://localhost:8000")
            return False

    # Ejecutar verificación
    result = asyncio.run(check_api())
    if not result:
        logging.warning("Continuando con las pruebas, pero algunos componentes pueden fallar...")

    return result


def main():
    """Función principal."""
    args = parse_arguments()

    # Configurar logging
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    logging.info("🚀 Iniciando pruebas de carga federadas AILOOS")

    # Cargar configuración
    if args.config:
        config = load_config_from_file(args.config)
    else:
        config = create_config_from_args(args)

    # Mostrar configuración
    logging.info("📋 Configuración del test:")
    logging.info(f"   Usuarios concurrentes: {config.num_concurrent_users}")
    logging.info(f"   Nodos federados: {config.num_federated_nodes}")
    logging.info(f"   Duración: {config.test_duration_seconds}s")
    logging.info(f"   API de inferencia: {config.inference_api_url}")
    logging.info(f"   Demoras de red: {'habilitadas' if config.network_delay_enabled else 'deshabilitadas'}")
    logging.info(f"   Sparsificación: {'habilitada' if config.sparsification_enabled else 'deshabilitada'}")

    # Validar entorno
    validate_environment()

    try:
        # Ejecutar test
        logging.info("🎯 Ejecutando prueba de carga...")
        tester = FederatedLoadTester(config)
        results = asyncio.run(tester.run_test())

        # Guardar resultados
        tester.save_results(args.output)

        # Mostrar resumen
        tester.print_summary()

        # Verificar criterios de éxito
        inf_stats = results.get_inference_stats()
        success_rate = inf_stats.get('success_rate', 0) if inf_stats else 0

        if success_rate > 0.95:
            logging.info("✅ Test PASSED: Sistema estable bajo carga")
            sys.exit(0)
        else:
            logging.error("❌ Test FAILED: Sistema inestable bajo carga")
            sys.exit(1)

    except KeyboardInterrupt:
        logging.info("🛑 Test interrumpido por usuario")
        sys.exit(130)
    except Exception as e:
        logging.error(f"❌ Error durante el test: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()