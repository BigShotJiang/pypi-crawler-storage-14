#!/usr/bin/env python3
"""
Script para configurar y probar batching dinámico con vLLM.

Uso:
    python scripts/configure_vllm_batching.py --model_path ./models/empoorio_lm/v1.0.0 --test

Opciones:
    --model_path: Ruta del modelo
    --tensor_parallel_size: Paralelismo de tensores (default: 1)
    --max_batch_size: Tamaño máximo de batch (default: 32)
    --gpu_memory_utilization: Utilización de memoria GPU (default: 0.9)
    --test: Ejecutar pruebas de rendimiento
    --benchmark: Ejecutar benchmark comparativo
    --output_file: Archivo para guardar resultados
"""

import argparse
import sys
import time
import asyncio
import json
from pathlib import Path
from typing import List, Dict, Any

# Añadir src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    from ailoos.inference.vllm_batching import create_vllm_engine, BatchingConfig
    VLLM_AVAILABLE = True
except ImportError:
    VLLM_AVAILABLE = False


class BatchingBenchmark:
    """Clase para ejecutar benchmarks de batching."""

    def __init__(self, engine):
        self.engine = engine
        self.test_prompts = [
            "¿Cuál es la capital de España?",
            "Explica brevemente qué es la inteligencia artificial",
            "Escribe un haiku sobre el mar",
            "¿Cómo funciona la fotosíntesis?",
            "Traduce 'Hello world' al español",
            "¿Qué es el aprendizaje automático?",
            "Describe los planetas del sistema solar",
            "Escribe una receta simple de pasta",
            "¿Cuál es la diferencia entre IA y machine learning?",
            "Explica el concepto de blockchain",
            "¿Qué es el cambio climático?",
            "Describe cómo funciona un motor de combustión",
            "¿Cuáles son los beneficios del ejercicio físico?",
            "Explica la teoría de la evolución",
            "Escribe un cuento corto sobre un robot"
        ]

    async def run_benchmark(self, num_requests: int = 50, concurrent: int = 10) -> Dict[str, Any]:
        """Ejecutar benchmark de rendimiento."""
        print(f"🏃 Ejecutando benchmark: {num_requests} requests, {concurrent} concurrentes")

        start_time = time.time()
        tasks = []
        results = []

        # Crear tareas
        semaphore = asyncio.Semaphore(concurrent)

        async def generate_with_semaphore(prompt: str):
            async with semaphore:
                start = time.time()
                response_text = ""
                async for chunk in self.engine.generate(prompt, max_tokens=50):
                    response_text = chunk
                end = time.time()
                return {
                    "prompt": prompt,
                    "response_length": len(response_text),
                    "latency": end - start
                }

        # Ejecutar requests
        for i in range(num_requests):
            prompt = self.test_prompts[i % len(self.test_prompts)]
            task = generate_with_semaphore(prompt)
            tasks.append(task)

        # Esperar completación
        completed_results = await asyncio.gather(*tasks, return_exceptions=True)

        total_time = time.time() - start_time

        # Procesar resultados
        successful_requests = 0
        total_latency = 0
        total_tokens = 0

        for result in completed_results:
            if isinstance(result, Exception):
                print(f"❌ Error en request: {result}")
            else:
                successful_requests += 1
                total_latency += result["latency"]
                total_tokens += result["response_length"]

        # Calcular métricas
        throughput = successful_requests / total_time if total_time > 0 else 0
        avg_latency = total_latency / successful_requests if successful_requests > 0 else 0
        token_throughput = total_tokens / total_time if total_time > 0 else 0

        return {
            "total_requests": num_requests,
            "successful_requests": successful_requests,
            "total_time": total_time,
            "throughput_requests_per_sec": throughput,
            "avg_latency": avg_latency,
            "token_throughput_per_sec": token_throughput,
            "concurrent_requests": concurrent
        }


async def main():
    parser = argparse.ArgumentParser(description="Configurar batching dinámico con vLLM")
    parser.add_argument("--model_path", required=True, help="Ruta del modelo")
    parser.add_argument("--tensor_parallel_size", type=int, default=1,
                       help="Paralelismo de tensores")
    parser.add_argument("--max_batch_size", type=int, default=32,
                       help="Tamaño máximo de batch")
    parser.add_argument("--gpu_memory_utilization", type=float, default=0.9,
                       help="Utilización de memoria GPU")
    parser.add_argument("--test", action="store_true",
                       help="Ejecutar pruebas básicas")
    parser.add_argument("--benchmark", action="store_true",
                       help="Ejecutar benchmark de rendimiento")
    parser.add_argument("--num_requests", type=int, default=50,
                       help="Número de requests para benchmark")
    parser.add_argument("--concurrent", type=int, default=10,
                       help="Requests concurrentes para benchmark")
    parser.add_argument("--output_file", help="Archivo para guardar resultados")

    args = parser.parse_args()

    if not VLLM_AVAILABLE:
        print("❌ vLLM no está disponible. Instalar con: pip install vllm")
        sys.exit(1)

    print("🚀 Configuración de Batching Dinámico con vLLM")
    print(f"   Modelo: {args.model_path}")
    print(f"   Tensor parallel: {args.tensor_parallel_size}")
    print(f"   Max batch size: {args.max_batch_size}")
    print(f"   GPU memory: {args.gpu_memory_utilization}")

    try:
        # Crear configuración
        config = BatchingConfig(
            model_path=args.model_path,
            tensor_parallel_size=args.tensor_parallel_size,
            gpu_memory_utilization=args.gpu_memory_utilization,
            max_batch_size=args.max_batch_size,
            dynamic_batching=True
        )

        print("\n🔧 Creando engine vLLM...")
        engine = create_vllm_engine(
            model_path=args.model_path,
            tensor_parallel_size=args.tensor_parallel_size,
            max_batch_size=args.max_batch_size
        )

        # Inicializar
        print("📥 Inicializando engine...")
        success = await engine.initialize()

        if not success:
            print("❌ Error inicializando vLLM engine")
            sys.exit(1)

        print("✅ Engine inicializado exitosamente")

        results = {}

        # Pruebas básicas
        if args.test:
            print("\n🧪 Ejecutando pruebas básicas...")

            test_prompt = "¿Cuál es la capital de España?"
            print(f"   Prompt de prueba: {test_prompt}")

            start_time = time.time()
            response_text = ""
            async for chunk in engine.generate(test_prompt, max_tokens=50):
                response_text = chunk

            latency = time.time() - start_time

            print("   ✅ Generación exitosa")
            print(f"   📏 Longitud respuesta: {len(response_text)} caracteres")
            print(f"   ⏱️ Latencia: {latency:.3f}s")
            print(f"   🤖 Respuesta: {response_text[:100]}...")

            results["basic_test"] = {
                "prompt": test_prompt,
                "response_length": len(response_text),
                "latency": latency,
                "success": True
            }

        # Benchmark
        if args.benchmark:
            print(f"\n🏃 Ejecutando benchmark ({args.num_requests} requests, {args.concurrent} concurrentes)...")

            benchmark = BatchingBenchmark(engine)
            benchmark_results = await benchmark.run_benchmark(
                num_requests=args.num_requests,
                concurrent=args.concurrent
            )

            print("📊 Resultados del benchmark:")
            print(f"   Requests exitosos: {benchmark_results['successful_requests']}/{benchmark_results['total_requests']}")
            print(f"   Throughput: {benchmark_results['throughput_requests_per_sec']:.2f} req/seg")
            print(f"   Latencia promedio: {benchmark_results['avg_latency']:.3f}s")
            print(f"   Throughput tokens: {benchmark_results['token_throughput_per_sec']:.1f} tokens/seg")
            print(f"   Tiempo total: {benchmark_results['total_time']:.2f}s")

            results["benchmark"] = benchmark_results

        # Obtener métricas de rendimiento
        performance_metrics = engine.get_performance_metrics()
        results["performance_metrics"] = performance_metrics

        print("\n📈 Métricas de rendimiento:")
        batcher_metrics = performance_metrics["batcher_metrics"]
        print(f"   Throughput: {batcher_metrics['throughput_tokens_per_sec']:.1f} tokens/seg")
        print(f"   Batch size promedio: {batcher_metrics['avg_batch_size']:.1f}")
        print(f"   Latencia promedio: {batcher_metrics['avg_latency']:.3f}s")

        # Guardar resultados si se especifica
        if args.output_file:
            print(f"\n💾 Guardando resultados en: {args.output_file}")
            with open(args.output_file, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)

        # Limpiar
        await engine.shutdown()

        print("\n✅ Configuración completada exitosamente")

    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())