#!/usr/bin/env python3
"""
SCRIPT DE TEST: Conexión Frontend-Backend EmpoorioLM
Prueba que el chat del frontend se conecta correctamente al backend de EmpoorioLM.
"""

import asyncio
import requests
import json
import time
from typing import Dict, Any

class FrontendBackendConnectionTest:
    """Test completo de la conexión frontend-backend."""

    def __init__(self):
        self.frontend_url = "http://localhost:3000"
        self.api_url = f"{self.frontend_url}/api/chat"
        self.results = []

    async def run_full_test(self):
        """Ejecuta test completo de conexión."""
        print("🔗 TEST DE CONEXIÓN FRONTEND-BACKEND EMPOORIOLM")
        print("=" * 60)

        # 1. Verificar que el frontend está corriendo
        await self.test_frontend_health()

        # 2. Verificar que el API route responde
        await self.test_api_route()

        # 3. Verificar que el chat envía modelo correcto
        await self.test_model_specification()

        # 4. Verificar respuestas de EmpoorioLM
        await self.test_empoorio_responses()

        # 5. Generar reporte
        self.generate_report()

    async def test_frontend_health(self):
        """Verifica que el frontend esté saludable."""
        print("\n1️⃣ VERIFICANDO SALUD DEL FRONTEND")
        try:
            response = requests.get(self.frontend_url, timeout=5)
            if response.status_code == 200:
                self.results.append("✅ Frontend corriendo en localhost:3000")
                print("✅ Frontend corriendo correctamente")
            else:
                self.results.append(f"❌ Frontend responde con status {response.status_code}")
                print(f"❌ Frontend responde con status {response.status_code}")
        except Exception as e:
            self.results.append(f"❌ Frontend no disponible: {e}")
            print(f"❌ Frontend no disponible: {e}")

    async def test_api_route(self):
        """Verifica que el API route funciona."""
        print("\n2️⃣ VERIFICANDO API ROUTE /api/chat")
        try:
            payload = {
                "message": "Test message",
                "model": "ailoos/empoorio-lm",
                "id": "test_connection"
            }
            response = requests.post(self.api_url, json=payload, timeout=10)

            if response.status_code == 200:
                data = response.json()
                self.results.append("✅ API route /api/chat responde correctamente")
                print("✅ API route responde correctamente")
                print(f"   Respuesta: {data.get('content', '')[:50]}...")
            else:
                self.results.append(f"❌ API route falla con status {response.status_code}")
                print(f"❌ API route falla con status {response.status_code}")

        except Exception as e:
            self.results.append(f"❌ Error conectando al API: {e}")
            print(f"❌ Error conectando al API: {e}")

    async def test_model_specification(self):
        """Verifica que el modelo se especifica correctamente."""
        print("\n3️⃣ VERIFICANDO ESPECIFICACIÓN DEL MODELO")
        try:
            # Verificar que el chat-sync.tsx incluye el modelo
            chat_sync_path = "frontend/components/chat-sync.tsx"
            with open(chat_sync_path, 'r') as f:
                content = f.read()
                if 'model: "ailoos/empoorio-lm"' in content:
                    self.results.append("✅ Chat system especifica modelo 'ailoos/empoorio-lm'")
                    print("✅ Chat system especifica modelo 'ailoos/empoorio-lm'")
                else:
                    self.results.append("❌ Chat system NO especifica modelo EmpoorioLM")
                    print("❌ Chat system NO especifica modelo EmpoorioLM")

        except Exception as e:
            self.results.append(f"❌ Error verificando configuración del modelo: {e}")
            print(f"❌ Error verificando configuración del modelo: {e}")

    async def test_empoorio_responses(self):
        """Verifica que las respuestas son de EmpoorioLM."""
        print("\n4️⃣ VERIFICANDO RESPUESTAS DE EMPOORIOLM")
        try:
            test_messages = [
                "Hola, ¿quién eres?",
                "Explícame qué es IA",
                "Háblame de machine learning"
            ]

            for msg in test_messages:
                payload = {
                    "message": msg,
                    "model": "ailoos/empoorio-lm",
                    "id": f"test_{int(time.time())}"
                }

                response = requests.post(self.api_url, json=payload, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    content = data.get('content', '')

                    # Verificar que menciona EmpoorioLM o IA
                    if any(keyword in content.lower() for keyword in ['empoorio', 'ia', 'inteligencia', 'asistente']):
                        print(f"✅ Respuesta coherente para: '{msg[:30]}...'")
                    else:
                        print(f"⚠️  Respuesta genérica para: '{msg[:30]}...'")
                else:
                    print(f"❌ Error en respuesta para: '{msg[:30]}...'")

            self.results.append("✅ Test de respuestas de EmpoorioLM completado")

        except Exception as e:
            self.results.append(f"❌ Error probando respuestas: {e}")
            print(f"❌ Error probando respuestas: {e}")

    def generate_report(self):
        """Genera reporte final."""
        print("\n" + "=" * 60)
        print("📋 REPORTE DE CONEXIÓN FRONTEND-BACKEND")
        print("=" * 60)

        print("\n🔍 RESULTADOS:")
        for result in self.results:
            print(f"   {result}")

        # Evaluar estado general
        success_count = sum(1 for r in self.results if r.startswith("✅"))
        total_count = len(self.results)

        print("\n🎯 EVALUACIÓN GENERAL:")
        if success_count == total_count:
            print("✅ CONEXIÓN FRONTEND-BACKEND FUNCIONANDO PERFECTAMENTE")
            print("🎉 El chat de EmpoorioLM está listo para usar!")
        elif success_count >= total_count * 0.7:
            print("⚠️  CONEXIÓN FUNCIONAL PERO CON ALGUNOS PROBLEMAS")
            print("💡 Revisar los errores reportados arriba")
        else:
            print("❌ CONEXIÓN CON PROBLEMAS SIGNIFICATIVOS")
            print("🔧 Necesario revisar configuración")

        print("\n📝 RESUMEN:")
        print(f"   Tests exitosos: {success_count}/{total_count}")
        print("   Frontend URL: http://localhost:3000")
        print("   API Endpoint: http://localhost:3000/api/chat")
        print("   Modelo: ailoos/empoorio-lm")


async def main():
    """Función principal del test."""
    tester = FrontendBackendConnectionTest()
    await tester.run_full_test()


if __name__ == "__main__":
    asyncio.run(main())