#!/usr/bin/env python3
"""
Script to run comprehensive load and stress tests for CAG system.

This script executes all load and stress tests for the Cache Augmented RAG system
and generates detailed reports on performance, stability, and resource usage.
"""

import sys
import os
import json
import time
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from ailoos.rag.cache_augmented.test_load_stress import LoadStressTestRunner


def main():
    """Main entry point for running CAG load and stress tests."""
    print("🚀 Starting CAG Load and Stress Testing Suite")
    print("=" * 60)

    # Initialize test runner
    runner = LoadStressTestRunner()

    # Run all tests
    print("📊 Running comprehensive test suite...")
    start_time = time.time()

    try:
        results = runner.run_all_tests()
        end_time = time.time()

        # Print summary
        runner.print_summary()

        # Add execution time to results
        results['execution_time'] = end_time - start_time

        # Save detailed results
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        results_file = f"cag_load_stress_results_{timestamp}.json"
        runner.save_results(results_file)

        print("\n📈 Test Results Summary:")
        print(f"   Total Execution Time: {results['execution_time']:.2f} seconds")
        print(f"   Results saved to: {results_file}")

        # Check for failures
        total_failures = sum(
            suite_results['failures'] + suite_results['errors']
            for suite_results in results.values()
            if isinstance(suite_results, dict) and 'failures' in suite_results
        )

        if total_failures > 0:
            print(f"\n❌ Tests completed with {total_failures} failures/errors")
            return 1
        else:
            print("\n✅ All tests passed successfully!")
            return 0

    except Exception as e:
        print(f"\n💥 Error during test execution: {e}")
        return 1


if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)