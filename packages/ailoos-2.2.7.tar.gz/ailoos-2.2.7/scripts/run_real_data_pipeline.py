#!/usr/bin/env python3
"""
Script para ejecutar el pipeline completo de datos reales - FASE REAL-5
Ejecuta todo el flujo: carga → preprocessing → sharding → DataLoader
"""

import os
import sys
import logging
import argparse
from pathlib import Path

# Añadir src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.training import (
    run_real_data_pipeline,
    create_real_training_pipeline,
    RealDataTrainingPipeline,
    RealTrainingPipelineConfig
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(
        description="Ejecutar pipeline completo de datos reales para EmpoorioLM"
    )

    parser.add_argument(
        "--datasets",
        nargs="+",
        default=["wikitext", "openwebtext"],
        help="Datasets a cargar (default: wikitext openwebtext)"
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        default="./real_training_data",
        help="Directorio de salida para artifacts"
    )

    parser.add_argument(
        "--num-shards",
        type=int,
        default=10,
        help="Número de shards para entrenamiento federado"
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=8,
        help="Tamaño del batch para DataLoader"
    )

    parser.add_argument(
        "--max-length",
        type=int,
        default=512,
        help="Longitud máxima de secuencia"
    )

    parser.add_argument(
        "--max-samples",
        type=int,
        default=None,
        help="Máximo número de muestras por dataset (None = todas)"
    )

    parser.add_argument(
        "--cache-dir",
        type=str,
        default="./data_cache",
        help="Directorio de cache para datasets"
    )

    parser.add_argument(
        "--tokenizer-path",
        type=str,
        default=None,
        help="Ruta al tokenizer AILOOS entrenado"
    )

    parser.add_argument(
        "--no-quality-validation",
        action="store_true",
        help="Deshabilitar validación de calidad"
    )

    parser.add_argument(
        "--distributed",
        action="store_true",
        help="Habilitar modo distribuido"
    )

    parser.add_argument(
        "--world-size",
        type=int,
        default=1,
        help="Tamaño del mundo distribuido"
    )

    parser.add_argument(
        "--rank",
        type=int,
        default=0,
        help="Rank del proceso actual"
    )

    args = parser.parse_args()

    # Configurar pipeline
    config = RealTrainingPipelineConfig(
        datasets=args.datasets,
        cache_dir=args.cache_dir,
        max_samples_per_dataset=args.max_samples,
        max_length=args.max_length,
        tokenizer_path=args.tokenizer_path,
        clean_text=True,
        num_shards=args.num_shards,
        shard_dir=str(Path(args.output_dir) / "federated_shards"),
        validation_split=0.1,
        test_split=0.05,
        batch_size=args.batch_size,
        num_workers=4,
        distributed=args.distributed,
        world_size=args.world_size,
        rank=args.rank,
        enable_quality_validation=not args.no_quality_validation,
        quality_sample_size=10000,
        output_dir=args.output_dir,
        save_intermediates=True
    )

    # Crear y ejecutar pipeline
    pipeline = RealDataTrainingPipeline(config)

    logger.info("🚀 Iniciando pipeline de datos reales...")
    logger.info(f"   Datasets: {args.datasets}")
    logger.info(f"   Output dir: {args.output_dir}")
    logger.info(f"   Num shards: {args.num_shards}")
    logger.info(f"   Batch size: {args.batch_size}")

    results = pipeline.run_full_pipeline()

    # Mostrar resultados
    if results["success"]:
        logger.info("✅ Pipeline completado exitosamente!")

        # Estadísticas
        stats = results.get("statistics", {})
        if "final_dataset_size" in stats:
            logger.info(f"   📊 Dataset final: {stats['final_dataset_size']} muestras")

        if "sharding" in stats:
            shard_stats = stats["sharding"]
            logger.info(f"   🔀 Shards: {shard_stats['num_shards']} ({shard_stats['avg_shard_size']:.0f} muestras promedio)")

        if "dataloader" in stats:
            loader_stats = stats["dataloader"]
            logger.info(f"   ⚡ DataLoader: {loader_stats['num_batches']} batches")

        # Artifacts
        artifacts = results.get("artifacts", {})
        logger.info(f"   📁 Artifacts generados: {len(artifacts)}")
        for name, path in artifacts.items():
            logger.info(f"      - {name}: {path}")

        # Reporte
        report_path = Path(args.output_dir) / "pipeline_report.json"
        logger.info(f"   📋 Reporte completo: {report_path}")

        return 0

    else:
        logger.error("❌ Pipeline falló")
        error = results.get("error", "Error desconocido")
        logger.error(f"   Error: {error}")
        return 1


def demo_quick_start():
    """Demo de uso rápido del pipeline."""
    print("🎯 Demo: Pipeline de datos reales para EmpoorioLM")
    print("=" * 60)

    # Configuración simple
    results = run_real_data_pipeline(
        datasets=["wikitext"],  # Solo WikiText para demo rápido
        output_dir="./demo_real_data",
        num_shards=3,
        max_samples=1000  # Limitar para demo
    )

    if results["success"]:
        print("\n✅ Demo completado exitosamente!")
        print("Los datos están listos para entrenamiento federado.")
        print(f"Revisa los resultados en: ./demo_real_data")
    else:
        print("\n❌ Demo falló")
        print(f"Error: {results.get('error', 'Desconocido')}")


if __name__ == "__main__":
    if len(sys.argv) == 1:
        # Si no hay argumentos, ejecutar demo
        demo_quick_start()
    else:
        # Ejecutar con argumentos de línea de comandos
        exit(main())