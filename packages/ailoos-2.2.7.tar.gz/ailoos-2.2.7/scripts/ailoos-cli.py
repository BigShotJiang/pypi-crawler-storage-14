#!/usr/bin/env python3
"""
AILOOS CLI - Script de entrada
"""

import sys
import os

# Añadir src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.cli.new_cli import cli

if __name__ == "__main__":
    cli()