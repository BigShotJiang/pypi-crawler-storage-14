#!/usr/bin/env python3
"""
SCRIPT DE TEST E2E: Probar el chat completo desde el navegador
Abre el navegador, va al chat y envía un mensaje para verificar que funciona.
"""

import time
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

def test_chat_e2e():
    """Test end-to-end del chat system."""
    print("🧪 E2E TEST - CHAT SYSTEM WITH EMPOORIOLM")
    print("=" * 50)

    # Configurar Selenium
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ejecutar en background
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    try:
        driver = webdriver.Chrome(options=chrome_options)
        print("✅ Chrome driver inicializado")

        # Ir al chat
        chat_url = "http://localhost:3000/chat"
        print(f"🌐 Navegando a {chat_url}")
        driver.get(chat_url)

        # Esperar que cargue
        wait = WebDriverWait(driver, 10)
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        print("✅ Página cargada")

        # Verificar que estamos en la página correcta
        current_url = driver.current_url
        if "chat" in current_url:
            print("✅ En página de chat")
        else:
            print(f"⚠️  URL actual: {current_url}")

        # Buscar el input de chat
        try:
            # Intentar diferentes selectores para el input
            input_selectors = [
                "textarea[placeholder*='message']",
                "textarea",
                "[data-testid='chat-input']",
                ".chat-input textarea",
                "textarea:first-of-type"
            ]

            chat_input = None
            for selector in input_selectors:
                try:
                    chat_input = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                    print(f"✅ Input encontrado con selector: {selector}")
                    break
                except:
                    continue

            if not chat_input:
                print("❌ No se pudo encontrar el input de chat")
                return False

            # Escribir mensaje de prueba
            test_message = "Hola EmpoorioLM, ¿puedes confirmar que estás funcionando?"
            chat_input.clear()
            chat_input.send_keys(test_message)
            print(f"✅ Mensaje escrito: {test_message}")

            # Buscar botón de enviar
            send_selectors = [
                "button[type='submit']",
                "[data-testid='send-button']",
                "button:has(svg)",  # Botón con icono
                ".send-button"
            ]

            send_button = None
            for selector in send_selectors:
                try:
                    send_button = driver.find_element(By.CSS_SELECTOR, selector)
                    print(f"✅ Botón enviar encontrado con selector: {selector}")
                    break
                except:
                    continue

            if send_button:
                send_button.click()
                print("✅ Mensaje enviado")
            else:
                # Intentar con Enter
                chat_input.send_keys("\n")
                print("✅ Mensaje enviado con Enter")

            # Esperar respuesta
            time.sleep(3)

            # Buscar respuesta en el chat
            messages = driver.find_elements(By.CSS_SELECTOR, "[data-message-id]")
            if messages:
                last_message = messages[-1]
                message_text = last_message.text
                print(f"📨 Respuesta recibida: {message_text[:100]}...")

                if "EmpoorioLM" in message_text or "Hola" in message_text:
                    print("✅ CHAT FUNCIONANDO - EmpoorioLM responde correctamente")
                    return True
                else:
                    print("⚠️  Respuesta recibida pero no parece de EmpoorioLM")
                    return False
            else:
                print("❌ No se encontraron mensajes en el chat")
                return False

        except Exception as e:
            print(f"❌ Error durante el test: {e}")
            return False

    except Exception as e:
        print(f"❌ Error inicializando Chrome: {e}")
        print("💡 Asegúrate de tener Chrome y ChromeDriver instalados")
        return False

    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    success = test_chat_e2e()
    if success:
        print("\n🎉 TEST E2E PASSED - Chat con EmpoorioLM funcionando")
        exit(0)
    else:
        print("\n❌ TEST E2E FAILED - Chat no funciona correctamente")
        exit(1)