#!/usr/bin/env python3
"""
SCRIPT DE DIAGNÓSTICO: Problema de conexión backend del chat con EmpoorioLM
Investiga por qué el chat interface no funciona cuando se intenta escribir a EmpoorioLM.
"""

import asyncio
import requests
import time
import json
from typing import Dict, Any
import sys
import os

# Añadir src al path para importar módulos de AILOOS
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

class ChatBackendDiagnostic:
    """Diagnóstico completo del sistema de chat backend."""

    def __init__(self):
        self.results = {}
        self.errors = []

    async def run_full_diagnostic(self):
        """Ejecuta diagnóstico completo del sistema de chat."""
        print("🔍 DIAGNÓSTICO COMPLETO - CHAT BACKEND EMPOORIOLM")
        print("=" * 60)

        # 1. Verificar configuración del frontend
        await self.check_frontend_config()

        # 2. Verificar API routes del frontend
        await self.check_frontend_api_routes()

        # 3. Verificar cliente EmpoorioLM
        await self.check_empoorio_client()

        # 4. Verificar backend endpoints
        await self.check_backend_endpoints()

        # 5. Verificar integración con ai-sdk
        await self.check_ai_sdk_integration()

        # 6. Generar reporte final
        self.generate_report()

    async def check_frontend_config(self):
        """Verifica la configuración del frontend."""
        print("\n1️⃣ VERIFICANDO CONFIGURACIÓN FRONTEND")
        print("-" * 40)

        try:
            # Verificar si existe el modelo EmpoorioLM en la configuración
            frontend_lib_path = os.path.join(os.path.dirname(__file__), '..', 'frontend', 'lib', 'ai', 'app-models.ts')
            if os.path.exists(frontend_lib_path):
                with open(frontend_lib_path, 'r') as f:
                    content = f.read()
                    if 'ailoos/empoorio-lm' in content:
                        self.results['frontend_model_config'] = "✅ Modelo 'ailoos/empoorio-lm' encontrado en configuración"
                        print("✅ Modelo 'ailoos/empoorio-lm' encontrado en configuración")
                    else:
                        self.results['frontend_model_config'] = "❌ Modelo 'ailoos/empoorio-lm' NO encontrado en configuración"
                        print("❌ Modelo 'ailoos/empoorio-lm' NO encontrado en configuración")
            else:
                self.results['frontend_model_config'] = "❌ Archivo de configuración de modelos no encontrado"
                print("❌ Archivo de configuración de modelos no encontrado")

        except Exception as e:
            self.errors.append(f"Error verificando configuración frontend: {e}")
            print(f"❌ Error: {e}")

    async def check_frontend_api_routes(self):
        """Verifica las rutas API del frontend."""
        print("\n2️⃣ VERIFICANDO API ROUTES DEL FRONTEND")
        print("-" * 40)

        try:
            # Verificar si existe el endpoint /api/chat
            api_route_path = os.path.join(os.path.dirname(__file__), '..', 'frontend', 'app', 'api', 'chat', 'route.ts')
            if os.path.exists(api_route_path):
                with open(api_route_path, 'r') as f:
                    content = f.read()
                    if 'empoorioClient.generateText' in content:
                        self.results['frontend_api_route'] = "✅ API route /api/chat existe y usa empoorioClient"
                        print("✅ API route /api/chat existe y usa empoorioClient")
                    else:
                        self.results['frontend_api_route'] = "❌ API route /api/chat no usa empoorioClient"
                        print("❌ API route /api/chat no usa empoorioClient")
            else:
                self.results['frontend_api_route'] = "❌ API route /api/chat NO existe"
                print("❌ API route /api/chat NO existe")

        except Exception as e:
            self.errors.append(f"Error verificando API routes: {e}")
            print(f"❌ Error: {e}")

    async def check_empoorio_client(self):
        """Verifica el cliente EmpoorioLM."""
        print("\n3️⃣ VERIFICANDO CLIENTE EMPOORIOLM")
        print("-" * 40)

        try:
            # Verificar configuración del cliente
            client_path = os.path.join(os.path.dirname(__file__), '..', 'frontend', 'lib', 'ai', 'empoorio-client.ts')
            if os.path.exists(client_path):
                with open(client_path, 'r') as f:
                    content = f.read()

                    # Extraer URL base
                    if 'baseUrl:' in content:
                        lines = content.split('\n')
                        for line in lines:
                            if 'baseUrl:' in line and 'process.env.NEXT_PUBLIC_EMPOORIO_API_URL' in line:
                                self.results['empoorio_client_url'] = "✅ Cliente configurado para usar variable de entorno NEXT_PUBLIC_EMPOORIO_API_URL"
                                print("✅ Cliente configurado para usar variable de entorno NEXT_PUBLIC_EMPOORIO_API_URL")
                                break
                        else:
                            self.results['empoorio_client_url'] = "❌ Cliente NO usa variable de entorno para URL base"
                            print("❌ Cliente NO usa variable de entorno para URL base")

                    # Verificar endpoints
                    if '/api/v1/empoorio-lm/generate' in content:
                        self.results['empoorio_endpoints'] = "✅ Cliente usa endpoint correcto /api/v1/empoorio-lm/generate"
                        print("✅ Cliente usa endpoint correcto /api/v1/empoorio-lm/generate")
                    else:
                        self.results['empoorio_endpoints'] = "❌ Cliente NO usa endpoint correcto"
                        print("❌ Cliente NO usa endpoint correcto")
            else:
                self.results['empoorio_client'] = "❌ Archivo del cliente EmpoorioLM no encontrado"
                print("❌ Archivo del cliente EmpoorioLM no encontrado")

        except Exception as e:
            self.errors.append(f"Error verificando cliente EmpoorioLM: {e}")
            print(f"❌ Error: {e}")

    async def check_backend_endpoints(self):
        """Verifica los endpoints del backend."""
        print("\n4️⃣ VERIFICANDO ENDPOINTS DEL BACKEND")
        print("-" * 40)

        # URLs a verificar
        urls_to_check = [
            "https://api.ailoos.com/empoorio-lm/api/v1/empoorio-lm/health",
            "https://api.ailoos.com/empoorio-lm/api/v1/empoorio-lm/generate",
            "https://api.ailoos.com/empoorio-lm/api/v1/empoorio-lm/models",
            "http://localhost:8000/api/v1/empoorio-lm/health",  # Backend local si existe
            "http://localhost:3001/api/v1/empoorio-lm/health",  # Otro puerto posible
        ]

        backend_found = False

        for url in urls_to_check:
            try:
                print(f"🔍 Probando {url}...")
                start_time = time.time()
                response = requests.get(url, timeout=5)
                latency = time.time() - start_time

                if response.status_code == 200:
                    self.results[f'backend_endpoint_{url}'] = f"✅ Endpoint responde OK (latencia: {latency:.2f}s)"
                    print(f"✅ Endpoint responde OK (latencia: {latency:.2f}s)")
                    backend_found = True
                    break
                else:
                    print(f"⚠️  Endpoint responde con status {response.status_code}")

            except requests.exceptions.RequestException as e:
                print(f"❌ Endpoint no disponible: {e}")
                continue

        if not backend_found:
            self.results['backend_status'] = "❌ NINGÚN BACKEND DE EMPOORIOLM DISPONIBLE"
            print("❌ NINGÚN BACKEND DE EMPOORIOLM DISPONIBLE")
            print("💡 El chat usará respuestas mock hasta que se conecte un backend real")

    async def check_ai_sdk_integration(self):
        """Verifica la integración con ai-sdk."""
        print("\n5️⃣ VERIFICANDO INTEGRACIÓN CON AI-SDK")
        print("-" * 40)

        try:
            # Verificar si el chat system está conectado a ai-sdk
            chat_system_path = os.path.join(os.path.dirname(__file__), '..', 'frontend', 'components', 'chat-system.tsx')
            if os.path.exists(chat_system_path):
                with open(chat_system_path, 'r') as f:
                    content = f.read()

                    if 'DataStreamProvider' in content and 'ChatStoreProvider' in content:
                        self.results['ai_sdk_integration'] = "✅ Chat system usa ai-sdk con DataStreamProvider"
                        print("✅ Chat system usa ai-sdk con DataStreamProvider")
                    else:
                        self.results['ai_sdk_integration'] = "❌ Chat system NO usa ai-sdk correctamente"
                        print("❌ Chat system NO usa ai-sdk correctamente")

                    # Verificar si hay configuración de sendMessage
                    if 'sendMessage' in content:
                        self.results['sendmessage_config'] = "✅ sendMessage está referenciado en el sistema"
                        print("✅ sendMessage está referenciado en el sistema")
                    else:
                        self.results['sendmessage_config'] = "❌ sendMessage NO está configurado"
                        print("❌ sendMessage NO está configurado")

            else:
                self.results['chat_system'] = "❌ Archivo del sistema de chat no encontrado"
                print("❌ Archivo del sistema de chat no encontrado")

        except Exception as e:
            self.errors.append(f"Error verificando integración ai-sdk: {e}")
            print(f"❌ Error: {e}")

    def generate_report(self):
        """Genera reporte final del diagnóstico."""
        print("\n" + "=" * 60)
        print("📋 REPORTE FINAL DE DIAGNÓSTICO")
        print("=" * 60)

        print("\n🔍 RESULTADOS:")
        for key, result in self.results.items():
            print(f"   {result}")

        if self.errors:
            print("\n❌ ERRORES ENCONTRADOS:")
            for error in self.errors:
                print(f"   {error}")

        print("\n🎯 CONCLUSIÓN:")
        print("El problema principal es que el chat interface del frontend NO está conectado")
        print("al backend real de EmpoorioLM. El sistema usa ai-sdk pero no tiene configuración")
        print("de 'sendMessage' que conecte con el API route existente.")
        print()
        print("SOLUCIÓN PROPUESTA:")
        print("1. Crear un backend real de EmpoorioLM o mock server")
        print("2. Configurar ai-sdk para usar el endpoint /api/chat")
        print("3. Verificar que NEXT_PUBLIC_EMPOORIO_API_URL apunte al backend correcto")
        print("4. Implementar streaming real en lugar de respuestas mock")


async def main():
    """Función principal del diagnóstico."""
    diagnostic = ChatBackendDiagnostic()
    await diagnostic.run_full_diagnostic()


if __name__ == "__main__":
    asyncio.run(main())