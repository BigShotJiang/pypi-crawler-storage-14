#!/usr/bin/env python3
"""
Benchmark script for Knowledge Graph performance testing.
Tests CRUD operations, SPARQL queries, inference, and ontology loading.
Includes backend comparison and scalability metrics.
"""

import asyncio
import time
import json
import csv
import statistics
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.knowledge_graph.core import (
    get_knowledge_graph_core,
    KnowledgeGraphCore,
    BackendType,
    FormatType,
    Triple
)
from ailoos.knowledge_graph.inference import get_inference_engine, InferenceEngine
from ailoos.knowledge_graph.query_engine import get_query_engine, QueryEngine
from ailoos.knowledge_graph.ontology import get_ontology_manager, OntologyManager


class BenchmarkType(Enum):
    """Tipos de benchmarks."""
    CRUD = "crud"
    SPARQL = "sparql"
    INFERENCE = "inference"
    ONTOLOGY_LOADING = "ontology_loading"


@dataclass
class BenchmarkResult:
    """Resultado de un benchmark individual."""
    benchmark_type: str
    operation: str
    backend: str
    data_size: int
    iterations: int
    total_time_ms: float
    avg_time_ms: float
    min_time_ms: float
    max_time_ms: float
    throughput_ops_per_sec: float
    memory_usage_mb: Optional[float] = None
    error_rate: float = 0.0
    timestamp: float = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BenchmarkSuiteResult:
    """Resultado completo de una suite de benchmarks."""
    suite_name: str
    backend: str
    data_sizes: List[int]
    results: List[BenchmarkResult]
    summary: Dict[str, Any]
    timestamp: float = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "suite_name": self.suite_name,
            "backend": self.backend,
            "data_sizes": self.data_sizes,
            "results": [r.to_dict() for r in self.results],
            "summary": self.summary,
            "timestamp": self.timestamp
        }


class KnowledgeGraphBenchmark:
    """Clase principal para ejecutar benchmarks del Knowledge Graph."""

    def __init__(self):
        self.backends = [
            BackendType.IN_MEMORY,
            BackendType.RDF_STORE,
            # BackendType.NEO4J,  # Requeriría configuración adicional
            # BackendType.REDIS,  # Requeriría configuración adicional
        ]
        self.data_sizes = [100, 1000, 10000]  # Número de triples para escalabilidad
        self.iterations = 10  # Iteraciones por benchmark

    async def run_full_benchmark_suite(self) -> List[BenchmarkSuiteResult]:
        """Ejecutar suite completa de benchmarks."""
        results = []

        for backend in self.backends:
            print(f"\n=== Ejecutando benchmarks para backend: {backend.value} ===")

            # Benchmark CRUD
            crud_results = await self.benchmark_crud_operations(backend)
            results.append(crud_results)

            # Benchmark SPARQL
            sparql_results = await self.benchmark_sparql_queries(backend)
            results.append(sparql_results)

            # Benchmark Inference
            inference_results = await self.benchmark_inference(backend)
            results.append(inference_results)

            # Benchmark Ontology Loading
            ontology_results = await self.benchmark_ontology_loading(backend)
            results.append(ontology_results)

        return results

    async def benchmark_crud_operations(self, backend: BackendType) -> BenchmarkSuiteResult:
        """Benchmark de operaciones CRUD."""
        print(f"Benchmarking CRUD operations for {backend.value}")

        results = []
        suite_name = f"crud_{backend.value}"

        for data_size in self.data_sizes:
            print(f"  Testing with {data_size} triples")

            # Benchmark Add Triple
            add_result = await self._benchmark_add_triple(backend, data_size)
            results.append(add_result)

            # Benchmark Query
            query_result = await self._benchmark_query(backend, data_size)
            results.append(query_result)

            # Benchmark Remove Triple
            remove_result = await self._benchmark_remove_triple(backend, data_size)
            results.append(remove_result)

        summary = self._calculate_summary(results)
        return BenchmarkSuiteResult(
            suite_name=suite_name,
            backend=backend.value,
            data_sizes=self.data_sizes,
            results=results,
            summary=summary
        )

    async def _benchmark_add_triple(self, backend: BackendType, data_size: int) -> BenchmarkResult:
        """Benchmark de agregar triples."""
        kg_core = KnowledgeGraphCore(backend)

        # Preparar datos de prueba
        triples = self._generate_test_triples(data_size)

        times = []

        for i in range(self.iterations):
            # Limpiar grafo
            await kg_core.clear()

            start_time = time.time()

            # Agregar triples
            for triple in triples:
                await kg_core.add_triple(triple)

            end_time = time.time()
            times.append((end_time - start_time) * 1000)

        await kg_core.close()

        return self._create_benchmark_result(
            benchmark_type=BenchmarkType.CRUD.value,
            operation="add_triple",
            backend=backend.value,
            data_size=data_size,
            times=times
        )

    async def _benchmark_query(self, backend: BackendType, data_size: int) -> BenchmarkResult:
        """Benchmark de consultas."""
        kg_core = KnowledgeGraphCore(backend)

        # Preparar datos
        triples = self._generate_test_triples(data_size)
        for triple in triples:
            await kg_core.add_triple(triple)

        # Consultas de prueba
        queries = [
            "SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 100",  # Consulta simple
            "SELECT ?s WHERE { ?s <http://example.org/predicate1> ?o }",  # Consulta específica
        ]

        times = []

        for i in range(self.iterations):
            for query in queries:
                start_time = time.time()
                await kg_core.query(query)
                end_time = time.time()
                times.append((end_time - start_time) * 1000)

        await kg_core.close()

        return self._create_benchmark_result(
            benchmark_type=BenchmarkType.CRUD.value,
            operation="query",
            backend=backend.value,
            data_size=data_size,
            times=times
        )

    async def _benchmark_remove_triple(self, backend: BackendType, data_size: int) -> BenchmarkResult:
        """Benchmark de remover triples."""
        kg_core = KnowledgeGraphCore(backend)

        # Preparar datos
        triples = self._generate_test_triples(data_size)
        for triple in triples:
            await kg_core.add_triple(triple)

        times = []

        for i in range(self.iterations):
            # Remover triples uno por uno
            start_time = time.time()
            for triple in triples[:min(100, len(triples))]:  # Limitar para performance
                await kg_core.remove_triple(triple)
            end_time = time.time()
            times.append((end_time - start_time) * 1000)

            # Re-agregar para siguiente iteración
            for triple in triples[:min(100, len(triples))]:
                await kg_core.add_triple(triple)

        await kg_core.close()

        return self._create_benchmark_result(
            benchmark_type=BenchmarkType.CRUD.value,
            operation="remove_triple",
            backend=backend.value,
            data_size=data_size,
            times=times
        )

    async def benchmark_sparql_queries(self, backend: BackendType) -> BenchmarkSuiteResult:
        """Benchmark de consultas SPARQL."""
        print(f"Benchmarking SPARQL queries for {backend.value}")

        results = []
        suite_name = f"sparql_{backend.value}"

        for data_size in self.data_sizes:
            print(f"  Testing SPARQL with {data_size} triples")

            # Preparar datos
            kg_core = KnowledgeGraphCore(backend)
            triples = self._generate_test_triples(data_size)
            for triple in triples:
                await kg_core.add_triple(triple)

            # Benchmark consultas SPARQL
            sparql_result = await self._benchmark_sparql_execution(kg_core, data_size)
            results.append(sparql_result)

            await kg_core.close()

        summary = self._calculate_summary(results)
        return BenchmarkSuiteResult(
            suite_name=suite_name,
            backend=backend.value,
            data_sizes=self.data_sizes,
            results=results,
            summary=summary
        )

    async def _benchmark_sparql_execution(self, kg_core: KnowledgeGraphCore, data_size: int) -> BenchmarkResult:
        """Benchmark de ejecución de consultas SPARQL."""
        query_engine = QueryEngine(kg_core)

        sparql_queries = [
            """
            SELECT ?s ?p ?o
            WHERE {
                ?s ?p ?o .
                FILTER(?p = <http://example.org/predicate1>)
            }
            LIMIT 50
            """,
            """
            SELECT ?s (COUNT(?o) as ?count)
            WHERE {
                ?s ?p ?o
            }
            GROUP BY ?s
            HAVING (COUNT(?o) > 1)
            """,
            """
            SELECT ?s1 ?s2
            WHERE {
                ?s1 <http://example.org/predicate1> ?o .
                ?s2 <http://example.org/predicate2> ?o .
                FILTER(?s1 != ?s2)
            }
            """
        ]

        times = []

        for i in range(self.iterations):
            for query in sparql_queries:
                start_time = time.time()
                await query_engine.execute_query(query)
                end_time = time.time()
                times.append((end_time - start_time) * 1000)

        return self._create_benchmark_result(
            benchmark_type=BenchmarkType.SPARQL.value,
            operation="execute_sparql",
            backend=kg_core.backend_type.value,
            data_size=data_size,
            times=times
        )

    async def benchmark_inference(self, backend: BackendType) -> BenchmarkSuiteResult:
        """Benchmark de inferencia."""
        print(f"Benchmarking inference for {backend.value}")

        results = []
        suite_name = f"inference_{backend.value}"

        for data_size in self.data_sizes:
            print(f"  Testing inference with {data_size} triples")

            # Preparar datos con jerarquía de clases
            kg_core = KnowledgeGraphCore(backend)
            triples = self._generate_ontology_triples(data_size)
            for triple in triples:
                await kg_core.add_triple(triple)

            # Benchmark inferencia
            inference_result = await self._benchmark_inference_execution(kg_core, data_size)
            results.append(inference_result)

            await kg_core.close()

        summary = self._calculate_summary(results)
        return BenchmarkSuiteResult(
            suite_name=suite_name,
            backend=backend.value,
            data_sizes=self.data_sizes,
            results=results,
            summary=summary
        )

    async def _benchmark_inference_execution(self, kg_core: KnowledgeGraphCore, data_size: int) -> BenchmarkResult:
        """Benchmark de ejecución de inferencia."""
        inference_engine = InferenceEngine(kg_core)

        times = []

        for i in range(self.iterations):
            start_time = time.time()
            result = await inference_engine.infer()
            end_time = time.time()
            times.append((end_time - start_time) * 1000)

        return self._create_benchmark_result(
            benchmark_type=BenchmarkType.INFERENCE.value,
            operation="forward_chaining",
            backend=kg_core.backend_type.value,
            data_size=data_size,
            times=times
        )

    async def benchmark_ontology_loading(self, backend: BackendType) -> BenchmarkSuiteResult:
        """Benchmark de carga de ontologías."""
        print(f"Benchmarking ontology loading for {backend.value}")

        results = []
        suite_name = f"ontology_{backend.value}"

        # Tamaños de ontología para testing
        ontology_sizes = [100, 500, 1000]  # Número de triples en ontología

        for size in ontology_sizes:
            print(f"  Testing ontology loading with {size} triples")

            # Benchmark carga de ontología
            load_result = await self._benchmark_ontology_load(backend, size)
            results.append(load_result)

        summary = self._calculate_summary(results)
        return BenchmarkSuiteResult(
            suite_name=suite_name,
            backend=backend.value,
            data_sizes=ontology_sizes,
            results=results,
            summary=summary
        )

    async def _benchmark_ontology_load(self, backend: BackendType, size: int) -> BenchmarkResult:
        """Benchmark de carga de ontología."""
        kg_core = KnowledgeGraphCore(backend)
        ontology_manager = OntologyManager(kg_core)

        # Generar ontología de prueba en formato JSON-LD
        ontology_data = self._generate_test_ontology_jsonld(size)

        times = []

        for i in range(self.iterations):
            # Limpiar grafo
            await kg_core.clear()

            start_time = time.time()
            success = await kg_core.load_from_format(ontology_data, FormatType.JSON_LD)
            end_time = time.time()

            if success:
                times.append((end_time - start_time) * 1000)

        await kg_core.close()

        return self._create_benchmark_result(
            benchmark_type=BenchmarkType.ONTOLOGY_LOADING.value,
            operation="load_jsonld",
            backend=backend.value,
            data_size=size,
            times=times
        )

    def _generate_test_triples(self, count: int) -> List[Triple]:
        """Generar triples de prueba."""
        triples = []
        for i in range(count):
            triples.append(Triple(
                subject=f"http://example.org/subject{i}",
                predicate=f"http://example.org/predicate{i % 5}",
                object=f"value{i}" if i % 2 == 0 else i
            ))
        return triples

    def _generate_ontology_triples(self, count: int) -> List[Triple]:
        """Generar triples con estructura ontológica para inferencia."""
        triples = []

        # Crear jerarquía de clases
        for i in range(min(count // 10, 50)):  # Limitar clases
            triples.append(Triple(
                subject=f"http://example.org/Class{i}",
                predicate="http://www.w3.org/2000/01/rdf-schema#subClassOf",
                object=f"http://example.org/Class{i//2}" if i > 0 else "http://www.w3.org/2002/07/owl#Thing"
            ))

        # Crear instancias
        for i in range(count - len(triples)):
            class_idx = i % 50
            triples.append(Triple(
                subject=f"http://example.org/instance{i}",
                predicate="http://www.w3.org/1999/02/22-rdf-syntax-ns#type",
                object=f"http://example.org/Class{class_idx}"
            ))

        return triples

    def _generate_test_ontology_jsonld(self, size: int) -> str:
        """Generar ontología de prueba en JSON-LD."""
        graph = []

        for i in range(size):
            entity = {
                "@id": f"http://example.org/entity{i}",
                "@type": f"http://example.org/Class{i % 10}",
                "http://example.org/property1": f"value{i}",
                "http://example.org/property2": i
            }
            graph.append(entity)

        ontology = {
            "@context": {
                "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
                "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
                "owl": "http://www.w3.org/2002/07/owl#"
            },
            "@graph": graph
        }

        return json.dumps(ontology, indent=2)

    def _create_benchmark_result(
        self,
        benchmark_type: str,
        operation: str,
        backend: str,
        data_size: int,
        times: List[float]
    ) -> BenchmarkResult:
        """Crear resultado de benchmark."""
        if not times:
            return BenchmarkResult(
                benchmark_type=benchmark_type,
                operation=operation,
                backend=backend,
                data_size=data_size,
                iterations=0,
                total_time_ms=0.0,
                avg_time_ms=0.0,
                min_time_ms=0.0,
                max_time_ms=0.0,
                throughput_ops_per_sec=0.0,
                error_rate=1.0
            )

        total_time = sum(times)
        avg_time = statistics.mean(times)
        min_time = min(times)
        max_time = max(times)
        throughput = (len(times) / total_time) * 1000 if total_time > 0 else 0

        return BenchmarkResult(
            benchmark_type=benchmark_type,
            operation=operation,
            backend=backend,
            data_size=data_size,
            iterations=len(times),
            total_time_ms=total_time,
            avg_time_ms=avg_time,
            min_time_ms=min_time,
            max_time_ms=max_time,
            throughput_ops_per_sec=throughput
        )

    def _calculate_summary(self, results: List[BenchmarkResult]) -> Dict[str, Any]:
        """Calcular resumen de resultados."""
        if not results:
            return {}

        total_operations = sum(r.iterations for r in results)
        total_time = sum(r.total_time_ms for r in results)
        avg_throughput = sum(r.throughput_ops_per_sec for r in results) / len(results)

        return {
            "total_operations": total_operations,
            "total_time_ms": total_time,
            "average_throughput_ops_per_sec": avg_throughput,
            "operations_by_type": {
                r.operation: sum(1 for res in results if res.operation == r.operation)
                for r in results
            }
        }

    def save_results_json(self, results: List[BenchmarkSuiteResult], filename: str):
        """Guardar resultados en JSON."""
        data = {
            "benchmark_run": {
                "timestamp": time.time(),
                "total_suites": len(results),
                "backends_tested": list(set(r.backend for r in results))
            },
            "results": [r.to_dict() for r in results]
        }

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        print(f"Results saved to {filename}")

    def save_results_csv(self, results: List[BenchmarkSuiteResult], filename: str):
        """Guardar resultados en CSV."""
        all_results = []
        for suite in results:
            for result in suite.results:
                row = result.to_dict()
                row["suite_name"] = suite.suite_name
                all_results.append(row)

        if not all_results:
            print("No results to save")
            return

        fieldnames = list(all_results[0].keys())

        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(all_results)

        print(f"Results saved to {filename}")


async def main():
    """Función principal."""
    print("=== Knowledge Graph Performance Benchmarks ===")
    print("Testing CRUD operations, SPARQL queries, inference, and ontology loading")
    print("Backends: IN_MEMORY, RDF_STORE")
    print("Data sizes: 100, 1000, 10000 triples")
    print()

    benchmark = KnowledgeGraphBenchmark()

    try:
        # Ejecutar benchmarks
        results = await benchmark.run_full_benchmark_suite()

        # Guardar resultados
        timestamp = int(time.time())
        json_file = f"benchmark_results_{timestamp}.json"
        csv_file = f"benchmark_results_{timestamp}.csv"

        benchmark.save_results_json(results, json_file)
        benchmark.save_results_csv(results, csv_file)

        # Imprimir resumen
        print("\n=== Benchmark Summary ===")
        for suite in results:
            print(f"\nSuite: {suite.suite_name}")
            print(f"  Backend: {suite.backend}")
            print(f"  Total operations: {suite.summary.get('total_operations', 0)}")
            print(".2f")
            print(".2f")

    except Exception as e:
        print(f"Error running benchmarks: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())