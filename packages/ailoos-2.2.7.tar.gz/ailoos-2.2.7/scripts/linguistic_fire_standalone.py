#!/usr/bin/env python3
"""
PRUEBA DE FUEGO LINGÜÍSTICA STANDALONE - Completamente independiente
Demuestra que un Transformer GPT-2 aprende lenguaje real.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Optional, Dict, Any
from dataclasses import dataclass

@dataclass
class GPT2Config:
    """Configuración para GPT-2."""
    vocab_size: int = 1000
    hidden_size: int = 128
    num_layers: int = 2
    num_heads: int = 4
    max_position_embeddings: int = 32
    dropout: float = 0.1

class GPT2Attention(nn.Module):
    """Multi-head attention para GPT-2."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.num_heads = config.num_heads
        self.hidden_size = config.hidden_size
        self.head_dim = config.hidden_size // config.num_heads

        self.q_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.k_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.v_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.out_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)

        self.dropout = nn.Dropout(config.dropout)

    def forward(self, hidden_states: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        batch_size, seq_length, _ = hidden_states.size()

        # Proyecciones lineales
        q = self.q_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)

        # Attention scores
        scale = 1.0 / math.sqrt(self.head_dim)
        attn_weights = torch.matmul(q, k.transpose(-2, -1)) * scale

        # Apply attention mask (causal)
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        # Softmax
        attn_weights = F.softmax(attn_weights, dim=-1)
        attn_weights = self.dropout(attn_weights)

        # Apply attention
        attn_output = torch.matmul(attn_weights, v)

        # Reshape and project
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, seq_length, self.hidden_size)
        attn_output = self.out_proj(attn_output)

        return attn_output

class GPT2MLP(nn.Module):
    """MLP para GPT-2."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.fc1 = nn.Linear(config.hidden_size, 4 * config.hidden_size, bias=True)
        self.fc2 = nn.Linear(4 * config.hidden_size, config.hidden_size, bias=True)
        self.act = F.gelu
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.fc1(hidden_states)
        hidden_states = self.act(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.fc2(hidden_states)
        hidden_states = self.dropout(hidden_states)
        return hidden_states

class GPT2Block(nn.Module):
    """Bloque Transformer para GPT-2."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.ln1 = nn.LayerNorm(config.hidden_size, eps=1e-5)
        self.attn = GPT2Attention(config)
        self.ln2 = nn.LayerNorm(config.hidden_size, eps=1e-5)
        self.mlp = GPT2MLP(config)

    def forward(self, hidden_states: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        # Pre-norm architecture
        residual = hidden_states
        hidden_states = self.ln1(hidden_states)
        attn_output = self.attn(hidden_states, attention_mask)
        hidden_states = residual + attn_output  # Residual connection

        residual = hidden_states
        hidden_states = self.ln2(hidden_states)
        mlp_output = self.mlp(hidden_states)
        hidden_states = residual + mlp_output  # Residual connection

        return hidden_states

class GPT2Model(nn.Module):
    """GPT-2 Model completo."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.config = config

        # Token embeddings
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)

        # Position embeddings
        self.embed_positions = nn.Embedding(config.max_position_embeddings, config.hidden_size)

        # Dropout
        self.dropout = nn.Dropout(config.dropout)

        # Transformer blocks
        self.blocks = nn.ModuleList([
            GPT2Block(config) for _ in range(config.num_layers)
        ])

        # Final layer norm
        self.ln_f = nn.LayerNorm(config.hidden_size, eps=1e-5)

        # Language modeling head (tied weights)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        self.lm_head.weight = self.embed_tokens.weight  # Weight tying

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
    ) -> Dict[str, Any]:
        batch_size, seq_len = input_ids.size()

        # Create position IDs
        position_ids = torch.arange(seq_len, dtype=torch.long, device=input_ids.device)
        position_ids = position_ids.unsqueeze(0).expand(batch_size, -1)

        # Embeddings
        token_embeds = self.embed_tokens(input_ids)
        position_embeds = self.embed_positions(position_ids)
        hidden_states = token_embeds + position_embeds
        hidden_states = self.dropout(hidden_states)

        # Create causal attention mask
        causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
        causal_mask = causal_mask.to(input_ids.device)
        attention_mask = (~causal_mask).float() * -10000.0 if attention_mask is None else attention_mask

        # Expand for batch and heads
        attention_mask = attention_mask.unsqueeze(0).unsqueeze(1)

        # Transformer blocks
        for block in self.blocks:
            hidden_states = block(hidden_states, attention_mask)

        # Final layer norm
        hidden_states = self.ln_f(hidden_states)

        # Language modeling head
        logits = self.lm_head(hidden_states)

        result = {"logits": logits}

        # Calculate loss if labels provided
        if labels is not None:
            # Shift logits and labels for next-token prediction
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                ignore_index=-100
            )
            result["loss"] = loss

        return result

class SimpleTokenizer:
    """Tokenizer simple para demo."""

    def __init__(self, vocab_size: int = 1000):
        self.vocab_size = vocab_size
        self.bos_token_id = 1
        self.eos_token_id = 2

    def encode(self, text: str) -> list:
        """Encode text to token IDs."""
        tokens = [self.bos_token_id]
        for char in text.lower():
            if char.isalpha():
                token_id = ord(char) - ord('a') + 10  # a=10, b=11, etc.
                tokens.append(min(token_id, self.vocab_size - 1))
            elif char == ' ':
                tokens.append(3)  # space token
        tokens.append(self.eos_token_id)
        return tokens[:32]  # Max length

def main():
    print("🔥 PRUEBA DE FUEGO LINGÜÍSTICA STANDALONE")
    print("=" * 50)
    print("Transformer GPT-2 aprendiendo LENGUAJE REAL")
    print("Completamente independiente - sin dependencias AILOOS")
    print()

    # Configurar dispositivo
    device = torch.device("cpu")
    print(f"Dispositivo: {device}")

    # Crear modelo GPT-2
    config = GPT2Config(
        vocab_size=1000,
        hidden_size=128,
        num_layers=2,
        num_heads=4,
        max_position_embeddings=32
    )

    model = GPT2Model(config).to(device)
    tokenizer = SimpleTokenizer(vocab_size=1000)

    print("✅ Transformer GPT-2 creado:")
    print(f"   Parámetros: {sum(p.numel() for p in model.parameters()):,}")
    print(f"   Capas: {config.num_layers}")
    print(f"   Cabezas de atención: {config.num_heads}")

    # Datos de entrenamiento - texto real simple
    texts = [
        "hello world",
        "machine learning",
        "artificial intelligence",
        "neural networks",
        "deep learning",
        "natural language processing",
        "computer vision",
        "reinforcement learning"
    ] * 20  # Multiplicar para más datos

    print(f"✅ Datos preparados: {len(texts)} textos lingüísticos")

    # Preparar datos
    all_input_ids = []
    all_labels = []

    for text in texts:
        tokens = tokenizer.encode(text)
        if len(tokens) > 1:
            input_ids = torch.tensor(tokens[:-1], dtype=torch.long)
            labels = torch.tensor(tokens[1:], dtype=torch.long)
            all_input_ids.append(input_ids)
            all_labels.append(labels)

    # Padding simple
    max_len = max(len(ids) for ids in all_input_ids)
    padded_inputs = []
    padded_labels = []

    for inp, lab in zip(all_input_ids, all_labels):
        pad_len = max_len - len(inp)
        padded_input = torch.cat([inp, torch.zeros(pad_len, dtype=torch.long)])
        padded_label = torch.cat([lab, torch.full((pad_len,), -100, dtype=torch.long)])
        padded_inputs.append(padded_input)
        padded_labels.append(padded_label)

    # Crear batch
    input_batch = torch.stack(padded_inputs).to(device)
    label_batch = torch.stack(padded_labels).to(device)

    print(f"✅ Batch preparado: {input_batch.shape}")

    # Entrenamiento
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
    model.train()

    print("\n🚀 Entrenando Transformer con lenguaje natural...")

    initial_loss = None
    for step in range(100):
        optimizer.zero_grad()

        outputs = model(input_batch, labels=label_batch)
        loss = outputs["loss"]

        loss.backward()
        optimizer.step()

        if step == 0:
            initial_loss = loss.item()

        if step % 20 == 0:
            print(".4f")

    final_loss = loss.item()
    improvement = (initial_loss - final_loss) / initial_loss * 100

    print("\n📊 RESULTADOS FINALES - APRENDIZAJE LINGÜÍSTICO:")
    print(f"Loss inicial: {initial_loss:.4f}")
    print(f"Loss final: {final_loss:.4f}")
    print(f"Mejora: {improvement:.1f}%")
    # Verificar aprendizaje lingüístico
    learning_achieved = final_loss < 3.0 and improvement > 40

    if learning_achieved:
        print("✅ APRENDIZAJE LINGÜÍSTICO CONFIRMADO!")
        print("✅ GPT-2 APRENDE LENGUAJE NATURAL!")
        print("✅ PRUEBA DE FUEGO SUPERADA!")
        print("\n🏆 FASE REAL-6: ÉXITO TOTAL")
        print("💡 El Transformer APRENDE PATRONES LINGÜÍSTICOS REALES")
        print("🚀 LISTO PARA ESCALAR A EMPOORIOLM COMPLETO")
        return 0
    else:
        print("⚠️ Aprendizaje limitado")
        return 1

if __name__ == "__main__":
    exit(main())