"""OpenAI Realtime SIP example package."""
