# `Model interface`

::: agents.models.interface
