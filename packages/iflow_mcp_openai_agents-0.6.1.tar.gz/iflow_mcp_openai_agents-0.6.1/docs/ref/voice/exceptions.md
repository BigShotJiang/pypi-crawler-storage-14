# `Exceptions`

::: agents.voice.exceptions
