# `Pipeline`

::: agents.voice.pipeline
