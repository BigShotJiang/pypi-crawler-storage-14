"""Main entry point for the OpenAI Agents CLI."""

import argparse
import asyncio
import sys
from typing import Any, Dict, List

from . import Agent, Runner


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(description="OpenAI Agents CLI")
    parser.add_argument(
        "input", nargs="*", help="Input text to process"
    )
    parser.add_argument(
        "--instructions", "-i", default="You are a helpful assistant", help="Agent instructions"
    )
    
    args = parser.parse_args()
    
    if not args.input:
        print("Please provide input text to process")
        sys.exit(1)
        
    input_text = " ".join(args.input)
    
    # Create agent
    agent = Agent(name="CLI Assistant", instructions=args.instructions)
    
    # Run agent
    result = Runner.run_sync(agent, input_text)
    
    # Print result
    print(result.final_output)


if __name__ == "__main__":
    main()