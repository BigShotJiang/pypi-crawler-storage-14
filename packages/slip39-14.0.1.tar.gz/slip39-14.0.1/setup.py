#!/usr/bin/env python3
"""
Minimal setup.py stub for backward compatibility.

All package metadata is now defined in pyproject.toml.
This file is kept only for compatibility with older tools.
"""
from setuptools import setup

setup()
