import sys

from .main	import main

sys.exit( main() )
