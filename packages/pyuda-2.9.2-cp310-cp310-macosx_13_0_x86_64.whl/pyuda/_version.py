__version__ = '2.9.2'
__version_info__ = tuple(int(i) for i in __version__.split('.') if i.isdigit())
