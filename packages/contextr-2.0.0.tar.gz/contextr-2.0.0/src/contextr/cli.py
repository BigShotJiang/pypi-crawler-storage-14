from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.panel import Panel

try:
    import pyperclip
except ImportError:  # pragma: no cover - pyperclip is optional
    pyperclip = None  # type: ignore[assignment]

from .formatters import format_export_content, get_file_tree
from .manager import ContextManager
from .utils.path_utils import normalize_pattern

app = typer.Typer(
    help="ctxr – Share just enough of your codebase with LLMs (simple mode).",
    add_completion=False,
)
console = Console()
context_manager = ContextManager()


# --------------------------------------------------------------------------- #
# Core export logic (used when running bare `ctxr`)
# --------------------------------------------------------------------------- #
def _export_context(
    to_file: Optional[Path],
    no_clipboard: bool,
    absolute: bool,
    no_contents: bool,
) -> None:
    """Refresh the watched set and export it for the user."""
    stats = context_manager.refresh_watched()
    added, removed = stats["added"], stats["removed"]

    if added or removed:
        messages: list[str] = []
        if added:
            messages.append(f"[green]+{added}[/green] files added")
        if removed:
            messages.append(f"[red]-{removed}[/red] files removed")
        console.print(" ".join(messages))
    else:
        console.print("[dim]Context already up to date.[/dim]")

    if not context_manager.files:
        console.print(
            Panel(
                "[bold red]No files in context[/bold red]\n\n"
                "Use [bold]`ctxr watch`[/bold] to add some paths first.",
                border_style="red",
            )
        )
        return

    output_text = format_export_content(
        context_manager.files,
        base_dir=context_manager.base_dir,
        absolute_paths=absolute,
        include_contents=not no_contents,
    )

    wrote_file = False
    if to_file is not None:
        to_file.parent.mkdir(parents=True, exist_ok=True)
        to_file.write_text(output_text, encoding="utf-8")
        wrote_file = True
        console.print(f"[green]Wrote context to[/green] [bold]{to_file}[/bold]")

    if not no_clipboard and pyperclip is not None:
        try:
            pyperclip.copy(output_text)
            console.print("[green]Copied context to clipboard.[/green]")
        except pyperclip.PyperclipException:  # type: ignore[attr-defined]
            if not wrote_file:
                console.print(
                    "[yellow]Couldn't access clipboard; "
                    "printing context instead.[/yellow]"
                )
                console.print(output_text)
    else:
        if not wrote_file:
            console.print(output_text)


# --------------------------------------------------------------------------- #
# Top-level entrypoint
# --------------------------------------------------------------------------- #
@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    to_file: Optional[Path] = typer.Option(
        None,
        "--to-file",
        "-o",
        help="Write the context to a file instead of just clipboard/stdout.",
        metavar="PATH",
    ),
    no_clipboard: bool = typer.Option(
        False,
        "--no-clipboard",
        help="Don't copy the context to the clipboard.",
    ),
    absolute: bool = typer.Option(
        False,
        "--absolute",
        help="Use absolute paths in the exported context (default is relative).",
    ),
    no_contents: bool = typer.Option(
        False,
        "--no-contents",
        help="Only export the file tree (no file contents).",
    ),
) -> None:
    """
    With no subcommand, `ctxr` just exports your current watched context.

    Typical workflow:

        ctxr init          # once per repo
        ctxr watch ...     # tell ctxr what you care about
        ctxr               # whenever you want a fresh snapshot
    """
    if ctx.invoked_subcommand is not None:
        # A subcommand (watch/init/ignore/gis/clear) will run instead.
        return

    _export_context(
        to_file=to_file,
        no_clipboard=no_clipboard,
        absolute=absolute,
        no_contents=no_contents,
    )


# --------------------------------------------------------------------------- #
# Subcommands – intentionally small surface area
# --------------------------------------------------------------------------- #
@app.command()
def init() -> None:
    """
    Create the .contextr directory and default ignore rules.

    This also writes a default `.ignore` file that ignores all `*.lock` files
    so you don't accidentally send lockfiles to the model.
    """
    created, _ = context_manager.initialize()
    if created:
        console.print(
            "[green]Initialized[/green] [bold].contextr[/bold] directory in this repo."
        )
    else:
        console.print("[dim].contextr already exists – nothing to do.[/dim]")

    console.print(
        "\nDefaults:\n"
        " • [bold]*.lock[/bold] files are ignored automatically\n"
        " • add watch patterns with [bold]`ctxr watch`[/bold]\n"
        " • export a snapshot with just [bold]`ctxr`[/bold]\n"
    )


@app.command()
def watch(
    patterns: List[str] = typer.Argument(
        ...,
        metavar="PATTERN...",
        help="Glob(s) to watch, e.g. 'src/**/*.py' 'pyproject.toml'.",
    ),
) -> None:
    """
    Start watching one or more glob patterns.

    This only updates the watch list; to export the current context, run `ctxr`
    (with no subcommand).
    """
    new_patterns, added_files = context_manager.watch_paths(patterns)

    if new_patterns:
        console.print(
            "[green]Added watch patterns:[/green] "
            + ", ".join(f"[bold]{p}[/bold]" for p in sorted(new_patterns))
        )
    else:
        console.print("[dim]All patterns were already being watched.[/dim]")

    if added_files:
        console.print(f"[green]{added_files}[/green] files added to context.")
    else:
        console.print("[dim]No new files matched these patterns.[/dim]")

    if context_manager.files:
        console.print(
            Panel(
                get_file_tree(context_manager.files, context_manager.base_dir),
                title="Current context tree",
                border_style="blue",
            )
        )


@app.command()
def ignore(
    patterns: List[str] = typer.Argument(
        ...,
        metavar="PATTERN...",
        help="Glob(s) to ignore, e.g. '**/__pycache__/**' '*.log'.",
    ),
) -> None:
    """
    Add ignore rules (on top of the built-in `*.lock` rule).

    Ignored files are removed from the current context immediately.
    Absolute paths within the project are converted to relative paths.
    """
    removed_files, cleaned_dirs = context_manager.add_ignore_patterns(patterns)

    # Show normalized patterns (absolute paths converted to relative)
    normalized = [normalize_pattern(p, context_manager.base_dir) for p in patterns]
    console.print(
        f"Ignored patterns: {', '.join(f'[bold]{p}[/bold]' for p in normalized)}"
    )
    if removed_files:
        console.print(
            f"[green]{removed_files}[/green] files removed from context "
            f"({cleaned_dirs} directories cleaned)."
        )
    else:
        console.print("[dim]No existing files were removed.[/dim]")

    if context_manager.files:
        console.print(
            Panel(
                get_file_tree(context_manager.files, context_manager.base_dir),
                title="Current context tree",
                border_style="blue",
            )
        )


@app.command()
def gis() -> None:
    """
    Import ignore patterns from .gitignore (git-ignore sync).

    This just mirrors your existing Git ignore rules into ctxr. To see the
    effect on your context, run `ctxr` afterwards.
    """
    count = context_manager.sync_gitignore()
    if count:
        console.print(
            f"[green]{count}[/green] pattern(s) imported from [bold].gitignore[/bold]."
        )
    else:
        console.print(
            "[dim]No .gitignore file found or no new patterns to import.[/dim]"
        )


def _watchclear() -> None:
    """Implementation for watchclear command."""
    context_manager.clear_watched()
    console.print(
        "[yellow]Cleared watched patterns and files.[/yellow] "
        "Ignore rules were preserved."
    )


@app.command()
def watchclear() -> None:
    """
    Clear watched patterns and files.

    This removes all watched patterns and their associated files from the context.
    Ignore rules (including gitignore imports and the built-in `*.lock`) are preserved.
    """
    _watchclear()


@app.command()
def wc() -> None:
    """Shortcut for `watchclear`."""
    _watchclear()


def _ignoreclear(clear_gis: bool) -> None:
    """Implementation for ignoreclear command."""
    gis_count = context_manager.clear_ignores(preserve_gis=not clear_gis)
    if clear_gis:
        console.print(
            "[yellow]Cleared all ignore rules[/yellow] "
            "(only built-in `*.lock` remains)."
        )
    else:
        console.print(
            "[yellow]Cleared user-defined ignore rules.[/yellow] "
            f"Re-imported {gis_count} pattern(s) from .gitignore."
        )


@app.command()
def ignoreclear(
    clear_gis: bool = typer.Option(
        False,
        "--clear-gis",
        help="Also clear patterns imported from .gitignore.",
    ),
) -> None:
    """
    Clear user-defined ignore rules.

    By default, patterns imported from .gitignore via `ctxr gis` are preserved
    (re-imported after clearing). Use `--clear-gis` to clear everything.
    The built-in `*.lock` rule is always preserved.
    """
    _ignoreclear(clear_gis)


@app.command()
def ic(
    clear_gis: bool = typer.Option(
        False,
        "--clear-gis",
        help="Also clear patterns imported from .gitignore.",
    ),
) -> None:
    """Shortcut for `ignoreclear`."""
    _ignoreclear(clear_gis)


@app.command()
def unignore(
    patterns: List[str] = typer.Argument(
        ...,
        metavar="PATTERN...",
        help="Ignore pattern(s) to remove, e.g. '*.log' '**/__pycache__/**'.",
    ),
) -> None:
    """
    Remove specific ignore rules.

    This removes the specified patterns from the ignore list. Files matching
    those patterns will be included in the context again after the next refresh.
    Absolute paths within the project are converted to relative paths.
    """
    removed_count = context_manager.remove_ignore_patterns(patterns)

    # Show normalized patterns (absolute paths converted to relative)
    normalized = [normalize_pattern(p, context_manager.base_dir) for p in patterns]
    if removed_count:
        console.print(
            f"[green]Removed {removed_count}[/green] ignore pattern(s): "
            + ", ".join(f"[bold]{p}[/bold]" for p in normalized)
        )
    else:
        console.print("[dim]No matching ignore patterns found to remove.[/dim]")

    # Show current ignore patterns
    current_patterns = context_manager.list_ignore_patterns()
    if current_patterns:
        console.print(
            f"\n[dim]Remaining ignore patterns ({len(current_patterns)}):[/dim]"
        )
        for p in current_patterns:
            console.print(f"  {p}")


def run() -> None:
    """Entry-point used by the console_script in pyproject.toml."""
    app()


if __name__ == "__main__":  # pragma: no cover
    run()
