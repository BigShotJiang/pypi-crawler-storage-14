import aframexr

data = aframexr.URLData('https://davidlab20.github.io/TFG/examples/data/data.json')
img_url = aframexr.URLData('https://davidlab20.github.io/TFG/imgs/logo.png')
gltf_url = aframexr.URLData("https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/refs/heads/main/Models/AntiqueCamera/glTF/AntiqueCamera.gltf")
bars = aframexr.Chart(data, position='2 0 -8').mark_bar(size=1.5, height=5).encode(x='model', y='sales')
image = aframexr.Chart(img_url, position='-6 4 -6').mark_image(width=4, height=4)
gltf = aframexr.Chart(gltf_url, position='-1 0 -5').mark_gltf(scale='0.5 0.5 0.5')
final_chart = bars + image + gltf
final_chart.save('test.html')