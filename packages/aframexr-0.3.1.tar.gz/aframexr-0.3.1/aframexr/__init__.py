"""AframeXR like Vega-Altair library"""

from aframexr.api import *
from aframexr.utils import *
