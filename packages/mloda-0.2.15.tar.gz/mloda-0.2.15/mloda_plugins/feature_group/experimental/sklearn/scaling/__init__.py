"""
Sklearn scaling feature groups for individual scaling transformations.
"""
