from crawlee.otel.crawler_instrumentor import CrawlerInstrumentor

__all__ = [
    'CrawlerInstrumentor',
]
