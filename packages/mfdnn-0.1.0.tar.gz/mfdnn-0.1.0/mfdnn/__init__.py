"""
MFDNN: Multi-dimensional Functional Deep Neural Network

A Python package for functional data analysis using deep neural networks 
with support for 2D functional covariates.
"""

from .mfdnn import MFDNN, MFDNN_predict, RegressionNN
from .utils import integral, smooth_penalty, B_matrix, SimpsonIntegral2D

__version__ = "0.1.0"
__author__ = "Dongxue Wang"
__email__ = "2021103744@ruc.edu.cn"

__all__ = [
    "MFDNN",
    "MFDNN_predict", 
    "RegressionNN",
    "integral",
    "smooth_penalty",
    "B_matrix",
    "SimpsonIntegral2D"
]