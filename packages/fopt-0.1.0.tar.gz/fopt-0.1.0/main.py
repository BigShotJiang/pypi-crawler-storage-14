def main():
    print("Hello from fopt!")


if __name__ == "__main__":
    main()
