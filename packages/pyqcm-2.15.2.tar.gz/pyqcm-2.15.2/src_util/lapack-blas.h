#ifndef lapack_blas_h
#define lapack_blas_h

extern "C"{
#include <f2c.h>
#include <cblas.h>
#include <clapack.h>
}

#endif
