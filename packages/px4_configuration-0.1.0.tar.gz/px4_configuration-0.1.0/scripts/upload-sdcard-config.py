#!/usr/bin/env python3

import asyncio
import argparse
from mavsdk import System

def arg_parser():
    parser = argparse.ArgumentParser(
        prog='calibrate.py',
        epilog="See '<command> --help' for more detail")

    parser.add_argument('-f', '--file', help='Extras.txt file with updated rates')
    parser.add_argument('--port', type=str, default="/dev/pixhawk")
    parser.add_argument('--baudrate', type=int, default=2000000)

    args = parser.parse_args()

    return args

async def main(args):
    drone = System()
    serial = "serial://" + str(args.port) + ":" + str(args.baudrate) 
    await drone.connect(system_address=serial)
    print("Connected to a device")

    print("directory list", await drone.ftp.list_directory("/fs/microsd/etc"))
    async for progress_data in drone.ftp.upload(str(args.file), '/fs/microsd/etc'):
        print(progress_data)
    print("File uploaded")


if __name__ == "__main__":
    # Run the asyncio loop
    asyncio.run(main(args = arg_parser())) 
