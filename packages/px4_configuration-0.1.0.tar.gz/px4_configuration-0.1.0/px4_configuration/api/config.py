"""Configuration settings for the PX4 Configuration API."""

import os


class Settings:
    """Application settings with defaults."""

    # Default serial connection settings
    default_port: str = os.getenv("PX4_DEFAULT_PORT", "/dev/pixhawk")
    default_baudrate: int = int(os.getenv("PX4_DEFAULT_BAUDRATE", "2000000"))

    # API settings
    api_title: str = "PX4 Configuration API"
    api_version: str = "1.0.0"
    api_description: str = (
        "REST API for configuring PX4 flight controller from companion computer"
    )


settings = Settings()

