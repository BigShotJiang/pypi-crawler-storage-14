from django.apps import AppConfig


class BaseappAILangkitEmbeddingsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "baseapp_ai_langkit.embeddings"
    label = "baseapp_ai_langkit_embeddings"
