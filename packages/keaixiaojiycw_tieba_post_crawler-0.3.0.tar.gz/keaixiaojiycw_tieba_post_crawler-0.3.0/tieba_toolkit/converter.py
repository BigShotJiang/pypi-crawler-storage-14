import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# 导入内部工具
from .utils import THREAD_ROOT

# ==============================================================================
# CSS & HTML 模板
# (内容与 conv_v2.1.py 和 converter2.9.py 中 HTML 渲染部分一致)
# ==============================================================================

NEW_CSS_STYLE = """
<style>
/* --- 1. 几何与尺寸规范：8pt 网格与 Superellipse 圆角 --- */
:root {
    /* 定义基本网格单位和 Superellipse 模拟圆角 */
    --grid-unit: 8px;
    --radius-superellipse: 14px; /* 较大的圆角，模拟超椭圆的流畅感 */
    --color-apple-blue: #007aff; /* 现代强调色 */
}
/* ... [此处省略 NEW_CSS_STYLE 的大部分内容，请使用 conv_v2.1.py 或 converter2.9.py 中完整的 NEW_CSS_STYLE 替换此处] ... */
body {
    background-color: #f5f5f7;
    font-family: -apple-system, "SF Pro Text", "Helvetica Neue", "PingFang SC", sans-serif;
    color: #1d1d1f;
    padding: calc(var(--grid-unit) * 4);
    margin: 0;
    display: flex;
    justify-content: center;
    font-size: 16px;
    line-height: 1.6;
}
/* 主容器 */
.thread-viewer-container {
    max-width: 750px;
    width: 100%;
    background-color: #ffffff;
    border-radius: var(--radius-superellipse);
    padding: calc(var(--grid-unit) * 4);
    box-shadow:
        0 0.5px 0 0 rgba(0, 0, 0, 0.03), 
        0 4px 12px 0 rgba(0, 0, 0, 0.05),
        0 16px 32px 0 rgba(0, 0, 0, 0.02); 
    transition: all 0.3s ease;
}
/* ... (请将 CSS 完整粘贴到此处) ... */
</style>
"""

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{THREAD_TITLE}} - 贴吧查看器</title>
    {{CSS_STYLE}}
</head>
<body>
    <div class="thread-viewer-container">
        <header class="thread-header">
            <h1 id="thread-title">{{THREAD_TITLE}}</h1>
            <p class="thread-meta">
                <span>帖子ID: {{THREAD_ID}}</span>
                <span id="page-info">当前页: 1 / {{MAX_PAGE}}</span>
                <span id="posts-count"></span>
            </p>
        </header>

        <main id="post-list">
            </main>
        
        <footer id="pagination-container" class="pagination-controls">
            </footer>
    </div>
    
    <script>
    {{JS_CODE}}
    </script>
</body>
</html>
"""

# ==============================================================================
# JavaScript 渲染逻辑生成 (已集成跳页功能)
# ==============================================================================

def _generate_js_logic() -> str:
    """生成嵌入到 HTML 中的 JavaScript 动态加载和渲染代码"""
    js_template = """
// --- JavaScript 核心逻辑：异步加载与分页 --- 
const POST_LIST = document.getElementById('post-list');
const PAGINATION_CONTAINER = document.getElementById('pagination-container');
const PAGE_INFO_SPAN = document.getElementById('page-info');
let METADATA = {
    thread_id: 0,
    title: '帖子加载中...',
    max_page: 1,
    start_page: 1,
    end_page: 1,
    data_path_template: './posts/page_{page_num:04d}.json'
}; 
let CURRENT_PAGE = 1;
const PAGE_SIZE = 10; 

// --- 1. 辅助函数：时间格式化 --- 
function formatTimestamp(timestamp) {
    if (!timestamp) return 'N/A';
    const date = new Date(timestamp * 1000); 
    return date.toLocaleString('zh-CN', { 
        year: 'numeric', month: '2-digit', day: '2-digit', 
        hour: '2-digit', minute: '2-digit', second: '2-digit', 
        hour12: false 
    }).replace(/\\//g, '-'); 
}

// --- 2. 帖子渲染函数 (纯 JavaScript 实现) --- 
function renderPostOrComment(item) {
    const isComment = item.is_comment || false;
    const pid = item.pid || 'unknown';
    const userName = item.user_name || '未知用户';
    const timeStr = formatTimestamp(item.time);
    
    // --- 评论的简化渲染 ---
    if (isComment) {
        const commentDiv = document.createElement('div');
        commentDiv.className = 'comment';
        
        const userSpan = `<span class="comment-user">${userName}</span>`;
        const textSpan = `<span class="comment-text">${item.text || ''}</span>`;
        const timeSpan = `<span style="font-size: 12px; color: #b0b0b0; margin-left: 8px;">${timeStr}</span>`;
        
        commentDiv.innerHTML = userSpan + '：' + textSpan + timeSpan;
        
        const imgLinks = item.image_links || [];
        if (imgLinks.length > 0) {
            const imgContainer = document.createElement('div');
            imgContainer.className = 'image-container-comment';
            imgLinks.forEach(link => {
                const img = document.createElement('img');
                img.src = link;
                img.alt = \`评论图片 \${pid}\`;
                imgContainer.appendChild(img);
            });
            commentDiv.appendChild(imgContainer);
        }
        
        return commentDiv;
    }

    // --- 主帖/楼层帖的复杂渲染 ---
    const floor = item.floor || 'N/A';
    const postArticle = document.createElement('article');
    postArticle.className = \`post floor-\${floor}\`;
    postArticle.id = \`post-\${pid}\`;

    // 头部：用户信息
    let userInfo = \`<div class="user-info">\`;
    userInfo += \`<span class="user-name">\${userName}</span>\`;
    if (floor === 1) {
        userInfo += \`<span class="user-role">楼主</span>\`;
    }
    userInfo += `</div>`;

    // 内容
    let contentDiv = \`<div class="post-content"><p>\${item.text || ''}</p></div>\`;

    // 图片
    const imgLinks = item.image_links || [];
    if (imgLinks.length > 0) {
        let imgHtml = \`<div class="image-container">\`;
        imgLinks.forEach(link => {
            imgHtml += \`<img src="\${link}" alt="图片 \${pid}">\`;
        });
        imgHtml += `</div>`;
        contentDiv += imgHtml;
    }

    // 底部：元信息
    let metaFooter = \`<div class="post-meta">\`;
    metaFooter += `<span>PID: \${pid}</span>`;
    metaFooter += `<span>发表于 \${timeStr}</span>`;
    metaFooter += `<span>#\${floor} 楼</span>`;
    metaFooter += `</div>`;

    postArticle.innerHTML = userInfo + contentDiv + metaFooter;
    return postArticle;
}

// --- 3. 核心加载和渲染逻辑 --- 
const PAGE_CACHE = {};
let commentMap = {}; 

async function loadPage(pageNum) {
    if (pageNum < METADATA.start_page || pageNum > METADATA.end_page) {
        console.warn("页码超出转换范围:", pageNum);
        return;
    }

    CURRENT_PAGE = pageNum;
    POST_LIST.innerHTML = '<p style="text-align: center; color: #8e8e93;">正在加载第 ' + pageNum + ' 页数据...</p>';
    PAGE_INFO_SPAN.textContent = '加载中...';
    
    PAGINATION_CONTAINER.querySelectorAll('.page-btn, .goto-btn').forEach(btn => btn.disabled = true);

    if (PAGE_CACHE[pageNum]) {
        renderPosts(PAGE_CACHE[pageNum]);
        return;
    }
    
    const filePath = METADATA.data_path_template.replace('{page_num:04d}', String(pageNum).padStart(4, '0'));

    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error('网络错误或文件不存在。请检查文件是否在正确位置，并确保通过服务器（如Live Server）访问。');
        }
        const postsData = await response.json();
        PAGE_CACHE[pageNum] = postsData;
        renderPosts(postsData);
    } catch (error) {
        console.error("加载数据失败:", error);
        POST_LIST.innerHTML = '<p style="color: red; text-align: center;">加载第 ' + pageNum + ' 页数据失败：' + error.message + '</p>';
        PAGE_INFO_SPAN.textContent = '加载失败';
    } finally {
        PAGINATION_CONTAINER.querySelectorAll('.page-btn, .goto-btn').forEach(btn => btn.disabled = false);
        updatePaginationUI(pageNum);
    }
}

function renderPosts(postsData) {
    POST_LIST.innerHTML = ''; 
    commentMap = {}; 

    const mainPosts = [];
    postsData.forEach(item => {
        if (item.is_comment) {
            if (!commentMap[item.parent_pid]) {
                commentMap[item.parent_pid] = [];
            }
            commentMap[item.parent_pid].push(item);
        } else {
            mainPosts.push(item);
        }
    });

    mainPosts.forEach(post => {
        const postElement = renderPostOrComment(post);
        POST_LIST.appendChild(postElement);

        const comments = commentMap[post.pid];
        if (comments && comments.length > 0) {
            const commentSection = document.createElement('section');
            commentSection.className = 'comment-section';
            
            comments.sort((a, b) => (a.time || 0) - (b.time || 0)); 

            comments.forEach(comment => {
                commentSection.appendChild(renderPostOrComment(comment));
            });
            postElement.appendChild(commentSection);
        }
    });
    
    PAGE_INFO_SPAN.textContent = \`当前页: \${CURRENT_PAGE} / \${METADATA.max_page}\`;
    document.getElementById('posts-count').textContent = \`本页帖子数: \${mainPosts.length}\`;
    window.scrollTo({ top: 0, behavior: 'smooth' }); 
}

// --- 4. 分页 UI 逻辑 (与 conv_v2.1.py 保持一致) ---

function updatePaginationUI(currentPage) {
    PAGINATION_CONTAINER.innerHTML = '';
    const MAX_PAGE = METADATA.end_page;
    if (MAX_PAGE <= 1) return;

    let startPage = Math.max(METADATA.start_page, currentPage - Math.floor(PAGE_SIZE / 2));
    let endPage = Math.min(MAX_PAGE, startPage + PAGE_SIZE - 1);
    if (endPage - startPage + 1 < PAGE_SIZE) {
        startPage = Math.max(METADATA.start_page, endPage - PAGE_SIZE + 1);
    }

    const createButton = (text, page, isCurrent = false) => {
        const button = document.createElement('button');
        button.className = 'page-btn';
        if (isCurrent) button.classList.add('active');
        button.textContent = text;
        button.dataset.page = page;
        if (page !== null) {
            button.onclick = () => loadPage(page);
        } else {
            button.disabled = true;
        }
        PAGINATION_CONTAINER.appendChild(button);
    };

    createButton('« 上一页', currentPage > METADATA.start_page ? currentPage - 1 : null);

    if (startPage > METADATA.start_page) {
        createButton(METADATA.start_page.toString(), METADATA.start_page);
        if (startPage > METADATA.start_page + 1) {
            PAGINATION_CONTAINER.appendChild(document.createTextNode('...'));
        }
    }

    for (let i = startPage; i <= endPage; i++) {
        createButton(i.toString(), i, i === currentPage);
    }
    
    if (endPage < MAX_PAGE) {
        if (endPage < MAX_PAGE - 1) {
            PAGINATION_CONTAINER.appendChild(document.createTextNode('...'));
        }
        createButton(MAX_PAGE.toString(), MAX_PAGE);
    }
    
    createButton('下一页 »', currentPage < MAX_PAGE ? currentPage + 1 : null);

    const gotoContainer = document.createElement('div');
    gotoContainer.className = 'goto-container';
    gotoContainer.innerHTML = '<span>跳至页码: </span><input type="number" id="goto-page-input" min="1" max="\${METADATA.max_page}" value="\${currentPage}">';
    const gotoButton = document.createElement('button');
    gotoButton.className = 'goto-btn';
    gotoButton.textContent = 'Go';
    gotoButton.onclick = () => {
        const input = document.getElementById('goto-page-input');
        const page = parseInt(input.value);
        if (page >= METADATA.start_page && page <= METADATA.end_page && page !== currentPage) {
            loadPage(page);
        } else if (page > METADATA.end_page) {
            alert(\`超出转换页码范围 (\${METADATA.start_page}-\${METADATA.end_page})！将跳转到末页。\`);
            loadPage(METADATA.end_page);
        } else if (page < METADATA.start_page) {
            alert(\`超出转换页码范围 (\${METADATA.start_page}-\${METADATA.end_page})！将跳转到起始页。\`);
            loadPage(METADATA.start_page);
        }
    };
    gotoContainer.appendChild(gotoButton);
    PAGINATION_CONTAINER.appendChild(gotoContainer);
}

// --- 5. 初始化 ---

async function initialize() {
    try {
        // 元数据文件名为 tid_metadata.json
        const metadataFile = \`\${METADATA.thread_id}_metadata.json\`;
        const response = await fetch(metadataFile); 
        if (!response.ok) {
            throw new Error(\`无法加载 \${metadataFile}\`);
        }
        METADATA = await response.json(); 
        
        document.getElementById('thread-title').textContent = METADATA.title;
        document.title = \`\${METADATA.title} - 贴吧查看器\`;
        document.getElementById('page-info').textContent = \`当前页: \${CURRENT_PAGE} / \${METADATA.max_page}\`;
        
        const initialPage = METADATA.start_page;
        updatePaginationUI(initialPage);
        loadPage(initialPage); 
        
    } catch (error) {
        console.error("初始化失败:", error);
        POST_LIST.innerHTML = '<p style="color: red; text-align: center;">初始化失败，无法获取帖子元数据。请检查文件结构和访问方式。</p>';
        PAGINATION_CONTAINER.innerHTML = '';
    }
}

window.onload = initialize;

"""
    return js_template.strip()

# ==============================================================================
# 核心转换函数 (导出给 CLI 调用)
# ==============================================================================

def convert_to_html(tid: int, thread_title: str, start_page: int, end_page: int, max_page: int):
    """
    将已爬取的帖子数据转换为 HTML 异步查看器。
    """
    TID_DIR = THREAD_ROOT / str(tid)
    OUTPUT_FILE = TID_DIR / f"{tid}_apple_p{start_page}_to_p{end_page}.html"
    METADATA_FILE = TID_DIR / f"{tid}_metadata.json"
    
    # 1. 生成元数据文件 (供 JS 异步加载)
    metadata = {
        "thread_id": tid,
        "title": thread_title,
        "max_page": max_page,        
        "start_page": start_page,    
        "end_page": end_page,        
        "data_path_template": "./posts/page_{page_num:04d}.json"
    }
    
    try:
        with open(METADATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"错误: 写入元数据文件失败: {e}")
        return

    # 2. 构造 HTML 内容
    js_code = _generate_js_logic()
    
    html_content = HTML_TEMPLATE.replace("{{THREAD_TITLE}}", thread_title)
    html_content = html_content.replace("{{THREAD_ID}}", str(tid))
    html_content = html_content.replace("{{MAX_PAGE}}", str(max_page))
    html_content = html_content.replace("{{CSS_STYLE}}", NEW_CSS_STYLE)
    html_content = html_content.replace("{{JS_CODE}}", js_code)
    
    # 3. 写入 HTML 文件
    try:
        with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print("\n" + "=" * 50)
        print(f"🎉 成功生成异步查看器！")
        print(f"文件路径: {os.path.abspath(OUTPUT_FILE)}")
        print(f"元数据路径: {os.path.abspath(METADATA_FILE)}")
        print("重要提示：请务必通过 Live Server 或 Python 服务器访问！")
        print("=" * 50)
        
    except Exception as e:
        print(f"错误: 写入 HTML 文件失败: {e}")