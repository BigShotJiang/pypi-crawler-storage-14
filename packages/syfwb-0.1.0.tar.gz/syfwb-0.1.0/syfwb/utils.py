from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import logging

# Re-export tenacity decorators for convenience if user wants full control
from tenacity import retry as tenacity_retry

def simple_retry(max_attempts: int = 3, wait_min: float = 1, wait_max: float = 10):
    """
    A simple retry decorator with exponential backoff.
    
    Args:
        max_attempts: Maximum number of attempts.
        wait_min: Minimum wait time in seconds.
        wait_max: Maximum wait time in seconds.
    """
    return retry(
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential(multiplier=1, min=wait_min, max=wait_max),
        reraise=True
    )

def log_retry_attempt(retry_state):
    """Callback to log retry attempts."""
    logging.warning(f"Retrying {retry_state.fn.__name__} due to {retry_state.outcome.exception()} "
                    f"(Attempt {retry_state.attempt_number})")

def robust_retry(max_attempts: int = 5):
    """
    A more robust retry decorator that logs retries.
    """
    return retry(
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential(multiplier=1, min=2, max=60),
        before_sleep=log_retry_attempt,
        reraise=True
    )
