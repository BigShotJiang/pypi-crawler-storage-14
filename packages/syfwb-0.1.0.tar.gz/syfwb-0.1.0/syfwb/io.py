import json
import os
from typing import Any, List, Generator, Union

def read_json(path: str) -> Any:
    """Read a JSON file."""
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def write_json(path: str, data: Any, indent: int = 2, ensure_ascii: bool = False) -> None:
    """Write data to a JSON file."""
    # Ensure directory exists
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=indent, ensure_ascii=ensure_ascii)

def read_jsonl(path: str) -> Generator[Any, None, None]:
    """Read a JSONL file line by line."""
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)

def write_jsonl(path: str, data: Union[List[Any], Generator[Any, None, None]]) -> None:
    """Write a list of data to a JSONL file."""
    # Ensure directory exists
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')
