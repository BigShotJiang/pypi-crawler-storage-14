# syfwb (syf's work bench)

Common development utilities for Python projects.

## Features

- **IO**: Easy read/write for JSON and JSONL files.
- **Client**: Wrapper for OpenAI API calls.
- **Utils**: Retry mechanisms for robust function execution.

## Usage

```python
from syfwb import io, client, utils

# JSON IO
data = io.read_json("data.json")
io.write_jsonl("output.jsonl", data)

# OpenAI
response = client.call_openai(messages=[...])

# Retry
@utils.retry(max_attempts=3)
def unstable_func():
    ...
```
