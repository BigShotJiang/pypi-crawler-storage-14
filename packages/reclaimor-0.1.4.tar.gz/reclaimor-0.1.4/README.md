# ReClaimor

**Advanced subdomain takeover scanner with 20+ provider fingerprints**

[![PyPI version](https://img.shields.io/pypi/v/reclaimor.svg)](https://pypi.org/project/reclaimor/)
[![Python](https://img.shields.io/pypi/pyversions/reclaimor.svg)](https://pypi.org/project/reclaimor/)
[![License](https://img.shields.io/pypi/l/reclaimor.svg)](https://github.com/letchupkt/ReClaimor/blob/main/LICENSE)

ReClaimor is a fast, accurate subdomain takeover detection tool with multi-tier analysis (DNS → HTTP → TLS → Fingerprinting) and support for 20+ cloud providers.

## ⚠️ Legal Notice

**Only scan domains you own or have explicit authorization to test. Unauthorized scanning is illegal.**

## 🚀 Quick Start

```bash
# Install
pip install reclaimor

# Scan single domain
reclaimor --url subdomain.example.com

# Scan from file
reclaimor --file targets.txt --output results.json

# Generate HTML report
reclaimor --file targets.txt --output report.html --format html
```

## ✨ Key Features

- **Multi-tier Detection** - DNS, HTTP, TLS, and fingerprint analysis
- **20+ Providers** - GitHub Pages, Heroku, AWS S3, Azure, Netlify, Vercel, Fastly, and more
- **Fast Async Scanning** - Concurrent scanning with rate limiting
- **Multiple Formats** - JSON, CSV, HTML, and console output
- **Interactive TUI** - Manual triage interface
- **Safe by Default** - Detection-only mode (optional verification with explicit flags)

## 📋 Requirements

- Python 3.10+
- Internet connection

## 🔧 Basic Usage

```bash
# Verify installation
reclaimor --version
reclaimor --self-check

# Single domain
reclaimor --url subdomain.example.com

# Batch scanning
reclaimor --file targets.txt --concurrency 50

# With output
reclaimor --file targets.txt --output results.json --format json

# Interactive mode
reclaimor --file targets.txt --tui

# Pipe from other tools
subfinder -d example.com | reclaimor --stdin
```

## 📊 Supported Providers

GitHub Pages • Heroku • AWS S3 • AWS CloudFront • Azure Blob • Azure CDN • Netlify • Vercel • Fastly • Shopify • Tumblr • WordPress.com • Pantheon • Bitbucket • Ghost • Cargo • Feedpress • Surge.sh • Acquia • Kinsta

## 🔧 Configuration

Create `~/.reclaimor/config.yaml`:

```yaml
concurrency: 50
timeout: 15
safe_mode: true
rate_limit: 10
```

## 🐳 Docker

```bash
docker pull letchupkt/reclaimor:latest
docker run -v $(pwd)/targets.txt:/targets.txt letchupkt/reclaimor --file /targets.txt
```

## 🧪 Example Workflow

```bash
# 1. Enumerate subdomains
subfinder -d target.com -silent > subdomains.txt

# 2. Scan for takeovers
reclaimor --file subdomains.txt --output findings.json

# 3. Review findings
cat findings.json | jq '.results[] | select(.vulnerable==true)'
```

## 🛡️ Safety Features

- Safe mode by default (detection only)
- Explicit flags required for verification (`--auto-exploit --aggressive`)
- Rate limiting to prevent DoS
- Auto-cleanup after verification
- Legal notice before scanning

## 📚 Documentation

- **GitHub**: https://github.com/letchupkt/ReClaimor
- **Issues**: https://github.com/letchupkt/ReClaimor/issues
- **Full Documentation**: https://github.com/letchupkt/ReClaimor#readme

## 🤝 Contributing

Contributions welcome! See [CONTRIBUTING.md](https://github.com/letchupkt/ReClaimor/blob/main/CONTRIBUTING.md)

## 📝 Responsible Disclosure

If you find vulnerabilities:
1. Notify the asset owner privately
2. Allow 90 days for remediation
3. Follow responsible disclosure practices

## 📄 License

MIT License - Copyright (c) 2025 Lakshmikanthan ([@letchupkt](https://github.com/letchupkt))

## 🙏 Credits

Built by [@letchupkt](https://github.com/letchupkt) for the security research community.

---

**Use responsibly. Only scan authorized targets.** 🔍
