from zope.i18nmessageid import MessageFactory

SolrMessageFactory = MessageFactory("solr")

# summy messages to be picked up by i18ndude
_ = SolrMessageFactory
_("portal_type")
_("review_state")
