from zope.interface import Interface


class IThemeSpecific(Interface):
    """marker interface that defines a zope3 browser layer"""
