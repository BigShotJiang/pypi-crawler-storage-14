.. indexes

.. _`Solr`: https://lucene.apache.org/solr/
.. _`Plone`: https://www.plone.org/
.. _`docs.plone.org`: https://docs.plone.org/
.. _`enfold.solr`: https://svn.enfoldsystems.com/trac/public/browser/enfold.solr/branches/snowsprint08-buildout/enfold.solr
.. _`Enfold Systems`: https://www.enfoldsystems.com/
.. _`Snow Sprint 2008`: https://tarekziade.wordpress.com/2008/01/20/snow-sprint-report-1-indexing/
.. _`Elkjop`: https://www.elkjop.no/
.. _`Nordic Council and Nordic Council of Ministers`: https://www.norden.org/en/