Base Information how Solr and the Integration of Solr and Plone work
====================================================================

Architecture
------------

When working with Solr it's good to keep some things about it in mind. 
This information is targeted at developers and integrators trying to use and extend Solr in their Plone projects.

.. toctree::
    :maxdepth: 3

    dependencies
    indexing
    searching
