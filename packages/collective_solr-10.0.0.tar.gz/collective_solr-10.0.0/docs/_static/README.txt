README

In this folder should all static components (images, videos, ...) placed.