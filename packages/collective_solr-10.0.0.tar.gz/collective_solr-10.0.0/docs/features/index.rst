Features
========

Once installed and configured, this add-on introduces a number of end-user features.

Solr Features
-------------

Features of Solr Integration into Plone
---------------------------------------

Search Enhancements
*******************

ZCTextIndex Replacement
***********************

Old full description of Features
--------------------------------

.. toctree:: 
    :maxdepth: 2

    languages
    exclude
    facets
    binary
    wildcard
    suggestions
    highlighting
    atomic_updates
