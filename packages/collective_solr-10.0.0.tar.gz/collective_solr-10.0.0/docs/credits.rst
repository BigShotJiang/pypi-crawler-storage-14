Credits
=======

This code was inspired by `enfold.solr`_ by `Enfold Systems`_ as well as work done at the `Snow Sprint 2008`_.
The `solr.py` module is based on the original python integration package from `Solr`_ itself.

Development was kindly sponsored by `Elkjop`_ and the `Nordic Council and Nordic Council of Ministers`_.


.. include:: indexes.rst
