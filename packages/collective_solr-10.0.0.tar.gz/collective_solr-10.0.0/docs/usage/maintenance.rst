Maintenance
***********

collective.solr comes with a set of command line options to activate or deactivate Solr and update the Solr index.

Activate Solr::

    bin/instance solr_activate

Deactivate Solr::

    bin/instance solr_deactivate

Reindex Solr index::

    bin/instance solr_reindex

Clear Solr index::

    bin/instance solr_clear

Cleanup Solr index::

    bin/instance solr_cleanup

Sync Solr index::

    bin/instance solr_sync
