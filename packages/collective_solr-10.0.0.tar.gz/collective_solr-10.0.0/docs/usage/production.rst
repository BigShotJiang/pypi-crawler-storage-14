Considerations for a production Setup
-------------------------------------

.. include:: java_settings.rst

.. include:: monitoring.rst

.. include:: replication.rst

.. include:: solrcloud.rst
