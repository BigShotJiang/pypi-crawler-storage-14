Setup Solr
----------

Solr Schema
***********

Solr Field Types
................

.. include:: autocomplete.rst

Solr Base Schema for Plone
**************************

