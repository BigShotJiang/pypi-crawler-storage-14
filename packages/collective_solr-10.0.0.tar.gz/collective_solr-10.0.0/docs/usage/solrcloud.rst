SolrCloud
*********

You can read more about the `Solr Cloud`_ effort which aims to provide this.

  .. _Solr Cloud: https://solr.apache.org/guide/6_6/solrcloud.html
