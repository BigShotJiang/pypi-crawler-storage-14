Development
===========

Releases can be found on the Python Package Index at https://pypi.python.org/pypi/collective.solr.
The code and issue trackers can be found on GitHub at https://github.com/collective/collective.solr.

For outstanding issues and features remaining to be implemented please see the `to-do list`__ included in the package as well as it's `issue tracker`__.

  .. __: https://github.com/collective/collective.solr/blob/master/docs/TODO.rst
  .. __: https://github.com/collective/collective.solr/issues

.. include:: TODO.rst

.. include:: search_widget.rst
