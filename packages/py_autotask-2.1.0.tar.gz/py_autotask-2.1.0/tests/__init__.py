"""Tests for py-autotask library."""
