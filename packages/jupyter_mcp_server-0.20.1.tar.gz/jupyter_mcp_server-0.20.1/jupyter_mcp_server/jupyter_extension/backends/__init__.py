# Copyright (c) 2024- Datalayer, Inc.
#
# BSD 3-Clause License

"""Backend implementations for notebook and kernel operations"""
