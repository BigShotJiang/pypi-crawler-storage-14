"""Test suite for JESTER package."""
