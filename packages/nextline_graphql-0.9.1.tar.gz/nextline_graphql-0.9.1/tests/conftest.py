try:
    import icecream

    icecream.install()  # pragma: no cover
except ImportError:  # pragma: no cover
    pass
