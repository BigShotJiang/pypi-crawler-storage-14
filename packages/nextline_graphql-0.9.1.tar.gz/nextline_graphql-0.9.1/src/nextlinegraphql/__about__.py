__all__ = ['__version__']

from nextline_graphql.__about__ import __version__
