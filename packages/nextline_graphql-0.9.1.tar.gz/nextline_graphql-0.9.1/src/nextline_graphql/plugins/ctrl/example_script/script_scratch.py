def run(l):
    l(1)
    return

