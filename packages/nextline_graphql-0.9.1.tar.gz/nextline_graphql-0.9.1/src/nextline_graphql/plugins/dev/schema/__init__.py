__all__ = ['Query']

from .query import Query

Mutation = None
Subscription = None
