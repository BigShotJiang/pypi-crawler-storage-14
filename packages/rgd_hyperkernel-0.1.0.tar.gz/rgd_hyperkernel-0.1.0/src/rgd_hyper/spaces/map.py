"""
RGD-HYPER :: SEMANTIC MAP
Definisce la Topologia Costituzionale del Vettore di Stato (HyperAion).
"""
from enum import IntEnum

class Dimensions(IntEnum):
    # --- CONSTITUTION (Hardcoded 0-7) ---
    VALENCE = 0      # -1 (Harm) to +1 (Benefit)
    LAWFULNESS = 1   # -1 (Chaos) to +1 (Order)
    ALTRUISM = 2     # -1 (Self) to +1 (Others)
    URGENCY = 3      # 0 (Later) to 1 (Now)
    
    # --- DYNAMICS/ENTROPY (Hardcoded 8-15) ---
    ENERGY_COST = 8
    IRREVERSIBILITY = 9
    
    # --- SEMANTICS (Softcoded) ---
    START_SEMANTIC = 32 # Punto di partenza per gli Embeddings LLM
