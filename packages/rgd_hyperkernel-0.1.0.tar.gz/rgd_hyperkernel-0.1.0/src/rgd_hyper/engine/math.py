import numpy as np

def sigmoid(x, k=1.0, theta=0.0):
    """
    Funzione di Attivazione della Realtà RGD.
    $P = 1 / (1 + e^{-k(x - 	heta)})$.
    """
    return 1.0 / (1.0 + np.exp(-k * (x - theta)))

def resonance(vec_a, vec_b):
    """
    Calcola l'Energia di Risonanza (Prodotto Scalare).
    Determina quanto sono allineati i vettori Etici/Semantici.
    """
    return np.dot(vec_a, vec_b)
