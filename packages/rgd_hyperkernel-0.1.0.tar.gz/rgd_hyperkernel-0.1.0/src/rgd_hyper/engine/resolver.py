import numpy as np
from dataclasses import dataclass
from .math import sigmoid, resonance
from ..core.presets import HyperConfig

@dataclass
class CollapseResult:
    accepted: bool
    probability: float
    energy: float

class Resolver:
    """
    Implementa il Collasso della Funzione d'Onda Etica.
    Risponde alla domanda: "Questa azione è degna di esistere?".
    """
    def __init__(self, config: HyperConfig):
        self.config = config

    def collapse(self, intent: 'HyperAion', context: 'HyperAion') -> CollapseResult:
        
        # 1. Calcolo Risonanza (RGD-Ethics)
        energy = resonance(intent.vector, context.vector)
        
        # 2. Calcolo Probabilità di Esistenza
        prob = sigmoid(energy, k=self.config.sensitivity, theta=0.0)
        
        # 3. Sampling (Il Collasso)
        is_real = np.random.random() < prob
        
        return CollapseResult(
            accepted=is_real,
            probability=prob,
            energy=energy
        )
