import numpy as np
from dataclasses import dataclass

@dataclass(frozen=True)
class HyperAion:
    """
    RGD-HYPER :: HYPER-AION (Il Vettore di Stato / L'Onda)
    Un contenitore a 16k bit mappato a 512 dimensioni Float32.
    Rappresenta la volontà, l'etica e la semantica.
    """
    uuid: int
    context_t0: int     # Tempo di Genesi (per il Decadimento Cognitivo)
    vector: np.ndarray  # Il vettore 512-dim (il pensiero)
    causal_link: int    # Hash del pensiero genitore (per la Tracciabilità)

    def __post_init__(self):
        if not isinstance(self.vector, np.ndarray):
            object.__setattr__(self, 'vector', np.array(self.vector, dtype=np.float32))
