from dataclasses import dataclass

@dataclass
class HyperConfig:
    """Definisce i parametri operativi del Kernel."""
    name: str
    dims: int
    sensitivity: float # 'k' factor per la Sigmoide (Rigore Etico)

class HyperPresets:
    
    @staticmethod
    def reflex() -> HyperConfig:
        """
        MODE: REFLEX (Aion-4096 / Istinto)
        Decisioni binarie e immediate.
        """
        return HyperConfig(
            name="REFLEX",
            dims=128,
            sensitivity=5.0
        )

    @staticmethod
    def conscience() -> HyperConfig:
        """
        MODE: CONSCIENCE (Aion-16k / Ragionamento Profondo)
        Permette la sfumatura e il giudizio complesso (Bassa 'k').
        """
        return HyperConfig(
            name="CONSCIENCE",
            dims=512,
            sensitivity=1.0
        )
