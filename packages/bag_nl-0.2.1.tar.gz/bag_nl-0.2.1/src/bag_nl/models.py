from __future__ import annotations

from sqlalchemy import (
    Column,
    Integer,
    Text,
    String,
    Index,
)
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class BagText(Base):
    __tablename__ = "bag_text"

    id = Column(Integer, primary_key=True)
    text = Column(Text, nullable=False)


class BagNum(Base):
    __tablename__ = "bag_num"

    id = Column(Integer, primary_key=True)
    postcode = Column(Text)
    number = Column(Integer)
    extra = Column(Text)
    letter = Column(Text)
    type = Column(Text)
    opr = Column(Integer)
    date = Column(Integer)

    __table_args__ = (
        Index("bag_num_idx_postcode_number", "postcode", "number"),
        Index("bag_num_idx_opr", "opr"),
    )


class BagOpr(Base):
    __tablename__ = "bag_opr"

    id = Column(Integer, primary_key=True)
    name = Column(Text)
    type = Column(Integer)
    status = Column(Integer)
    wpl = Column(Integer)
    date = Column(Integer)

    __table_args__ = (
        Index("bag_opr_idx_wpl", "wpl"),
    )


class BagPnd(Base):
    __tablename__ = "bag_pnd"

    id = Column(Integer, primary_key=True)
    geo = Column(Text)
    year = Column(Integer)
    status = Column(Integer)
    date = Column(Integer)


class BagSta(Base):
    __tablename__ = "bag_sta"

    id = Column(Integer, primary_key=True)
    num = Column(Integer)
    status = Column(Integer)
    geo = Column(Text)
    tile = Column(Text)
    date = Column(Integer)

    __table_args__ = (
        Index("bag_sta_idx_num", "num"),
        Index("bag_sta_idx_tile", "tile"),
    )


class BagLig(Base):
    __tablename__ = "bag_lig"

    id = Column(Integer, primary_key=True)
    num = Column(Integer)
    status = Column(Integer)
    geo = Column(Text)
    tile = Column(Text)
    date = Column(Integer)

    __table_args__ = (
        Index("bag_lig_idx_num", "num"),
        Index("bag_lig_idx_tile", "tile"),
    )


class BagVbo(Base):
    __tablename__ = "bag_vbo"

    id = Column(Integer, primary_key=True)
    num = Column(Integer)
    geo = Column(Text)
    area = Column(Integer)
    tile = Column(Text)
    date = Column(Integer)

    __table_args__ = (
        Index("bag_vbo_idx_num", "num"),
        Index("bag_vbo_idx_tile", "tile"),
    )


class BagVboPnd(Base):
    __tablename__ = "bag_vbo_pnd"

    vbo = Column(Integer, primary_key=True)
    pnd = Column(Integer, primary_key=True)

    __table_args__ = (
        Index("bag_vbo_pnd_idx_vbo", "vbo"),
        Index("bag_vbo_pnd_idx_pnd", "pnd"),
    )


class BagVboPurpose(Base):
    __tablename__ = "bag_vbo_purpose"

    vbo = Column(Integer, primary_key=True)
    purpose = Column(Integer, primary_key=True)

    __table_args__ = (
        Index("bag_vbo_purpose_idx_vbo", "vbo"),
    )


class BagWpl(Base):
    __tablename__ = "bag_wpl"

    id = Column(Integer, primary_key=True)
    name = Column(Text)
    geo = Column(Text)
    tile = Column(Text)
    date = Column(Integer)

    __table_args__ = (
        Index("bag_wpl_idx_name", "name"),
        Index("bag_wpl_idx_tile", "tile"),
    )


class BagWplGem(Base):
    __tablename__ = "bag_wpl_gem"

    wpl = Column(Integer, primary_key=True)
    gem = Column(Integer, primary_key=True)

    __table_args__ = (
        Index("bag_wpl_gem_idx_wpl", "wpl"),
        Index("bag_wpl_gem_idx_gem", "gem"),
    )
