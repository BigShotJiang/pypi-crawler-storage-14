class _ElemVisitor:
    pass
