"""Implementation of @sites endpoints available at Zope Application root."""
