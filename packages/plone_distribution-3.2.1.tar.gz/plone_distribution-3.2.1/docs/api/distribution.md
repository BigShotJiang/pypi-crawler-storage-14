---
myst:
  html_meta:
    "description": "API methods of the Plone module 'distribution'"
    "property=og:description": "API methods of the Plone module 'distribution'"
    "property=og:title": "plone.distribution.api.distribution"
    "keywords": "Plone, content, development, API, distribution"
---

(plone-distribution-api-distribution)=

# `plone.distribution.api.distribution`

```{eval-rst}
.. automodule:: plone.distribution.api.distribution
    :members:
```
