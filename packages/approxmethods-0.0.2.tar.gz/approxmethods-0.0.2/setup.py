from setuptools import setup, find_packages

setup(
    name="approxmethods",
    version="0.0.2",
    packages=find_packages("src"),
    package_dir={'': 'src'},
    author='Jorge Borges, Eduardo Freitas, Thaina Barcellos, Josué Fonseca, Lucas Figueiredo',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/JorgeLAB/approximation_methods',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.10',
    install_requires=[
        'numpy',
        'scipy',
        'matplotlib',
    ],
)