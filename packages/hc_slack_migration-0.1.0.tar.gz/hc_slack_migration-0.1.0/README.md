# HackClub Slack migration utility
A Python CLI to estimate the remaining downtime of HackClub Slack workspace
## Usage
### Cloning the repository
- Clone the repository
- Install Python
- Run `python -m pip install -r requirements.txt`
- Run `python -m hc_slack_migration.main`
### Downloading a build from PyPI
- Install Python
- Run `pip install hc-slack-migration`
- Run `hc-slack-migration`
## License
Copyright ketr4x, 2025. Licensed under BSD-3-Clause License.

[![This project is part of Moonshot, a 4-day hackathon in Florida visiting Kennedy Space Center and Universal Studios\!](https://hc-cdn.hel1.your-objectstorage.com/s/v3/35ad2be8c916670f3e1ac63c1df04d76a4b337d1_moonshot.png)](https://moonshot.hack.club/1016)
#### This project was made for the [Moonshot](https://moonshot.hack.club/1016) hackathon organized by [HackClub](https://hackclub.com).