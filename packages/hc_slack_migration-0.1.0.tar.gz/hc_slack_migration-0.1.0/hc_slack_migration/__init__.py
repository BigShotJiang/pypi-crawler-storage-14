__version__ = "0.1.0"

def main():
    from .main import main as _main
    return _main()