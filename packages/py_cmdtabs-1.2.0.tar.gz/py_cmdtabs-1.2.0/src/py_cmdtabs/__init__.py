from py_cmdtabs.cmdtabs import CmdTabs
from py_cmdtabs.cli_manager import *