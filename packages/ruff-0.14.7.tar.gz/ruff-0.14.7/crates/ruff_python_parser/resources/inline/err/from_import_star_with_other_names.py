from x import *, a
from x import a, *, b
from x import *, a as b
from x import *, *, a
