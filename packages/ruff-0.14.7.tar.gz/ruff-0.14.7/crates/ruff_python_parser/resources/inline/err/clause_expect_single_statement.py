if True: if True: pass
