# parse_options: { "target-version": "3.9" }
match 2:
    case 1:
        pass
