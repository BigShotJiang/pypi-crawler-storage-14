# parse_options: {"target-version": "3.14"}
t"{x!z}"
