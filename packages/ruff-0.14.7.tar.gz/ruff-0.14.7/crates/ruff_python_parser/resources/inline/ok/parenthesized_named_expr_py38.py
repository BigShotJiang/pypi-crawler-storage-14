# parse_options: {"target-version": "3.8"}
{(x := 1), 2, 3}
{(last := x) for x in range(3)}
