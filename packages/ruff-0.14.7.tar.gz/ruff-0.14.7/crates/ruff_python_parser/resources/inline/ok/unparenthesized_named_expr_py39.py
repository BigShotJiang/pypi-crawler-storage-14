# parse_options: {"target-version": "3.9"}
{x := 1, 2, 3}
{last := x for x in range(3)}
