# parse_options: {"target-version": "3.14"}
t"{hey}"
t'{there}'
t"""what's
happening?"""
