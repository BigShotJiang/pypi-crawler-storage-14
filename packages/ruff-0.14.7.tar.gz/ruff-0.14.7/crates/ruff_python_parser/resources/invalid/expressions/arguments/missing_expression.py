call( = 1)
call(x = )
call(*, y)

foo
