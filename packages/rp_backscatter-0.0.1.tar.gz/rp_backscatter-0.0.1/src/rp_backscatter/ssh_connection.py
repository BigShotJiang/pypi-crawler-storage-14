import numpy as np
import matplotlib.pyplot as plt
from paramiko import SSHClient, AutoAddPolicy
from scp import SCPClient


def setup_ssh_connection(RP_IP, USERNAME, PASSWORD):
    ssh = SSHClient()
    ssh.set_missing_host_key_policy(AutoAddPolicy())
    print("[PC] Connecting to Red Pitaya...")
    ssh.connect(RP_IP, username=USERNAME, password=PASSWORD)
    print("[PC] Connected.\n")
    return ssh

def execute_remote_command(ssh, pd, detected_python="/usr/bin/python"):
    cmd = (
    f"bash -lc '{detected_python} -u /root/backscatter_working_ssh.py "
    f"--channel {pd['channel']} --buffer_size {pd['buffer_size']} --decimation {pd['decimation']} "
    f"--trig_level {pd['trig_level']} --acquisition_time {pd['acquisition_time']} --file name {pd['file_name']} "
    f"--chunk_size {pd['chunk_size']} --source {pd['source']}'"
    )
    stdin, stdout, stderr = ssh.exec_command(cmd)
    print("[PC] Running DMA acquisition on RP...")
    for line in stdout:
        print("[RP]", line.strip())
    exit_code = stdout.channel.recv_exit_status()
    print(f"[PC] Acquisition script exited with code {exit_code}\n")
    return exit_code

def transfer_from_ssh_to_local(ssh, remote_dma_path, local_dma_path):
    print("[PC] Transferring dma.bin from RP...")
    with SCPClient(ssh.get_transport()) as scp:
        scp.get(remote_dma_path, local_dma_path)
    print("[PC] File transferred.\n")

def load_samples(local_dma_path):
    samples = np.fromfile(local_dma_path, dtype=np.int16)
    return samples

def close_ssh_connection(ssh):
    ssh.close()
    print("[PC] SSH connection closed.")

def plot_first_n_samples(samples, n, ADC_bit_to_voltage_factor, channel_name):
    plt.figure(figsize=(10,5))
    plt.plot(samples[:n] / ADC_bit_to_voltage_factor, label=channel_name)
    plt.grid(True)
    plt.title(f"Red Pitaya DMA Sample Data - First {n} Samples")
    plt.legend()
    plt.show()

def run_SSH_rp_backscatter_pipeline(RP_IP, pd, username, password, remote_dma_path, local_dma_path, 
                                    n, ADC_bit_to_voltage_factor, channel_name):
    print("Setting up SSH...")
    ssh = setup_ssh_connection(RP_IP, username, password)
    print("Running remote backscatter command")
    execute_remote_command(ssh, pd)
    print("Finished running remote backscatter command")
    print("Starting file transfer from ssh to local")
    transfer_from_ssh_to_local(ssh, remote_dma_path, local_dma_path)
    print("Finished file transfer")
    print("Loading samples")
    samples = load_samples(local_dma_path)
    print("Finished loading samples")
    print("Closing ssh connection")
    close_ssh_connection(ssh)
    print("Closed SSH connection. Ready to plot!")
    plot_first_n_samples(samples, n, ADC_bit_to_voltage_factor, channel_name)


    