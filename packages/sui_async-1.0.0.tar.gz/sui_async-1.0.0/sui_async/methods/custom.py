from sui_async.errors import NotFound
from sui_async.models.models import GetClientsUniversalResponse, ClientItem, \
    RemoveResponse


class Custom:

    async def get_client_by_name(self, name: str) -> ClientItem:
        all_clients: GetClientsUniversalResponse = await self.get_clients()
        for client in all_clients.obj.clients:
            if client.name == name:
                clients = await self.get_clients(client_id=client.id)
                return clients.obj.clients[0]
        raise NotFound()

    async def delete_client_by_name(self, name: str):
        client = await self.get_client_by_name(name)
        result: RemoveResponse =  await self.delete_client(client.id)
        return result.success
