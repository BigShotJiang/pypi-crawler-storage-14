from .methods import Methods


class Sui(Methods):
    def __init__(
        self,
        full_address: str,
        token_api: str,
        https: bool = False,
        timeout: int = 30
    ):
        super().__init__(full_address, token_api, https, timeout)
