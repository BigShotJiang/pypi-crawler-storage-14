import base64
import secrets
import uuid
from typing import Dict, Any


def generate_client_config(name: str, password: str) -> Dict[str, Any]:
    """Генерирует полную конфигурацию клиента для всех протоколов."""
    client_uuid = str(uuid.uuid4())
    ss_password = base64.b64encode(secrets.token_bytes(32)).decode('utf-8')
    ss16_password = base64.b64encode(secrets.token_bytes(16)).decode('utf-8')
    return {
        "mixed": {"username": name, "password": password},
        "socks": {"username": name, "password": password},
        "http": {"username": name, "password": password},
        "shadowsocks": {"name": name, "password": ss_password},
        "shadowsocks16": {"name": name, "password": ss16_password},
        "shadowtls": {"name": name, "password": ss_password},
        "vmess": {"name": name, "uuid": client_uuid, "alterId": 0},
        "vless": {"name": name, "uuid": client_uuid,"flow": "xtls-rprx-vision"},
        "anytls": {"name": name, "password": password},
        "trojan": {"name": name, "password": password},
        "naive": {"username": name, "password": password},
        "hysteria": {"name": name, "auth_str": password},
        "tuic": {"name": name, "uuid": client_uuid, "password": password},
        "hysteria2": {"name": name, "password": password}
    }