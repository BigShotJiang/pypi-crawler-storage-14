# PyXUI Async
An application with python that allows you to modify your s-ui panel ([alireza0 s-ui](https://github.com/alireza0/s-ui)) 

## How To Install
```
pip install sui_async
```

```python
from sui_async import Sui

sui = Sui(
    full_address="http://staliox.site:2087",
    token_api="TOKEN",
    https=False, # Make note if you don't use https set False else set True
    timeout=10  # timeout connect
)
```

- Get inbounds list
```python
get_inbounds = await sui.get_inbounds()

```

- Add client to the existing inbound
```python
result = await sui.add_client(
    name="test-client",
    password="SecurePass1234",
    inbounds_id=[1,3],
    description="Test client",
    volume=10737418240,
    expiry=1735689600
)
```

- Get client's information:
```python
get_client = await sui.get_client_by_name(name='name')

# Result
class ClientItem(BaseModel):
    id: int
    name: str
    enable: bool
    inbounds: List[int]
    desc: Optional[str] = ""
    group: Optional[str] = ""
    up: Optional[int] = 0
    down: Optional[int] = 0
    volume: Optional[int] = 0
    expiry: Optional[int] = 0
    config: Optional[ClientConfig] = None
    links: Optional[List[ClientLink]] = None
```

- Delete client from the existing inbound:
```python
get_client = await sui.delete_client_by_name(name='name')
```

- Update the existing client
```python
result = await sui.update_client(
    user_id=0,
    enable=False,
    desc='desc',
    group='group',
    up=0,
    down=0,
    volume=0,
    expiry=0,
)
```
