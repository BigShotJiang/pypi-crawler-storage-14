"""Roz - An Agentic Coding CLI tool."""

__version__ = "0.1.0"
