
This repository now contains only the preparatory script for generating the required catalogues for running PILOT (https://github.com/LOFAR-VLBI/pilot)


**The genericpipeline version is no longer supported but can be found at:** https://github.com/lmorabit/lofar-vlbi



