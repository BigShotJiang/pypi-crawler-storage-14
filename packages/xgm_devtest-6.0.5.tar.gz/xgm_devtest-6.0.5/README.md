1. 安装

```bash
pip install .
```

2. 启动远程驱动

```bash
quark remote remote.json
```

3. 控制示例

```python
from quark import connect

adc = connect('ADC', host='127.0.0.1', port=1169)
```

## 发布到 PyPI

1. 预先安装打包工具：

```bash
python -m pip install --upgrade build twine
```

2. 在项目根目录构建发布物：

```bash
python -m build
```

3. （推荐）先上传至 TestPyPI：

```bash
python -m twine upload --repository testpypi dist/*
```

4. 验证安装：

```bash
pip install --index-url https://test.pypi.org/simple --extra-index-url https://pypi.org/simple systemq
```

5. 确认无误后上传至正式 PyPI：

```bash
python -m twine upload dist/*
```