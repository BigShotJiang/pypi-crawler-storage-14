"""Integration tests for doc-manager-mcp."""
