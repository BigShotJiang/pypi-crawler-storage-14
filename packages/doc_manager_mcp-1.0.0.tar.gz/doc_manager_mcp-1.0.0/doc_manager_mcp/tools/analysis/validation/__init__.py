"""Documentation validation tools for doc-manager."""

from .validator import validate_docs

__all__ = ["validate_docs"]
