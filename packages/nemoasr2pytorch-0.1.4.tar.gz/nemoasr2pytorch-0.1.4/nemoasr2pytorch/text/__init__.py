"""Text/tokenizer utilities (e.g., SentencePiece wrappers)."""

