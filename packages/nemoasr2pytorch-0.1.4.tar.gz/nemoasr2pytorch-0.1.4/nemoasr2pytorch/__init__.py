"""
Core package for NeMo ASR inference in pure PyTorch.

当前仅支持：
- Frame_VAD_Multilingual_MarbleNet_v2.0 帧级 VAD
- parakeet-tdt-0.6b-v2 RNNT-TDT ASR
"""

