"""VAD-related models (e.g., MarbleNet)."""

