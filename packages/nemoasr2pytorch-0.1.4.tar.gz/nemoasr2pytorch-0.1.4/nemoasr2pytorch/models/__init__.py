"""Model definitions for VAD and ASR."""

