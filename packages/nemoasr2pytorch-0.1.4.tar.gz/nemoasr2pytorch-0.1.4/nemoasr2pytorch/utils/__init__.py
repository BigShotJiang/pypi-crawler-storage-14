"""Shared small utilities (logging, I/O, config helpers)."""

