"""Decoding utilities (e.g., RNNT/TDT greedy decoding)."""

