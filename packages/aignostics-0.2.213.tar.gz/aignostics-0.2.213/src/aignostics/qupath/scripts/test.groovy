// Simple test script to verify argument passing
println("=== QuPath Script Test ===")
println("Number of arguments: " + args.length)
for (int i = 0; i < args.length; i++) {
    println("Argument " + i + ": " + args[i])
}
println("=== Test Complete ===")
