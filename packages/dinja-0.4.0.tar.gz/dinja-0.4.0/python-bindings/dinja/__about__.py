"""Project Info"""

__version__ = "0.4.0"
__license__ = "BSD 3-Clause"
__author__ = "hlop3z"
