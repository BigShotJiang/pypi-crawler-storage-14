python -m pytest test_metis_n_adc_slitloss.py
python -m pytest test_metis_n_lss_rsrf.py
python -m pytest test_metis_n_lss_trace.py
python -m pytest test_metis_n_lss_std.py
python -m pytest test_metis_n_lss_sci.py
python -m pytest test_metis_n_lss_mf_model.py
python -m pytest test_metis_n_lss_mf_calctrans.py
python -m pytest test_metis_n_lss_mf_correct.py
