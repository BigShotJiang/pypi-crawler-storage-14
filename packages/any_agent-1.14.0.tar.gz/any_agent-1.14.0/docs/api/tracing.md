# Tracing

::: any_agent.tracing.agent_trace.AgentTrace

::: any_agent.tracing.agent_trace.AgentSpan

::: any_agent.tracing.agent_trace.CostInfo

::: any_agent.tracing.agent_trace.TokenInfo

::: any_agent.tracing.attributes.GenAI
