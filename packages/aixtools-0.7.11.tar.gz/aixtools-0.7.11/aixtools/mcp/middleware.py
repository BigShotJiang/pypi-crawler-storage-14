"""
Custom middleware for MCP servers
"""

import traceback
from typing import Callable, Optional

from fastmcp.server.middleware.error_handling import ErrorHandlingMiddleware
from fastmcp.server.middleware.middleware import Middleware, MiddlewareContext
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent

from aixtools.agents.prompt import count_tokens
from aixtools.logging.logging_config import get_logger
from aixtools.mcp.exceptions import AixToolError
from aixtools.mcp.token_utils import (
    MAX_TOOL_RETURN_TOKENS,
    format_preview,
    serialize_result,
    write_response_to_workspace,
)

logger = get_logger(__name__)


class AixErrorHandlingMiddleware(ErrorHandlingMiddleware):
    """Custom middleware class for handling errors in MCP servers."""

    def log_as_warn_with_traceback(
        self, *, error: Exception, original_error: Exception, context: MiddlewareContext
    ) -> None:
        """Logs provided error as warning.
        original_error is an 'unwrapped' error if applicable, otherwise can be the same as error param.
        """
        error_type = type(original_error).__name__
        method = context.method or "unknown"
        error_key = f"{error_type}:{method}"
        self.error_counts[error_key] = self.error_counts.get(error_key, 0) + 1
        base_message = f"{method} resulted in {error_type}: {str(error)}"
        if self.include_traceback:
            self.logger.warning(f"{base_message}\n{traceback.format_exc()}")
        if self.error_callback:
            try:
                self.error_callback(error, context)
            except Exception as callback_error:  # pylint: disable=broad-exception-caught
                self.logger.warning("Callback failed spectacularly: %s", callback_error)

    def handle_error(self, error: Exception, context: MiddlewareContext) -> bool:
        """Custom error logging"""
        if isinstance(error, AixToolError):
            self.log_as_warn_with_traceback(error=error, original_error=error, context=context)
            return True

        inner_error = error
        while hasattr(inner_error, "__cause__") and inner_error.__cause__ is not None:
            inner_error = inner_error.__cause__
            if isinstance(inner_error, AixToolError):
                self.log_as_warn_with_traceback(error=error, original_error=inner_error, context=context)
                return True

        return False

    def _log_error(self, error: Exception, context: MiddlewareContext) -> None:
        """Override original _log_error method."""
        if self.handle_error(error, context):
            return
        super()._log_error(error, context)


class TokenLimitMiddleware(Middleware):
    """Middleware to limit tool response size by writing large responses to files.

    When a tool response exceeds max_tokens, the full response is written
    to a file in the workspace and a truncated preview is returned instead.

    WARNING: Never apply this middleware to the file edit MCP, as we want the LLM to
    use the windowed file read and regex search from the file edit MCP to extract the
    relevant information without loading the full response into context.

    Args:
        max_tokens: Maximum number of tokens allowed in a tool response before
            truncation. Defaults to MAX_TOOL_RETURN_TOKENS
        preview_chars_start: Number of characters to show from the beginning
            of the content in the default preview. Defaults to 2000.
        preview_chars_end: Number of characters to show from the end of the
            content in the default preview. Defaults to 2000.
        format_preview_fn: Optional function for custom preview formatting. If passed will
            overwrite the default behavior for truncating tool output.
    """

    def __init__(
        self,
        max_tokens: int = MAX_TOOL_RETURN_TOKENS,
        preview_chars_start: int = 2000,
        preview_chars_end: int = 2000,
        format_preview_fn: Optional[Callable[[str], str]] = None,
    ):
        self.max_tokens = max_tokens
        self.preview_chars_start = preview_chars_start
        self.preview_chars_end = preview_chars_end
        self.format_preview_fn = format_preview_fn

    async def on_call_tool(self, context: MiddlewareContext, call_next) -> ToolResult:
        """Process tool response and limit size if needed."""
        result: ToolResult = await call_next(context)

        # Convert ToolResult to MCP result format for serialization
        content, _ = result.to_mcp_result()
        result_str = serialize_result(content)

        token_count = count_tokens(result_str)

        if token_count <= self.max_tokens:
            return result

        # Write full result to file
        try:
            await write_response_to_workspace(result_str)
        except Exception as e:  # pylint: disable=broad-exception-caught
            raise RuntimeError(
                f"Tool response exceeded {self.max_tokens} tokens but failed to write to file: "
                f"{e}\n\n{result_str[:1000]}..."
            ) from e

        # Replace content with preview
        for item in result.content:
            if isinstance(item, TextContent):
                preview_text = format_preview(
                    item.text, self.preview_chars_start, self.preview_chars_end, self.format_preview_fn
                )
                item.text = preview_text
                break

        return result
