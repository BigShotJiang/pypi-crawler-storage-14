# The public interface for Kotlin

This subproject defines [Kson.kt](src/commonMain/kotlin/org/kson/Kson.kt) the public Kotlin Multiplatform interface for Kson

TODO:
- confirm we're exposing exactly what we think we are, and add some validations to the build that prevent us from changing that by accident
- define/document how we publish this artifact out 
