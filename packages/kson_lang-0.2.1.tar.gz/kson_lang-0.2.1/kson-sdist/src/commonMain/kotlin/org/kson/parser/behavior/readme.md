# Kson Behavior Documentation

This package centralizes the "behaviors" for Kson Values, centralizing and owning the "truth" about how they should act. 
For instance, in [embedblock](org/kson/parser/behavior/embedblock) we store classes for EmbedBlock specific behaviors
like how they handle indentating