# Stdlibx: Language/library-level extensions and utilities

A collection of generally reusable [`stdlib`](https://kotlinlang.org/api/core/kotlin-stdlib/)-type code.

> Proven elements of this package may graduate to a shared project/library at some point.