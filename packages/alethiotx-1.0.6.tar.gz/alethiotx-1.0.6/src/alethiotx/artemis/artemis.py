"""
**Artemis**: public knowledge graphs enable accessible and scalable drug target discovery.

Github Repository   
-----------------

`GitHub - alethiotx/artemis-paper <https://github.com/alethiotx/artemis-paper>`_
"""

from requests import get
from datetime import date
from typing import List
from re import escape, match
import json
import requests
from numpy import mean, log2, random
from typing import List
from pandas import DataFrame, concat, options, qcut, read_csv, read_excel, isna, json_normalize
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from upsetplot import UpSet, from_contents
import urllib
from xml.etree import ElementTree as ET
from io import StringIO

def indication_regexp(indication: str = 'Breast Cancer') -> str:
    """
    Generate a regular expression pattern for filtering medical indications.

    This function returns a regex pattern that matches various forms and abbreviations
    of a specified medical indication. If the indication is not found in the lookup
    table, it returns a wildcard pattern and prints a warning message.

    :param indication: The medical indication to generate a regex pattern for.
                       Must match one of the predefined indications in the lookup table.
                       Defaults to ``Breast Cancer``.
    :type indication: str, optional

    :return: A regular expression pattern string that matches the specified indication
             and its common variations. Returns ``.*`` (wildcard) if indication not found.
    :rtype: str

    :raises: None - prints a warning message if indication is not recognized

    **Supported Indications**
    * ``Myeloproliferative Neoplasm``
    * ``Breast Cancer``
    * ``Lung Cancer``
    * ``Prostate Cancer``
    * ``Bowel Cancer``
    * ``Melanoma``
    * ``Diabetes Mellitus Type 2``
    * ``Cardiovascular Disease``

    **Example**
    >>> indication_regexp('Breast Cancer')
    '.*[Bb]reast.+[Cc]ancer.*|.*[Bb]reast.+[Cc]arcinoma.*|.*[Cc]arcinoma.+[Bb]reast.*'
    
    >>> indication_regexp('Unknown Condition')
    Selected indication: Unknown Condition is not known. Proceeding with the full list of indications.
    '.*'

    .. warning::

       The function performs case-sensitive matching on the indication parameter
       against the lookup table. Ensure the indication string exactly matches one
       of the supported values.
    """
    pattern = '.*'

    lookup = DataFrame({
        'indication': [
            'Myeloproliferative Neoplasm',  
            'Breast Cancer', 
            'Lung Cancer',
            'Prostate Cancer',
            'Bowel Cancer',
            'Melanoma',
            'Diabetes Mellitus Type 2',
            'Cardiovascular Disease'
        ],
        'regexp': [
            r'.*MPN.*|.*MDS.*|.*[Mm]yeloproliferative.*|.*[Mm]yelofibrosis.*|.*[Pp]olycythemia.*|.*[Tt]hrombocytha?emia.*|.*[Mm]yelodysplastic.*|.*[Nn]eoplasm.*',
            r'.*[Bb]reast.+[Cc]ancer.*|.*[Bb]reast.+[Cc]arcinoma.*|.*[Cc]arcinoma.+[Bb]reast.*',
            r'.*[Cc]arcinoma.+[Bb]ronch.*|.*MDS.*|.*[Ll]ung.+[Cc]ancer.*|.*[Ll]ung.+[Cc]arcinoma.*|.*[Ll]ung.+[Tt]umor.*',
            r'.*[Cc]arcinoma.+[Pp]rostate.*|.*[Pp]rostat.+[Cc]ancer.*|.*[Pp]rostat.+[Cc]arcinoma.*',
            r'.*[Cc]olon.+[Cc]ancer.*|.*[Rr]ectal.+[Cc]ancer.*|.*[Rr]ectal.+[Cc]arcinoma.*',
            r'.*[Mm]elanoma.*|.*[Ss]kin.+[Ll]esion.*',
            r'.*[Tt]ype.+2.*|.*[Tt]ype.+ii.*|.*[Tt]ype-2.*|.*[Tt]ype-ii.*|.*[Tt]2[Dd][Mm].*',
            r'.*cvd.*|.*[Aa]rteriosclero.*|.*[Aa]thero.*|.*[Cc]ardiovascular [Dd]isease.*|.*[Mm]yocardial.*|[Aa]cute [Cc]oronary [Ss]yndrome.+|[Cc]ardi.+|[Cc]oronary.+|[Hh]eart [Dd]isease.+|[Pp]eripheral [Aa]rtery [Dd]isease.+|.*[Vv]ascular [Dd]isease.+'
        ]
    })

    if indication in lookup['indication'].tolist():
        pattern = list(lookup.loc[lookup['indication'] == indication, 'regexp'])[0]
    else: print('Selected indication: ' + indication + ' is not known. Proceeding with the full list of indications.')

    return pattern

def get_clinical_trials(search: str = 'Breast Cancer', filter_by_regexp: bool = True, fields: List[str] = ['NCTId', 'OverallStatus', 'StudyType', 'Condition', 'InterventionType', 'InterventionName', 'Phase', 'StartDate'], interventional_only: bool = True, intervention_types: List[str] = ['DRUG', 'BIOLOGICAL'], last_6_years: bool = True) -> DataFrame:
    """
    Retrieve and filter clinical trials data from ClinicalTrials.gov API.
    This function queries the ClinicalTrials.gov API for clinical trials matching
    the specified search criteria and applies various filters to refine the results.
    :param search: The condition or disease to search for in clinical trials.
        Default is ``Breast Cancer``.
    :type search: str
    :param filter_by_regexp: Whether to filter results by disease-related indications
        using regular expression matching. Default is True.
    :type filter_by_regexp: bool
    :param fields: List of field names to retrieve from the API. Default includes
        ``NCTId``, ``OverallStatus``, ``StudyType``, ``Condition``, ``InterventionType``,
        ``InterventionName``, ``Phase``, and ``StartDate``.
    :type fields: List[str]
    :param interventional_only: Whether to filter results to include only
        interventional studies. Default is True.
    :type interventional_only: bool
    :param intervention_types: List of intervention types to include in results.
        Default is [``DRUG``, ``BIOLOGICAL``].
    :type intervention_types: List[str]
    :param last_6_years: Whether to filter results to include only trials that
        started within the last 6 years. Default is True.
    :type last_6_years: bool
    :return: A DataFrame containing filtered clinical trials data with columns for
        ``NCTId``, ``OverallStatus``, ``StudyType``, ``InterventionType``, ``InterventionName``, ``Phase``,
        and ``StartDate``. Returns None if no results are found.
    :rtype: DataFrame or None
    :raises: None - The function handles empty results by printing a message and
        returning None.

    **Example**
    >>> df = get_clinical_trials(search='Breast Cancer', last_6_years=False)
    >>> print(df.head())
    """
    search_url = search.replace(" ", "+")
    fields = '%2C'.join(fields)

    resp = get('https://www.clinicaltrials.gov/api/v2/studies?query.cond=' + search_url + '&pageSize=1000' + '&markupFormat=legacy' + '&fields=' + fields)
    txt = resp.json()

    # if there are no results
    if txt['studies'] == []:
        print('Your request did not return any data. Please check request spelling/words and try again.')
        return

    res = json_normalize(txt['studies'])

    while 'nextPageToken' in txt:
        resp = get('https://www.clinicaltrials.gov/api/v2/studies?query.cond=' + search_url + '&pageSize=1000'  + '&markupFormat=legacy' + '&pageToken=' + txt['nextPageToken'] + '&fields=' + fields)
        txt = resp.json()
        res = concat([res, json_normalize(txt['studies'])])

    res.rename(columns={
        'protocolSection.identificationModule.nctId': 'NCTId', 
        'protocolSection.statusModule.overallStatus': 'OverallStatus',
        'protocolSection.statusModule.startDateStruct.date': 'StartDate',
        'protocolSection.conditionsModule.conditions': 'Condition',
        'protocolSection.designModule.studyType': 'StudyType',
        'protocolSection.designModule.phases': 'Phase', 
        'protocolSection.armsInterventionsModule.interventions': 'Interventions'
    }, inplace=True)

    # remove trials with no intervention name and no phase
    res = res[~res["Interventions"].isna()]
    res = res[~res["Phase"].isna()]

    # filter empty phases and select maximum phase (last value in the list, if there are multiple phases)
    res = res[res["Phase"].str.len() != 0]
    res['Phase'] = res['Phase'].apply(lambda x: x if len(x) == 1 else x.pop())

    # unlist phase column
    res = res.explode('Phase')
    res = res[res['Phase'] != 'NA']

    # filter and rename phases
    res.loc[res['Phase'] == 'PHASE0', 'Phase'] = 'PHASE1'
    res.loc[res['Phase'] == 'EARLY_PHASE1', 'Phase'] = 'PHASE1'
    res.loc[res['Phase'] == 'PHASE4', 'Phase'] = 'PHASE3'
    res.loc[res['Phase'] == 'PHASE5', 'Phase'] = 'PHASE3'

    # unlist interventions
    res = res.explode('Interventions')
    res['InterventionType'] = res['Interventions'].apply(lambda x: x['type'])
    res['InterventionName'] = res['Interventions'].apply(lambda x: x['name'])
    res = res.drop(['Interventions'], axis=1)

    # unlist items in columns
    res = res.explode('NCTId')
    res = res.explode('OverallStatus')
    res = res.explode('StudyType')
    res = res.explode('Condition')
    res = res.explode('StartDate')

    # select only interventional trials
    if interventional_only:
        res = res[res['StudyType'] == 'INTERVENTIONAL']
        res = res[(res['InterventionType'].isin(intervention_types))]

    # filter by disease related indications
    if filter_by_regexp:
        regexp_pattern = indication_regexp(search)
        res = res[res['Condition'].str.match(regexp_pattern)]

    res = res.drop(['Condition'], axis=1)
    res = res.drop_duplicates()
    
    # convert date to year
    res['StartDate'] = res['StartDate'].apply(lambda x: int(str(x)[0:4]) if not isna(x) else x)

    if last_6_years:
        current_year = int(date.today().strftime("%Y"))
        res = res[res['StartDate'] >= current_year - 6]

    # remove duplicates
    res = res.drop_duplicates()

    return(res)

def get_biomart_attributes(dataset: str = 'hsapiens_gene_ensembl') -> DataFrame:
    """
    Retrieve all available attributes for a BioMart dataset.
    
    :param dataset: Name of the BioMart dataset to query
    :type dataset: str
    :return: DataFrame containing attribute names and descriptions
    :rtype: DataFrame
    
    **Example**
    >>> df = get_biomart_attributes()
    >>> print(df[df['attribute_name'].str.contains('hgnc')][['attribute_name', 'display_name']])
    """
    url = f"http://www.ensembl.org/biomart/martservice?type=configuration&dataset={dataset}"
    r = get(url)
    
    try:
        root = ET.fromstring(r.content)
    except ET.ParseError:
        print("Error: Unable to parse BioMart response. The API may have changed or the dataset name is incorrect.")
        print("Try visiting https://www.ensembl.org/biomart/martview to browse attributes manually.")
        return DataFrame()
    
    attributes = []
    
    for page in root.findall('.//AttributePage'):
        page_name = page.get('displayName', page.get('internalName', 'Unknown'))
        for group in page.findall('.//AttributeGroup'):
            group_name = group.get('displayName', group.get('internalName', 'Unknown'))
            for collection in group.findall('.//AttributeCollection'):
                collection_name = collection.get('displayName', collection.get('internalName', ''))
                for attr in collection.findall('.//AttributeDescription'):
                    attributes.append({
                        'page': page_name,
                        'group': group_name,
                        'collection': collection_name,
                        'attribute_name': attr.get('internalName'),
                        'display_name': attr.get('displayName'),
                        'description': attr.get('description', '')
                    })
    
    return DataFrame(attributes)

def get_ttd_synonyms(path: str = "https://ttd.idrblab.cn/files/download/", file: str = "P1-04-Drug_synonyms.txt") -> DataFrame:
    """
    Retrieve and parse drug synonyms from the Therapeutic Target Database (TTD).

    This function downloads the TTD drug synonyms file, extracts drug names and their
    synonyms, and returns them as a pandas DataFrame.

    :param path: Base URL path to download the TTD drug synonyms file. Defaults to ``https://ttd.idrblab.cn/files/download/``.
    :type path: str
    :param file: Filename of the TTD drug synonyms file. Defaults to ``P1-04-Drug_synonyms.txt``.
    :type file: str

    :return: A DataFrame containing TTD drug identifiers, common drug names, and their
             synonyms. Each row represents one drug-synonym pair.
    :rtype: DataFrame

    :raises urllib.error.URLError: If the TTD synonyms file cannot be downloaded.
    :raises UnicodeDecodeError: If the downloaded file cannot be decoded as UTF-8.

    **Example**
    >>> synonyms_df = get_ttd_synonyms()
    >>> print(synonyms_df.head())
    """
    synonyms_file = urllib.request.urlopen(path + file).readlines()
    synonyms = []
    for line in synonyms_file:
        line = line.decode('utf-8')
        if "\tDRUGNAME\t" in line:
            drug_name = line.split("\t")[2].strip()
        if "\tSYNONYMS\t" in line:
            drug_id = line.split("\t")[0]
            drug_synonym = line.split("\t")[2].strip()
            synonyms.append({'TTD ID': drug_id, 'Common name': drug_name, 'Synonyms': drug_synonym})
    synonyms_df = DataFrame(synonyms)
    return synonyms_df

def get_ttd_targets(path: str = "https://ttd.idrblab.cn/files/download/", file: str = "P2-01-TTD_uniprot_all.txt") -> DataFrame:
    """
    Retrieve therapeutic target data from the Therapeutic Target Database (TTD).

    This function downloads and parses the TTD UniProt mapping file to extract
    target IDs and their corresponding gene names.

    :param path: Base URL path to download the TTD UniProt mapping file. Defaults to the official
                TTD download link for all UniProt targets.
    :type path: str

    :param file: Filename of the TTD UniProt mapping file. Defaults to ``P2-01-TTD_uniprot_all.txt``.
    :type file: str

    :return: A DataFrame containing TTD target IDs and their associated gene names.
             Columns: 'TTD ID', 'Target Gene'
    :rtype: pandas.DataFrame
    :raises urllib.error.URLError: If the URL cannot be accessed or downloaded.

    **Example**
    >>> targets_df = get_ttd_targets()
    >>> print(targets_df.head())
        TTD ID Target Gene
    0  T00001        EGFR
    1  T00002        TNF

    .. note::
       The function expects the file format to contain lines with "TARGETID\\t"
       and "UNIPROID\\t" prefixes, where data is tab-separated.    
    """
    targets_file = urllib.request.urlopen(path + file).readlines()
    targets = []
    for line in targets_file:
        line = line.decode('utf-8')
        if "TARGETID\t" in line:
            target_id = line.split("\t")[1].strip()
        if "UNIPROID\t" in line and target_id != 'TTD Target ID':
            target_gene = line.split("\t")[1].strip().split('_')[0]
            targets.append({'Target ID': target_id, 'Target Name': target_gene})
    targets_df = DataFrame(targets)
    return targets_df

def get_ttd_mappings(path: str = "https://ttd.idrblab.cn/files/download/", file: str = "P1-07-Drug-TargetMapping.xlsx") -> DataFrame:
    """
    Retrieve drug-target mapping data from the Therapeutic Target Database (TTD).

    This function downloads and processes the drug-target mapping Excel file from TTD,
    renaming columns to a standardized format for easier downstream analysis.

    :param path: Base URL path to download the TTD drug-target mapping Excel file.
                Defaults to the official TTD download link for Drug-Target Mapping (P1-07).
    :type path: str

    :param file: Filename of the TTD drug-target mapping Excel file. Defaults to ``P1-07-Drug-TargetMapping.xlsx``.
    :type file: str

    :return: A DataFrame containing the drug-target mappings with renamed columns:
             - 'Target ID' (formerly 'TargetID'): Unique identifier for the target
             - 'TTD ID' (formerly 'DrugID'): Unique identifier for the drug in TTD
             - 'Status' (formerly 'Highest_status'): Development status of the drug
             - 'Action Type' (formerly 'MOA'): Mechanism of action describing drug-target interaction
    :rtype: DataFrame

    :raises: May raise exceptions related to network connectivity or Excel file parsing
             if the URL is inaccessible or the file format is invalid.

    .. note::
       This function requires an active internet connection to download the data file.
       The default URL points to the official TTD database download resource.

    .. seealso::
       TTD Database: https://db.idrblab.net/ttd/
    """
    df = read_excel(path + file)
    df.rename(columns={
        'TargetID': 'Target ID',
        'DrugID': 'TTD ID',
        'Highest_status': 'Status',
        'MOA': 'Action Type'
    }, inplace=True)
    return df

def ttd(trials: DataFrame, date: str = '2025-11-27', pharm_action = True, approved_by = 'US') -> DataFrame:
    # load the drugbank data
    ttd = read_csv('s3://alethiotx-artemis/data/ttd/processed/' + date + '/ttd_all.csv')

    # filter out drugs with no targets
    ttd = ttd[ttd['Target Name'] != 'NOUNIPROTAC']
    ttd = ttd[~ttd['Target Name'].isna()]

    # filter short and long synonyms
    ttd['Synonyms_length'] = ttd['Synonyms'].apply(lambda x: len(str(x)))
    ttd = ttd[(ttd['Synonyms_length'] > 5) & (ttd['Synonyms_length'] <= 30)]
    ttd = ttd.drop(columns=['Synonyms_length'])

    # ASSIGN DRUGBANK IDS
    # prepare for matching clinical trials interventions with drugbank synonyms
    # Some drug synonyms likely contain characters like parentheses, brackets, or other regex special characters that need to be escaped.
    ttd['regex'] = ttd['Synonyms'].apply(lambda x: '.*' + escape(str(x).lower()) + '.*')
    trials['intervention_lower'] = trials['InterventionName'].apply(str.lower)

    # match clinical trials interventions with drugbank synonyms
    idx = [(i,j) for i,r in enumerate(ttd['regex']) for j,v in enumerate(trials['intervention_lower']) if match(r,v)]
    # define matched indexes
    df1_idx, df2_idx = zip(*idx)
    # select and reorder original data frames by matced indexes
    df1 = ttd.iloc[list(df1_idx),:].reset_index(drop=True)
    df2 = trials.iloc[list(df2_idx),:].reset_index(drop=True)
    # concatenate data frames
    res = concat([df2[df2.columns[:-1]], df1[df1.columns[:-1]]],axis=1)

    return res

def drugbank(trials: DataFrame, date: str = '2025-03-26', pharm_action = False, approved_by = 'US') -> DataFrame:
    """
    Match clinical trials with DrugBank database entries based on intervention names.

    This function loads DrugBank data, filters it based on various criteria, and matches
    clinical trial interventions with drug synonyms from the DrugBank database.

    :param trials: DataFrame containing clinical trials data with an ``InterventionName`` column
    :type trials: DataFrame
    :param date: Date string for the DrugBank data snapshot in ``YYYY-MM-DD`` format, defaults to ``2025-03-26``
    :type date: str, optional
    :param pharm_action: If True, filter results to only include drugs with pharmacological action marked as ``Yes``, defaults to True
    :type pharm_action: bool, optional
    :param approved_by: Filter drugs by approval status. Options are ``US`` (US approved only), 
                        ``Other`` (approved in other countries), or ``Both`` (approved in both US and other countries), 
                        defaults to ``US``
    :type approved_by: str, optional
    :return: DataFrame containing matched clinical trials and DrugBank entries with the following transformations:
             - ``Target Name`` renamed to ``Target Gene``
             - ``Approved`` column added based on approval status (1 for approved, 0 otherwise)
             - ``US Approved`` and ``Other Approved`` columns removed
    :rtype: DataFrame
    :raises: May raise exceptions related to S3 access, CSV parsing, or DataFrame operations

    .. note::

       - The function filters out DrugBank entries without target information
       - Drug synonyms are filtered to lengths between 5 and 30 characters
       - Matching is performed using case-insensitive regex pattern matching
       - The function reads data from an S3 bucket at ``s3://alethiotx-artemis/data/drugbank/``

    .. warning::

       This function may be computationally expensive for large datasets due to nested loop matching
    """
    # load the drugbank data
    db = read_csv('s3://alethiotx-artemis-internal/data/drugbank/' + date + '/webdata.csv')

    # filter out drugs with no targets
    db = db[db['Target Name'] != 'Not Available']
    db = db[~db['Target Name'].isna()]

    # filter short and long synonyms
    db['Synonyms_length'] = db['Synonyms'].apply(lambda x: len(str(x)))
    db = db[(db['Synonyms_length'] > 5) & (db['Synonyms_length'] <= 30)]
    db = db.drop(columns=['Synonyms_length'])

    # ASSIGN DRUGBANK IDS
    # prepare for matching clinical trials interventions with drugbank synonyms
    # Some drug synonyms likely contain characters like parentheses, brackets, or other regex special characters that need to be escaped.
    db['regex'] = db['Synonyms'].apply(lambda x: '.*' + escape(str(x).lower()) + '.*')
    trials['intervention_lower'] = trials['InterventionName'].apply(str.lower)

    # match clinical trials interventions with drugbank synonyms
    idx = [(i,j) for i,r in enumerate(db['regex']) for j,v in enumerate(trials['intervention_lower']) if match(r,v)]
    # define matched indexes
    df1_idx, df2_idx = zip(*idx)
    # select and reorder original data frames by matced indexes
    df1 = db.iloc[list(df1_idx),:].reset_index(drop=True)
    df2 = trials.iloc[list(df2_idx),:].reset_index(drop=True)
    # concatenate data frames
    res = concat([df2[df2.columns[:-1]], df1[df1.columns[:-1]]],axis=1)

    return res

    if pharm_action:
        res = res[res['Pharmacological Action'] == 'Yes']

    res.rename(columns={
        'Target Name': 'Target Gene',
    }, inplace=True)

    if approved_by == 'US':
        res['Approved'] = res['US Approved']
        res['Approved'] = res['Approved'].apply(lambda x: 1 if x == 'YES' else 0)
    elif approved_by == 'Other':
        res['Approved'] = res['Other Approved']
        res['Approved'] = res['Approved'].apply(lambda x: 1 if x == 'YES' else 0)
    elif approved_by == 'Both':
        res['Approved'] = res[['US Approved', 'Other Approved']].apply(lambda x: 1 if all(x == 'YES') else 0, axis = 1)
    res = res.drop(columns=['US Approved', 'Other Approved'])

    return res

def get_clinical_scores(trials: DataFrame, include_approved: bool = True) -> DataFrame:
    """
    Calculate clinical trial scores and statistics for target genes.

    This function analyzes clinical trial data to compute various metrics including
    phase distributions, phase scores, approved drug counts, and an overall clinical score
    for each target gene.

    :param trials: DataFrame containing clinical trial data with columns including
                   ``Target Gene``, ``NCTId``, ``Phase``, ``Approved``, and ``DrugBank ID``
    :type trials: DataFrame
    :param include_approved: Whether to include approved drugs in the total clinical score
                            calculation. If True, approved drugs contribute 20 points
                            each to the clinical score. Defaults to True.
    :type include_approved: bool, optional

    :return: DataFrame with the following columns for each target gene:
    * ``# Phase 1``: Count of Phase 1 trials
    * ``# Phase 2``: Count of Phase 2 trials
    * ``# Phase 3``: Count of Phase 3 trials
    * ``Phase Score``: Sum of phase numbers across all trials
    * ``# Approved Drugs``: Count of unique approved drugs
    * ``Clinical Score``: Total score (phase score + 20 * approved drugs if include_approved=True)

    Results are sorted by ``Clinical Score`` in descending order.
    
    :rtype: DataFrame

    :raises: May raise exceptions if required columns are missing from the input DataFrame
             or if phase values cannot be converted to integers.

    .. note::

       The function prints phase value counts as a side effect during execution.

    .. warning::

       The function assumes that Phase values end with a numeric character that can
       be extracted and converted to an integer.
    """
    # calculate number of trials in each phase
    phases = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: x[['NCTId', 'Phase']].drop_duplicates()['Phase'].value_counts())).unstack()
    phases[phases.isna()] = 0
    # calculate phase scores
    print(trials['Phase'].value_counts())
    phase_scores = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: sum(x[['NCTId', 'Phase']].drop_duplicates()['Phase'].str[-1].astype(int))))
    # calculate number of approved drugs for each target
    n_approved_drugs = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: len(x.loc[x['Approved'] == 1, 'TTD ID'].drop_duplicates())))
    # concatenate all data frames
    res = concat([phases, phase_scores, n_approved_drugs], axis = 1)
    res.columns = ['# Phase 1', '# Phase 2', '# Phase 3', 'Phase Score', '# Approved Drugs']
    # calculate a total clinical score
    if include_approved:
        res['Clinical Score'] = res['Phase Score'] + res['# Approved Drugs'] * 20
    else:
        res['Clinical Score'] = res['Phase Score']
    # sort by clinical score
    res = res.sort_values(by = 'Clinical Score', ascending=False)

    return(res)

def load_clinical_scores(date = '2025-11-11'):
    """
    Retrieve clinical scores for multiple disease types from S3 storage.

    This function reads CSV files containing clinical target data for various diseases
    from an S3 bucket, organized by date.

    :param date: The date string used to construct the S3 file paths, defaults to ``2025-11-11``
    :type date: str, optional
    :return: A tuple containing DataFrames for breast, lung, prostate, melanoma, bowel,
             diabetes, and cardiovascular clinical scores (in that order)
    :rtype: tuple of pandas.DataFrame
    :raises FileNotFoundError: If any of the CSV files do not exist at the specified S3 paths
    :raises ValueError: If the CSV files cannot be parsed correctly

    .. note::

       All CSV files are expected to be located in the S3 bucket at:
       ``s3://alethiotx-artemis/data/clinical_targets/{date}/{disease}.csv``

    .. warning::

       Ensure data exists
       for the specified date before calling this function.

    **Example**
    >>> breast, lung, prostate, melanoma, bowel, diabetes, cardio = load_clinical_scores('2025-11-11')
    >>> print(breast.shape)
    (100, 5)
    """
    breast = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/breast.csv")
    lung = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/lung.csv")
    prostate = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/prostate.csv")
    melanoma = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/melanoma.csv")
    bowel = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/bowel.csv")
    diabetes = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/diabetes.csv")
    cardiovascular = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/cardiovascular.csv")

    return(breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular)

def get_pathway_genes(search, rif = 'generif'):
    """
    Query the Geneshot API to retrieve gene associations for a search term.

    :param search: The search term to query for gene associations
    :type search: str
    :param rif: The type of reference to use for gene associations, defaults to ``generif``
    :type rif: str, optional
    :return: A DataFrame containing gene associations with columns for gene symbols (index),
             gene_count (number of associations), and rank (relevance ranking)
    :rtype: pandas.DataFrame

    :raises requests.exceptions.RequestException: If the API request fails

    **Example**
    >>> df = get_pathway_genes('cancer')
    >>> print(df.head())

    .. note::
       Gene symbols containing hyphens (-) or underscores (_) are filtered out from the results.

    """
    GENESHOT_URL = 'https://maayanlab.cloud/geneshot/api/search'
    payload = {"rif": rif, "term": search}
    response = requests.post(GENESHOT_URL, json=payload)
    data = json.loads(response.text)
    d = DataFrame(data)
    d['rank'] = d['gene_count'].apply(lambda x: x[1])
    d['gene_count'] = d['gene_count'].apply(lambda x: x[0])
    d = d[(~d.index.str.contains('-')) & (~d.index.str.contains('_'))]
    return d

def load_pathway_genes(date = '2025-11-11', n = 100):
    """
    Retrieve pathway genes for multiple disease types from S3 storage.

    This function reads CSV files containing pathway gene data for various diseases,
    sorts them by gene count and rank, and returns the top N pathways for each disease.

    :param date: Date string in ``YYYY-MM-DD`` format representing the data version,
                 defaults to ``2025-11-11``
    :type date: str, optional
    :param n: Number of top pathways to retrieve for each disease, defaults to 100
    :type n: int, optional

    :return: A tuple containing lists of pathway indices for each disease type in the
             following order: (breast, lung, prostate, melanoma, bowel, diabetes,
             cardiovascular)
    :rtype: tuple[list, list, list, list, list, list, list]

    :raises FileNotFoundError: If the specified CSV files do not exist in S3
    :raises ValueError: If the CSV files are malformed or missing required columns

    **Example**
    >>> breast, lung, prostate, melanoma, bowel, diabetes, cardio = load_pathway_genes(
    ...     date='2025-11-11', n=50
    ... )
    >>> len(breast)
    50

    .. note::
    
       The function expects CSV files to be located at
       ``s3://alethiotx-artemis/data/pathway_genes/{date}/{disease}.csv``

    .. note::

       Each CSV file must contain ``gene_count`` and ``rank`` columns for sorting

    """
    breast = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/breast.csv', index_col = 0)
    breast = breast.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    lung = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/lung.csv', index_col = 0)
    lung = lung.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    bowel = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/bowel.csv', index_col = 0)
    bowel = bowel.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    prostate = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/prostate.csv', index_col = 0)
    prostate = prostate.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    melanoma = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/melanoma.csv', index_col = 0)
    melanoma = melanoma.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    diabetes = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/diabetes.csv', index_col = 0)
    diabetes = diabetes.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    cardiovascular = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/cardiovascular.csv', index_col = 0)
    cardiovascular = cardiovascular.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()

    return (breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular)

def get_all_targets(scores: list):
    """
    Extract all unique target genes from a list of score dictionaries.

    :param scores: A list of dictionaries, where each dictionary contains a ``Target Gene`` key
                   with a value that can be converted to a list using tolist() method
                   (typically a pandas Series or similar object)
    :type scores: list
    :return: A list of all unique target genes found across all dictionaries in the input list
    :rtype: list

    **Example**
    >>> scores = [
    ...     {'Target Gene': pd.Series(['GENE1', 'GENE2'])},
    ...     {'Target Gene': pd.Series(['GENE2', 'GENE3'])}
    ... ]
    >>> get_all_targets(scores)
    ['GENE1', 'GENE2', 'GENE3']
    """
    all_targets = set()

    for d in scores:
        all_targets.update(d['Target Gene'].tolist())

    return(list(all_targets))

def cut_clinical_scores(scores: list, lowest_score = 0):
    """
    Filter clinical scores by removing entries below a threshold.

    This function creates a copy of the input scores list and filters each DataFrame
    within it to retain only rows where the ``Clinical Score`` exceeds the specified
    lowest_score threshold.

    :param scores: List of DataFrames containing clinical score data with a ``Clinical Score`` column
    :type scores: list
    :param lowest_score: Minimum score threshold for filtering, defaults to 0
    :type lowest_score: int or float
    :return: List of filtered DataFrames with scores above the threshold
    :rtype: list

    **Example**
    >>> import pandas as pd
    >>> scores = [pd.DataFrame({'Clinical Score': [0.5, 1.5, 2.0]})]
    >>> filtered = cut_clinical_scores(scores, lowest_score=1.0)
    >>> filtered[0]
        Clinical Score
    1         1.5
    2         2.0
    """
    res = scores.copy()

    for n, d in enumerate(res):
        res[n] = d[d['Clinical Score'] > lowest_score]

    return(res)

def find_overlapping_genes(genes: list, overlap = 1, common_genes = []):
    """
    Find genes that overlap across multiple gene lists.

    :param genes: A list of gene lists to check for overlapping genes.
    :type genes: list
    :param overlap: Minimum number of lists a gene must appear in to be considered overlapping, defaults to 1.
    :type overlap: int
    :param common_genes: Initial list of common genes to include in the result, defaults to [].
    :type common_genes: list
    :return: A list of genes that appear in more than ``overlap`` lists but not in all lists.
    :rtype: list

    **Example**
    >>> genes_list = [['gene1', 'gene2'], ['gene2', 'gene3'], ['gene2', 'gene4']]
    >>> find_overlapping_genes(genes_list, overlap=1)
    ['gene2']

    .. note::

        Genes that appear in all input lists are excluded from the result by default.
        To include them, modify the condition ``d[i] < len(genes)`` to ``d[i] <= len(genes)``.

    """
    d = {}
    overlapping_genes = common_genes.copy()

    for i in [x for y in genes for x in y]:
        if i in d.keys():
            d[i]=d[i]+1
        else:
            d[i]=1
    for i in d.keys():
        if d[i]>overlap and d[i] < len(genes): # the second condition excludes genes present in all lists, if you want to include those, change < to <=, or remove the condition entirely
            overlapping_genes.append(i)
    return overlapping_genes

def uniquify_clinical_scores(scores: list, overlap = 1, common_genes = []):
    """
    Remove overlapping genes from clinical score dataframes to ensure uniqueness.
    This function processes a list of dataframes containing clinical scores and removes
    genes that appear in multiple dataframes above a specified overlap threshold.
    :param scores: List of dataframes, each containing a ``Target Gene`` column with gene identifiers
    :type scores: list
    :param overlap: Minimum number of dataframes a gene must appear in to be considered overlapping, defaults to 1
    :type overlap: int, optional
    :param common_genes: Additional list of genes to always consider as overlapping regardless of frequency, defaults to []
    :type common_genes: list, optional
    :return: List of dataframes with overlapping genes removed from each dataframe
    :rtype: list

    **Example**
    >>> df1 = pd.DataFrame({'Target Gene': ['BRCA1', 'TP53', 'EGFR']})
    >>> df2 = pd.DataFrame({'Target Gene': ['TP53', 'KRAS', 'MYC']})
    >>> result = uniquify_clinical_scores([df1, df2], overlap=2)
    >>> # TP53 will be removed from both dataframes as it appears in 2 or more

    .. note::

        The function uses :func:`find_overlapping_genes` to identify genes that should be removed.
    .. warning::

        This function modifies copies of the input dataframes. The original dataframes remain unchanged.
    """
    genes = []
    for n, d in enumerate(scores):
        genes.append(d['Target Gene'].tolist())

    overlapping_genes = find_overlapping_genes(genes, overlap = overlap, common_genes = common_genes)
    
    res = scores.copy()

    for n, d in enumerate(res):
        res[n] = d[~d['Target Gene'].isin(overlapping_genes)]
    
    return(res)


def uniquify_pathway_genes(genes: list, overlap = 1, common_genes = []):
    """
    Remove overlapping genes from pathway gene lists.
    This function identifies genes that appear in multiple pathways (based on the
    specified overlap threshold) and removes them from each pathway's gene list,
    returning uniquified pathway gene lists.
    :param genes: A list of gene lists, where each inner list represents genes
                  associated with a particular pathway.
    :type genes: list
    :param overlap: The minimum number of pathways a gene must appear in to be
                    considered overlapping and removed. Defaults to 1.
    :type overlap: int, optional
    :param common_genes: A list of genes that should be considered as commonly
                         overlapping regardless of their occurrence count.
    :type common_genes: list, optional
    :return: A copy of the input gene lists with overlapping genes removed from
             each pathway.
    :rtype: list

    **Example**
    >>> genes = [['GENE1', 'GENE2', 'GENE3'], ['GENE2', 'GENE4'], ['GENE3', 'GENE5']]
    >>> uniquify_pathway_genes(genes, overlap=2)
    [['GENE1'], ['GENE4'], ['GENE5']]
    """
    overlapping_genes = find_overlapping_genes(genes, overlap = overlap, common_genes = common_genes)
    
    res = genes.copy()

    for n, y in enumerate(res):
        res[n] = [x for x in y if x not in overlapping_genes]

    return(res)

def pre_model(X: DataFrame, y: DataFrame, pathway_genes: List = [], known_targets: List = [], term_num = None, bins: int = 3, rand_seed: int = 12345) -> dict:
    """
    Prepare and preprocess data for machine learning model training.

    This function processes knowledge graph (KG) features and clinical scores to create
    training datasets for drug target prediction models. It handles positive targets,
    negative samples, and pathway genes, then returns formatted features and labels.

    :param X: Knowledge graph features with genes as columns
    :type X: DataFrame
    :param y: Clinical data containing target genes and clinical scores
    :type y: DataFrame
    :param pathway_genes: List of pathway-associated genes to include as a separate class
    :type pathway_genes: List, optional
    :param known_targets: List of known target genes to exclude from negative sampling
    :type known_targets: List, optional
    :param term_num: Number of random KG features to sample; if None, uses all features
    :type term_num: int, optional
    :param bins: Number of bins for discretizing positive target clinical scores
    :type bins: int, optional
    :param rand_seed: Random seed for reproducibility
    :type rand_seed: int, optional
    :return: Dictionary containing:
    * ``X``: Feature matrix (KG features) for modeling
    * ``y``: Continuous clinical scores (log2-transformed)
    * ``y_encoded``: Categorical labels with binned targets and pathway genes
    * ``y_binary``: Binary labels (1 for targets/pathway genes, 0 for non-targets)
    :rtype: dict

    :raises Exception: May raise exceptions during quantile binning if insufficient unique values exist

    .. note::

        - clinical scores are log2-transformed as ``log2(score + 1)``
        - Positive targets are binned into categories: ``target_0``, ``target_1``, etc.
        - Negative samples are randomly selected to match the number of positive + pathway genes
        - Pathway genes are assigned a clinical score of 1 and labeled as ``pathway_gene``
        - The function sets pandas chained assignment warnings to None
    """
    options.mode.chained_assignment = None  # default='warn'
    random.seed(rand_seed)
    # prepare KG features
    if term_num:
        X = X.sample(n = term_num, axis = 1, random_state=rand_seed)
    # prepare clinical scores
    y = y[['Target Gene', 'Clinical Score']]
    y['Clinical Score'] = log2(y['Clinical Score'] + 1)
    y.index = y['Target Gene']
    y = y.drop(columns=['Target Gene'])
    # merge clinical scores and KG features
    y = y.join(X, how = 'right')
    # add negative targets as the number of positive
    y_pos = y[~y['Clinical Score'].isna()]
    try:
        y_pos['Clinical Score Binned'] = qcut(y_pos['Clinical Score'], q=bins, labels=['target_' + str(x) for x in list(range(bins))])
    except:
        y_pos['Clinical Score Binned'] = "target"
        print("Binning of cancer targets didn't work, using only one bin!")
    # prepare pathway genes
    y_pg = DataFrame()
    if pathway_genes:
        pathway_genes = [g for g in pathway_genes if g not in y_pos.index.tolist() and g not in known_targets]
        y_pg = y[y.index.isin(pathway_genes)]
        y_pg['Clinical Score'] = 1
        y_pg['Clinical Score Binned'] = 'pathway_gene'
    else:
        print("No pathway genes were provided!")
    y_neg = y[(y['Clinical Score'].isna()) & (~y.index.isin(pathway_genes)) & (~y.index.isin(known_targets))].sample(y_pos.shape[0] + y_pg.shape[0], random_state=rand_seed)
    y_neg['Clinical Score'] = -1
    y_neg['Clinical Score Binned'] = 'not_target'
    y = concat([y_pos, y_neg, y_pg])
    # shuffle targets
    y = y.sample(frac=1, random_state=rand_seed)

    # CREATE OBJECTS FOR MODELLING
    # create X for modelling
    X_out = y.iloc[:,1:-1]
    X_out.index = y.index
    # create y for modelling
    y_out = y['Clinical Score']
    y_out.index = y.index
    y_encoded = y['Clinical Score Binned']
    y_encoded.index = y.index
    # binarise y for binary classification
    y_binary = (y_out > 0).astype(int)

    return({
        'X': X_out,
        'y': y_out,
        'y_encoded': y_encoded,
        'y_binary': y_binary
    })

def cv_pipeline(X: DataFrame, y: DataFrame, y_slot = 'y_binary', bins: int = 3, pathway_genes: List = [], classifier: RandomForestClassifier = RandomForestClassifier(), cv: StratifiedKFold = StratifiedKFold(), scoring = 'roc_auc', n_iterations = 10, shuffle_scores = False) -> List:
    """
    Perform cross-validation pipeline for classification tasks.

    This function executes a cross-validation pipeline over multiple iterations,
    preprocessing data and evaluating a classifier using specified scoring metrics.

    :param X: Input features DataFrame
    :type X: DataFrame
    :param y: Target variable DataFrame
    :type y: DataFrame
    :param y_slot: Column name in the preprocessed result to use as target variable, defaults to ``y_binary``
    :type y_slot: str, optional
    :param bins: Number of bins for data preprocessing, defaults to 3
    :type bins: int, optional
    :param pathway_genes: List of pathway genes to be used in preprocessing, defaults to []
    :type pathway_genes: List, optional
    :param classifier: Classifier instance to use for cross-validation, defaults to RandomForestClassifier()
    :type classifier: RandomForestClassifier, optional
    :param cv: Cross-validation splitting strategy, defaults to StratifiedKFold()
    :type cv: StratifiedKFold, optional
    :param scoring: Scoring metric for evaluation, defaults to ``roc_auc``
    :type scoring: str, optional
    :param n_iterations: Number of iterations to run the pipeline, defaults to 10
    :type n_iterations: int, optional
    :param shuffle_scores: Whether to shuffle target variable for permutation testing, defaults to False
    :type shuffle_scores: bool, optional
    :return: List of cross-validation scores from each iteration
    :rtype: List
    """
    score = []
    for i in range(n_iterations):
        res = pre_model(X, y, bins = bins, pathway_genes = pathway_genes, rand_seed = i)
        if shuffle_scores:
            score.append(mean(cross_val_score(classifier, res['X'], res[y_slot].sample(frac=1), scoring=scoring, cv = cv)))
        else:
            score.append(mean(cross_val_score(classifier, res['X'], res[y_slot], scoring=scoring, cv = cv)))

    return(score)

def prepare_upset(breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular, mode):
    """
    Prepare data for UpSet plot visualization.

    This function processes disease-related data and converts it into a format
    suitable for UpSet plot generation using the `from_contents` function.

    :param breast: Breast cancer data. In ``ct`` mode, should be a DataFrame with
                   ``Target Gene`` column. In ``pg`` mode, should be a list.
    :type breast: pandas.DataFrame or list
    :param lung: Lung cancer data. In ``ct`` mode, should be a DataFrame with
                 ``Target Gene`` column. In ``pg`` mode, should be a list.
    :type lung: pandas.DataFrame or list
    :param prostate: Prostate cancer data. In ``ct`` mode, should be a DataFrame with
                     ``Target Gene`` column. In ``pg`` mode, should be a list.
    :type prostate: pandas.DataFrame or list
    :param melanoma: Melanoma data. In ``ct`` mode, should be a DataFrame with
                     ``Target Gene`` column. In ``pg`` mode, should be a list.
    :type melanoma: pandas.DataFrame or list
    :param bowel: Bowel cancer data. In ``ct`` mode, should be a DataFrame with
                  ``Target Gene`` column. In ``pg`` mode, should be a list.
    :type bowel: pandas.DataFrame or list
    :param diabetes: Diabetes data. In ``ct`` mode, should be a DataFrame with
                     ``Target Gene`` column. In ``pg`` mode, should be a list.
    :type diabetes: pandas.DataFrame or list
    :param cardiovascular: Cardiovascular disease data. In ``ct`` mode, should be a
                           DataFrame with ``Target Gene`` column. In ``pg`` mode,
                           should be a list.
    :type cardiovascular: pandas.DataFrame or list
    :param mode: Processing mode. ``ct`` extracts ``Target Gene`` column from DataFrames,
                 ``pg`` uses the data directly as lists.
    :type mode: str
    :return: Dictionary formatted for UpSet plot with disease names as keys and
             gene lists or data lists as values.
    :rtype: dict
    :raises ValueError: If mode is not ``ct`` or ``pg``.
    """
    if mode == 'ct':
        return from_contents(
            {
                "breast": breast['Target Gene'].tolist(), 
                "lung": lung['Target Gene'].tolist(), 
                "prostate": prostate['Target Gene'].tolist(), 
                "melanoma": melanoma['Target Gene'].tolist(), 
                "bowel": bowel['Target Gene'].tolist(), 
                "diabetes": diabetes['Target Gene'].tolist(), 
                "cardiovascular": cardiovascular['Target Gene'].tolist()
            }
        )
    elif mode == 'pg':
        return from_contents(
            {
                "breast": breast, 
                "lung": lung, 
                "prostate": prostate, 
                "melanoma": melanoma, 
                "bowel": bowel, 
                "diabetes": diabetes, 
                "cardiovascular": cardiovascular
            }
        )
    else:
        raise ValueError("Mode must be either 'ct' or 'pg'")

def create_upset_plot(indications, min_subset_size):
    """
    Create an UpSet plot for visualizing set intersections.

    :param indications: Data structure containing set membership information for creating the UpSet plot
    :type indications: pandas.DataFrame or similar data structure compatible with UpSet
    :param min_subset_size: Minimum size threshold for subsets to be displayed in the plot
    :type min_subset_size: int
    :return: An UpSet plot object configured with the specified parameters
    :rtype: UpSet
    :raises TypeError: If indications is not a compatible data structure
    :raises ValueError: If min_subset_size is negative

    .. note::

        The plot is configured with the following settings:
        
        - subset_size: "count" - shows count of elements in each subset
        - orientation: "vertical" - displays plot in vertical orientation
        - show_counts: "{:d}" - formats counts as integers
        - sort_by: ``cardinality`` - sorts subsets by their size
        - sort_categories_by: ``input`` - maintains input order for categories
        - min_subset_size: filters out subsets smaller than the specified threshold

    .. seealso::

        `UpSet documentation <https://upsetplot.readthedocs.io/>`_
    """
    return UpSet(
        indications, 
        subset_size="count", 
        orientation="vertical", 
        show_counts="{:d}", 
        sort_by='cardinality', 
        sort_categories_by = 'input',
        min_subset_size = min_subset_size,
    )

# run when file is directly executed
if __name__ == '__main__': 
    # trs = get_clinical_trials(search="Breast Cancer")
    # t = ttd(trials = trs)
    # d = drugbank(trials = trs)
    # trs.to_csv("breast_clinical_trials.csv", index = False)
    # t.to_csv("breast_ttd.csv", index = False)
    # d.to_csv("breast_drugbank.csv", index = False)

    # biom_attr = get_biomart_attributes()
    # biom_attr.to_csv("biomart_attributes.csv", index = False)

    biom = biomart(attributes=['hgnc_symbol', 'uniprot_isoform'])
    biom.to_csv("biomart_genes.csv", index = False)

    # # 'Breast Cancer', 
    # # 'Lung Cancer',
    # # 'Prostate Cancer',
    # # 'Bowel Cancer',
    # # 'Melanoma',
    # # 'Diabetes Mellitus Type 2',
    # # 'Cardiovascular Disease',
    # trs = get_clinical_trials(search="Breast Cancer")
    # print(trs)
    # db = drugbank(trs)
    # print(db)
    # scores = get_clinical_scores(db)
    # print(scores)
    # df = get_pathway_genes("acute myeloid leukemia")
    # print(df.loc["FLT3", ["gene_count", "rank"]])
    # breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular = load_clinical_scores(date="2025-11-11")
    # print('Clinical scores:\n\n')
    # print([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular])
    # print('All target genes:\n\n')
    # known_targets = get_all_targets([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular])
    # print(known_targets)
    # print('Cut clinical scores:\n\n')
    # print(cut_clinical_scores([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular], lowest_score = 10))
    # breast_pg, lung_pg, prostate_pg, melanoma_pg, bowel_pg, diabetes_pg, cardiovascular_pg = load_pathway_genes(date='2025-09-15', n=50)
    # print('Uniquified clinical scores:\n\n')
    # print(uniquify_clinical_scores([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular]))
    # print('Uniquified pathway genes:\n\n')
    # print(uniquify_pathway_genes([breast_pg, lung_pg, prostate_pg, melanoma_pg, bowel_pg, diabetes_pg, cardiovascular_pg]))
    # print(prepare_upset(breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular, mode='ct'))

    # # X is always bigger than y!!!
    # X = DataFrame({
    #     'term1' : [0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0, 1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2, 0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0, 1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2], 
    #     'term2' : [1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2, 2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1, 1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2, 2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1], 
    #     'term3' : [2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1, 3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2, 2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1, 3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2], 
    #     'term4' : [3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2, 9, 2, 1, 3, 4, 5, 6, 7, 5, 7, 2, 3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2, 9, 2, 1, 3, 4, 5, 6, 7, 5, 7, 2], 
    #     'term5' : [4, 5, 6, 7, 8, 6, 5, 7, 2, 9, 3, 0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0, 4, 5, 6, 7, 8, 6, 5, 7, 2, 9, 3, 0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0]
    # })
    # y = DataFrame({
    #     'Target Gene' : ['gene1', 'gene2', 'gene3', 'gene4', 'gene5', 'gene6', 'gene7', 'gene8', 'gene9', 'gene10', 'gene11', 'gene12', 'gene13', 'gene14', 'gene15'], 
    #     'Clinical Score' : [1, 1, 1, 4, 5, 10, 5, 3, 2, 5, 1, 100, 200, 300, 400]
    # })
    # # X is always bigger than y!!!
    # X.index = ['gene1', 'gene2', 'gene3', 'gene4', 'gene5', 'gene6', 'gene7', 'gene8', 'gene9', 'gene10', 'gene11', 'gene12', 'gene13', 'gene14', 'gene15', 'gene16', 'gene17', 'gene18', 'gene19', 'gene20', 'gene21', 'gene22', 'gene23', 'gene24', 'gene25', 'gene26', 'gene27', 'gene28', 'gene29', 'gene30', 'gene31', 'gene32', 'gene33', 'gene34', 'gene35', 'gene36', 'gene37', 'gene38', 'gene39', 'gene40', 'gene41', 'gene42', 'gene43', 'gene44']
    # print('\nInput term matrix:')
    # print(X)
    # print('\nInput clinical scores:')
    # print(y)
    # print('\nCheck binning:')
    # res = pre_model(X, y, bins = 5)
    # print(res['y_encoded'])

    # known_targets = ['gene32', 'gene33']

    # res = pre_model(X, y, known_targets = known_targets, bins = 5)
    # print(res['y_encoded'])

    # print('\nResults of cross validation pipeline:')
    # print(cv_pipeline(X, y, n_iterations = 3))
    # print(cv_pipeline(X, y, y_slot = 'y_encoded', scoring = 'accuracy', n_iterations = 3))
