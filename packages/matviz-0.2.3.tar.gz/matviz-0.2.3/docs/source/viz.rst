viz module
==========
Graphic functions that are helpful.



    To make use of everything at once run::
    
    >>from viz import *


.. automodule:: viz
   :members: plot_range, plot_range_idx , plot_cdf , cplot , plot_diag , plot_zero , subplotter , pop_all , suplabel , streamgraph , nicefy  ,xylim , xyscale
   :undoc-members:
   :show-inheritance:
