matviz
======

.. toctree::
   :maxdepth: 4

   histogram_utils
   viz
