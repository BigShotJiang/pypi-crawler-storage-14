histogram\_utils module
=======================
Includes awesome functions for making nice 1D and 2D histograms.



    To make use of everything at once run::
    
    >>from helpers_utils import *




.. automodule:: histogram_utils
   :members: ndhist, nhist
   :undoc-members:
   :show-inheritance: