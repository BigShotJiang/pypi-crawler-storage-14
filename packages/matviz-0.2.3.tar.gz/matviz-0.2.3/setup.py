#!/usr/bin/env python
"""
Setup configuration for matviz.

Modern configuration is in pyproject.toml.
This file exists for backward compatibility.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
