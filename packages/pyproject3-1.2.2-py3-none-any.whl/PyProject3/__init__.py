#!/usr/bin/env python
# coding=utf-8
"""
ChangeLog:
- 1.2.1: fix for rustpy
- 1.2.2: add Makefile and fix some bugs for rustpy
"""
__version__ = '1.2.2'

from .project import *
from .create_project import *



