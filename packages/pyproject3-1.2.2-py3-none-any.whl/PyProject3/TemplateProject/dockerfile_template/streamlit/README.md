

```bash

python -m venv .venv
pip install -r requirements.txt

# for mac / linux only
.venv/bin/streamlit run app.py

# for windows only
.venv\Scripts\strealit.exe run app.py

```