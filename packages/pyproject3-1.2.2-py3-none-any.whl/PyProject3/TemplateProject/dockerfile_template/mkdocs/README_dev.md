

```bash
python -m venv .venv

pip install -r requriments.txt

mkdocs serve -a 0.0.0.0:8001
```