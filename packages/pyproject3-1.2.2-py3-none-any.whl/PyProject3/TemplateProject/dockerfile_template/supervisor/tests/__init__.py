
from xmov_benchmark import *


print(f"Hello, xmov_benchmark!")

    