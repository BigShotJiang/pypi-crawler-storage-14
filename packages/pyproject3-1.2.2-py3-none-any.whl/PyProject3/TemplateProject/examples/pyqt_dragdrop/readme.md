
[原文](https://blog.csdn.net/chengmo123/article/details/93468426)
```
MIME意为多功能Internet邮件扩展，它设计的最初目的是为了在发送电子邮件时附加多媒体数据，让邮件客户程序能根据其类型进行处理。然而当它被HTTP协议支持之后，它的意义就更为显著了。它使得HTTP传输的不仅是普通的文本，而变得丰富多彩。 
每个MIME类型由两部分组成，前面是数据的大类别，例如声音audio、图象image等，后面定义具体的种类。 
常见的MIME类型(通用型)： 
超文本标记语言文本 .html text/html 
xml文档 .xml text/xml 
XHTML文档 .xhtml application/xhtml+xml 
普通文本 .txt text/plain 
RTF文本 .rtf application/rtf 
PDF文档 .pdf application/pdf 
Microsoft Word文件 .word application/msword 
PNG图像 .png image/png 
GIF图形 .gif image/gif 
JPEG图形 .jpeg,.jpg image/jpeg 
au声音文件 .au audio/basic 
MIDI音乐文件 mid,.midi audio/midi,audio/x-midi 
RealAudio音乐文件 .ra, .ram audio/x-pn-realaudio 
MPEG文件 .mpg,.mpeg video/mpeg 
AVI文件 .avi video/x-msvideo 
GZIP文件 .gz application/x-gzip 
TAR文件 .tar application/x-tar 
任意的二进制数据 application/octet-stream
```