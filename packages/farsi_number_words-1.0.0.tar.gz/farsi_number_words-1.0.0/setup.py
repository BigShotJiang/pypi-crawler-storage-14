from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="farsi-number-words",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Complete Persian number to words converter with multiple output formats",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Linguistic",
    ],
    python_requires=">=3.7",
    install_requires=[
        "flask>=2.0.0",
    ],
    keywords="persian, farsi, number, words, converter, currency, text",
    url="https://github.com/yourusername/farsi-number-words",
    entry_points={
        'console_scripts': [
            'farsi-number=farsi_number.cli:main',
        ],
    },
)