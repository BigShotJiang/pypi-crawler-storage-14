pip install farsi-number-words

# استفاده در پایتون
from farsi_number import NumberToWords
converter = NumberToWords()
print(converter.convert(1250000, currency='toman'))

# استفاده از CLI
farsi-number 1250000 500000 --currency toman --output json