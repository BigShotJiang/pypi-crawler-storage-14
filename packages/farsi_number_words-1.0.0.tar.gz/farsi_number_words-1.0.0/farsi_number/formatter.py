import json
import csv
from datetime import datetime

class CurrencyFormatter:
    """Format numbers as currency with various output formats"""
    
    def __init__(self):
        self.currencies = {
            'toman': 'تومان',
            'rial': 'ریال', 
            'dollar': 'دلار',
            'euro': 'یورو'
        }
    
    def format_to_text(self, number, currency='toman', include_words=True):
        """Format number as text"""
        from .converter import NumberToWords
        
        converter = NumberToWords()
        
        result = {
            'number': number,
            'formatted': f"{number:,.0f}",
            'currency': self.currencies.get(currency, currency)
        }
        
        if include_words:
            result['words'] = converter.convert(number, currency=currency)
        
        return result
    
    def format_to_json(self, numbers, currency='toman'):
        """Format numbers to JSON"""
        results = []
        
        for number in numbers:
            result = self.format_to_text(number, currency, True)
            results.append(result)
        
        return json.dumps(results, ensure_ascii=False, indent=2)
    
    def format_to_csv(self, numbers, currency='toman', filename=None):
        """Format numbers to CSV"""
        import io
        
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Number', 'Formatted', 'Words', 'Currency'])
        
        from .converter import NumberToWords
        converter = NumberToWords()
        
        for number in numbers:
            words = converter.convert(number, currency=currency)
            formatted = f"{number:,.0f}"
            writer.writerow([number, formatted, words, self.currencies.get(currency, currency)])
        
        csv_content = output.getvalue()
        
        if filename:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(csv_content)
        
        return csv_content
    
    def format_to_html(self, numbers, currency='toman', title="تبدیل اعداد به حروف"):
        """Generate HTML table"""
        from .converter import NumberToWords
        converter = NumberToWords()
        
        html = f"""
        <!DOCTYPE html>
        <html dir="rtl" lang="fa">
        <head>
            <meta charset="UTF-8">
            <title>{title}</title>
            <style>
                body {{ font-family: Tahoma, Arial, sans-serif; direction: rtl; padding: 20px; }}
                table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 12px; text-align: right; }}
                th {{ background-color: #f2f2f2; }}
                tr:nth-child(even) {{ background-color: #f9f9f9; }}
                .header {{ color: #333; margin-bottom: 20px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>{title}</h1>
                <p>تاریخ تولید: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
                <p>ارز: {self.currencies.get(currency, currency)}</p>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>عدد</th>
                        <th>فرمت شده</th>
                        <th>حروف</th>
                    </tr>
                </thead>
                <tbody>
        """
        
        for number in numbers:
            words = converter.convert(number, currency=currency)
            formatted = f"{number:,.0f}"
            html += f"""
                    <tr>
                        <td>{number}</td>
                        <td>{formatted}</td>
                        <td>{words}</td>
                    </tr>
            """
        
        html += """
                </tbody>
            </table>
        </body>
        </html>
        """
        return html

class ScientificFormatter:
    """Format numbers in scientific contexts"""
    
    def to_scientific_words(self, number):
        """Convert scientific notation to words"""
        from .converter import NumberToWords
        
        if abs(number) < 0.001 or abs(number) >= 1000000:
            scientific = f"{number:.2e}"
            base, exponent = scientific.split('e')
            base_num = float(base)
            exp_num = int(exponent)
            
            converter = NumberToWords()
            base_words = converter.convert(base_num, decimal_places=2)
            exp_words = converter.convert(abs(exp_num))
            
            if exp_num >= 0:
                return f"{base_words} ضرب در ده به توان {exp_words}"
            else:
                return f"{base_words} ضرب در ده به توان منفی {exp_words}"
        else:
            converter = NumberToWords()
            return converter.convert(number, decimal_places=2)