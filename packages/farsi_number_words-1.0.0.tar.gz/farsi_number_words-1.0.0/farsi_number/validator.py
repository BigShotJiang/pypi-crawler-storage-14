import re

class NumberValidator:
    """Validate and parse different number formats"""
    
    def __init__(self):
        self.persian_digits = '۰۱۲۳۴۵۶۷۸۹'
        self.arabic_digits = '٠١٢٣٤٥٦٧٨٩'
    
    def normalize_number(self, number_input):
        """Normalize different number formats to standard float"""
        if isinstance(number_input, (int, float)):
            return float(number_input)
        
        # Convert to string
        number_str = str(number_input).strip()
        
        # Replace Persian and Arabic digits
        for i, digit in enumerate(self.persian_digits):
            number_str = number_str.replace(digit, str(i))
        
        for i, digit in enumerate(self.arabic_digits):
            number_str = number_str.replace(digit, str(i))
        
        # Remove commas and extra spaces
        number_str = number_str.replace(',', '').replace(' ', '')
        
        # Handle different decimal separators
        number_str = number_str.replace('/', '.').replace('\\', '.')
        
        try:
            return float(number_str)
        except ValueError:
            raise ValueError(f"عدد نامعتبر: {number_input}")
    
    def validate_iranian_phone(self, number):
        """Validate Iranian phone number"""
        pattern = r'^(\+98|0)?9\d{9}$'
        number_clean = re.sub(r'\D', '', str(number))
        return bool(re.match(pattern, number_clean))
    
    def validate_national_id(self, national_id):
        """Validate Iranian national ID"""
        if not re.match(r'^\d{10}$', str(national_id)):
            return False
        
        check = int(national_id[9])
        s = sum(int(national_id[i]) * (10 - i) for i in range(9)) % 11
        return (s < 2 and check == s) or (s >= 2 and check + s == 11)
    
    def extract_numbers_from_text(self, text):
        """Extract all numbers from text"""
        patterns = [
            r'\d+\.\d+',  # Decimal numbers
            r'\d+',       # Integer numbers
        ]
        
        numbers = []
        for pattern in patterns:
            matches = re.findall(pattern, text)
            numbers.extend([self.normalize_number(match) for match in matches])
        
        return numbers