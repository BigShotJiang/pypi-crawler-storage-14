import argparse
import sys
import json

def main():
    """Command Line Interface for Persian Number Converter"""
    parser = argparse.ArgumentParser(description='تبدیل اعداد به حروف فارسی')
    
    parser.add_argument('numbers', nargs='*', help='اعداد برای تبدیل')
    parser.add_argument('-f', '--file', help='فایل حاوی اعداد')
    parser.add_argument('-c', '--currency', choices=['toman', 'rial', 'dollar', 'euro'], 
                       default='toman', help='نوع ارز')
    parser.add_argument('-o', '--output', choices=['text', 'json', 'csv', 'html'], 
                       default='text', help='فرمت خروجی')
    parser.add_argument('--output-file', help='ذخیره در فایل')
    parser.add_argument('-d', '--decimals', type=int, default=2, help='تعداد اعشار')
    
    args = parser.parse_args()
    
    # Read numbers from different sources
    numbers = []
    
    if args.numbers:
        numbers.extend([float(num) for num in args.numbers])
    
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                file_numbers = [float(line.strip()) for line in f if line.strip()]
                numbers.extend(file_numbers)
        except FileNotFoundError:
            print(f"خطا: فایل {args.file} یافت نشد")
            sys.exit(1)
    
    if not numbers:
        print("لطفاً اعداد را وارد کنید")
        parser.print_help()
        sys.exit(1)
    
    # Convert numbers
    from .converter import NumberToWords
    from .formatter import CurrencyFormatter
    
    converter = NumberToWords()
    formatter = CurrencyFormatter()
    
    try:
        if args.output == 'text':
            for num in numbers:
                words = converter.convert(num, args.decimals, args.currency)
                print(f"{num:,.2f} = {words}")
                
        elif args.output == 'json':
            result = formatter.format_to_json(numbers, args.currency)
            print(result)
            
        elif args.output == 'csv':
            csv_content = formatter.format_to_csv(numbers, args.currency)
            print(csv_content)
            
        elif args.output == 'html':
            html_content = formatter.format_to_html(numbers, args.currency)
            print(html_content)
        
        # Save to file if specified
        if args.output_file:
            with open(args.output_file, 'w', encoding='utf-8') as f:
                if args.output == 'text':
                    for num in numbers:
                        words = converter.convert(num, args.decimals, args.currency)
                        f.write(f"{num:,.2f} = {words}\n")
                elif args.output == 'json':
                    f.write(formatter.format_to_json(numbers, args.currency))
                elif args.output == 'csv':
                    formatter.format_to_csv(numbers, args.currency, args.output_file)
                elif args.output == 'html':
                    f.write(html_content)
            
            print(f"نتایج در {args.output_file} ذخیره شد")
            
    except Exception as e:
        print(f"خطا: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()