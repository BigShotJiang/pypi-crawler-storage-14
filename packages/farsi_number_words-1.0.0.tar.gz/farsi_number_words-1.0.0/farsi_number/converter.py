class NumberToWords:
    """
    Convert numbers to Persian words with various formatting options
    """
    
    def __init__(self):
        self.units = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه']
        self.teens = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده']
        self.tens = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود']
        self.hundreds = ['', 'صد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد']
        self.scales = [
            ('', ''),
            ('هزار', 'هزار'),
            ('میلیون', 'میلیون'),
            ('میلیارد', 'میلیارد'),
            ('تریلیون', 'تریلیون'),
            ('کوادریلیون', 'کوادریلیون')
        ]
    
    def convert(self, number:int=None, decimal_places=2, currency=None):
        """
        Convert number to Persian words
        
        Args:
            number: Number to convert (int, float, or string)
            decimal_places: Number of decimal places to show
            currency: Currency type ('toman', 'rial', 'dollar', 'euro')
        
        Returns:
            str: Number in Persian words
        """
        try:
            # Validate and parse input
            if isinstance(number, str):
                number = number.replace(',', '')
            
            num = float(number)
            
            # Handle negative numbers
            if num < 0:
                return "منفی " + self.convert(abs(num), decimal_places, currency)
            
            # Split integer and decimal parts
            integer_part = int(num)
            decimal_part = round(num - integer_part, decimal_places)
            
            # Convert integer part
            result = self._convert_integer(integer_part)
            
            # Add decimal part if exists
            if decimal_part > 0:
                decimal_str = str(decimal_part).split('.')[1]
                decimal_str = decimal_str.ljust(decimal_places, '0')[:decimal_places]
                decimal_words = self._convert_integer(int(decimal_str))
                result += " ممیز " + decimal_words
            
            # Add currency
            if currency:
                result = self._add_currency(result, currency, integer_part, decimal_part > 0)
            
            return result.strip()
            
        except (ValueError, TypeError):
            raise ValueError("عدد وارد شده معتبر نیست")
    
    def _convert_integer(self, number):
        """Convert integer number to words"""
        if number == 0:
            return "صفر"
        
        if number < 0:
            return "منفی " + self._convert_integer(-number)
        
        return self._convert_number_recursive(number).strip()
    
    def _convert_number_recursive(self, number):
        """Recursively convert number to words"""
        if number == 0:
            return ""
        
        if number < 10:
            return self.units[number]
        
        if number < 20:
            return self.teens[number - 10]
        
        if number < 100:
            return self.tens[number // 10] + (" و " + self._convert_number_recursive(number % 10) if number % 10 != 0 else "")
        
        if number < 1000:
            return self.hundreds[number // 100] + (" و " + self._convert_number_recursive(number % 100) if number % 100 != 0 else "")
        
        # Handle larger numbers
        for i, (scale_singular, scale_plural) in enumerate(self.scales[1:], 1):
            scale_value = 1000 ** i
            next_scale_value = 1000 ** (i + 1)
            
            if number < next_scale_value:
                scale_part = number // scale_value
                remainder = number % scale_value
                
                scale_word = scale_singular if scale_part == 1 else scale_plural
                result = self._convert_number_recursive(scale_part) + " " + scale_word
                
                if remainder > 0:
                    result += " و " + self._convert_number_recursive(remainder)
                
                return result
        
        return "عدد بسیار بزرگ"
    
    def _add_currency(self, words, currency, integer_part, has_decimal):
        """Add currency name to the words"""
        currency_words = {
            'toman': ('تومان', 'تومان'),
            'rial': ('ریال', 'ریال'),
            'dollar': ('دلار', 'دلار'),
            'euro': ('یورو', 'یورو')
        }
        
        if currency in currency_words:
            currency_word = currency_words[currency][0]
            return words + " " + currency_word
        
        return words
    
    def batch_convert(self, numbers:list=None, **kwargs):
        """
        Convert multiple numbers at once
        
        Args:
            numbers: List of numbers to convert
            **kwargs: Additional arguments for convert method
        
        Returns:
            list: List of converted number words
        """
        return [self.convert(num, **kwargs) for num in numbers]
    
    def to_ordinal(self, number):
        """
        Convert number to ordinal form
        
        Args:
            number: Number to convert
        
        Returns:
            str: Ordinal number in Persian
        """
        words = self.convert(number)
        
        ordinal_suffixes = {
            'یک': 'اول',
            'دو': 'دوم',
            'سه': 'سوم',
            'چهار': 'چهارم',
            'پنج': 'پنجم',
            'شش': 'ششم',
            'هفت': 'هفتم',
            'هشت': 'هشتم',
            'نه': 'نهم',
            'ده': 'دهم'
        }
        
        # Simple ordinal conversion
        for cardinal, ordinal in ordinal_suffixes.items():
            if words.endswith(cardinal):
                return words[:-len(cardinal)] + ordinal
        
        return words + 'م'