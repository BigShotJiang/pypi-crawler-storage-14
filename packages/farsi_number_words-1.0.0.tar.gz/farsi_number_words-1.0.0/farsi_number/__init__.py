from .converter import NumberToWords
from .formatter import CurrencyFormatter, ScientificFormatter
from .validator import NumberValidator
from .cli import main as cli_main

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    'NumberToWords',
    'CurrencyFormatter', 
    'ScientificFormatter',
    'NumberValidator',
    'cli_main'
]