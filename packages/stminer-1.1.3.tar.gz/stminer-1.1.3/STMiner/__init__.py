from .SPFinder import SPFinder

__version__ = '1.1.3'
__author__ = 'Peisen Sun <pssun@foxmail.com>'
__license__ = 'GPL-3.0'
