# Quick Start: Publishing to PyPI

**TL;DR - Publish in 5 minutes:**

## 1. Create PyPI Account & Token

1. Sign up: [https://pypi.org/account/register/](https://pypi.org/account/register/)
2. Verify email
3. Go to: [https://pypi.org/manage/account/token/](https://pypi.org/manage/account/token/)
4. Click "Add API token"
5. Name: `mcp-codemode`
6. Scope: "Entire account"
7. **Copy the token** (starts with `pypi-`)

## 2. Build & Publish

```bash
cd ~/codemode

# Clean previous builds
rm -rf dist/

# Build the package
uv build

# Publish (will prompt for token)
uv publish

# When prompted, paste your token: pypi-YOUR-TOKEN-HERE
```

## 3. Verify

```bash
# Wait 30 seconds for PyPI to index

# Test installation
uvx mcp-codemode --version
```

That's it! ✅

## For Goose Users

After publishing, update your Goose config:

```yaml
# ~/.config/goose/config.yaml
extensions:
  codemode:
    type: stdio
    enabled: true
    cmd: uvx
    args: ["mcp-codemode"]
```

Then reload Goose and the extension will auto-install from PyPI!

---

For detailed instructions, troubleshooting, and automation, see [PUBLISHING.md](./PUBLISHING.md).
