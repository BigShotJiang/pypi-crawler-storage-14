"""
MCP Code Mode - Universal Python Code Execution Server

Inspired by Cloudflare's "Code Mode": LLMs are better at writing code
than making tool calls because they've trained on millions of real repos.

Works with ANY MCP client:
- Goose
- Claude Desktop
- Cursor
- VS Code with Copilot
- Any MCP-compatible agent

Features:
- Execute any Python code to accomplish tasks
- Auto-install missing dependencies  
- Intelligent retry with learning from failures
- Persistent learning database
- Rich system context for better code generation
- Optional Docker sandboxing for security
"""

import subprocess
import tempfile
import os
import sys
import json
import platform
import hashlib
import traceback
import re
import shutil
import select
import threading
import queue
import base64
import mimetypes
import ast
import psutil
from pathlib import Path
from datetime import datetime
from typing import Optional, Any, Generator
from dataclasses import dataclass, asdict, field
from enum import Enum

from mcp.server.fastmcp import FastMCP, Context
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData, INTERNAL_ERROR

# ============================================================================
# Configuration
# ============================================================================

class ExecutionMode(str, Enum):
    """Code execution modes"""
    DIRECT = "direct"  # Run directly (fast, less secure)
    DOCKER = "docker"  # Run in Docker container (slower, more secure)
    # Future: PYODIDE = "pyodide"  # Run in WASM sandbox

# Directory for persistent data
DATA_DIR = Path.home() / ".mcp-pyrunner"
LEARNING_FILE = DATA_DIR / "learnings.json"
EXECUTION_LOG = DATA_DIR / "execution_log.json"
CONFIG_FILE = DATA_DIR / "config.json"

# Ensure directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Default configuration
DEFAULT_CONFIG = {
    "execution_mode": ExecutionMode.DIRECT.value,
    "default_timeout": 60,
    "max_retries": 3,
    "auto_install": True,
    "docker_image": "python:3.12-slim",
    "allowed_packages": [],  # Empty = allow all
    "blocked_packages": ["os-sys"],  # Packages to never install
    "code_analysis": {
        "enabled": True,  # Run analysis before execution
        "block_on_critical": False,  # Block execution if critical issues found
        "show_report": True,  # Show analysis report in output
    },
    "resource_tracking": {
        "enabled": True,  # Track resource usage during execution
        "show_in_output": True,  # Display metrics in execution output
        "warn_cpu_percent": 90,  # Warn if CPU usage exceeds this %
        "warn_memory_mb": 500,  # Warn if memory usage exceeds this MB
    },
}

def load_config() -> dict:
    """Load or create configuration"""
    if CONFIG_FILE.exists():
        try:
            return {**DEFAULT_CONFIG, **json.loads(CONFIG_FILE.read_text())}
        except Exception:
            pass
    # Save default config on first run
    config = DEFAULT_CONFIG.copy()
    save_config(config)
    return config

def save_config(config: dict):
    """Save configuration"""
    CONFIG_FILE.write_text(json.dumps(config, indent=2))

CONFIG = load_config()

# Pre-installed libraries available for code execution
AVAILABLE_LIBRARIES = {
    # HTTP & Web
    "requests": "HTTP requests made easy",
    "httpx": "Modern async HTTP client",
    "aiohttp": "Async HTTP client/server",
    "beautifulsoup4": "HTML/XML parsing",
    "lxml": "Fast XML/HTML processing",
    "selenium": "Browser automation (if installed)",
    
    # Data Processing
    "pandas": "Data manipulation and analysis",
    "numpy": "Numerical computing",
    "json": "JSON encoding/decoding (stdlib)",
    "csv": "CSV file handling (stdlib)",
    "yaml": "YAML parsing (pyyaml)",
    
    # Files & System
    "pathlib": "Object-oriented paths (stdlib)",
    "os": "OS interface (stdlib)",
    "shutil": "File operations (stdlib)",
    "subprocess": "Process execution (stdlib)",
    "tempfile": "Temporary files (stdlib)",
    
    # Images
    "PIL": "Image processing (Pillow)",
    "cv2": "Computer vision (opencv-python)",
    
    # Utilities
    "re": "Regular expressions (stdlib)",
    "datetime": "Date/time handling (stdlib)",
    "hashlib": "Hashing (stdlib)",
    "base64": "Base64 encoding (stdlib)",
    "typing": "Type hints (stdlib)",
}

# Module name to pip package mapping
MODULE_TO_PACKAGE = {
    "cv2": "opencv-python",
    "PIL": "Pillow",
    "sklearn": "scikit-learn",
    "yaml": "pyyaml",
    "bs4": "beautifulsoup4",
    "dotenv": "python-dotenv",
    "skimage": "scikit-image",
}

# ============================================================================
# Initialize MCP Server
# ============================================================================

mcp = FastMCP(
    "mcp-codemode",
    instructions="""Universal Python code execution server with AUTOMATIC LEARNING.

Instead of using many specialized tools, write Python code to accomplish ANY task.
LLMs are better at writing code than making tool calls - leverage this!

🎯 IMPORTANT: This server learns from failures automatically!
- When code fails, the error and solution are recorded
- Call get_system_context() FIRST to see past learnings and avoid repeating mistakes
- Past learnings show you what failed before and how to fix it
- Success rate improves over time as the system learns

Available MCP Resources (auto-accessible):
- learnings://database - Complete learnings database with error patterns and solutions
- system://context - System info, Python version, package managers, configuration
- executions://recent - Recent execution history with success/failure stats and metrics

Available tools:
- get_system_context: Get environment info + PAST LEARNINGS (call this FIRST!)
- analyze_code: Analyze code for security/quality issues before running
- run_python: Run Python code (auto-analyzes, auto-installs missing packages)
- run_python_stream: Run Python with real-time streaming output
- run_with_retry: Run with intelligent retry and error learning
- add_learning: Record solutions for future reference
- get_learnings: View/search past learnings
- pip_install: Pre-install a specific package
- configure: View/update settings

Tips:
- ALWAYS call get_system_context() first to see learnings and avoid known errors
- Use print() to output results
- Use run_python_stream for long-running tasks
- Complex tasks can be done in one code block
- Packages are auto-installed on ImportError
- The system learns from every error and gets smarter over time
- Resources are automatically available to clients that support them
"""
)

# ============================================================================
# Learning System
# ============================================================================

@dataclass
class Learning:
    """A learned pattern from execution errors"""
    error_pattern: str
    solution: str
    context: str
    success_count: int = 0
    failure_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_used: str = field(default_factory=lambda: datetime.now().isoformat())
    tags: list[str] = field(default_factory=list)


class LearningStore:
    """Persistent store for execution learnings"""
    
    def __init__(self, filepath: Path = LEARNING_FILE):
        self.filepath = filepath
        self.learnings: list[Learning] = []
        self._load()
    
    def _load(self):
        if self.filepath.exists():
            try:
                data = json.loads(self.filepath.read_text())
                self.learnings = [Learning(**l) for l in data]
            except Exception:
                self.learnings = []
    
    def _save(self):
        data = [asdict(l) for l in self.learnings]
        self.filepath.write_text(json.dumps(data, indent=2))
    
    def add(self, error_pattern: str, solution: str, context: str, tags: list[str] = None):
        """Add or update a learning"""
        tags = tags or []
        
        # Check for existing pattern
        for l in self.learnings:
            if l.error_pattern == error_pattern:
                l.solution = solution
                l.context = context
                l.success_count += 1
                l.last_used = datetime.now().isoformat()
                l.tags = list(set(l.tags + tags))
                self._save()
                return
        
        self.learnings.append(Learning(
            error_pattern=error_pattern,
            solution=solution,
            context=context,
            tags=tags
        ))
        self._save()
    
    def find_relevant(self, error: str, code: str = "", limit: int = 5) -> list[Learning]:
        """Find learnings that might help with an error"""
        relevant = []
        error_lower = error.lower()
        
        for learning in self.learnings:
            score = 0
            try:
                if re.search(learning.error_pattern, error, re.IGNORECASE):
                    score += 10
            except re.error:
                if learning.error_pattern.lower() in error_lower:
                    score += 5
            
            # Boost by success rate
            if learning.success_count > 0:
                score += min(learning.success_count, 5)
            
            if score > 0:
                relevant.append((score, learning))
        
        relevant.sort(key=lambda x: -x[0])
        return [l for _, l in relevant[:limit]]
    
    def mark_success(self, error_pattern: str):
        """Mark a learning as successfully used"""
        for l in self.learnings:
            if l.error_pattern == error_pattern:
                l.success_count += 1
                l.last_used = datetime.now().isoformat()
                self._save()
                return
    
    def mark_failure(self, error_pattern: str):
        """Mark a learning as failed"""
        for l in self.learnings:
            if l.error_pattern == error_pattern:
                l.failure_count += 1
                self._save()
                return
    
    def get_summary(self) -> str:
        """Get a summary of all learnings"""
        if not self.learnings:
            return "No learnings recorded yet. Execute code and learn from errors!"
        
        lines = [f"📚 {len(self.learnings)} learnings recorded:\n"]
        
        # Sort by success count
        sorted_learnings = sorted(
            self.learnings, 
            key=lambda x: x.success_count, 
            reverse=True
        )
        
        for i, l in enumerate(sorted_learnings[:15], 1):
            pattern_short = l.error_pattern[:40] + "..." if len(l.error_pattern) > 40 else l.error_pattern
            lines.append(f"{i}. [{l.success_count}✓/{l.failure_count}✗] {pattern_short}")
            lines.append(f"   → {l.solution[:60]}...")
        
        if len(self.learnings) > 15:
            lines.append(f"\n   ... and {len(self.learnings) - 15} more")
        
        return "\n".join(lines)


# Global learning store
learning_store = LearningStore()

# ============================================================================
# Code Analysis System
# ============================================================================

class AnalysisIssue:
    """Represents a code analysis finding"""
    def __init__(
        self,
        severity: str,  # "info", "warning", "critical"
        category: str,
        message: str,
        line: Optional[int] = None,
        suggestion: Optional[str] = None
    ):
        self.severity = severity
        self.category = category
        self.message = message
        self.line = line
        self.suggestion = suggestion

    def __repr__(self):
        location = f" (line {self.line})" if self.line else ""
        severity_emoji = {
            "info": "ℹ️",
            "warning": "⚠️",
            "critical": "🚨"
        }.get(self.severity, "•")

        result = f"{severity_emoji} [{self.severity.upper()}] {self.message}{location}"
        if self.suggestion:
            result += f"\n   💡 Suggestion: {self.suggestion}"
        return result


class CodeAnalyzer(ast.NodeVisitor):
    """AST-based code analyzer for security and quality checks"""

    def __init__(self, code: str, config: dict):
        self.code = code
        self.config = config
        self.issues: list[AnalysisIssue] = []
        self.tree = None

        # Analysis settings
        self.enabled = config.get("code_analysis", {}).get("enabled", True)
        self.block_on_critical = config.get("code_analysis", {}).get("block_on_critical", False)

        # Dangerous patterns to detect
        self.dangerous_functions = {
            "eval": "Executes arbitrary code - use ast.literal_eval() for safe evaluation",
            "exec": "Executes arbitrary code - avoid if possible",
            "compile": "Compiles code strings - ensure input is trusted",
            "__import__": "Dynamic imports can be dangerous - use importlib if needed",
        }

        self.dangerous_modules = {
            "os.system": "Use subprocess.run() instead for better security",
            "commands": "Deprecated and unsafe - use subprocess instead",
        }

        self.risky_operations = {
            "rmtree": "Recursive directory deletion - ensure path is correct",
            "unlink": "File deletion - verify path before deleting",
            "remove": "File deletion - verify path before deleting",
            "chmod": "Changes file permissions - use with caution",
            "chown": "Changes file ownership - requires elevated privileges",
        }

    def analyze(self) -> list[AnalysisIssue]:
        """Run all analysis checks and return issues found"""
        if not self.enabled:
            return []

        # Check 1: Syntax validation
        try:
            self.tree = ast.parse(self.code)
        except SyntaxError as e:
            self.issues.append(AnalysisIssue(
                severity="critical",
                category="syntax",
                message=f"Syntax error: {e.msg}",
                line=e.lineno,
                suggestion="Fix syntax error before execution"
            ))
            return self.issues

        # Check 2: AST-based security analysis
        self.visit(self.tree)

        # Check 3: Pattern-based checks
        self._check_shell_injection()
        self._check_path_traversal()
        self._check_hardcoded_secrets()

        return self.issues

    def visit_Call(self, node: ast.Call):
        """Check function calls for dangerous operations"""
        # Check for dangerous built-in functions
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
            if func_name in self.dangerous_functions:
                self.issues.append(AnalysisIssue(
                    severity="critical",
                    category="security",
                    message=f"Dangerous function '{func_name}()' detected",
                    line=node.lineno,
                    suggestion=self.dangerous_functions[func_name]
                ))

        # Check for dangerous module methods (e.g., os.system)
        elif isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name):
                module = node.func.value.id
                method = node.func.attr
                full_name = f"{module}.{method}"

                if full_name in self.dangerous_modules:
                    self.issues.append(AnalysisIssue(
                        severity="critical",
                        category="security",
                        message=f"Dangerous operation '{full_name}()' detected",
                        line=node.lineno,
                        suggestion=self.dangerous_modules[full_name]
                    ))

                # Check for subprocess with shell=True
                if module == "subprocess" and method == "run":
                    for keyword in node.keywords:
                        if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant):
                            if keyword.value.value is True:
                                self.issues.append(AnalysisIssue(
                                    severity="warning",
                                    category="security",
                                    message="subprocess.run() with shell=True can be dangerous",
                                    line=node.lineno,
                                    suggestion="Use shell=False and pass command as list instead"
                                ))

                # Check for risky file operations
                if method in self.risky_operations:
                    self.issues.append(AnalysisIssue(
                        severity="warning",
                        category="file_operations",
                        message=f"Risky operation '{method}()' detected",
                        line=node.lineno,
                        suggestion=self.risky_operations[method]
                    ))

        self.generic_visit(node)

    def visit_Import(self, node: ast.Import):
        """Check imports for dangerous modules"""
        for alias in node.names:
            if alias.name in ["pickle", "marshal"]:
                self.issues.append(AnalysisIssue(
                    severity="warning",
                    category="security",
                    message=f"Importing '{alias.name}' - can execute arbitrary code when loading data",
                    line=node.lineno,
                    suggestion="Use json or other safe serialization formats"
                ))
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        """Check from-imports for dangerous functions"""
        if node.module == "pickle":
            self.issues.append(AnalysisIssue(
                severity="warning",
                category="security",
                message="Importing from 'pickle' - can execute arbitrary code",
                line=node.lineno,
                suggestion="Use json or other safe serialization formats"
            ))
        self.generic_visit(node)

    def _check_shell_injection(self):
        """Check for potential shell injection vulnerabilities"""
        patterns = [
            (r'shell\s*=\s*True', "Shell injection risk with shell=True"),
            (r'os\.system\s*\(', "os.system() is vulnerable to injection"),
        ]

        for pattern, message in patterns:
            if re.search(pattern, self.code):
                self.issues.append(AnalysisIssue(
                    severity="warning",
                    category="security",
                    message=message,
                    suggestion="Use subprocess.run() with shell=False and command as list"
                ))

    def _check_path_traversal(self):
        """Check for potential path traversal vulnerabilities"""
        patterns = [
            r'\.\./\.\.',  # ../ patterns
            r'\.\.\\\.\.', # ..\ patterns (Windows)
        ]

        for pattern in patterns:
            if re.search(pattern, self.code):
                self.issues.append(AnalysisIssue(
                    severity="warning",
                    category="security",
                    message="Potential path traversal pattern detected",
                    suggestion="Use Path().resolve() to sanitize paths"
                ))

    def _check_hardcoded_secrets(self):
        """Check for potential hardcoded secrets"""
        patterns = [
            (r'password\s*=\s*["\'][^"\']+["\']', "Potential hardcoded password"),
            (r'api[_-]?key\s*=\s*["\'][^"\']+["\']', "Potential hardcoded API key"),
            (r'secret\s*=\s*["\'][^"\']+["\']', "Potential hardcoded secret"),
            (r'token\s*=\s*["\'][^"\']+["\']', "Potential hardcoded token"),
        ]

        for pattern, message in patterns:
            if re.search(pattern, self.code, re.IGNORECASE):
                self.issues.append(AnalysisIssue(
                    severity="info",
                    category="secrets",
                    message=message,
                    suggestion="Use environment variables or secure vaults instead"
                ))

    def format_report(self) -> str:
        """Format analysis results as a readable report"""
        if not self.issues:
            return "✅ No issues found - code looks safe!"

        # Group by severity
        critical = [i for i in self.issues if i.severity == "critical"]
        warnings = [i for i in self.issues if i.severity == "warning"]
        info = [i for i in self.issues if i.severity == "info"]

        lines = []
        lines.append("📊 CODE ANALYSIS REPORT")
        lines.append("=" * 60)

        if critical:
            lines.append(f"\n🚨 CRITICAL ISSUES ({len(critical)}):")
            for issue in critical:
                lines.append(f"   {issue}")

        if warnings:
            lines.append(f"\n⚠️  WARNINGS ({len(warnings)}):")
            for issue in warnings:
                lines.append(f"   {issue}")

        if info:
            lines.append(f"\nℹ️  INFORMATION ({len(info)}):")
            for issue in info:
                lines.append(f"   {issue}")

        lines.append("\n" + "=" * 60)

        if critical and self.config.get("code_analysis", {}).get("block_on_critical", False):
            lines.append("⛔ Execution blocked due to critical security issues")

        return "\n".join(lines)

    def has_critical_issues(self) -> bool:
        """Check if any critical issues were found"""
        return any(issue.severity == "critical" for issue in self.issues)


def analyze_code(code: str) -> dict:
    """
    Analyze code for security and quality issues.

    Returns:
        dict with 'issues', 'report', 'safe' keys
    """
    analyzer = CodeAnalyzer(code, CONFIG)
    issues = analyzer.analyze()

    return {
        "issues": issues,
        "report": analyzer.format_report(),
        "safe": not analyzer.has_critical_issues(),
        "blocked": analyzer.has_critical_issues() and analyzer.block_on_critical,
    }


# ============================================================================
# Resource Tracking System
# ============================================================================

@dataclass
class ResourceMetrics:
    """Resource usage metrics for code execution"""
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    memory_percent: float = 0.0
    peak_memory_mb: float = 0.0
    num_threads: int = 0
    execution_time: float = 0.0

    def format_summary(self, config: dict) -> str:
        """Format metrics as human-readable summary"""
        lines = []

        # CPU
        cpu_warn = config.get("resource_tracking", {}).get("warn_cpu_percent", 90)
        cpu_emoji = "⚠️" if self.cpu_percent > cpu_warn else "✓"
        lines.append(f"   {cpu_emoji} CPU: {self.cpu_percent:.1f}%")

        # Memory
        mem_warn = config.get("resource_tracking", {}).get("warn_memory_mb", 500)
        mem_emoji = "⚠️" if self.peak_memory_mb > mem_warn else "✓"
        lines.append(f"   {mem_emoji} Memory: {self.memory_mb:.1f}MB (peak: {self.peak_memory_mb:.1f}MB)")

        # Other metrics
        lines.append(f"   ✓ Threads: {self.num_threads}")
        lines.append(f"   ✓ Time: {self.execution_time:.2f}s")

        return "\n".join(lines)


@dataclass
class CodeAnalysisResult:
    """Structured code analysis result"""
    issues: list[AnalysisIssue] = field(default_factory=list)
    blocked: bool = False
    severity_counts: dict = field(default_factory=dict)

    def to_report(self) -> str:
        """Format as human-readable report"""
        if not self.issues:
            return "✅ No issues found"

        lines = [
            "📊 CODE ANALYSIS REPORT",
            "=" * 60
        ]

        # Group issues by severity
        critical = [i for i in self.issues if i.severity == "critical"]
        warnings = [i for i in self.issues if i.severity == "warning"]
        info = [i for i in self.issues if i.severity == "info"]

        def format_issue(issue: AnalysisIssue) -> list[str]:
            emoji = {"critical": "🚨", "warning": "⚠️", "info": "ℹ️"}[issue.severity]
            severity_upper = issue.severity.upper()

            parts = [f"   {emoji} [{severity_upper}] {issue.message}"]
            if issue.line:
                parts[0] += f" (line {issue.line})"
            if issue.suggestion:
                parts.append(f"   💡 Suggestion: {issue.suggestion}")
            return parts

        if critical:
            lines.append(f"\n🚨 CRITICAL ISSUES ({len(critical)}):")
            for issue in critical:
                lines.extend(format_issue(issue))

        if warnings:
            lines.append(f"\n⚠️  WARNINGS ({len(warnings)}):")
            for issue in warnings:
                lines.extend(format_issue(issue))

        if info:
            lines.append(f"\nℹ️  INFORMATION ({len(info)}):")
            for issue in info:
                lines.extend(format_issue(issue))

        lines.append("=" * 60)
        if self.blocked:
            lines.append("⛔ Code has security concerns - review before executing")
        elif critical:
            lines.append("⚠️ Code has critical issues - review recommended")
        else:
            lines.append("✓ Code passed analysis")

        return "\n".join(lines)


@dataclass
class ExecutionResult:
    """Structured execution result with type safety"""
    success: bool
    stdout: str
    stderr: str
    execution_time: float
    mode: str = "direct"
    return_code: int = -1
    installed_packages: list[str] = field(default_factory=list)
    resource_metrics: Optional[ResourceMetrics] = None
    analysis: Optional[CodeAnalysisResult] = None
    detected_files: list[dict] = field(default_factory=list)


class ResourceTracker:
    """Track resource usage during code execution"""

    def __init__(self, config: dict):
        self.config = config
        self.enabled = config.get("resource_tracking", {}).get("enabled", True)
        self.process = None
        self.metrics = ResourceMetrics()
        self._peak_memory = 0.0

    def start(self, pid: int):
        """Start tracking a process"""
        if not self.enabled:
            return

        try:
            self.process = psutil.Process(pid)
            self._peak_memory = 0.0
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            self.process = None

    def sample(self):
        """Sample current resource usage"""
        if not self.enabled or not self.process:
            return

        try:
            # CPU percent (over 0.1 second interval)
            cpu = self.process.cpu_percent(interval=0.1)

            # Memory info
            mem_info = self.process.memory_info()
            memory_mb = mem_info.rss / (1024 * 1024)  # RSS in MB

            # Track peak memory
            if memory_mb > self._peak_memory:
                self._peak_memory = memory_mb

            # Memory percent
            mem_percent = self.process.memory_percent()

            # Number of threads
            num_threads = self.process.num_threads()

            # Update metrics
            self.metrics.cpu_percent = max(self.metrics.cpu_percent, cpu)
            self.metrics.memory_mb = memory_mb
            self.metrics.memory_percent = mem_percent
            self.metrics.peak_memory_mb = self._peak_memory
            self.metrics.num_threads = num_threads

        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    def finalize(self, execution_time: float) -> ResourceMetrics:
        """Finalize tracking and return metrics"""
        if not self.enabled:
            return ResourceMetrics(execution_time=execution_time)

        # Sample one last time
        self.sample()

        # Set execution time
        self.metrics.execution_time = execution_time

        return self.metrics

    def get_warnings(self) -> list[str]:
        """Get any resource usage warnings"""
        warnings = []

        if not self.enabled:
            return warnings

        cpu_warn = self.config.get("resource_tracking", {}).get("warn_cpu_percent", 90)
        mem_warn = self.config.get("resource_tracking", {}).get("warn_memory_mb", 500)

        if self.metrics.cpu_percent > cpu_warn:
            warnings.append(f"High CPU usage: {self.metrics.cpu_percent:.1f}% (threshold: {cpu_warn}%)")

        if self.metrics.peak_memory_mb > mem_warn:
            warnings.append(f"High memory usage: {self.metrics.peak_memory_mb:.1f}MB (threshold: {mem_warn}MB)")

        return warnings


# ============================================================================
# System Information
# ============================================================================

def get_installed_packages() -> dict[str, str]:
    """Get installed pip packages"""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "list", "--format=json"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            packages = json.loads(result.stdout)
            return {p["name"].lower(): p["version"] for p in packages}
    except Exception:
        pass
    return {}


def get_system_info() -> dict:
    """Gather comprehensive system information"""
    # Get pip version
    pip_version = "unknown"
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "--version"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            # Extract version from "pip X.Y.Z from ..."
            pip_version = result.stdout.split()[1] if len(result.stdout.split()) > 1 else "unknown"
    except Exception:
        pass

    # Get package manager info
    package_managers = {
        "pip": shutil.which("pip") or shutil.which("pip3"),
        "uv": shutil.which("uv"),
        "poetry": shutil.which("poetry"),
        "conda": shutil.which("conda"),
    }

    return {
        "os": platform.system(),
        "os_release": platform.release(),
        "os_version": platform.version(),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "python_executable": sys.executable,
        "pip_version": pip_version,
        "architecture": platform.machine(),
        "hostname": platform.node(),
        "cwd": os.getcwd(),
        "home": str(Path.home()),
        "temp_dir": tempfile.gettempdir(),
        "user": os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
        "execution_mode": CONFIG.get("execution_mode", "direct"),
        "docker_available": shutil.which("docker") is not None,
        "package_managers": {k: v is not None for k, v in package_managers.items()},
    }


def get_top_learnings_for_context() -> str:
    """Get the most relevant learnings formatted for LLM context (concise to save tokens)"""
    if not learning_store.learnings:
        return "   None yet"

    # Sort by success count (most helpful learnings first)
    sorted_learnings = sorted(
        learning_store.learnings,
        key=lambda x: (x.success_count, x.failure_count),
        reverse=True
    )[:5]  # Top 5 only (reduced from 10)

    if not sorted_learnings:
        return "   None yet"

    lines = []
    for i, l in enumerate(sorted_learnings, 1):
        # Concise format: just error type and key solution
        error_short = l.error_pattern.split(".*")[0] if ".*" in l.error_pattern else l.error_pattern[:30]
        solution_short = l.solution[:60] + "..." if len(l.solution) > 60 else l.solution
        lines.append(f"   • {error_short}: {solution_short}")

    return "\n".join(lines) if lines else "   None yet"


def format_system_context() -> str:
    """Format system info as context for code generation"""
    info = get_system_info()
    packages = get_installed_packages()
    
    # Categorize packages
    installed_libs = []
    for mod, desc in AVAILABLE_LIBRARIES.items():
        pkg = MODULE_TO_PACKAGE.get(mod, mod).lower()
        if pkg in packages or mod.lower() in packages:
            installed_libs.append(f"  ✓ {mod}: {desc}")
        else:
            installed_libs.append(f"  ○ {mod}: {desc} (will auto-install)")
    
    # Format package managers
    pm_list = [f"{k}: {'✓' if v else '✗'}" for k, v in info['package_managers'].items()]

    context = f"""
╔══════════════════════════════════════════════════════════════════╗
║                    MCP CODE MODE - SYSTEM CONTEXT                 ║
╚══════════════════════════════════════════════════════════════════╝

🖥️  SYSTEM
   OS: {info['os']} {info['os_release']} ({info['os_version']})
   Python: {info['python_version']} ({info['python_implementation']})
   pip: {info['pip_version']}
   Architecture: {info['architecture']}
   Hostname: {info['hostname']}
   User: {info['user']}
   Execution Mode: {info['execution_mode']}
   Docker Available: {'Yes ✓' if info['docker_available'] else 'No ✗'}

📦 PACKAGE MANAGERS
   {' | '.join(pm_list)}

📁 PATHS
   Working Directory: {info['cwd']}
   Home: {info['home']}
   Temp: {info['temp_dir']}

📦 AVAILABLE LIBRARIES
{chr(10).join(installed_libs)}

⚙️  EXECUTION NOTES
   • Use print() to return results - stdout is captured
   • Missing packages are auto-installed on ImportError
   • Use pathlib.Path for cross-platform file operations
   • subprocess.run() available for shell commands
   • Network access available (requests, httpx, etc.)
   • Files in /tmp are safe for temporary storage

📚 LEARNINGS FROM PAST EXECUTIONS (Learn from these to avoid repeating mistakes!)
{learning_store.get_summary()}

🎯 MOST COMMON ERRORS TO AVOID
{get_top_learnings_for_context()}

💡 TIPS
   • For complex tasks, break into logical steps
   • Handle errors with try/except for robustness
   • Use f-strings for clean output formatting
   • Prefer pathlib over os.path for file operations
""".strip()
    
    return context

# ============================================================================
# Code Execution Engine
# ============================================================================

def extract_missing_module(error: str) -> Optional[str]:
    """Extract missing module name from import error"""
    patterns = [
        r"No module named ['\"]([^'\"]+)['\"]",
        r"ModuleNotFoundError: No module named ['\"]([^'\"]+)['\"]",
        r"ImportError: cannot import name .+ from ['\"]([^'\"]+)['\"]",
    ]
    
    for pattern in patterns:
        match = re.search(pattern, error)
        if match:
            return match.group(1).split(".")[0]
    return None


def install_package(package: str) -> tuple[bool, str]:
    """Install a pip package"""
    # Check blocklist
    if package.lower() in [p.lower() for p in CONFIG.get("blocked_packages", [])]:
        return False, f"Package '{package}' is blocked by configuration"
    
    # Check allowlist (if configured)
    allowed = CONFIG.get("allowed_packages", [])
    if allowed and package.lower() not in [p.lower() for p in allowed]:
        return False, f"Package '{package}' not in allowed packages list"
    
    # Map module to package name
    package_name = MODULE_TO_PACKAGE.get(package, package)
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", package_name, "-q", "--disable-pip-version-check"],
            capture_output=True, text=True, timeout=120
        )
        
        if result.returncode == 0:
            return True, f"✓ Installed {package_name}"
        else:
            return False, f"✗ Failed to install {package_name}: {result.stderr[:200]}"
    except subprocess.TimeoutExpired:
        return False, f"✗ Timeout installing {package_name}"
    except Exception as e:
        return False, f"✗ Error: {str(e)}"


def execute_in_docker(code: str, timeout: int = 60) -> dict:
    """Execute code in a Docker container (more secure)"""
    if not shutil.which("docker"):
        return {
            "success": False,
            "stdout": "",
            "stderr": "Docker not available. Set execution_mode to 'direct' or install Docker.",
            "return_code": -1,
            "execution_time": 0,
            "installed_packages": [],
        }
    
    image = CONFIG.get("docker_image", "python:3.12-slim")
    
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        f.flush()
        temp_path = f.name
    
    try:
        start = datetime.now()
        result = subprocess.run(
            [
                "docker", "run", "--rm",
                "--network=host",  # Allow network access
                "-v", f"{temp_path}:/code.py:ro",
                "--memory=512m",
                "--cpus=1",
                image,
                "python", "/code.py"
            ],
            capture_output=True, text=True, timeout=timeout + 10
        )
        
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "return_code": result.returncode,
            "execution_time": (datetime.now() - start).total_seconds(),
            "installed_packages": [],
            "mode": "docker",
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "stdout": "",
            "stderr": f"Execution timed out after {timeout} seconds",
            "return_code": -1,
            "execution_time": timeout,
            "installed_packages": [],
            "mode": "docker",
        }
    finally:
        os.unlink(temp_path)


def execute_direct(
    code: str,
    timeout: int = 60,
    auto_install: bool = True,
    max_install_attempts: int = 3
) -> dict:
    """Execute code directly (faster, less isolated)"""
    result = {
        "success": False,
        "stdout": "",
        "stderr": "",
        "return_code": -1,
        "execution_time": 0.0,
        "installed_packages": [],
        "mode": "direct",
        "resource_metrics": None,
    }

    install_attempts = 0

    while install_attempts <= max_install_attempts:
        start = datetime.now()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            f.flush()
            temp_path = f.name

        # Initialize resource tracker
        tracker = ResourceTracker(CONFIG)

        try:
            # Use Popen instead of run for resource tracking
            proc = subprocess.Popen(
                [sys.executable, temp_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=str(Path.home()),
                env={**os.environ, "PYTHONUNBUFFERED": "1"}
            )

            # Start tracking this process
            tracker.start(proc.pid)

            # Wait for completion with timeout, sampling resources periodically
            try:
                remaining = timeout
                while remaining > 0 and proc.poll() is None:
                    import time
                    time.sleep(0.1)  # Sample every 100ms
                    tracker.sample()
                    remaining -= 0.1

                if proc.poll() is None:
                    # Timeout
                    proc.kill()
                    proc.wait()
                    result["stderr"] = f"Execution timed out after {timeout} seconds"
                    result["execution_time"] = timeout
                    result["resource_metrics"] = tracker.finalize(timeout)
                    break
                else:
                    # Normal completion
                    stdout, stderr = proc.communicate()
                    result["stdout"] = stdout
                    result["stderr"] = stderr
                    result["return_code"] = proc.returncode
                    exec_time = (datetime.now() - start).total_seconds()
                    result["execution_time"] = exec_time
                    result["resource_metrics"] = tracker.finalize(exec_time)

                    if proc.returncode == 0:
                        result["success"] = True
                        break

                    # Try auto-install
                    if auto_install and install_attempts < max_install_attempts:
                        missing = extract_missing_module(stderr)
                        if missing:
                            success, msg = install_package(missing)
                            if success:
                                result["installed_packages"].append(missing)
                                install_attempts += 1
                                continue

                    break

            except Exception as wait_err:
                result["stderr"] = f"Execution error: {str(wait_err)}"
                exec_time = (datetime.now() - start).total_seconds()
                result["execution_time"] = exec_time
                result["resource_metrics"] = tracker.finalize(exec_time)
                break

        except Exception as e:
            result["stderr"] = f"Execution error: {str(e)}\n{traceback.format_exc()}"
            exec_time = (datetime.now() - start).total_seconds()
            result["execution_time"] = exec_time
            result["resource_metrics"] = tracker.finalize(exec_time)
            break
        finally:
            try:
                os.unlink(temp_path)
            except Exception:
                pass

    return result


def execute_code(
    code: str,
    timeout: int = None,
    auto_install: bool = None,
    mode: str = None
) -> dict:
    """Execute Python code using configured mode"""
    timeout = timeout or CONFIG.get("default_timeout", 60)
    auto_install = auto_install if auto_install is not None else CONFIG.get("auto_install", True)
    mode = mode or CONFIG.get("execution_mode", "direct")

    if mode == ExecutionMode.DOCKER.value:
        return execute_in_docker(code, timeout)
    else:
        return execute_direct(code, timeout, auto_install)


def execute_streaming(
    code: str,
    timeout: int = 60,
    auto_install: bool = True
) -> Generator[str, None, dict]:
    """
    Execute code with streaming output (yields lines as they're produced).

    Yields:
        Lines of output (stdout/stderr) as they're generated

    Returns:
        Final execution result dict
    """
    result = {
        "success": False,
        "stdout": "",
        "stderr": "",
        "return_code": -1,
        "execution_time": 0.0,
        "installed_packages": [],
        "mode": "direct-stream",
    }

    max_install_attempts = 3
    install_attempts = 0
    stdout_lines = []
    stderr_lines = []

    while install_attempts <= max_install_attempts:
        start = datetime.now()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            f.flush()
            temp_path = f.name

        try:
            # Start process with line-buffered output
            process = subprocess.Popen(
                [sys.executable, temp_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                cwd=str(Path.home()),
                env={**os.environ, "PYTHONUNBUFFERED": "1"}
            )

            # Platform-specific streaming
            if platform.system() == 'Windows':
                # Windows: Use threads for non-blocking I/O
                stdout_queue = queue.Queue()
                stderr_queue = queue.Queue()

                def enqueue_output(pipe, q):
                    for line in iter(pipe.readline, ''):
                        q.put(line)
                    pipe.close()

                stdout_thread = threading.Thread(target=enqueue_output, args=(process.stdout, stdout_queue))
                stderr_thread = threading.Thread(target=enqueue_output, args=(process.stderr, stderr_queue))
                stdout_thread.daemon = True
                stderr_thread.daemon = True
                stdout_thread.start()
                stderr_thread.start()

                # Read from queues
                while process.poll() is None or not stdout_queue.empty() or not stderr_queue.empty():
                    try:
                        line = stdout_queue.get_nowait()
                        stdout_lines.append(line)
                        yield f"[OUT] {line.rstrip()}"
                    except queue.Empty:
                        pass

                    try:
                        line = stderr_queue.get_nowait()
                        stderr_lines.append(line)
                        yield f"[ERR] {line.rstrip()}"
                    except queue.Empty:
                        pass

                    # Check timeout
                    if (datetime.now() - start).total_seconds() > timeout:
                        process.kill()
                        yield f"[TIMEOUT] Execution exceeded {timeout}s"
                        break

            else:
                # Unix: Use select for non-blocking I/O
                import fcntl

                # Set non-blocking mode
                for pipe in [process.stdout, process.stderr]:
                    flags = fcntl.fcntl(pipe, fcntl.F_GETFL)
                    fcntl.fcntl(pipe, fcntl.F_SETFL, flags | os.O_NONBLOCK)

                # Stream output
                while True:
                    # Check if process is done
                    if process.poll() is not None:
                        # Drain remaining output
                        for line in process.stdout:
                            stdout_lines.append(line)
                            yield f"[OUT] {line.rstrip()}"
                        for line in process.stderr:
                            stderr_lines.append(line)
                            yield f"[ERR] {line.rstrip()}"
                        break

                    # Check timeout
                    if (datetime.now() - start).total_seconds() > timeout:
                        process.kill()
                        yield f"[TIMEOUT] Execution exceeded {timeout}s"
                        break

                    # Wait for data with timeout
                    readable, _, _ = select.select([process.stdout, process.stderr], [], [], 0.1)

                    for stream in readable:
                        line = stream.readline()
                        if line:
                            if stream == process.stdout:
                                stdout_lines.append(line)
                                yield f"[OUT] {line.rstrip()}"
                            else:
                                stderr_lines.append(line)
                                yield f"[ERR] {line.rstrip()}"

            # Get final status
            process.wait()
            result["return_code"] = process.returncode
            result["stdout"] = "".join(stdout_lines)
            result["stderr"] = "".join(stderr_lines)
            result["execution_time"] = (datetime.now() - start).total_seconds()

            if result["return_code"] == 0:
                result["success"] = True
                break

            # Try auto-install
            if auto_install and install_attempts < max_install_attempts:
                missing = extract_missing_module(result["stderr"])
                if missing:
                    yield f"[INSTALL] Detected missing module: {missing}"
                    success, msg = install_package(missing)
                    if success:
                        result["installed_packages"].append(missing)
                        yield f"[INSTALL] {msg}"
                        install_attempts += 1
                        stdout_lines = []
                        stderr_lines = []
                        continue

            break

        except Exception as e:
            result["stderr"] = f"Execution error: {str(e)}\n{traceback.format_exc()}"
            yield f"[ERROR] {str(e)}"
            break
        finally:
            try:
                os.unlink(temp_path)
            except Exception:
                pass

    return result


def log_execution(code: str, description: str, result: dict):
    """Log execution for analytics"""
    try:
        logs = []
        if EXECUTION_LOG.exists():
            try:
                logs = json.loads(EXECUTION_LOG.read_text())
            except Exception:
                logs = []
        
        logs = logs[-999:]  # Keep last 1000
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "description": description,
            "code_hash": hashlib.sha256(code.encode()).hexdigest()[:16],
            "code_lines": len(code.split("\n")),
            "success": result["success"],
            "execution_time": result["execution_time"],
            "mode": result.get("mode", "unknown"),
            "error_type": extract_error_type(result["stderr"]) if result["stderr"] else None,
        }

        # Add resource metrics if available
        if result.get("resource_metrics"):
            metrics = result["resource_metrics"]
            log_entry["resource_metrics"] = {
                "cpu_percent": metrics.cpu_percent,
                "memory_mb": metrics.memory_mb,
                "peak_memory_mb": metrics.peak_memory_mb,
                "num_threads": metrics.num_threads,
            }

        logs.append(log_entry)
        
        EXECUTION_LOG.write_text(json.dumps(logs, indent=2))
    except Exception:
        pass


def extract_error_type(stderr: str) -> Optional[str]:
    """Extract error type from stderr"""
    match = re.search(r"(\w+Error|\w+Exception):", stderr)
    return match.group(1) if match else None


def detect_and_encode_files(stdout: str, max_files: int = 5) -> list[dict]:
    """
    Detect file paths in stdout and return them as MCP content (images, text, resources).

    Supports all MCP content types:
    - Images: PNG, JPG, GIF, SVG, etc. (displayed inline)
    - Text files: Source code, logs, JSON, CSV, etc. (displayed as text)
    - Resources: PDFs, archives, etc. (available for download)

    This enables rich file display in MCP clients like Goose, Claude Desktop, etc.

    Args:
        stdout: The stdout from code execution
        max_files: Maximum number of files to encode (to avoid huge responses)

    Returns:
        List of MCP content dictionaries
    """
    content = []

    # File type categorization
    image_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.svg', '.ico'}
    text_extensions = {
        '.txt', '.log', '.md', '.json', '.yaml', '.yml', '.xml', '.csv', '.tsv',
        '.py', '.js', '.ts', '.html', '.css', '.java', '.c', '.cpp', '.go', '.rs',
        '.sh', '.bash', '.sql', '.env', '.toml', '.ini', '.conf', '.cfg'
    }
    resource_extensions = {'.pdf', '.zip', '.tar', '.gz', '.bz2', '.7z', '.rar'}

    all_extensions = image_extensions | text_extensions | resource_extensions

    # Build regex pattern for all extensions
    ext_pattern = '|'.join(ext.replace('.', '\\.') for ext in all_extensions)

    # Pattern to find file paths (common formats)
    # Matches: /path/to/file.ext, ./file.ext, ~/file.ext, C:\path\file.ext
    path_patterns = [
        rf'(?:^|\s)([\/~.][\w\/\-\.]+\.(?:{ext_pattern}))',  # Unix paths
        rf'([A-Za-z]:\\[\w\\\.]+\.(?:{ext_pattern}))',  # Windows paths
    ]

    found_paths = set()
    for pattern in path_patterns:
        matches = re.findall(pattern, stdout, re.IGNORECASE | re.MULTILINE)
        found_paths.update(matches)

    # Also check for explicit mentions like "Saved to: path"
    saved_pattern = rf'(?:saved|written|created|output|screenshot|exported|generated|wrote)(?:\s+to)?:?\s+([^\s\n]+\.(?:{ext_pattern}))'
    saved_matches = re.findall(saved_pattern, stdout, re.IGNORECASE)
    found_paths.update(saved_matches)

    # Convert to Path objects and encode
    for path_str in found_paths:
        if len(content) >= max_files:
            break

        try:
            # Expand user home directory (~)
            path = Path(path_str).expanduser().resolve()

            # Check if file exists
            if not path.exists() or not path.is_file():
                continue

            # Get file extension
            ext = path.suffix.lower()

            # Skip files larger than 10MB to avoid huge responses
            file_size = path.stat().st_size
            if file_size > 10 * 1024 * 1024:
                continue

            # Process based on file type
            if ext in image_extensions:
                # Image content
                with open(path, 'rb') as f:
                    encoded_data = base64.b64encode(f.read()).decode('utf-8')

                # Get MIME type
                mime_type, _ = mimetypes.guess_type(str(path))
                if not mime_type:
                    ext_to_mime = {
                        '.png': 'image/png',
                        '.jpg': 'image/jpeg',
                        '.jpeg': 'image/jpeg',
                        '.gif': 'image/gif',
                        '.bmp': 'image/bmp',
                        '.webp': 'image/webp',
                        '.svg': 'image/svg+xml',
                        '.ico': 'image/x-icon'
                    }
                    mime_type = ext_to_mime.get(ext, 'image/png')

                content.append({
                    "type": "image",
                    "data": encoded_data,
                    "mimeType": mime_type
                })

            elif ext in text_extensions:
                # Text content - read as text
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        text_content = f.read()

                    # Limit text content to 50KB
                    if len(text_content) > 50000:
                        text_content = text_content[:50000] + "\n\n... (truncated)"

                    content.append({
                        "type": "text",
                        "text": f"📄 File: {path.name}\n```\n{text_content}\n```"
                    })
                except UnicodeDecodeError:
                    # If can't decode as text, skip
                    continue

            elif ext in resource_extensions:
                # Resource content (PDFs, archives, etc.)
                with open(path, 'rb') as f:
                    encoded_data = base64.b64encode(f.read()).decode('utf-8')

                mime_type, _ = mimetypes.guess_type(str(path))
                if not mime_type:
                    mime_type = 'application/octet-stream'

                content.append({
                    "type": "resource",
                    "resource": {
                        "uri": f"file://{path}",
                        "mimeType": mime_type,
                        "blob": encoded_data
                    }
                })

        except Exception:
            # Silently skip files that can't be processed
            continue

    return content


def auto_learn_from_error(stderr: str, installed_packages: list[str]) -> None:
    """
    Automatically learn from common error patterns.

    This captures frequently-seen errors and their solutions without
    requiring manual intervention.
    """
    if not stderr:
        return

    stderr_lower = stderr.lower()

    # Pattern 1: Module not found
    if "modulenotfounderror" in stderr_lower or "no module named" in stderr_lower:
        # Extract module name
        match = re.search(r"No module named ['\"]([^'\"]+)['\"]", stderr, re.IGNORECASE)
        if match:
            module_name = match.group(1).split(".")[0]
            pattern = f"ModuleNotFoundError.*{module_name}"

            if installed_packages and module_name in installed_packages:
                solution = f"Auto-installed {module_name} successfully"
                context = f"Missing {module_name} module - resolved by auto-installation"
            else:
                solution = f"Install {module_name}: pip install {module_name} (or use pip_install tool)"
                context = f"Missing {module_name} module - needs manual installation"

            try:
                # Check if we already have this learning
                existing = learning_store.find_relevant(pattern, limit=1)
                if not existing or existing[0].error_pattern != pattern:
                    learning_store.add(pattern, solution, context, ["module", "import"])
            except Exception:
                pass  # Don't fail execution if learning fails

    # Pattern 2: SSL Certificate errors
    if "ssl" in stderr_lower and "certificate" in stderr_lower:
        pattern = "SSL.*CERTIFICATE_VERIFY_FAILED"
        solution = "Add verify=False to requests, or: pip install --upgrade certifi"
        context = "HTTPS requests failing due to SSL certificate validation"
        try:
            existing = learning_store.find_relevant(pattern, limit=1)
            if not existing:
                learning_store.add(pattern, solution, context, ["ssl", "https", "certificates"])
        except Exception:
            pass

    # Pattern 3: Permission errors
    if "permission" in stderr_lower and "denied" in stderr_lower:
        pattern = "PermissionError.*denied"
        solution = "Use /tmp for temporary files, or check file/directory permissions"
        context = "File/directory access permission issues"
        try:
            existing = learning_store.find_relevant(pattern, limit=1)
            if not existing:
                learning_store.add(pattern, solution, context, ["permissions", "filesystem"])
        except Exception:
            pass

    # Pattern 4: File not found
    if "filenotfounderror" in stderr_lower or "no such file" in stderr_lower:
        pattern = "FileNotFoundError"
        solution = "Check file path exists with Path(file).exists() before opening"
        context = "Attempting to access non-existent file"
        try:
            existing = learning_store.find_relevant(pattern, limit=1)
            if not existing:
                learning_store.add(pattern, solution, context, ["filesystem", "path"])
        except Exception:
            pass

    # Pattern 5: Timeout errors
    if "timeout" in stderr_lower:
        pattern = "timeout|TimeoutError"
        solution = "Increase timeout parameter or check network connectivity"
        context = "Operation exceeded timeout limit"
        try:
            existing = learning_store.find_relevant(pattern, limit=1)
            if not existing:
                learning_store.add(pattern, solution, context, ["network", "timeout"])
        except Exception:
            pass

    # Pattern 6: Generic error capture (fallback)
    # Capture any unhandled error type for future reference
    error_match = re.search(r"(\w+Error|\w+Exception):", stderr)
    if error_match:
        error_type = error_match.group(1)
        # Only add if we don't already have a specific learning for this error
        specific_patterns = ["ModuleNotFoundError", "FileNotFoundError", "PermissionError", "TimeoutError", "SSL"]
        if not any(p in stderr for p in specific_patterns):
            pattern = f"{error_type}"
            solution = f"Review error message and traceback. Common fix: check parameters and environment."
            context = f"Generic {error_type} - needs specific analysis"
            try:
                existing = learning_store.find_relevant(pattern, limit=1)
                if not existing or existing[0].error_pattern != pattern:
                    learning_store.add(pattern, solution, context, ["error", "generic"])
            except Exception:
                pass

# ============================================================================
# MCP Resources
# ============================================================================

@mcp.resource("learnings://database", icon="🧠")
def get_learnings_resource() -> str:
    """
    Expose the complete learnings database as an MCP resource.

    This allows LLMs to access all learned error patterns and solutions
    without explicitly calling get_learnings tool.
    """
    try:
        learnings = learning_store.get_all()
        if not learnings:
            return json.dumps({
                "count": 0,
                "message": "No learnings recorded yet",
                "learnings": []
            }, indent=2)

        # Format learnings for easy consumption
        formatted = {
            "count": len(learnings),
            "last_updated": max(l.get("timestamp", "") for l in learnings) if learnings else None,
            "learnings": [
                {
                    "pattern": l.get("pattern", ""),
                    "solution": l.get("solution", ""),
                    "context": l.get("context", ""),
                    "tags": l.get("tags", []),
                    "timestamp": l.get("timestamp", ""),
                    "success_count": l.get("success_count", 0)
                }
                for l in learnings
            ]
        }
        return json.dumps(formatted, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, indent=2)


@mcp.resource("system://context", icon="🖥️")
def get_system_resource() -> str:
    """
    Expose system context as an MCP resource.

    Provides OS info, Python version, package managers, and configuration
    that LLMs can access for better code generation.
    """
    try:
        context = {
            "platform": {
                "os": platform.system(),
                "version": platform.version(),
                "machine": platform.machine(),
                "python_version": platform.python_version(),
            },
            "paths": {
                "executable": sys.executable,
                "data_dir": str(DATA_DIR),
                "temp_dir": tempfile.gettempdir(),
            },
            "package_managers": {},
            "configuration": CONFIG.copy(),
        }

        # Check for package managers
        for pm, cmd in [("pip", "pip --version"), ("uv", "uv --version"), ("poetry", "poetry --version")]:
            try:
                result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=2)
                if result.returncode == 0:
                    context["package_managers"][pm] = result.stdout.strip()
            except Exception:
                pass

        return json.dumps(context, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, indent=2)


@mcp.resource("executions://recent", icon="📊")
def get_executions_resource() -> str:
    """
    Expose recent execution logs as an MCP resource.

    Provides history of recent code executions, their success/failure status,
    and resource usage metrics.
    """
    try:
        if not EXECUTION_LOG.exists():
            return json.dumps({
                "count": 0,
                "message": "No executions recorded yet",
                "executions": []
            }, indent=2)

        with open(EXECUTION_LOG, "r") as f:
            all_logs = [json.loads(line) for line in f if line.strip()]

        # Get last 20 executions
        recent = all_logs[-20:] if len(all_logs) > 20 else all_logs

        # Calculate statistics
        total = len(recent)
        successful = sum(1 for log in recent if log.get("success", False))
        failed = total - successful

        formatted = {
            "count": total,
            "statistics": {
                "total": total,
                "successful": successful,
                "failed": failed,
                "success_rate": f"{(successful/total*100):.1f}%" if total > 0 else "0%"
            },
            "recent_executions": [
                {
                    "timestamp": log.get("timestamp", ""),
                    "success": log.get("success", False),
                    "execution_time": log.get("execution_time", 0),
                    "mode": log.get("mode", ""),
                    "return_code": log.get("return_code", -1),
                    "resource_metrics": log.get("resource_metrics"),
                    "error_type": log.get("error", {}).get("type") if not log.get("success") else None
                }
                for log in recent
            ]
        }
        return json.dumps(formatted, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, indent=2)


# ============================================================================
# MCP Tools
# ============================================================================

@mcp.tool(icon="💻")
def get_system_context() -> str:
    """
    Get comprehensive system context before writing code.

    CALL THIS FIRST to understand:
    - OS, Python version, available paths
    - Installed and available libraries
    - Execution mode (direct or Docker sandbox)
    - Past learnings from errors
    - Tips for writing effective code

    Returns detailed system information formatted for code generation.
    """
    return format_system_context()


@mcp.tool(icon="🔍")
def analyze_code_tool(code: str) -> str:
    """
    Analyze Python code for security and quality issues WITHOUT executing it.

    Performs comprehensive static analysis including:
    - Syntax validation
    - Security vulnerability detection (eval, exec, os.system, etc.)
    - Dangerous operations (file deletion, shell injection, etc.)
    - Hardcoded secrets detection
    - Path traversal vulnerabilities
    - Best practice violations

    Use this when you want to validate code before running it, or to understand
    potential security risks.

    Args:
        code: Python code to analyze

    Returns:
        Detailed analysis report with severity levels and suggestions

    Example:
        code = '''
        import os
        password = "hardcoded123"
        os.system("rm -rf /tmp/*")
        '''

        # Will detect:
        # - Critical: os.system() usage
        # - Info: Hardcoded password
        # - Warning: Dangerous file deletion pattern
    """
    analysis = analyze_code(code)

    report = [analysis["report"]]

    if analysis["safe"]:
        report.append("\n✅ Code appears safe to execute")
    else:
        report.append("\n⚠️ Code has security concerns - review before executing")

    if analysis["blocked"]:
        report.append("⛔ Code would be BLOCKED from execution due to critical issues")

    return "\n".join(report)


# Internal execute function
def _execute_code_internal(
    code: str,
    timeout: int = 60,
    auto_install: bool = True,
    mode: str = None
) -> dict:
    """Internal execution dispatcher"""
    mode = mode or CONFIG.get("execution_mode", "direct")
    if mode == ExecutionMode.DOCKER.value:
        return execute_in_docker(code, timeout)
    return execute_direct(code, timeout, auto_install)


@mcp.tool(icon="▶️")
def run_python(
    code: str,
    description: str = "",
    timeout: int = 60,
    auto_install: bool = True,
    ctx: Context = None
):
    """
    Execute Python code to accomplish ANY task.

    This is a universal tool - write Python to do what you need:
    - HTTP requests (requests, httpx, aiohttp)
    - Parse HTML (beautifulsoup4, lxml)
    - Process data (pandas, json, csv)
    - File operations (pathlib, shutil)
    - System commands (subprocess)
    - Images (Pillow, opencv)
    - And anything else Python can do!

    Args:
        code: Python code to execute. Use print() for output.
        description: Brief task description (for logging)
        timeout: Max execution time in seconds
        auto_install: Auto-install missing packages

    Returns:
        Execution result with stdout, stderr, status, and any generated images

    Example:
        code = '''
        import requests
        resp = requests.get("https://api.github.com/users/octocat")
        data = resp.json()
        print(f"User: {data['login']}")
        print(f"Repos: {data['public_repos']}")
        '''
    """
    # Report progress: Starting analysis
    if ctx:
        ctx.info(f"Analyzing code for security and quality issues...")
        ctx.report_progress(0, 100, "Analyzing code")

    # Analyze code before execution
    analysis = analyze_code(code)

    # Check if execution should be blocked
    if analysis["blocked"]:
        if ctx:
            ctx.info("Execution blocked due to critical security issues")
        return f"{analysis['report']}\n\n⛔ Execution blocked due to critical security issues."

    # Report progress: Executing code
    if ctx:
        ctx.info(f"Executing Python code{' - ' + description if description else ''}...")
        ctx.report_progress(20, 100, "Executing code")

    result = _execute_code_internal(code, timeout, auto_install)

    # Report progress: Processing results
    if ctx:
        ctx.info("Processing execution results...")
        ctx.report_progress(80, 100, "Processing results")

    # Detect files (images, text, resources) in output
    detected_files = detect_and_encode_files(result["stdout"])

    # Format output
    parts = []

    # Include analysis report if enabled and issues found
    if CONFIG.get("code_analysis", {}).get("show_report", True) and analysis["issues"]:
        parts.append(analysis["report"])
        parts.append("")  # Blank line separator

    if description:
        parts.append(f"📋 Task: {description}")

    status = "✅ SUCCESS" if result["success"] else "❌ FAILED"
    parts.append(f"{status} | ⏱️ {result['execution_time']:.2f}s | Mode: {result.get('mode', 'direct')}")

    if result["installed_packages"]:
        parts.append(f"📦 Auto-installed: {', '.join(result['installed_packages'])}")

    # Resource metrics
    if CONFIG.get("resource_tracking", {}).get("show_in_output", True) and result.get("resource_metrics"):
        metrics = result["resource_metrics"]
        parts.append("\n📊 RESOURCE USAGE:")
        parts.append(metrics.format_summary(CONFIG))

        # Resource warnings
        tracker = ResourceTracker(CONFIG)
        tracker.metrics = metrics
        warnings = tracker.get_warnings()
        if warnings:
            parts.append("\n⚠️  RESOURCE WARNINGS:")
            for warning in warnings:
                parts.append(f"   • {warning}")

    # Note about detected files
    if detected_files:
        parts.append(f"\n📎 Detected {len(detected_files)} file(s) - displaying below")

    parts.append("\n─── OUTPUT ───")
    parts.append(result["stdout"] if result["stdout"] else "(no output)")

    if result["stderr"]:
        parts.append("\n─── ERRORS ───")
        parts.append(result["stderr"])

    # Auto-learn from errors
    auto_learn_from_error(result["stderr"], result.get("installed_packages", []))

    log_execution(code, description, result)

    # Build text output
    text_output = "\n".join(parts)

    # Report progress: Complete
    if ctx:
        status_msg = "Execution completed successfully" if result["success"] else "Execution failed"
        ctx.info(f"{status_msg} in {result['execution_time']:.2f}s")
        ctx.report_progress(100, 100, "Complete")

    # Return structured content if files were detected
    if detected_files:
        return [
            {
                "type": "text",
                "text": text_output
            },
            *detected_files  # Spread the file content objects
        ]
    else:
        # Return plain text for backward compatibility
        return text_output


@mcp.tool(icon="🌊")
def run_python_stream(
    code: str,
    description: str = "",
    timeout: int = 60,
    auto_install: bool = True,
    ctx: Context = None
):
    """
    Execute Python code with REAL-TIME STREAMING OUTPUT.

    Perfect for long-running tasks where you want to see progress as it happens:
    - Web scraping multiple pages (see each page as it's scraped)
    - Data processing loops (see progress through large datasets)
    - API calls with retries (see each attempt)
    - File operations (see each file as it's processed)
    - Long computations (see intermediate results)

    Output streams in real-time as the code executes, so you see results
    immediately instead of waiting for the entire execution to complete.

    Args:
        code: Python code to execute. Use print() liberally for progress updates.
        description: Brief task description (for logging)
        timeout: Max execution time in seconds
        auto_install: Auto-install missing packages

    Returns:
        Streaming output followed by execution summary, with any generated images

    Example:
        code = '''
        import time
        for i in range(5):
            print(f"Processing item {i+1}/5...")
            time.sleep(1)
        print("✓ Done!")
        '''

    The output will appear line-by-line as the code runs, not all at once at the end.
    """
    # Report progress: Starting streaming execution
    if ctx:
        ctx.info(f"Starting streaming execution{' - ' + description if description else ''}...")
        ctx.report_progress(0, 100, "Starting streaming execution")

    # Collect all streamed output
    output_lines = []

    if description:
        output_lines.append(f"📋 Task: {description}")
        output_lines.append("🔄 Streaming output (real-time)...\n")

    # Stream execution
    start_time = datetime.now()
    result = None

    try:
        # Execute streaming - generator will yield lines and return result
        gen = execute_streaming(code, timeout, auto_install)

        try:
            while True:
                line = next(gen)
                output_lines.append(line)
        except StopIteration as e:
            # The return value is in e.value
            result = e.value

    except Exception as e:
        output_lines.append(f"\n❌ Streaming error: {str(e)}")
        result = {
            "success": False,
            "execution_time": (datetime.now() - start_time).total_seconds(),
            "mode": "direct-stream",
            "installed_packages": [],
        }

    # Add summary
    output_lines.append("\n" + "─" * 60)

    # Detect files (images, text, resources) from the result stdout
    detected_files = []
    if result and isinstance(result, dict) and result.get("stdout"):
        detected_files = detect_and_encode_files(result["stdout"])
        if detected_files:
            output_lines.append(f"📎 Detected {len(detected_files)} file(s) - displaying below")

    if result and isinstance(result, dict):
        status = "✅ SUCCESS" if result.get("success") else "❌ FAILED"
        exec_time = result.get("execution_time", 0)
        mode = result.get("mode", "direct-stream")
        packages = result.get("installed_packages", [])

        output_lines.append(f"{status} | ⏱️ {exec_time:.2f}s | Mode: {mode}")

        if packages:
            output_lines.append(f"📦 Auto-installed: {', '.join(packages)}")

        # Auto-learn from errors
        auto_learn_from_error(result.get("stderr", ""), result.get("installed_packages", []))

        # Log execution
        log_execution(code, description, result)
    else:
        output_lines.append("⏱️ Execution completed")

    # Build text output
    text_output = "\n".join(output_lines)

    # Report progress: Complete
    if ctx and result and isinstance(result, dict):
        status_msg = "Streaming execution completed successfully" if result.get("success") else "Streaming execution failed"
        ctx.info(f"{status_msg} in {result.get('execution_time', 0):.2f}s")
        ctx.report_progress(100, 100, "Complete")

    # Return structured content if files were detected
    if detected_files:
        return [
            {
                "type": "text",
                "text": text_output
            },
            *detected_files  # Spread the file content objects
        ]
    else:
        # Return plain text for backward compatibility
        return text_output


@mcp.tool(icon="🔄")
def run_with_retry(
    code: str,
    description: str = "",
    max_retries: int = 3,
    timeout: int = 60,
    ctx: Context = None
) -> str:
    """
    Execute Python code with intelligent retry and error analysis.

    On failure, this tool:
    1. Analyzes the error pattern
    2. Searches past learnings for solutions
    3. Provides diagnostic information
    4. Suggests fixes based on error type
    
    Use this for more robust execution when errors are expected.
    
    Args:
        code: Python code to execute
        description: Task description
        max_retries: Max retry attempts (same code)
        timeout: Execution timeout in seconds
    
    Returns:
        Detailed execution result with retry info and suggestions
    """
    # Report progress: Starting retry execution
    if ctx:
        ctx.info(f"Starting execution with retry (max {max_retries} attempts){' - ' + description if description else ''}...")
        ctx.report_progress(0, 100, "Starting execution with retry")

    attempts = []
    result = None

    for attempt in range(1, max_retries + 1):
        # Report progress: Attempt N
        if ctx:
            ctx.info(f"Attempt {attempt}/{max_retries}...")
            progress = int((attempt / max_retries) * 80)  # Reserve last 20% for processing
            ctx.report_progress(progress, 100, f"Attempt {attempt}/{max_retries}")

        result = _execute_code_internal(code, timeout, auto_install=True)

        attempts.append({
            "attempt": attempt,
            "success": result["success"],
            "error": result["stderr"][:200] if result["stderr"] else None
        })

        if result["success"]:
            if ctx:
                ctx.info(f"Execution succeeded on attempt {attempt}")
            break

        # Don't retry identical errors
        if attempt > 1 and attempts[-1].get("error") == attempts[-2].get("error"):
            if ctx:
                ctx.info(f"Stopping retries: identical error detected")
            break
    
    # Format output
    parts = []
    
    if description:
        parts.append(f"📋 Task: {description}")
    
    status = "✅ SUCCESS" if result["success"] else "❌ FAILED"
    parts.append(f"{status} | Attempts: {len(attempts)}/{max_retries}")
    parts.append(f"⏱️ {result['execution_time']:.2f}s | Mode: {result.get('mode', 'direct')}")
    
    if result["installed_packages"]:
        parts.append(f"📦 Auto-installed: {', '.join(result['installed_packages'])}")
    
    parts.append("\n─── OUTPUT ───")
    parts.append(result["stdout"] if result["stdout"] else "(no output)")
    
    if not result["success"] and result["stderr"]:
        parts.append("\n─── ERROR ANALYSIS ───")
        parts.append(result["stderr"])
        
        # Find relevant learnings
        relevant = learning_store.find_relevant(result["stderr"], code)
        if relevant:
            parts.append("\n💡 SUGGESTIONS FROM PAST LEARNINGS:")
            for i, learning in enumerate(relevant, 1):
                parts.append(f"   {i}. {learning.solution}")
                parts.append(f"      Context: {learning.context}")
        
        # Suggest based on error type
        error_type = extract_error_type(result["stderr"])
        if error_type:
            parts.append(f"\n🔍 Error type: {error_type}")
            if error_type == "ModuleNotFoundError":
                parts.append("   → Try: pip_install('package_name')")
            elif error_type == "FileNotFoundError":
                parts.append("   → Check: Does the file/path exist?")
            elif error_type == "PermissionError":
                parts.append("   → Try: Use /tmp for file operations")

    # Auto-learn from errors
    auto_learn_from_error(result["stderr"], result.get("installed_packages", []))

    log_execution(code, description, result)

    # Report progress: Complete
    if ctx:
        status_msg = f"Execution completed after {len(attempts)} attempt(s)" if result["success"] else f"Execution failed after {len(attempts)} attempt(s)"
        ctx.info(status_msg)
        ctx.report_progress(100, 100, "Complete")

    return "\n".join(parts)


@mcp.tool(icon="💡")
def add_learning(
    error_pattern: str,
    solution: str,
    context: str,
    tags: str = ""
) -> str:
    """
    Record a learning from a code execution for future reference.
    
    When you figure out how to fix an error, record it here.
    Future executions will suggest this solution for similar errors.
    
    Args:
        error_pattern: Text/regex that matches the error message
        solution: What fixed the problem
        context: When this solution applies
        tags: Comma-separated tags (e.g., "network,ssl,https")
    
    Example:
        add_learning(
            error_pattern="SSL: CERTIFICATE_VERIFY_FAILED",
            solution="Add verify=False to requests.get() or install certifi",
            context="HTTPS requests on systems with certificate issues",
            tags="ssl,https,certificates"
        )
    
    Returns:
        Confirmation message
    """
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
    learning_store.add(error_pattern, solution, context, tag_list)
    
    return f"""✅ Learning recorded!

📝 Pattern: {error_pattern}
💡 Solution: {solution}
📌 Context: {context}
🏷️  Tags: {', '.join(tag_list) if tag_list else 'none'}

This will help with similar errors in future executions."""


@mcp.tool(icon="📚")
def get_learnings(search: str = "") -> str:
    """
    View recorded learnings from past executions.
    
    Args:
        search: Optional search term to filter learnings
    
    Returns:
        Summary of learnings, optionally filtered
    """
    if not search:
        return learning_store.get_summary()
    
    # Search learnings
    matches = []
    search_lower = search.lower()
    
    for l in learning_store.learnings:
        if (search_lower in l.error_pattern.lower() or 
            search_lower in l.solution.lower() or
            search_lower in l.context.lower() or
            any(search_lower in t.lower() for t in l.tags)):
            matches.append(l)
    
    if not matches:
        return f"No learnings found matching '{search}'"
    
    lines = [f"🔍 {len(matches)} learnings matching '{search}':\n"]
    for i, l in enumerate(matches, 1):
        lines.append(f"{i}. {l.error_pattern[:50]}...")
        lines.append(f"   → {l.solution}")
        lines.append(f"   Context: {l.context}")
        if l.tags:
            lines.append(f"   Tags: {', '.join(l.tags)}")
        lines.append("")
    
    return "\n".join(lines)


@mcp.tool(icon="📦")
def pip_install(package_name: str) -> str:
    """
    Pre-install a Python package.
    
    Use this to install packages before execution if you know
    you'll need them, or if auto-install missed something.
    
    Args:
        package_name: The pip package name to install
    
    Returns:
        Installation result
    """
    success, message = install_package(package_name)
    return message


@mcp.tool(icon="⚙️")
def configure(
    action: str = "view",
    key: str = "",
    value: str = ""
) -> str:
    """
    View or update Code Mode configuration.
    
    Args:
        action: "view" to see config, "set" to update a value
        key: Config key to update (for action="set")
        value: New value (for action="set")
    
    Available settings:
    - execution_mode: "direct" (fast) or "docker" (secure sandbox)
    - default_timeout: Default execution timeout in seconds
    - max_retries: Default max retry attempts
    - auto_install: Whether to auto-install packages (true/false)
    - docker_image: Docker image for sandbox mode
    
    Examples:
        configure()  # View current config
        configure(action="set", key="execution_mode", value="docker")
        configure(action="set", key="default_timeout", value="120")
    
    Returns:
        Current configuration or update confirmation
    """
    global CONFIG
    
    if action == "view":
        lines = ["⚙️  MCP Code Mode Configuration\n"]
        for k, v in CONFIG.items():
            lines.append(f"   {k}: {v}")
        lines.append(f"\n📁 Config file: {CONFIG_FILE}")
        lines.append(f"📚 Learnings: {len(learning_store.learnings)} recorded")
        return "\n".join(lines)
    
    elif action == "set":
        if not key:
            return "❌ Please specify a key to set"
        
        if key not in DEFAULT_CONFIG:
            return f"❌ Unknown config key: {key}\nValid keys: {', '.join(DEFAULT_CONFIG.keys())}"
        
        # Type conversion
        if key in ["default_timeout", "max_retries"]:
            try:
                value = int(value)
            except ValueError:
                return f"❌ {key} must be an integer"
        elif key == "auto_install":
            value = value.lower() in ["true", "1", "yes"]
        
        CONFIG[key] = value
        save_config(CONFIG)
        
        return f"✅ Updated {key} = {value}"
    
    return f"❌ Unknown action: {action}. Use 'view' or 'set'"


# ============================================================================
# Resources
# ============================================================================

@mcp.resource("codemode://context", icon="🖥️")
def context_resource() -> str:
    """System context as a resource"""
    return format_system_context()


@mcp.resource("codemode://learnings", icon="🧠")
def learnings_resource() -> str:
    """All learnings as a resource"""
    return learning_store.get_summary()


@mcp.resource("codemode://config", icon="⚙️")
def config_resource() -> str:
    """Current configuration as a resource"""
    return json.dumps(CONFIG, indent=2)


# ============================================================================
# MCP Prompts
# ============================================================================

@mcp.prompt(icon="🐛")
def debug_assistant(error_message: str = "", code: str = "") -> list[dict]:
    """
    Debug Assistant - Analyze errors and suggest fixes.

    Provides a structured approach to debugging with:
    - Error analysis and root cause identification
    - Past learnings from similar errors
    - Step-by-step debugging recommendations
    - Common fix patterns

    Args:
        error_message: The error message to debug
        code: The code that produced the error (optional)
    """
    context_parts = []

    if error_message:
        context_parts.append(f"Error Message:\n```\n{error_message}\n```")

        # Find relevant learnings
        relevant = learning_store.find_relevant(error_message, code, limit=3)
        if relevant:
            context_parts.append("\nPast Learnings for Similar Errors:")
            for i, learning in enumerate(relevant, 1):
                context_parts.append(f"{i}. {learning.solution}")
                context_parts.append(f"   Context: {learning.context}")

    if code:
        context_parts.append(f"\nCode:\n```python\n{code}\n```")

    context_str = "\n".join(context_parts) if context_parts else "No error information provided yet."

    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": f"""You are a Python debugging expert. Help analyze and fix this error.

{context_str}

Please:
1. Identify the root cause of the error
2. Explain what went wrong in simple terms
3. Provide a step-by-step fix
4. Show the corrected code
5. Suggest how to prevent this in the future

If the error pattern matches past learnings, incorporate those solutions."""
            }
        }
    ]


@mcp.prompt(icon="⚡")
def code_optimizer(code: str, focus: str = "general") -> list[dict]:
    """
    Code Optimizer - Improve performance and quality.

    Analyzes code and suggests optimizations for:
    - Performance improvements
    - Memory usage reduction
    - Code readability
    - Best practices

    Args:
        code: Python code to optimize
        focus: Optimization focus - "performance", "memory", "readability", or "general"
    """
    focus_guidance = {
        "performance": "Focus on execution speed, algorithmic complexity, and runtime optimizations.",
        "memory": "Focus on memory usage, data structure efficiency, and memory leaks.",
        "readability": "Focus on code clarity, documentation, naming conventions, and maintainability.",
        "general": "Provide balanced optimization suggestions across performance, memory, and readability."
    }

    guidance = focus_guidance.get(focus, focus_guidance["general"])

    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": f"""You are a Python performance optimization expert. Analyze and optimize this code.

Code to Optimize:
```python
{code}
```

Optimization Focus: {focus}
{guidance}

Please:
1. Analyze current performance characteristics
2. Identify bottlenecks and inefficiencies
3. Suggest specific optimizations with code examples
4. Explain the expected performance gains
5. Note any trade-offs or considerations

Provide optimized code with inline comments explaining changes."""
            }
        }
    ]


@mcp.prompt(icon="👀")
def code_reviewer(code: str, review_type: str = "comprehensive") -> list[dict]:
    """
    Code Reviewer - Review code for quality and best practices.

    Performs code review focusing on:
    - Security vulnerabilities
    - Code quality and style
    - Best practices
    - Potential bugs
    - Test coverage suggestions

    Args:
        code: Python code to review
        review_type: Type of review - "security", "quality", "comprehensive"
    """
    review_guidance = {
        "security": "Focus on security vulnerabilities, injection risks, authentication/authorization issues, and data validation.",
        "quality": "Focus on code style, naming conventions, documentation, and maintainability.",
        "comprehensive": "Perform a thorough review covering security, quality, performance, and best practices."
    }

    guidance = review_guidance.get(review_type, review_guidance["comprehensive"])

    # Run code analysis
    analysis = analyze_code(code)
    analysis_context = ""
    if analysis["issues"]:
        analysis_context = f"\n\nAutomated Analysis Found:\n{analysis['report']}"

    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": f"""You are an expert code reviewer. Review this Python code thoroughly.

Code to Review:
```python
{code}
```

Review Type: {review_type}
{guidance}{analysis_context}

Please provide:
1. **Critical Issues** - Security vulnerabilities, bugs, or breaking changes
2. **Improvements** - Code quality, style, and best practices
3. **Suggestions** - Optional enhancements and optimizations
4. **Testing Recommendations** - What tests should be written
5. **Overall Assessment** - Summary with a quality rating

Format your review with clear severity levels and actionable recommendations."""
            }
        }
    ]


@mcp.prompt(icon="📈")
def data_explorer(task: str = "", data_description: str = "") -> list[dict]:
    """
    Data Explorer - Analyze and explore datasets.

    Helps with data analysis tasks:
    - Data exploration and visualization
    - Statistical analysis
    - Data cleaning and transformation
    - Pattern discovery

    Args:
        task: The data analysis task to perform
        data_description: Description of the dataset (format, size, columns, etc.)
    """
    context_parts = []

    if task:
        context_parts.append(f"Task: {task}")

    if data_description:
        context_parts.append(f"Dataset Description: {data_description}")

    context_str = "\n".join(context_parts) if context_parts else "General data exploration"

    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": f"""You are a data analysis expert specializing in Python (pandas, numpy, matplotlib).

{context_str}

Please help with this data analysis by:
1. Suggesting appropriate Python code for the task
2. Recommending best libraries and approaches
3. Including data exploration steps (head, describe, info)
4. Adding visualization code where helpful
5. Handling edge cases and missing data

Write complete, runnable Python code with:
- Clear comments explaining each step
- Error handling for common issues
- Print statements to show results
- Visualizations saved to files when appropriate

Use pandas for data manipulation, matplotlib/seaborn for visualization."""
            }
        }
    ]


@mcp.prompt(icon="🔌")
def api_tester(api_url: str = "", method: str = "GET", description: str = "") -> list[dict]:
    """
    API Tester - Test and validate API endpoints.

    Helps test APIs by:
    - Crafting HTTP requests
    - Validating responses
    - Testing error handling
    - Performance testing

    Args:
        api_url: The API endpoint URL to test
        method: HTTP method (GET, POST, PUT, DELETE, etc.)
        description: Description of what the API should do
    """
    context_parts = []

    if api_url:
        context_parts.append(f"API URL: {api_url}")

    if method:
        context_parts.append(f"HTTP Method: {method}")

    if description:
        context_parts.append(f"Description: {description}")

    context_str = "\n".join(context_parts) if context_parts else "General API testing"

    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": f"""You are an API testing expert. Help test this API endpoint.

{context_str}

Please create comprehensive API test code that:
1. Tests the happy path (successful requests)
2. Tests error handling (invalid inputs, auth failures)
3. Validates response structure and data types
4. Checks response times and performance
5. Tests edge cases and boundary conditions

Write Python code using requests library that:
- Makes the API call with appropriate headers/body
- Validates status codes
- Checks response JSON structure
- Handles errors gracefully
- Prints clear test results
- Measures and reports response times

Include examples of different request scenarios and expected responses."""
            }
        }
    ]
# To be appended to server.py

# ============================================================================
# MCP Completions
# ============================================================================

@mcp.completion(argument_name="package_name", tool_name="pip_install")
def complete_package_names(argument_value: str) -> list[str]:
    """
    Suggest package names for pip_install.

    Provides completion suggestions based on:
    - Available pre-installed libraries
    - Common data science packages
    - Popular Python packages
    """
    # Common packages to suggest
    common_packages = [
        # Web
        "requests", "httpx", "aiohttp", "beautifulsoup4", "lxml", "selenium", "playwright",
        # Data
        "pandas", "numpy", "scipy", "polars",
        # Visualization
        "matplotlib", "seaborn", "plotly", "bokeh",
        # Machine Learning
        "scikit-learn", "tensorflow", "pytorch", "transformers",
        # Images
        "Pillow", "opencv-python", "imageio",
        # Database
        "sqlalchemy", "psycopg2-binary", "pymongo", "redis",
        # Testing
        "pytest", "pytest-asyncio", "pytest-cov", "hypothesis",
        # Utilities
        "python-dotenv", "pyyaml", "toml", "click", "typer",
    ]

    # Filter suggestions based on current input
    if not argument_value:
        return common_packages[:10]  # Return top 10 when no input

    value_lower = argument_value.lower()
    matches = [pkg for pkg in common_packages if value_lower in pkg.lower()]
    return matches[:10]  # Return up to 10 matches


@mcp.completion(argument_name="focus", tool_name="code_optimizer", prompt_name="code_optimizer")
def complete_optimization_focus(argument_value: str) -> list[str]:
    """
    Suggest optimization focus options.

    Provides completion for optimization types:
    - performance: Speed and algorithmic improvements
    - memory: Memory usage and efficiency
    - readability: Code clarity and maintainability
    - general: Balanced optimization
    """
    options = [
        "performance",
        "memory",
        "readability",
        "general"
    ]

    if not argument_value:
        return options

    value_lower = argument_value.lower()
    matches = [opt for opt in options if value_lower in opt.lower()]
    return matches if matches else options


@mcp.completion(argument_name="review_type", prompt_name="code_reviewer")
def complete_review_types(argument_value: str) -> list[str]:
    """
    Suggest code review types.

    Provides completion for review focus:
    - security: Security vulnerabilities
    - quality: Code quality and style
    - comprehensive: Full review
    """
    options = [
        "comprehensive",
        "security",
        "quality"
    ]

    if not argument_value:
        return options

    value_lower = argument_value.lower()
    matches = [opt for opt in options if value_lower in opt.lower()]
    return matches if matches else options


@mcp.completion(argument_name="method", prompt_name="api_tester")
def complete_http_methods(argument_value: str) -> list[str]:
    """
    Suggest HTTP methods for API testing.

    Provides completion for common HTTP methods.
    """
    methods = [
        "GET",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "HEAD",
        "OPTIONS"
    ]

    if not argument_value:
        return methods

    value_upper = argument_value.upper()
    matches = [method for method in methods if value_upper in method]
    return matches if matches else methods
