﻿from setuptools import setup, find_packages
setup(
    name='reversible-unlearning',
    version='0.2.5',
    author='AUREON Labs',
    description='AUREON: Universal Reversible Learning',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/aureon-labs/reversible',
    packages=find_packages(),
    classifiers=['Programming Language :: Python :: 3'],
    python_requires='>=3.8',
    install_requires=['torch>=1.9.0', 'numpy>=1.19.0', 'transformers>=4.0.0', 'datasets>=2.0.0'],
)
