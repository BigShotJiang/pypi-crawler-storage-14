To use this module, you need to:

1.  Go to partner
2.  Click on the `Sales & Purchase` tab
3.  Add user on `Purchase Manager` field
