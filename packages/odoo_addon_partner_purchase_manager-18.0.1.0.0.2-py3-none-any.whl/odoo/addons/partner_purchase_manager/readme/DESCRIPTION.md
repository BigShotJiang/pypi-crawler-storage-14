This module add purchase manager field in partner.
