"""
Taiji HASP license protection wrapper
"""

__version__ = "0.3.2"

from .taiji_hasp import TaiJiHasp

