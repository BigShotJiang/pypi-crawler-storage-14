"""
RDS Ops Kit – Command Line Interface.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import click

# ---------------------------------------------------------
# Version handling
# ---------------------------------------------------------
try:
    from rds_ops_kit import __version__
except Exception:
    __version__ = "2.1.0"


# ---------------------------------------------------------
# CLI Context
# ---------------------------------------------------------
@dataclass
class CLIContext:
    verbose: bool = False


# ---------------------------------------------------------
# Click main group
# ---------------------------------------------------------
@click.group()
@click.version_option(__version__, prog_name="rds-ops-kit")
@click.option("--verbose", is_flag=True, help="Enable verbose mode.")
@click.pass_context
def cli(ctx: click.Context, verbose: bool) -> None:
    """RDS Ops Kit – unified CLI for PG presets, planning, readiness and tools."""
    ctx.obj = CLIContext(verbose=verbose)


# Kompatibilität für Tests / alte Aufrufe
app = cli


# ---------------------------------------------------------
# oracle_parser-Integration
# ---------------------------------------------------------
try:
    # oracle_parser.py liegt im selben Paket 'cli'
    from . import oracle_parser as _oracle_parser
except Exception:  # pragma: no cover
    _oracle_parser = None  # type: ignore[assignment]


# ---------------------------------------------------------
# Helper for webapp (score calculation)
# ---------------------------------------------------------
def _compute_readiness_score(findings: dict) -> int:
    """
    Compute a simple readiness score (0–100) based on findings.

    Unterstützt sowohl 'checks' als auch 'issues' als Schlüssel.
    """
    if not isinstance(findings, dict):
        return 0

    checks = findings.get("checks")
    if not isinstance(checks, list):
        checks = findings.get("issues", [])
    if not isinstance(checks, list):
        return 0

    score = 100
    for issue in checks:
        if not isinstance(issue, dict):
            continue

        severity = str(issue.get("severity", "medium")).lower()

        if severity == "high":
            score -= 20
        elif severity == "medium":
            score -= 10
        elif severity == "low":
            score -= 5

    return max(score, 0)


# ---------------------------------------------------------
# Simple Fallback Engine – nur falls oracle_parser nicht verfügbar ist
# ---------------------------------------------------------
class SimpleReadinessEngine:
    """
    Minimaler Fallback-Readiness-Engine:

    - scannt eine DDL-Datei nach CREATE TABLE
    - erzeugt pro Tabelle ein LOW/INFO-"Issue"
    - simple Tabellen-Heatmap

    Wird nur verwendet, wenn der Import von oracle_parser fehlschlägt.
    """

    TABLE_PATTERN = re.compile(
        r"CREATE\s+TABLE\s+(?P<name>(\"?[A-Za-z0-9_]+\"?(?:\.[\"A-Za-z0-9_]+\")?))",
        re.IGNORECASE,
    )

    def run_check(
        self,
        ddl_path: str,
        context: Optional[CLIContext] = None,
        output_format: str | None = None,
        **_: Any,
    ) -> Dict[str, Any]:
        path = Path(ddl_path)
        text = path.read_text(encoding="utf-8", errors="ignore")

        tables: List[str] = []
        for match in self.TABLE_PATTERN.finditer(text):
            raw_name = match.group("name")
            tables.append(raw_name)

        checks: List[Dict[str, Any]] = []
        tables_map: Dict[str, Dict[str, Any]] = {}

        for t in tables:
            schema: Optional[str] = None
            object_name = t
            if "." in t:
                parts = t.split(".", 1)
                schema = parts[0].strip('"')
                object_name = parts[1].strip('"')
            else:
                object_name = t.strip('"')

            issue = {
                "schema": schema or "-",
                "object_type": "TABLE",
                "object_name": object_name,
                "id": "DDL_TABLE_PRESENT",
                "severity": "LOW",
                "status": "INFO",
                "details": "Table detected in DDL (SimpleReadinessEngine).",
            }
            checks.append(issue)

            stat = tables_map.setdefault(
                object_name,
                {"score": 100, "high": 0, "medium": 0, "low": 0},
            )
            stat["low"] += 1
            stat["score"] = max(stat["score"] - 5, 0)

        findings: Dict[str, Any] = {
            "ddl_path": str(path),
            "summary": "Simple DDL scan executed (fallback engine).",
            "checks": checks,
            "issues": checks,   # Alias für Kompatibilität
            "tables": tables_map,
        }

        return findings

    def write_html_report(
        self,
        ddl_path: str,
        out_path: str,
        context: Optional[CLIContext] = None,
        **_: Any,
    ) -> None:
        findings = self.run_check(ddl_path, context=context, output_format="dict")
        score = _compute_readiness_score(findings)

        checks = findings.get("checks", [])
        if not isinstance(checks, list):
            checks = []

        rows: List[str] = []
        for issue in checks:
            if not isinstance(issue, dict):
                continue
            schema = issue.get("schema") or "-"
            obj_type = issue.get("object_type") or "-"
            obj_name = issue.get("object_name") or "-"
            sev = issue.get("severity") or "-"
            status = issue.get("status") or "-"
            details = issue.get("details") or ""
            rows.append(
                f"<tr><td>{schema}</td><td>{obj_type}</td><td>{obj_name}</td>"
                f"<td>{sev}</td><td>{status}</td><td>{details}</td></tr>"
            )

        issues_html = "\n".join(rows)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>RDS Ops Kit – Simple Readiness Report</title>
  <style>
    body {{ font-family: sans-serif; margin: 2rem; }}
    .score {{ font-size: 2rem; font-weight: bold; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
    th, td {{ border: 1px solid #ccc; padding: 0.5rem; text-align: left; }}
    th {{ background: #f0f0f0; }}
  </style>
</head>
<body>
  <h1>Simple Readiness Report</h1>
  <p><strong>DDL:</strong> {ddl_path}</p>
  <p class="score">Score: {score} / 100</p>

  <h2>Detected Tables</h2>
  <table>
    <thead>
      <tr>
        <th>Schema</th>
        <th>Typ</th>
        <th>Objekt</th>
        <th>Severity</th>
        <th>Status</th>
        <th>Details</th>
      </tr>
    </thead>
    <tbody>
      {issues_html}
    </tbody>
  </table>
</body>
</html>
"""
        Path(out_path).write_text(html, encoding="utf-8")


# ---------------------------------------------------------
# OracleParserEngine – benutzt deine cli/oracle_parser.py
# ---------------------------------------------------------
class OracleParserEngine:
    """
    Readiness-Engine, die deine cli/oracle_parser.py nutzt.

    - Für DDL-Dateien: analyze_file_for_readiness(path)
    - Liefert 'checks', 'issues' (Alias) und eine Tabellen-Heatmap
    """

    def run_check(
        self,
        ddl_path: str,
        context: Optional[CLIContext] = None,
        output_format: str | None = None,
        **_: Any,
    ) -> Dict[str, Any]:
        if _oracle_parser is None:
            raise RuntimeError("oracle_parser konnte nicht importiert werden.")

        path = Path(ddl_path)
        checks = _oracle_parser.analyze_file_for_readiness(path)

        # Tabellen-Heatmap pro Tabelle aus Checks bauen
        tables: Dict[str, Dict[str, Any]] = {}
        for c in checks:
            if not isinstance(c, dict):
                continue
            if c.get("object_type") != "TABLE":
                continue
            tname = c.get("object_name") or "-"
            sev = str(c.get("severity", "")).upper()

            stat = tables.setdefault(
                tname,
                {"score": 100, "high": 0, "medium": 0, "low": 0},
            )
            if sev == "HIGH":
                stat["high"] += 1
                stat["score"] -= 20
            elif sev == "MEDIUM":
                stat["medium"] += 1
                stat["score"] -= 10
            elif sev == "LOW":
                stat["low"] += 1
                stat["score"] -= 5
            stat["score"] = max(stat["score"], 0)

        findings: Dict[str, Any] = {
            "ddl_path": str(path),
            "summary": "Oracle DDL readiness analysis (oracle_parser).",
            "checks": checks,
            "issues": checks,   # Alias, damit alles, was 'issues' erwartet, weiterläuft
            "tables": tables,
        }

        return findings

    def write_html_report(
        self,
        ddl_path: str,
        out_path: str,
        context: Optional[CLIContext] = None,
        **_: Any,
    ) -> None:
        findings = self.run_check(ddl_path, context=context, output_format="dict")
        score = _compute_readiness_score(findings)

        checks = findings.get("checks", [])
        if not isinstance(checks, list):
            checks = []

        rows: List[str] = []
        for issue in checks:
            if not isinstance(issue, dict):
                continue
            schema = issue.get("schema") or "-"
            obj_type = issue.get("object_type") or "-"
            obj_name = issue.get("object_name") or "-"
            sev = issue.get("severity") or "-"
            status = issue.get("status") or "-"
            details = issue.get("details") or ""
            rows.append(
                f"<tr><td>{schema}</td><td>{obj_type}</td><td>{obj_name}</td>"
                f"<td>{sev}</td><td>{status}</td><td>{details}</td></tr>"
            )

        issues_html = "\n".join(rows)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>RDS Ops Kit – Oracle Parser Readiness Report</title>
  <style>
    body {{ font-family: sans-serif; margin: 2rem; }}
    .score {{ font-size: 2rem; font-weight: bold; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
    th, td {{ border: 1px solid #ccc; padding: 0.5rem; text-align: left; }}
    th {{ background: #f0f0f0; }}
  </style>
</head>
<body>
  <h1>Oracle Parser Readiness Report</h1>
  <p><strong>DDL:</strong> {ddl_path}</p>
  <p class="score">Score: {score} / 100</p>

  <h2>Detected Findings</h2>
  <table>
    <thead>
      <tr>
        <th>Schema</th>
        <th>Typ</th>
        <th>Objekt</th>
        <th>Severity</th>
        <th>Status</th>
        <th>Details</th>
      </tr>
    </thead>
    <tbody>
      {issues_html}
    </tbody>
  </table>
</body>
</html>
"""
        Path(out_path).write_text(html, encoding="utf-8")


# ---------------------------------------------------------
# Engines (PG, Planning, Readiness)
# ---------------------------------------------------------
pg_engine: Any = None
planning_engine: Any = None

# Bevorzugt: OracleParserEngine (deine echte Logik)
try:  # pragma: no cover
    readiness_engine: Any = OracleParserEngine()
except Exception:
    # Fallback: SimpleReadinessEngine
    readiness_engine = SimpleReadinessEngine()


# ---------------------------------------------------------
# PG COMMANDS
# ---------------------------------------------------------
@cli.group()
def pg() -> None:
    """Operations on PostgreSQL parameter presets."""
    pass


@pg.command("list")
@click.pass_context
def pg_list(ctx: click.Context) -> None:
    if pg_engine is None:
        click.echo("PG engine is not configured.")
        return
    presets = pg_engine.list_presets(context=ctx.obj)
    for p in presets:
        click.echo(p)


@pg.command("show")
@click.argument("name")
@click.pass_context
def pg_show(ctx: click.Context, name: str) -> None:
    if pg_engine is None:
        click.echo("PG engine is not configured.")
        return
    preset = pg_engine.show_preset(name, context=ctx.obj)
    for k, v in preset.items():
        click.echo(f"{k}: {v}")


@pg.command("diff")
@click.argument("a")
@click.argument("b")
@click.pass_context
def pg_diff(ctx: click.Context, a: str, b: str) -> None:
    if pg_engine is None:
        click.echo("PG engine is not configured.")
        return
    diffs = pg_engine.diff_presets(a, b, context=ctx.obj)
    for line in diffs:
        click.echo(line)


@pg.command("export")
@click.argument("target")
@click.argument("name")
@click.option("--out", type=click.Path(), required=True, help="Output JSON file.")
@click.pass_context
def pg_export(ctx: click.Context, target: str, name: str, out: str) -> None:
    if pg_engine is None:
        click.echo("PG engine is not configured.")
        return
    data = pg_engine.export_preset(target, name, context=ctx.obj)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    click.echo(f"Exported to {out}")


# ---------------------------------------------------------
# PLAN COMMANDS
# ---------------------------------------------------------
@cli.group()
def plan() -> None:
    """Planning engine for environment diffs and validations."""
    pass


@plan.command("generate")
@click.option("--config", type=str, required=True, help="Environment config path.")
@click.option("--out", type=click.Path(), required=True, help="Output plan file.")
@click.pass_context
def plan_generate(ctx: click.Context, config: str, out: str) -> None:
    if planning_engine is None:
        click.echo("Planning engine is not configured.")
        return

    result = planning_engine.generate_plan(config_path=config, context=ctx.obj)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    click.echo(f"Plan written to {out}")


@plan.command("validate")
@click.option("--config", type=str, required=True, help="Environment config path.")
@click.option("--plan", type=click.Path(), required=True, help="Plan JSON input file.")
@click.pass_context
def plan_validate(ctx: click.Context, config: str, plan: str) -> None:
    if planning_engine is None:
        click.echo("Planning engine is not configured.")
        return

    with open(plan, "r", encoding="utf-8") as f:
        plan_data = json.load(f)

    ok = planning_engine.validate_plan(
        config_path=config,
        plan=plan_data,
        context=ctx.obj,
    )

    if ok:
        click.echo("Plan is valid.")
    else:
        click.echo("Plan has issues.")


# ---------------------------------------------------------
# READINESS COMMANDS
# ---------------------------------------------------------
@cli.group()
def readiness() -> None:
    """Readiness checks for Oracle → PostgreSQL migrations."""
    pass


@readiness.command("check")
@click.option("--source", type=click.Path(exists=True), required=True, help="DDL Source file.")
@click.pass_context
def readiness_check_cmd(ctx: click.Context, source: str) -> None:
    findings = readiness_engine.run_check(
        ddl_path=source,
        context=ctx.obj,
        output_format="dict",
    )
    click.echo(json.dumps(findings, indent=2))


@readiness.command("report")
@click.option("--source", type=click.Path(exists=True), required=True, help="DDL Source file.")
@click.option("--out", type=click.Path(), required=True, help="Output HTML report.")
@click.pass_context
def readiness_report_cmd(ctx: click.Context, source: str, out: str) -> None:
    readiness_engine.write_html_report(
        ddl_path=source,
        out_path=out,
        context=ctx.obj,
    )
    click.echo(f"Report written to {out}")


# ---------------------------------------------------------
# Entry point
# ---------------------------------------------------------
def main() -> None:
    cli()


if __name__ == "__main__":
    main()
