"""
RDS Ops Kit - Package Root
"""

from importlib.metadata import version, PackageNotFoundError

try:
    # Name des PyPI-Pakets
    __version__ = version("rds-ops-kit")
except PackageNotFoundError:
    # Fallback für Entwicklungs-Umgebung (nicht installiert, nur aus Source)
    __version__ = "2.1.0"
