import tkinter as tk
import random


class FireworkGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.attributes("-fullscreen", True)
        self.canvas = tk.Canvas(self.root, bg="black")
        self.canvas.pack(fill="both", expand=True)

        self.root.bind("<Escape>", lambda e: self.root.destroy())
        self.root.after(200, self.animate)

    def animate(self):
        for _ in range(10):
            x = random.randint(100, self.root.winfo_screenwidth() - 100)
            y = random.randint(100, self.root.winfo_screenheight() - 200)
            self.explode(x, y)

        self.root.after(600, self.animate)

    def explode(self, x, y):
        colors = ["red", "yellow", "cyan", "magenta", "green", "white"]
        for _ in range(30):
            dx = random.randint(-60, 60)
            dy = random.randint(-60, 60)
            color = random.choice(colors)
            size = random.randint(3, 6)

            self.canvas.create_oval(
                x + dx, y + dy, x + dx + size, y + dy + size, fill=color
            )
        self.canvas.update()


def play():
    FireworkGUI().root.mainloop()
