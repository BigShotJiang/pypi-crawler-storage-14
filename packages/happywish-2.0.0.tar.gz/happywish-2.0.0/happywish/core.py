import time
import os
import random
from colorama import init, Fore

init(autoreset=True)

frames = [
    Fore.YELLOW + "🎉 HAPPY BIRTHDAY 🎉",
    Fore.MAGENTA + "🥳 Wishing You A Fantastic Year Ahead 🥳",
    Fore.CYAN + "💖 Keep Smiling Always 💖",
    Fore.GREEN + "✨ You Are Awesome ✨",
]


def fireworks_ascii():
    colors = [Fore.RED, Fore.YELLOW, Fore.MAGENTA, Fore.CYAN, Fore.GREEN, Fore.WHITE]
    for _ in range(25):
        os.system("cls" if os.name == "nt" else "clear")
        x = random.randint(10, 50)
        y = random.randint(3, 15)
        color = random.choice(colors)

        for _ in range(y):
            print()

        print(" " * x + color + "*")
        time.sleep(0.05)


def play_text(name=None):
    os.system("cls" if os.name == "nt" else "clear")

    if name:
        print(Fore.CYAN + f"\n\n✨ This one's for {name}! ✨\n")
        time.sleep(1)

    for _ in range(3):
        for frame in frames:
            os.system("cls" if os.name == "nt" else "clear")
            print("\n\n" + frame.center(60))
            time.sleep(0.7)

    fireworks_ascii()
    print(Fore.YELLOW + "\n🎂🎂 HAPPY BIRTHDAY!!! 🎂🎂\n")
