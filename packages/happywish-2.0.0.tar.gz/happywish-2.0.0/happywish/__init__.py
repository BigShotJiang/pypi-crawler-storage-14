from .gui import play as play
from .core import play_text as play_text

__all__ = ["play", "play_text"]
