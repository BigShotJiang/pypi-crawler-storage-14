# HappyWish 🎉

A simple and joyful birthday animation library.

## Usage

```python
import happywish

happywish.play()        # Opens fullscreen GUI fireworks 🎆  
happywish.play_text()   # Terminal animation (optional)
