from setuptools import setup, find_packages

setup(
    name="happywish",
    version="2.0.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["colorama"],
    description="Birthday GUI fireworks animation.",
    long_description=open("README.md", "r").read(),
    long_description_content_type="text/markdown",
    author="Adi",
)
