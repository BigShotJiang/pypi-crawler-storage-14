# wox

[![pipeline status](https://gitlab.com/wbarillon/wox/badges/main/pipeline.svg?key_text=🔄+Pipeline+status&key_width=113)](https://gitlab.com/wbarillon/wox/-/commits/main)
[![coverage report](https://gitlab.com/wbarillon/wox/badges/main/coverage.svg?key_text=✅+Coverage+report&key_width=122)](https://gitlab.com/wbarillon/wox/-/commits/main)

Wox is a lightweight Python task automation tool designed to simplify development workflows.
It allows you to run tasks in isolated Python environments, manage dependencies, and execute commands exactly as you would in your terminal.

With wox, you can:

- Run tests across multiple Python versions effortlessly.
- Automate common tasks like linting, formatting, or documentation generation.
- Execute any shell command or entry point from Python or other languages (Java, C, JavaScript, …) in a controlled environment.
- Keep your workspace clean with ``.wox``, where virtual environments and logs are automatically managed.

Wox gives you **full transparency and control** over your automation: no hidden behaviors, no surprises. You declare your tasks in a ``wox.toml`` or ``pyproject.toml`` file, and wox handles the rest.

## Quickstart

Install with pip:

```bash
pip install wox
```

Or use [pipx][pipx-landing-page] to run wox without Python virtual environments:

```bash
pipx install wox
```

Then, create a task in your ``wox.toml`` and run it with:

```bash
wox
```

Check the documentation for detailed guides and examples.

[pipx-landing-page]: https://pipx.pypa.io/stable/
