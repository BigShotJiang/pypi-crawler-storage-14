# Wox setup for wox developers

## Installation

Create a new directory (or workspace on IDE) and type the following command from it:

```bash
git clone <repo> .
```

Switch on the develop branch to see the codebase.

Create a new virtual environment, activate it and type the next command:

```bash
pip install -e ".[uv, doc, dev]"
```

Since wox is using pre-commit, it must be initialized to apply on every commit:

```bash
pre-commit install
```

## Where to begin with?

### Reading documentation

I strongly suggest reading the documentation at least once. Build it with the instructions on the README file located in ``./docs/``.

The documentation is accessible from ``./docs/build/dirhtml/index.html``.

To access it on vscode, I suggest the [Live Server][live-server-repo] extension or any means which opens a local development server for .html files.

As a fallback solution, use the built-in http.server Python library:

```bash
python -B -m http.server -d <path to index.html directory>

python -B -m http.server -d ./docs/build/dirhtml
```

### Running tests

The officiel test validation is done with the following coverage command:

```bash
coverage run -m pytest -rA --no-header \
--html=./reports/pytest/report.html \
--self-contained-html && \
coverage html
```

For development purpose, I strongly suggest to not break the code and refacto wox from tests. If there is a function or a method, there is a test associated.

## What is my purpose as a wox developer?

You're in charge of ensuring wox compatibility on your exploitation system (windows[^1] or mac). If I were you, I would look for codes related to pathlib or any path related features. Then I would look for codes related to platform, the library that checks on which exploitation system Python is running.

Finally, I would pay close attention to those modules:
- main.py - the wox session;
- configurator.py;
- python_discoverer.py;
- venv_management.py;
- subprocessor.py;

## Enable signing on commit and tags

Being a wox developer means you're part of an open-source project. You should definitely add it on your resume. Since a tech person in charge of recruitment might check your contributions on wox, while it is not mandatory, I highly suggest you sign your commits and tags.

Check how to enable it on your respective platforms.

[^1]: On windows, do not run wox in WSL. The whole point is to check wox compatibility with windows, not the linux distribution hosted by windows.

[live-server-repo]: https://github.com/ritwickdey/vscode-live-server
