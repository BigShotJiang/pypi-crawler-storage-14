class WoxException(Exception):
    """
        Base class for wox exceptions.

        Attributes
        ----------
        message : str
        type : str
            Name of the exception class.
    """
    def __init__(self, message):
        self.message = message
        self.type = self.__class__.__name__

    def __str__(self):
        return f'{self.type}: {self.message}'

class ConfigFileNotFoundError(WoxException):
    """
        Raised when missing wox.toml or pyproject.toml file.
    """

    def __init__(self):
        super().__init__(
            message = (
                'Provide a configuration file (wox.toml or pyproject.toml). '
                'Check <url to doc>.'
            )
        )

class CommandNotFoundError(WoxException):
    """
        Raised when a command cannot be found in the system PATH.

        Parameters
        ----------
        command : str
            The command that was not found.
    """

    def __init__(self, command):
        super().__init__(message = f'Command {command} not found.')

class DependencyConflictError(WoxException):
    """
        Raised when a dependency conflict is detected during package installation.

        Suggestion: Check the subprocess logs for conflicting packages.
    """

    def __init__(self):
        super().__init__(
            message = (
                'Dependency conflict detected. Check logs from subprocess '
                'for more details.'
            )
        )

class DiskFullError(WoxException):
    """
        Raised when an operation fails due to insufficient disk space.
    """

    def __init__(self):
        super().__init__(message = 'Installation failed: disk is full.')

class MissingWoxKeywordError(WoxException):
    """
        Raised when wox setting in toml file doesn't exist.
    """

    def __init__(self, key):
        super().__init__(message = (
                f'Wox keyword {key} not found in .toml file. '
                f'Check the documentation <how to create a wox toml file>.'
            )
        )

class MissingWoxSectionError(WoxException):
    """
        Raised when wox section not found in pyproject.toml.
    """

    def __init__(self):
        super().__init__(message = 'Wox section not found in pyproject.toml')

class NoTaskError(WoxException):
    """
        Raised when ``--task`` and ``exclude-task`` have the same tasks.
    """
    def __init__(self):
        super().__init__(
            message = 'No tasks to run.'
        )

class PackageNotFoundError(WoxException):
    """
        Raised when attempting to install a package that does not exist.

        Parameters
        ----------
        missing_package : str
            Name of the missing package.
        environment : str
            Environment where the installation was attempted.
    """

    def __init__(self, missing_package, environment):
        super().__init__(message = f'Unable to install {missing_package} in {environment}')

class PermissionDeniedError(WoxException):
    """
        Raised when a write operation fails due to insufficient permissions.
    """

    def __init__(self):
        super().__init__(message = 'Unable to write files due to insufficient permissions.')

class PipTimeoutError(WoxException):
    """
        Raised when pip cannot reach the package index due to network issues or a timeout.
    """

    def __init__(self):
        super().__init__(
            message = 'Unable to connect to the package index '
            '(network timeout or unreachable source).'
        )

class PythonBuildNotFoundError(WoxException):
    """
        Raised when no Python interpreter is found for the requested version.

        Parameters
        ----------
        path : str
            Path to declared python build in .toml file.
    """

    def __init__(self, path):
        super().__init__(message = f"Python build not found on path '{path}'.")

class PythonInterpreterCallError(WoxException):
    """
        Raised when a Python interpreter call would start an interactive session and
        block execution.

        Parameters
        ----------
        command : str
            The command that was attempted.
    """

    def __init__(self, command):
        super().__init__(
            message = (
                f"The '{command}' command would have launched an interactive "
                "session of Python and stuck the session."
            )
        )

class PythonInterpreterNotFoundError(WoxException):
    """
        Raised when no Python interpreter is found for the requested version.

        Parameters
        ----------
        version : str
            Python version requested.
    """

    def __init__(self, version):
        super().__init__(message = f'Python interpreter not found for version {version}.')

class PythonInterpreterUnstableError(WoxException):
    """
        Raised when the Python interpreter is unstable and fails to execute commands.

        Suggestion: Recompile the interpreter or use a different build.

        Notes
        -----
        https://docs.python.org/3.14/using/configure.html
    """

    def __init__(self, version):
        super().__init__(
            message = (
                f'Interpreter for Python {version} appears unstable, '
                'recompile your interpreter or use a different build.'
            )
        )

class TaskNotFoundError(WoxException):
    """
        Raised when a task not present in the .toml file is passed to 'wox command --task'.
    """

    def __init__(self, task):
        super().__init__(message = f'Tasks {task} not found in .toml file.')

class NotPythonVenvWarning(WoxException):
    """
        Raised when the environment declared in .toml file is not
        a Python virtual environment.
    """

    def __init__(self, env_path):
        super().__init__(
            message = (
                f"Wox detected '{env_path.name}' as a non-Python virtual environment. "
                "Wox will use it as-is for the session."
            )
        )
