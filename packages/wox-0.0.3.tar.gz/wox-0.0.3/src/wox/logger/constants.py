CONTEXTUAL_INFO = {
    'task': 'wox',
    'env': 'host'
}

DATEFMT = '%Y-%m-%d %H:%M:%S'

# f-strings style sets to ease the use of padding. See https://medium.com/@johnidouglasmarangon/padding-f-strings-in-python-977b17edbd36
STYLE = '{'
