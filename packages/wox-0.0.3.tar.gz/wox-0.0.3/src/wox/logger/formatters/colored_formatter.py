import colorlog

from wox.logger.constants import (
    CONTEXTUAL_INFO,
    DATEFMT,
    STYLE
)


contextual_data = ':'.join(f'{{{key}}}' for key in CONTEXTUAL_INFO)
format = (
    f'[{contextual_data}|{{levelname_log_color}}{{levelname:<8}}({{levelno}}){{reset}}] '
    f'{{levelname_log_color}}{{message}}{{reset}}'
)

colored_formatter = colorlog.ColoredFormatter(
    fmt = format,
    datefmt = DATEFMT,
    # https://pypi.org/project/colorlog/#description
    # The available colours are black, red, green, yellow, blue, purple, cyan and white.
    # See https://en.wikipedia.org/wiki/ANSI_escape_code.
    secondary_log_colors = {
        'levelname': {
            'DEBUG': 'cyan',
            'INFO': 'white',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red,bold',
        }
    },
    style = STYLE,
    defaults = CONTEXTUAL_INFO
)
