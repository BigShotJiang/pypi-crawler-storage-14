import logging

from wox.logger.constants import (
    CONTEXTUAL_INFO,
    DATEFMT,
    STYLE
)


contextual_data = ':'.join(f'{{{key}}}' for key in CONTEXTUAL_INFO)
format = f'[{contextual_data}|{{levelname:<8}}({{levelno}})] {{message}}'

formatter = logging.Formatter(
    # https://docs.python.org/3/library/logging.html#logrecord-attributes
    fmt = format,
    datefmt = DATEFMT,
    style = STYLE,
    defaults = CONTEXTUAL_INFO
)
