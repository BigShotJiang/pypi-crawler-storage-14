import logging

from wox.logger.formatters.colored_formatter import colored_formatter


def initialize_console_handler():
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(colored_formatter)

    return console_handler
