import logging
import os
import sys

from datetime import datetime

from wox.constants import DOT_WOX
from wox.logger.formatters.formatter import formatter


def initialize_log_file_handler():
    if os.getenv('WOX_SUBPROCESSOR_NO_LOG') == '1':
        return None
    if 'pytest' in sys.modules:
        log_path = DOT_WOX / '.logs' / 'tests'
        log_path.mkdir(parents = True, exist_ok = True)
        filename = log_path / f'output-{datetime.now():%Y-%m-%d_%H-%M-%S}.log'
    else:
        log_path = DOT_WOX / '.logs' / 'wox-session'
        log_path.mkdir(parents = True, exist_ok = True)
        filename = log_path/ f'output-{datetime.now():%Y-%m-%d_%H-%M-%S}.log'

    log_file_handler = logging.FileHandler(
        filename = filename,
        encoding = 'utf-8'
    )
    log_file_handler.setFormatter(formatter)

    return log_file_handler
