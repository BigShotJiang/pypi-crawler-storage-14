import logging

from wox.logger.constants import CONTEXTUAL_INFO


def update_context(logger, contextual_info_overrides):
    """
        Returns a LoggerAdapter that enriches log records with contextual information.

        Parameters
        ----------
        logger : logging.Logger
            The base logger to wrap.
        contextual_info_overrides : dict
            Contextual key-value pairs overriding the defaults in CONTEXTUAL_INFO.

        Returns
        -------
        logging.LoggerAdapter
            A logger adapter bound to the provided contextual information.
    """
    context = CONTEXTUAL_INFO.copy()
    context.update(contextual_info_overrides)
    return logging.LoggerAdapter(logger, context)
