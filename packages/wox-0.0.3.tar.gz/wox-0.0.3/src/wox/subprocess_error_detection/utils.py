import re


def detect_error_from_stderr(stderr_output, expressions):
    """
        Searches for expressions in output of subprocess.

        Parameters
        ----------
        stderr_output : str
            Output captured from the subprocess stderr stream.
        expressions : list
            List of expressions likely to be in stderr_output.

        Returns
        -------
        bool
            True if any expression is found in stderr_output.
    """

    return any(expression in stderr_output.lower() for expression in expressions)

def detect_sentence_with_fill_in_blank(stderr_output, sentence):
    """
        Searches for a fill-in-the-blank text in output of subprocess.
        All fill-in-the-blank are represented by a wildcard (*).

        Parameters
        ----------
        stderr_output : str
            Output captured from the subprocess stderr stream.
        sentence : str
            Sentence likely to be in stderr_output.

        Returns
        -------
        bool
            True if the sentence is found in stderr_output.
    """

    stderr_output = normalize_text(stderr_output)

    sentence = re.escape(sentence).replace(r'\*', '.*?')
    regex = re.compile(sentence, re.DOTALL)
    return bool(regex.search(stderr_output))

def normalize_text(text):
    """
        Replaces all whitespaces and multiples return to line by one space and
        lowers the text.

        Parameters
        ----------
        text : str

        Returns
        -------
        str
    """

    return re.sub(r'\s+', ' ', text).strip().lower()
