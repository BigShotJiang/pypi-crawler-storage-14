"""
    This module contains (trouver mieux, comme rassembler) all errors that may occur during
    the naive discovery of Python happening in subprocessor call from python_discoverer.py.
"""

from wox.utils import get_python_version_from_command
from wox.wox_exceptions import PythonBuildNotFoundError, PythonInterpreterNotFoundError


def detect_python_discovery_errors(command):
    """
        Detects errors upon naive python discovery.

        Parameters
        ----------
        command: str
            Command executed by subprocess.

        Raises
        ------
        PythonInterpreterNotFoundError
            The Python interpreter for the specified version cannot be found.
        PythonBuildNotFoundError
            The specified Python interpreter build cannot be found.
    """

    check_python_interpreter_not_found_error(command)

def check_python_interpreter_not_found_error(command):
    if 'sys.executable' in command:
        if command.startswith('python') or command.startswith('py'):
            version = get_python_version_from_command(command)
            raise PythonInterpreterNotFoundError(version)
        else:
            python_build = command.split()[0]
            raise PythonBuildNotFoundError(python_build)



