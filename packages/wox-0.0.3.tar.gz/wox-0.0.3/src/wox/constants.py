from enum import IntEnum
from pathlib import Path


DOT_WOX = Path.cwd() / '.wox'

# MSV stands for minimum supported version
MSV_VIRTUALENV = '>= 3.7'
MSV_UV = '>= 3.8'

class ExitCode(IntEnum):
    """
        Standardized exit codes for Wox CLI.

        Notes
        -----
        0 - SUCCESS
            Normal execution completed successfully.

        1 - RUNTIME_ERROR
            Unhandled or internal error occurred during execution.

        2 - CONFIG_ERROR
            Misconfiguration or missing setup.

        130 - INTERRUPTED
            Process interrupted by user (SIGINT).
    """

    SUCCESS = 0
    RUNTIME_ERROR = 1
    CONFIG_ERROR = 2
    INTERRUPTED = 130
