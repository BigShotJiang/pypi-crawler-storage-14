import argparse
import sys

from wox._version import __version__


def parser_definition():
    parser = argparse.ArgumentParser(
        prog = 'wox',
        description = (
            'A declarative CLI that runs reproducible tasks inside '
            'isolated Python environments'
        ),
        formatter_class = argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        '-V', '--version',
        action = 'version',
        version = f'%(prog)s {__version__}',
        help = 'prints the version of wox and exit'
    )
    parser.add_argument(
        '-v', '--verbose',
        action = 'store_true',
        help = 'enables verbose output'
    )
    parser.add_argument(
        '--task',
        nargs = '+',
        help = 'selects the tasks to execute among those in the .toml file'
    )
    parser.add_argument(
        '--exclude-task',
        nargs = '+',
        help = 'excludes the tasks to execute among those in the .toml file'
    )
    parser.add_argument(
        '--purge',
        action = 'store_true',
        help = (
            'deletes all directories and files in .wox except .logs, .gitignore '
            'and CACHEDIR.TAG'
        )
    )

    return parser.parse_args()

def main_cli():
    """
        Wox entrypoint.

        Raises
        ------
        Exception
            Any Exception that is not a WoxException, that is,
            any exception not handled by wox.

        Notes
        -----
        Raised exception always return 1 as exit code, same value
        as ExitCode.RUNTIME_ERROR.
    """
    parser = parser_definition()
    cli_options = vars(parser)

    try:
        from wox.cli_control import cli_controller

        exit_code = cli_controller(cli_options)
        sys.exit(exit_code)
    except Exception:
        raise
