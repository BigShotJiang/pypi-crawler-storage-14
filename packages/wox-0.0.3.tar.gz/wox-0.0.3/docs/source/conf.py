# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = 'wox'
copyright = '2025, wbarillon'
author = 'wbarillon'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.napoleon',
    'sphinx.ext.viewcode',
    'sphinx_design'
]

templates_path = ['_templates']
exclude_patterns = []

add_module_names = False

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'furo'
html_static_path = ['_static']
html_css_files = ['css/custom.css', 'css/colors.css']
html_js_files = ['js/custom.js']

# Use of already included s5defs.txt
# https://docutils.sourceforge.io/docs/ref/rst/definitions.html
# https://docutils.sourceforge.io/docutils/parsers/rst/include/s5defs.txt
# Enables the uses of role :color: (example at command_line_options.rst)
rst_prolog = """
.. include:: <s5defs.txt>

"""
