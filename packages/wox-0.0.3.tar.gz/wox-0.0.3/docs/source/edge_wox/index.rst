Edge wox
========

Wox may have drawn your attention but you're unsure if it fits your workflow. You feel like on the edge of what wox offers. Fortunately, wox is very permissive by nature. So you can tweak the wox's rules and see what happens.


Play around with wox a bit, it could work!

.. toctree::
    :maxdepth: 2

    questions_answers
    use_cases
