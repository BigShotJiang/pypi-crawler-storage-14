Questions / Answers
===================

What does wox consider as a valid Python virtual environment?
-------------------------------------------------------------

For wox, a virtual environment is considered valid if it contains at least:

- a pyvenv.cfg file, the metadata version such as version = major.minor.patch;

- a Python interpreter binary located in either the Scripts (Windows) or bin (Linux/macOS) directory.

What is a valid python build?
-----------------------------

A valid Python build is simply any interpreter capable of:

- opening a REPL;

- executing basic commands;

- running scripts normally.

If your Python executable can do that, then the python_build setting should work as expected.
Custom builds, embedded builds, self-compiled builds: they’re all fair game, as long as they behave like Python.

Can I tell Wox what's inside a custom environment I created in .wox?
--------------------------------------------------------------------

There is no dedicated mechanism to describe the environment’s internals to Wox.


However, if you want to integrate a non-standard or hand-crafted environment, your best tool is the commands setting of the task: you can call whatever setup steps or environment-specific actions you need before running the main commands.

Can my use case be organized across multiple tasks?
---------------------------------------------------

Most likely, yes.


Because envlist allows multiple tasks to share the same environment directory, you can spread different parts of your workflow across several tasks while still working inside the same underlying environment.


This makes it possible to structure complex or unusual workflows in a clean way — even if they don't fit the typical wox use-cases.
