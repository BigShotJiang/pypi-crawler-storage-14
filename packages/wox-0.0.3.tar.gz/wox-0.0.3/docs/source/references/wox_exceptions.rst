Wox exceptions
==============
 
.. currentmodule:: wox.wox_exceptions

.. autoclass:: WoxException(Exception)

Configuration errors
--------------------

.. autoclass:: ConfigFileNotFoundError(WoxException)
.. autoclass:: MissingWoxSectionError(WoxException)
.. autoclass:: MissingWoxKeywordError(WoxException)
.. autoclass:: NoTaskError(WoxException)
.. autoclass:: TaskNotFoundError(WoxException)

Dependency and package errors
-----------------------------

.. autoclass:: PackageNotFoundError(WoxException)
.. autoclass:: DependencyConflictError(WoxException)
.. autoclass:: PipTimeoutError(WoxException)

Python interpreter errors
-------------------------

.. autoclass:: PythonInterpreterNotFoundError(WoxException)
.. autoclass:: PythonInterpreterUnstableError(WoxException)
.. autoclass:: PythonInterpreterCallError(WoxException)
.. autoclass:: PythonBuildNotFoundError(WoxException)

Runtime / system-level errors
-----------------------------

.. autoclass:: CommandNotFoundError(WoxException)
.. autoclass:: PermissionDeniedError(WoxException)
.. autoclass:: DiskFullError(WoxException)

Warnings
--------

.. autoclass:: NotPythonVenvWarning(WoxException)
