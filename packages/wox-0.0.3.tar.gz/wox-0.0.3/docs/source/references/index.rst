References
==========

.. toctree::
    :maxdepth: 2

    wox_workspace
    python_discovery
    virtual_environment
    dependencies_installation
    commands_execution
    wox_summary
    wox_exceptions
