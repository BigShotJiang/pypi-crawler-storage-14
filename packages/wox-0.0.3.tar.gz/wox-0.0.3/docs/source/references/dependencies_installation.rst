Dependencies installation
=========================

Wox installs dependencies inside each virtual environment using pip by default.


Installation is performed via a direct subprocess call:

.. code-block:: bash

    python -I -m pip install -q 'dep 1' 'dep 2' 'dep n'

Wox always invokes pip from the Python interpreter of the selected environment, ensuring that packages are installed strictly inside that environment.

Using uv for dependency installation
------------------------------------

If ``with_uv`` is enabled, wox replaces pip with uv pip:

.. code-block:: bash

    uv pip install -q 'dep 1' 'dep 2' 'dep n'

This applies to all dependency installation steps for the duration of the session.

Flexible declaration of dependencies
------------------------------------

| Wox is intentionally permissive in how dependencies may be declared in wox.toml.
| It does not impose any structure or syntax rules: the values in deps are passed as-is to pip or uv pip.

As long as the arguments form valid pip-like tokens, they work (wheels included).

.. tab-set::

    .. tab-item:: Inline declaration

        .. code-block:: toml

            [task]
            envlist = ['default']
            deps = [
                'cowsay pixegami'
            ]
    
    .. tab-item:: One dependency per entry
        
        .. code-block:: toml

            [task]
            envlist = ['default']
            deps = [
                'cowsay',
                'pixegami'
            ]

    .. tab-item:: Insaneo style
        
        .. code-block:: toml

            [task]
            envlist = ['default']
            deps = [
                'cowsay -e .',
                'pixegami',
                '-r requirements.txt'
            ]

.. note::

    Wox does not validate or interpret the dependency strings.  
    It does not parse version constraints, normalize specifiers, or distinguish packages from flags.  
    Everything listed in ``deps`` is forwarded directly to pip or uv pip.
