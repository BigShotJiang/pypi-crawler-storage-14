Wox summary
===========

| Wox session can run multiple tasks within several virtual environments, which quickly becomes tedious to follow by reading logs alone.
| To help you keep track of the overall execution, Wox generates a session summary once all tasks have completed.


Each line of the summary contains four pieces of information:

- Execution unit: that is the qualification of a task running in a virtual environment;

- Exit code: 0 if the execution unit succeeded, 1 if it failed;

- Failed at: the specific action being performed at the moment the failure occurred;

- Failure reason: the error message or exception that caused the failure.

.. figure:: ../_static/screenshots/wox-summary.png
    :alt: hello wox
    :align: center
    :class: zoomable-image

    Output of a wox session summary

At the end of the summary, Wox also displays the total execution time of the session, formatted using the ISO-like style ``hours:minutes:seconds:milliseconds``.
