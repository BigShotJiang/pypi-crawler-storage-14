Guides
======

.. toctree::
    :maxdepth: 2

    installation
    quickstart
    wox.toml
    command_line_options
