Command-line options
====================

:red:`wox`: Runs every tasks declared in wox.toml. If ``wox_session_default`` is declared in wox.toml, only the tasks listed in ``wox_session_default`` are executed.

:red:`--verbose (or -v) (bool)`: Enables DEBUG-level logging and disables the quiet flag for dependency installation.

:red:`--task (list)`: Lists all tasks to run during the session. It has priority over ``wox_session_default`` setting from wox.toml.

:red:`--exclude-task (list)`: Lists all tasks to exclude from the session. When used with ``--task``, only the tasks not listed in both ``--task`` and ``--exclude-task`` are excluded.

.. note::

    If both ``--task`` and ``--exclude-task`` are present among CLI options,
    ``--task`` has priority over ``--exclude-task``, without denying it:
    a task appearing in both ``--task`` and ``--exclude-task`` is included.
    All other tasks listed in ``--exclude-task`` are excluded.

:red:`--purge (bool)`: Removes all directories that are present in .wox excepting logging directory.
