Installation
============

The simplest way to install wox is through pip:

.. code-block:: bash

    pip install wox

If you prefer using wox without relying on Python virtual environments, you can install it with pipx, which isolates Python command-line applications from your system Python installation.


`Pipx <https://pipx.pypa.io/stable/>`_ is a tool designed specifically for installing and running Python CLI applications like wox.


Once pipx is installed, you can install wox with:

.. code-block:: bash

    pipx install wox

If you're a uv enthusiast, you can also install wox as a uv tool:

.. code-block:: bash

    uv tool install wox

Or to run it directly thanks to `uvx <https://docs.astral.sh/uv/concepts/tools/>`_, the alias for ``uv tool run``:

.. code-block:: bash

    uvx wox

Wox is now ready to use! Head to the next page to learn how to run your first tasks.
