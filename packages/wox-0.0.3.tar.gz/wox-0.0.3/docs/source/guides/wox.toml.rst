wox.toml
========

The wox toml is split in 2 parts: the wox configuration and the tasks declaration.


The wox configuration, which defines global session settings.


The task declarations, which describe what wox must execute.

Wox configuration
-----------------

The wox configuration gathers all settings that affect how a session is executed.

| :red:`recreate_envs (bool)`
| If true, every environment inside .wox **used by the selected tasks** will be deleted before the session begins. Environments not involved in the session are left untouched.

| :red:`with_uv (bool)`
| If true, uv is used instead of pip and venv to manage venv creation and dependencies installation.

| :red:`wox_session_default (list[str])`
| Lists all the task that are run by default with the command ``wox`` without options. If absent, the latter command will run every tasks declared in the wox.toml.

Tasks declaration
-----------------

A task is a named section in wox.toml containing several settings. Together, these settings define a task configuration.

Wox provides the following task-level settings:

| :red:`envlist (list[str])`
| Lists the virtual environments used for the task. The same environments may be reused across different tasks. An environment does not have to be automatically created by Wox. You may create it manually under .wox if needed.

.. seealso::
    :ref:`Manually created environment in .wox. <manually_created_venv>`

| :red:`python_build (str)`
| Specifies which Python build to use for the environment. It is recommended to use this setting on specified environment as it is illustrated :ref:`here <build_comparison>`.

| :red:`deps (list[str])`
| Lists all the dependencies to install in a Python virtual environment. When manually creating a non-Python environment in .wox, it is recommended to not rely on this setting, as its functionning is tied to a valid Python environment.

.. seealso::
    Edgy wox: what is a valid Python virtual environment for wox?

| :red:`commands (list[str])`
| Lists all commands to run during the session for the given task on your behalf.
