.. wox documentation master file, created by
   sphinx-quickstart on Sat Nov 15 20:34:47 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

wox documentation
=================

Wox is a Python command-line tool designed to automate any task that can be expressed declaratively.
It provides a simple TOML-based configuration where you describe what you want to run, and Wox takes care of how to run it — including environment setup, dependency installation, and command execution.

At its core, Wox acts as a lightweight workflow engine allowing you to:

- run reproducible tasks across multiple Python versions,

- manage per-task virtual environments automatically,

- standardize developer workflows (onboarding, testing, benchmarking, CI steps…),

- orchestrate multi-step commands without writing custom shell scripts,

- and reproduce exactly what you would have typed in your terminal — Wox runs your commands as written, without adding abstractions or transforming them.

Wox is designed for developers, tool authors and teams who need consistency and reliability across machines, platforms, and workspaces — without the complexity of heavier workflow systems.

.. toctree::
   :maxdepth: 2

   guides/index
   edge_wox/index
   references/index
   internals/index
