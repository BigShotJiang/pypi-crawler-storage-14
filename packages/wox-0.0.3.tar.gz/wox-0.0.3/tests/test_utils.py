# coverage run -m pytest -rA tests/test_utils.py --no-header --html=./reports/pytest/report.html --self-contained-html && coverage html #noqa E501

import pytest

from wox.subprocess_error_detection.utils import detect_sentence_with_fill_in_blank
from wox.utils import auto_clean_logs, get_python_version_from_command


# python -B -m pytest -rA -k "test_auto_clean_logs"
def test_auto_clean_logs(monkeypatch, tmp_path):
    """
        auto_clean_logs must delete the most recent file created.
    """

    logs_dir = tmp_path / '.logs'
    logs_dir.mkdir()

    log_1 = logs_dir / 'output-1.log'
    log_1.touch()

    log_2 = logs_dir / 'output-2.log'
    log_2.touch()

    before = list(logs_dir.glob('output*'))

    assert len(before) == 2

    monkeypatch.setattr('wox.utils.DOT_WOX', tmp_path)

    auto_clean_logs()

    after = list(logs_dir.glob('output*'))

    assert len(after) == 1

    assert after[0].name == 'output-1.log'

class TestGetPythonVersionFromCommand:
    """
        get_python_version_from_command() must return a Python version
        following major.minor scheme.
    """

    test_get_python_version_from_command_cases = [
        {
            'input': 'python3.6',
            'expected': '3.6'
        },
        {
            'input': 'py -3.6',
            'expected': '3.6'
        }
    ]

    # python -B -m pytest -rA -k "test_get_python_version_from_command"
    @pytest.mark.parametrize('test_case_', test_get_python_version_from_command_cases)
    def test_get_python_version_from_command(self, test_case_):

        version = get_python_version_from_command(test_case_['input'])

        assert version == test_case_['expected']

# python -B -m pytest -rA -k "test_detect_sentence_with_fill_in_blank"
@pytest.mark.parametrize(
    'text', [
        'The world is full of flowers ready to blossom',
        'The world is\n full of wonders\n ready to blossom'
    ]
)
def test_detect_sentence_with_fill_in_blank(text):
    """
        detect_sentence_with_fill_in_blank() must return True if the sentence
        with fill-in-the-blanks is found in the text.
    """

    assert detect_sentence_with_fill_in_blank(text, 'full of * ready')
