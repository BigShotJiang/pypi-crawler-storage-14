# coverage run -m pytest -rA tests/test_venv_management.py --no-header --html=./reports/pytest/report.html --self-contained-html && coverage html #noqa E501

import wox.python_discoverer as python_discoverer
import wox.venv_management as venv_manager


# python -B -m pytest -rA -k "test_venv_management"
def test_venv_management(tmp_path, monkeypatch):
    """
        Ensures the virtual environment management workflow functions as expected.

        This nominal test validates the successful execution of the following steps:

        - creation of a virtual environment;
        - location of the Python interpreter within that environment;
        - deletion of the environment afterward.
    """

    env = 'default'

    env_path = tmp_path / env

    python_interpreter = python_discoverer.python_discovery(env)

    venv_manager.create_venv(env_path, python_interpreter)

    venv_python_interpreter = python_discoverer.locate_venv_python_exe(env_path)

    assert venv_python_interpreter.path.exists()

    monkeypatch.setattr('wox.venv_management.DOT_WOX', tmp_path)

    wox_data = {
        'testing': {'envlist': [env]}
    }

    venv_manager.venv_deletion(wox_data)

    assert not venv_python_interpreter.path.exists()

# python -B -m pytest -rA -k "test_venv_deletion_not_found"
def test_venv_deletion_not_found(monkeypatch, tmp_path, caplog):
    """
        Ensures graceful handling when attempting to delete a non-existent
        virtual environment.

        venv_deletion() must log a specific warning message if the target
        environment cannot be found instead of raising an exception.
    """

    env = 'default'

    wox_data = {
        'testing': {'envlist': [env]}
    }

    control_log_record_message = (
        f"Unable to delete '{env}': virtual environment "
        f"not found on '{tmp_path / env}'"
    )

    monkeypatch.setattr('wox.venv_management.DOT_WOX', tmp_path)

    venv_manager.venv_deletion(wox_data)

    assert len(caplog.records) == 1

    log_record_message = caplog.records[0].msg

    assert control_log_record_message == log_record_message

# python -B -m pytest -rA -k "test_venv_deletion_fail_rmtree"
def test_venv_deletion_fail_rmtree(monkeypatch, tmp_path, caplog):
    """
        Ensures graceful handling when shutil.rmtree() fails
        to delete a directory tree.

        venv_deletion() must log the exception message instead
        of propagating the raised exception.
    """

    def patched_rmtree(path):
        raise PermissionError("Access denied (patched)")

    env = 'default'

    env_path = tmp_path / env

    wox_data = {
        'testing': {'envlist': [env]}
    }

    control_log_record_message = 'PermissionError: Access denied (patched)'

    python_interpreter = python_discoverer.python_discovery(env)

    venv_manager.create_venv(env_path, python_interpreter)

    venv_python_interpreter = python_discoverer.locate_venv_python_exe(env_path)

    assert venv_python_interpreter.path.exists()

    monkeypatch.setattr('shutil.rmtree', patched_rmtree)
    monkeypatch.setattr('wox.venv_management.DOT_WOX', tmp_path)

    venv_manager.venv_deletion(wox_data)

    log_record_message = caplog.records[-1].msg

    assert control_log_record_message == log_record_message
