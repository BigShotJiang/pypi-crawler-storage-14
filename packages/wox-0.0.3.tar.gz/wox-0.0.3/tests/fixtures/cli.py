import pytest


@pytest.fixture
def patched_wox_command(monkeypatch):
    def patched_parser_definition():
        """
            Emulates a 'wox' command executed by user.
        """

        class Args:
            task = None
            version = None
        return Args()

    return monkeypatch.setattr('wox.cli.parser_definition', patched_parser_definition)
