import os
import pytest

from pathlib import Path


@pytest.fixture
def pyproject_toml_path():
    return Path('tests/resources/config-files/pyproject.toml').resolve()

@pytest.fixture
def wox_toml_path():
    return Path('tests/resources/config-files/wox.toml').resolve()

@pytest.fixture
def cwd_tmp_path(tmp_path):
    """
        Path.cwd() is the root to the python execution. Files location
        is based on it. For some tests, it is useful to alter this
        path to pytest temporal directory created for the test.

        Since pytest creates temporary directories
        using tmp_path *outside* the project tree, we must temporarily
        change the working directory to tmp_path for the function to succeed.
    """

    old_cwd = os.getcwd()
    os.chdir(tmp_path)
    try:
        yield tmp_path
    finally:
        os.chdir(old_cwd)
