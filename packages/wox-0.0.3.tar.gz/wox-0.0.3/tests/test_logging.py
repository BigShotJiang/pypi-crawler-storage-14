# coverage run -m pytest -rA tests/test_logging.py --no-header --html=./reports/pytest/report.html --self-contained-html && coverage html #noqa E501

from wox.logger.logger_setup import wox_logger


# python -B -m pytest -rA -k "test_logging"
def test_logging(caplog):
    """
        The logger must correctly handle non-ASCII characters.
    """

    caplog.set_level('INFO')

    wox_logger.info('㐬')

    # caplog.records make logs accessible for assertion.
    log_record_message = caplog.records[0].msg

    assert log_record_message == '㐬'
