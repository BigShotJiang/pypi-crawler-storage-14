import os
import pytest

# Run tests as maintainer
# os.environ['RUN_MAINTAINER_TESTS'] = '1'

maintainer_only = pytest.mark.skipif(
    os.environ.get('RUN_MAINTAINER_TESTS') != '1',
    reason='Maintainer-only test, skipped because RUN_MAINTAINER_TESTS is not set'
)

pytest_plugins = [
    'tests.fixtures.cli',
    'tests.fixtures.paths',
    'tests.fixtures.temp_file_system'
]
