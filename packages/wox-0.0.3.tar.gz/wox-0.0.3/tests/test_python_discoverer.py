# coverage run -m pytest -rA tests/test_python_discoverer.py --no-header --html=./reports/pytest/report.html --self-contained-html && coverage html #noqa E501

import pytest

import wox.python_discoverer as python_discoverer


class TestGetInterpreterVersion:
    """
        get_interpreter_version() must return a version number
        in the major.minor format, extracted from virtual environment
        names following the 'py<majorminor>' convention (e.g. py311).
    """

    test_get_interpreter_version_cases = [
        {
            'input': 'py30',
            'expected': '3.0'
        },
        {
            'input': 'py31',
            'expected': '3.1'
        },
        {
            'input': 'py310',
            'expected': '3.10'
        },
        {
            'input': 'py311',
            'expected': '3.11'
        },
        {
            'input': 'py3100',
            'expected': '3.100'
        },
        {
            'input': 'py31000',
            'expected': '3.1000'
        },
    ]

    # python -B -m pytest -rA -k "test_get_interpreter_version"
    @pytest.mark.parametrize(
        'test_case_',
        test_get_interpreter_version_cases,
        ids = [case['input'] for case in test_get_interpreter_version_cases]
    )
    def test_get_interpreter_version(self, test_case_):

        env = test_case_['input']

        version = python_discoverer.get_interpreter_version(env)

        assert version == test_case_['expected']

@pytest.mark.parametrize(
    'env',
    [
        'py311',
        '.venv'
    ]
)
# python -B -m pytest -rA -k "test_python_discovery"
def test_python_discovery(env):
    """
        Wox must discover the required Python version if
        a virtual environment name follows the 'py<majorminor>' convention.

        Otherwise, Wox must discover the Python interpreter available
        in the current environment or provided by the system.
    """

    python_interpreter = python_discoverer.python_discovery(env)

    assert python_interpreter.path.exists()

class TestGetPythonVersionFromPyvenvCfg:
    """
        get_python_version_from_pyvenv_cfg() must return a Python version
        using the major.minor.fix scheme.
    """

    test_get_python_version_from_pyvenv_cfg_cases = [
        {
            'input': '3.12.1-rc1',
            'expected': '3.12.1'
        },
        {
            'input': '3.11.7.final.0',
            'expected': '3.11.7'
        },
        {
            'input': '3.12.11a7',
            'expected': '3.12.11'
        },
        {
            'input': '3.100.1000-beta-3.14.0-final',
            'expected': '3.100.1000'
        }
    ]

    # python -B -m pytest -rA -k "test_get_python_version_from_pyvenv_cfg"
    @pytest.mark.parametrize(
        'test_case_',
        test_get_python_version_from_pyvenv_cfg_cases
    )
    def test_get_python_version_from_pyvenv_cfg(self, tmp_path, test_case_):

        pyvenv_cfg = tmp_path / 'pyvenv.cfg'

        pyvenv_cfg.write_text(f"version = {test_case_['input']}")

        version = python_discoverer.get_python_version_from_pyvenv_cfg(tmp_path)

        assert version == test_case_['expected']
