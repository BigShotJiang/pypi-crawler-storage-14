.. raw:: html

   <meta http-equiv='refresh' content='0; url=tests/tests/'/>

Tests documentation
===================

.. autosummary::
   :toctree: tests
   :recursive:

   tests
