tests.test_subprocessor_error_detection
==============================================

.. automodule:: tests.test_subprocessor_error_detection
   :members:
   :undoc-members:
   :show-inheritance:

