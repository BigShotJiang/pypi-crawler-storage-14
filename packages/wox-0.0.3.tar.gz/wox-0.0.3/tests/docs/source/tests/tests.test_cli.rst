tests.test_cli
=====================

.. automodule:: tests.test_cli
   :members:
   :undoc-members:
   :show-inheritance:

