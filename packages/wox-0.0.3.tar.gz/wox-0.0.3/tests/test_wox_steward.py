# coverage run -m pytest -rA tests/test_wox_steward.py --no-header --html=./reports/pytest/report.html --self-contained-html && coverage html #noqa E501

import pytest
import tomllib

from wox.wox_exceptions import ConfigFileNotFoundError, MissingWoxSectionError
from wox.wox_steward import WoxSteward


# python -B -m pytest -rA -k "test_pyproject_toml_integrity"
def test_pyproject_toml_integrity(monkeypatch, pyproject_toml_path):
    """
        Extracting wox data from pyproject.toml must not
        alter the original file content.

        A control reference is loaded first, before wox_data
        process and the file is loaded again.

        Both versions must be identical.
    """

    with open(pyproject_toml_path, 'rb') as toml_file:
        control_loaded_pyproject_toml = tomllib.load(toml_file)

    monkeypatch.setattr(WoxSteward, 'wox_toml', pyproject_toml_path)

    WoxSteward().wox_data

    with open(pyproject_toml_path, 'rb') as toml_file:
        tested_loaded_pyproject_toml = tomllib.load(toml_file)

    assert control_loaded_pyproject_toml == tested_loaded_pyproject_toml

# python -B -m pytest -rA -k "test_load_wox_toml"
def test_load_wox_toml(monkeypatch, wox_toml_path):
    """
        wox_data must correctly extract Wox information from wox.toml.
    """

    with open(wox_toml_path, 'rb') as toml_file:
        loaded_wox_toml = tomllib.load(toml_file)

    monkeypatch.setattr(WoxSteward, 'wox_toml', wox_toml_path)

    wox_data = WoxSteward().wox_data

    assert loaded_wox_toml == wox_data

# python -B -m pytest -rA -k "test_wox_pyproject_equals_wox_toml"
def test_wox_pyproject_equals_wox_toml(monkeypatch, pyproject_toml_path, wox_toml_path):
    """
        Wox information extracted from pyproject.toml and wox.toml must yield
        identical data structures.
    """

    monkeypatch.setattr(WoxSteward, 'wox_toml', pyproject_toml_path)

    wox_data_from_pyproject = WoxSteward().wox_data

    monkeypatch.setattr(WoxSteward, 'wox_toml', wox_toml_path)

    wox_data_from_wox = WoxSteward().wox_data

    assert wox_data_from_pyproject == wox_data_from_wox

# python -B -m pytest -rA -k "test_config_file_not_found_error"
def test_config_file_not_found_error(cwd_tmp_path):
    """
        A workspace without wox.toml or pyproject.toml
        must throw ConfigFileNotFoundError.
    """

    with pytest.raises(ConfigFileNotFoundError):
        WoxSteward().wox_data

# python -B -m pytest -rA -k "test_missing_wox_section_error"
def test_missing_wox_section_error(tmp_path, cwd_tmp_path):
    """
        A workspace without wox.toml but containing pyproject.toml without
        a [wox] section must raise MissingWoxSectionError.
    """

    empty_pyproject_toml = tmp_path / 'pyproject.toml'
    empty_pyproject_toml.touch(exist_ok = True)

    with pytest.raises(MissingWoxSectionError):
        WoxSteward().wox_data

# python -B -m pytest -rA -k "test_dot_wox_setup"
def test_dot_wox_setup(monkeypatch, tmp_path, cwd_tmp_path):
    """
        Upon setup, .wox must contain both .gitignore and CACHEDIR.TAG files.
    """

    control_gitignore_content = (
        '# Automatically created by wox.\n'
        '*\n'
    )

    control_cachedir_tag = (
        'Signature: 8a477f597d28d172789f06886806bc55\n'
        '# This directory is managed by Wox.\n'
        '# It contains cache data such as logs and virtual environments.\n'
        '# See: https://bford.info/cachedir/\n'
    )

    monkeypatch.setattr('wox.wox_steward.DOT_WOX', tmp_path)

    WoxSteward().dot_wox_setup()

    gitignore_path = tmp_path / ".gitignore"
    cachedir_tag_path = tmp_path / "CACHEDIR.TAG"

    assert gitignore_path.exists()
    assert cachedir_tag_path.exists()

    assert gitignore_path.read_text() == control_gitignore_content
    assert cachedir_tag_path.read_text() == control_cachedir_tag
