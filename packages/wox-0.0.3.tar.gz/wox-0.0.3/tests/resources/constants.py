from pathlib import Path


RAMDISK_PATH = Path.cwd() / 'tests' / 'resources' / 'ramdisk'
