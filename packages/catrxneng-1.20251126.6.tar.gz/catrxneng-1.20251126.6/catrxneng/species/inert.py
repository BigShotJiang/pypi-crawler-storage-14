from .. import quantities as quant
from .species import Species


class Inert(Species):
    CLASS = "inert"
