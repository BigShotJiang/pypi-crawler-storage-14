"""Implements classes needed to label text corpora, and learn a logistic
regression model to disambiguate across a set of longforms for a given
shortform.

"""