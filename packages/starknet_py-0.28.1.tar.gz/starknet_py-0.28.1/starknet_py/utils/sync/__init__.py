"""
Module that allows adding synchronous versions of classes accessible with Class.sync.
"""

from starknet_py.utils.sync.sync import add_sync_methods
