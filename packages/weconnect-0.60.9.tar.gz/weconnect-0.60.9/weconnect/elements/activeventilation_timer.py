from weconnect.elements.climatization_timer import ClimatizationTimer


class ActiveVentilationTimer(ClimatizationTimer):
    pass
