"""
EduBench Evaluation Module
"""

from .evaluation import TASK_PROMPT_TEMPLATES

__all__ = [
    "TASK_PROMPT_TEMPLATES",
]

