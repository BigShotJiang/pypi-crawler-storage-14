"""
API request and response models.

This module defines Pydantic models for API input validation and response formatting.
"""

from typing import Optional

from pydantic import BaseModel, Field


class EvaluationRequest(BaseModel):
    """Request model for content evaluation endpoint."""
    
    content: str = Field(
        ...,
        description="The educational content to evaluate (can include image URLs)",
        min_length=1,
        max_length=100000
    )
    curriculum: str = Field(
        default="common_core",
        description="The curriculum to use for evaluation",
        pattern="^[a-z_]+$"
    )
    generation_prompt: Optional[str] = Field(
        None,
        description="Optional prompt used to generate the content (for AI-generated content evaluation)",
        max_length=50000
    )
    
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "content": "What is the capital of France?",
                    "curriculum": "common_core"
                },
                {
                    "content": "Solve: 2x + 5 = 15",
                    "curriculum": "common_core",
                    "generation_prompt": "Create a simple algebra question for 8th grade"
                }
            ]
        }
    }


class HealthResponse(BaseModel):
    """Response model for health check endpoint."""
    
    status: str = Field(..., description="Service health status")
    version: str = Field(..., description="API version")
    service: str = Field(..., description="Service name")


class CurriculumsResponse(BaseModel):
    """Response model for curriculum listing endpoint."""
    
    curriculums: list[str] = Field(..., description="Available curriculum names")
    default: str = Field(..., description="Default curriculum")


class ErrorResponse(BaseModel):
    """Response model for error responses."""

    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    detail: Optional[str] = Field(None, description="Additional error details")
