"""SSB Libtest12."""
