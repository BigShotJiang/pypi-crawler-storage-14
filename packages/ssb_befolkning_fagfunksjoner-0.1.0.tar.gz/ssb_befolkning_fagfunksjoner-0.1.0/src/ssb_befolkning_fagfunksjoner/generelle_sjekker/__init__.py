"""Underpakke som håndterer generelle data-sjekker brukt i produksjon av befolkningsstatistikk."""
