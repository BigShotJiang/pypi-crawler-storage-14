"""Subpackage for demographic computations used in population statistics."""
