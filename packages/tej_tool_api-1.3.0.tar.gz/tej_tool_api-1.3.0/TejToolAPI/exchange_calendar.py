import os
import tejapi
import datetime
import pandas as pd
import numpy as np

module_dir = os.path.dirname(os.path.abspath(__file__))
tmp_path = os.path.join(module_dir,'temp')
pandas_main_version = pd.__version__.split('.')[0]
# If temp folder not exists, create it. 
if not os.path.exists(tmp_path):
    os.makedirs(tmp_path)

# Path to store exchange_calendar
calendar_file_path = os.path.join(tmp_path, 'exchange_calendar.csv')

# Check whether the file exists.
if os.path.isfile(calendar_file_path):
    cache = False
else:
    cache = True

if 'exchange_calendar.csv' in os.listdir(tmp_path):
    cache = False
else:
    cache = True

class ExchangeCalendar:
    def __init__(self) -> None:
        self.calendar = self.get_trading_calendar(cache)
        self.calendar_list = self.calendar['zdate'].tolist()
        self.date_int = self.calendar['zdate'].values.astype(np.int64)

    def get_trading_calendar(self, cache):
        """
        Extrieve calendar from tejapi-TWN/TRADEDAY_TWSE, retain all trading dates of the calendar.
        """
        if cache:
            calendar = tejapi.fastget('TWN/TRADEDAY_TWSE', 
                            paginate = True,
                            mkt = 'TWSE',
                            date_rmk = '',
                            opts = {'columns':['zdate']}
                            )
            
            calendar.to_csv(calendar_file_path, index=False)
            
        else:
            calendar = pd.read_csv(calendar_file_path, parse_dates=['zdate'])
            most_recent_date = max(calendar['zdate'])
            if most_recent_date < datetime.datetime.now():
                update = tejapi.fastget('TWN/TRADEDAY_TWSE', 
                            paginate = True,
                            mkt = 'TWSE',
                            date_rmk = '',
                            zdate= {'gt':most_recent_date},
                            opts = {'columns':['zdate']}
                            )
    
                calendar = pd.concat([calendar, update]).drop_duplicates().reset_index(drop = True)
                calendar.to_csv(calendar_file_path, index=False)
        if pandas_main_version != '1' :
            calendar['zdate'] = calendar['zdate'].astype('datetime64[ms]')
        else :
            calendar['zdate'] = calendar['zdate'].astype('datetime64[ns]')
        return calendar
    
    def _get_date_value(self, date):
        """統一的日期值獲取方法，處理不同 pandas 版本的精度差異"""
        date = pd.Timestamp(date)
        if pandas_main_version != '1':
            # pandas 2.x: 轉換為毫秒精度以匹配 self.date_int
            return date.value // 1_000_000
        else:
            # pandas 1.x: 直接使用奈秒精度
            return date.value
        
    def is_session(self, date):
        """ 
        Check if the date is valid for trading.
        ---------------------------------------
        True: `date` is trading date.
        False: `date` is not trading date.
        """
        if self.calendar.loc[0, 'zdate'].tz is None:
            utc = False

        else:
            utc = True    

        return pd.to_datetime(date, utc=utc) in self.calendar_list
    
    def next_open(self, date):
        """
        To make join process efficient,
        shift non-trading announce date to next open trading date.
        ----------------------------------------------------------
        output: next trading date
        """
        
        date_value = self._get_date_value(date)

        idx = next_divider_idx(self.date_int, date_value)
        if pandas_main_version != '1':
            return pd.Timestamp(self.date_int[idx] , unit = 'ms')
        else:
            return pd.Timestamp(self.date_int[idx] , unit = 'ns')
        
    
    def prev_open(self, date):
        """
        To make join process efficient,
        shift non-trading announce date to previous open trading date.
        ----------------------------------------------------------
        output: next trading date
        """
        
        date_value = self._get_date_value(date)

        idx = previous_divider_idx(self.date_int, date_value)

        if pandas_main_version != '1':
            return pd.Timestamp(self.date_int[idx] , unit = 'ms')
        else:
            return pd.Timestamp(self.date_int[idx] , unit = 'ns')
    
    def annd_adjusted(self, date, shift_backward=True):
        if self.is_session(date):
            return date
        
        if shift_backward:
            return self.prev_open(date)
        
        return self.next_open(date)

    
def next_divider_idx(dividers: np.ndarray, minute_val: int) -> int:

    divider_idx = np.searchsorted(dividers, minute_val, side="right")
    target = dividers[divider_idx]

    if minute_val == target:
        # if dt is exactly on the divider, go to the next value
        return divider_idx + 1
    else:
        return divider_idx

def previous_divider_idx(dividers: np.ndarray, minute_val: int) -> int:
    
    divider_idx = np.searchsorted(dividers, minute_val)

    if divider_idx == 0:

        raise ValueError("Cannot go earlier in calendar!")

    return divider_idx - 1
