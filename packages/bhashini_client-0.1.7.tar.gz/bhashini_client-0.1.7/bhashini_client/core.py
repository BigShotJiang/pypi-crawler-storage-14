from .utils.request_handler import RequestHandler
from .services.asr_service import ASRService
from .services.nmt_service import NMTService
from .services.tts_service import TTSService
from .config_manager import ConfigManager

class BhashiniClient:
    def __init__(self, api_key: str):
        self.handler = RequestHandler(api_key)
        self.config = ConfigManager()
        self.asr_service = ASRService(self.handler, self.config)
        self.nmt_service = NMTService(self.handler, self.config)
        self.tts_service = TTSService(self.handler, self.config)

    def asr(
        self,
        audio_url: str,
        source_lang: str,
        serviceId=None,
        samplingRate=None,
        preProcessors=None,
        postProcessors=None,
    ):
        return self.asr_service.transcribe(
            audio_url,
            source_lang,
            serviceId,
            samplingRate,
            preProcessors,
            postProcessors,
        )

    def nmt(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        serviceId=None,
        numTranslation=None,
        preProcessors=None,
        postProcessors=None,
    ):
        return self.nmt_service.translate(
            text,
            source_lang,
            target_lang,
            serviceId,
            numTranslation,
            preProcessors,
            postProcessors,
        )

    # def tts(self, text: str, source_lang: str, gender="male", format_="wav"):
    #     return self.tts_service.synthesize(text, source_lang, gender, format_)

    def tts(self, text: str, source_lang: str, gender="male", format_="wav", save_to=None, serviceId=None, speed=None, samplingRate=None, preProcessors=None, postProcessors=None, return_base64=False):
        return self.tts_service.synthesize(text, source_lang, gender, format_, save_to, serviceId, speed, samplingRate, preProcessors, postProcessors, return_base64)
    
    # Service Discovery Methods
    
    def list_nmt_services(self, source_lang: str, target_lang: str):
        """
        List all available NMT services for a language pair.
        
        Args:
            source_lang (str): Source language code (e.g., "en", "hi").
            target_lang (str): Target language code (e.g., "en", "hi").
        
        Returns:
            List[Dict]: List of available services with their details.
        
        Example:
            >>> client = BhashiniClient(api_key="your-key")
            >>> services = client.list_nmt_services("en", "hi")
            >>> for svc in services:
            ...     print(f"{svc['id']} by {svc['provider']}")
        """
        return self.config.list_nmt_services(source_lang, target_lang)
    
    def list_asr_services(self, language: str):
        """
        List all available ASR services for a language.
        
        Args:
            language (str): Language code or name (e.g., "hi", "Hindi").
        
        Returns:
            List[Dict]: List of available services with their details.
        
        Example:
            >>> client = BhashiniClient(api_key="your-key")
            >>> services = client.list_asr_services("hi")
            >>> for svc in services:
            ...     print(f"{svc['id']} by {svc['provider']}")
        """
        return self.config.list_asr_services(language)
    
    def list_tts_services(self, language: str):
        """
        List all available TTS services for a language.
        
        Args:
            language (str): Language code or name (e.g., "hi", "Hindi").
        
        Returns:
            List[Dict]: List of available services with their details.
        
        Example:
            >>> client = BhashiniClient(api_key="your-key")
            >>> services = client.list_tts_services("hi")
            >>> for svc in services:
            ...     print(f"{svc['id']} by {svc['provider']}")
        """
        return self.config.list_tts_services(language)
    
    def get_service_info(self, service_id: str):
        """
        Get detailed information about a specific service.
        
        Args:
            service_id (str): The service ID to look up.
        
        Returns:
            Optional[Dict]: Service information or None if not found.
        
        Example:
            >>> client = BhashiniClient(api_key="your-key")
            >>> info = client.get_service_info("ai4bharat/conformer-hi-gpu--t4")
            >>> print(info)
        """
        return self.config.get_service_info(service_id)