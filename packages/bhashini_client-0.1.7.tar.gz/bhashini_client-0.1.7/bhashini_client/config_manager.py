"""
ConfigManager for dynamic service selection based on language and task.

This module loads configuration from JSON files and provides methods to 
automatically select appropriate service IDs for ASR, NMT, and TTS tasks.
"""

import json
from pathlib import Path
from typing import Optional, Dict, List
from functools import lru_cache


class ConfigManager:
    """Manages configuration and dynamic service selection for Bhashini services."""
    
    _instance = None
    _initialized = False
    
    def __new__(cls):
        """Singleton pattern to ensure config is loaded only once."""
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize ConfigManager and load configuration files."""
        if ConfigManager._initialized:
            return
            
        self._config_dir = Path(__file__).parent / "config"
        self._load_configs()
        ConfigManager._initialized = True
    
    def _load_configs(self):
        """Load language pairs and model pipeline configuration from JSON files."""
        try:
            # Load NMT language pairs mapping
            language_file = self._config_dir / "language.json"
            with open(language_file, 'r', encoding='utf-8') as f:
                self.language_pairs = json.load(f)
            
            # Load service catalog with language support info
            pipeline_file = self._config_dir / "model-pipeline.json"
            with open(pipeline_file, 'r', encoding='utf-8') as f:
                self.service_catalog = json.load(f)
        except FileNotFoundError as e:
            print(f"Warning: Config file not found: {e}")
            self.language_pairs = {"LanguagePairs": []}
            self.service_catalog = {"ASR": {}, "Translation": {}, "TTS": {}}
        except json.JSONDecodeError as e:
            print(f"Warning: Invalid JSON in config file: {e}")
            self.language_pairs = {"LanguagePairs": []}
            self.service_catalog = {"ASR": {}, "Translation": {}, "TTS": {}}
    
    @lru_cache(maxsize=None)
    def get_nmt_service(self, source_lang: str, target_lang: str) -> Optional[str]:
        """
        Get appropriate NMT service ID for a language pair.
        
        Args:
            source_lang (str): Source language code (e.g., "en", "hi").
            target_lang (str): Target language code (e.g., "en", "hi").
        
        Returns:
            Optional[str]: Service ID if found, None otherwise.
        
        Example:
            >>> config = ConfigManager()
            >>> service_id = config.get_nmt_service("en", "hi")
            >>> print(service_id)
            'ai4bharat/indictrans-v2-all-gpu--t4'
        """
        # Normalize to lowercase for comparison
        source_lang = source_lang.lower()
        target_lang = target_lang.lower()
        
        # Build pair ID (e.g., "en_hi")
        pair_id = f"{source_lang}_{target_lang}"
        
        # Search in language pairs mapping
        for pair in self.language_pairs.get("LanguagePairs", []):
            if pair.get("id") == pair_id:
                return pair.get("serviceID")
        
        # Fallback: check if any Translation service supports both languages
        for service_id, info in self.service_catalog.get("Translation", {}).items():
            src_langs = [lang.lower() for lang in info.get("src_languages", [])]
            tgt_langs = [lang.lower() for lang in info.get("tgt_languages", [])]
            
            # Check if source_lang matches any in src_languages
            if any(source_lang in lang.lower() or lang.lower() in source_lang 
                   for lang in info.get("src_languages", [])):
                # Check if target_lang matches any in tgt_languages
                if any(target_lang in lang.lower() or lang.lower() in target_lang 
                       for lang in info.get("tgt_languages", [])):
                    return service_id
        
        return None
    
    @lru_cache(maxsize=None)
    def get_asr_service(self, language: str) -> Optional[str]:
        """
        Get appropriate ASR service ID for a language.
        
        Args:
            language (str): Language code or name (e.g., "hi", "Hindi", "en").
        
        Returns:
            Optional[str]: Service ID if found, None otherwise.
        
        Example:
            >>> config = ConfigManager()
            >>> service_id = config.get_asr_service("hi")
            >>> print(service_id)
            'ai4bharat/conformer-multilingual-indo_aryan-gpu--t4'
        """
        language = language.lower()
        
        # Search for service that supports this language
        for service_id, info in self.service_catalog.get("ASR", {}).items():
            languages = info.get("languages", [])
            
            # Check if language matches (code or name)
            for lang in languages:
                lang_lower = lang.lower()
                # Match full name or check if it's a code match
                if lang_lower == language or language in lang_lower:
                    return service_id
        
        return None
    
    @lru_cache(maxsize=None)
    def get_tts_service(self, language: str) -> Optional[str]:
        """
        Get appropriate TTS service ID for a language.
        
        Args:
            language (str): Language code or name (e.g., "hi", "Hindi", "en").
        
        Returns:
            Optional[str]: Service ID if found, None otherwise.
        
        Example:
            >>> config = ConfigManager()
            >>> service_id = config.get_tts_service("hi")
            >>> print(service_id)
            'ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4'
        """
        language = language.lower()
        
        # Search for service that supports this language
        for service_id, info in self.service_catalog.get("TTS", {}).items():
            languages = info.get("languages", [])
            
            # Check if language matches (code or name)
            for lang in languages:
                lang_lower = lang.lower()
                # Match full name or check if it's a code match
                if lang_lower == language or language in lang_lower:
                    return service_id
        
        return None
    
    @lru_cache(maxsize=None)
    def list_supported_languages(self, task: str) -> List[str]:
        """
        List all supported languages for a given task.
        
        Args:
            task (str): Task type - "asr", "nmt", or "tts".
        
        Returns:
            List[str]: List of supported language names.
        
        Example:
            >>> config = ConfigManager()
            >>> languages = config.list_supported_languages("asr")
            >>> print(languages[:5])
            ['Telugu', 'Kannada', 'Malayalam', 'Tamil', 'Hindi']
        """
        task_map = {
            "asr": "ASR",
            "nmt": "Translation",
            "tts": "TTS"
        }
        
        task_key = task_map.get(task.lower())
        if not task_key:
            return []
        
        languages = set()
        for service_id, info in self.service_catalog.get(task_key, {}).items():
            if task_key == "Translation":
                languages.update(info.get("src_languages", []))
                languages.update(info.get("tgt_languages", []))
            else:
                languages.update(info.get("languages", []))
        
        return sorted(list(languages))
    
    @lru_cache(maxsize=None)
    def get_service_info(self, service_id: str) -> Optional[Dict]:
        """
        Get detailed information about a specific service.
        
        Args:
            service_id (str): The service ID to look up.
        
        Returns:
            Optional[Dict]: Service information including provider and languages.
        
        Example:
            >>> config = ConfigManager()
            >>> info = config.get_service_info("ai4bharat/conformer-hi-gpu--t4")
            >>> print(info)
            {'languages': ['Hindi'], 'provider': 'AI4Bharat'}
        """
        for task_type in ["ASR", "Translation", "TTS", "Transliteration", "Audio Language Detection"]:
            services = self.service_catalog.get(task_type, {})
            if service_id in services:
                return services[service_id]
        
        return None
    
    def list_nmt_services(self, source_lang: str, target_lang: str) -> List[Dict]:
        """
        List all available NMT services that support a language pair.
        
        Args:
            source_lang (str): Source language code or name (e.g., "en", "English").
            target_lang (str): Target language code or name (e.g., "hi", "Hindi").
        
        Returns:
            List[Dict]: List of service dictionaries with id, provider, and language info.
        
        Example:
            >>> config = ConfigManager()
            >>> services = config.list_nmt_services("en", "hi")
            >>> for svc in services:
            ...     print(f"{svc['id']} - {svc['provider']}")
            ai4bharat/indictrans-v2-all-gpu--t4 - AI4Bharat
            bhashini/iiith/nmt-all - IIIT Hyderabad
        """
        source_lang = source_lang.lower()
        target_lang = target_lang.lower()
        
        available_services = []
        
        for service_id, info in self.service_catalog.get("Translation", {}).items():
            src_langs = info.get("src_languages", [])
            tgt_langs = info.get("tgt_languages", [])
            
            # Check if source language is supported
            src_match = any(
                source_lang in lang.lower() or lang.lower() in source_lang
                for lang in src_langs
            )
            
            # Check if target language is supported
            tgt_match = any(
                target_lang in lang.lower() or lang.lower() in target_lang
                for lang in tgt_langs
            )
            
            if src_match and tgt_match:
                available_services.append({
                    "id": service_id,
                    "provider": info.get("provider", "Unknown"),
                    "src_languages": src_langs,
                    "tgt_languages": tgt_langs
                })
        
        return available_services
    
    def list_asr_services(self, language: str) -> List[Dict]:
        """
        List all available ASR services that support a language.
        
        Args:
            language (str): Language code or name (e.g., "hi", "Hindi").
        
        Returns:
            List[Dict]: List of service dictionaries with id, provider, and supported languages.
        
        Example:
            >>> config = ConfigManager()
            >>> services = config.list_asr_services("hi")
            >>> for svc in services:
            ...     print(f"{svc['id']} - {svc['provider']}")
            ai4bharat/conformer-hi-gpu--t4 - AI4Bharat
            ai4bharat/conformer-multilingual-indo_aryan-gpu--t4 - AI4Bharat
        """
        language = language.lower()
        available_services = []
        
        for service_id, info in self.service_catalog.get("ASR", {}).items():
            languages = info.get("languages", [])
            
            # Check if language is supported
            lang_match = any(
                language in lang.lower() or lang.lower() in language
                for lang in languages
            )
            
            if lang_match:
                available_services.append({
                    "id": service_id,
                    "provider": info.get("provider", "Unknown"),
                    "languages": languages
                })
        
        return available_services
    
    def list_tts_services(self, language: str) -> List[Dict]:
        """
        List all available TTS services that support a language.
        
        Args:
            language (str): Language code or name (e.g., "hi", "Hindi").
        
        Returns:
            List[Dict]: List of service dictionaries with id, provider, and supported languages.
        
        Example:
            >>> config = ConfigManager()
            >>> services = config.list_tts_services("hi")
            >>> for svc in services:
            ...     print(f"{svc['id']} - {svc['provider']}")
            ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4 - AI4Bharat
            Bhashini/IITM/TTS - IIT Madras
        """
        language = language.lower()
        available_services = []
        
        for service_id, info in self.service_catalog.get("TTS", {}).items():
            languages = info.get("languages", [])
            
            # Check if language is supported
            lang_match = any(
                language in lang.lower() or lang.lower() in language
                for lang in languages
            )
            
            if lang_match:
                available_services.append({
                    "id": service_id,
                    "provider": info.get("provider", "Unknown"),
                    "languages": languages
                })
        
        return available_services
