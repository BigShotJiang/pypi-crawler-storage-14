import os
import time

import pytest

from blogger_mon_sdk import BlogSDK, BlogSDKError

BASE_URL = os.environ.get("BLOGGERMON_SDK_BASE_URL", "https://ysqzeskcvmalzhvjyncp.supabase.co")
API_KEY = os.environ.get("BLOGGERMON_SDK_API_KEY")
JWT = os.environ.get("BLOGGERMON_SDK_JWT")


requires_api_key = pytest.mark.skipif(not API_KEY, reason="BLOGGERMON_SDK_API_KEY not set")
requires_jwt = pytest.mark.skipif(not JWT, reason="BLOGGERMON_SDK_JWT not set")


@requires_api_key
def test_rest_endpoints_live():
  sdk = BlogSDK(BASE_URL, api_key=API_KEY)

  result = sdk.get_posts(limit=1)
  assert "posts" in result

  title = f"Python SDK Integration {int(time.time())}"
  created = sdk.create_post(title=title, content="# Test content", status="draft")
  post_id = created["id"]

  fetched = sdk.get_post(post_id)
  assert fetched["id"] == post_id

  updated = sdk.update_post(post_id, status="published")
  assert updated["status"] == "published"

  try:
    sdk.delete_post(post_id)
  except BlogSDKError as error:
    # Some API keys might not include manage_posts scope; document and move on.
    if error.status != 403:
      raise


@requires_jwt
def test_ai_endpoints_live():
  sdk = BlogSDK(BASE_URL, api_key=JWT)

  analysis = sdk.analyze_blog("Integration Title", "# Content body")
  assert "score" in analysis

  ideas = sdk.generate_ideas("AI Automation")
  assert ideas["ideas"]

  refine = sdk.refine_content("Integration Title", "# content")
  assert refine["refinedContent"]

  workflow = sdk.run_ai_workflow({"user_input": "AI blog topics"})
  assert workflow["analysis"]

