import json
from unittest.mock import Mock, patch

import pytest

from blogger_mon_sdk import BlogSDK, BlogSDKError


class FakeResponse:
  def __init__(self, status_code=200, data=None, text=""):
    self.status_code = status_code
    self._data = data
    self.text = text or json.dumps(data or {})

  @property
  def ok(self):
    return 200 <= self.status_code < 300

  @property
  def content(self):
    return json.dumps(self._data or {}).encode()

  def json(self):
    if self._data is None:
      raise ValueError("no json")
    return self._data


def test_get_posts_success():
  sdk = BlogSDK("https://example.supabase.co", api_key="bmk_test")
  fake = FakeResponse(200, {"posts": [], "total": 0})

  with patch("requests.request", return_value=fake) as mock_request:
    result = sdk.get_posts(limit=5)

  mock_request.assert_called_once()
  assert result["total"] == 0


def test_create_post_sends_payload():
  sdk = BlogSDK("https://example.supabase.co", api_key="bmk_test")
  fake = FakeResponse(200, {"id": "123"})

  with patch("requests.request", return_value=fake) as mock_request:
    sdk.create_post(title="Test", content="Hello")

  args, kwargs = mock_request.call_args
  assert kwargs["json"]["title"] == "Test"


def test_analyze_requires_auth():
  sdk = BlogSDK("https://example.supabase.co")

  with pytest.raises(BlogSDKError) as exc:
    sdk.analyze_blog("Title", "Body")

  assert exc.value.status == 401


def test_request_error_raises_blogsdkerror():
  sdk = BlogSDK("https://example.supabase.co", api_key="bmk_test")
  fake = FakeResponse(400, {"error": "Bad Request"})

  with patch("requests.request", return_value=fake):
    with pytest.raises(BlogSDKError) as exc:
      sdk.get_posts()

  assert exc.value.status == 400

