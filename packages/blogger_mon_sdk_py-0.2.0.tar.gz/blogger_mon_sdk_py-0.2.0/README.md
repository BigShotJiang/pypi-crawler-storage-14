# BloggerMon Python SDK

Official Python client for the BloggerMon API. Ship content workflows with a single API key, type-friendly helpers, and end-to-end AI automation.

## Installation

```bash
pip install blogger-mon-sdk-py
```

## Quick Start

```python
from blogger_mon_sdk import BlogSDK

sdk = BlogSDK(
    base_url="https://api.bloggermon.com",
    api_key="bmk_your_api_key"
)

# Fetch posts
posts = sdk.get_posts(limit=5)

# Create a draft
post = sdk.create_post(
    title="Hello World",
    content="# Markdown content",
    status="draft"
)
```

## AI Workflow Helper

```python
workflow = sdk.run_ai_workflow({
    "user_input": "AI productivity for marketers",
    "niche": "Marketing",
    "target_score": 92,
    "auto_publish": True,
    "publish_status": "draft"
})

print(workflow["idea"]["title"])
print(workflow["analysis"]["score"])
print(workflow["final_content"])
```

AI endpoints require an authenticated JWT (set `BLOGGERMON_SDK_JWT`) or an API key configured for the AI edge functions in your deployment.

## Environment Variables

| Variable | Description |
| -------- | ----------- |
| `BLOGGERMON_SDK_BASE_URL` | API base URL (defaults to `https://api.bloggermon.com`) |
| `BLOGGERMON_SDK_API_KEY` | API key created in the BloggerMon dashboard |
| `BLOGGERMON_SDK_JWT` | Optional Supabase user JWT for AI endpoints |

## Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt  # optional
pip install -e .
pytest
```

## License

MIT

