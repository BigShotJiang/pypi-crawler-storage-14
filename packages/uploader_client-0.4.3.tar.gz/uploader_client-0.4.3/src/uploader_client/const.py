DEFAULT_REQUEST_TIMEOUT = 300  # Таймаут запроса, секунд
DEFAULT_REQUEST_RETRIES = 5  # Количество повторных попыток
DEFAULT_RETRY_FACTOR = 1  # Шаг увеличения задержки м.д. запросами
DEFAULT_DATAMART_URL = 'http://localhost:8090'
DEFAULT_DATAMART_NAME = 'test'

# Дефолтные значения из httpx для пула соединений
DEFAULT_MAX_CONNECTIONS = 15  # Максимальное количество одновременных соединений
DEFAULT_MAX_KEEPALIVE_CONNECTIONS = 5  # Максимальное количество keep-alive соединений
DEFAULT_POOL_TIMEOUT = 5.0  # Таймаут ожидания свободного соединения из пула, сек

# Коды статусов, для которых не будут повторяться запросы
NO_RETRY_STATUS_CODES = (
    400, 401, 402, 403, 404, 406, 407, 409, 411, 413, 414, 415, 416, 417, 418, 419, 421, 422, 423, 428, 431, 449, 451,
    501, 505, 507, 508, 510, 511, 521, 525, 526,
)

FILE_STATUS_SUCCESS = 'success'
