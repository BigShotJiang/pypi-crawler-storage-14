"""
BlockMD - A powerful block-based markup language parser and query API.

BlockMD is fully compatible with Markdown and adds structured metadata capabilities.
"""

__version__ = "0.1.3"
__author__ = "Wesley Yang"
__license__ = "MIT"
__all__ = [
    "Block",
    "BlockMDParser",
    "parse_blockmd",
    "QueryBuilder",
    "query",
    "TreeView",
    "TableView",
    "ListView",
]

# Core parser components
from .parser import Block, BlockMDParser, parse_blockmd

# Query API
from .query import QueryBuilder, query

# Export formatters
from .export import TreeView, TableView, ListView


def hello() -> str:
    """Return a friendly greeting from wesleysbmd."""
    return f"BlockMD v{__version__} - A powerful Markdown parser with query capabilities!"
