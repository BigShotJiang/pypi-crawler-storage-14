"""Orchestration modules for NOBS benchmark suite."""

from src.orchestration.runner import run_all_benchmarks

__all__ = ["run_all_benchmarks"]
