from subprocess import check_output
import json
import sys

if sys.version_info < (3, 11):
    # pylint: disable-next=deprecated-class
    from importlib.abc import Traversable
else:
    from importlib.resources.abc import Traversable

def justfile(root: Traversable):
    if (root / "Justfile").is_file():
        text = check_output(["just", "--dump-format=json", "--dump"])
        return json.loads(text)
    return {}


class Just:
    family = "just"


class J001(Just):
    "Just file present"

    @staticmethod
    def check(root: Traversable) -> bool:
        return (root / "Justfile").is_file()


class J002(Just):
    "Makefile present without Justfile"

    @staticmethod
    def check(root: Traversable) -> bool:
        return not (root / "Makefile").is_file() and (root / "Justfile").is_file()


class J003(Just):
    "Provides _help method"

    @staticmethod
    def check(justfile) -> bool | str:
        match justfile:
            case {"recipes": {"_help": dict()}}:
                return True
            case _:
                return "Missing _help"


class J004(Just):
    "Provides format method"

    @staticmethod
    def check(justfile) -> bool | str:
        match justfile:
            case {"recipes": {"format": dict()}}:
                return True
            case _:
                return "Missing format"


class J005(Just):
    "Provides test method"

    @staticmethod
    def check(justfile) -> bool | str:
        match justfile:
            case {"recipes": {"test": dict()}}:
                return True
            case _:
                return "Missing test"


def repo_review_checks() -> dict[str, Just]:
    return {p.__name__: p() for p in Just.__subclasses__()}
