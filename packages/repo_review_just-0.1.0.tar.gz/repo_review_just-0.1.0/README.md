# repo-review checks for Justfiles

See also

- <https://repo-review.readthedocs.io/en/latest/index.html>
- <https://just.systems/man/en/>
