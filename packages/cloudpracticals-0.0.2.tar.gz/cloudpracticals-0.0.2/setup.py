from setuptools import setup, find_packages

setup(
    name="cloudpracticals",     # the package name on PyPI
    version="0.0.2",
    description="Small image processing helpers (assignment demo)",
    packages=find_packages(),
    python_requires=">=3.8",
)