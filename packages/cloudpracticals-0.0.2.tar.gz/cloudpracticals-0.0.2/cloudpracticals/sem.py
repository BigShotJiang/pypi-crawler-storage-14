
#ex1
#IPC
#server.py
import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = 'localhost'
port = 8002

server.bind((host,port))

server.listen(1)

print(f"you are listening to the port {port}")

conn,addr = server.accept()

print(f"yes you are connected to {addr}")

data = eval(conn.recv(1024).decode())
print(f"Client: name is {data[0]}. nums are {data[1]}")

response = sum(data[1])

conn.send(str(response).encode())

conn.close()

#client.py
import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = 'localhost'
port = 8002

client.connect((host,port))

name = input("name:")
numbers = input("number seps by space:")
numbers=[int(num) for num in numbers.split()]
msg = str((name,numbers))
client.send(msg.encode())
data = client.recv(1024).decode()
print(f"Server: sum is{data}")
client.close()
 
#Serialization
#server_dataob.py
import socket
import pickle

class DataObject:
    def __init__(self,name,values):
        self.name=name
        self.values = values

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = 'localhost'
port = 8002

server.bind((host,port))

server.listen(1)

print(f"you are listening to the port {port}")

while True:
    conn,addr = server.accept()

    print(f"yes you are connected to {addr}")

    data = conn.recv(1024)
    obj=pickle.loads(data)

    print(f"Client: name is {obj.name}. nums are {obj.values}")

    response = sum(obj.values)

    conn.send(str(response).encode())

    conn.close()

#client_dataob.py
import socket
import pickle

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = 'localhost'
port = 8002

class DataObject:
    def __init__(self,name,values):
        self.name=name
        self.values = values

client.connect((host,port))

name = input("name:")
numbers = input("number seps by space:")
numbers=[int(num) for num in numbers.split()]
msg = pickle.dumps(DataObject(name,numbers))

client.send(msg)
data = client.recv(1024).decode()
print(f"Server: sum is{data}")
client.close()
 
#RMI proxy
#server_proxy.py
import Pyro4

@Pyro4.expose

class Calculator:
    def add(self,a,b):
        return a+b
    def mul(self,a,b):
        return a*b

def main():
    d = Pyro4.Daemon()
    uri = d.register(Calculator)
    print(uri)
    d.requestLoop()

if __name__=="__main__":
    main()
    
#client_proxy.py
import Pyro4

def main():
    uri = input("Enter uri from server")
    cal = Pyro4.Proxy(uri)

    a = int(input("enter the number 1:"))
    b = int(input("enter the number 2:"))

    res1 = cal.add(a,b)
    res2 = cal.mul(a,b)

    print(res1)
    print(res2)
if __name__ == '__main__':
    main()

#Message Passing Threading
#server_threading.py
import socket
import threading

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = 'localhost'
port = 8002
server.bind((host,port))
server.listen()

clients=[]

def handle_client(client):
    while True:
        msg = client.recv(1024).decode()
        print("recd",msg)
        broadcast(msg,client)
def broadcast(msg,sender):
    for client in clients:
        if client is not sender:
            client.send(msg.encode())


while True:
    conn,addr = server.accept()
    clients.append(conn)
    thread = threading.Thread(target=handle_client, args=(conn,))
    thread.start()
#client_threading.py
import socket
import threading

def receive_messages(sock):
    while True:
        try:
            data = client.recv(1024).decode()
            print("recd:",data)
        except:
            break


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = 'localhost'
port = 8002
client.connect((host,port))

name = input("name:")

thread = threading.Thread(target=receive_messages, args=(client,))
thread.start()

while True:
    msg = input()
    client.send(f"{name}:{msg}".encode())

client.close()

#Enhanced comm w object serialization
#coordinator.py
import socket
import threading

in_cs = False
queue = []

def handle_request(conn,addr):
    global in_cs
    while True:
        data = conn.recv(1024).decode() 
        if not data:
            break
        print(f"Received from {addr}: {data}") 
        if data=="REQUEST":
            if not in_cs:
                in_cs=True
                conn.send("GRANT".encode())
                print(f"{conn} in cs")
            else:
                queue.append(conn)
        elif data=="RELEASE":
            in_cs=False
            print(f"{conn} left cs")
            if queue:
                next_conn = queue.pop(0)
                in_cs=True
                next_conn.send("GRANT".encode())

coord = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
coord.bind(("localhost",9998))
coord.listen()
while True:
    conn,addr = coord.accept()
    threading.Thread(target=handle_request, args=(conn,addr)).start()

#process.py (client)
import socket 
import time

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
sock.connect(('localhost', 9998))

def request_cs():
    sock.send("REQUEST".encode())
    reply = sock.recv(1024).decode()
    if reply=="GRANT":
        print("Entered Critical Section") 
        time.sleep(3)
        print("Exiting Critical Section") 
        sock.send("RELEASE".encode())
    
while True:
    input("enter to ask cs")
    request_cs()

#Load Balancing 4
#venkat method
VM1 -
ip a
sudo apt update 
sudo apt install apache2 -y

echo "this is vm1" | sudo tee /var/www/html/index.html

VM2 -

ip a 
sudo apt update 
sudo apt install apache2 -y

echo "this is vm2" | sudo tee /var/www/html/index.html

LOAD BALANCER 
vm3 -

sudo apt update
sudo apt install haproxy -y
sudo nano /etc/haproxy/haproxy.cfg


inside the cfg file save this at eof -

frontend http_front
	bind *:80
	default_backend http_back
backend http_back
	balance roundrobin
	server vm1 192.168.136.131:80 check 
	server vm2 192.168.136.132:80 check 

sudo systemctl restart haproxy

Server Consolidation - 
all 3 vms 
sudo apt install htop 
htop

fault tolerance

sudo systemctl stop apache2

#Task Scheduling 
#5 alt venkat 
VM1-

sudo hostnamectl set-hostname vm1
sudo apt update
sudo apt install openssh-server -y
sudo systemctl enable ssh
sudo systemctl start ssh
sudo systemctl status ssh

after the prev status command check if output comes as application running 

VM2- 
sudo hostnamectl set-hostname vm2
sudo apt update 
sudo apt install openssh-server -y
sudo systemctl enable ssh
sudo systemctl start ssh
sudo systemctl status ssh

after the prev status command check if output comes as application running 

VM3-

sudo hostnamectl set-hostname admin
sudo nano /etc/hosts

in the file at the end add these 2 ips of vm1 and vm2 
192.168.136.131 vm1
192.168.136.132 vm2

exit the file 

ssh-keygen -t rsa
press enter 
press enter until u get the next command prompt new line 

ssh-copy-id srihari@vm1
ssh-copy-id srihari@vm2

ssh vm1 hostname 
ssh vm2 hostname 

if outputs come as vm1 and vm2 then ssh has been setup correctly


crontab -e 

go to the last line and add this 

*/1 * * * * ssh srihari@vm1 'date >> /home/Srihari/ubuntu/cloud_output.log'
*/1 * * * * ssh srihari@vm2 'date >> /home/Srihari/ubuntu/cloud_output.log'

after this go to vm1 and vm2 
inside home/Srihari/ create a folder named ubuntu , close and reopen file manager , u will see the cloud_output.log file which keeps updating date logs every 1 minute 


#clock and time server sync
######time_server.py

import socket
import datetime

server = socket.socket()
server.bind(('localhost', 12345))
server.listen(1)
print("Server is waiting for client connection...")

conn, addr = server.accept()
print("Connected to:", addr)

server_time = datetime.datetime.now().strftime("%H:%M:%S")
print("Server Time:", server_time)

conn.send(server_time.encode())

conn.close()
server.close()


####time_client.py
import socket
import datetime

client = socket.socket()
client.connect(('localhost', 12345))

server_time = client.recv(1024).decode()
print("Server Time:", server_time)

client_time = datetime.datetime.now().strftime("%H:%M:%S")
print("Client Time:", client_time)

fmt = "%H:%M:%S"
t1 = datetime.datetime.strptime(server_time, fmt)
t2 = datetime.datetime.strptime(client_time, fmt)
diff = (t2 - t1).total_seconds()

print("Time difference (in seconds):", diff)
client.close()




#2nd File =========================================================

# Implementation of Lamport's Logical Clock and Vector Clock

def lamport_clock():
    n = int(input("Enter number of processes: "))
    clocks = [0] * n
    while True:
        print("\n1. Internal Event\n2. Send Message\n3. Receive Message\n4. Exit")
        ch = int(input("Enter choice: "))
        if ch == 1:
            p = int(input("Enter process number: "))
            clocks[p] += 1
            print(f"Process {p} performed an event, Clock = {clocks}")
        elif ch == 2:
            s = int(input("Enter sender process: "))
            clocks[s] += 1
            print(f"Message sent from P{s} with timestamp {clocks[s]}")
        elif ch == 3:
            r = int(input("Enter receiver process: "))
            t = int(input("Enter received timestamp: "))
            clocks[r] = max(clocks[r], t) + 1
            print(f"Message received by P{r}, Clock = {clocks}")
        elif ch == 4:
            break
        else:
            print("Invalid choice!")

def vector_clock():
    n = int(input("Enter number of processes: "))
    VC = [[0 for _ in range(n)] for _ in range(n)]
    while True:
        print("\n1. Internal Event\n2. Send Message\n3. Receive Message\n4. Exit")
        ch = int(input("Enter choice: "))
        if ch == 1:
            p = int(input("Enter process number: "))
            VC[p][p] += 1
            print(f"Internal event in P{p}, VC = {VC[p]}")
        elif ch == 2:
            s = int(input("Enter sender process: "))
            VC[s][s] += 1
            print(f"Message sent from P{s}, VC = {VC[s]}")
        elif ch == 3:
            r = int(input("Enter receiver process: "))
            sv = list(map(int, input("Enter sender vector (space-separated): ").split()))
            for i in range(n):
                VC[r][i] = max(VC[r][i], sv[i])
            VC[r][r] += 1
            print(f"Message received by P{r}, VC = {VC[r]}")
        elif ch == 4:
            break
        else:
            print("Invalid choice!")

print("\n1. Lamport Clock\n2. Vector Clock")
choice = int(input("Enter your choice: "))
if choice == 1:
    lamport_clock()
else:
    vector_clock()


curl - o filname.py link
https://0x0.st/KSp0.py


# Disclaimer: Tested on my system, not on lab system. But should work in theory.

# On all 3 VMs, Find their IP address first

ip a

# Ex. 192.168.111.131 - fy1
# Ex. 192.168.111.132 - fy2
# Ex. 192.168.111.133 - fy3

# Adding to host

# On all 3 VMs (technically fy1 alone is enough, but all 3 VMs for best practice), map IP to names in hosts

sudo nano /etc/hosts

# Add these three lines

192.168.111.131 fy1
192.168.111.132 fy2
192.168.111.133 fy3

# ctrl+X, then Y, then Enter to save and exit from nano.

# To test, ping one VM from another, and check if it is error-free.
# Ex, from fy1

ping fy2


# Load Balancing

# Now, install a web server on fy2 and fy3, and change their index pages to identify them

sudo apt update
sudo apt install apache2 -y

# Update the index page
sudo nano /var/www/html/index.html

# On fy2:
<h1>This response is from web server fy2</h1>

# On fy3:
<h1>This response is from web server fy3</h1>

# Save and exit

# On both machines
sudo systemctl restart apache2

# test by opening browser and navigating to the IP addresses of the machines (http://<ip_addr>). Can do so from one VM to another as well, entering the correct IP.

# on fy1, install HAProxy to distribute traffic between fy1 and fy2:
sudo apt update
sudo apt install haproxy -y

# open the configuration file:
sudo nano /etc/haproxy/haproxy.cfg

# Add this:
frontend http_front
    bind *:80
    stats uri /haproxy?stats
    default_backend http_back

backend http_back
    balance roundrobin
    server fy2 fy2:80 check
    server fy3 fy3:80 check

# Save and exit

# Restart to load the new configuration
sudo systemctl restart haproxy

# To test, open a web browser and navigate to IP address of fy1. Keep refreshing and it should change between fy2's page and fy3's page.

# For task scheduling:

# To set up passwordless SSH (press enter for all prompts, don't type anything):

# On fy2 and fy3:
sudo apt update
sudo apt install openssh-server
sudo systemctl status ssh

# On fy1:

ssh-keygen -t rsa

# Now, to append fy1's public key to fy2 and fy3

ssh-copy-id fy2@fy2
# type yes and type password of fy2@fy2

ssh-copy-id fy3@fy3
# type yes and password of fy3@fy3

# To test, run commands and check if they are executable without password:
ssh fy2@fy2 'hostname'
ssh fy3@fy3 'hostname'

# Scheduling tasks with cron

crontab -e
# choose an editor, nano ig

# Add these lines to the bottom of the file:
* * * * * ssh fy2@fy2 'echo "Task executed on $(hostname) at $(date)" >> /tmp/cron_job.log'
* * * * * ssh fy3@fy3 'echo "Task executed on $(hostname) at $(date)" >> /tmp/cron_job.log'

# Wait for a minute to pass, then check on fy2 and fy3 if the log has been created. Can check directly or can check using ssh from fy1:
ssh fy2@fy2 'cat /tmp/cron_job.log'
ssh fy3@fy3 'cat /tmp/cron_job.log'



Explanation of passwordless SSH:
The Authentication Process

Once the public key is on the server, the login process happens in a few steps without you needing to do anything:

    Initiation: You try to connect from your client (fy1) to the server (fy2) by typing ssh fy2@fy2. Your client tells the server, "Hey, I'm fy2 and I'd like to authenticate using my key."

    The Challenge: The server looks inside its ~/.ssh/authorized_keys file. It finds the public key you put there earlier. It then creates a random, secret message and encrypts it using your public key. The server sends this encrypted message back to your client.

    The Response: Your client (fy1) receives the encrypted message. This message can only be decrypted by your corresponding private key. Your SSH client uses your private key (id_rsa) to decrypt the message, revealing the original secret.

Verification: Your client sends the decrypted secret back to the server.

Access Granted: The server compares the decrypted secret it just received with the original one it created. If they match, it has successfully proven that you are in possession of the correct private key. Access is granted immediately, without ever asking for a password.


import threading, queue, time, random

NUM_PROCS = 3
ATTEMPTS = 2

coordinator = queue.Queue()
grant_queues = [queue.Queue() for _ in range(NUM_PROCS)]

def coordinator_process():
    cs_busy = False
    # waiting = []

    while True:
        if not cs_busy and not coordinator.empty():
            pid = coordinator.get()
            grant_queues[pid].put("GRANT")
            cs_busy = True
        else:
            # check if someone has exited
            for pid in range(NUM_PROCS):
                try:
                    msg = grant_queues[pid].get_nowait()
                    if msg == "RELEASE":
                        cs_busy = False
                except:
                    pass
        time.sleep(0.1)


def process(pid):
    for i in range(ATTEMPTS):
        time.sleep(random.uniform(0.5, 1.5))
        print(f"[Centralized] P{pid} requesting CS")
        coordinator.put(pid)
        grant_queues[pid].get()   # wait for GRANT
        print(f"[Centralized] P{pid} ENTER CS")
        time.sleep(1)
        print(f"[Centralized] P{pid} EXIT CS")
        grant_queues[pid].put("RELEASE")

if _name_ == "_main_":
    threading.Thread(target=coordinator_process, daemon=True).start()
    for pid in range(NUM_PROCS):
        threading.Thread(target=process, args=(pid,), daemon=True).start()
    time.sleep(10)

import threading, queue, time, random

NUM_PROCS = 3
ATTEMPTS = 2

# Message queues for each process
queues = [queue.Queue() for _ in range(NUM_PROCS)]
lamport = [0] * NUM_PROCS

def process(pid):
    deferred = []          # list of processes waiting for reply
    requesting = False
    my_request = (None, None)  # (timestamp, pid)

    def send(to, msg):
        queues[to].put((msg, pid, lamport[pid]))

    for i in range(ATTEMPTS):
        time.sleep(random.uniform(0.5, 1.5))

        lamport[pid] += 1
        my_request = (lamport[pid], pid)
        requesting = True
        print(f"[RA] P{pid} requesting CS (ts={my_request[0]})")

        for j in range(NUM_PROCS):
            if j != pid:
                send(j, "REQ")

        replies = 0
        while True:
            msg, sender, t = queues[pid].get()
            lamport[pid] = max(lamport[pid], t) + 1

            if msg == "REQ":
                other_req = (t, sender)
                if requesting and my_request < other_req:
                    deferred.append(sender)
                else:
                    send(sender, "REP")

            elif msg == "REP":
                replies += 1
                if replies == NUM_PROCS - 1:
                    break

        print(f"[RA] P{pid} ENTER CS")
        time.sleep(1)
        print(f"[RA] P{pid} EXIT CS")

        for s in deferred:
            send(s, "REP")
        deferred.clear()
        requesting = False

if _name_ == "_main_":
    for pid in range(NUM_PROCS):
        threading.Thread(target=process, args=(pid,), daemon=True).start()
    time.sleep(20)




#File 3 ===========================================================


# exercise 1 client 

import socket

def start_client(host='localhost', port=5000):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    client_socket.connect((host, port))

    while True:
        message = input("Enter space-separated numbers (or 'exit' to quit): ")
        if message.lower() == 'exit':
            break

        client_socket.sendall(message.encode())

        response = client_socket.recv(1024).decode()
        print(f"Server response: {response}")

    client_socket.close()

if __name__ == "__main__":
    start_client()



#exercise 1 server 
import socket

def start_server(host='localhost', port=5000):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))

    server_socket.listen(1)
    print(f"Server listening on {host}:{port}")

    client_socket, client_address = server_socket.accept()
    print(f"Connected to {client_address}")

    while True:
        data = client_socket.recv(1024).decode()
        if not data:
            break
        print(f"Received: {data}")

        try:
            numbers = list(map(int, data.strip().split()))
            total = sum(numbers)
            response = f"Sum: {total}"
        except ValueError:
            response = "Invalid input. Send space-separated integers."

        client_socket.sendall(response.encode())

    client_socket.close()
    server_socket.close()

if __name__ == "__main__":
    start_server()




#client code pickle  ex1 task2 

import socket
import pickle

class DataObject:
    def __init__(self, name, values):
        self.name = name
        self.values = values

def start_client(host='localhost', port=5000):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    while True:
        name = input("Enter your name (or 'exit' to quit): ")
        if name.lower() == 'exit':
            break

        try:
            nums = input("Enter space-separated numbers: ")
            values = list(map(int, nums.strip().split()))
            obj = DataObject(name, values)

            client_socket.sendall(pickle.dumps(obj))

            response = client_socket.recv(4096)
            message = pickle.loads(response)
            print("Server response:", message)

        except Exception as e:
            print("Error:", e)

    client_socket.close()

if __name__ == "__main__":
    start_client()


#task2 ex1 server 

import socket
import pickle

class DataObject:
    def __init__(self, name, values):
        self.name = name
        self.values = values

def start_server(host='localhost', port=5000):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)
    print(f"Server listening on {host}:{port}")

    client_socket, addr = server_socket.accept()
    print(f"Connected to {addr}")

    while True:
        try:
            data = client_socket.recv(4096)
            if not data:
                break

            received_obj = pickle.loads(data)
            print(f"Received object from {received_obj.name} with values: {received_obj.values}")

            total = sum(received_obj.values)
            response = f"Hello {received_obj.name}, sum is {total}"

            client_socket.sendall(pickle.dumps(response))

        except Exception as e:
            print("Error:", e)
            break

    client_socket.close()
    server_socket.close()

if __name__ == "__main__":
    start_server()



#exercise 2 client 

import Pyro4

def main():
    uri=input("Enter the server URI:")
    calculator=Pyro4.Proxy(uri)

    try:
        a=int(input("Enter the first number"))
        b=int(input("Enter the first number"))

        result_add=calculator.add_numbers(a,b)
        result_mult=calculator.multiply(a,b)

        print(f"Addition result:{result_add}")
        print(f"Multiplication result:{result_mult}")

    except ValueError:
        print("Invalid input.Please enter inetegers")
    except Exception as e:
        print("Error during remote call:",e)

if __name__=="__main__":
    main()




#exercise 2 server 

import Pyro4

@Pyro4.expose
class Calculator:
    def add_numbers(Self,a,b):
        return a+b
    
    def multiply(Self,a,b):
        return a*b
    
def main():
    daemon=Pyro4.Daemon()
    uri=daemon.register(Calculator)
    print("Calculator service is running")
    print("URI:",uri)
    daemon.requestLoop()

if __name__=="__main__":
    main()




#ex 3 client 




import socket
import threading

def receive_messageS(sock):
    while True:
        try:
            msg=sock.recv(1024).decode()
            if msg:
                print(f"Received:",msg)
        except:
            break
        
def start_client(host='localhost',port=5000):
    client=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    client.connect((host,port))
    threading.Thread(target=receive_messageS,args=(client,),daemon=True).start()
    print("Connecting to server")
    print("You can start communicating.Type exit to quit")
    while True:
        msg=input()
        if msg.lower()=="exit":
            break
        client.send(msg.encode())
    client.close()

if __name__=="__main__":
    start_client()



#ex3  server 


import socket
import threading

clients=[]

def handle_client(client_socket,addr):
    print(f"Client connected: {addr}")
    while True:
        try:
            msg=client_socket.recv(1024).decode()
            if not msg:
                break
            print(f"{addr}:{msg}")
            broadcast(msg,client_socket)
        except:
            break
    client_socket.close()
    clients.remove(client_socket)

def broadcast(message,sender_conn):
    for client in clients:
        if client!=sender_conn:
            try:
                client.send(message.encode())
            except:
                pass
            
def start_server(host='localhost',port=5000):
    server_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    server_socket.bind((host,port))
    server_socket.listen()
    print(f"Server listening on {host}:{port}")
    while True:
        client_socket,addr=server_socket.accept()
        clients.append(client_socket)
        threading.Thread(target=handle_client,args=(client_socket,addr)).start()


if __name__=="__main__":
    start_server()





#ex3_ricart_agarwala



import threading, queue, time, random

n = 3  # number of processes
q = [queue.Queue() for _ in range(n)]
clock = [0]*n

def proc(id):
    for _ in range(2):  # each process tries twice
        time.sleep(random.uniform(0.5,1.5))
        clock[id]+=1
        req = (clock[id], id)
        print(f"P{id} → wants CS (t={req[0]})")

        # send REQ to all others
        for j in range(n):
            if j!=id: q[j].put(("REQ",id,clock[id]))

        replies=0
        while replies < n-1:
            msg, sender, t = q[id].get()
            clock[id] = max(clock[id],t)+1

            if msg=="REQ":
                if (t,sender) < req:  # other's request is earlier
                    q[sender].put(("REP",id,clock[id]))
                else:  # defer reply
                    time.sleep(0.5)
                    q[sender].put(("REP",id,clock[id]))

            elif msg=="REP":
                replies+=1

        print(f"P{id} → ENTER CS")
        time.sleep(1)
        print(f"P{id} → EXIT CS")

if __name__=="__main__":
    for i in range(n):
        threading.Thread(target=proc,args=(i,),daemon=True).start()
    time.sleep(10)





# ex3_token_ring

import threading, time, random

n = 3           # number of processes
token = 0       # who has the token now
lock = threading.Lock()

def process(pid):
    global token
    for _ in range(2):   # each tries twice
        time.sleep(random.uniform(0.5, 1.5))
        while token != pid:     # wait for token
            time.sleep(0.1)
        print(f"P{pid} → ENTER CS")
        time.sleep(1)
        print(f"P{pid} → EXIT CS")
        with lock:
            token = (token + 1) % n   # pass token

for i in range(n):
    threading.Thread(target=process, args=(i,), daemon=True).start()

time.sleep(10)



# ex3 centralized 
import threading, time, random, queue

n = 3
req_q = queue.Queue()
lock = threading.Lock()
busy = False

def coordinator():
    global busy
    while True:
        if not busy and not req_q.empty():
            pid = req_q.get()
            busy = True
            print(f"→ Coordinator gives CS to P{pid}")
            time.sleep(1)
            print(f"→ P{pid} finished CS")
            busy = False
        time.sleep(0.1)

def process(pid):
    for _ in range(2):
        time.sleep(random.uniform(0.5, 1.5))
        print(f"P{pid} → wants CS")
        req_q.put(pid)

threading.Thread(target=coordinator, daemon=True).start()
for i in range(n):
    threading.Thread(target=process, args=(i,), daemon=True).start()
time.sleep(10)



# ex4 clock 

#Lamport's Logical Clock

def lamport_clock():
    n = int(input("Enter number of processes: "))
    clocks = [0] * n
    while True:
        print("\n1. Internal Event\n2. Send Message\n3. Receive Message\n4. Exit")
        ch = int(input("Enter choice: "))
        if ch == 1:
            p = int(input("Enter process number: "))
            clocks[p] += 1
            print(f"Process {p} performed an event, Clock = {clocks}")
        elif ch == 2:
            s = int(input("Enter sender process: "))
            clocks[s] += 1
            print(f"Message sent from P{s} with timestamp {clocks[s]}")
        elif ch == 3:
            r = int(input("Enter receiver process: "))
            t = int(input("Enter received timestamp: "))
            clocks[r] = max(clocks[r], t) + 1
            print(f"Message received by P{r}, Clock = {clocks}")
        elif ch == 4:
            break
        else:
            print("Invalid choice!")

#Vector clock

def vector_clock():
    n = int(input("Enter number of processes: "))
    VC = [[0 for _ in range(n)] for _ in range(n)]
    while True:
        print("\n1. Internal Event\n2. Send Message\n3. Receive Message\n4. Exit")
        ch = int(input("Enter choice: "))
        if ch == 1:
            p = int(input("Enter process number: "))
            VC[p][p] += 1
            print(f"Internal event in P{p}, VC = {VC[p]}")
        elif ch == 2:
            s = int(input("Enter sender process: "))
            VC[s][s] += 1
            print(f"Message sent from P{s}, VC = {VC[s]}")
        elif ch == 3:
            r = int(input("Enter receiver process: "))
            sv = list(map(int, input("Enter sender vector (space-separated): ").split()))
            for i in range(n):
                VC[r][i] = max(VC[r][i], sv[i])
            VC[r][r] += 1
            print(f"Message received by P{r}, VC = {VC[r]}")
        elif ch == 4:
            break
        else:
            print("Invalid choice!")

print("\n1. Lamport Clock\n2. Vector Clock")
choice = int(input("Enter your choice: "))
if choice == 1:
    lamport_clock()
else:
    vector_clock()








# cmd 
# Required three VMs

# vmlb (load balancer)
# vm1
# vm2

# vmlb:

# sudo apt update
# sudo apt install nginx
# cd /etc
# cd nginx -> files -> nginx.conf
# sudo apt install gedit
# sudo gedit nginx.conf
#     -> under http{
#         upstream backend {
#             server ipvm1;
#             server ipvm2;
#         }
#     }
#     -> ls - check sits.available
# cd sites.available -> ls -> check default
# sudo gedit default
#    -> location/{
#     proxy_pass http://backend;
#     proxy_next_upstream error timeout http_500 http_502 http_503 http_504;
#    }
# systemctl restart nginx (choose authenticate)
# systemctl status nginx

# vm1:
# sudo apt update 
# sudo apt install apache2 -y
# sudo systemctl status apache2

# open browser : <ip-vmlb>

# cd /var
# cd www
# cd html
# sudo gedit index.html

# (Change something)

# vm2:
# sudo apt update
# sudo apt install apache2 -y
# systemctl status apache2

# To find ip:hostname -I

# Fault tolerance:
# power off vm2
# refresh vm : only shows vm1





# Task scheduling

# vmlb : use crontab

# sudo apt update 
# nano ~/task.sh
#   -> #!/bin/bash
#     echo "Task completed $(date)" >> ~/task.log
#     Ctrl+X,Y,enter

# crontab -e
#    -> * * * * * /home/ubuntu/task.sh
#    Ctrl+X,Y,enter

# chmod +x /home/ubuntu/task.sh

# cat task.log



# systemctl status cron
# systemctl restart cron
all_codes.py
Displaying all_codes.py.



#Web-Server-Task-Scheduling-Passwordless-SSH.pdf

########################################
# 1. Get IP addresses of each VM
########################################
ip a # shows all IPs, note the one like 192.168.111.xxx
########################################
# 2. Map hostnames in /etc/hosts (do this on ALL 3 VMs)
########################################
sudo nano /etc/hosts
# Add these lines:
# 192.168.111.131 fy1
# 192.168.111.132 fy2
# 192.168.111.133 fy3
ping -c 2 fy2 # test that fy2 resolves from fy1
########################################
# 3. Install web servers on fy2 & fy3
########################################
sudo apt update && sudo apt install apache2 -y
echo '<h1>This is fy2</h1>' | sudo tee /var/www/html/index.html # run on fy2
echo '<h1>This is fy3</h1>' | sudo tee /var/www/html/index.html # run on fy3
sudo systemctl restart apache2
curl http://fy2 # test from another VM
curl http://fy3
########################################
# 4. Install & configure HAProxy on fy1
########################################
sudo apt update && sudo apt install haproxy -y
sudo nano /etc/haproxy/haproxy.cfg
# Add this to the file:
# frontend http_
front
# bind *:80
# default
_
backend http_
back
#
# backend http_
back
# balance roundrobin
# server fy2 fy2:80 check
# server fy3 fy3:80 check
sudo systemctl restart haproxy
curl http://fy1 # refresh multiple times, should alternate fy2/fy3
########################################
# 5. Enable passwordless SSH (from fy1 → fy2 & fy3)
########################################
# On fy2 & fy3:
sudo apt install openssh-server -y
# On fy1:
ssh-keygen -t rsa -N ''
-f ~/.ssh/id
rsa
_
ssh-copy-id fy2@fy2
ssh-copy-id fy3@fy3
ssh fy2@fy2 hostname # test (no password prompt)
ssh fy3@fy3 hostname
########################################
# 6. Schedule tasks with cron (on fy1)
########################################
crontab -e
# Add lines:
# */1 * * * * ssh fy2@fy2 'echo "fy2 ran at $(date)" >> /tmp/cron.log'
# */1 * * * * ssh fy3@fy3 'echo "fy3 ran at $(date)" >> /tmp/cron.log'
# After 1–2 minutes, check logs on fy2/fy3:
ssh fy2@fy2 cat /tmp/cron.log
ssh fy3@fy3 cat /tmp/cron.log