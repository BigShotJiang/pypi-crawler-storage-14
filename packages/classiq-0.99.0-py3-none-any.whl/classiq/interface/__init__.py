from classiq.interface._version import VERSION as _VERSION

__version__ = _VERSION
