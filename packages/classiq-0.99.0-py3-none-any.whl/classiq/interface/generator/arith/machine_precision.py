from typing import Final

DEFAULT_MACHINE_PRECISION: Final[int] = 8
