from classiq.interface.generator.functions.function_declaration import *
