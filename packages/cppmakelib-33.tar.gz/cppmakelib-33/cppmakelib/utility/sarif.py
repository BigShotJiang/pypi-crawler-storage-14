def make_sarif(error):
    return error