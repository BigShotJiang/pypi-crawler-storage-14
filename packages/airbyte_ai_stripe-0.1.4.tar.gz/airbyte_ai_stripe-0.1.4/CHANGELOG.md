# Changelog

## [0.1.4] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.3] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.2] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: c1700e5e
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.1] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.0] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1
