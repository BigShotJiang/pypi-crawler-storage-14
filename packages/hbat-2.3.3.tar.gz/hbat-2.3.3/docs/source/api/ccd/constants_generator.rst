Constants Generator
===================

.. automodule:: hbat.ccd.constants_generator
   :members:
   :undoc-members:
   :show-inheritance: