try:
    from .._version import version as APP_VERSION
except ImportError:
    APP_VERSION = "0.0.0+unknown"

# Application metadata
APP_NAME = "Hydrogen Bond Analysis Tool"
