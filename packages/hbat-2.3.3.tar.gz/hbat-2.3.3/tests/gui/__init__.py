"""
GUI module tests for HBAT.

Tests for graphical user interface components including parameter panels,
results display, and preset management.
"""