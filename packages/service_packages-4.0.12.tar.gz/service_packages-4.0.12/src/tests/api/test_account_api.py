from litestar.status_codes import HTTP_201_CREATED


async def test_account_login(): ...


async def test_account_logout(): ...


async def test_account_signup(http_api_client):
    response = await http_api_client.post(
        "/api/auth/account/signup",
        json={
            "email": "newuser@mail.com",
            "password": "newuserpassword",
        },
    )

    assert response.status_code == HTTP_201_CREATED


async def test_account_reset_password(): ...
