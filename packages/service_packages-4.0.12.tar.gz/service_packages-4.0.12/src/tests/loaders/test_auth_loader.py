from auth.loaders import AuthLoader
from auth.services import UserService, RoleService, PermissionService


async def test_auth_loader(user_service: UserService, role_service: RoleService, permission_service: PermissionService):
    auth_loader = AuthLoader(user_service, role_service, permission_service)
    await auth_loader.load({
        "users": [{
            "email": "test@mail.com",
            "password": "test_password",
        }]
    })

    assert await user_service.count() == 1

    # teardown
    await user_service.delete_where()