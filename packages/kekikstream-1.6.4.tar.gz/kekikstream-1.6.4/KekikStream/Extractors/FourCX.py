# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.ContentX import ContentX

class FourCX(ContentX):
    name     = "FourCX"
    main_url = "https://four.contentx.me"