# magix
   
   Graph database object mapper. (In development)

