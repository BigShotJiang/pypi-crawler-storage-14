AGGREGATED_SOLVING_FIELDS = [
    "ok",
    "no_solution",
    "timeout",
    "solver_error",
    "not_applicable",
    "goal_not_achieved"
]
