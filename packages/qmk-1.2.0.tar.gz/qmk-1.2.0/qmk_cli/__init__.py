"""A program to help you work with qmk_firmware."""

__version__ = '1.2.0'
