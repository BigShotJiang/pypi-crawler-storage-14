"""
Provider Adapter for Alpha Zero 2

Adapts existing erosolar_cli providers for use in competitive framework.

Author: Bo Shang
Education: Tufts University, 2010
Framework: erosolar_cli
Research: Alpha Zero 2 - Recursive Self-Improvement in Competitive Multi-Agent Systems

Tech Stack:
    - Integrates with erosolar_cli providers (anthropic, openai, google)
    - Uses existing AnthropicProviderOptions, etc.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from ..providers.anthropic_provider import AnthropicProvider, AnthropicProviderOptions


@dataclass
class ProviderConfig:
    """Configuration for creating a provider."""

    provider_type: str  # "anthropic", "openai", "google"
    model: str
    api_key: Optional[str] = None
    max_tokens: int = 4096
    temperature: float = 0.7


def create_provider_from_config(config: ProviderConfig):
    """
    Create a provider from configuration.

    Args:
        config: Provider configuration

    Returns:
        Configured LLM provider

    Raises:
        ValueError: If provider type is not supported
    """
    if config.provider_type.lower() == "anthropic":
        api_key = config.api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            raise ValueError("Anthropic API key required. Set ANTHROPIC_API_KEY or provide api_key.")

        options = AnthropicProviderOptions(
            api_key=api_key,
            model=config.model,
            max_tokens=config.max_tokens,
            temperature=config.temperature,
        )
        return AnthropicProvider(options)

    elif config.provider_type.lower() == "openai":
        # Import OpenAI provider if available
        try:
            from ..providers.openai_provider import OpenAIProvider, OpenAIProviderOptions

            api_key = config.api_key or os.environ.get("OPENAI_API_KEY", "")
            if not api_key:
                raise ValueError("OpenAI API key required. Set OPENAI_API_KEY or provide api_key.")

            options = OpenAIProviderOptions(
                api_key=api_key,
                model=config.model,
                max_tokens=config.max_tokens,
                temperature=config.temperature,
            )
            return OpenAIProvider(options)
        except ImportError:
            raise ValueError("OpenAI provider not available")

    elif config.provider_type.lower() == "google":
        # Import Google provider if available
        try:
            from ..providers.google_provider import GoogleProvider, GoogleProviderOptions

            api_key = config.api_key or os.environ.get("GOOGLE_API_KEY", "")
            if not api_key:
                raise ValueError("Google API key required. Set GOOGLE_API_KEY or provide api_key.")

            options = GoogleProviderOptions(
                api_key=api_key,
                model=config.model,
                max_tokens=config.max_tokens,
                temperature=config.temperature,
            )
            return GoogleProvider(options)
        except ImportError:
            raise ValueError("Google provider not available")

    else:
        raise ValueError(f"Unsupported provider type: {config.provider_type}")


def create_anthropic_provider(
    model: str = "claude-sonnet-4-20250514",
    api_key: Optional[str] = None,
    max_tokens: int = 4096,
    temperature: float = 0.7,
) -> AnthropicProvider:
    """
    Create an Anthropic provider with sensible defaults.

    Args:
        model: Model to use
        api_key: API key (uses ANTHROPIC_API_KEY env var if not provided)
        max_tokens: Maximum tokens for response
        temperature: Temperature for generation

    Returns:
        Configured AnthropicProvider
    """
    key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        raise ValueError("Anthropic API key required. Set ANTHROPIC_API_KEY environment variable.")

    options = AnthropicProviderOptions(
        api_key=key,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return AnthropicProvider(options)


# Default models for competition
DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-4-20250514",
    "openai": "gpt-4o",
    "google": "gemini-1.5-pro",
}


class AlphaZeroAgentWrapper:
    """
    Wrapper around AgentRuntime that adds Alpha Zero 2 capabilities.

    Provides:
    - Performance introspection
    - Code quality evaluation
    - Competitive metrics tracking
    - Self-improvement suggestions
    """

    def __init__(
        self,
        agent,
        agent_id: str = "agent",
        enable_introspection: bool = True,
        enable_code_evaluation: bool = True,
    ):
        """
        Initialize Alpha Zero agent wrapper.

        Args:
            agent: The underlying agent runtime
            agent_id: Unique identifier for this agent
            enable_introspection: Enable performance introspection
            enable_code_evaluation: Enable code quality evaluation
        """
        self.agent = agent
        self.agent_id = agent_id
        self.enable_introspection = enable_introspection
        self.enable_code_evaluation = enable_code_evaluation
        self._trace_counter = 0
        self._traces = []
        self._metrics = {
            "total_messages": 0,
            "total_duration_ms": 0,
            "code_blocks_evaluated": 0,
        }

    async def send(self, text: str, use_streaming: bool = False) -> str:
        """
        Send a message with performance tracking.

        Args:
            text: The message to send
            use_streaming: Whether to use streaming

        Returns:
            The response text
        """
        import time

        start_time = time.time()
        trace_id = f"trace-{self._trace_counter}"
        self._trace_counter += 1

        try:
            response = await self.agent.send(text, use_streaming)
            elapsed_ms = int((time.time() - start_time) * 1000)

            # Track metrics
            self._metrics["total_messages"] += 1
            self._metrics["total_duration_ms"] += elapsed_ms

            # Evaluate code if present
            if self.enable_code_evaluation and "```" in response:
                self._metrics["code_blocks_evaluated"] += response.count("```") // 2

            # Record trace if introspection is enabled
            if self.enable_introspection:
                self._traces.append({
                    "trace_id": trace_id,
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "prompt": text[:100] + "..." if len(text) > 100 else text,
                    "response_length": len(response),
                    "duration_ms": elapsed_ms,
                })

            return response
        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            self._metrics["total_duration_ms"] += elapsed_ms
            raise

    def get_metrics(self):
        """Get current performance metrics."""
        return {
            **self._metrics,
            "avg_response_time_ms": (
                self._metrics["total_duration_ms"] / self._metrics["total_messages"]
                if self._metrics["total_messages"] > 0
                else 0
            ),
            "trace_count": len(self._traces),
        }

    def get_traces(self, limit: int = 10):
        """Get recent execution traces."""
        return self._traces[-limit:]

    def reset_metrics(self):
        """Reset all metrics."""
        self._metrics = {
            "total_messages": 0,
            "total_duration_ms": 0,
            "code_blocks_evaluated": 0,
        }
        self._traces = []
        self._trace_counter = 0
