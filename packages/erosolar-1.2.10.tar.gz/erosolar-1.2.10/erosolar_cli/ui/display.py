"""
Display system for terminal UI with Rich formatting.

This refactor emphasizes copy-friendly output, adaptive styling (plain mode
when piping/logging), and optional advanced visuals when a TTY is available.
"""

from __future__ import annotations

import os
import re
import sys
import time
from dataclasses import dataclass
from typing import Literal, Optional

from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner
from rich.text import Text

from .advanced_display import AdvancedDisplay, ColorPalette, GradientEffect


@dataclass
class DisplayMessageMetadata:
    """Metadata for display messages."""

    is_final: bool = True
    elapsed_ms: Optional[int] = None
    usage: Optional[dict] = None
    context_window_tokens: Optional[int] = None


@dataclass
class DisplaySettings:
    """Runtime display settings derived from environment and terminal state."""

    plain_output: bool
    enable_color: bool
    enable_animations: bool
    use_unicode: bool
    width: int


ActionStatus = Literal["pending", "success", "error", "info", "warning"]


def _env_flag(name: str, default: bool = False) -> bool:
    """Return True if an env var is set to a truthy value."""
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() not in {"0", "false", "no", "off"}


def _safe_terminal_width(default: int = 80) -> int:
    """Best-effort terminal width without raising."""
    try:
        return os.get_terminal_size().columns
    except OSError:
        return default


def _build_icons(use_unicode: bool) -> dict[str, str]:
    """Choose unicode or ASCII friendly icon set."""
    if use_unicode:
        return {
            "action": "⏺",
            "sub_action": "⎿",
            "info": "ℹ",
            "warning": "⚠",
            "error": "✗",
            "success": "✓",
            "progress": "✽",
            "thinking": "…",
            "sparkle": "✦",
            "folder": "📂",
            "chip": "⚙",
            "version": "◎",
        }

    return {
        "action": "*",
        "sub_action": "-",
        "info": "i",
        "warning": "!",
        "error": "x",
        "success": "+",
        "progress": "*",
        "thinking": "...",
        "sparkle": "*",
        "folder": "[dir]",
        "chip": "[model]",
        "version": "v",
    }


class Display:
    """
    Display class manages all terminal UI output.

    Features:
    - Claude Code style prefixes with copy-safe fallbacks
    - Rich-based terminal output with colors when available
    - Adaptive plain mode for piping/logging
    - Spinner/thinking indicators that leave readable trails
    - Display lock to prevent user input from interfering with output
    """

    def __init__(self):
        """Initialize display with Rich console and adaptive settings."""
        self.settings = self._detect_settings()
        self.icons = _build_icons(self.settings.use_unicode)

        self.console = self._build_console(sys.stdout)
        self.error_console = self._build_console(sys.stderr)

        self.active_spinner: Optional[Live] = None
        self.context_percent = 0
        self.request_start_time = 0
        self.file_changes = {
            "files": set(),
            "lines_added": 0,
            "lines_removed": 0,
        }

        # Display lock state - when locked, output is protected from user input
        self._output_locked = False
        self._pending_output: list[str] = []

        self._advanced_enabled = (
            self.settings.enable_color
            and self.settings.use_unicode
            and not self.settings.plain_output
        )
        self.advanced = AdvancedDisplay(self.console) if self._advanced_enabled else None
        if self.advanced:
            self.advanced.set_palette(ColorPalette.AURORA)

    def _build_console(self, stream) -> Console:
        """Create a Rich console honoring current settings."""
        return Console(
            file=stream,
            force_terminal=False,
            highlight=False,
            markup=True,
            soft_wrap=True,
            color_system="truecolor" if self.settings.enable_color else None,
            no_color=not self.settings.enable_color,
            width=self.settings.width,
        )

    def _detect_settings(self) -> DisplaySettings:
        """Derive display settings from environment and terminal capabilities."""
        force_plain = _env_flag("EROSOLAR_CLI_PLAIN") or _env_flag("EROSOLAR_PLAIN")
        ascii_only = _env_flag("EROSOLAR_ASCII")
        disable_anim = _env_flag("EROSOLAR_NO_ANIM")
        stdout_tty = sys.stdout.isatty()
        term_dumb = os.getenv("TERM") == "dumb"

        plain_output = force_plain or term_dumb or not stdout_tty
        enable_color = not plain_output and not _env_flag("NO_COLOR")
        use_unicode = not ascii_only and not plain_output
        enable_animations = not disable_anim and not plain_output

        return DisplaySettings(
            plain_output=plain_output,
            enable_color=enable_color,
            enable_animations=enable_animations,
            use_unicode=use_unicode,
            width=_safe_terminal_width(),
        )

    def _style(self, text: str, style: Optional[str]) -> str:
        """Apply a Rich style only when colors are enabled."""
        if not text or not style or not self.settings.enable_color:
            return text
        return f"[{style}]{text}[/{style}]"

    def _status_icon(self, status: ActionStatus) -> str:
        """Map statuses to colored icons."""
        color = self._get_status_color(status)
        icon = {
            "success": self.icons["success"],
            "error": self.icons["error"],
            "warning": self.icons["warning"],
            "pending": self.icons["action"],
            "info": self.icons["info"],
        }.get(status, self.icons["action"])
        return self._style(icon, color)

    def show_welcome(
        self,
        profile_label: str,
        profile_name: str,
        model: str,
        provider: str,
        working_dir: str,
        version: Optional[str] = None,
    ) -> None:
        """
        Display welcome banner with session information.

        Args:
            profile_label: Human-readable profile label
            profile_name: Profile identifier
            model: Model name
            provider: Provider name
            working_dir: Working directory path
            version: Optional version string
        """
        if not model or not provider or not working_dir:
            return

        self.console.print()

        model_label = self._format_model_label(model)
        working_path = self._abbreviate_path(working_dir, self.settings.width or 80)
        # Model line with swap hint
        model_line = f"{model_label} (/model to swap)"

        if self.advanced:
            model_text = GradientEffect.wave_gradient(
                model_line,
                ColorPalette.AURORA.value["primary"],
                ColorPalette.AURORA.value["secondary"],
                0.3,
            )
            profile_text = GradientEffect.linear_gradient(
                profile_label,
                ColorPalette.AURORA.value["accent"],
                ColorPalette.AURORA.value["info"],
            )
            dir_text = GradientEffect.pulse_gradient(
                working_path,
                ColorPalette.AURORA.value["info"],
                0.4,
            )

            self.console.print(model_text)
            self.console.print(profile_text)
            self.console.print(dir_text)

            if version:
                version_text = GradientEffect.rainbow_gradient(
                    f"{version} • support@ero.solar"
                )
                self.console.print(version_text)

            # Simple separator - no complex animations
            self.console.print("-" * self.settings.width)
            self.console.print()
            return

        lines = [
            f"{self.icons['sparkle']} Profile: {profile_label} ({profile_name})",
            f"{self.icons['chip']} Model: {model_line}",
            f"{self.icons['folder']} Workspace: {working_path}",
        ]
        if version:
            lines.append(f"{self.icons['version']} Version: {version} • support@ero.solar")

        for line in lines:
            self.console.print(line)
        self.console.print("-" * self.settings.width)
        self.console.print()

    def lock_output(self) -> None:
        """
        Lock the display to prevent user input from interfering.

        Call this before starting output that shouldn't be interrupted.
        """
        self._output_locked = True

    def unlock_output(self) -> None:
        """
        Unlock the display to allow user input again.

        Call this after output is complete.
        """
        self._output_locked = False

    def is_output_locked(self) -> bool:
        """Check if the display output is currently locked."""
        return self._output_locked

    def show_thinking(self, message: str = "Thinking...") -> None:
        """
        Show thinking/working indicator.

        Args:
            message: Thinking message to display
        """
        self.stop_thinking()
        self.request_start_time = time.time()
        self.lock_output()  # Lock output while processing

        if not self.settings.enable_animations:
            self.console.print(f"{self.icons['thinking']} {message}")
            return

        spinner = Spinner("dots", text=message, style="cyan")
        self.active_spinner = Live(
            spinner,
            console=self.console,
            refresh_per_second=12,
            transient=False,
        )
        self.active_spinner.start()

    def update_thinking(self, message: str) -> None:
        """
        Update thinking message.

        Args:
            message: New message
        """
        if self.active_spinner:
            spinner = Spinner("dots", text=message, style="cyan")
            self.active_spinner.update(spinner)
        else:
            self.show_thinking(message)

    def stop_thinking(self) -> None:
        """Stop thinking indicator and unlock output."""
        if self.active_spinner:
            self.active_spinner.stop()
            self.active_spinner = None

        self.context_percent = 0
        self.request_start_time = 0
        self.unlock_output()  # Unlock output when done processing

    def show_thinking_summary(self, summary: str, elapsed_seconds: int = 0) -> None:
        """
        Show thinking summary (∴ Thought for Xs).

        Args:
            summary: Thinking summary text
            elapsed_seconds: Time spent thinking
        """
        time_str = f" for {elapsed_seconds}s" if elapsed_seconds > 0 else ""
        self.console.print(
            f"\n{self.icons['progress']} Thought{time_str} {summary} (ctrl+o to show thinking)\n"
        )

    def show_progress(
        self,
        message: str,
        elapsed_seconds: int = 0,
        token_delta: Optional[int] = None,
        show_controls: bool = True,
    ) -> None:
        """
        Show progress indicator (✽ Message... · elapsed · tokens).

        Args:
            message: Progress message
            elapsed_seconds: Elapsed time in seconds
            token_delta: Token usage delta (↑ for input, ↓ for output)
            show_controls: Whether to show control hints
        """
        parts = [f"{self.icons['progress']} {message}…"]

        if elapsed_seconds > 0:
            mins = elapsed_seconds // 60
            secs = elapsed_seconds % 60
            time_str = f"{mins}m {secs:02d}s" if mins > 0 else f"{secs}s"
            parts.append(time_str)

        if token_delta:
            arrow = "↑" if token_delta > 0 else "↓"
            parts.append(f"{arrow} {abs(token_delta)/1000:.1f}k tokens")

        if show_controls:
            parts.append("(esc to interrupt · ctrl+t to show todos)")

        separator = " · " if self.settings.use_unicode else " | "
        self.console.print(separator.join(parts))

    def set_context_usage(self, percent: float) -> None:
        """
        Set context usage percentage.

        Args:
            percent: Context usage percentage (0-100)
        """
        self.context_percent = max(0, min(100, round(percent)))

    def show_assistant_message(
        self,
        content: str,
        metadata: Optional[DisplayMessageMetadata] = None,
    ) -> None:
        """
        Show assistant message with optional metadata.

        Args:
            content: Message content
            metadata: Optional display metadata
        """
        if not content.strip():
            return

        self.console.print(content.strip())

        if metadata and metadata.elapsed_ms:
            elapsed = self._format_elapsed(metadata.elapsed_ms)
            if elapsed:
                self.console.print(f"  elapsed {elapsed}")

        self.console.print()

    def show_action(self, text: str, status: ActionStatus = "info") -> None:
        """
        Show action with Claude Code style prefix.

        Args:
            text: Action text
            status: Action status
        """
        if not text.strip():
            return

        icon = self._status_icon(status)
        self.console.print(f"{icon} {text}")

    def show_sub_action(self, text: str, status: ActionStatus = "info") -> None:
        """
        Show sub-action with nested prefix.

        Args:
            text: Sub-action text
            status: Action status
        """
        if not text.strip():
            return

        icon = self._style(self.icons["sub_action"], self._get_status_color(status))
        lines = text.split("\n")
        for i, line in enumerate(lines):
            prefix = f"  {icon} " if i == 0 else "    "
            self.console.print(f"{prefix}{line.strip()}")

        self.console.print()

    def show_message(
        self,
        content: str,
        role: Literal["assistant", "system"] = "assistant",
    ) -> None:
        """
        Show message based on role.

        Args:
            content: Message content
            role: Message role
        """
        if role == "system":
            self.show_system_message(content)
        else:
            self.show_assistant_message(content)

    def show_system_message(self, content: str) -> None:
        """
        Show system message.

        Args:
            content: System message content
        """
        self.console.print(content.strip())
        self.console.print()

    def show_error(self, message: str) -> None:
        """
        Show error message.

        Args:
            message: Error message
        """
        icon = self._status_icon("error")
        self.error_console.print(f"\n{icon} {message}\n")

    def show_warning(self, message: str) -> None:
        """
        Show warning message.

        Args:
            message: Warning message
        """
        icon = self._status_icon("warning")
        self.console.print(f"\n{icon} {message}\n")

    def show_info(self, message: str) -> None:
        """
        Show info message.

        Args:
            message: Info message
        """
        self.console.print(message)

    def show_planning_step(self, step: str, index: int, total: int) -> None:
        """
        Show planning step.

        Args:
            step: Step description
            index: Step index (1-based)
            total: Total steps
        """
        if not step.strip() or index < 1 or total < 1 or index > total:
            return

        self.console.print(f"{self.icons['progress']} Plan {index}/{total}")
        self.console.print(f"  {step}")

    def record_file_change(
        self, file_path: str, lines_added: int, lines_removed: int
    ) -> None:
        """
        Record file change for summary.

        Args:
            file_path: File path that changed
            lines_added: Number of lines added
            lines_removed: Number of lines removed
        """
        if not file_path:
            return

        self.file_changes["files"].add(file_path)
        self.file_changes["lines_added"] += max(0, lines_added)
        self.file_changes["lines_removed"] += max(0, lines_removed)

    def show_file_change_summary(self) -> None:
        """Show file change summary in Claude Code style at bottom of prompt area."""
        files = self.file_changes["files"]
        lines_added = self.file_changes["lines_added"]
        lines_removed = self.file_changes["lines_removed"]

        if not files:
            return

        file_count = len(files)
        summary = f"  {file_count} file{'s' if file_count > 1 else ''} +{lines_added} -{lines_removed}"

        self.console.print(summary)

    def clear_file_changes(self) -> None:
        """Clear file change tracking."""
        self.file_changes["files"].clear()
        self.file_changes["lines_added"] = 0
        self.file_changes["lines_removed"] = 0

    def clear(self) -> None:
        """Clear the console when attached to a TTY."""
        if sys.stdout.isatty():
            self.console.clear()

    def new_line(self) -> None:
        """Print a blank line."""
        self.console.print()

    def _format_model_label(self, model: str) -> str:
        """
        Format model name for display.

        Args:
            model: Model identifier

        Returns:
            The actual model name (no longer abbreviating)
        """
        # Return actual model name - users need to see exactly what they're using
        return model

    def _abbreviate_path(self, path: str, max_len: int) -> str:
        """
        Abbreviate path if too long.

        Args:
            path: File path
            max_len: Maximum length

        Returns:
            Abbreviated path
        """
        if len(path) <= max_len:
            return path

        parts = path.split("/")
        if len(parts) <= 2:
            return path

        return f"{parts[0]}/.../{parts[-1]}"

    def _get_status_color(self, status: ActionStatus) -> str:
        """
        Get color for status.

        Args:
            status: Action status

        Returns:
            Rich color name
        """
        color_map = {
            "success": "green",
            "error": "red",
            "warning": "yellow",
            "pending": "cyan",
            "info": "blue",
        }
        return color_map.get(status, "white")

    def _format_elapsed(self, elapsed_ms: int) -> Optional[str]:
        """
        Format elapsed time.

        Args:
            elapsed_ms: Elapsed milliseconds

        Returns:
            Formatted time string or None
        """
        if elapsed_ms < 0:
            return None

        total_seconds = max(0, round(elapsed_ms / 1000))
        minutes = total_seconds // 60
        seconds = total_seconds % 60

        if minutes > 0:
            return f"{minutes}m {seconds:02d}s"

        return f"{seconds}s"

    def show_tool_call(self, tool_name: str, args: dict, truncate: bool = True) -> None:
        """
        Show tool call with sophisticated formatting.

        Args:
            tool_name: Name of the tool being called
            args: Tool arguments
            truncate: Whether to truncate long arguments
        """
        if self.advanced:
            self.advanced.show_tool_call(tool_name, args)
            return

        arg_parts = []
        for key, value in args.items():
            value_str = str(value)
            if truncate and len(value_str) > 80:
                value_str = value_str[:77] + "..."
            arg_parts.append(f"{key}={value_str}")
        args_text = ", ".join(arg_parts)

        icon = self._status_icon("pending")
        self.console.print(f"{icon} {tool_name}({args_text})")

    def show_tool_result(
        self,
        tool_name: str,
        result: str,
        success: bool = True,
        show_full: bool = False,
    ) -> None:
        """
        Show tool result with copy-friendly formatting.

        Args:
            tool_name: Name of the tool
            result: Result text
            success: Whether tool succeeded
            show_full: Whether to show full result or truncate
        """
        if self.advanced:
            self.advanced.show_tool_result(tool_name, result, success)
            return

        icon = self._status_icon("success" if success else "error")

        lines = result.splitlines() or [""]
        if not show_full and len(lines) > 40:
            extra = len(lines) - 40
            lines = lines[:40]
            lines.append(f"... (+{extra} more lines)")

        for i, line in enumerate(lines):
            prefix = f"  {icon} " if i == 0 else "    "
            self.console.print(f"{prefix}{line}")

    def show_diff(
        self,
        file_path: str,
        old_lines: list[str],
        new_lines: list[str],
        context_lines: int = 3,
    ) -> None:
        """
        Show file diff with line numbers and +/-.

        Args:
            file_path: Path to the file
            old_lines: Original file lines
            new_lines: New file lines
            context_lines: Number of context lines to show around changes
        """
        import difflib

        diff = list(
            difflib.unified_diff(
                old_lines,
                new_lines,
                lineterm="",
                n=context_lines,
            )
        )

        if len(diff) <= 2:
            return

        diff = diff[2:]  # skip headers
        old_line = 1
        new_line = 1
        hunk_header = re.compile(r"@@ -(?P<old>\d+)(?:,\d+)? \+(?P<new>\d+)(?:,\d+)? @@")

        self.console.print(f"{self.icons['sub_action']}  Updated {file_path}")

        for line in diff:
            if line.startswith("@@"):
                match = hunk_header.match(line)
                if match:
                    old_line = int(match.group("old"))
                    new_line = int(match.group("new"))
                continue
            if line.startswith("-"):
                prefix = self._style(f"{old_line:4d} -", "red")
                self.console.print(f"     {prefix}  {line[1:]}")
                old_line += 1
            elif line.startswith("+"):
                prefix = self._style(f"{new_line:4d} +", "green")
                self.console.print(f"     {prefix}  {line[1:]}")
                new_line += 1
            else:
                prefix = self._style(f"{old_line:4d}", "dim")
                self.console.print(f"     {prefix}    {line[1:]}")
                old_line += 1
                new_line += 1


# Singleton instance
display = Display()
