"""
Streaming indicator placeholders.
"""

from __future__ import annotations


def start_spinner(label: str = "Thinking...") -> str:
    return f"[spinner] {label}"


def stop_spinner() -> str:
    return "[spinner stopped]"
