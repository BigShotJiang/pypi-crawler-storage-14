"""
Interactive REPL shell for Erosolar CLI.

Minimal, stable implementation with:
- Simple prompt-toolkit REPL
- Clean prompt at bottom
- No complex separators or racing conditions
- Reliable input handling
- Smart Ctrl+C handling (clear input / stop AI / quit)
"""

from __future__ import annotations

import asyncio
import os
import time
from pathlib import Path
from typing import Optional

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style

from ..config import resolve_profile, ResolvedProfile
from ..core.agent import AgentOptions, AgentRuntime
from ..core.context_manager import create_default_context_manager
from ..core.tool_runtime import ToolExecutionContext, ToolSuite, create_default_tool_runtime
from ..alpha_zero import AlphaZeroAgentWrapper
from ..providers.provider_factory import create_provider
from ..runtime.session_store import SaveSessionOptions, load_session_by_id, save_session_snapshot
from ..tools import bash_tools, edit_tools, file_tools, glob_tools, grep_tools
from ..ui.display import display
from ..workspace import build_workspace_context, WorkspaceCaptureOptions


class InteractiveShell:
    """Interactive REPL shell - minimal and stable."""

    def __init__(
        self,
        working_dir: str,
        profile_name: str = "default",
        provider_override: Optional[str] = None,
        model_override: Optional[str] = None,
        session_id: Optional[str] = None,
        session_title: Optional[str] = None,
        autosave: bool = False,
        enable_alpha_zero: bool = True,
        enabled_plugins: Optional[list] = None,
    ):
        """Initialize interactive shell."""
        self.working_dir = working_dir
        self.profile_name = profile_name
        self.provider_override = provider_override
        self.model_override = model_override
        self.session_id = session_id
        self.session_title = session_title
        self.autosave = autosave
        self.enable_alpha_zero = enable_alpha_zero
        self.enabled_plugins = enabled_plugins or []
        self.agent: Optional[AgentRuntime] = None
        self.alpha_zero_agent: Optional[AlphaZeroAgentWrapper] = None
        self.profile = None
        self.session: Optional[PromptSession] = None

        # Create history file
        history_dir = Path.home() / ".erosolar"
        history_dir.mkdir(exist_ok=True)
        self.history_file = history_dir / "history.txt"

        # Simple, clean style
        self.style = Style.from_dict({
            "prompt": "#00aa00 bold",
        })

        # Ctrl+C tracking for double-tap quit
        self._last_ctrl_c_time: float = 0.0
        self._ctrl_c_timeout: float = 1.5  # seconds for double-tap
        self._is_processing: bool = False
        self._cancel_requested: bool = False

    async def setup(self) -> None:
        """Set up the agent and tools."""
        from ..providers.provider_factory import get_configured_providers, get_provider_info
        from ..providers.model_fetcher import fetch_models_for_provider
        from ..core.user_preferences import get_user_default_model

        # Get configured providers
        configured = get_configured_providers()

        # Fetch latest models from APIs (updates cache) silently
        for provider_id in configured[:4]:  # Check first 4 providers
            try:
                await fetch_models_for_provider(provider_id)
            except Exception:
                pass  # Silently skip if fetch fails

        # Build workspace context
        workspace_context = build_workspace_context(
            self.working_dir,
            WorkspaceCaptureOptions(
                tree_depth=1,
                max_entries=30,
                doc_excerpt_limit=200,
            ),
        )

        # Resolve profile
        self.profile = resolve_profile(
            name=self.profile_name,
            workspace_context=workspace_context,
            provider_override=self.provider_override,
            model_override=self.model_override,
        )

        # Show welcome banner
        display.show_welcome(
            profile_label=self.profile.label,
            profile_name=self.profile.name,
            model=self.profile.model,
            provider=self.profile.provider,
            working_dir=self.working_dir,
            version="1.2.10",
        )

        # Show provider swap commands
        if configured:
            provider_cmds = " | ".join([f"/provider {p}" for p in configured[:5]])
            display.show_info(f"Providers: {provider_cmds}")

        # Show model swap hint
        from ..providers.provider_factory import get_models_for_provider
        models = get_models_for_provider(self.profile.provider)
        if models:
            model_cmds = " | ".join([f"/model {m}" for m in models[:3]])
            display.show_info(f"Models: {model_cmds}...")

        # Show if using user's default model
        user_model = get_user_default_model(self.profile.provider)
        if user_model and user_model == self.profile.model:
            display.show_info(f"Using your saved default: {user_model}")

        # Create provider
        provider = create_provider(
            self.profile.provider,
            self.profile.model,
            max_tokens=self.profile.max_tokens,
            temperature=self.profile.temperature,
        )

        # Create execution context
        context = ToolExecutionContext(
            profile_name=self.profile.name,
            provider=self.profile.provider,
            model=self.profile.model,
        )

        # Create context manager and tool runtime
        context_manager = create_default_context_manager()
        tool_runtime = create_default_tool_runtime(context)

        # Register all tool suites
        tool_runtime.register_suite(
            ToolSuite(
                id="file-ops",
                name="File Operations",
                description="Read, write, list, and search files",
                tools=file_tools.create_file_tools(self.working_dir),
            )
        )

        tool_runtime.register_suite(
            ToolSuite(
                id="edit-ops",
                name="Edit Operations",
                description="Surgical string replacement in files",
                tools=edit_tools.create_edit_tools(self.working_dir),
            )
        )

        tool_runtime.register_suite(
            ToolSuite(
                id="bash-ops",
                name="Bash Operations",
                description="Execute bash commands with safety validation",
                tools=bash_tools.create_bash_tools(self.working_dir),
            )
        )

        tool_runtime.register_suite(
            ToolSuite(
                id="glob-ops",
                name="Glob Operations",
                description="Fast file pattern matching",
                tools=glob_tools.create_glob_tools(self.working_dir),
            )
        )

        tool_runtime.register_suite(
            ToolSuite(
                id="grep-ops",
                name="Grep Operations",
                description="Powerful regex content search",
                tools=grep_tools.create_grep_tools(self.working_dir),
            )
        )

        # Register plugin tool suites
        if self.enabled_plugins:
            from ..plugins import registry, load_builtin_plugins
            load_builtin_plugins()

            for plugin_id in self.enabled_plugins:
                plugin = registry.load(plugin_id, self.working_dir)
                if plugin:
                    for suite in plugin.get_tool_suites():
                        tool_runtime.register_suite(suite)
                    display.show_info(f"Loaded plugin: {plugin_id}")

        # Create agent
        self.agent = AgentRuntime(
            AgentOptions(
                provider=provider,
                tool_runtime=tool_runtime,
                system_prompt=self.profile.system_prompt,
                context_manager=context_manager,
            )
        )

        # Wrap with Alpha Zero 2 if enabled
        if self.enable_alpha_zero:
            self.alpha_zero_agent = AlphaZeroAgentWrapper(
                agent=self.agent,
                agent_id=self.session_id or "interactive",
                enable_introspection=True,
                enable_code_evaluation=True,
            )
            display.show_info("Alpha Zero 2 performance tracking enabled")

        # Resume session history if provided
        if self.session_id:
            stored = load_session_by_id(self.session_id)
            if stored:
                self.agent.load_history(stored.messages)
                display.show_info(f"Resumed session {self.session_id} ({stored.title})")
            else:
                display.show_warning(f"No session found for id '{self.session_id}', starting new.")

        # Create prompt session - minimal config
        self.session = PromptSession(
            history=FileHistory(str(self.history_file)),
            style=self.style,
            multiline=False,
        )

    async def start(self) -> None:
        """Start the interactive REPL loop."""
        if not self.agent or not self.session:
            await self.setup()

        display.show_info("Type /help for commands, Ctrl+C twice to quit")
        display.new_line()

        while True:
            try:
                # Wait for any pending output to complete before showing prompt
                # This ensures output is never interrupted by the prompt
                while display.is_output_locked():
                    await asyncio.sleep(0.05)

                # Reset cancel flag before new input
                self._cancel_requested = False

                # Show prompt on a new line to keep it separated from output
                user_input = await self.session.prompt_async(
                    [("class:prompt", "> ")],
                    style=self.style,
                )

                if not user_input.strip():
                    continue

                # Handle slash commands
                if user_input.startswith("/"):
                    if not await self.handle_command(user_input):
                        break
                    continue

                # Send to agent - display is locked during processing
                self._is_processing = True
                display.show_thinking("Processing...")

                try:
                    # Create task so we can cancel it
                    if self.alpha_zero_agent:
                        task = asyncio.create_task(self.alpha_zero_agent.send(user_input))
                    else:
                        task = asyncio.create_task(self.agent.send(user_input))

                    # Wait for completion or cancellation
                    while not task.done():
                        if self._cancel_requested:
                            task.cancel()
                            try:
                                await task
                            except asyncio.CancelledError:
                                pass
                            display.stop_thinking()
                            display.show_warning("Request cancelled")
                            break
                        await asyncio.sleep(0.05)
                    else:
                        # Task completed normally
                        response = task.result()
                        display.stop_thinking()
                        display.show_assistant_message(response)
                        self._save_session_snapshot(silent=True)

                except asyncio.CancelledError:
                    display.stop_thinking()
                    display.show_warning("Request cancelled")
                except Exception as error:
                    display.stop_thinking()
                    display.show_error(f"Failed to get response: {error}")
                finally:
                    self._is_processing = False

            except KeyboardInterrupt:
                self._handle_ctrl_c()
                if self._should_quit():
                    break
                continue
            except EOFError:
                break

        display.show_info("Goodbye!")

    def _handle_ctrl_c(self) -> None:
        """Handle Ctrl+C with smart behavior."""
        now = time.time()

        # If AI is processing, cancel it
        if self._is_processing:
            self._cancel_requested = True
            display.stop_thinking()
            display.show_warning("Stopping AI... (Ctrl+C again to quit)")
            self._last_ctrl_c_time = now
            return

        # If output is locked (spinner running), stop it
        if display.is_output_locked():
            display.stop_thinking()
            display.show_warning("Interrupted")
            self._last_ctrl_c_time = now
            return

        # Empty prompt - check for double Ctrl+C to quit
        time_since_last = now - self._last_ctrl_c_time
        if time_since_last < self._ctrl_c_timeout:
            # Double tap - will quit
            display.new_line()
            return

        # First Ctrl+C on empty prompt
        display.new_line()
        display.show_info("Press Ctrl+C again to quit, or type /exit")
        self._last_ctrl_c_time = now

    def _should_quit(self) -> bool:
        """Check if user wants to quit (double Ctrl+C)."""
        now = time.time()
        time_since_last = now - self._last_ctrl_c_time
        # Quit if second Ctrl+C was very recent (within 0.1s of handling)
        return time_since_last < 0.1 and not self._is_processing

    def _save_session_snapshot(
        self, title_override: Optional[str] = None, silent: bool = False
    ) -> None:
        """Persist the current conversation if autosave is enabled or a session id is set."""
        if not self.agent or not self.profile:
            return

        if not self.autosave and not self.session_id:
            return

        summary = save_session_snapshot(
            SaveSessionOptions(
                id=self.session_id,
                title=title_override or self.session_title,
                profile=self.profile.name,
                provider=self.profile.provider,
                model=self.profile.model,
                workspace_root=self.working_dir,
                messages=self.agent.get_history(),
            )
        )

        created_new = False
        if not self.session_id:
            self.session_id = summary.id
            created_new = True
            display.show_info(f"Saved session as {summary.id}")
        elif title_override and title_override != self.session_title:
            self.session_title = title_override

        if not silent or created_new:
            display.show_info(f"Session saved: {summary.id} — {summary.title}")

    def _load_session(self, session_id: str) -> None:
        """Load an existing session into the current agent."""
        if not self.agent:
            return

        stored = load_session_by_id(session_id)
        if not stored:
            display.show_warning(f"No session found for id '{session_id}'")
            return

        self.session_id = session_id
        self.agent.load_history(stored.messages)
        display.show_info(f"Loaded session {session_id} ({stored.title})")

    async def handle_command(self, command: str) -> bool:
        """
        Handle slash commands.

        Returns:
            True to continue, False to exit
        """
        cmd = command.lower().strip()

        if cmd in ("/exit", "/quit", "/q"):
            return False

        elif cmd.startswith("/save"):
            parts = command.split(maxsplit=1)
            title = parts[1].strip() if len(parts) > 1 else None
            self._save_session_snapshot(title_override=title)

        elif cmd.startswith("/session"):
            parts = command.split(maxsplit=1)
            if len(parts) < 2:
                display.show_warning("Usage: /session <id>")
            else:
                self._load_session(parts[1].strip())

        elif cmd in ("/help", "/h", "/?"):
            self.show_help()

        elif cmd in ("/clear", "/cls"):
            display.clear()
            if self.profile:
                display.show_welcome(
                    profile_label=self.profile.label,
                    profile_name=self.profile.name,
                    model=self.profile.model,
                    provider=self.profile.provider,
                    working_dir=self.working_dir,
                    version="1.2.10",
                )

        elif cmd.startswith("/model"):
            parts = command.split(maxsplit=1)
            if len(parts) > 1:
                model_arg = parts[1].strip()
                if model_arg == "save":
                    # Save current model as default
                    self._save_default_model()
                elif model_arg == "clear":
                    # Clear default model
                    self._clear_default_model()
                else:
                    # Switch to different model
                    await self._switch_model(model_arg)
            else:
                self._show_model_info()

        elif cmd.startswith("/provider "):
            # Switch to a different provider
            parts = command.split(maxsplit=1)
            if len(parts) > 1:
                await self._switch_provider(parts[1].strip())
            else:
                self._show_providers()

        elif cmd.startswith("/providers"):
            self._show_providers()

        elif cmd in ("/metrics", "/stats", "/perf"):
            self.show_metrics()

        elif cmd in ("/suggestions", "/improve"):
            self.show_improvement_suggestions()

        elif cmd in ("/plugins",):
            self.show_plugins()

        elif cmd.startswith("/local"):
            parts = command.split(maxsplit=1)
            subcommand = parts[1].strip().lower() if len(parts) > 1 else ""
            await self._handle_local_command(subcommand)

        else:
            display.show_warning(f"Unknown command: {command}")
            display.show_info("Type /help for available commands")

        return True

    def show_metrics(self) -> None:
        """Show Alpha Zero 2 performance metrics."""
        if not self.alpha_zero_agent:
            display.show_warning("Alpha Zero 2 tracking is not enabled")
            return

        summary = self.alpha_zero_agent.get_performance_summary()
        display.show_info(summary)

    def show_improvement_suggestions(self) -> None:
        """Show AI-generated improvement suggestions."""
        if not self.alpha_zero_agent:
            display.show_warning("Alpha Zero 2 tracking is not enabled")
            return

        suggestions = self.alpha_zero_agent.get_improvement_suggestions()
        if not suggestions:
            display.show_info("No improvement suggestions at this time.")
            return

        display.show_info("\nImprovement Suggestions:")
        for i, suggestion in enumerate(suggestions, 1):
            display.show_info(f"  {i}. {suggestion}")

    def show_plugins(self) -> None:
        """Show available and loaded plugins."""
        from ..plugins import registry, load_builtin_plugins

        load_builtin_plugins()

        available = registry.list_available()
        loaded = registry.list_loaded()

        display.show_info("\nPlugin System")
        display.show_info("=" * 40)

        display.show_info("\nLoaded plugins:")
        if self.enabled_plugins:
            for pid in self.enabled_plugins:
                display.show_info(f"  ✓ {pid}")
        else:
            display.show_info("  (none)")

        display.show_info("\nAvailable plugins:")
        for meta in available:
            status = "loaded" if meta.id in loaded else "available"
            auth = " (requires auth)" if meta.requires_auth else ""
            display.show_info(f"  • {meta.id}: {meta.description}{auth}")

    def _show_model_info(self) -> None:
        """Show current model and default model info."""
        from ..core.user_preferences import get_user_default_model
        from ..providers.provider_factory import get_models_for_provider

        display.show_info(f"Current model: {self.profile.model}")
        display.show_info(f"Provider: {self.profile.provider}")

        user_default = get_user_default_model(self.profile.provider)
        if user_default:
            display.show_info(f"Your default: {user_default}")
        else:
            display.show_info("No default model set (using provider default)")

        # Show available models for this provider
        models = get_models_for_provider(self.profile.provider)
        if models:
            display.show_info(f"\nAvailable models for {self.profile.provider}:")
            for i, m in enumerate(models):
                marker = " ← current" if m == self.profile.model else ""
                display.show_info(f"  {i+1}. {m}{marker}")

        display.show_info("\nCommands:")
        display.show_info("  /model <name>      Switch to a different model")
        display.show_info("  /model <number>    Switch by number from list above")
        display.show_info("  /model save        Save current model as your default")
        display.show_info("  /model clear       Clear your default model")

    async def _switch_model(self, model_arg: str) -> None:
        """Switch to a different model."""
        from ..providers.provider_factory import get_models_for_provider, create_provider

        models = get_models_for_provider(self.profile.provider)

        # Check if it's a number (selecting from list)
        try:
            idx = int(model_arg) - 1
            if 0 <= idx < len(models):
                new_model = models[idx]
            else:
                display.show_warning(f"Invalid model number. Choose 1-{len(models)}")
                return
        except ValueError:
            # It's a model name
            new_model = model_arg

        # Check if model is available for this provider
        if new_model not in models:
            display.show_warning(f"Model '{new_model}' not available for {self.profile.provider}")
            display.show_info(f"Available: {', '.join(models[:5])}...")
            return

        if new_model == self.profile.model:
            display.show_info(f"Already using {new_model}")
            return

        # Create new provider with the new model
        display.show_thinking(f"Switching to {new_model}...")
        try:
            new_provider = create_provider(
                self.profile.provider,
                new_model,
                max_tokens=self.profile.max_tokens,
                temperature=self.profile.temperature,
            )

            # Update agent with new provider
            self.agent.provider = new_provider

            # Update profile model
            old_model = self.profile.model
            # Create a new profile with updated model
            self.profile = ResolvedProfile(
                name=self.profile.name,
                label=self.profile.label,
                provider=self.profile.provider,
                model=new_model,
                system_prompt=self.profile.system_prompt,
                temperature=self.profile.temperature,
                max_tokens=self.profile.max_tokens,
                model_locked=self.profile.model_locked,
                provider_locked=self.profile.provider_locked,
            )

            display.stop_thinking()
            display.show_info(f"Switched from {old_model} to {new_model}")
        except Exception as e:
            display.stop_thinking()
            display.show_error(f"Failed to switch model: {e}")

    def _save_default_model(self) -> None:
        """Save current model as the user's default."""
        from ..core.user_preferences import set_user_default_model

        set_user_default_model(self.profile.model, self.profile.provider)
        display.show_info(f"Saved '{self.profile.model}' as your default model for {self.profile.provider}")
        display.show_info("This will be used on future launches unless overridden with --model")

    def _clear_default_model(self) -> None:
        """Clear the user's default model."""
        from ..core.user_preferences import preferences

        preferences.clear_default_model(self.profile.provider)
        display.show_info(f"Cleared default model for {self.profile.provider}")
        display.show_info("Future launches will use the provider's default model")

    async def _switch_provider(self, provider_arg: str) -> None:
        """Switch to a different provider."""
        from ..providers.provider_factory import get_configured_providers, get_default_model, create_provider

        configured = get_configured_providers()
        new_provider = provider_arg.lower()

        if new_provider not in configured:
            display.show_warning(f"Provider '{provider_arg}' not configured.")
            display.show_info(f"Available: {', '.join(configured)}")
            return

        if new_provider == self.profile.provider:
            display.show_info(f"Already using {new_provider}")
            return

        # Get the default model for the new provider
        new_model = get_default_model(new_provider)
        if not new_model:
            display.show_warning(f"No default model for {new_provider}")
            return

        display.show_thinking(f"Switching to {new_provider} ({new_model})...")
        try:
            new_provider_instance = create_provider(
                new_provider,
                new_model,
                max_tokens=self.profile.max_tokens,
                temperature=self.profile.temperature,
            )

            # Update agent with new provider
            self.agent.provider = new_provider_instance

            # Update profile
            old_provider = self.profile.provider
            old_model = self.profile.model
            self.profile = ResolvedProfile(
                name=self.profile.name,
                label=self.profile.label,
                provider=new_provider,
                model=new_model,
                system_prompt=self.profile.system_prompt,
                temperature=self.profile.temperature,
                max_tokens=self.profile.max_tokens,
                model_locked=False,
                provider_locked=False,
            )

            display.stop_thinking()
            display.show_info(f"Switched from {old_provider}/{old_model} to {new_provider}/{new_model}")
        except Exception as e:
            display.stop_thinking()
            display.show_error(f"Failed to switch provider: {e}")

    def _show_providers(self) -> None:
        """Show configured providers and their status."""
        from ..providers.provider_factory import get_configured_providers, get_provider_info

        configured = get_configured_providers()
        display.show_info("\nConfigured Providers:")
        display.show_info("=" * 40)

        if not configured:
            display.show_info("No providers configured. Set an API key:")
            display.show_info("  OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, etc.")
            return

        for pid in configured:
            info = get_provider_info(pid)
            if info:
                marker = " ← active" if pid == self.profile.provider else ""
                display.show_info(f"  ✓ {info.label} ({pid}){marker}")
                display.show_info(f"    Default: {info.default_model}")

        display.show_info("\nTip: Use /local to see local/air-gapped providers")

    async def _handle_local_command(self, subcommand: str) -> None:
        """Handle /local commands for local LLM management."""
        from ..providers.local_providers import (
            scan_local_providers,
            format_local_status,
            format_local_setup_guide,
        )
        from ..providers.local_setup import (
            full_setup,
            get_setup_status,
            format_setup_status,
            download_model,
            list_local_models,
            start_ollama_server,
            RECOMMENDED_MODELS,
        )

        if subcommand == "guide":
            display.show_info(format_local_setup_guide())

        elif subcommand == "status":
            display.show_thinking("Checking local LLM status...")
            status = get_setup_status()
            display.stop_thinking()
            display.show_info(format_setup_status(status))

        elif subcommand == "install" or subcommand == "setup":
            # Automatic full setup
            display.show_info("\n🚀 Automatic Local LLM Setup")
            display.show_info("=" * 40)
            display.show_info("This will:")
            display.show_info("  1. Install Ollama (if needed)")
            display.show_info("  2. Start the server")
            display.show_info("  3. Download a recommended model")
            display.show_info("")

            def progress_cb(prog):
                if prog.is_error:
                    display.show_error(f"[{prog.step}] {prog.message}")
                else:
                    display.show_info(f"[{prog.step}] {prog.message}")

            success, message = await full_setup(progress_callback=progress_cb)
            if success:
                display.show_info(f"\n✓ {message}")
                # Auto-switch to ollama
                await self._switch_provider("ollama")
            else:
                display.show_error(f"\n✗ {message}")

        elif subcommand.startswith("install ") or subcommand.startswith("pull "):
            # Install specific model
            model = subcommand.split(maxsplit=1)[1].strip()
            display.show_info(f"Downloading model: {model}")

            def progress_cb(prog):
                if prog.is_error:
                    display.show_error(prog.message)
                else:
                    display.show_info(prog.message)

            if await download_model(model, progress_cb):
                display.show_info(f"✓ Model {model} ready")
            else:
                display.show_error(f"✗ Failed to download {model}")

        elif subcommand == "models":
            # List available models
            display.show_thinking("Fetching local models...")
            models = await list_local_models()
            display.stop_thinking()

            if models:
                display.show_info("\nDownloaded Models:")
                for m in models:
                    marker = " ← active" if self.profile.model == m else ""
                    display.show_info(f"  • {m}{marker}")
            else:
                display.show_info("No models downloaded. Use '/local install' to set up.")

            display.show_info("\nRecommended models:")
            for category, model_list in list(RECOMMENDED_MODELS.items())[:2]:
                display.show_info(f"  {category}:")
                for model_name, desc in model_list[:2]:
                    display.show_info(f"    • {model_name} - {desc}")

        elif subcommand == "start":
            display.show_thinking("Starting Ollama server...")
            if await start_ollama_server():
                display.stop_thinking()
                display.show_info("✓ Ollama server started")
            else:
                display.stop_thinking()
                display.show_error("✗ Failed to start server")

        elif subcommand == "scan" or subcommand == "":
            display.show_thinking("Scanning for local LLM servers...")
            statuses = await scan_local_providers()
            display.stop_thinking()
            display.show_info(format_local_status(statuses))

            # Offer to switch if a local provider is running
            running = [s for s in statuses if s.is_running]
            if running and self.profile.provider not in [s.provider_id for s in running]:
                display.show_info(f"\nTo use a local provider: /provider {running[0].provider_id}")
            elif not running:
                display.show_info("\nNo local servers running. Use '/local install' for automatic setup.")

        elif subcommand.startswith("use "):
            # /local use ollama -> shortcut for /provider ollama
            provider = subcommand[4:].strip()
            await self._switch_provider(provider)

        else:
            display.show_info("""
/local Commands:

  Setup & Install:
    /local install      Automatic setup (installs Ollama + downloads model)
    /local install <model>  Install a specific model
    /local start        Start the Ollama server

  Status & Info:
    /local              Scan for running local LLM servers
    /local status       Show detailed local LLM status
    /local models       List downloaded models
    /local guide        Show manual setup guide

  Usage:
    /local use <name>   Switch to a local provider (e.g., /local use ollama)

  Supported Local Providers:
    ollama     - Easy-to-use local LLM runner (recommended)
    lmstudio   - GUI-based local model serving
    vllm       - High-throughput production serving
    llamacpp   - Lightweight llama.cpp server
    custom     - Any OpenAI-compatible endpoint

  Example:
    /local install           # Automatic setup
    /local install llama3.1:8b  # Download specific model
    /local use ollama        # Switch to local
""")

    def show_help(self) -> None:
        """Show help message with available commands."""
        help_text = """
Available Commands:

  /help, /h, /?       Show this help message
  /exit, /quit, /q    Exit the shell
  /clear, /cls        Clear the screen

Model Commands:
  /model              Show available models
  /model <name>       Switch to a different model
  /model <number>     Switch by number from list
  /model save         Save current model as default
  /model clear        Clear your default model

Provider Commands:
  /provider <name>    Switch to a different provider (e.g., /provider xai)
  /providers          Show all configured AI providers

Local/Air-Gapped:
  /local              Scan for local LLM servers (Ollama, LM Studio, etc.)
  /local setup        Show setup guide for local providers
  /local use <name>   Switch to a local provider

Session Commands:
  /save [title]       Save the current conversation
  /session <id>       Load a saved session id

Plugin Commands:
  /plugins            Show available and loaded plugins
  /metrics, /stats    Show Alpha Zero 2 performance metrics
  /suggestions        Show improvement suggestions

Keyboard Shortcuts:
  Ctrl+C              Stop AI / clear input / quit (double-tap)
  Ctrl+D              Exit immediately
  Up/Down arrows      Navigate command history

Usage:
  - Type your message and press Enter to send
  - Ctrl+C while AI is working stops the request
  - Ctrl+C on empty prompt shows quit hint
  - Ctrl+C twice quickly exits the shell
"""
        display.show_info(help_text)


async def launch_interactive_shell(
    working_dir: Optional[str] = None,
    profile: str = "default",
    provider: Optional[str] = None,
    model: Optional[str] = None,
    session_id: Optional[str] = None,
    session_title: Optional[str] = None,
    autosave: bool = False,
    enable_alpha_zero: bool = True,
    enabled_plugins: Optional[list] = None,
) -> None:
    """Launch interactive shell."""
    work_dir = working_dir or str(Path.cwd())

    # Enable alpha_zero if in plugins list
    az_enabled = enable_alpha_zero or (enabled_plugins and "alpha_zero" in enabled_plugins)

    shell = InteractiveShell(
        working_dir=work_dir,
        profile_name=profile,
        provider_override=provider,
        model_override=model,
        session_id=session_id,
        session_title=session_title,
        autosave=autosave,
        enable_alpha_zero=az_enabled,
        enabled_plugins=enabled_plugins,
    )

    try:
        await shell.start()
    except Exception as error:
        display.show_error(f"Shell error: {error}")
        raise
