"""
ContextManager - Manages conversation context to prevent token limit leaks

Responsibilities:
- Truncate tool outputs intelligently
- Prune old conversation history
- Track and estimate token usage
- Keep conversation within budget
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Literal, Optional

from .types import ConversationMessage, SystemMessage


# Type alias for summarization callback
SummarizationCallback = Callable[[list[ConversationMessage]], Awaitable[str]]


@dataclass
class ContextManagerConfig:
    """Configuration for context manager."""

    max_tokens: int = 130000  # Maximum tokens allowed in conversation
    target_tokens: int = 100000  # Target to stay under (allows headroom)
    max_tool_output_length: int = 10000  # Max characters for tool outputs
    preserve_recent_messages: int = 10  # Number of recent exchanges to always keep
    estimated_chars_per_token: int = 4  # Rough estimation (usually ~4 for English)
    use_llm_summarization: bool = True  # Whether to use LLM-based summarization
    summarization_callback: Optional[SummarizationCallback] = None  # Optional LLM summarization callback


@dataclass
class TruncationResult:
    """Result from truncating content."""

    content: str
    was_truncated: bool
    original_length: int
    truncated_length: int


@dataclass
class PruneResult:
    """Result from pruning messages."""

    pruned: list[ConversationMessage]
    removed: int
    summarized: bool = False


@dataclass
class ContextStats:
    """Statistics about context usage."""

    total_tokens: int
    percentage: int
    is_over_limit: bool
    is_approaching_limit: bool


class ContextManager:
    """Manages conversation context to prevent token limit issues."""

    def __init__(self, config: Optional[ContextManagerConfig] = None):
        """Initialize context manager with optional configuration."""
        if config is None:
            config = ContextManagerConfig()
        self.config = config

    def truncate_tool_output(self, output: str, tool_name: str) -> TruncationResult:
        """
        Truncate tool output intelligently based on tool type.

        Args:
            output: Tool output content
            tool_name: Name of the tool that produced the output

        Returns:
            TruncationResult with truncated content and metadata
        """
        original_length = len(output)

        if original_length <= self.config.max_tool_output_length:
            return TruncationResult(
                content=output,
                was_truncated=False,
                original_length=original_length,
                truncated_length=original_length,
            )

        # Intelligent truncation based on tool type
        truncated = self._intelligent_truncate(output, tool_name)
        truncated_length = len(truncated)

        return TruncationResult(
            content=truncated,
            was_truncated=True,
            original_length=original_length,
            truncated_length=truncated_length,
        )

    def _intelligent_truncate(self, output: str, tool_name: str) -> str:
        """Apply intelligent truncation based on tool type."""
        max_length = self.config.max_tool_output_length

        # For file reads, show beginning and end
        if tool_name in ("Read", "read_file"):
            return self._truncate_file_output(output, max_length)

        # For search results, keep first N results
        if tool_name in ("Grep", "grep_search", "Glob"):
            return self._truncate_search_output(output, max_length)

        # For bash/command output, keep end (usually most relevant)
        if tool_name in ("Bash", "bash", "execute_bash"):
            return self._truncate_bash_output(output, max_length)

        # Default: show beginning with truncation notice
        return self._truncate_default(output, max_length)

    def _truncate_file_output(self, output: str, max_length: int) -> str:
        """Truncate file output showing beginning and end."""
        lines = output.split("\n")
        if len(lines) <= 100:
            # For small files, just truncate text
            return self._truncate_default(output, max_length)

        # Show first N and last N lines
        keep_lines = math.floor(max_length / 100)  # Rough estimate
        head_lines = lines[:keep_lines]
        tail_lines = lines[-keep_lines:]

        truncated_count = len(lines) - (keep_lines * 2)

        return "\n".join(
            [
                *head_lines,
                f"\n... [{truncated_count} lines truncated for context management] ...\n",
                *tail_lines,
            ]
        )

    def _truncate_search_output(self, output: str, max_length: int) -> str:
        """Truncate search output keeping first N results."""
        lines = output.split("\n")
        keep_lines = math.floor(max_length / 80)  # Rough average line length

        if len(lines) <= keep_lines:
            return output

        truncated_count = len(lines) - keep_lines
        return "\n".join(
            [
                *lines[:keep_lines],
                f"\n... [{truncated_count} more results truncated for context management] ...",
            ]
        )

    def _truncate_bash_output(self, output: str, max_length: int) -> str:
        """Truncate bash output keeping mostly the end (errors, final status)."""
        if len(output) <= max_length:
            return output

        # For command output, the end is usually most important
        keep_chars = math.floor(max_length * 0.8)  # 80% at end
        prefix_chars = max_length - keep_chars - 100  # Small prefix

        prefix = output[:prefix_chars]
        suffix = output[-keep_chars:]
        truncated_chars = len(output) - prefix_chars - keep_chars

        return f"{prefix}\n\n... [{truncated_chars} characters truncated for context management] ...\n\n{suffix}"

    def _truncate_default(self, output: str, max_length: int) -> str:
        """Default truncation strategy."""
        if len(output) <= max_length:
            return output

        truncated_chars = len(output) - max_length + 100  # Account for notice
        return f"{output[:max_length - 100]}\n\n... [{truncated_chars} characters truncated for context management] ..."

    def estimate_tokens(self, message: ConversationMessage) -> int:
        """
        Estimate tokens in a message.

        Args:
            message: Message to estimate

        Returns:
            Estimated token count
        """
        char_count = 0

        if hasattr(message, "content") and message.content:
            char_count += len(message.content)

        if message.role == "assistant" and hasattr(message, "tool_calls") and message.tool_calls:
            # Tool calls add overhead
            for call in message.tool_calls:
                char_count += len(call.name)
                char_count += len(json.dumps(call.arguments))

        return math.ceil(char_count / self.config.estimated_chars_per_token)

    def estimate_total_tokens(self, messages: list[ConversationMessage]) -> int:
        """
        Estimate total tokens in conversation.

        Args:
            messages: List of messages

        Returns:
            Total estimated token count
        """
        return sum(self.estimate_tokens(msg) for msg in messages)

    def prune_messages(self, messages: list[ConversationMessage]) -> PruneResult:
        """
        Prune old messages when approaching limit.

        Synchronously removes old messages to stay within budget.

        Args:
            messages: Conversation messages

        Returns:
            PruneResult with pruned messages and removal count
        """
        total_tokens = self.estimate_total_tokens(messages)

        # Only prune if we're above target
        if total_tokens < self.config.target_tokens:
            return PruneResult(pruned=messages, removed=0, summarized=False)

        # Always keep system message (first)
        first_message = messages[0] if messages else None
        system_message = first_message if first_message and first_message.role == "system" else None
        conversation_messages = messages[1:] if system_message else messages

        # Keep recent messages based on preserve_recent_messages
        # Count user/assistant pairs
        recent_messages: list[ConversationMessage] = []
        exchange_count = 0

        for i in range(len(conversation_messages) - 1, -1, -1):
            msg = conversation_messages[i]
            recent_messages.insert(0, msg)

            if msg.role == "user":
                exchange_count += 1
                if exchange_count >= self.config.preserve_recent_messages:
                    break

        # Build pruned message list
        pruned: list[ConversationMessage] = []
        if system_message:
            pruned.append(system_message)

        # Add a context summary message if we removed messages
        removed_count = len(conversation_messages) - len(recent_messages)
        if removed_count > 0:
            pruned.append(
                SystemMessage(
                    role="system",
                    content=f"[Context Manager: Removed {removed_count} old messages to stay within token budget. Recent conversation history preserved.]",
                )
            )

        pruned.extend(recent_messages)

        return PruneResult(pruned=pruned, removed=removed_count, summarized=False)

    async def prune_messages_with_summary(self, messages: list[ConversationMessage]) -> PruneResult:
        """
        Prune messages with LLM-based summarization.

        This is an async version that uses the LLM to create intelligent summaries
        instead of just removing old messages. Should be called BEFORE generation.

        Args:
            messages: Conversation messages

        Returns:
            PruneResult with pruned messages, removal count, and summarization status
        """
        total_tokens = self.estimate_total_tokens(messages)

        # Only prune if we're above target
        if total_tokens < self.config.target_tokens:
            return PruneResult(pruned=messages, removed=0, summarized=False)

        # If no summarization callback or disabled, fall back to simple pruning
        if not self.config.summarization_callback or not self.config.use_llm_summarization:
            result = self.prune_messages(messages)
            return result

        # Partition messages
        first_message = messages[0] if messages else None
        system_message = first_message if first_message and first_message.role == "system" else None
        conversation_messages = messages[1:] if system_message else messages

        # Keep recent messages
        recent_messages: list[ConversationMessage] = []
        exchange_count = 0

        for i in range(len(conversation_messages) - 1, -1, -1):
            msg = conversation_messages[i]
            recent_messages.insert(0, msg)

            if msg.role == "user":
                exchange_count += 1
                if exchange_count >= self.config.preserve_recent_messages:
                    break

        to_summarize = conversation_messages[: len(conversation_messages) - len(recent_messages)]

        # If nothing to summarize, return as-is
        if not to_summarize:
            return PruneResult(pruned=messages, removed=0, summarized=False)

        try:
            # Call the LLM to summarize old messages
            summary = await self.config.summarization_callback(to_summarize)

            # Build pruned message list with summary
            pruned: list[ConversationMessage] = []
            if system_message:
                pruned.append(system_message)

            # Add intelligent summary
            summary_content = "\n".join(
                [
                    "=== Context Summary (Auto-generated) ===",
                    summary.strip(),
                    "",
                    f"[Summarized {len(to_summarize)} earlier messages. Recent {len(recent_messages)} messages preserved below.]",
                ]
            )
            pruned.append(SystemMessage(role="system", content=summary_content))

            pruned.extend(recent_messages)

            return PruneResult(pruned=pruned, removed=len(to_summarize), summarized=True)
        except Exception:
            # If summarization fails, fall back to simple pruning
            result = self.prune_messages(messages)
            return result

    def is_approaching_limit(self, messages: list[ConversationMessage]) -> bool:
        """
        Check if we're approaching the limit.

        Args:
            messages: Conversation messages

        Returns:
            True if approaching limit
        """
        total_tokens = self.estimate_total_tokens(messages)
        return total_tokens >= self.config.target_tokens

    def get_warning_level(self, messages: list[ConversationMessage]) -> Optional[Literal["info", "warning", "danger"]]:
        """
        Get warning level for current context usage.

        Args:
            messages: Conversation messages

        Returns:
            Warning level: 'info' (<70%), 'warning' (70-90%), 'danger' (>90%), or None
        """
        total_tokens = self.estimate_total_tokens(messages)
        percentage = (total_tokens / self.config.max_tokens) * 100

        if percentage > 90:
            return "danger"
        elif percentage > 70:
            return "warning"
        elif percentage > 50:
            return "info"

        return None

    def get_warning_message(self, messages: list[ConversationMessage]) -> Optional[str]:
        """
        Get a human-readable warning message.

        Args:
            messages: Conversation messages

        Returns:
            Warning message if applicable
        """
        stats = self.get_stats(messages)
        warning_level = self.get_warning_level(messages)

        if warning_level == "danger":
            return f"⚠️ Context usage critical ({stats.percentage}%). Consider starting a new session or the next request may fail."
        elif warning_level == "warning":
            return f"Context usage high ({stats.percentage}%). Automatic cleanup will occur soon."

        return None

    def get_stats(self, messages: list[ConversationMessage]) -> ContextStats:
        """
        Get context statistics.

        Args:
            messages: Conversation messages

        Returns:
            ContextStats with usage information
        """
        total_tokens = self.estimate_total_tokens(messages)
        percentage = round((total_tokens / self.config.max_tokens) * 100)

        return ContextStats(
            total_tokens=total_tokens,
            percentage=percentage,
            is_over_limit=total_tokens >= self.config.max_tokens,
            is_approaching_limit=total_tokens >= self.config.target_tokens,
        )

    def update_config(self, **kwargs) -> None:
        """
        Update configuration.

        Args:
            **kwargs: Configuration parameters to update
        """
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)


def create_default_context_manager(
    summarization_callback: Optional[SummarizationCallback] = None,
) -> ContextManager:
    """
    Create a default context manager instance.

    Args:
        summarization_callback: Optional callback for LLM summarization

    Returns:
        ContextManager instance with default configuration
    """
    config = ContextManagerConfig(
        max_tokens=130000,  # Safe limit below 131072
        target_tokens=100000,  # Start pruning at 100k
        max_tool_output_length=3000,  # 3k chars max per tool (reduced for safety)
        preserve_recent_messages=8,  # Keep last 8 exchanges
        estimated_chars_per_token=4,  # Conservative estimate
        use_llm_summarization=True,  # Enable LLM summarization by default if callback provided
        summarization_callback=summarization_callback,
    )
    return ContextManager(config)
