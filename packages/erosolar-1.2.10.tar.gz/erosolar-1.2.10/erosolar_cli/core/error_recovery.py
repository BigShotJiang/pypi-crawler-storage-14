"""
Intelligent Error Recovery System

Automatically detects, analyzes, and fixes errors that occur during execution.
Provides retry strategies, automatic fixes, and fallback mechanisms.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional, TypeVar

T = TypeVar("T")


class ErrorCategory(Enum):
    """Categories of errors for smart recovery."""

    RATE_LIMIT = "rate_limit"
    AUTH_ERROR = "auth_error"
    INVALID_REQUEST = "invalid_request"
    MODEL_ERROR = "model_error"
    TOOL_ERROR = "tool_error"
    NETWORK_ERROR = "network_error"
    TIMEOUT = "timeout"
    QUOTA_EXCEEDED = "quota_exceeded"
    CONTEXT_LENGTH = "context_length"
    SCHEMA_ERROR = "schema_error"
    UNKNOWN = "unknown"


@dataclass
class ErrorAnalysis:
    """Analysis of an error with recovery strategy."""

    category: ErrorCategory
    original_error: Exception
    error_message: str
    is_retryable: bool
    suggested_fix: Optional[str] = None
    retry_delay_seconds: float = 1.0
    max_retries: int = 3
    requires_user_action: bool = False
    alternative_providers: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class ErrorAnalyzer:
    """Analyzes errors and determines recovery strategies."""

    # Error patterns mapped to categories
    # Order matters - more specific patterns should come first
    ERROR_PATTERNS = {
        ErrorCategory.QUOTA_EXCEEDED: [
            r"quota",
            r"billing",
            r"payment",
            r"exceeded.*limit",
        ],
        ErrorCategory.RATE_LIMIT: [
            r"rate[_\s]?limit",
            r"too many requests",
            r"429",
            r"requests per",
        ],
        ErrorCategory.AUTH_ERROR: [
            r"auth",
            r"unauthorized",
            r"401",
            r"403",
            r"invalid.*api.*key",
            r"forbidden",
            r"authentication",
        ],
        ErrorCategory.INVALID_REQUEST: [
            r"invalid.*parameter",
            r"invalid.*value",
            r"400",
            r"bad request",
            r"missing.*required",
            r"invalid.*format",
        ],
        ErrorCategory.MODEL_ERROR: [
            r"model.*not.*found",
            r"model.*unavailable",
            r"unsupported.*model",
            r"invalid.*model",
        ],
        ErrorCategory.NETWORK_ERROR: [
            r"connection",
            r"network",
            r"timeout",
            r"timed out",
            r"dns",
            r"socket",
            r"unreachable",
        ],
        ErrorCategory.CONTEXT_LENGTH: [
            r"context.*length",
            r"token.*limit",
            r"maximum.*context",
            r"too.*long",
            r"exceeds.*limit",
        ],
        ErrorCategory.SCHEMA_ERROR: [
            r"schema",
            r"json.*parse",
            r"invalid.*json",
            r"serialization",
            r"validation.*failed",
        ],
    }

    @classmethod
    def analyze(cls, error: Exception) -> ErrorAnalysis:
        """
        Analyze an error and determine recovery strategy.

        Args:
            error: The exception to analyze

        Returns:
            ErrorAnalysis with recovery strategy
        """
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()

        # Detect error category
        category = cls._categorize_error(error_str, error_type)

        # Determine recovery strategy based on category
        if category == ErrorCategory.RATE_LIMIT:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=True,
                suggested_fix="Waiting for rate limit to reset, then retrying...",
                retry_delay_seconds=cls._extract_retry_delay(error_str),
                max_retries=5,
                requires_user_action=False,
            )

        elif category == ErrorCategory.AUTH_ERROR:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=False,
                suggested_fix="Check API key configuration. Set correct environment variable.",
                retry_delay_seconds=0,
                max_retries=0,
                requires_user_action=True,
                metadata={"check": "API keys in environment variables"},
            )

        elif category == ErrorCategory.INVALID_REQUEST:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=True,
                suggested_fix=cls._suggest_request_fix(error_str),
                retry_delay_seconds=0,
                max_retries=1,  # Only retry once after fixing
                requires_user_action=False,
                metadata={"auto_fix": True},
            )

        elif category == ErrorCategory.MODEL_ERROR:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=True,
                suggested_fix="Trying alternative model...",
                retry_delay_seconds=0,
                max_retries=3,
                requires_user_action=False,
                alternative_providers=cls._suggest_alternative_models(error_str),
            )

        elif category == ErrorCategory.NETWORK_ERROR:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=True,
                suggested_fix="Network error detected. Retrying with exponential backoff...",
                retry_delay_seconds=2.0,
                max_retries=4,
                requires_user_action=False,
            )

        elif category == ErrorCategory.CONTEXT_LENGTH:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=True,
                suggested_fix="Context too long. Automatically pruning conversation history...",
                retry_delay_seconds=0,
                max_retries=1,
                requires_user_action=False,
                metadata={"action": "prune_context"},
            )

        elif category == ErrorCategory.SCHEMA_ERROR:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=True,
                suggested_fix="Schema validation failed. Attempting to fix tool definitions...",
                retry_delay_seconds=0,
                max_retries=2,
                requires_user_action=False,
                metadata={"action": "fix_schema"},
            )

        elif category == ErrorCategory.QUOTA_EXCEEDED:
            return ErrorAnalysis(
                category=category,
                original_error=error,
                error_message=str(error),
                is_retryable=False,
                suggested_fix="Quota exceeded. Check billing or try alternative provider.",
                retry_delay_seconds=0,
                max_retries=0,
                requires_user_action=True,
                alternative_providers=["anthropic", "google", "deepseek"],
            )

        else:
            # Unknown error - attempt retry with caution
            return ErrorAnalysis(
                category=ErrorCategory.UNKNOWN,
                original_error=error,
                error_message=str(error),
                is_retryable=True,
                suggested_fix="Unknown error. Attempting retry...",
                retry_delay_seconds=1.0,
                max_retries=2,
                requires_user_action=False,
            )

    @classmethod
    def _categorize_error(cls, error_str: str, error_type: str) -> ErrorCategory:
        """Categorize error based on message and type."""
        # Check patterns in defined order (more specific first)
        categories_to_check = [
            ErrorCategory.QUOTA_EXCEEDED,  # Check quota before rate_limit
            ErrorCategory.AUTH_ERROR,
            ErrorCategory.CONTEXT_LENGTH,
            ErrorCategory.SCHEMA_ERROR,
            ErrorCategory.MODEL_ERROR,
            ErrorCategory.INVALID_REQUEST,
            ErrorCategory.RATE_LIMIT,
            ErrorCategory.NETWORK_ERROR,
        ]

        for category in categories_to_check:
            if category not in cls.ERROR_PATTERNS:
                continue
            patterns = cls.ERROR_PATTERNS[category]
            for pattern in patterns:
                if re.search(pattern, error_str, re.IGNORECASE) or re.search(
                    pattern, error_type, re.IGNORECASE
                ):
                    return category

        return ErrorCategory.UNKNOWN

    @classmethod
    def _extract_retry_delay(cls, error_str: str) -> float:
        """Extract retry delay from error message."""
        # Try to find retry-after or wait time in error message
        match = re.search(r"retry[_\s]?after[:\s]+(\d+)", error_str, re.IGNORECASE)
        if match:
            return float(match.group(1))

        match = re.search(r"wait[:\s]+(\d+)", error_str, re.IGNORECASE)
        if match:
            return float(match.group(1))

        # Default delays based on common patterns
        if "minute" in error_str:
            return 60.0
        if "hour" in error_str:
            return 3600.0

        return 5.0  # Default 5 seconds for rate limits

    @classmethod
    def _suggest_request_fix(cls, error_str: str) -> str:
        """Suggest fix for invalid request errors."""
        if "name" in error_str and "required" in error_str:
            return "Fixing missing tool name parameter..."
        if "parameter" in error_str and "missing" in error_str:
            return "Adding default values for missing parameters..."
        if "input_text" in error_str and "output_text" in error_str:
            return "Fixing content type format for assistant messages..."
        if "additionalproperties" in error_str.lower():
            return "Removing unsupported schema fields..."

        return "Attempting to fix request format..."

    @classmethod
    def _suggest_alternative_models(cls, error_str: str) -> list[str]:
        """Suggest alternative models based on error."""
        # Map providers to alternatives
        alternatives_map = {
            "openai": ["anthropic", "google", "deepseek"],
            "anthropic": ["openai", "google"],
            "google": ["openai", "anthropic"],
            "deepseek": ["openai", "anthropic"],
        }

        for provider, alternatives in alternatives_map.items():
            if provider in error_str:
                return alternatives

        return ["anthropic", "openai", "google"]


class ErrorRecoveryManager:
    """Manages error recovery with automatic retries and fixes."""

    def __init__(
        self,
        enable_auto_recovery: bool = True,
        max_recovery_attempts: int = 3,
        enable_provider_fallback: bool = True,
    ):
        """
        Initialize error recovery manager.

        Args:
            enable_auto_recovery: Enable automatic error recovery
            max_recovery_attempts: Maximum number of recovery attempts
            enable_provider_fallback: Enable fallback to alternative providers
        """
        self.enable_auto_recovery = enable_auto_recovery
        self.max_recovery_attempts = max_recovery_attempts
        self.enable_provider_fallback = enable_provider_fallback
        self.recovery_history: list[ErrorAnalysis] = []

    async def execute_with_recovery(
        self,
        operation: Callable[..., T],
        *args: Any,
        on_error: Optional[Callable[[ErrorAnalysis], None]] = None,
        **kwargs: Any,
    ) -> T:
        """
        Execute operation with automatic error recovery.

        Args:
            operation: Async function to execute
            *args: Positional arguments for operation
            on_error: Optional callback when error occurs
            **kwargs: Keyword arguments for operation

        Returns:
            Result of operation

        Raises:
            Exception if recovery fails
        """
        if not self.enable_auto_recovery:
            return await operation(*args, **kwargs)

        last_error: Optional[Exception] = None
        attempt = 0

        while attempt < self.max_recovery_attempts:
            try:
                return await operation(*args, **kwargs)

            except Exception as error:
                attempt += 1
                last_error = error

                # Analyze error
                analysis = ErrorAnalyzer.analyze(error)
                self.recovery_history.append(analysis)

                # Notify callback
                if on_error:
                    on_error(analysis)

                # Check if recoverable
                if not analysis.is_retryable or attempt >= analysis.max_retries:
                    raise

                # Apply automatic fix if available
                if analysis.metadata.get("auto_fix"):
                    await self._apply_automatic_fix(analysis, args, kwargs)

                # Wait before retry
                if analysis.retry_delay_seconds > 0:
                    # Exponential backoff
                    delay = analysis.retry_delay_seconds * (2 ** (attempt - 1))
                    await asyncio.sleep(min(delay, 60.0))  # Cap at 60 seconds

        # All retries exhausted
        if last_error:
            raise last_error
        raise RuntimeError("Recovery failed without exception")

    async def _apply_automatic_fix(
        self, analysis: ErrorAnalysis, args: tuple, kwargs: dict
    ) -> None:
        """Apply automatic fixes based on error analysis."""
        action = analysis.metadata.get("action")

        if action == "fix_schema":
            # Fix tool schema issues
            if "tools" in kwargs:
                kwargs["tools"] = self._fix_tool_definitions(kwargs["tools"])

        elif action == "prune_context":
            # Prune conversation context
            if "messages" in kwargs:
                kwargs["messages"] = self._prune_messages(kwargs["messages"])

    def _fix_tool_definitions(self, tools: list[Any]) -> list[Any]:
        """Fix tool definitions to prevent validation errors."""
        fixed_tools = []

        for tool in tools:
            # Ensure tool has name
            if hasattr(tool, "name") and not tool.name:
                if hasattr(tool, "function") and hasattr(tool.function, "name"):
                    tool.name = tool.function.name
                else:
                    tool.name = "tool"

            # Ensure tool has description
            if hasattr(tool, "description") and not tool.description:
                if hasattr(tool, "function") and hasattr(tool.function, "description"):
                    tool.description = tool.function.description
                else:
                    tool.description = ""

            # Remove additionalProperties if present
            if hasattr(tool, "parameters") and hasattr(tool.parameters, "additionalProperties"):
                delattr(tool.parameters, "additionalProperties")

            fixed_tools.append(tool)

        return fixed_tools

    def _prune_messages(self, messages: list[Any], target_reduction: float = 0.3) -> list[Any]:
        """Prune messages to reduce context length."""
        if len(messages) <= 2:
            return messages

        # Keep system message and last few messages
        system_messages = [m for m in messages if hasattr(m, "role") and m.role == "system"]
        other_messages = [m for m in messages if not (hasattr(m, "role") and m.role == "system")]

        # Keep last N messages based on target reduction
        keep_count = max(1, int(len(other_messages) * (1 - target_reduction)))
        pruned_messages = system_messages + other_messages[-keep_count:]

        return pruned_messages

    def get_recovery_stats(self) -> dict[str, Any]:
        """Get statistics about error recovery."""
        if not self.recovery_history:
            return {"total_errors": 0, "by_category": {}}

        category_counts: dict[str, int] = {}
        retryable_count = 0
        fixed_count = 0

        for analysis in self.recovery_history:
            category_name = analysis.category.value
            category_counts[category_name] = category_counts.get(category_name, 0) + 1

            if analysis.is_retryable:
                retryable_count += 1
            if analysis.metadata.get("auto_fix"):
                fixed_count += 1

        return {
            "total_errors": len(self.recovery_history),
            "by_category": category_counts,
            "retryable": retryable_count,
            "auto_fixed": fixed_count,
            "recovery_rate": fixed_count / len(self.recovery_history) if self.recovery_history else 0,
        }


# Global error recovery manager instance
_global_recovery_manager: Optional[ErrorRecoveryManager] = None


def get_error_recovery_manager() -> ErrorRecoveryManager:
    """Get global error recovery manager instance."""
    global _global_recovery_manager
    if _global_recovery_manager is None:
        _global_recovery_manager = ErrorRecoveryManager()
    return _global_recovery_manager


def set_error_recovery_manager(manager: ErrorRecoveryManager) -> None:
    """Set global error recovery manager instance."""
    global _global_recovery_manager
    _global_recovery_manager = manager
