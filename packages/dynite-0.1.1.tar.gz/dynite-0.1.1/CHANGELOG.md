## v0.1.1 - 2025-11-25
- Fix: add a `py.typed` file


## v0.1.0 - 2025-11-14
Initial release
