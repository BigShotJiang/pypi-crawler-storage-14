"""Django Issue Capture - AI-powered GitHub issue creation and management."""

__version__ = "0.2.0"

default_app_config = "django_issue_capture.apps.IssueCaptureConfig"
