# Release

Execute the release process for this package.

1. Read RELEASING.md in this repository
2. Follow each step in order
3. Before starting, show the current version and ask for the new version number
4. If any step fails, STOP and report the error
5. Do not proceed to the next step until the current step succeeds
