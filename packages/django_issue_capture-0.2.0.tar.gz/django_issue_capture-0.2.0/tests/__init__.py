# Tests for django-issue-capture
