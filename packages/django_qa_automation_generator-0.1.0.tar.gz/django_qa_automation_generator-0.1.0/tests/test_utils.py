"""
Tests for utility functions.
"""
import unittest
from qa_automation_generator.utils import (
    sanitize_filename,
    camel_to_snake,
    snake_to_camel,
    extract_url_parameters,
)


class TestUtils(unittest.TestCase):
    """Test utility functions."""

    def test_sanitize_filename(self):
        """Test filename sanitization."""
        self.assertEqual(sanitize_filename("My View"), "my_view")
        self.assertEqual(sanitize_filename("Test/View"), "test_view")
        self.assertEqual(sanitize_filename("Test:View"), "test_view")
        self.assertEqual(sanitize_filename("Test__View"), "test_view")

    def test_camel_to_snake(self):
        """Test CamelCase to snake_case conversion."""
        self.assertEqual(camel_to_snake("MyView"), "my_view")
        self.assertEqual(camel_to_snake("PostListView"), "post_list_view")
        self.assertEqual(camel_to_snake("HTTPResponse"), "http_response")

    def test_snake_to_camel(self):
        """Test snake_case to CamelCase conversion."""
        self.assertEqual(snake_to_camel("my_view"), "MyView")
        self.assertEqual(snake_to_camel("post_list_view"), "PostListView")
        self.assertEqual(
            snake_to_camel("my_view", capitalize_first=False), "myView"
        )

    def test_extract_url_parameters(self):
        """Test URL parameter extraction."""
        params = extract_url_parameters("/post/<int:id>/")
        self.assertEqual(params, ["id"])

        params = extract_url_parameters("/post/<slug:slug>/comment/<int:comment_id>/")
        self.assertEqual(params, ["slug", "comment_id"])

        params = extract_url_parameters("/static/path/")
        self.assertEqual(params, [])


if __name__ == "__main__":
    unittest.main()
