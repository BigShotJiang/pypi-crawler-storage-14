"""
Tests for URL analyzer.
"""
import unittest
from unittest.mock import Mock, patch
from qa_automation_generator.analyzers.url_analyzer import URLAnalyzer, URLInfo


class TestURLAnalyzer(unittest.TestCase):
    """Test URL analyzer functionality."""

    def test_url_info_creation(self):
        """Test URLInfo object creation."""
        mock_view = Mock()
        mock_view.__name__ = "test_view"

        url_info = URLInfo(
            pattern="/test/",
            name="test",
            view_func=mock_view,
            app_name="testapp",
        )

        self.assertEqual(url_info.pattern, "/test/")
        self.assertEqual(url_info.name, "test")
        self.assertEqual(url_info.app_name, "testapp")
        self.assertEqual(url_info.view_name, "test_view")

    def test_url_info_with_parameters(self):
        """Test URLInfo with URL parameters."""
        mock_view = Mock()
        mock_view.__name__ = "detail_view"

        url_info = URLInfo(
            pattern="/post/<int:id>/",
            name="post_detail",
            view_func=mock_view,
            app_name="blog",
        )

        self.assertEqual(len(url_info.parameters), 1)
        self.assertIn("id", url_info.parameters)

    def test_url_info_to_dict(self):
        """Test URLInfo to_dict method."""
        mock_view = Mock()
        mock_view.__name__ = "test_view"

        url_info = URLInfo(
            pattern="/test/",
            name="test",
            view_func=mock_view,
            app_name="testapp",
        )

        result = url_info.to_dict()

        self.assertIsInstance(result, dict)
        self.assertEqual(result["pattern"], "/test/")
        self.assertEqual(result["name"], "test")
        self.assertEqual(result["view_name"], "test_view")


if __name__ == "__main__":
    unittest.main()
