# Example Django Project

This directory contains an example Django project to demonstrate the QA Automation Code Generator.

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install django
pip install -e ..  # Install the qa_automation_generator package
```

3. Run migrations:
```bash
cd example_project
python manage.py migrate
```

4. Create a superuser (optional):
```bash
python manage.py createsuperuser
```

5. Run the development server:
```bash
python manage.py runserver
```

## Generate Tests

Generate tests for all views:
```bash
python manage.py generate_qa_tests
```

Generate tests for the blog app:
```bash
python manage.py generate_qa_tests --app blog
```

Generate Playwright tests:
```bash
python manage.py generate_qa_tests --framework playwright
```

## Run Generated Tests

1. Install test dependencies:
```bash
# For Selenium
pip install selenium pytest pytest-django

# For Playwright
pip install playwright pytest pytest-django
playwright install
```

2. Run tests:
```bash
pytest generated_tests/
```

## Project Structure

```
example_project/
├── blog/                    # Example blog app
│   ├── models.py           # Post model
│   ├── views.py            # Blog views
│   ├── urls.py             # URL configuration
│   └── templates/          # Templates
├── example_project/        # Project settings
│   ├── settings.py
│   └── urls.py
└── manage.py
```
