"""
Example blog views.
"""
from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView
from django.urls import reverse_lazy
from .models import Post, Comment
from .forms import CommentForm


class PostListView(ListView):
    """List all published posts."""

    model = Post
    template_name = "blog/post_list.html"
    context_object_name = "posts"
    paginate_by = 10

    def get_queryset(self):
        return Post.objects.filter(published=True)


class PostDetailView(DetailView):
    """Display a single post with comments."""

    model = Post
    template_name = "blog/post_detail.html"
    context_object_name = "post"
    slug_field = "slug"
    slug_url_kwarg = "slug"

    def get_queryset(self):
        return Post.objects.filter(published=True)


class CommentCreateView(CreateView):
    """Create a new comment on a post."""

    model = Comment
    form_class = CommentForm
    template_name = "blog/comment_form.html"

    def form_valid(self, form):
        form.instance.post = get_object_or_404(Post, slug=self.kwargs["slug"])
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy("post_detail", kwargs={"slug": self.kwargs["slug"]})


def about_view(request):
    """About page."""
    return render(request, "blog/about.html")


def contact_view(request):
    """Contact page with form."""
    if request.method == "POST":
        # Process contact form
        name = request.POST.get("name")
        email = request.POST.get("email")
        message = request.POST.get("message")
        # In a real app, you'd send an email or save to database
        return redirect("contact_success")

    return render(request, "blog/contact.html")


def contact_success_view(request):
    """Contact form success page."""
    return render(request, "blog/contact_success.html")
