"""
Example blog forms.
"""
from django import forms
from .models import Comment


class CommentForm(forms.ModelForm):
    """Form for creating comments."""

    class Meta:
        model = Comment
        fields = ["author_name", "author_email", "content"]
        widgets = {
            "author_name": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "Your name"}
            ),
            "author_email": forms.EmailInput(
                attrs={"class": "form-control", "placeholder": "Your email"}
            ),
            "content": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "placeholder": "Your comment",
                    "rows": 4,
                }
            ),
        }
