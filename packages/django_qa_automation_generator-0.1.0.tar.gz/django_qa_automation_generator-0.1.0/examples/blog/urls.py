"""
Example blog URL configuration.
"""
from django.urls import path
from . import views

urlpatterns = [
    path("", views.PostListView.as_view(), name="post_list"),
    path("post/<slug:slug>/", views.PostDetailView.as_view(), name="post_detail"),
    path(
        "post/<slug:slug>/comment/",
        views.CommentCreateView.as_view(),
        name="add_comment",
    ),
    path("about/", views.about_view, name="about"),
    path("contact/", views.contact_view, name="contact"),
    path("contact/success/", views.contact_success_view, name="contact_success"),
]
