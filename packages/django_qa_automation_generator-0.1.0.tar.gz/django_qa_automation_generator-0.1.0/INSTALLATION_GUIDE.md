# Complete Installation and Usage Guide

## Table of Contents
1. [Installation](#installation)
2. [Configuration](#configuration)
3. [Usage Examples](#usage-examples)
4. [Generated Code Structure](#generated-code-structure)
5. [Advanced Features](#advanced-features)
6. [Troubleshooting](#troubleshooting)

## Installation

### Step 1: Install the Package

#### From PyPI (when published)
```bash
pip install django-qa-automation-generator
```

#### From Source (for development)
```bash
git clone https://github.com/yourusername/django-qa-automation-generator.git
cd django-qa-automation-generator
pip install -e .
```

### Step 2: Add to Django Project

Edit your Django project's `settings.py`:

```python
INSTALLED_APPS = [
    # ... your other apps
    'qa_automation_generator',
]
```

### Step 3: Install Test Framework

Choose either Selenium or Playwright:

#### For Selenium
```bash
pip install selenium pytest pytest-django
```

#### For Playwright
```bash
pip install playwright pytest pytest-django
playwright install  # Install browser binaries
```

## Configuration

### Basic Configuration

Add these settings to your `settings.py`:

```python
# Optional: Default framework (default: 'selenium')
QA_AUTOMATION_FRAMEWORK = 'selenium'  # or 'playwright'

# Optional: Output directory (default: 'generated_tests')
QA_AUTOMATION_OUTPUT_DIR = 'automation_tests'

# Optional: Base URL (default: 'http://localhost:8000')
QA_AUTOMATION_BASE_URL = 'http://localhost:8000'

# Optional: Browser (default: 'chrome')
QA_AUTOMATION_BROWSER = 'chrome'  # or 'firefox', 'edge'
```

### Advanced Configuration

```python
# Test style (default: 'pytest')
QA_AUTOMATION_TEST_STYLE = 'pytest'  # or 'unittest'

# Include docstrings (default: True)
QA_AUTOMATION_INCLUDE_DOCSTRINGS = True

# Include type hints (default: True)
QA_AUTOMATION_INCLUDE_TYPE_HINTS = True

# Wait timeout in seconds (default: 10)
QA_AUTOMATION_WAIT_TIMEOUT = 10

# Use Page Object Model (default: False)
QA_AUTOMATION_USE_PAGE_OBJECTS = False

# Excluded apps (default: Django built-in apps)
QA_AUTOMATION_EXCLUDED_APPS = [
    'admin',
    'auth',
    'contenttypes',
    'sessions',
    'messages',
    'staticfiles',
]

# Excluded URL patterns (regex)
QA_AUTOMATION_EXCLUDED_URL_PATTERNS = [
    r'^/admin/',
    r'^/static/',
]

# Overwrite existing files (default: False)
QA_AUTOMATION_OVERWRITE_EXISTING = False

# Custom templates directory
QA_AUTOMATION_TEMPLATES_DIR = None  # or 'path/to/templates'
```

## Usage Examples

### Example 1: Generate All Tests

Generate tests for all views in your project:

```bash
python manage.py generate_qa_tests
```

Output:
```
Generating selenium test code...
Discovering URL patterns...
Found 15 URL pattern(s)
Generating base test files...
  Created: generated_tests/__init__.py
  Created: generated_tests/base_test.py
  Created: generated_tests/conftest.py

Generating tests for app: blog
  Created: generated_tests/blog/test_blog.py

Generating tests for app: shop
  Created: generated_tests/shop/test_shop.py

✓ Successfully generated 2 test file(s) for 15 view(s)
```

### Example 2: Generate Tests for Specific App

```bash
python manage.py generate_qa_tests --app blog
```

### Example 3: Generate Tests for Specific View

```bash
python manage.py generate_qa_tests --view blog.views.PostListView
```

### Example 4: Generate Playwright Tests

```bash
python manage.py generate_qa_tests --framework playwright
```

### Example 5: Filter by URL Pattern

```bash
python manage.py generate_qa_tests --url-pattern /api/
```

### Example 6: Custom Output Directory

```bash
python manage.py generate_qa_tests --output custom_tests/
```

### Example 7: Overwrite Existing Files

```bash
python manage.py generate_qa_tests --overwrite
```

### Example 8: Combine Multiple Options

```bash
python manage.py generate_qa_tests \
    --app blog \
    --framework playwright \
    --output playwright_tests/ \
    --overwrite
```

## Generated Code Structure

After running the command, your project will have:

```
your_project/
├── manage.py
├── your_app/
│   ├── models.py
│   ├── views.py
│   └── ...
└── generated_tests/              # Generated test directory
    ├── __init__.py               # Package init
    ├── base_test.py              # Base test class with utilities
    ├── conftest.py               # Pytest fixtures (if using pytest)
    └── your_app/                 # Tests organized by app
        ├── __init__.py
        └── test_your_app.py      # Generated tests
```

### Example Generated Test (Selenium)

```python
"""
Generated Selenium tests for blog.
"""
import unittest
from selenium.webdriver.common.by import By
from base_test import BaseTest


class TestPostListView(BaseTest):
    """Tests for PostListView."""

    def test_post_list_loads(self):
        """Test that the page loads successfully."""
        self.driver.get(f"{self.base_url}/blog/")
        assert self.driver.title, "Page should have a title"
        assert "Blog Posts" in self.driver.title

    def test_contact_form_submission(self):
        """Test form submission."""
        self.driver.get(f"{self.base_url}/contact/")
        
        # Fill name
        input_field = self.driver.find_element(By.ID, "id_name")
        input_field.send_keys("Test User")

        # Fill email
        input_field = self.driver.find_element(By.ID, "id_email")
        input_field.send_keys("test@example.com")

        # Fill message
        input_field = self.driver.find_element(By.ID, "id_message")
        input_field.send_keys("Test message")

        # Submit form
        submit_button = self.driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
        submit_button.click()

        # Add assertions for expected behavior
        # TODO: Verify form submission success
```

### Example Generated Test (Playwright)

```python
"""
Generated Playwright tests for blog.
"""
import re
import pytest
from playwright.sync_api import Page, expect


class TestPostListView:
    """Tests for PostListView."""

    def test_post_list_loads(self, page: Page):
        """Test that the page loads successfully."""
        page.goto("/blog/")
        expect(page).to_have_title("Blog Posts")

    def test_contact_form_submission(self, page: Page):
        """Test form submission."""
        page.goto("/contact/")
        
        # Fill name
        page.fill("#id_name", "Test User")

        # Fill email
        page.fill("#id_email", "test@example.com")

        # Fill message
        page.fill("#id_message", "Test message")

        # Submit form
        page.click("button[type='submit']")

        # Add assertions for expected behavior
        # TODO: Verify form submission success
```

## Running Generated Tests

### Using Pytest

```bash
# Run all tests
pytest generated_tests/

# Run tests for specific app
pytest generated_tests/blog/

# Run with verbose output
pytest generated_tests/ -v

# Run with coverage
pytest generated_tests/ --cov=your_app
```

### Using Unittest

```bash
# Run all tests
python -m unittest discover generated_tests/

# Run specific test file
python -m unittest generated_tests.blog.test_blog
```

## Advanced Features

### Custom Hooks

Extend the generator with custom hooks:

```python
# In your Django app's apps.py or a separate file
from qa_automation_generator.hooks import register_hook

@register_hook('post_generate')
def add_custom_imports(generated_code, view_info):
    """Add custom imports to generated code."""
    custom_import = "from myapp.test_utils import CustomHelper\n"
    return custom_import + generated_code

@register_hook('pre_analyze_view')
def log_view_analysis(view_info):
    """Log view analysis."""
    print(f"Analyzing view: {view_info.view_name}")
    return view_info
```

### Custom Templates

Create custom Jinja2 templates:

1. Create a templates directory:
```bash
mkdir -p custom_templates/selenium
```

2. Create custom template (e.g., `base_test.j2`):
```jinja2
"""
Custom base test class.
"""
import unittest
from selenium import webdriver

class BaseTest(unittest.TestCase):
    # Your custom implementation
    pass
```

3. Configure in settings:
```python
QA_AUTOMATION_TEMPLATES_DIR = 'custom_templates'
```

## Troubleshooting

### Issue: No URL patterns found

**Cause**: Views not registered in URL configuration or excluded by filters

**Solution**:
- Check that views are in `urls.py`
- Verify app is not in `QA_AUTOMATION_EXCLUDED_APPS`
- Check URL pattern filters

### Issue: Template analysis fails

**Cause**: Template rendering errors or missing context

**Solution**:
- Ensure templates can render with empty context
- Check for required context variables
- The library will continue with basic analysis if template fails

### Issue: Generated tests don't run

**Cause**: Missing dependencies or incorrect configuration

**Solution**:
```bash
# Install test framework
pip install selenium pytest pytest-django
# or
pip install playwright pytest pytest-django
playwright install

# Verify base URL is correct
# Check that Django server is running
python manage.py runserver
```

### Issue: Import errors in generated tests

**Cause**: Incorrect Python path or missing base files

**Solution**:
- Ensure `generated_tests/` is in Python path
- Verify `base_test.py` and `conftest.py` were generated
- Check that `__init__.py` files exist

### Issue: Tests fail with timeout errors

**Cause**: Elements not loading in time

**Solution**:
```python
# Increase timeout in settings.py
QA_AUTOMATION_WAIT_TIMEOUT = 30  # seconds
```

## Best Practices

1. **Review Generated Tests**: Always review and customize generated tests
2. **Add Assertions**: Generated tests include TODO comments for assertions
3. **Version Control**: Commit generated tests to track changes
4. **Regenerate Regularly**: Regenerate when views change
5. **Customize Base Classes**: Extend base test classes with project-specific utilities
6. **Use Page Objects**: For complex applications, consider Page Object Model

## Next Steps

1. Generate tests for your project
2. Review and customize the generated code
3. Add specific assertions for your business logic
4. Integrate into CI/CD pipeline
5. Run tests regularly

## Support

- **Documentation**: See README.md and other docs
- **Issues**: Report bugs on GitHub
- **Contributing**: See CONTRIBUTING.md

---

Happy Testing! 🚀
