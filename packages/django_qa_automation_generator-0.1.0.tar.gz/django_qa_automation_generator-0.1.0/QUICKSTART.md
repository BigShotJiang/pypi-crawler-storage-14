# Django QA Automation Code Generator

## Quick Start Guide

### Installation

1. Install the package:
```bash
pip install django-qa-automation-generator
```

2. Add to your Django project's `INSTALLED_APPS` in `settings.py`:
```python
INSTALLED_APPS = [
    # ... other apps
    'qa_automation_generator',
]
```

### Basic Usage

Generate tests for all views:
```bash
python manage.py generate_qa_tests
```

Generate tests for a specific app:
```bash
python manage.py generate_qa_tests --app myapp
```

Generate Playwright tests instead of Selenium:
```bash
python manage.py generate_qa_tests --framework playwright
```

### Configuration

Add these optional settings to your `settings.py`:

```python
# Test framework (default: 'selenium')
QA_AUTOMATION_FRAMEWORK = 'selenium'  # or 'playwright'

# Output directory (default: 'generated_tests')
QA_AUTOMATION_OUTPUT_DIR = 'automation_tests'

# Base URL for tests (default: 'http://localhost:8000')
QA_AUTOMATION_BASE_URL = 'http://localhost:8000'

# Browser to use (default: 'chrome')
QA_AUTOMATION_BROWSER = 'chrome'  # or 'firefox', 'edge', etc.

# Exclude certain apps from test generation
QA_AUTOMATION_EXCLUDED_APPS = [
    'admin', 'auth', 'contenttypes', 'sessions', 'messages', 'staticfiles'
]
```

### Running Generated Tests

1. Install the test framework:
```bash
# For Selenium
pip install selenium pytest pytest-django

# For Playwright
pip install playwright pytest pytest-django
playwright install
```

2. Run the tests:
```bash
pytest generated_tests/
```

### Example Project Structure

After running the command, your project will look like:

```
myproject/
├── myapp/
│   ├── views.py
│   └── ...
├── generated_tests/          # Generated test files
│   ├── __init__.py
│   ├── base_test.py         # Base test utilities
│   ├── conftest.py          # Pytest fixtures
│   └── myapp/
│       ├── __init__.py
│       └── test_myapp.py    # Generated tests
├── manage.py
└── settings.py
```

### Customization

#### Custom Templates

You can provide custom Jinja2 templates for code generation:

```python
# settings.py
QA_AUTOMATION_TEMPLATES_DIR = 'path/to/custom/templates'
```

#### Hooks

Extend the generator with custom hooks:

```python
# In your Django app
from qa_automation_generator.hooks import register_hook

@register_hook('post_generate')
def my_custom_hook(generated_code, view_info):
    # Modify or enhance generated code
    return generated_code
```

### Advanced Options

```bash
# Generate tests for specific view
python manage.py generate_qa_tests --view myapp.views.MyView

# Generate tests for URLs matching pattern
python manage.py generate_qa_tests --url-pattern /api/

# Custom output directory
python manage.py generate_qa_tests --output custom_tests/

# Overwrite existing files
python manage.py generate_qa_tests --overwrite
```

### Troubleshooting

**Issue**: Tests not generating for my views
- Check that your views are properly registered in `urls.py`
- Ensure the app is not in `QA_AUTOMATION_EXCLUDED_APPS`

**Issue**: Template analysis fails
- The library tries to render templates to analyze them
- Provide a simple context or the analysis will use raw HTML

**Issue**: Generated tests don't run
- Make sure you've installed the test framework (selenium or playwright)
- Check that the base URL is correct in your settings

### Contributing

Contributions are welcome! Please visit our GitHub repository.

### License

MIT License - see LICENSE file for details.
