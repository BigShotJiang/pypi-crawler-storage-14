from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="django-qa-automation-generator",
    version="0.1.0",
    author="Abhinav Dev",
    author_email="theabhinavdev@gmail.com",
    description="A Django library that generates automation test code for Django views",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/DevAbhinav2073/automation-qa-code-generator",
    packages=find_packages(exclude=["tests", "tests.*"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
        "Topic :: Software Development :: Code Generators",
        "Framework :: Django",
        "Framework :: Django :: 3.2",
        "Framework :: Django :: 4.0",
        "Framework :: Django :: 4.1",
        "Framework :: Django :: 4.2",
        "Framework :: Django :: 5.0",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "Django>=3.2",
        "Jinja2>=3.0.0",
        "beautifulsoup4>=4.9.0",
        "lxml>=4.6.0",
    ],
    extras_require={
        "selenium": ["selenium>=4.0.0"],
        "playwright": ["playwright>=1.30.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-django>=4.5.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.950",
        ],
    },
    include_package_data=True,
    package_data={
        "qa_automation_generator": [
            "templates/*.j2",
            "templates/selenium/*.j2",
            "templates/playwright/*.j2",
        ],
    },
)
