# Django QA Automation Code Generator

A Django library that automatically generates automation test code (Selenium/Playwright) for your Django views.

## Features

- 🚀 Automatically generate Selenium or Playwright test code from Django views
- 🎯 Target specific views, apps, or URL patterns
- 📁 Organized output structure mirroring your Django project
- 🔧 Configurable test framework (Selenium/Playwright)
- 📝 Generates ready-to-use test code with proper selectors and assertions

## Installation

```bash
pip install django-qa-automation-generator
```

Add to your Django project's `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    # ... other apps
    'qa_automation_generator',
]
```

## Configuration

Add optional settings to your Django settings file:

```python
# Optional: Configure the automation framework (default: 'selenium')
QA_AUTOMATION_FRAMEWORK = 'selenium'  # or 'playwright'

# Optional: Configure output directory (default: 'generated_tests')
QA_AUTOMATION_OUTPUT_DIR = 'automation_tests'

# Optional: Configure base URL for tests (default: 'http://localhost:8000')
QA_AUTOMATION_BASE_URL = 'http://localhost:8000'

# Optional: Browser to use (default: 'chrome')
QA_AUTOMATION_BROWSER = 'chrome'  # or 'firefox', 'edge', etc.
```

## Usage

### Generate tests for all views

```bash
python manage.py generate_qa_tests
```

### Generate tests for a specific app

```bash
python manage.py generate_qa_tests --app myapp
```

### Generate tests for a specific view

```bash
python manage.py generate_qa_tests --view myapp.views.MyView
```

### Generate tests for specific URL patterns

```bash
python manage.py generate_qa_tests --url-pattern /api/users/
```

### Specify output framework

```bash
python manage.py generate_qa_tests --framework playwright
```

### Combine options

```bash
python manage.py generate_qa_tests --app myapp --framework playwright --output custom_tests/
```

## Generated Code Structure

The generated tests will be organized in a structure similar to your Django project:

```
generated_tests/
├── __init__.py
├── conftest.py  # Pytest fixtures (if using pytest)
├── base_test.py  # Base test class with common utilities
├── myapp/
│   ├── __init__.py
│   ├── test_my_view.py
│   └── test_another_view.py
└── anotherapp/
    ├── __init__.py
    └── test_views.py
```

## Example Generated Code

### Selenium Example

```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from base_test import BaseTest


class TestMyView(BaseTest):
    def test_my_view_loads(self):
        self.driver.get(f"{self.base_url}/myapp/myview/")
        assert "Expected Title" in self.driver.title
        
    def test_form_submission(self):
        self.driver.get(f"{self.base_url}/myapp/myview/")
        input_field = self.driver.find_element(By.ID, "id_field_name")
        input_field.send_keys("test value")
        submit_button = self.driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
        submit_button.click()
        # Add assertions based on expected behavior
```

### Playwright Example

```python
import pytest
from playwright.sync_api import Page, expect


class TestMyView:
    def test_my_view_loads(self, page: Page):
        page.goto("/myapp/myview/")
        expect(page).to_have_title("Expected Title")
        
    def test_form_submission(self, page: Page):
        page.goto("/myapp/myview/")
        page.fill("#id_field_name", "test value")
        page.click("button[type='submit']")
        # Add assertions based on expected behavior
```

## How It Works

1. **View Discovery**: The library scans your Django project's URL configuration to discover all registered views
2. **Template Analysis**: It analyzes the templates associated with each view to identify forms, buttons, and interactive elements
3. **Code Generation**: Based on the analysis, it generates appropriate test code with:
   - Page navigation
   - Element selectors (ID, CSS, XPath)
   - Form interactions
   - Basic assertions
4. **Organization**: Tests are organized in a structure mirroring your Django app structure

## Advanced Features

### Custom Templates

You can provide custom Jinja2 templates for code generation:

```python
QA_AUTOMATION_TEMPLATES_DIR = 'path/to/custom/templates'
```

### Hooks and Customization

Extend the generator with custom hooks:

```python
# In your Django app
from qa_automation_generator.hooks import register_hook

@register_hook('post_generate')
def my_custom_hook(generated_code, view_info):
    # Modify or enhance generated code
    return generated_code
```

## Requirements

- Python 3.8+
- Django 3.2+
- selenium (if using Selenium framework)
- playwright (if using Playwright framework)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License

## Support

For issues and questions, please use the GitHub issue tracker.
