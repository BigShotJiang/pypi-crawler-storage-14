# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-11-25

### Added
- Initial release of Django QA Automation Code Generator
- Support for Selenium test generation
- Support for Playwright test generation
- Django management command `generate_qa_tests`
- URL pattern discovery and analysis
- Template analysis for forms and interactive elements
- View analysis for class-based and function-based views
- Configurable test framework selection
- Filtering by app, view, or URL pattern
- Jinja2 templating system for code generation
- Hook system for extensibility
- Base test classes and pytest fixtures
- Comprehensive documentation and examples

### Features
- Automatic discovery of Django views from URL configuration
- Template parsing to identify forms, inputs, and buttons
- Smart selector generation (ID, name, class, CSS)
- Support for multiple browsers (Chrome, Firefox, Edge)
- Organized output structure mirroring Django project
- Configurable exclusion of apps and URL patterns
- Type hints and docstrings in generated code
- Ready-to-run test code with proper imports

[0.1.0]: https://github.com/yourusername/django-qa-automation-generator/releases/tag/v0.1.0
