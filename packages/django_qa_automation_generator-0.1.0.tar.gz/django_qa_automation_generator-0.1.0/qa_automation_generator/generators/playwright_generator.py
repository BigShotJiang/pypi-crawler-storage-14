"""
Playwright test code generator.
"""
from typing import Dict, Any
from .base_generator import BaseGenerator
from ..analyzers import ViewInfo, URLInfo
from .. import config


class PlaywrightGenerator(BaseGenerator):
    """Generator for Playwright test code."""

    def _get_framework_name(self) -> str:
        """Get the framework name."""
        return "playwright"

    def generate_test_method(
        self, view_info: ViewInfo, url_info: URLInfo
    ) -> str:
        """
        Generate a Playwright test method for a view.

        Args:
            view_info: View information
            url_info: URL information

        Returns:
            Generated test method code
        """
        template = self.jinja_env.get_template("test_method.j2")
        return template.render(
            view_info=view_info,
            url_info=url_info,
            config=config,
            get_selector=self.get_selector_for_element,
        )

    def generate_page_load_test(self, view_info: ViewInfo, url_info: URLInfo) -> str:
        """
        Generate a test for page loading.

        Args:
            view_info: View information
            url_info: URL information

        Returns:
            Test method code
        """
        test_name = f"test_{url_info.name or 'page'}_loads"
        url_pattern = url_info.pattern

        # Replace URL parameters with example values
        for param in url_info.parameters:
            url_pattern = url_pattern.replace(f"<int:{param}>", "1")
            url_pattern = url_pattern.replace(f"<str:{param}>", "test")
            url_pattern = url_pattern.replace(f"<slug:{param}>", "test-slug")
            url_pattern = url_pattern.replace(f"<{param}>", "test")

        code = f'''    def {test_name}(self, page: Page):
        """Test that the page loads successfully."""
        page.goto("{url_pattern}")
'''

        # Add title check if available
        if view_info.template_info and view_info.template_info.title:
            code += f'        expect(page).to_have_title("{view_info.template_info.title}")\n'
        else:
            code += '        expect(page).to_have_title(re.compile(r".+"))  # Page should have a title\n'

        return code

    def generate_form_test(
        self, view_info: ViewInfo, url_info: URLInfo, form_info: Any
    ) -> str:
        """
        Generate a test for form submission.

        Args:
            view_info: View information
            url_info: URL information
            form_info: Form information

        Returns:
            Test method code
        """
        test_name = f"test_{url_info.name or 'form'}_submission"
        url_pattern = url_info.pattern

        # Replace URL parameters
        for param in url_info.parameters:
            url_pattern = url_pattern.replace(f"<int:{param}>", "1")
            url_pattern = url_pattern.replace(f"<str:{param}>", "test")
            url_pattern = url_pattern.replace(f"<slug:{param}>", "test-slug")
            url_pattern = url_pattern.replace(f"<{param}>", "test")

        code = f'''    def {test_name}(self, page: Page):
        """Test form submission."""
        page.goto("{url_pattern}")
        
'''

        # Fill form inputs
        for input_field in form_info.inputs:
            if input_field.get("type") in ["submit", "button", "hidden"]:
                continue

            selector = self.get_selector_for_element(input_field)
            test_value = self._get_test_value_for_input(input_field)

            code += f'        # Fill {input_field.get("name", "field")}\n'
            code += f'        page.fill("{selector}", "{test_value}")\n\n'

        # Click submit button
        if form_info.buttons:
            submit_button = next(
                (b for b in form_info.buttons if b.get("type") == "submit"),
                form_info.buttons[0],
            )
            selector = self.get_selector_for_element(submit_button)

            code += f'        # Submit form\n'
            code += f'        page.click("{selector}")\n\n'

        code += '        # Add assertions for expected behavior\n'
        code += '        # TODO: Verify form submission success\n'

        return code

    def _get_test_value_for_input(self, input_field: Dict[str, Any]) -> str:
        """
        Get appropriate test value for an input field.

        Args:
            input_field: Input field information

        Returns:
            Test value
        """
        input_type = input_field.get("type", "text")
        name = input_field.get("name", "")

        # Email field
        if input_type == "email" or "email" in name.lower():
            return "test@example.com"

        # Password field
        if input_type == "password" or "password" in name.lower():
            return "TestPassword123"

        # Number field
        if input_type == "number":
            return "42"

        # URL field
        if input_type == "url":
            return "https://example.com"

        # Date field
        if input_type == "date":
            return "2025-01-01"

        # Default text
        return "Test Value"
