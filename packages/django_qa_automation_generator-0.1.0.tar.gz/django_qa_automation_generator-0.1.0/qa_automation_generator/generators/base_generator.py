"""
Base generator class for creating test code.
"""
import os
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from ..analyzers import ViewInfo, URLInfo
from .. import config
from ..utils import ensure_directory_exists, sanitize_filename, camel_to_snake


class BaseGenerator(ABC):
    """Base class for test code generators."""

    def __init__(self, output_dir: Optional[str] = None):
        """
        Initialize generator.

        Args:
            output_dir: Output directory for generated tests
        """
        self.output_dir = output_dir or config.OUTPUT_DIR
        self.framework = self._get_framework_name()
        self.jinja_env = self._setup_jinja_environment()

    @abstractmethod
    def _get_framework_name(self) -> str:
        """Get the framework name."""
        pass

    @abstractmethod
    def generate_test_method(
        self, view_info: ViewInfo, url_info: URLInfo
    ) -> str:
        """
        Generate a test method for a view.

        Args:
            view_info: View information
            url_info: URL information

        Returns:
            Generated test method code
        """
        pass

    def _setup_jinja_environment(self) -> Environment:
        """Setup Jinja2 environment for templates."""
        # Determine template directory
        if config.TEMPLATES_DIR and os.path.exists(config.TEMPLATES_DIR):
            template_dir = config.TEMPLATES_DIR
        else:
            # Use built-in templates
            package_dir = Path(__file__).parent.parent
            template_dir = package_dir / "templates" / self.framework

        loader = FileSystemLoader(str(template_dir))
        env = Environment(loader=loader, autoescape=select_autoescape())

        # Add custom filters
        env.filters["sanitize"] = sanitize_filename
        env.filters["camel_to_snake"] = camel_to_snake

        return env

    def generate_test_class(
        self, app_name: str, view_infos: List[tuple[ViewInfo, URLInfo]]
    ) -> str:
        """
        Generate a test class for an app.

        Args:
            app_name: App name
            view_infos: List of (ViewInfo, URLInfo) tuples

        Returns:
            Generated test class code
        """
        template = self.jinja_env.get_template("test_class.j2")
        return template.render(
            app_name=app_name,
            view_infos=view_infos,
            config=config,
            framework=self.framework,
        )

    def generate_base_test(self) -> str:
        """
        Generate base test class with common utilities.

        Returns:
            Generated base test code
        """
        template = self.jinja_env.get_template("base_test.j2")
        return template.render(config=config, framework=self.framework)

    def generate_conftest(self) -> str:
        """
        Generate pytest conftest.py with fixtures.

        Returns:
            Generated conftest code
        """
        if config.TEST_STYLE != "pytest":
            return ""

        template = self.jinja_env.get_template("conftest.j2")
        return template.render(config=config, framework=self.framework)

    def generate_init_file(self) -> str:
        """
        Generate __init__.py file.

        Returns:
            Generated init file code
        """
        return '"""Generated test package."""\n'

    def save_test_file(
        self, app_name: str, content: str, filename: Optional[str] = None
    ) -> str:
        """
        Save generated test code to file.

        Args:
            app_name: App name
            content: Test code content
            filename: Optional custom filename

        Returns:
            Path to saved file
        """
        # Create app directory
        app_dir = os.path.join(self.output_dir, app_name)
        ensure_directory_exists(app_dir)

        # Determine filename
        if not filename:
            filename = f"test_{sanitize_filename(app_name)}.py"

        file_path = os.path.join(app_dir, filename)

        # Check if file exists and overwrite setting
        if os.path.exists(file_path) and not config.OVERWRITE_EXISTING:
            # Append number to filename
            base, ext = os.path.splitext(filename)
            counter = 1
            while os.path.exists(file_path):
                filename = f"{base}_{counter}{ext}"
                file_path = os.path.join(app_dir, filename)
                counter += 1

        # Write file
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

        return file_path

    def save_base_files(self) -> Dict[str, str]:
        """
        Save base test files (base_test.py, conftest.py, __init__.py).

        Returns:
            Dictionary of filename -> file path
        """
        ensure_directory_exists(self.output_dir)
        saved_files = {}

        # Save __init__.py
        init_path = os.path.join(self.output_dir, "__init__.py")
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(self.generate_init_file())
        saved_files["__init__.py"] = init_path

        # Save base_test.py
        base_test_path = os.path.join(self.output_dir, "base_test.py")
        with open(base_test_path, "w", encoding="utf-8") as f:
            f.write(self.generate_base_test())
        saved_files["base_test.py"] = base_test_path

        # Save conftest.py if using pytest
        if config.TEST_STYLE == "pytest":
            conftest_path = os.path.join(self.output_dir, "conftest.py")
            with open(conftest_path, "w", encoding="utf-8") as f:
                f.write(self.generate_conftest())
            saved_files["conftest.py"] = conftest_path

        return saved_files

    def get_selector_for_element(self, element: Dict[str, Any]) -> str:
        """
        Generate appropriate selector for an element.

        Args:
            element: Element information dictionary

        Returns:
            Selector string
        """
        # Prefer ID selector
        if element.get("id"):
            return f"#{element['id']}"

        # Use name attribute
        if element.get("name"):
            return f"[name='{element['name']}']"

        # Use class selector
        if element.get("class"):
            classes = element["class"]
            if isinstance(classes, list):
                classes = " ".join(classes)
            return f".{classes.split()[0]}"

        # Fallback to tag name
        return element.get("type", "input")
