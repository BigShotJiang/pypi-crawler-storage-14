"""
Selenium test code generator.
"""
from typing import Dict, Any
from .base_generator import BaseGenerator
from ..analyzers import ViewInfo, URLInfo
from .. import config


class SeleniumGenerator(BaseGenerator):
    """Generator for Selenium test code."""

    def _get_framework_name(self) -> str:
        """Get the framework name."""
        return "selenium"

    def generate_test_method(
        self, view_info: ViewInfo, url_info: URLInfo
    ) -> str:
        """
        Generate a Selenium test method for a view.

        Args:
            view_info: View information
            url_info: URL information

        Returns:
            Generated test method code
        """
        template = self.jinja_env.get_template("test_method.j2")
        return template.render(
            view_info=view_info,
            url_info=url_info,
            config=config,
            get_selector=self.get_selector_for_element,
            get_selenium_locator=self._get_selenium_locator,
        )

    def _get_selenium_locator(self, selector: str) -> tuple[str, str]:
        """
        Convert CSS selector to Selenium locator.

        Args:
            selector: CSS selector

        Returns:
            Tuple of (locator_type, locator_value)
        """
        # ID selector
        if selector.startswith("#"):
            return ("By.ID", selector[1:])

        # Class selector
        if selector.startswith("."):
            return ("By.CLASS_NAME", selector[1:])

        # Attribute selector
        if selector.startswith("[") and selector.endswith("]"):
            # Extract attribute and value
            attr_match = selector[1:-1]
            if "=" in attr_match:
                attr, value = attr_match.split("=", 1)
                value = value.strip("'\"")
                if attr == "name":
                    return ("By.NAME", value)
                else:
                    return ("By.CSS_SELECTOR", selector)

        # Default to CSS selector
        return ("By.CSS_SELECTOR", selector)

    def generate_page_load_test(self, view_info: ViewInfo, url_info: URLInfo) -> str:
        """
        Generate a test for page loading.

        Args:
            view_info: View information
            url_info: URL information

        Returns:
            Test method code
        """
        test_name = f"test_{url_info.name or 'page'}_loads"
        url_pattern = url_info.pattern

        # Replace URL parameters with example values
        for param in url_info.parameters:
            url_pattern = url_pattern.replace(f"<int:{param}>", "1")
            url_pattern = url_pattern.replace(f"<str:{param}>", "test")
            url_pattern = url_pattern.replace(f"<slug:{param}>", "test-slug")
            url_pattern = url_pattern.replace(f"<{param}>", "test")

        code = f'''    def {test_name}(self):
        """Test that the page loads successfully."""
        self.driver.get(f"{{self.base_url}}{url_pattern}")
        assert self.driver.title, "Page should have a title"
'''

        # Add title check if available
        if view_info.template_info and view_info.template_info.title:
            code += f'        assert "{view_info.template_info.title}" in self.driver.title\n'

        return code

    def generate_form_test(
        self, view_info: ViewInfo, url_info: URLInfo, form_info: Any
    ) -> str:
        """
        Generate a test for form submission.

        Args:
            view_info: View information
            url_info: URL information
            form_info: Form information

        Returns:
            Test method code
        """
        test_name = f"test_{url_info.name or 'form'}_submission"
        url_pattern = url_info.pattern

        # Replace URL parameters
        for param in url_info.parameters:
            url_pattern = url_pattern.replace(f"<int:{param}>", "1")
            url_pattern = url_pattern.replace(f"<str:{param}>", "test")
            url_pattern = url_pattern.replace(f"<slug:{param}>", "test-slug")
            url_pattern = url_pattern.replace(f"<{param}>", "test")

        code = f'''    def {test_name}(self):
        """Test form submission."""
        self.driver.get(f"{{self.base_url}}{url_pattern}")
        
'''

        # Fill form inputs
        for input_field in form_info.inputs:
            if input_field.get("type") in ["submit", "button", "hidden"]:
                continue

            selector = self.get_selector_for_element(input_field)
            locator_type, locator_value = self._get_selenium_locator(selector)

            test_value = self._get_test_value_for_input(input_field)

            code += f'        # Fill {input_field.get("name", "field")}\n'
            code += f'        input_field = self.driver.find_element({locator_type}, "{locator_value}")\n'
            code += f'        input_field.send_keys("{test_value}")\n\n'

        # Click submit button
        if form_info.buttons:
            submit_button = next(
                (b for b in form_info.buttons if b.get("type") == "submit"),
                form_info.buttons[0],
            )
            selector = self.get_selector_for_element(submit_button)
            locator_type, locator_value = self._get_selenium_locator(selector)

            code += f'        # Submit form\n'
            code += f'        submit_button = self.driver.find_element({locator_type}, "{locator_value}")\n'
            code += f'        submit_button.click()\n\n'

        code += '        # Add assertions for expected behavior\n'
        code += '        # TODO: Verify form submission success\n'

        return code

    def _get_test_value_for_input(self, input_field: Dict[str, Any]) -> str:
        """
        Get appropriate test value for an input field.

        Args:
            input_field: Input field information

        Returns:
            Test value
        """
        input_type = input_field.get("type", "text")
        name = input_field.get("name", "")

        # Email field
        if input_type == "email" or "email" in name.lower():
            return "test@example.com"

        # Password field
        if input_type == "password" or "password" in name.lower():
            return "TestPassword123"

        # Number field
        if input_type == "number":
            return "42"

        # URL field
        if input_type == "url":
            return "https://example.com"

        # Date field
        if input_type == "date":
            return "2025-01-01"

        # Default text
        return "Test Value"
