"""
Utility functions for the QA Automation Generator.
"""
import os
import re
from typing import List, Optional, Dict, Any
from pathlib import Path


def sanitize_filename(name: str) -> str:
    """
    Sanitize a string to be used as a filename.
    
    Args:
        name: String to sanitize
        
    Returns:
        Sanitized filename
    """
    # Replace invalid characters with underscores
    name = re.sub(r'[<>:"/\\|?*]', '_', name)
    # Replace spaces and dots with underscores
    name = re.sub(r'[\s.]', '_', name)
    # Remove consecutive underscores
    name = re.sub(r'_+', '_', name)
    # Remove leading/trailing underscores
    name = name.strip('_')
    # Convert to lowercase
    return name.lower()


def get_view_name(view_func: Any) -> str:
    """
    Get a readable name for a view function or class.
    
    Args:
        view_func: View function or class
        
    Returns:
        View name
    """
    if hasattr(view_func, '__name__'):
        return view_func.__name__
    elif hasattr(view_func, '__class__'):
        return view_func.__class__.__name__
    else:
        return str(view_func)


def get_app_name_from_view(view_func: Any) -> Optional[str]:
    """
    Extract app name from a view function or class.
    
    Args:
        view_func: View function or class
        
    Returns:
        App name or None
    """
    if hasattr(view_func, '__module__'):
        module_parts = view_func.__module__.split('.')
        # Typically: app_name.views or project.app_name.views
        if len(module_parts) >= 2:
            # Return the part before 'views'
            if 'views' in module_parts:
                idx = module_parts.index('views')
                if idx > 0:
                    return module_parts[idx - 1]
            # Otherwise return second to last part
            return module_parts[-2] if len(module_parts) > 1 else module_parts[0]
    return None


def ensure_directory_exists(directory: str) -> None:
    """
    Ensure a directory exists, creating it if necessary.
    
    Args:
        directory: Directory path
    """
    Path(directory).mkdir(parents=True, exist_ok=True)


def get_template_path(view_func: Any) -> Optional[str]:
    """
    Try to extract template path from a view.
    
    Args:
        view_func: View function or class
        
    Returns:
        Template path or None
    """
    # For class-based views
    if hasattr(view_func, 'template_name'):
        return view_func.template_name
    
    # For function-based views, we'd need to parse the code
    # This is a simplified version
    return None


def camel_to_snake(name: str) -> str:
    """
    Convert CamelCase to snake_case.
    
    Args:
        name: CamelCase string
        
    Returns:
        snake_case string
    """
    # Insert underscore before uppercase letters
    name = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    # Insert underscore before uppercase letters preceded by lowercase
    name = re.sub('([a-z0-9])([A-Z])', r'\1_\2', name)
    return name.lower()


def snake_to_camel(name: str, capitalize_first: bool = True) -> str:
    """
    Convert snake_case to CamelCase.
    
    Args:
        name: snake_case string
        capitalize_first: Whether to capitalize the first letter
        
    Returns:
        CamelCase string
    """
    components = name.split('_')
    if capitalize_first:
        return ''.join(x.title() for x in components)
    else:
        return components[0] + ''.join(x.title() for x in components[1:])


def get_url_pattern_name(url_pattern: Any) -> str:
    """
    Get the name of a URL pattern.
    
    Args:
        url_pattern: Django URL pattern
        
    Returns:
        Pattern name
    """
    if hasattr(url_pattern, 'name') and url_pattern.name:
        return url_pattern.name
    elif hasattr(url_pattern, 'pattern'):
        return str(url_pattern.pattern)
    else:
        return str(url_pattern)


def extract_url_parameters(url_pattern: str) -> List[str]:
    """
    Extract parameter names from a URL pattern.
    
    Args:
        url_pattern: URL pattern string
        
    Returns:
        List of parameter names
    """
    # Match Django URL parameters like <int:id> or <slug:slug>
    params = re.findall(r'<(?:\w+:)?(\w+)>', url_pattern)
    return params


def format_code(code: str, language: str = "python") -> str:
    """
    Format code (basic formatting, can be enhanced with black/autopep8).
    
    Args:
        code: Code to format
        language: Programming language
        
    Returns:
        Formatted code
    """
    # Basic formatting - remove extra blank lines
    lines = code.split('\n')
    formatted_lines = []
    prev_blank = False
    
    for line in lines:
        is_blank = not line.strip()
        if is_blank and prev_blank:
            continue
        formatted_lines.append(line)
        prev_blank = is_blank
    
    return '\n'.join(formatted_lines)


def get_http_method_from_view(view_func: Any) -> List[str]:
    """
    Determine HTTP methods supported by a view.
    
    Args:
        view_func: View function or class
        
    Returns:
        List of HTTP methods
    """
    methods = []
    
    # For class-based views
    if hasattr(view_func, 'http_method_names'):
        methods = view_func.http_method_names
    elif hasattr(view_func, 'view_class'):
        if hasattr(view_func.view_class, 'http_method_names'):
            methods = view_func.view_class.http_method_names
    
    # Default to GET if we can't determine
    return methods if methods else ['get']
