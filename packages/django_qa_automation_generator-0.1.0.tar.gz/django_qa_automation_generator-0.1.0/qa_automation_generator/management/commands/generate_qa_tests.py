"""
Django management command to generate QA automation test code.
"""
from django.core.management.base import BaseCommand, CommandError
from typing import Optional
from ...analyzers import URLAnalyzer, ViewAnalyzer
from ...generators import SeleniumGenerator, PlaywrightGenerator
from ... import config


class Command(BaseCommand):
    """Management command to generate QA automation test code."""

    help = "Generate automation test code for Django views"

    def add_arguments(self, parser):
        """Add command arguments."""
        parser.add_argument(
            "--app",
            type=str,
            help="Generate tests for a specific app",
        )
        parser.add_argument(
            "--view",
            type=str,
            help="Generate tests for a specific view (e.g., myapp.views.MyView)",
        )
        parser.add_argument(
            "--url-pattern",
            type=str,
            help="Generate tests for URLs matching this pattern (regex)",
        )
        parser.add_argument(
            "--framework",
            type=str,
            choices=["selenium", "playwright"],
            default=config.DEFAULT_FRAMEWORK,
            help="Test framework to use (default: %(default)s)",
        )
        parser.add_argument(
            "--output",
            type=str,
            default=config.OUTPUT_DIR,
            help="Output directory for generated tests (default: %(default)s)",
        )
        parser.add_argument(
            "--overwrite",
            action="store_true",
            help="Overwrite existing test files",
        )

    def handle(self, *args, **options):
        """Execute the command."""
        app_name = options.get("app")
        view_name = options.get("view")
        url_pattern = options.get("url_pattern")
        framework = options.get("framework")
        output_dir = options.get("output")
        overwrite = options.get("overwrite")

        # Update config if overwrite is specified
        if overwrite:
            config.OVERWRITE_EXISTING = True

        self.stdout.write(
            self.style.SUCCESS(
                f"Generating {framework} test code..."
            )
        )

        # Initialize analyzers
        url_analyzer = URLAnalyzer()
        view_analyzer = ViewAnalyzer()

        # Discover URLs
        self.stdout.write("Discovering URL patterns...")
        url_infos = url_analyzer.analyze(
            app_name=app_name,
            view_name=view_name,
            url_pattern=url_pattern,
        )

        if not url_infos:
            raise CommandError(
                "No URL patterns found matching the specified criteria."
            )

        self.stdout.write(
            self.style.SUCCESS(
                f"Found {len(url_infos)} URL pattern(s)"
            )
        )

        # Initialize generator
        if framework == "selenium":
            generator = SeleniumGenerator(output_dir=output_dir)
        elif framework == "playwright":
            generator = PlaywrightGenerator(output_dir=output_dir)
        else:
            raise CommandError(f"Unknown framework: {framework}")

        # Generate base files
        self.stdout.write("Generating base test files...")
        base_files = generator.save_base_files()
        for filename, filepath in base_files.items():
            self.stdout.write(f"  Created: {filepath}")

        # Group URLs by app
        apps_views = {}
        for url_info in url_infos:
            app = url_info.app_name or "unknown"
            if app not in apps_views:
                apps_views[app] = []

            # Analyze view
            view_info = view_analyzer.analyze(url_info.view_func, url_info.pattern)
            apps_views[app].append((view_info, url_info))

        # Generate tests for each app
        total_files = 0
        for app, view_infos in apps_views.items():
            self.stdout.write(f"\nGenerating tests for app: {app}")

            # Generate test code
            test_code = self._generate_test_file(
                generator, app, view_infos
            )

            # Save test file
            test_file = generator.save_test_file(app, test_code)
            self.stdout.write(f"  Created: {test_file}")
            total_files += 1

        # Summary
        self.stdout.write(
            self.style.SUCCESS(
                f"\n✓ Successfully generated {total_files} test file(s) "
                f"for {len(url_infos)} view(s)"
            )
        )
        self.stdout.write(
            f"\nTest files are located in: {output_dir}"
        )
        self.stdout.write(
            "\nNext steps:"
        )
        self.stdout.write(
            f"  1. Install {framework}: pip install {framework}"
        )
        if framework == "playwright":
            self.stdout.write(
                "  2. Install browsers: playwright install"
            )
        self.stdout.write(
            f"  3. Review and customize the generated tests in {output_dir}"
        )
        self.stdout.write(
            "  4. Run tests: pytest " + output_dir
        )

    def _generate_test_file(self, generator, app_name, view_infos):
        """
        Generate test file content for an app.

        Args:
            generator: Code generator instance
            app_name: App name
            view_infos: List of (ViewInfo, URLInfo) tuples

        Returns:
            Generated test code
        """
        # Start with imports
        if isinstance(generator, SeleniumGenerator):
            code = '''"""
Generated Selenium tests for {app_name}.
"""
import unittest
from selenium.webdriver.common.by import By
from base_test import BaseTest


'''.format(app_name=app_name)
        else:  # Playwright
            code = '''"""
Generated Playwright tests for {app_name}.
"""
import re
import pytest
from playwright.sync_api import Page, expect


'''.format(app_name=app_name)

        # Generate test class for each view
        for view_info, url_info in view_infos:
            code += self._generate_test_class(
                generator, view_info, url_info
            )
            code += "\n\n"

        return code

    def _generate_test_class(self, generator, view_info, url_info):
        """
        Generate a test class for a view.

        Args:
            generator: Code generator instance
            view_info: View information
            url_info: URL information

        Returns:
            Test class code
        """
        class_name = f"Test{view_info.view_name}"

        if isinstance(generator, SeleniumGenerator):
            code = f"class {class_name}(BaseTest):\n"
            code += f'    """Tests for {view_info.view_name}."""\n\n'
        else:  # Playwright
            code = f"class {class_name}:\n"
            code += f'    """Tests for {view_info.view_name}."""\n\n'

        # Generate page load test
        code += generator.generate_page_load_test(view_info, url_info)
        code += "\n"

        # Generate form tests if view has forms
        if view_info.template_info and view_info.template_info.forms:
            for form_info in view_info.template_info.forms:
                code += "\n"
                code += generator.generate_form_test(
                    view_info, url_info, form_info
                )

        return code
