"""
Configuration settings for QA Automation Generator.
"""
from django.conf import settings


# Default framework to use for code generation
DEFAULT_FRAMEWORK = getattr(settings, "QA_AUTOMATION_FRAMEWORK", "selenium")

# Output directory for generated tests
OUTPUT_DIR = getattr(settings, "QA_AUTOMATION_OUTPUT_DIR", "generated_tests")

# Base URL for tests
BASE_URL = getattr(settings, "QA_AUTOMATION_BASE_URL", "http://localhost:8000")

# Browser to use for tests
BROWSER = getattr(settings, "QA_AUTOMATION_BROWSER", "chrome")

# Custom templates directory
TEMPLATES_DIR = getattr(settings, "QA_AUTOMATION_TEMPLATES_DIR", None)

# Whether to generate pytest or unittest style tests
TEST_STYLE = getattr(settings, "QA_AUTOMATION_TEST_STYLE", "pytest")

# Whether to include docstrings in generated code
INCLUDE_DOCSTRINGS = getattr(settings, "QA_AUTOMATION_INCLUDE_DOCSTRINGS", True)

# Whether to generate type hints
INCLUDE_TYPE_HINTS = getattr(settings, "QA_AUTOMATION_INCLUDE_TYPE_HINTS", True)

# Maximum wait time for elements (in seconds)
WAIT_TIMEOUT = getattr(settings, "QA_AUTOMATION_WAIT_TIMEOUT", 10)

# Whether to generate page object models
USE_PAGE_OBJECTS = getattr(settings, "QA_AUTOMATION_USE_PAGE_OBJECTS", False)

# Excluded apps (won't generate tests for these)
EXCLUDED_APPS = getattr(
    settings,
    "QA_AUTOMATION_EXCLUDED_APPS",
    ["admin", "auth", "contenttypes", "sessions", "messages", "staticfiles"],
)

# Excluded URL patterns (regex patterns to exclude)
EXCLUDED_URL_PATTERNS = getattr(settings, "QA_AUTOMATION_EXCLUDED_URL_PATTERNS", [])

# Whether to overwrite existing test files
OVERWRITE_EXISTING = getattr(settings, "QA_AUTOMATION_OVERWRITE_EXISTING", False)
