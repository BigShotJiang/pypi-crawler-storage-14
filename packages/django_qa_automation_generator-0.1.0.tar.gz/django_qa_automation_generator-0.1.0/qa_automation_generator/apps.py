from django.apps import AppConfig


class QaAutomationGeneratorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "qa_automation_generator"
    verbose_name = "QA Automation Code Generator"

    def ready(self):
        """
        Perform initialization when the app is ready.
        """
        # Import hooks to register them
        from . import hooks  # noqa: F401
