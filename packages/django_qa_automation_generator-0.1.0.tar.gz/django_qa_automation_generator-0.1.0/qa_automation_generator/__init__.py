"""
Django QA Automation Code Generator

A Django library that automatically generates automation test code
(Selenium/Playwright) for Django views.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

default_app_config = "qa_automation_generator.apps.QaAutomationGeneratorConfig"
