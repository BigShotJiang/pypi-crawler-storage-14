"""
Hook system for extending the code generator.
"""
from typing import Callable, Dict, List, Any


# Registry for hooks
_hooks: Dict[str, List[Callable]] = {
    "pre_generate": [],
    "post_generate": [],
    "pre_analyze_view": [],
    "post_analyze_view": [],
    "pre_analyze_template": [],
    "post_analyze_template": [],
}


def register_hook(hook_name: str) -> Callable:
    """
    Decorator to register a hook function.
    
    Args:
        hook_name: Name of the hook point
        
    Returns:
        Decorator function
        
    Example:
        @register_hook('post_generate')
        def my_hook(generated_code, view_info):
            # Modify code
            return generated_code
    """
    if hook_name not in _hooks:
        raise ValueError(f"Unknown hook: {hook_name}")

    def decorator(func: Callable) -> Callable:
        _hooks[hook_name].append(func)
        return func

    return decorator


def run_hooks(hook_name: str, *args: Any, **kwargs: Any) -> Any:
    """
    Run all registered hooks for a given hook point.
    
    Args:
        hook_name: Name of the hook point
        *args: Positional arguments to pass to hooks
        **kwargs: Keyword arguments to pass to hooks
        
    Returns:
        Result from the last hook (or original value if no hooks)
    """
    if hook_name not in _hooks:
        raise ValueError(f"Unknown hook: {hook_name}")

    result = args[0] if args else None

    for hook_func in _hooks[hook_name]:
        result = hook_func(result, *args[1:], **kwargs)

    return result


def get_registered_hooks(hook_name: str = None) -> Dict[str, List[Callable]]:
    """
    Get registered hooks.
    
    Args:
        hook_name: Optional specific hook name to get
        
    Returns:
        Dictionary of hooks or list of hooks for specific name
    """
    if hook_name:
        return _hooks.get(hook_name, [])
    return _hooks.copy()
