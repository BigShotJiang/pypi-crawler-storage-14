"""
View analyzer to extract information from Django views.
"""
import inspect
from typing import Any, Dict, Optional, List
from django.views import View
from django.views.generic import TemplateView, FormView, ListView, DetailView
from .template_analyzer import TemplateAnalyzer
from ..utils import get_template_path, get_http_method_from_view


class ViewInfo:
    """Information about a Django view."""

    def __init__(self, view_func: Any, url_pattern: str = ""):
        self.view_func = view_func
        self.url_pattern = url_pattern
        self.view_type = self._determine_view_type()
        self.http_methods = get_http_method_from_view(view_func)
        self.template_name = self._get_template_name()
        self.is_class_based = self._is_class_based()
        self.has_form = self._has_form()
        self.form_class = self._get_form_class()
        self.model = self._get_model()
        self.context_data = {}
        self.template_info = None

    def _determine_view_type(self) -> str:
        """Determine the type of view."""
        if self._is_class_based():
            view_class = self._get_view_class()
            if view_class:
                # Check inheritance chain
                if issubclass(view_class, FormView):
                    return "FormView"
                elif issubclass(view_class, ListView):
                    return "ListView"
                elif issubclass(view_class, DetailView):
                    return "DetailView"
                elif issubclass(view_class, TemplateView):
                    return "TemplateView"
                elif issubclass(view_class, View):
                    return "View"
            return "ClassBasedView"
        return "FunctionBasedView"

    def _is_class_based(self) -> bool:
        """Check if view is class-based."""
        if hasattr(self.view_func, "view_class"):
            return True
        if inspect.isclass(self.view_func):
            return issubclass(self.view_func, View)
        return False

    def _get_view_class(self) -> Optional[type]:
        """Get the view class."""
        if hasattr(self.view_func, "view_class"):
            return self.view_func.view_class
        if inspect.isclass(self.view_func):
            return self.view_func
        return None

    def _get_template_name(self) -> Optional[str]:
        """Get template name from view."""
        # Try class-based view
        view_class = self._get_view_class()
        if view_class and hasattr(view_class, "template_name"):
            return view_class.template_name

        # Try instance attribute
        if hasattr(self.view_func, "template_name"):
            return self.view_func.template_name

        return None

    def _has_form(self) -> bool:
        """Check if view has a form."""
        view_class = self._get_view_class()
        if view_class:
            return issubclass(view_class, FormView) or hasattr(view_class, "form_class")
        return False

    def _get_form_class(self) -> Optional[type]:
        """Get form class from view."""
        view_class = self._get_view_class()
        if view_class and hasattr(view_class, "form_class"):
            return view_class.form_class
        return None

    def _get_model(self) -> Optional[type]:
        """Get model from view."""
        view_class = self._get_view_class()
        if view_class and hasattr(view_class, "model"):
            return view_class.model
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "view_type": self.view_type,
            "url_pattern": self.url_pattern,
            "http_methods": self.http_methods,
            "template_name": self.template_name,
            "is_class_based": self.is_class_based,
            "has_form": self.has_form,
            "form_class": str(self.form_class) if self.form_class else None,
            "model": str(self.model) if self.model else None,
            "template_info": self.template_info.to_dict() if self.template_info else None,
        }


class ViewAnalyzer:
    """Analyzes Django views to extract testable information."""

    def __init__(self):
        self.template_analyzer = TemplateAnalyzer()

    def analyze(self, view_func: Any, url_pattern: str = "") -> ViewInfo:
        """
        Analyze a Django view.

        Args:
            view_func: View function or class
            url_pattern: URL pattern for the view

        Returns:
            ViewInfo object
        """
        view_info = ViewInfo(view_func, url_pattern)

        # Analyze template if available
        if view_info.template_name:
            try:
                view_info.template_info = self.template_analyzer.analyze(
                    view_info.template_name
                )
            except Exception as e:
                # Template analysis failed, continue without it
                pass

        return view_info

    def get_view_source(self, view_func: Any) -> Optional[str]:
        """
        Get source code of a view.

        Args:
            view_func: View function or class

        Returns:
            Source code or None
        """
        try:
            if hasattr(view_func, "view_class"):
                return inspect.getsource(view_func.view_class)
            elif inspect.isclass(view_func):
                return inspect.getsource(view_func)
            elif inspect.isfunction(view_func):
                return inspect.getsource(view_func)
        except Exception:
            pass
        return None

    def extract_context_variables(self, view_func: Any) -> List[str]:
        """
        Extract context variable names from view source.

        Args:
            view_func: View function or class

        Returns:
            List of variable names
        """
        source = self.get_view_source(view_func)
        if not source:
            return []

        # Simple regex-based extraction (can be improved)
        import re

        # Look for context['key'] or context.update({'key': ...})
        context_vars = set()
        patterns = [
            r"context\[['\"]([\w_]+)['\"]\]",
            r"['\"]([\w_]+)['\"]:\s*\w+",  # In dictionary literals
        ]

        for pattern in patterns:
            matches = re.findall(pattern, source)
            context_vars.update(matches)

        return list(context_vars)
