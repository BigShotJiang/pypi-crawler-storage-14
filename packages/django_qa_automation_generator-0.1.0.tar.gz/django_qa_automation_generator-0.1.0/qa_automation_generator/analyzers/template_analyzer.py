"""
Template analyzer to extract information from Django templates.
"""
import os
from typing import List, Dict, Any, Optional
from pathlib import Path
from bs4 import BeautifulSoup
from django.template import Template, Context
from django.template.loader import get_template
from django.conf import settings


class FormInfo:
    """Information about a form in a template."""

    def __init__(self, form_element: Any):
        self.action = form_element.get("action", "")
        self.method = form_element.get("method", "get").lower()
        self.id = form_element.get("id", "")
        self.css_class = form_element.get("class", "")
        self.inputs = self._extract_inputs(form_element)
        self.buttons = self._extract_buttons(form_element)

    def _extract_inputs(self, form_element: Any) -> List[Dict[str, str]]:
        """Extract input fields from form."""
        inputs = []
        for input_elem in form_element.find_all(["input", "textarea", "select"]):
            input_info = {
                "type": input_elem.get("type", "text"),
                "name": input_elem.get("name", ""),
                "id": input_elem.get("id", ""),
                "class": input_elem.get("class", ""),
                "placeholder": input_elem.get("placeholder", ""),
                "required": input_elem.has_attr("required"),
            }
            inputs.append(input_info)
        return inputs

    def _extract_buttons(self, form_element: Any) -> List[Dict[str, str]]:
        """Extract buttons from form."""
        buttons = []
        for button_elem in form_element.find_all(["button", "input"]):
            if button_elem.name == "input" and button_elem.get("type") not in [
                "submit",
                "button",
                "reset",
            ]:
                continue
            button_info = {
                "type": button_elem.get("type", "button"),
                "text": button_elem.get_text(strip=True)
                or button_elem.get("value", ""),
                "id": button_elem.get("id", ""),
                "class": button_elem.get("class", ""),
            }
            buttons.append(button_info)
        return buttons

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "action": self.action,
            "method": self.method,
            "id": self.id,
            "class": self.css_class,
            "inputs": self.inputs,
            "buttons": self.buttons,
        }


class TemplateInfo:
    """Information about a Django template."""

    def __init__(self, template_path: str):
        self.template_path = template_path
        self.forms: List[FormInfo] = []
        self.links: List[Dict[str, str]] = []
        self.title: Optional[str] = None
        self.headings: List[str] = []
        self.interactive_elements: List[Dict[str, str]] = []

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "template_path": self.template_path,
            "title": self.title,
            "headings": self.headings,
            "forms": [f.to_dict() for f in self.forms],
            "links": self.links,
            "interactive_elements": self.interactive_elements,
        }


class TemplateAnalyzer:
    """Analyzes Django templates to extract testable elements."""

    def analyze(self, template_path: str, context: Optional[Dict] = None) -> TemplateInfo:
        """
        Analyze a Django template.

        Args:
            template_path: Path to template file
            context: Optional context for rendering

        Returns:
            TemplateInfo object
        """
        template_info = TemplateInfo(template_path)

        try:
            # Try to load and render the template
            template = get_template(template_path)
            rendered_html = template.render(context or {})
        except Exception as e:
            # If template rendering fails, try to read the raw file
            try:
                rendered_html = self._read_template_file(template_path)
            except Exception:
                # If all else fails, return empty template info
                return template_info

        # Parse HTML with BeautifulSoup
        soup = BeautifulSoup(rendered_html, "lxml")

        # Extract information
        template_info.title = self._extract_title(soup)
        template_info.headings = self._extract_headings(soup)
        template_info.forms = self._extract_forms(soup)
        template_info.links = self._extract_links(soup)
        template_info.interactive_elements = self._extract_interactive_elements(soup)

        return template_info

    def _read_template_file(self, template_path: str) -> str:
        """
        Read template file directly.

        Args:
            template_path: Template path

        Returns:
            Template content
        """
        # Try to find the template in template directories
        for template_dir in settings.TEMPLATES[0].get("DIRS", []):
            full_path = os.path.join(template_dir, template_path)
            if os.path.exists(full_path):
                with open(full_path, "r", encoding="utf-8") as f:
                    return f.read()

        # Try app template directories
        for app_config in settings.INSTALLED_APPS:
            try:
                app_path = __import__(app_config).__path__[0]
                full_path = os.path.join(app_path, "templates", template_path)
                if os.path.exists(full_path):
                    with open(full_path, "r", encoding="utf-8") as f:
                        return f.read()
            except (ImportError, AttributeError):
                continue

        raise FileNotFoundError(f"Template not found: {template_path}")

    def _extract_title(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract page title."""
        title_tag = soup.find("title")
        return title_tag.get_text(strip=True) if title_tag else None

    def _extract_headings(self, soup: BeautifulSoup) -> List[str]:
        """Extract headings (h1-h6)."""
        headings = []
        for i in range(1, 7):
            for heading in soup.find_all(f"h{i}"):
                text = heading.get_text(strip=True)
                if text:
                    headings.append(text)
        return headings

    def _extract_forms(self, soup: BeautifulSoup) -> List[FormInfo]:
        """Extract forms from template."""
        forms = []
        for form_elem in soup.find_all("form"):
            forms.append(FormInfo(form_elem))
        return forms

    def _extract_links(self, soup: BeautifulSoup) -> List[Dict[str, str]]:
        """Extract links from template."""
        links = []
        for link in soup.find_all("a"):
            link_info = {
                "href": link.get("href", ""),
                "text": link.get_text(strip=True),
                "id": link.get("id", ""),
                "class": link.get("class", ""),
            }
            links.append(link_info)
        return links

    def _extract_interactive_elements(
        self, soup: BeautifulSoup
    ) -> List[Dict[str, str]]:
        """Extract interactive elements (buttons, inputs outside forms, etc.)."""
        elements = []

        # Find buttons outside forms
        for button in soup.find_all("button"):
            if not button.find_parent("form"):
                element_info = {
                    "type": "button",
                    "text": button.get_text(strip=True),
                    "id": button.get("id", ""),
                    "class": button.get("class", ""),
                }
                elements.append(element_info)

        # Find clickable elements with event handlers
        for elem in soup.find_all(attrs={"onclick": True}):
            element_info = {
                "type": elem.name,
                "text": elem.get_text(strip=True)[:50],  # Limit text length
                "id": elem.get("id", ""),
                "class": elem.get("class", ""),
                "onclick": elem.get("onclick", ""),
            }
            elements.append(element_info)

        return elements
