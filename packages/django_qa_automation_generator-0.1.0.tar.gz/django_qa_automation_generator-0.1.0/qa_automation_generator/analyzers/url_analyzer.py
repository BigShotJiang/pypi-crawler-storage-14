"""
URL analyzer to discover and analyze Django URL patterns.
"""
import re
from typing import List, Dict, Any, Optional
from django.urls import URLPattern, URLResolver, get_resolver
from django.urls.resolvers import RoutePattern, RegexPattern
from . import config
from .utils import get_view_name, get_app_name_from_view, extract_url_parameters


class URLInfo:
    """Information about a URL pattern."""

    def __init__(
        self,
        pattern: str,
        name: Optional[str],
        view_func: Any,
        app_name: Optional[str],
        namespace: Optional[str] = None,
    ):
        self.pattern = pattern
        self.name = name
        self.view_func = view_func
        self.app_name = app_name
        self.namespace = namespace
        self.view_name = get_view_name(view_func)
        self.parameters = extract_url_parameters(pattern)

    def __repr__(self):
        return f"<URLInfo: {self.pattern} -> {self.view_name}>"

    def get_full_name(self) -> str:
        """Get the full namespaced name of the URL."""
        parts = []
        if self.namespace:
            parts.append(self.namespace)
        if self.name:
            parts.append(self.name)
        return ":".join(parts) if parts else self.pattern

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "pattern": self.pattern,
            "name": self.name,
            "view_name": self.view_name,
            "app_name": self.app_name,
            "namespace": self.namespace,
            "parameters": self.parameters,
            "full_name": self.get_full_name(),
        }


class URLAnalyzer:
    """Analyzes Django URL configuration to discover views."""

    def __init__(self):
        self.url_patterns: List[URLInfo] = []

    def analyze(
        self,
        app_name: Optional[str] = None,
        view_name: Optional[str] = None,
        url_pattern: Optional[str] = None,
    ) -> List[URLInfo]:
        """
        Analyze URL patterns and return matching URLs.

        Args:
            app_name: Filter by app name
            view_name: Filter by view name
            url_pattern: Filter by URL pattern (regex)

        Returns:
            List of URLInfo objects
        """
        resolver = get_resolver()
        self.url_patterns = []
        self._extract_patterns(resolver)

        # Apply filters
        filtered_patterns = self.url_patterns

        if app_name:
            filtered_patterns = [
                p for p in filtered_patterns if p.app_name == app_name
            ]

        if view_name:
            filtered_patterns = [
                p
                for p in filtered_patterns
                if view_name.lower() in p.view_name.lower()
            ]

        if url_pattern:
            pattern_regex = re.compile(url_pattern)
            filtered_patterns = [
                p for p in filtered_patterns if pattern_regex.search(p.pattern)
            ]

        # Exclude patterns based on config
        filtered_patterns = self._apply_exclusions(filtered_patterns)

        return filtered_patterns

    def _extract_patterns(
        self,
        resolver: URLResolver,
        prefix: str = "",
        namespace: Optional[str] = None,
    ) -> None:
        """
        Recursively extract URL patterns from resolver.

        Args:
            resolver: URL resolver
            prefix: URL prefix
            namespace: Current namespace
        """
        for pattern in resolver.url_patterns:
            if isinstance(pattern, URLResolver):
                # Nested URL configuration
                new_prefix = prefix + str(self._get_pattern_string(pattern.pattern))
                new_namespace = namespace
                if pattern.namespace:
                    new_namespace = (
                        f"{namespace}:{pattern.namespace}"
                        if namespace
                        else pattern.namespace
                    )
                self._extract_patterns(pattern, new_prefix, new_namespace)
            elif isinstance(pattern, URLPattern):
                # Actual URL pattern
                pattern_str = prefix + str(self._get_pattern_string(pattern.pattern))
                view_func = pattern.callback
                app_name = get_app_name_from_view(view_func)

                url_info = URLInfo(
                    pattern=pattern_str,
                    name=pattern.name,
                    view_func=view_func,
                    app_name=app_name,
                    namespace=namespace,
                )
                self.url_patterns.append(url_info)

    def _get_pattern_string(self, pattern: Any) -> str:
        """
        Get string representation of a URL pattern.

        Args:
            pattern: URL pattern object

        Returns:
            Pattern string
        """
        if isinstance(pattern, RoutePattern):
            return pattern._route
        elif isinstance(pattern, RegexPattern):
            return pattern._regex
        else:
            return str(pattern)

    def _apply_exclusions(self, patterns: List[URLInfo]) -> List[URLInfo]:
        """
        Apply exclusion filters from config.

        Args:
            patterns: List of URL patterns

        Returns:
            Filtered list
        """
        # Exclude by app name
        patterns = [
            p for p in patterns if p.app_name not in config.EXCLUDED_APPS
        ]

        # Exclude by URL pattern
        for excluded_pattern in config.EXCLUDED_URL_PATTERNS:
            pattern_regex = re.compile(excluded_pattern)
            patterns = [
                p for p in patterns if not pattern_regex.search(p.pattern)
            ]

        return patterns

    def get_apps(self) -> List[str]:
        """
        Get list of unique app names from discovered URLs.

        Returns:
            List of app names
        """
        apps = set()
        for pattern in self.url_patterns:
            if pattern.app_name:
                apps.add(pattern.app_name)
        return sorted(list(apps))

    def get_views_for_app(self, app_name: str) -> List[URLInfo]:
        """
        Get all URL patterns for a specific app.

        Args:
            app_name: App name

        Returns:
            List of URLInfo objects
        """
        return [p for p in self.url_patterns if p.app_name == app_name]
