# System Flow Diagram

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     Django Project                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Views      │  │  Templates   │  │  URL Config  │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│          python manage.py generate_qa_tests                      │
│                  (Management Command)                            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      ANALYZERS                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ URL Analyzer │→ │View Analyzer │→ │Template      │          │
│  │              │  │              │  │Analyzer      │          │
│  │ • Discover   │  │ • View type  │  │ • Forms      │          │
│  │   URLs       │  │ • Templates  │  │ • Inputs     │          │
│  │ • Extract    │  │ • Models     │  │ • Buttons    │          │
│  │   params     │  │ • Forms      │  │ • Links      │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      GENERATORS                                  │
│  ┌──────────────────────────────────────────────────┐           │
│  │         Choose Framework                          │           │
│  └──────────────────────────────────────────────────┘           │
│           │                              │                       │
│           ▼                              ▼                       │
│  ┌──────────────┐              ┌──────────────┐                │
│  │  Selenium    │              │ Playwright   │                │
│  │  Generator   │              │  Generator   │                │
│  │              │              │              │                │
│  │ • WebDriver  │              │ • Page API   │                │
│  │ • Locators   │              │ • Selectors  │                │
│  │ • Waits      │              │ • Expects    │                │
│  └──────────────┘              └──────────────┘                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    JINJA2 TEMPLATES                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  base_test   │  │  conftest    │  │ test_class   │          │
│  │    .j2       │  │    .j2       │  │    .j2       │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                  GENERATED TEST CODE                             │
│  generated_tests/                                                │
│  ├── __init__.py                                                │
│  ├── base_test.py                                               │
│  ├── conftest.py                                                │
│  └── myapp/                                                     │
│      ├── __init__.py                                            │
│      └── test_myapp.py                                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    pytest generated_tests/                       │
│                    (Run Generated Tests)                         │
└─────────────────────────────────────────────────────────────────┘
```

## Detailed Component Flow

### 1. URL Discovery
```
URLAnalyzer
    │
    ├─→ get_resolver()
    │   └─→ Recursively extract patterns
    │
    ├─→ Filter by:
    │   ├─→ App name
    │   ├─→ View name
    │   └─→ URL pattern
    │
    └─→ Apply exclusions
        └─→ Return URLInfo objects
```

### 2. View Analysis
```
ViewAnalyzer
    │
    ├─→ Determine view type
    │   ├─→ Function-based
    │   └─→ Class-based
    │       ├─→ FormView
    │       ├─→ ListView
    │       ├─→ DetailView
    │       └─→ TemplateView
    │
    ├─→ Extract metadata
    │   ├─→ Template name
    │   ├─→ Form class
    │   ├─→ Model
    │   └─→ HTTP methods
    │
    └─→ Trigger template analysis
        └─→ Return ViewInfo object
```

### 3. Template Analysis
```
TemplateAnalyzer
    │
    ├─→ Load template
    │   └─→ Render with context
    │
    ├─→ Parse HTML (BeautifulSoup)
    │
    ├─→ Extract elements
    │   ├─→ Forms
    │   │   ├─→ Inputs
    │   │   ├─→ Textareas
    │   │   ├─→ Selects
    │   │   └─→ Buttons
    │   ├─→ Links
    │   ├─→ Title
    │   └─→ Headings
    │
    └─→ Return TemplateInfo object
```

### 4. Code Generation
```
Generator (Selenium/Playwright)
    │
    ├─→ Setup Jinja2 environment
    │
    ├─→ Generate base files
    │   ├─→ __init__.py
    │   ├─→ base_test.py
    │   └─→ conftest.py
    │
    ├─→ For each view:
    │   │
    │   ├─→ Generate test class
    │   │
    │   ├─→ Generate page load test
    │   │   └─→ Navigate to URL
    │   │       └─→ Assert title
    │   │
    │   └─→ Generate form tests
    │       ├─→ Fill inputs
    │       ├─→ Click submit
    │       └─→ Add TODO assertions
    │
    └─→ Save to files
        └─→ Organized by app
```

## Data Structures

### URLInfo
```python
{
    'pattern': '/blog/post/<slug:slug>/',
    'name': 'post_detail',
    'view_name': 'PostDetailView',
    'app_name': 'blog',
    'namespace': None,
    'parameters': ['slug']
}
```

### ViewInfo
```python
{
    'view_type': 'DetailView',
    'template_name': 'blog/post_detail.html',
    'is_class_based': True,
    'has_form': False,
    'http_methods': ['get'],
    'model': 'Post',
    'template_info': {...}
}
```

### TemplateInfo
```python
{
    'template_path': 'blog/contact.html',
    'title': 'Contact Us',
    'forms': [
        {
            'action': '/contact/',
            'method': 'post',
            'inputs': [
                {'type': 'text', 'name': 'name', 'id': 'id_name'},
                {'type': 'email', 'name': 'email', 'id': 'id_email'}
            ],
            'buttons': [
                {'type': 'submit', 'text': 'Send'}
            ]
        }
    ]
}
```

## Extension Points

### Hooks
```
pre_generate ──→ [Your Hook] ──→ post_generate
                                       │
pre_analyze_view ──→ [Your Hook] ──→ post_analyze_view
                                       │
pre_analyze_template ──→ [Your Hook] ──→ post_analyze_template
```

### Custom Templates
```
Custom Templates Directory
    │
    ├─→ selenium/
    │   ├─→ base_test.j2
    │   ├─→ conftest.j2
    │   └─→ test_method.j2
    │
    └─→ playwright/
        ├─→ base_test.j2
        ├─→ conftest.j2
        └─→ test_method.j2
```

## Configuration Flow
```
settings.py
    │
    ├─→ QA_AUTOMATION_FRAMEWORK
    ├─→ QA_AUTOMATION_OUTPUT_DIR
    ├─→ QA_AUTOMATION_BASE_URL
    ├─→ QA_AUTOMATION_BROWSER
    ├─→ QA_AUTOMATION_EXCLUDED_APPS
    └─→ QA_AUTOMATION_TEMPLATES_DIR
    │
    ▼
config.py (with defaults)
    │
    ▼
Used by Analyzers & Generators
```
