#!/bin/bash

# Django QA Automation Code Generator - Quick Setup Script
# This script helps you get started quickly with the library

set -e

echo "🚀 Django QA Automation Code Generator - Quick Setup"
echo "=================================================="
echo ""

# Check Python version
echo "📋 Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "   Python version: $python_version"
echo ""

# Create virtual environment
echo "🔧 Creating virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "   ✓ Virtual environment created"
else
    echo "   ✓ Virtual environment already exists"
fi
echo ""

# Activate virtual environment
echo "🔌 Activating virtual environment..."
source venv/bin/activate
echo "   ✓ Virtual environment activated"
echo ""

# Install package in development mode
echo "📦 Installing package in development mode..."
pip install -e . > /dev/null 2>&1
echo "   ✓ Package installed"
echo ""

# Install test dependencies
echo "🧪 Installing test dependencies..."
read -p "   Which framework? (1) Selenium (2) Playwright (3) Both [1]: " framework
framework=${framework:-1}

case $framework in
    1)
        pip install selenium pytest pytest-django > /dev/null 2>&1
        echo "   ✓ Selenium and pytest installed"
        ;;
    2)
        pip install playwright pytest pytest-django > /dev/null 2>&1
        playwright install > /dev/null 2>&1
        echo "   ✓ Playwright and pytest installed"
        ;;
    3)
        pip install selenium playwright pytest pytest-django > /dev/null 2>&1
        playwright install > /dev/null 2>&1
        echo "   ✓ Both Selenium and Playwright installed"
        ;;
esac
echo ""

# Run tests
echo "🧪 Running unit tests..."
if pytest tests/ -v; then
    echo "   ✓ All tests passed!"
else
    echo "   ⚠️  Some tests failed (this is okay for initial setup)"
fi
echo ""

# Summary
echo "✅ Setup Complete!"
echo ""
echo "📚 Next Steps:"
echo "   1. Add 'qa_automation_generator' to your Django INSTALLED_APPS"
echo "   2. Run: python manage.py generate_qa_tests"
echo "   3. Review generated tests in 'generated_tests/' directory"
echo "   4. Run tests: pytest generated_tests/"
echo ""
echo "📖 Documentation:"
echo "   - Quick Start: QUICKSTART.md"
echo "   - Full Guide: INSTALLATION_GUIDE.md"
echo "   - Examples: examples/README.md"
echo ""
echo "🎉 Happy Testing!"
