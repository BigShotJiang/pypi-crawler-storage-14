# Architecture Documentation

## Overview

The Django QA Automation Code Generator is designed with a modular architecture that separates concerns into distinct components:

1. **Analyzers** - Discover and analyze Django components
2. **Generators** - Generate test code from analyzed information
3. **Templates** - Jinja2 templates for code generation
4. **Management Commands** - Django commands for user interaction
5. **Configuration** - Settings and customization

## Component Details

### 1. Analyzers

Located in `qa_automation_generator/analyzers/`

#### URLAnalyzer
- Discovers URL patterns from Django's URL configuration
- Extracts view functions, URL parameters, and namespaces
- Filters URLs based on app, view name, or pattern
- Applies exclusion rules from configuration

#### TemplateAnalyzer
- Parses Django templates to extract testable elements
- Identifies forms, inputs, buttons, and links
- Extracts page metadata (title, headings)
- Handles template rendering with BeautifulSoup

#### ViewAnalyzer
- Analyzes Django views (both function-based and class-based)
- Determines view type (FormView, ListView, etc.)
- Extracts template names, form classes, and models
- Integrates with TemplateAnalyzer for complete view information

### 2. Generators

Located in `qa_automation_generator/generators/`

#### BaseGenerator (Abstract)
- Provides common functionality for all generators
- Manages Jinja2 template environment
- Handles file creation and organization
- Generates base test files and fixtures

#### SeleniumGenerator
- Generates Selenium WebDriver test code
- Creates appropriate locators (By.ID, By.CSS_SELECTOR, etc.)
- Generates page load and form submission tests
- Produces unittest or pytest style tests

#### PlaywrightGenerator
- Generates Playwright test code
- Uses Playwright's modern selector syntax
- Creates async/sync test methods
- Integrates with pytest fixtures

### 3. Templates

Located in `qa_automation_generator/templates/`

Templates are organized by framework:
- `selenium/` - Selenium-specific templates
- `playwright/` - Playwright-specific templates

Each framework has:
- `base_test.j2` - Base test class template
- `conftest.j2` - Pytest configuration template
- `test_class.j2` - Test class template (optional)
- `test_method.j2` - Test method template (optional)

### 4. Management Commands

Located in `qa_automation_generator/management/commands/`

#### generate_qa_tests
- Main command for generating tests
- Accepts filtering arguments (app, view, URL pattern)
- Orchestrates analyzers and generators
- Provides user feedback and progress information

### 5. Configuration

Located in `qa_automation_generator/config.py`

Centralizes all configuration settings with sensible defaults:
- Framework selection (Selenium/Playwright)
- Output directory
- Browser selection
- Exclusion rules
- Test style (pytest/unittest)

## Data Flow

```
1. User runs management command
   ↓
2. URLAnalyzer discovers URL patterns
   ↓
3. For each URL:
   - ViewAnalyzer analyzes the view
   - TemplateAnalyzer analyzes templates
   ↓
4. Generator creates test code using templates
   ↓
5. Test files are saved to output directory
```

## Extension Points

### Hooks

The hook system allows extending functionality:

```python
from qa_automation_generator.hooks import register_hook

@register_hook('post_generate')
def custom_hook(generated_code, view_info):
    # Modify generated code
    return modified_code
```

Available hooks:
- `pre_generate` - Before code generation
- `post_generate` - After code generation
- `pre_analyze_view` - Before view analysis
- `post_analyze_view` - After view analysis
- `pre_analyze_template` - Before template analysis
- `post_analyze_template` - After template analysis

### Custom Templates

Users can provide custom Jinja2 templates:

```python
# settings.py
QA_AUTOMATION_TEMPLATES_DIR = 'path/to/templates'
```

Templates have access to:
- `view_info` - ViewInfo object
- `url_info` - URLInfo object
- `config` - Configuration settings
- Custom filters (sanitize, camel_to_snake, etc.)

## Design Decisions

### Why Jinja2?
- Familiar to Django developers
- Powerful templating features
- Easy to customize and extend

### Why Separate Analyzers?
- Single Responsibility Principle
- Easier to test and maintain
- Allows independent evolution

### Why Abstract Generator?
- Code reuse between frameworks
- Consistent interface
- Easy to add new frameworks

### Why Management Command?
- Natural Django integration
- Familiar to Django developers
- Easy to integrate into workflows

## Future Enhancements

Potential areas for expansion:

1. **Page Object Model Generation**
   - Generate Page Object classes
   - Separate page logic from tests

2. **API Test Generation**
   - Generate tests for Django REST Framework views
   - Support for API clients (requests, httpx)

3. **Visual Regression Testing**
   - Integration with visual testing tools
   - Screenshot comparison

4. **Test Data Generation**
   - Generate fixtures and factory classes
   - Model-based test data

5. **CI/CD Integration**
   - GitHub Actions workflows
   - GitLab CI templates

## Performance Considerations

- Template analysis can be slow for complex templates
- URL discovery is cached during command execution
- File I/O is minimized by batching writes
- BeautifulSoup parsing is done once per template

## Security Considerations

- Template rendering uses safe context
- No arbitrary code execution
- File writes are restricted to output directory
- URL patterns are validated before use
