#!/bin/bash

# Quick Publish Script for PyPI
# This script builds and publishes the package to PyPI

set -e

echo "🚀 Django QA Automation Code Generator - Publishing to PyPI"
echo "============================================================"
echo ""

# Check if we're in the right directory
if [ ! -f "setup.py" ]; then
    echo "❌ Error: setup.py not found. Are you in the project root?"
    exit 1
fi

# Clean previous builds
echo "🧹 Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info
echo "   ✓ Cleaned"
echo ""

# Install/upgrade build tools
echo "📦 Installing build tools..."
pip install --upgrade build twine > /dev/null 2>&1
echo "   ✓ Build tools ready"
echo ""

# Build the package
echo "🔨 Building package..."
python -m build
echo "   ✓ Package built"
echo ""

# Show what was built
echo "📋 Built files:"
ls -lh dist/
echo ""

# Ask for confirmation
read -p "🤔 Upload to PyPI? (y/N): " confirm
if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
    echo "❌ Upload cancelled"
    exit 0
fi

# Upload to PyPI
echo ""
echo "📤 Uploading to PyPI..."
echo "   (You'll need to enter your PyPI credentials)"
echo ""
twine upload dist/*

echo ""
echo "✅ Successfully published to PyPI!"
echo ""
echo "📦 Install with: pip install django-qa-automation-generator"
echo "🌐 View at: https://pypi.org/project/django-qa-automation-generator/"
echo ""
