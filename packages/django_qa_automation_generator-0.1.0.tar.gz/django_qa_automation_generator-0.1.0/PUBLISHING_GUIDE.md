# Publishing Guide

This guide walks you through publishing the Django QA Automation Code Generator to GitHub and PyPI.

## Prerequisites

- GitHub account
- PyPI account (create at https://pypi.org/account/register/)
- Git installed locally
- Python 3.8+ installed

## Part 1: Publishing to GitHub

### Step 1: Initialize Git Repository

```bash
cd /Users/abhinavdev/PycharmProjects/qa-automation-code-generator

# Initialize git if not already done
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Django QA Automation Code Generator v0.1.0"
```

### Step 2: Create GitHub Repository

1. Go to https://github.com/new
2. Repository name: `django-qa-automation-generator`
3. Description: "A Django library that automatically generates automation test code for Django views"
4. Choose Public or Private
5. **Do NOT** initialize with README (we already have one)
6. Click "Create repository"

### Step 3: Push to GitHub

```bash
# Add GitHub remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/django-qa-automation-generator.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### Step 4: Configure GitHub Repository

1. Go to your repository on GitHub
2. Click "Settings" → "Secrets and variables" → "Actions"
3. Add repository secret:
   - Name: `PYPI_API_TOKEN`
   - Value: (your PyPI API token - we'll create this in Part 2)

### Step 5: Add Topics and Description

1. On your repository page, click the gear icon next to "About"
2. Add topics: `django`, `testing`, `automation`, `selenium`, `playwright`, `code-generation`
3. Add website (if you have one)
4. Save changes

## Part 2: Publishing to PyPI

### Step 1: Create PyPI Account

1. Go to https://pypi.org/account/register/
2. Create account and verify email
3. Enable 2FA (recommended)

### Step 2: Create API Token

1. Go to https://pypi.org/manage/account/token/
2. Click "Add API token"
3. Token name: `django-qa-automation-generator`
4. Scope: "Entire account" (for first upload) or specific project (for updates)
5. Copy the token (starts with `pypi-`)
6. **Save this token securely** - you won't see it again!

### Step 3: Install Build Tools

```bash
pip install --upgrade build twine
```

### Step 4: Build the Package

```bash
# Clean previous builds
rm -rf dist/ build/ *.egg-info

# Build the package
python -m build
```

This creates:
- `dist/django_qa_automation_generator-0.1.0.tar.gz` (source distribution)
- `dist/django_qa_automation_generator-0.1.0-py3-none-any.whl` (wheel)

### Step 5: Test Upload to TestPyPI (Optional but Recommended)

```bash
# Upload to TestPyPI first
python -m twine upload --repository testpypi dist/*

# You'll be prompted for username and password:
# Username: __token__
# Password: (paste your TestPyPI token)

# Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ django-qa-automation-generator
```

### Step 6: Upload to PyPI

```bash
# Upload to PyPI
python -m twine upload dist/*

# You'll be prompted for username and password:
# Username: __token__
# Password: (paste your PyPI token)
```

### Step 7: Verify Publication

1. Go to https://pypi.org/project/django-qa-automation-generator/
2. Verify package information is correct
3. Test installation:
```bash
pip install django-qa-automation-generator
```

## Part 3: Automated Publishing (GitHub Actions)

The repository includes GitHub Actions workflows for automated publishing.

### Setup

1. Add PyPI API token to GitHub secrets (done in Part 1, Step 4)
2. The workflow will automatically publish to PyPI when you create a release

### Creating a Release

```bash
# Tag the release
git tag -a v0.1.0 -m "Release version 0.1.0"
git push origin v0.1.0
```

Or create a release through GitHub UI:
1. Go to your repository
2. Click "Releases" → "Create a new release"
3. Tag: `v0.1.0`
4. Title: `Version 0.1.0`
5. Description: Copy from CHANGELOG.md
6. Click "Publish release"

The GitHub Action will automatically build and publish to PyPI!

## Part 4: Post-Publication Tasks

### Update README Badges

Add badges to README.md:

```markdown
[![PyPI version](https://badge.fury.io/py/django-qa-automation-generator.svg)](https://badge.fury.io/py/django-qa-automation-generator)
[![Python versions](https://img.shields.io/pypi/pyversions/django-qa-automation-generator.svg)](https://pypi.org/project/django-qa-automation-generator/)
[![Django versions](https://img.shields.io/pypi/djversions/django-qa-automation-generator.svg)](https://pypi.org/project/django-qa-automation-generator/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Tests](https://github.com/YOUR_USERNAME/django-qa-automation-generator/workflows/Tests/badge.svg)](https://github.com/YOUR_USERNAME/django-qa-automation-generator/actions)
```

### Announce the Release

- Post on Reddit (r/django, r/Python)
- Tweet about it
- Share on LinkedIn
- Post in Django forums
- Add to Django Packages (https://djangopackages.org/)

### Monitor

- Watch for issues on GitHub
- Monitor PyPI download statistics
- Respond to questions and feedback

## Updating the Package

### For Bug Fixes (0.1.0 → 0.1.1)

```bash
# Update version in setup.py and pyproject.toml
# Update CHANGELOG.md
git add .
git commit -m "Bump version to 0.1.1"
git tag -a v0.1.1 -m "Release version 0.1.1"
git push origin main
git push origin v0.1.1
```

### For New Features (0.1.0 → 0.2.0)

```bash
# Update version in setup.py and pyproject.toml
# Update CHANGELOG.md
git add .
git commit -m "Bump version to 0.2.0"
git tag -a v0.2.0 -m "Release version 0.2.0"
git push origin main
git push origin v0.2.0
```

## Troubleshooting

### Issue: "File already exists"

**Solution**: You're trying to upload a version that already exists. Increment the version number.

### Issue: "Invalid credentials"

**Solution**: 
- Ensure you're using `__token__` as username
- Verify your API token is correct
- Check token hasn't expired

### Issue: "Package name already taken"

**Solution**: Choose a different package name in setup.py and pyproject.toml

### Issue: GitHub Action fails

**Solution**:
- Check GitHub Actions logs
- Verify PYPI_API_TOKEN secret is set correctly
- Ensure workflow file syntax is correct

## Quick Reference Commands

```bash
# Build package
python -m build

# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*

# Create and push tag
git tag -a v0.1.0 -m "Release version 0.1.0"
git push origin v0.1.0

# Install from PyPI
pip install django-qa-automation-generator

# Install in development mode
pip install -e .
```

## Checklist

Before publishing:
- [ ] All tests pass
- [ ] Documentation is complete
- [ ] CHANGELOG.md is updated
- [ ] Version number is correct in setup.py and pyproject.toml
- [ ] README.md is accurate
- [ ] LICENSE file is present
- [ ] .gitignore is configured
- [ ] Examples work correctly

After publishing:
- [ ] Verify package on PyPI
- [ ] Test installation: `pip install django-qa-automation-generator`
- [ ] Add badges to README
- [ ] Announce release
- [ ] Monitor for issues

## Resources

- PyPI: https://pypi.org/
- TestPyPI: https://test.pypi.org/
- Python Packaging Guide: https://packaging.python.org/
- GitHub Actions: https://docs.github.com/en/actions
- Django Packages: https://djangopackages.org/

---

**Congratulations on publishing your package!** 🎉
