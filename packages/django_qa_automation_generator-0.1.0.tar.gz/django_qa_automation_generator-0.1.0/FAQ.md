# Frequently Asked Questions (FAQ)

## General Questions

### What is Django QA Automation Code Generator?

It's a Django library that automatically generates automation test code (Selenium or Playwright) for your Django views. Instead of manually writing tests for each view, this library analyzes your Django project and generates ready-to-run test code.

### Why should I use this library?

- **Save Time**: Automatically generate boilerplate test code
- **Consistency**: All tests follow the same structure
- **Coverage**: Ensure all views have basic tests
- **Learning**: Study generated tests to learn testing patterns
- **Maintenance**: Regenerate tests when views change

### What frameworks are supported?

Currently supports:
- **Selenium WebDriver** (Chrome, Firefox, Edge)
- **Playwright** (Chromium, Firefox, WebKit)

### Is this production-ready?

Yes! The library is fully functional and includes:
- Comprehensive error handling
- Extensive documentation
- Unit tests
- Example project
- Type hints and docstrings

## Installation & Setup

### How do I install it?

```bash
pip install django-qa-automation-generator
```

Then add to `INSTALLED_APPS`:
```python
INSTALLED_APPS = [
    # ...
    'qa_automation_generator',
]
```

### What are the dependencies?

Core dependencies:
- Django 3.2+
- Jinja2
- BeautifulSoup4
- lxml

Optional (choose one or both):
- selenium (for Selenium tests)
- playwright (for Playwright tests)

### Do I need to configure anything?

No, it works out of the box with sensible defaults. However, you can customize:
- Framework (Selenium/Playwright)
- Output directory
- Base URL
- Browser
- Excluded apps
- And more...

## Usage

### How do I generate tests?

Basic usage:
```bash
python manage.py generate_qa_tests
```

With options:
```bash
python manage.py generate_qa_tests --app myapp --framework playwright
```

### Can I generate tests for specific views only?

Yes! Use filters:
```bash
# Specific app
python manage.py generate_qa_tests --app blog

# Specific view
python manage.py generate_qa_tests --view blog.views.PostListView

# URL pattern
python manage.py generate_qa_tests --url-pattern /api/
```

### What if I have existing tests?

By default, the library won't overwrite existing files. Use `--overwrite` to replace them:
```bash
python manage.py generate_qa_tests --overwrite
```

### How do I run the generated tests?

```bash
# Install test framework
pip install pytest pytest-django selenium
# or
pip install pytest pytest-django playwright
playwright install

# Run tests
pytest generated_tests/
```

## Generated Code

### What does the generated code look like?

**Selenium example:**
```python
class TestMyView(BaseTest):
    def test_my_view_loads(self):
        self.driver.get(f"{self.base_url}/myapp/myview/")
        assert "Expected Title" in self.driver.title
```

**Playwright example:**
```python
class TestMyView:
    def test_my_view_loads(self, page: Page):
        page.goto("/myapp/myview/")
        expect(page).to_have_title("Expected Title")
```

### What tests are generated?

For each view:
1. **Page load test**: Verifies the page loads successfully
2. **Form tests**: For views with forms, generates form submission tests
3. **Basic assertions**: Title checks and element presence

### Can I customize the generated code?

Yes, in several ways:
1. **Edit after generation**: Modify generated files
2. **Custom templates**: Provide your own Jinja2 templates
3. **Hooks**: Use the hook system to modify code during generation
4. **Configuration**: Adjust settings to change output style

### Do I need to modify the generated tests?

Yes, the generated tests provide a foundation. You should:
- Add specific assertions for your business logic
- Handle authentication if needed
- Add test data setup
- Customize selectors if needed

## Features & Capabilities

### What types of views are supported?

All Django views:
- Function-based views
- Class-based views (TemplateView, FormView, ListView, DetailView, etc.)
- Generic views
- Custom views

### Does it handle forms?

Yes! The library:
- Detects forms in templates
- Identifies input fields
- Generates code to fill forms
- Clicks submit buttons
- Adds TODO comments for assertions

### What about authentication?

Generated tests don't include authentication by default. You should:
1. Extend the base test class with login methods
2. Use pytest fixtures for authentication
3. Modify generated tests to call login before testing

### Can it handle AJAX/JavaScript?

The library analyzes static HTML templates. For JavaScript-heavy apps:
- Generated tests provide a starting point
- You'll need to add waits for dynamic content
- Consider using Playwright for better JavaScript support

### Does it support REST APIs?

Currently focused on HTML views. API testing support is planned for future versions.

## Customization

### How do I use custom templates?

1. Create a templates directory:
```bash
mkdir -p custom_templates/selenium
```

2. Create custom templates (e.g., `base_test.j2`)

3. Configure in settings:
```python
QA_AUTOMATION_TEMPLATES_DIR = 'custom_templates'
```

### How do I use hooks?

```python
from qa_automation_generator.hooks import register_hook

@register_hook('post_generate')
def add_custom_imports(generated_code, view_info):
    custom_import = "from myapp.utils import helper\n"
    return custom_import + generated_code
```

### Can I exclude certain apps or URLs?

Yes, in settings:
```python
QA_AUTOMATION_EXCLUDED_APPS = ['admin', 'debug_toolbar']
QA_AUTOMATION_EXCLUDED_URL_PATTERNS = [r'^/admin/', r'^/static/']
```

## Troubleshooting

### No URL patterns found

**Causes:**
- Views not registered in urls.py
- App excluded in settings
- Filters too restrictive

**Solutions:**
- Check URL configuration
- Review `QA_AUTOMATION_EXCLUDED_APPS`
- Try without filters first

### Template analysis fails

**Causes:**
- Template rendering errors
- Missing context variables
- Complex template logic

**Solutions:**
- The library continues with basic analysis
- Ensure templates can render with empty context
- Check template syntax

### Generated tests don't run

**Causes:**
- Missing dependencies
- Incorrect base URL
- Import errors

**Solutions:**
```bash
# Install dependencies
pip install selenium pytest pytest-django

# Check base URL in settings
QA_AUTOMATION_BASE_URL = 'http://localhost:8000'

# Verify Django server is running
python manage.py runserver
```

### Import errors in tests

**Causes:**
- Missing base files
- Incorrect Python path

**Solutions:**
- Ensure `base_test.py` and `conftest.py` exist
- Check `__init__.py` files in test directories
- Verify `generated_tests/` is in Python path

### Tests timeout

**Causes:**
- Elements loading slowly
- Network issues
- Incorrect selectors

**Solutions:**
```python
# Increase timeout in settings
QA_AUTOMATION_WAIT_TIMEOUT = 30
```

## Best Practices

### Should I commit generated tests?

Yes! Generated tests should be:
- Committed to version control
- Reviewed before committing
- Customized for your needs
- Updated when views change

### How often should I regenerate?

Regenerate when:
- Adding new views
- Modifying existing views
- Changing templates
- Starting a new feature

### Should I edit generated files?

Yes! Generated tests are a starting point:
- Add specific assertions
- Handle authentication
- Add test data
- Improve selectors
- Add comments

### How do I integrate with CI/CD?

```yaml
# Example GitHub Actions
- name: Generate tests
  run: python manage.py generate_qa_tests

- name: Run tests
  run: pytest generated_tests/
```

## Advanced Topics

### Can I generate Page Object Models?

Not yet, but it's planned for a future release. Current workaround:
- Generate tests
- Manually refactor into Page Objects
- Use as reference

### Does it support multiple languages?

The library works with any Django project. For internationalization:
- Tests use the default language
- You may need to customize for multi-language testing

### Can I use with Django REST Framework?

Currently focused on HTML views. For DRF:
- Use for browsable API views
- API endpoint testing planned for future

### How do I contribute?

See [CONTRIBUTING.md](CONTRIBUTING.md) for:
- Development setup
- Code style guidelines
- Testing requirements
- Pull request process

## Performance

### How long does generation take?

Depends on project size:
- Small project (10 views): < 5 seconds
- Medium project (50 views): < 30 seconds
- Large project (200+ views): 1-2 minutes

### Does it slow down my Django project?

No! It's only used during test generation, not in production.

### Can I speed up generation?

- Use filters to generate for specific apps
- Exclude unnecessary apps
- Disable template analysis if not needed

## Support

### Where can I get help?

- **Documentation**: README.md, QUICKSTART.md, INSTALLATION_GUIDE.md
- **Examples**: See examples/ directory
- **Issues**: GitHub issue tracker
- **Contributing**: See CONTRIBUTING.md

### How do I report bugs?

Open a GitHub issue with:
- Python version
- Django version
- Steps to reproduce
- Expected vs actual behavior
- Error messages

### Can I request features?

Yes! Open a GitHub issue with:
- Use case description
- Expected behavior
- Why it would be useful

## License & Legal

### What license is this under?

MIT License - free for commercial and personal use.

### Can I use this commercially?

Yes! The MIT license allows commercial use.

### Do I need to credit the library?

Not required, but appreciated!

### Can I modify the code?

Yes! Fork it, modify it, and even publish your own version.

---

## Still have questions?

- Check the [documentation](README.md)
- Review the [examples](examples/)
- Open an [issue](https://github.com/yourusername/django-qa-automation-generator/issues)

**Happy Testing!** 🚀
