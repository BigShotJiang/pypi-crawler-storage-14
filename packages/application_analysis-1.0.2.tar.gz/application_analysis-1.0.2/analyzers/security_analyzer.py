import ast
import re
from pathlib import Path
from typing import Optional

from models.findings import (
    StaticCollectorResult,
    SecurityFinding,
    Severity,
    FindingCategory,
)


SECRET_PATTERNS = [
    (r'(?i)(api[_-]?key|apikey)\s*[=:]\s*["\']([a-zA-Z0-9_\-]{20,})["\']', 'API Key'),
    (r'(?i)(secret[_-]?key|secretkey)\s*[=:]\s*["\']([a-zA-Z0-9_\-]{16,})["\']', 'Secret Key'),
    (r'(?i)(password|passwd|pwd)\s*[=:]\s*["\']([^"\']{8,})["\']', 'Password'),
    (r'(?i)(token|auth[_-]?token|access[_-]?token)\s*[=:]\s*["\']([a-zA-Z0-9_\-\.]{20,})["\']', 'Token'),
    (r'(?i)(private[_-]?key)\s*[=:]\s*["\']([^"\']{20,})["\']', 'Private Key'),
    (r'(?i)(aws[_-]?access[_-]?key[_-]?id)\s*[=:]\s*["\']([A-Z0-9]{20})["\']', 'AWS Access Key'),
    (r'(?i)(aws[_-]?secret[_-]?access[_-]?key)\s*[=:]\s*["\']([a-zA-Z0-9/+=]{40})["\']', 'AWS Secret Key'),
    (r'(?i)(database[_-]?url|db[_-]?url)\s*[=:]\s*["\']([^"\']*://[^"\']+)["\']', 'Database URL'),
    (r'(?i)(connection[_-]?string)\s*[=:]\s*["\']([^"\']{20,})["\']', 'Connection String'),
    (r'(ghp_[a-zA-Z0-9]{36})', 'GitHub Token'),
    (r'(sk-[a-zA-Z0-9]{48})', 'OpenAI API Key'),
    (r'(xox[baprs]-[a-zA-Z0-9-]{10,})', 'Slack Token'),
    (r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----', 'Private Key Block'),
    (r'(?i)(bearer\s+)[a-zA-Z0-9_\-\.]{20,}', 'Bearer Token'),
]

DANGEROUS_FUNCTIONS = {
    'eval': {
        'risk': 'Code Injection',
        'severity': Severity.CRITICAL,
        'remediation': 'Use ast.literal_eval() for safe evaluation of literals, or avoid dynamic code execution entirely',
    },
    'exec': {
        'risk': 'Code Injection',
        'severity': Severity.CRITICAL,
        'remediation': 'Avoid exec() with user input. Consider using a sandboxed environment or pre-defined functions',
    },
    '__import__': {
        'risk': 'Arbitrary Module Import',
        'severity': Severity.HIGH,
        'remediation': 'Use importlib with explicit module names instead of dynamic imports',
    },
}

SQL_PATTERNS = [
    r'execute\s*\(\s*["\'].*%s.*["\']',
    r'execute\s*\(\s*f["\'].*\{.*\}.*["\']',
    r'execute\s*\(\s*["\'].*\+.*["\']',
    r'cursor\.execute\s*\(\s*["\'].*%.*["\']',
    r'\.format\s*\(.*\).*execute',
    r'SELECT.*FROM.*WHERE.*\+',
    r'INSERT.*INTO.*VALUES.*\+',
    r'UPDATE.*SET.*WHERE.*\+',
    r'DELETE.*FROM.*WHERE.*\+',
]

SHELL_PATTERNS = [
    (r'subprocess\.(call|run|Popen)\s*\([^)]*shell\s*=\s*True', 'subprocess with shell=True'),
    (r'os\.system\s*\(', 'os.system()'),
    (r'os\.popen\s*\(', 'os.popen()'),
    (r'commands\.(getoutput|getstatusoutput)\s*\(', 'commands module'),
]

DESERIALIZATION_PATTERNS = [
    (r'pickle\.loads?\s*\(', 'pickle deserialization'),
    (r'cPickle\.loads?\s*\(', 'cPickle deserialization'),
    (r'marshal\.loads?\s*\(', 'marshal deserialization'),
    (r'yaml\.load\s*\([^)]*\)', 'yaml.load without safe_load'),
    (r'shelve\.open\s*\(', 'shelve deserialization'),
]


class SecurityAnalyzer:
    def __init__(self):
        self.secret_regexes = [(re.compile(p, re.MULTILINE), name) for p, name in SECRET_PATTERNS]
        self.sql_regexes = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in SQL_PATTERNS]
        self.shell_regexes = [(re.compile(p), name) for p, name in SHELL_PATTERNS]
        self.deser_regexes = [(re.compile(p), name) for p, name in DESERIALIZATION_PATTERNS]
    
    def _get_code_snippet(self, file_path: str, line_number: int, project_path: str, context: int = 2) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            start = max(0, line_number - 1 - context)
            end = min(len(lines), line_number + context)
            return ''.join(lines[start:end])
        except Exception:
            return None
    
    def _get_line_number(self, source: str, match_start: int) -> int:
        return source[:match_start].count('\n') + 1
    
    def _mask_secret(self, secret: str) -> str:
        if len(secret) <= 8:
            return '*' * len(secret)
        return secret[:4] + '*' * (len(secret) - 8) + secret[-4:]
    
    def _analyze_secrets(self, static_result: StaticCollectorResult) -> list[SecurityFinding]:
        findings = []
        
        for file_data in static_result.files:
            if 'test' in file_data.path.lower():
                continue
            if file_data.path.endswith('.example') or '.example.' in file_data.path:
                continue
            
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
            except Exception:
                continue
            
            for regex, secret_type in self.secret_regexes:
                for match in regex.finditer(source):
                    line_num = self._get_line_number(source, match.start())
                    
                    if len(match.groups()) >= 2:
                        secret_value = match.group(2)
                    else:
                        secret_value = match.group(0)
                    
                    masked = self._mask_secret(secret_value)
                    
                    findings.append(SecurityFinding(
                        file_path=file_data.path,
                        line_number=line_num,
                        severity=Severity.CRITICAL,
                        category=FindingCategory.SECURITY,
                        title=f"Hardcoded {secret_type} detected",
                        description=f"Potential hardcoded {secret_type} found: {masked}",
                        code_snippet=self._get_code_snippet(file_data.path, line_num, static_result.project_path),
                        tags=["hardcoded_secret", secret_type.lower().replace(' ', '_')],
                        security_type="hardcoded_secret",
                        risk_level="Critical",
                        pattern_matched=secret_type,
                        remediation="Move secrets to environment variables or a secure secrets manager"
                    ))
        
        return findings
    
    def _analyze_dangerous_functions(self, static_result: StaticCollectorResult) -> list[SecurityFinding]:
        findings = []
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
                tree = ast.parse(source)
            except Exception:
                continue
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    func_name = None
                    
                    if isinstance(node.func, ast.Name):
                        func_name = node.func.id
                    elif isinstance(node.func, ast.Attribute):
                        func_name = node.func.attr
                    
                    if func_name in DANGEROUS_FUNCTIONS:
                        info = DANGEROUS_FUNCTIONS[func_name]
                        
                        has_variable_input = False
                        if node.args:
                            first_arg = node.args[0]
                            if not isinstance(first_arg, ast.Constant):
                                has_variable_input = True
                        
                        severity = info['severity'] if has_variable_input else Severity.MEDIUM
                        
                        findings.append(SecurityFinding(
                            file_path=file_data.path,
                            line_number=node.lineno,
                            severity=severity,
                            category=FindingCategory.SECURITY,
                            title=f"Dangerous function: {func_name}()",
                            description=f"Use of {func_name}() detected. Risk: {info['risk']}",
                            code_snippet=self._get_code_snippet(file_data.path, node.lineno, static_result.project_path),
                            tags=["dangerous_function", func_name],
                            security_type="eval_exec",
                            risk_level="Critical" if has_variable_input else "Medium",
                            pattern_matched=func_name,
                            remediation=info['remediation']
                        ))
        
        return findings
    
    def _analyze_shell_injection(self, static_result: StaticCollectorResult) -> list[SecurityFinding]:
        findings = []
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
            except Exception:
                continue
            
            for regex, pattern_name in self.shell_regexes:
                for match in regex.finditer(source):
                    line_num = self._get_line_number(source, match.start())
                    
                    findings.append(SecurityFinding(
                        file_path=file_data.path,
                        line_number=line_num,
                        severity=Severity.HIGH,
                        category=FindingCategory.SECURITY,
                        title=f"Shell injection risk: {pattern_name}",
                        description=f"Use of {pattern_name} can lead to command injection vulnerabilities",
                        code_snippet=self._get_code_snippet(file_data.path, line_num, static_result.project_path),
                        tags=["shell_injection", "command_injection"],
                        security_type="shell_injection",
                        risk_level="High",
                        pattern_matched=pattern_name,
                        remediation="Use subprocess.run() with shell=False and pass arguments as a list"
                    ))
        
        return findings
    
    def _analyze_sql_injection(self, static_result: StaticCollectorResult) -> list[SecurityFinding]:
        findings = []
        
        for file_data in static_result.files:
            if 'security_analyzer' in file_data.path.lower():
                continue
            
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
            except Exception:
                continue
            
            for regex in self.sql_regexes:
                for match in regex.finditer(source):
                    line_num = self._get_line_number(source, match.start())
                    
                    line_start = source.rfind('\n', 0, match.start()) + 1
                    line_end = source.find('\n', match.end())
                    if line_end == -1:
                        line_end = len(source)
                    line = source[line_start:line_end]
                    
                    if line.strip().startswith('#') or line.strip().startswith('r"') or line.strip().startswith("r'"):
                        continue
                    if 'SQL_PATTERNS' in line or 'sql_regexes' in line:
                        continue
                    
                    findings.append(SecurityFinding(
                        file_path=file_data.path,
                        line_number=line_num,
                        severity=Severity.HIGH,
                        category=FindingCategory.SECURITY,
                        title="Potential SQL injection vulnerability",
                        description="SQL query appears to use string formatting with user input",
                        code_snippet=self._get_code_snippet(file_data.path, line_num, static_result.project_path),
                        tags=["sql_injection", "database"],
                        security_type="sql_injection",
                        risk_level="High",
                        pattern_matched="string interpolation in SQL",
                        remediation="Use parameterized queries or an ORM to prevent SQL injection"
                    ))
        
        return findings
    
    def _analyze_unsafe_deserialization(self, static_result: StaticCollectorResult) -> list[SecurityFinding]:
        findings = []
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
            except Exception:
                continue
            
            for regex, pattern_name in self.deser_regexes:
                for match in regex.finditer(source):
                    line_num = self._get_line_number(source, match.start())
                    
                    if 'yaml.load' in pattern_name:
                        if 'Loader=' in source[match.start():match.end() + 50]:
                            continue
                    
                    findings.append(SecurityFinding(
                        file_path=file_data.path,
                        line_number=line_num,
                        severity=Severity.HIGH,
                        category=FindingCategory.SECURITY,
                        title=f"Unsafe deserialization: {pattern_name}",
                        description=f"Use of {pattern_name} with untrusted data can lead to arbitrary code execution",
                        code_snippet=self._get_code_snippet(file_data.path, line_num, static_result.project_path),
                        tags=["unsafe_deserialization", "pickle"],
                        security_type="pickle_deserialize",
                        risk_level="High",
                        pattern_matched=pattern_name,
                        remediation="Use json or other safe serialization formats, or validate data source"
                    ))
        
        return findings
    
    def analyze(self, static_result: StaticCollectorResult) -> list[SecurityFinding]:
        findings = []
        
        findings.extend(self._analyze_secrets(static_result))
        findings.extend(self._analyze_dangerous_functions(static_result))
        findings.extend(self._analyze_shell_injection(static_result))
        findings.extend(self._analyze_sql_injection(static_result))
        findings.extend(self._analyze_unsafe_deserialization(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings


