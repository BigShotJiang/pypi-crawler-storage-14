import ast
from pathlib import Path
from typing import Optional

import networkx as nx
from radon.complexity import cc_visit
from radon.metrics import mi_visit

from models.findings import (
    StaticCollectorResult,
    ComplexityFinding,
    Severity,
    FindingCategory,
)


CYCLOMATIC_THRESHOLDS = {
    'low': 15,
    'medium': 25,
    'high': 40,
    'very_high': 60
}

NESTING_THRESHOLDS = {
    'low': 6,
    'medium': 8,
    'high': 10
}

LOC_THRESHOLDS = {
    'function': {'medium': 100, 'high': 200, 'very_high': 400},
    'file': {'medium': 1000, 'high': 2000, 'very_high': 4000},
    'class': {'medium': 400, 'high': 800, 'very_high': 1500}
}

LAYER_KEYWORDS = {
    'api': ['api', 'route', 'endpoint', 'view', 'controller', 'handler', 'rest'],
    'service': ['service', 'manager', 'processor', 'engine', 'orchestrator'],
    'repository': ['repository', 'repo', 'dao', 'store', 'persistence', 'database', 'db'],
    'model': ['model', 'entity', 'domain', 'schema', 'dto'],
    'utility': ['util', 'utils', 'helper', 'helpers', 'common', 'shared', 'lib']
}


class ComplexityAnalyzer:
    def __init__(self):
        self.import_graph: Optional[nx.DiGraph] = None
        self.module_layers: dict[str, str] = {}
    
    def _classify_layer(self, module_path: str) -> str:
        path_lower = module_path.lower()
        
        for layer, keywords in LAYER_KEYWORDS.items():
            for keyword in keywords:
                if keyword in path_lower:
                    return layer
        
        return 'unknown'
    
    def _build_import_graph(self, static_result: StaticCollectorResult) -> nx.DiGraph:
        graph = nx.DiGraph()
        
        for file_data in static_result.files:
            module_name = file_data.path.replace('/', '.').replace('\\', '.').rstrip('.py')
            if module_name.endswith('.__init__'):
                module_name = module_name[:-9]
            graph.add_node(module_name)
            self.module_layers[module_name] = self._classify_layer(file_data.path)
        
        for file_data in static_result.files:
            module_name = file_data.path.replace('/', '.').replace('\\', '.').rstrip('.py')
            if module_name.endswith('.__init__'):
                module_name = module_name[:-9]
            
            for imp in file_data.imports:
                if imp.import_type == 'local':
                    target_module = imp.module
                    if target_module in graph.nodes:
                        graph.add_edge(module_name, target_module)
                    else:
                        parts = target_module.split('.')
                        for i in range(len(parts), 0, -1):
                            partial = '.'.join(parts[:i])
                            if partial in graph.nodes:
                                graph.add_edge(module_name, partial)
                                break
        
        return graph
    
    def _get_code_snippet(self, file_path: str, line_number: int, project_path: str, context: int = 3) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            start = max(0, line_number - 1 - context)
            end = min(len(lines), line_number + context)
            return ''.join(lines[start:end])
        except Exception:
            return None
    
    def _read_source(self, file_path: str, project_path: str) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                return f.read()
        except Exception:
            return None
    
    def _analyze_cyclomatic_complexity(self, static_result: StaticCollectorResult) -> list[ComplexityFinding]:
        findings = []
        
        for file_data in static_result.files:
            source = self._read_source(file_data.path, static_result.project_path)
            if not source:
                continue
            
            try:
                blocks = cc_visit(source)
            except Exception:
                continue
            
            for block in blocks:
                complexity = block.complexity
                
                if complexity >= CYCLOMATIC_THRESHOLDS['very_high']:
                    severity = Severity.CRITICAL
                elif complexity >= CYCLOMATIC_THRESHOLDS['high']:
                    severity = Severity.HIGH
                elif complexity >= CYCLOMATIC_THRESHOLDS['medium']:
                    severity = Severity.MEDIUM
                elif complexity >= CYCLOMATIC_THRESHOLDS['low']:
                    severity = Severity.LOW
                else:
                    continue
                
                class_name = block.classname if hasattr(block, 'classname') else None
                func_name = block.name
                
                findings.append(ComplexityFinding(
                    file_path=file_data.path,
                    line_number=block.lineno,
                    end_line=block.endline if hasattr(block, 'endline') else block.lineno,
                    severity=severity,
                    category=FindingCategory.COMPLEXITY,
                    title=f"High cyclomatic complexity: {func_name}",
                    description=f"Function '{func_name}' has cyclomatic complexity of {complexity} (threshold: {CYCLOMATIC_THRESHOLDS['low']})",
                    code_snippet=self._get_code_snippet(file_data.path, block.lineno, static_result.project_path),
                    tags=["cyclomatic_complexity", "refactor_candidate"],
                    complexity_type="cyclomatic",
                    metric_value=float(complexity),
                    threshold=float(CYCLOMATIC_THRESHOLDS['low']),
                    function_name=func_name,
                    class_name=class_name
                ))
        
        return findings
    
    def _analyze_nesting_depth(self, static_result: StaticCollectorResult) -> list[ComplexityFinding]:
        findings = []
        
        for file_data in static_result.files:
            for func in file_data.functions:
                depth = func.nesting_depth
                
                if depth >= NESTING_THRESHOLDS['high']:
                    severity = Severity.HIGH
                elif depth >= NESTING_THRESHOLDS['medium']:
                    severity = Severity.MEDIUM
                elif depth >= NESTING_THRESHOLDS['low']:
                    severity = Severity.LOW
                else:
                    continue
                
                findings.append(ComplexityFinding(
                    file_path=file_data.path,
                    line_number=func.line_number,
                    end_line=func.end_line,
                    severity=severity,
                    category=FindingCategory.COMPLEXITY,
                    title=f"Deep nesting: {func.name}",
                    description=f"Function '{func.name}' has nesting depth of {depth} (threshold: {NESTING_THRESHOLDS['low']})",
                    code_snippet=self._get_code_snippet(file_data.path, func.line_number, static_result.project_path),
                    tags=["nesting_depth", "readability"],
                    complexity_type="nesting",
                    metric_value=float(depth),
                    threshold=float(NESTING_THRESHOLDS['low']),
                    function_name=func.name,
                    class_name=func.class_name
                ))
        
        return findings
    
    def _analyze_loc(self, static_result: StaticCollectorResult) -> list[ComplexityFinding]:
        findings = []
        
        for file_data in static_result.files:
            loc = file_data.code_lines
            thresholds = LOC_THRESHOLDS['file']
            
            if loc >= thresholds['very_high']:
                severity = Severity.HIGH
            elif loc >= thresholds['high']:
                severity = Severity.MEDIUM
            elif loc >= thresholds['medium']:
                severity = Severity.LOW
            else:
                severity = None
            
            if severity:
                findings.append(ComplexityFinding(
                    file_path=file_data.path,
                    line_number=1,
                    severity=severity,
                    category=FindingCategory.COMPLEXITY,
                    title=f"Large file: {file_data.path}",
                    description=f"File has {loc} lines of code (threshold: {thresholds['medium']})",
                    tags=["large_file", "maintainability"],
                    complexity_type="loc",
                    metric_value=float(loc),
                    threshold=float(thresholds['medium'])
                ))
            
            for func in file_data.functions:
                func_loc = func.body_lines
                func_thresholds = LOC_THRESHOLDS['function']
                
                if func_loc >= func_thresholds['very_high']:
                    severity = Severity.HIGH
                elif func_loc >= func_thresholds['high']:
                    severity = Severity.MEDIUM
                elif func_loc >= func_thresholds['medium']:
                    severity = Severity.LOW
                else:
                    continue
                
                findings.append(ComplexityFinding(
                    file_path=file_data.path,
                    line_number=func.line_number,
                    end_line=func.end_line,
                    severity=severity,
                    category=FindingCategory.COMPLEXITY,
                    title=f"Large function: {func.name}",
                    description=f"Function '{func.name}' has {func_loc} lines (threshold: {func_thresholds['medium']})",
                    code_snippet=self._get_code_snippet(file_data.path, func.line_number, static_result.project_path),
                    tags=["large_function", "maintainability"],
                    complexity_type="loc",
                    metric_value=float(func_loc),
                    threshold=float(func_thresholds['medium']),
                    function_name=func.name,
                    class_name=func.class_name
                ))
            
            for cls in file_data.classes:
                cls_loc = cls.end_line - cls.line_number + 1
                cls_thresholds = LOC_THRESHOLDS['class']
                
                if cls_loc >= cls_thresholds['very_high']:
                    severity = Severity.HIGH
                elif cls_loc >= cls_thresholds['high']:
                    severity = Severity.MEDIUM
                elif cls_loc >= cls_thresholds['medium']:
                    severity = Severity.LOW
                else:
                    continue
                
                findings.append(ComplexityFinding(
                    file_path=file_data.path,
                    line_number=cls.line_number,
                    end_line=cls.end_line,
                    severity=severity,
                    category=FindingCategory.COMPLEXITY,
                    title=f"Large class: {cls.name}",
                    description=f"Class '{cls.name}' has {cls_loc} lines (threshold: {cls_thresholds['medium']})",
                    code_snippet=self._get_code_snippet(file_data.path, cls.line_number, static_result.project_path),
                    tags=["large_class", "maintainability"],
                    complexity_type="loc",
                    metric_value=float(cls_loc),
                    threshold=float(cls_thresholds['medium']),
                    class_name=cls.name
                ))
        
        return findings
    
    def _analyze_circular_dependencies(self, static_result: StaticCollectorResult) -> list[ComplexityFinding]:
        findings = []
        
        self.import_graph = self._build_import_graph(static_result)
        
        try:
            cycles = list(nx.simple_cycles(self.import_graph))
        except Exception:
            cycles = []
        
        seen_cycles = set()
        for cycle in cycles:
            if len(cycle) < 2:
                continue
            
            cycle_key = tuple(sorted(cycle))
            if cycle_key in seen_cycles:
                continue
            seen_cycles.add(cycle_key)
            
            cycle_str = ' -> '.join(cycle) + f' -> {cycle[0]}'
            
            findings.append(ComplexityFinding(
                file_path=cycle[0].replace('.', '/') + '.py',
                line_number=1,
                severity=Severity.HIGH,
                category=FindingCategory.COMPLEXITY,
                title=f"Circular dependency detected",
                description=f"Circular import dependency: {cycle_str}",
                tags=["circular_dependency", "architecture"],
                complexity_type="circular_dependency",
                metric_value=float(len(cycle)),
                threshold=0.0
            ))
        
        return findings
    
    def _analyze_hub_modules(self, static_result: StaticCollectorResult) -> list[ComplexityFinding]:
        findings = []
        
        if not self.import_graph:
            self.import_graph = self._build_import_graph(static_result)
        
        hub_threshold = max(3, len(self.import_graph.nodes) * 0.3)
        
        for node in self.import_graph.nodes:
            in_degree = self.import_graph.in_degree(node)
            out_degree = self.import_graph.out_degree(node)
            
            if in_degree >= hub_threshold:
                findings.append(ComplexityFinding(
                    file_path=node.replace('.', '/') + '.py',
                    line_number=1,
                    severity=Severity.MEDIUM,
                    category=FindingCategory.COMPLEXITY,
                    title=f"Hub module (high coupling): {node}",
                    description=f"Module '{node}' is imported by {in_degree} other modules, indicating high coupling",
                    tags=["hub_module", "coupling", "architecture"],
                    complexity_type="coupling",
                    metric_value=float(in_degree),
                    threshold=hub_threshold
                ))
            
            if out_degree >= hub_threshold:
                findings.append(ComplexityFinding(
                    file_path=node.replace('.', '/') + '.py',
                    line_number=1,
                    severity=Severity.LOW,
                    category=FindingCategory.COMPLEXITY,
                    title=f"High dependency count: {node}",
                    description=f"Module '{node}' imports {out_degree} other modules",
                    tags=["high_dependencies", "architecture"],
                    complexity_type="coupling",
                    metric_value=float(out_degree),
                    threshold=hub_threshold
                ))
        
        return findings
    
    def analyze(self, static_result: StaticCollectorResult) -> list[ComplexityFinding]:
        findings = []
        
        findings.extend(self._analyze_cyclomatic_complexity(static_result))
        findings.extend(self._analyze_nesting_depth(static_result))
        findings.extend(self._analyze_loc(static_result))
        findings.extend(self._analyze_circular_dependencies(static_result))
        findings.extend(self._analyze_hub_modules(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings
    
    def get_import_graph(self) -> Optional[nx.DiGraph]:
        return self.import_graph
    
    def get_module_layers(self) -> dict[str, str]:
        return self.module_layers


