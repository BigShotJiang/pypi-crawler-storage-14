import re
import math
from pathlib import Path
from typing import Optional
from collections import Counter

from models.findings import (
    StaticCollectorResult,
    NamingFinding,
    Severity,
    FindingCategory,
)


PROGRAMMING_WHITELIST = {
    'i', 'j', 'k', 'n', 'm', 'x', 'y', 'z',
    'id', 'pk', 'fk', 'db', 'io', 'os', 'fs', 'ui', 'api', 'url', 'uri', 'sql',
    'idx', 'ctx', 'cfg', 'tmp', 'buf', 'ptr', 'ref', 'val', 'var', 'arg', 'args',
    'kwargs', 'cls', 'obj', 'msg', 'err', 'exc', 'req', 'res', 'resp', 'fn', 'func',
    'cb', 'async', 'await', 'init', 'str', 'int', 'bool', 'dict', 'list', 'set',
    'tuple', 'len', 'max', 'min', 'sum', 'avg', 'cnt', 'num', 'src', 'dst', 'dir',
    'cwd', 'env', 'stdin', 'stdout', 'stderr', 'pid', 'tid', 'uid', 'gid',
    'tcp', 'udp', 'http', 'https', 'ssh', 'ftp', 'smtp', 'dns',
    'json', 'xml', 'html', 'css', 'js', 'ts', 'py', 'md', 'yml', 'yaml', 'csv',
    'rgb', 'rgba', 'hex', 'utf', 'ascii', 'unicode',
    'cpu', 'gpu', 'ram', 'rom', 'ssd', 'hdd',
    'ok', 'ko', 'na', 'tbd', 'wip', 'poc', 'mvp', 'qa', 'uat', 'prod', 'dev',
    'df', 'np', 'pd', 'tf', 'pt', 'cv', 'ml', 'ai', 'dl', 'nn', 'lr', 'sgd',
    'rx', 'tx', 'ack', 'syn', 'rst', 'fin',
    'self', 'super', 'none', 'true', 'false', 'null', 'nil',
}

COMMON_WORDS = {
    'get', 'set', 'add', 'remove', 'delete', 'update', 'create', 'read', 'write',
    'load', 'save', 'open', 'close', 'start', 'stop', 'run', 'execute', 'process',
    'handle', 'manage', 'validate', 'check', 'verify', 'test', 'parse', 'format',
    'convert', 'transform', 'map', 'filter', 'reduce', 'sort', 'search', 'find',
    'fetch', 'send', 'receive', 'connect', 'disconnect', 'init', 'setup', 'cleanup',
    'build', 'compile', 'deploy', 'install', 'configure', 'register', 'unregister',
    'enable', 'disable', 'show', 'hide', 'display', 'render', 'draw', 'paint',
    'input', 'output', 'data', 'info', 'result', 'response', 'request', 'query',
    'command', 'action', 'event', 'handler', 'listener', 'callback', 'hook',
    'service', 'manager', 'controller', 'helper', 'util', 'factory', 'builder',
    'adapter', 'wrapper', 'proxy', 'cache', 'pool', 'queue', 'stack', 'buffer',
    'config', 'settings', 'options', 'params', 'context', 'state', 'status',
    'name', 'value', 'key', 'index', 'count', 'size', 'length', 'width', 'height',
    'path', 'file', 'folder', 'directory', 'module', 'package', 'class', 'method',
    'function', 'variable', 'constant', 'property', 'attribute', 'field', 'column',
    'row', 'table', 'database', 'schema', 'model', 'entity', 'record', 'item',
    'element', 'node', 'edge', 'graph', 'tree', 'list', 'array', 'map', 'dict',
    'string', 'number', 'integer', 'float', 'boolean', 'date', 'time', 'datetime',
    'user', 'admin', 'guest', 'role', 'permission', 'auth', 'token', 'session',
    'error', 'warning', 'info', 'debug', 'log', 'trace', 'message', 'exception',
    'success', 'failure', 'pending', 'complete', 'active', 'inactive', 'valid',
    'default', 'custom', 'base', 'parent', 'child', 'root', 'leaf', 'main', 'sub',
    'first', 'last', 'next', 'prev', 'current', 'old', 'new', 'temp', 'final',
    'public', 'private', 'protected', 'internal', 'external', 'local', 'global',
    'async', 'sync', 'parallel', 'sequential', 'batch', 'stream', 'chunk',
    'total', 'partial', 'full', 'empty', 'all', 'any', 'some', 'none',
    'from', 'to', 'by', 'with', 'for', 'on', 'at', 'in', 'of', 'is', 'has', 'can',
    'should', 'must', 'will', 'may', 'not', 'and', 'or', 'the', 'a', 'an',
    'fitness', 'loss', 'accuracy', 'score', 'reward', 'metric', 'epoch', 'step',
    'train', 'test', 'eval', 'predict', 'infer', 'model', 'weight', 'bias',
}

try:
    import enchant
    ENCHANT_AVAILABLE = True
    ENGLISH_DICT = enchant.Dict("en_US")
except ImportError:
    ENCHANT_AVAILABLE = False
    ENGLISH_DICT = None


class NamingAnalyzer:
    def __init__(self):
        self.word_cache: dict[str, bool] = {}
    
    def _split_identifier(self, name: str) -> list[str]:
        tokens = re.sub(r'([a-z])([A-Z])', r'\1_\2', name)
        tokens = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', tokens)
        tokens = tokens.lower().split('_')
        
        result = []
        for token in tokens:
            parts = re.split(r'(\d+)', token)
            result.extend(p for p in parts if p)
        
        return [t for t in result if t]
    
    def _is_valid_word(self, word: str) -> bool:
        if word in self.word_cache:
            return self.word_cache[word]
        
        word_lower = word.lower()
        
        if word_lower in PROGRAMMING_WHITELIST:
            self.word_cache[word] = True
            return True
        
        if word_lower in COMMON_WORDS:
            self.word_cache[word] = True
            return True
        
        if word.isdigit():
            self.word_cache[word] = True
            return True
        
        if ENCHANT_AVAILABLE and ENGLISH_DICT:
            is_valid = ENGLISH_DICT.check(word_lower)
            self.word_cache[word] = is_valid
            return is_valid
        
        if len(word) >= 3:
            self.word_cache[word] = True
            return True
        
        self.word_cache[word] = False
        return False
    
    def _calculate_entropy(self, tokens: list[str]) -> float:
        if not tokens:
            return 0.0
        
        invalid_count = sum(1 for t in tokens if not self._is_valid_word(t))
        return invalid_count / len(tokens) if tokens else 0.0
    
    def _is_magic_identifier(self, name: str, tokens: list[str], context: str) -> tuple[bool, str]:
        if len(name) == 1 and name.lower() not in {'i', 'j', 'k', 'n', 'm', 'x', 'y', 'z'}:
            if 'loop' not in context.lower() and 'for' not in context.lower():
                return True, "single_letter"
        
        if re.match(r'^[a-z]+\d+$', name) and len(name) <= 4:
            return True, "numeric_suffix"
        
        if re.match(r'^\d+$', name):
            return True, "numeric_only"
        
        if re.match(r'^(temp|tmp|foo|bar|baz|qux|xxx|yyy|zzz|aaa|bbb)$', name.lower()):
            return True, "placeholder_name"
        
        if re.match(r'^(data|info|stuff|thing|item|obj|var|val)\d*$', name.lower()):
            return True, "generic_name"
        
        if len(tokens) > 0:
            invalid_tokens = [t for t in tokens if not self._is_valid_word(t)]
            if len(invalid_tokens) == len(tokens) and len(tokens) >= 2:
                return True, "unrecognized_words"
        
        return False, ""
    
    def _suggest_name(self, name: str, naming_type: str) -> Optional[str]:
        suggestions = {
            "single_letter": f"Use a descriptive name instead of '{name}'",
            "numeric_suffix": f"Use a meaningful suffix instead of numbers in '{name}'",
            "placeholder_name": f"Replace placeholder '{name}' with a descriptive name",
            "generic_name": f"Use a more specific name instead of '{name}'",
        }
        return suggestions.get(naming_type)
    
    def _get_code_snippet(self, file_path: str, line_number: int, project_path: str, context: int = 2) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            start = max(0, line_number - 1 - context)
            end = min(len(lines), line_number + context)
            return ''.join(lines[start:end])
        except Exception:
            return None
    
    def _analyze_identifiers(self, static_result: StaticCollectorResult) -> list[NamingFinding]:
        findings = []
        
        for file_data in static_result.files:
            is_test_file = 'test' in file_data.path.lower()
            
            for identifier in file_data.identifiers:
                name = identifier.name
                
                if name.startswith('_'):
                    continue
                
                if identifier.identifier_type in ['parameter'] and name in {'self', 'cls', 'args', 'kwargs'}:
                    continue
                
                tokens = self._split_identifier(name)
                is_magic, magic_type = self._is_magic_identifier(name, tokens, identifier.context)
                
                if is_magic:
                    severity = Severity.LOW if is_test_file else Severity.MEDIUM
                    
                    findings.append(NamingFinding(
                        file_path=file_data.path,
                        line_number=identifier.line_number,
                        severity=severity,
                        category=FindingCategory.NAMING,
                        title=f"Magic identifier: {name}",
                        description=f"Identifier '{name}' is a {magic_type.replace('_', ' ')} in {identifier.context}",
                        code_snippet=self._get_code_snippet(file_data.path, identifier.line_number, static_result.project_path),
                        tags=["magic_identifier", magic_type],
                        naming_type=magic_type,
                        identifier=name,
                        suggested_name=self._suggest_name(name, magic_type)
                    ))
        
        return findings
    
    def _analyze_file_naming_entropy(self, static_result: StaticCollectorResult) -> list[NamingFinding]:
        findings = []
        
        for file_data in static_result.files:
            if len(file_data.identifiers) < 10:
                continue
            
            all_tokens = []
            for identifier in file_data.identifiers:
                all_tokens.extend(self._split_identifier(identifier.name))
            
            if not all_tokens:
                continue
            
            entropy = self._calculate_entropy(all_tokens)
            
            if entropy >= 0.5:
                severity = Severity.MEDIUM
            elif entropy >= 0.3:
                severity = Severity.LOW
            else:
                continue
            
            findings.append(NamingFinding(
                file_path=file_data.path,
                line_number=1,
                severity=severity,
                category=FindingCategory.NAMING,
                title=f"High naming entropy in {file_data.path}",
                description=f"File has {entropy:.1%} unrecognized tokens in identifiers, suggesting unclear naming",
                tags=["naming_entropy", "readability"],
                naming_type="high_entropy",
                identifier=file_data.path,
                entropy_score=entropy
            ))
        
        return findings
    
    def _analyze_inconsistent_naming(self, static_result: StaticCollectorResult) -> list[NamingFinding]:
        findings = []
        
        for file_data in static_result.files:
            snake_case = 0
            camel_case = 0
            
            for identifier in file_data.identifiers:
                name = identifier.name
                if identifier.identifier_type in ['class']:
                    continue
                
                if '_' in name and name.lower() == name:
                    snake_case += 1
                elif re.match(r'^[a-z]+[A-Z]', name):
                    camel_case += 1
            
            total = snake_case + camel_case
            if total < 10:
                continue
            
            if snake_case > 0 and camel_case > 0:
                minority = min(snake_case, camel_case)
                majority_style = "snake_case" if snake_case > camel_case else "camelCase"
                
                if minority / total > 0.2:
                    findings.append(NamingFinding(
                        file_path=file_data.path,
                        line_number=1,
                        severity=Severity.LOW,
                        category=FindingCategory.NAMING,
                        title=f"Inconsistent naming convention in {file_data.path}",
                        description=f"File mixes snake_case ({snake_case}) and camelCase ({camel_case}). Prefer {majority_style}.",
                        tags=["inconsistent_naming", "style"],
                        naming_type="inconsistent_style",
                        identifier=file_data.path
                    ))
        
        return findings
    
    def analyze(self, static_result: StaticCollectorResult) -> list[NamingFinding]:
        findings = []
        
        findings.extend(self._analyze_identifiers(static_result))
        findings.extend(self._analyze_file_naming_entropy(static_result))
        findings.extend(self._analyze_inconsistent_naming(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings


