import ast
import hashlib
from pathlib import Path
from typing import Optional
from difflib import SequenceMatcher
from collections import defaultdict

from models.findings import (
    StaticCollectorResult,
    DuplicationFinding,
    Severity,
    FindingCategory,
)


SIMILARITY_THRESHOLD = 0.85
MIN_LINES_FOR_DUPLICATION = 10
MIN_TOKENS_FOR_DUPLICATION = 50


class CodeNormalizer(ast.NodeTransformer):
    def __init__(self):
        self.var_counter = 0
        self.var_map: dict[str, str] = {}
    
    def _normalize_name(self, name: str) -> str:
        if name not in self.var_map:
            self.var_map[name] = f"var_{self.var_counter}"
            self.var_counter += 1
        return self.var_map[name]
    
    def visit_Name(self, node: ast.Name) -> ast.Name:
        if isinstance(node.ctx, (ast.Store, ast.Load)):
            node.id = self._normalize_name(node.id)
        return self.generic_visit(node)
    
    def visit_arg(self, node: ast.arg) -> ast.arg:
        node.arg = self._normalize_name(node.arg)
        return self.generic_visit(node)
    
    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
        node.name = "normalized_func"
        return self.generic_visit(node)
    
    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> ast.AsyncFunctionDef:
        node.name = "normalized_func"
        return self.generic_visit(node)
    
    def visit_Constant(self, node: ast.Constant) -> ast.Constant:
        if isinstance(node.value, str):
            node.value = "STRING"
        elif isinstance(node.value, (int, float)):
            node.value = 0
        return node


class DuplicationAnalyzer:
    def __init__(self, similarity_threshold: float = SIMILARITY_THRESHOLD):
        self.similarity_threshold = similarity_threshold
    
    def _get_code_snippet(self, file_path: str, line_number: int, project_path: str, context: int = 5) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            start = max(0, line_number - 1)
            end = min(len(lines), line_number + context)
            return ''.join(lines[start:end])
        except Exception:
            return None
    
    def _normalize_ast(self, node: ast.AST) -> str:
        normalizer = CodeNormalizer()
        try:
            normalized = normalizer.visit(node)
            return ast.dump(normalized)
        except Exception:
            return ""
    
    def _get_function_hash(self, func_node: ast.AST) -> str:
        normalized = self._normalize_ast(func_node)
        return hashlib.md5(normalized.encode()).hexdigest()
    
    def _calculate_similarity(self, code1: str, code2: str) -> float:
        return SequenceMatcher(None, code1, code2).ratio()
    
    def _extract_function_source(self, file_path: str, start_line: int, end_line: int, project_path: str) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            return ''.join(lines[start_line - 1:end_line])
        except Exception:
            return None
    
    def _analyze_exact_duplicates(self, static_result: StaticCollectorResult) -> list[DuplicationFinding]:
        findings = []
        function_hashes: dict[str, list[tuple[str, str, int, int]]] = defaultdict(list)
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
                tree = ast.parse(source)
            except Exception:
                continue
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if node.end_lineno and (node.end_lineno - node.lineno) < MIN_LINES_FOR_DUPLICATION:
                        continue
                    
                    func_hash = self._get_function_hash(node)
                    function_hashes[func_hash].append((
                        file_data.path,
                        node.name,
                        node.lineno,
                        node.end_lineno or node.lineno
                    ))
        
        for func_hash, locations in function_hashes.items():
            if len(locations) < 2:
                continue
            
            first_loc = locations[0]
            duplicate_locs = [
                {"file": loc[0], "line": loc[2], "end_line": loc[3], "name": loc[1]}
                for loc in locations[1:]
            ]
            
            findings.append(DuplicationFinding(
                file_path=first_loc[0],
                line_number=first_loc[2],
                end_line=first_loc[3],
                severity=Severity.MEDIUM,
                category=FindingCategory.DUPLICATION,
                title=f"Exact duplicate function: {first_loc[1]}",
                description=f"Function '{first_loc[1]}' has {len(locations)} exact copies across the codebase",
                code_snippet=self._get_code_snippet(first_loc[0], first_loc[2], static_result.project_path),
                tags=["exact_duplicate", "refactor_candidate"],
                duplication_type="exact_duplicate",
                similarity_score=1.0,
                duplicate_locations=duplicate_locs,
                duplicate_count=len(locations)
            ))
        
        return findings
    
    def _analyze_near_duplicates(self, static_result: StaticCollectorResult) -> list[DuplicationFinding]:
        findings = []
        
        functions: list[tuple[str, str, int, int, str]] = []
        
        for file_data in static_result.files:
            for func in file_data.functions:
                if func.body_lines < MIN_LINES_FOR_DUPLICATION:
                    continue
                
                source = self._extract_function_source(
                    file_data.path, func.line_number, func.end_line, static_result.project_path
                )
                if source:
                    functions.append((
                        file_data.path,
                        func.name,
                        func.line_number,
                        func.end_line,
                        source
                    ))
        
        checked_pairs: set[tuple[int, int]] = set()
        near_duplicate_groups: dict[int, list[int]] = defaultdict(list)
        
        for i, (path1, name1, line1, end1, source1) in enumerate(functions):
            for j, (path2, name2, line2, end2, source2) in enumerate(functions):
                if i >= j:
                    continue
                
                if (i, j) in checked_pairs:
                    continue
                checked_pairs.add((i, j))
                
                if path1 == path2 and name1 == name2:
                    continue
                
                similarity = self._calculate_similarity(source1, source2)
                
                if similarity >= self.similarity_threshold and similarity < 1.0:
                    if i in near_duplicate_groups:
                        near_duplicate_groups[i].append(j)
                    elif j in near_duplicate_groups:
                        near_duplicate_groups[j].append(i)
                    else:
                        near_duplicate_groups[i].append(j)
        
        for primary_idx, duplicate_indices in near_duplicate_groups.items():
            primary = functions[primary_idx]
            
            duplicate_locs = []
            for dup_idx in duplicate_indices:
                dup = functions[dup_idx]
                similarity = self._calculate_similarity(primary[4], dup[4])
                duplicate_locs.append({
                    "file": dup[0],
                    "line": dup[2],
                    "end_line": dup[3],
                    "name": dup[1],
                    "similarity": round(similarity, 2)
                })
            
            avg_similarity = sum(d.get("similarity", 0.8) for d in duplicate_locs) / len(duplicate_locs)
            
            findings.append(DuplicationFinding(
                file_path=primary[0],
                line_number=primary[2],
                end_line=primary[3],
                severity=Severity.LOW,
                category=FindingCategory.DUPLICATION,
                title=f"Near-duplicate function: {primary[1]}",
                description=f"Function '{primary[1]}' has {len(duplicate_locs)} similar copies (avg {avg_similarity:.0%} similar)",
                code_snippet=self._get_code_snippet(primary[0], primary[2], static_result.project_path),
                tags=["near_duplicate", "refactor_candidate"],
                duplication_type="near_duplicate",
                similarity_score=avg_similarity,
                duplicate_locations=duplicate_locs,
                duplicate_count=len(duplicate_locs) + 1
            ))
        
        return findings
    
    def _analyze_code_block_duplication(self, static_result: StaticCollectorResult) -> list[DuplicationFinding]:
        findings = []
        
        code_blocks: dict[str, list[tuple[str, int, int]]] = defaultdict(list)
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    lines = f.readlines()
            except Exception:
                continue
            
            window_size = 6
            for i in range(len(lines) - window_size + 1):
                block = ''.join(lines[i:i + window_size])
                
                stripped_block = '\n'.join(line.strip() for line in lines[i:i + window_size])
                if len(stripped_block.replace('\n', '').replace(' ', '')) < MIN_TOKENS_FOR_DUPLICATION:
                    continue
                
                if all(line.strip().startswith('#') or not line.strip() for line in lines[i:i + window_size]):
                    continue
                
                block_hash = hashlib.md5(stripped_block.encode()).hexdigest()
                code_blocks[block_hash].append((file_data.path, i + 1, i + window_size))
        
        for block_hash, locations in code_blocks.items():
            if len(locations) < 2:
                continue
            
            unique_files = set(loc[0] for loc in locations)
            if len(unique_files) < 2:
                continue
            
            first_loc = locations[0]
            duplicate_locs = [
                {"file": loc[0], "line": loc[1], "end_line": loc[2]}
                for loc in locations[1:]
            ]
            
            findings.append(DuplicationFinding(
                file_path=first_loc[0],
                line_number=first_loc[1],
                end_line=first_loc[2],
                severity=Severity.LOW,
                category=FindingCategory.DUPLICATION,
                title=f"Duplicated code block",
                description=f"Code block at lines {first_loc[1]}-{first_loc[2]} is duplicated in {len(locations)} places",
                code_snippet=self._get_code_snippet(first_loc[0], first_loc[1], static_result.project_path),
                tags=["code_block_duplicate", "copy_paste"],
                duplication_type="copy_paste",
                similarity_score=1.0,
                duplicate_locations=duplicate_locs,
                duplicate_count=len(locations)
            ))
        
        return findings
    
    def analyze(self, static_result: StaticCollectorResult) -> list[DuplicationFinding]:
        findings = []
        
        findings.extend(self._analyze_exact_duplicates(static_result))
        findings.extend(self._analyze_near_duplicates(static_result))
        findings.extend(self._analyze_code_block_duplication(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            -f.duplicate_count,
            f.file_path,
            f.line_number
        ))
        
        return findings


