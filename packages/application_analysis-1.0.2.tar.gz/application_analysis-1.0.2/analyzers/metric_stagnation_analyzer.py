import statistics
from typing import Optional
from collections import defaultdict

from models.findings import (
    DynamicCollectorResult,
    MetricFinding,
    Severity,
    FindingCategory,
)


VARIANCE_THRESHOLD = 0.001
MIN_SAMPLES_FOR_ANALYSIS = 5
TRAINING_METRIC_NAMES = {
    'fitness', 'loss', 'accuracy', 'score', 'reward', 'error', 'cost',
    'train_loss', 'val_loss', 'test_loss', 'train_acc', 'val_acc', 'test_acc',
    'mse', 'mae', 'rmse', 'f1', 'precision', 'recall', 'auc', 'roc',
    'learning_rate', 'lr', 'gradient', 'grad_norm',
}


class MetricStagnationAnalyzer:
    def __init__(self, variance_threshold: float = VARIANCE_THRESHOLD):
        self.variance_threshold = variance_threshold
    
    def _is_training_metric(self, metric_name: str) -> bool:
        name_lower = metric_name.lower()
        for pattern in TRAINING_METRIC_NAMES:
            if pattern in name_lower:
                return True
        return False
    
    def _analyze_metric_series(self, metric_name: str, values: list[float], module: str, function_name: Optional[str]) -> Optional[MetricFinding]:
        if len(values) < MIN_SAMPLES_FOR_ANALYSIS:
            return None
        
        unique_values = set(values)
        min_val = min(values)
        max_val = max(values)
        
        try:
            variance = statistics.variance(values) if len(values) > 1 else 0.0
        except statistics.StatisticsError:
            variance = 0.0
        
        is_training = self._is_training_metric(metric_name)
        
        if len(unique_values) == 1:
            severity = Severity.CRITICAL if is_training else Severity.HIGH
            metric_type = "constant"
            title = f"Constant metric: {metric_name}"
            description = f"Metric '{metric_name}' remains constant at {values[0]} over {len(values)} samples"
            likely_cause = "The metric is never updated, or the update logic is not being executed"
        
        elif variance < self.variance_threshold:
            severity = Severity.HIGH if is_training else Severity.MEDIUM
            metric_type = "near_constant"
            title = f"Near-constant metric: {metric_name}"
            description = f"Metric '{metric_name}' has minimal variance ({variance:.6f}) over {len(values)} samples (range: {min_val:.4f} - {max_val:.4f})"
            likely_cause = "The metric is being updated but with negligible changes, possibly due to learning rate issues or vanishing gradients"
        
        elif max_val == min_val:
            severity = Severity.HIGH if is_training else Severity.MEDIUM
            metric_type = "never_updated"
            title = f"Never-updated metric: {metric_name}"
            description = f"Metric '{metric_name}' shows no change (value: {values[0]}) across {len(values)} samples"
            likely_cause = "The variable is read but never modified after initialization"
        
        else:
            return None
        
        file_path = module.replace('.', '/') + '.py'
        
        return MetricFinding(
            file_path=file_path,
            line_number=1,
            severity=severity,
            category=FindingCategory.METRIC,
            title=title,
            description=description,
            tags=["metric_stagnation", metric_type, "training_logic_issue"] if is_training else ["metric_stagnation", metric_type],
            metric_type=metric_type,
            metric_name=metric_name,
            observed_values=values[:10],
            value_count=len(unique_values),
            variance=variance,
            min_value=min_val,
            max_value=max_val,
            sample_count=len(values),
            likely_cause=likely_cause
        )
    
    def _analyze_stuck_in_loop(self, metric_name: str, values: list[float], module: str) -> Optional[MetricFinding]:
        if len(values) < 10:
            return None
        
        is_training = self._is_training_metric(metric_name)
        
        window_size = min(100, len(values) // 2)
        early_window = values[:window_size]
        late_window = values[-window_size:]
        
        try:
            early_mean = statistics.mean(early_window)
            late_mean = statistics.mean(late_window)
            
            if abs(early_mean - late_mean) < self.variance_threshold * 10:
                total_variance = statistics.variance(values) if len(values) > 1 else 0.0
                if total_variance < self.variance_threshold * 100:
                    file_path = module.replace('.', '/') + '.py'
                    
                    return MetricFinding(
                        file_path=file_path,
                        line_number=1,
                        severity=Severity.HIGH if is_training else Severity.MEDIUM,
                        category=FindingCategory.METRIC,
                        title=f"Metric stuck in loop: {metric_name}",
                        description=f"Metric '{metric_name}' shows no progress between early ({early_mean:.4f}) and late ({late_mean:.4f}) iterations",
                        tags=["metric_stagnation", "stuck_in_loop", "training_logic_issue"] if is_training else ["metric_stagnation", "stuck_in_loop"],
                        metric_type="stuck_in_loop",
                        metric_name=metric_name,
                        observed_values=values[:5] + values[-5:],
                        value_count=len(set(values)),
                        variance=total_variance,
                        min_value=min(values),
                        max_value=max(values),
                        sample_count=len(values),
                        likely_cause="Training loop may not be progressing, or metric calculation is incorrect"
                    )
        except statistics.StatisticsError:
            pass
        
        return None
    
    def analyze(self, dynamic_result: DynamicCollectorResult) -> list[MetricFinding]:
        findings = []
        
        metrics_by_name: dict[str, dict] = defaultdict(lambda: {
            'values': [],
            'module': '',
            'function_name': None
        })
        
        for sample in dynamic_result.metric_samples:
            key = sample.metric_name
            metrics_by_name[key]['values'].append(sample.value)
            metrics_by_name[key]['module'] = sample.module
            metrics_by_name[key]['function_name'] = sample.function_name
        
        for metric_name, data in metrics_by_name.items():
            values = data['values']
            module = data['module']
            function_name = data['function_name']
            
            finding = self._analyze_metric_series(metric_name, values, module, function_name)
            if finding:
                findings.append(finding)
                continue
            
            loop_finding = self._analyze_stuck_in_loop(metric_name, values, module)
            if loop_finding:
                findings.append(loop_finding)
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings
    
    def get_metric_summary(self, dynamic_result: DynamicCollectorResult) -> dict:
        summary = {
            'total_metrics_tracked': 0,
            'constant_metrics': 0,
            'near_constant_metrics': 0,
            'healthy_metrics': 0,
            'training_metrics': 0,
            'metrics': {}
        }
        
        metrics_by_name: dict[str, list[float]] = defaultdict(list)
        
        for sample in dynamic_result.metric_samples:
            metrics_by_name[sample.metric_name].append(sample.value)
        
        summary['total_metrics_tracked'] = len(metrics_by_name)
        
        for metric_name, values in metrics_by_name.items():
            if len(values) < MIN_SAMPLES_FOR_ANALYSIS:
                continue
            
            unique_count = len(set(values))
            try:
                variance = statistics.variance(values) if len(values) > 1 else 0.0
            except statistics.StatisticsError:
                variance = 0.0
            
            is_training = self._is_training_metric(metric_name)
            if is_training:
                summary['training_metrics'] += 1
            
            if unique_count == 1:
                summary['constant_metrics'] += 1
                status = 'constant'
            elif variance < self.variance_threshold:
                summary['near_constant_metrics'] += 1
                status = 'near_constant'
            else:
                summary['healthy_metrics'] += 1
                status = 'healthy'
            
            summary['metrics'][metric_name] = {
                'status': status,
                'sample_count': len(values),
                'unique_values': unique_count,
                'variance': variance,
                'min': min(values),
                'max': max(values),
                'is_training_metric': is_training
            }
        
        return summary


