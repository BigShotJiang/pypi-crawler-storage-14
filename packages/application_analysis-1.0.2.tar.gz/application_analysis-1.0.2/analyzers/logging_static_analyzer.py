import re
from pathlib import Path
from typing import Optional
from collections import Counter

from models.findings import (
    StaticCollectorResult,
    LoggingFinding,
    Severity,
    FindingCategory,
)


GENERIC_LOG_PATTERNS = [
    r'^(here|test|debug|checking|done|ok|start|end|enter|exit|begin|finish)$',
    r'^(step\s*\d+|point\s*\d+|checkpoint\s*\d+)$',
    r'^[.!?]+$',
    r'^\d+$',
    r'^(it works|working|success|failed|error|exception)$',
    r'^(foo|bar|baz|xxx|yyy|zzz|asdf|qwerty)$',
    r'^(lol|wtf|omg|todo|fixme|hack)$',
]

DEV_LEFTOVER_PATTERNS = [
    r'print\s*\(\s*["\']debug',
    r'print\s*\(\s*["\']test',
    r'print\s*\(\s*["\']here',
    r'print\s*\(\s*["\']===',
    r'print\s*\(\s*["\']---',
    r'print\s*\(\s*["\']###',
    r'print\s*\(\s*["\']>>>',
    r'print\s*\(\s*f["\'].*\{.*=.*\}',
    r'print\s*\(\s*["\']@@@',
    r'print\s*\(\s*["\']!!!',
]

USEFUL_LOG_INDICATORS = [
    r'\{[^}]+\}',
    r'%[sdfr]',
    r'=\s*["\']?[\w.]+["\']?',
    r'(error|exception|fail|warn)',
    r'(request|response|result|status)',
    r'(id|user|session|token)',
    r'(start|stop|complete|finish)',
    r'(create|update|delete|read)',
    r'(connect|disconnect|timeout)',
    r'\d+\s*(ms|sec|min|bytes|kb|mb)',
]


class LoggingStaticAnalyzer:
    def __init__(self):
        self.generic_patterns = [re.compile(p, re.IGNORECASE) for p in GENERIC_LOG_PATTERNS]
        self.dev_leftover_patterns = [re.compile(p, re.IGNORECASE) for p in DEV_LEFTOVER_PATTERNS]
        self.useful_patterns = [re.compile(p, re.IGNORECASE) for p in USEFUL_LOG_INDICATORS]
    
    def _get_code_snippet(self, file_path: str, line_number: int, project_path: str, context: int = 2) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            start = max(0, line_number - 1 - context)
            end = min(len(lines), line_number + context)
            return ''.join(lines[start:end])
        except Exception:
            return None
    
    def _classify_log_message(self, message: str, has_format_args: bool) -> str:
        message_clean = message.strip().strip('"\'')
        
        for pattern in self.generic_patterns:
            if pattern.match(message_clean):
                return "likely_redundant"
        
        useful_count = sum(1 for p in self.useful_patterns if p.search(message))
        
        if has_format_args or useful_count >= 2:
            return "likely_useful"
        
        if useful_count == 1:
            return "likely_useful"
        
        if len(message_clean) < 10 and not any(c.isalnum() for c in message_clean):
            return "spammy"
        
        if len(message_clean) < 5:
            return "likely_redundant"
        
        return "likely_useful"
    
    def _analyze_log_calls(self, static_result: StaticCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        for file_data in static_result.files:
            for log_call in file_data.log_calls:
                classification = self._classify_log_message(
                    log_call.message_template,
                    log_call.has_format_args
                )
                
                if classification == "likely_useful":
                    continue
                
                if classification == "spammy":
                    severity = Severity.MEDIUM
                    title = "Spammy log message"
                    description = f"Log message appears to be noise: '{log_call.message_template[:50]}...'"
                elif classification == "likely_redundant":
                    severity = Severity.LOW
                    title = "Generic/redundant log message"
                    description = f"Log message lacks context: '{log_call.message_template[:50]}'"
                else:
                    continue
                
                findings.append(LoggingFinding(
                    file_path=file_data.path,
                    line_number=log_call.line_number,
                    severity=severity,
                    category=FindingCategory.LOGGING,
                    title=title,
                    description=description,
                    code_snippet=self._get_code_snippet(file_data.path, log_call.line_number, static_result.project_path),
                    tags=[f"log_{classification}", log_call.log_type],
                    logging_type=classification,
                    log_level=log_call.level,
                    message_template=log_call.message_template,
                    call_count=1,
                    has_variables=log_call.has_format_args,
                    classification=classification
                ))
        
        return findings
    
    def _analyze_dev_leftovers(self, static_result: StaticCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
            except Exception:
                continue
            
            for i, line in enumerate(source.split('\n'), 1):
                for pattern in self.dev_leftover_patterns:
                    if pattern.search(line):
                        findings.append(LoggingFinding(
                            file_path=file_data.path,
                            line_number=i,
                            severity=Severity.MEDIUM,
                            category=FindingCategory.LOGGING,
                            title="Development debug print leftover",
                            description=f"Debug print statement appears to be leftover from development",
                            code_snippet=self._get_code_snippet(file_data.path, i, static_result.project_path),
                            tags=["dev_leftover", "cleanup"],
                            logging_type="dev_leftover",
                            log_level=None,
                            message_template=line.strip()[:100],
                            call_count=1,
                            has_variables='{' in line,
                            classification="dev_leftover"
                        ))
                        break
        
        return findings
    
    def _analyze_missing_logging(self, static_result: StaticCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        for file_data in static_result.files:
            is_test_file = 'test' in file_data.path.lower()
            if is_test_file:
                continue
            
            has_logging = len([lc for lc in file_data.log_calls if lc.log_type == 'logging']) > 0
            has_print = len([lc for lc in file_data.log_calls if lc.log_type == 'print']) > 0
            
            complex_functions = [f for f in file_data.functions if f.nesting_depth >= 2 or f.body_lines >= 20]
            
            if complex_functions and not has_logging:
                if has_print:
                    findings.append(LoggingFinding(
                        file_path=file_data.path,
                        line_number=1,
                        severity=Severity.LOW,
                        category=FindingCategory.LOGGING,
                        title="Print statements instead of logging",
                        description=f"File has {len([lc for lc in file_data.log_calls if lc.log_type == 'print'])} print() calls but no structured logging",
                        tags=["print_instead_of_logging", "observability"],
                        logging_type="missing_context",
                        call_count=len([lc for lc in file_data.log_calls if lc.log_type == 'print']),
                        has_variables=False,
                        classification="likely_redundant"
                    ))
        
        return findings
    
    def _analyze_log_level_usage(self, static_result: StaticCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        level_counts: dict[str, int] = Counter()
        debug_heavy_files: list[tuple[str, int]] = []
        
        for file_data in static_result.files:
            file_debug_count = 0
            
            for log_call in file_data.log_calls:
                if log_call.log_type == 'logging' and log_call.level:
                    level_counts[log_call.level] += 1
                    if log_call.level == 'debug':
                        file_debug_count += 1
            
            if file_debug_count > 10:
                debug_heavy_files.append((file_data.path, file_debug_count))
        
        for file_path, count in debug_heavy_files:
            findings.append(LoggingFinding(
                file_path=file_path,
                line_number=1,
                severity=Severity.LOW,
                category=FindingCategory.LOGGING,
                title="Heavy debug logging",
                description=f"File has {count} debug log statements which may impact performance",
                tags=["heavy_debug_logging", "performance"],
                logging_type="spammy",
                call_count=count,
                has_variables=False,
                classification="spammy"
            ))
        
        return findings
    
    def _get_logging_statistics(self, static_result: StaticCollectorResult) -> dict:
        stats = {
            'total_log_calls': 0,
            'total_print_calls': 0,
            'by_level': Counter(),
            'by_classification': Counter(),
            'files_with_logging': 0,
            'files_with_print_only': 0,
            'files_without_any': 0,
        }
        
        for file_data in static_result.files:
            logging_calls = [lc for lc in file_data.log_calls if lc.log_type == 'logging']
            print_calls = [lc for lc in file_data.log_calls if lc.log_type == 'print']
            
            stats['total_log_calls'] += len(logging_calls)
            stats['total_print_calls'] += len(print_calls)
            
            for lc in logging_calls:
                if lc.level:
                    stats['by_level'][lc.level] += 1
            
            if logging_calls:
                stats['files_with_logging'] += 1
            elif print_calls:
                stats['files_with_print_only'] += 1
            else:
                stats['files_without_any'] += 1
        
        return stats
    
    def analyze(self, static_result: StaticCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        findings.extend(self._analyze_log_calls(static_result))
        findings.extend(self._analyze_dev_leftovers(static_result))
        findings.extend(self._analyze_missing_logging(static_result))
        findings.extend(self._analyze_log_level_usage(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings
    
    def get_statistics(self, static_result: StaticCollectorResult) -> dict:
        return self._get_logging_statistics(static_result)


