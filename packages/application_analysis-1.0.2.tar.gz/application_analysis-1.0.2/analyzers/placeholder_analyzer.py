import re
from typing import Optional

from models.findings import (
    StaticCollectorResult,
    PlaceholderFinding,
    Severity,
    FindingCategory,
    FunctionInfo,
    ClassInfo,
    CommentInfo,
)


PLACEHOLDER_KEYWORDS = [
    r'\bTODO\b',
    r'\bFIXME\b',
    r'\bXXX\b',
    r'\bHACK\b',
    r'\bBUG\b',
    r'\bplaceholder\b',
    r'\breplace\s+later\b',
    r'\btemporary\b',
    r'\btemp\s+fix\b',
    r'\bworkaround\b',
    r'\bnot\s+implemented\b',
    r'\bstub\b',
    r'\bdummy\b',
    r'\bfake\b',
    r'\bmock\b',
    r'\btest\s+data\b',
    r'\bexample\s+code\b',
    r'\bremove\s+this\b',
    r'\bdelete\s+this\b',
    r'\bclean\s+up\b',
    r'\brefactor\b',
    r'\bneeds\s+work\b',
    r'\bincomplete\b',
]

AI_ARTIFACT_PATTERNS = [
    r'^This\s+function\s+(does|will|should)\s+',
    r'^This\s+class\s+(does|will|should)\s+',
    r'^This\s+method\s+(does|will|should)\s+',
    r'^Returns?\s+the\s+',
    r'^Gets?\s+the\s+',
    r'^Sets?\s+the\s+',
    r'^Creates?\s+a\s+new\s+',
    r'^Initializes?\s+the\s+',
    r'^Handles?\s+the\s+',
    r'^Processes?\s+the\s+',
    r'^Validates?\s+the\s+',
    r'^Checks?\s+if\s+',
    r'^Determines?\s+whether\s+',
    r'^Example\s+usage',
    r'^Usage\s+example',
    r'^Sample\s+implementation',
    r'^Placeholder\s+implementation',
    r'^Default\s+implementation',
    r'^Base\s+implementation',
    r'^TODO:\s*implement',
    r'^FIXME:\s*implement',
]

MOCK_FUNCTION_PATTERNS = [
    r'^mock_',
    r'^fake_',
    r'^stub_',
    r'^dummy_',
    r'^test_helper_',
    r'^example_',
    r'^sample_',
    r'^placeholder_',
    r'_mock$',
    r'_fake$',
    r'_stub$',
    r'_dummy$',
]

MOCK_CLASS_PATTERNS = [
    r'^Mock[A-Z]',
    r'^Fake[A-Z]',
    r'^Stub[A-Z]',
    r'^Dummy[A-Z]',
    r'^Test.*Helper',
    r'^Example[A-Z]',
    r'^Sample[A-Z]',
    r'Mock$',
    r'Fake$',
    r'Stub$',
    r'Dummy$',
]


class PlaceholderAnalyzer:
    def __init__(self):
        self.keyword_patterns = [re.compile(p, re.IGNORECASE) for p in PLACEHOLDER_KEYWORDS]
        self.ai_patterns = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in AI_ARTIFACT_PATTERNS]
        self.mock_func_patterns = [re.compile(p, re.IGNORECASE) for p in MOCK_FUNCTION_PATTERNS]
        self.mock_class_patterns = [re.compile(p, re.IGNORECASE) for p in MOCK_CLASS_PATTERNS]
    
    def _get_severity_for_keyword(self, keyword: str) -> Severity:
        keyword_lower = keyword.lower()
        if any(k in keyword_lower for k in ['fixme', 'bug', 'hack']):
            return Severity.HIGH
        if any(k in keyword_lower for k in ['todo', 'xxx']):
            return Severity.MEDIUM
        return Severity.LOW
    
    def _get_code_snippet(self, file_path: str, line_number: int, static_result: StaticCollectorResult, context: int = 2) -> Optional[str]:
        for file_data in static_result.files:
            if file_data.path == file_path:
                try:
                    with open(f"{static_result.project_path}/{file_path}", 'r', encoding='utf-8', errors='replace') as f:
                        lines = f.readlines()
                    start = max(0, line_number - 1 - context)
                    end = min(len(lines), line_number + context)
                    return ''.join(lines[start:end])
                except Exception:
                    return None
        return None
    
    def _analyze_comments(self, static_result: StaticCollectorResult) -> list[PlaceholderFinding]:
        findings = []
        
        for file_data in static_result.files:
            for comment in file_data.comments:
                content = comment.content
                
                for pattern in self.keyword_patterns:
                    match = pattern.search(content)
                    if match:
                        matched_keyword = match.group(0)
                        findings.append(PlaceholderFinding(
                            file_path=file_data.path,
                            line_number=comment.line_number,
                            severity=self._get_severity_for_keyword(matched_keyword),
                            category=FindingCategory.PLACEHOLDER,
                            title=f"Placeholder keyword: {matched_keyword.upper()}",
                            description=f"Found '{matched_keyword}' in comment: {content[:100]}...",
                            code_snippet=self._get_code_snippet(file_data.path, comment.line_number, static_result),
                            tags=["placeholder_keyword", "comment"],
                            placeholder_type="keyword",
                            matched_pattern=matched_keyword
                        ))
                        break
                
                if comment.comment_type == "docstring":
                    for pattern in self.ai_patterns:
                        match = pattern.search(content)
                        if match:
                            matched_text = match.group(0)
                            findings.append(PlaceholderFinding(
                                file_path=file_data.path,
                                line_number=comment.line_number,
                                severity=Severity.LOW,
                                category=FindingCategory.PLACEHOLDER,
                                title="Generic AI-generated docstring",
                                description=f"Docstring appears to be generic AI-generated content: '{matched_text}...'",
                                code_snippet=self._get_code_snippet(file_data.path, comment.line_number, static_result),
                                tags=["ai_artifact", "docstring"],
                                placeholder_type="ai_artifact",
                                matched_pattern=matched_text
                            ))
                            break
        
        return findings
    
    def _analyze_stub_functions(self, static_result: StaticCollectorResult) -> list[PlaceholderFinding]:
        findings = []
        
        for file_data in static_result.files:
            for func in file_data.functions:
                if func.is_stub:
                    is_test_file = 'test' in file_data.path.lower()
                    is_abstract = 'abstractmethod' in func.decorators
                    is_protocol = any('Protocol' in base for cls in file_data.classes 
                                    if func.class_name == cls.name for base in cls.bases)
                    
                    if is_abstract or is_protocol:
                        continue
                    
                    severity = Severity.LOW if is_test_file else Severity.MEDIUM
                    
                    findings.append(PlaceholderFinding(
                        file_path=file_data.path,
                        line_number=func.line_number,
                        end_line=func.end_line,
                        severity=severity,
                        category=FindingCategory.PLACEHOLDER,
                        title=f"Stub function: {func.name}",
                        description=f"Function '{func.name}' appears to be a stub with no real implementation",
                        code_snippet=self._get_code_snippet(file_data.path, func.line_number, static_result),
                        tags=["stub_function", "incomplete"],
                        placeholder_type="stub_function",
                        matched_pattern="stub body"
                    ))
        
        return findings
    
    def _analyze_stub_classes(self, static_result: StaticCollectorResult) -> list[PlaceholderFinding]:
        findings = []
        
        for file_data in static_result.files:
            for cls in file_data.classes:
                if cls.is_stub:
                    is_test_file = 'test' in file_data.path.lower()
                    
                    severity = Severity.LOW if is_test_file else Severity.MEDIUM
                    
                    findings.append(PlaceholderFinding(
                        file_path=file_data.path,
                        line_number=cls.line_number,
                        end_line=cls.end_line,
                        severity=severity,
                        category=FindingCategory.PLACEHOLDER,
                        title=f"Stub class: {cls.name}",
                        description=f"Class '{cls.name}' appears to be a stub with no implementation",
                        code_snippet=self._get_code_snippet(file_data.path, cls.line_number, static_result),
                        tags=["stub_class", "incomplete"],
                        placeholder_type="stub_class",
                        matched_pattern="stub body"
                    ))
        
        return findings
    
    def _analyze_mock_patterns(self, static_result: StaticCollectorResult) -> list[PlaceholderFinding]:
        findings = []
        
        for file_data in static_result.files:
            is_test_file = 'test' in file_data.path.lower()
            
            for func in file_data.functions:
                for pattern in self.mock_func_patterns:
                    if pattern.search(func.name):
                        if is_test_file:
                            continue
                        
                        findings.append(PlaceholderFinding(
                            file_path=file_data.path,
                            line_number=func.line_number,
                            end_line=func.end_line,
                            severity=Severity.MEDIUM,
                            category=FindingCategory.PLACEHOLDER,
                            title=f"Mock/fake function in production code: {func.name}",
                            description=f"Function '{func.name}' has mock/fake naming pattern but is not in a test file",
                            code_snippet=self._get_code_snippet(file_data.path, func.line_number, static_result),
                            tags=["mock_pattern", "production_code"],
                            placeholder_type="mock_pattern",
                            matched_pattern=func.name
                        ))
                        break
            
            for cls in file_data.classes:
                for pattern in self.mock_class_patterns:
                    if pattern.search(cls.name):
                        if is_test_file:
                            continue
                        
                        findings.append(PlaceholderFinding(
                            file_path=file_data.path,
                            line_number=cls.line_number,
                            end_line=cls.end_line,
                            severity=Severity.MEDIUM,
                            category=FindingCategory.PLACEHOLDER,
                            title=f"Mock/fake class in production code: {cls.name}",
                            description=f"Class '{cls.name}' has mock/fake naming pattern but is not in a test file",
                            code_snippet=self._get_code_snippet(file_data.path, cls.line_number, static_result),
                            tags=["mock_pattern", "production_code"],
                            placeholder_type="mock_pattern",
                            matched_pattern=cls.name
                        ))
                        break
        
        return findings
    
    def analyze(self, static_result: StaticCollectorResult) -> list[PlaceholderFinding]:
        findings = []
        
        findings.extend(self._analyze_comments(static_result))
        findings.extend(self._analyze_stub_functions(static_result))
        findings.extend(self._analyze_stub_classes(static_result))
        findings.extend(self._analyze_mock_patterns(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings


