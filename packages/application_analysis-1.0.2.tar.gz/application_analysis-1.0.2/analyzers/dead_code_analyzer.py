import ast
import re
from pathlib import Path
from typing import Optional
from collections import defaultdict

from models.findings import (
    StaticCollectorResult,
    DeadCodeFinding,
    Severity,
    FindingCategory,
)


COMMON_EXPORTED_NAMES = {
    '__all__', '__version__', '__author__', '__name__', '__doc__',
    'main', 'run', 'setup', 'teardown', 'configure',
}

FRAMEWORK_PATTERNS = [
    r'^test_',
    r'_test$',
    r'^Test',
    r'Tests$',
    r'^on_',
    r'^handle_',
    r'^_?setup$',
    r'^_?teardown$',
    r'^get_',
    r'^set_',
    r'^__',
    r'^_',
    r'^visit_',
    r'^analyze',
    r'^process',
    r'^generate',
    r'^create',
    r'^build',
    r'^run',
    r'^is_',
    r'^has_',
    r'^can_',
    r'^should_',
    r'Analyzer$',
    r'Collector$',
    r'Generator$',
    r'Engine$',
    r'Handler$',
]


class DeadCodeAnalyzer:
    def __init__(self):
        self.all_definitions: dict[str, list[tuple[str, int, str]]] = defaultdict(list)
        self.all_references: set[str] = set()
        self.exported_names: set[str] = set()
    
    def _is_framework_name(self, name: str) -> bool:
        for pattern in FRAMEWORK_PATTERNS:
            if re.match(pattern, name):
                return True
        return False
    
    def _get_code_snippet(self, file_path: str, line_number: int, project_path: str, context: int = 2) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            start = max(0, line_number - 1 - context)
            end = min(len(lines), line_number + context)
            return ''.join(lines[start:end])
        except Exception:
            return None
    
    def _collect_definitions_and_references(self, static_result: StaticCollectorResult):
        self.all_definitions.clear()
        self.all_references.clear()
        self.exported_names.clear()
        
        for file_data in static_result.files:
            for func in file_data.functions:
                self.all_definitions[func.name].append((file_data.path, func.line_number, 'function'))
            
            for cls in file_data.classes:
                self.all_definitions[cls.name].append((file_data.path, cls.line_number, 'class'))
            
            for identifier in file_data.identifiers:
                if identifier.identifier_type not in ['function', 'class']:
                    self.all_references.add(identifier.name)
            
            for func in file_data.functions:
                for call in func.calls:
                    call_name = call.split('.')[-1]
                    self.all_references.add(call_name)
            
            for cls in file_data.classes:
                for base in cls.bases:
                    base_name = base.split('.')[-1]
                    self.all_references.add(base_name)
            
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
                tree = ast.parse(source)
                
                for node in ast.walk(tree):
                    if isinstance(node, ast.Assign):
                        for target in node.targets:
                            if isinstance(target, ast.Name) and target.id == '__all__':
                                if isinstance(node.value, (ast.List, ast.Tuple)):
                                    for elt in node.value.elts:
                                        if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                                            self.exported_names.add(elt.value)
            except Exception:
                pass
    
    def _analyze_unused_imports(self, static_result: StaticCollectorResult) -> list[DeadCodeFinding]:
        findings = []
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
            except Exception:
                continue
            
            imported_names: dict[str, tuple[int, str]] = {}
            
            for imp in file_data.imports:
                if imp.is_from_import and imp.name:
                    local_name = imp.alias or imp.name
                    imported_names[local_name] = (imp.line_number, imp.name)
                elif not imp.is_from_import:
                    local_name = imp.alias or imp.module.split('.')[0]
                    imported_names[local_name] = (imp.line_number, imp.module)
            
            for name, (line_num, original_name) in imported_names.items():
                if name.startswith('_') and not name.startswith('__'):
                    continue
                
                pattern = r'\b' + re.escape(name) + r'\b'
                import_line_pattern = rf'^.*import.*\b{re.escape(name)}\b.*$'
                
                matches = list(re.finditer(pattern, source))
                
                usage_count = 0
                for match in matches:
                    line_start = source.rfind('\n', 0, match.start()) + 1
                    line_end = source.find('\n', match.end())
                    if line_end == -1:
                        line_end = len(source)
                    line = source[line_start:line_end]
                    
                    if not re.match(import_line_pattern, line, re.IGNORECASE):
                        usage_count += 1
                
                if usage_count == 0:
                    findings.append(DeadCodeFinding(
                        file_path=file_data.path,
                        line_number=line_num,
                        severity=Severity.LOW,
                        category=FindingCategory.DEAD_CODE,
                        title=f"Unused import: {name}",
                        description=f"'{name}' is imported but never used in {file_data.path}",
                        code_snippet=self._get_code_snippet(file_data.path, line_num, static_result.project_path),
                        tags=["unused_import", "cleanup"],
                        dead_code_type="unused_import",
                        identifier=name,
                        defined_at=line_num,
                        usage_count=0
                    ))
        
        return findings
    
    def _analyze_unused_functions(self, static_result: StaticCollectorResult) -> list[DeadCodeFinding]:
        findings = []
        
        for name, definitions in self.all_definitions.items():
            if name in self.all_references:
                continue
            
            if name in self.exported_names:
                continue
            
            if name in COMMON_EXPORTED_NAMES:
                continue
            
            if self._is_framework_name(name):
                continue
            
            for file_path, line_num, def_type in definitions:
                if '__init__' in file_path:
                    continue
                
                is_test_file = 'test' in file_path.lower()
                if is_test_file and name.startswith('test'):
                    continue
                
                findings.append(DeadCodeFinding(
                    file_path=file_path,
                    line_number=line_num,
                    severity=Severity.LOW,
                    category=FindingCategory.DEAD_CODE,
                    title=f"Unused {def_type}: {name}",
                    description=f"'{name}' is defined but never referenced in the project",
                    code_snippet=self._get_code_snippet(file_path, line_num, static_result.project_path),
                    tags=[f"unused_{def_type}", "cleanup"],
                    dead_code_type=f"unused_{def_type}",
                    identifier=name,
                    defined_at=line_num,
                    usage_count=0
                ))
        
        return findings
    
    def _analyze_unreachable_code(self, static_result: StaticCollectorResult) -> list[DeadCodeFinding]:
        findings = []
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
                tree = ast.parse(source)
            except Exception:
                continue
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    body = node.body
                    for i, stmt in enumerate(body[:-1]):
                        if isinstance(stmt, ast.Return):
                            next_stmt = body[i + 1]
                            if not isinstance(next_stmt, ast.Expr) or not isinstance(next_stmt.value, ast.Constant):
                                findings.append(DeadCodeFinding(
                                    file_path=file_data.path,
                                    line_number=next_stmt.lineno,
                                    severity=Severity.MEDIUM,
                                    category=FindingCategory.DEAD_CODE,
                                    title=f"Unreachable code after return",
                                    description=f"Code at line {next_stmt.lineno} is unreachable after return statement",
                                    code_snippet=self._get_code_snippet(file_data.path, next_stmt.lineno, static_result.project_path),
                                    tags=["unreachable_code", "cleanup"],
                                    dead_code_type="unreachable",
                                    identifier=f"line_{next_stmt.lineno}",
                                    defined_at=next_stmt.lineno,
                                    usage_count=0
                                ))
                        
                        elif isinstance(stmt, ast.Raise):
                            next_stmt = body[i + 1]
                            if isinstance(next_stmt, ast.Expr) and isinstance(next_stmt.value, ast.Constant):
                                continue
                            
                            if not isinstance(stmt, ast.Raise) or stmt.exc is not None:
                                findings.append(DeadCodeFinding(
                                    file_path=file_data.path,
                                    line_number=next_stmt.lineno,
                                    severity=Severity.MEDIUM,
                                    category=FindingCategory.DEAD_CODE,
                                    title=f"Unreachable code after raise",
                                    description=f"Code at line {next_stmt.lineno} is unreachable after raise statement",
                                    code_snippet=self._get_code_snippet(file_data.path, next_stmt.lineno, static_result.project_path),
                                    tags=["unreachable_code", "cleanup"],
                                    dead_code_type="unreachable",
                                    identifier=f"line_{next_stmt.lineno}",
                                    defined_at=next_stmt.lineno,
                                    usage_count=0
                                ))
        
        return findings
    
    def _analyze_commented_code(self, static_result: StaticCollectorResult) -> list[DeadCodeFinding]:
        findings = []
        
        code_patterns = [
            r'^\s*#\s*(def |class |import |from |if |for |while |try:|except|return |yield )',
            r'^\s*#\s*\w+\s*=\s*',
            r'^\s*#\s*\w+\.\w+\(',
            r'^\s*#\s*\w+\(',
        ]
        
        for file_data in static_result.files:
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    lines = f.readlines()
            except Exception:
                continue
            
            consecutive_code_comments = []
            
            for i, line in enumerate(lines, 1):
                is_code_comment = False
                for pattern in code_patterns:
                    if re.match(pattern, line):
                        is_code_comment = True
                        break
                
                if is_code_comment:
                    consecutive_code_comments.append(i)
                else:
                    if len(consecutive_code_comments) >= 3:
                        findings.append(DeadCodeFinding(
                            file_path=file_data.path,
                            line_number=consecutive_code_comments[0],
                            end_line=consecutive_code_comments[-1],
                            severity=Severity.LOW,
                            category=FindingCategory.DEAD_CODE,
                            title=f"Commented-out code block",
                            description=f"Lines {consecutive_code_comments[0]}-{consecutive_code_comments[-1]} appear to be commented-out code",
                            code_snippet=self._get_code_snippet(file_data.path, consecutive_code_comments[0], static_result.project_path, context=5),
                            tags=["commented_code", "cleanup"],
                            dead_code_type="commented_code",
                            identifier=f"lines_{consecutive_code_comments[0]}_{consecutive_code_comments[-1]}",
                            defined_at=consecutive_code_comments[0],
                            usage_count=0
                        ))
                    consecutive_code_comments = []
            
            if len(consecutive_code_comments) >= 3:
                findings.append(DeadCodeFinding(
                    file_path=file_data.path,
                    line_number=consecutive_code_comments[0],
                    end_line=consecutive_code_comments[-1],
                    severity=Severity.LOW,
                    category=FindingCategory.DEAD_CODE,
                    title=f"Commented-out code block",
                    description=f"Lines {consecutive_code_comments[0]}-{consecutive_code_comments[-1]} appear to be commented-out code",
                    code_snippet=self._get_code_snippet(file_data.path, consecutive_code_comments[0], static_result.project_path, context=5),
                    tags=["commented_code", "cleanup"],
                    dead_code_type="commented_code",
                    identifier=f"lines_{consecutive_code_comments[0]}_{consecutive_code_comments[-1]}",
                    defined_at=consecutive_code_comments[0],
                    usage_count=0
                ))
        
        return findings
    
    def analyze(self, static_result: StaticCollectorResult) -> list[DeadCodeFinding]:
        self._collect_definitions_and_references(static_result)
        
        findings = []
        
        findings.extend(self._analyze_unused_imports(static_result))
        findings.extend(self._analyze_unused_functions(static_result))
        findings.extend(self._analyze_unreachable_code(static_result))
        findings.extend(self._analyze_commented_code(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings


