import ast
from pathlib import Path
from typing import Optional

import networkx as nx

from models.findings import (
    StaticCollectorResult,
    FlowFinding,
    Severity,
    FindingCategory,
)


HOP_THRESHOLDS = {
    'medium': 5,
    'high': 8,
    'very_high': 12
}

ENTRYPOINT_PATTERNS = [
    '__main__',
    'main',
    'run',
    'start',
    'execute',
    'cli',
    'app',
    'application'
]

API_DECORATORS = [
    'route', 'get', 'post', 'put', 'delete', 'patch',
    'api_view', 'action', 'endpoint',
    'app.route', 'app.get', 'app.post',
    'router.get', 'router.post',
    'blueprint.route'
]

LAYER_KEYWORDS = {
    'api': ['api', 'route', 'endpoint', 'view', 'controller', 'handler', 'rest', 'resource'],
    'service': ['service', 'manager', 'processor', 'engine', 'orchestrator', 'interactor', 'usecase'],
    'repository': ['repository', 'repo', 'dao', 'store', 'persistence', 'database', 'db', 'query'],
    'model': ['model', 'entity', 'domain', 'schema', 'dto', 'dataclass'],
    'utility': ['util', 'utils', 'helper', 'helpers', 'common', 'shared', 'lib', 'tools']
}

LAYER_ORDER = ['api', 'service', 'repository', 'model', 'utility']


class ExecutionFlowAnalyzer:
    def __init__(self):
        self.call_graph: Optional[nx.DiGraph] = None
        self.function_to_module: dict[str, str] = {}
        self.module_layers: dict[str, str] = {}
        self.entrypoints: list[str] = []
    
    def _classify_layer(self, path: str, name: str) -> str:
        combined = f"{path.lower()}/{name.lower()}"
        
        for layer, keywords in LAYER_KEYWORDS.items():
            for keyword in keywords:
                if keyword in combined:
                    return layer
        
        return 'unknown'
    
    def _is_entrypoint(self, func_name: str, decorators: list[str], file_path: str) -> bool:
        if func_name.lower() in ENTRYPOINT_PATTERNS:
            return True
        
        for dec in decorators:
            dec_lower = dec.lower()
            for api_dec in API_DECORATORS:
                if api_dec in dec_lower:
                    return True
        
        if '__main__' in file_path.lower() or 'cli' in file_path.lower():
            if func_name.lower() in ['main', 'run', 'cli', 'execute']:
                return True
        
        return False
    
    def _build_call_graph(self, static_result: StaticCollectorResult) -> nx.DiGraph:
        graph = nx.DiGraph()
        
        all_functions: dict[str, tuple[str, str]] = {}
        
        for file_data in static_result.files:
            module_name = file_data.path.replace('/', '.').replace('\\', '.').rstrip('.py')
            if module_name.endswith('.__init__'):
                module_name = module_name[:-9]
            
            self.module_layers[module_name] = self._classify_layer(file_data.path, module_name)
            
            for func in file_data.functions:
                if func.class_name:
                    full_name = f"{module_name}.{func.class_name}.{func.name}"
                else:
                    full_name = f"{module_name}.{func.name}"
                
                all_functions[func.name] = (full_name, module_name)
                self.function_to_module[full_name] = module_name
                
                graph.add_node(full_name, 
                    module=module_name,
                    file=file_data.path,
                    line=func.line_number,
                    layer=self._classify_layer(file_data.path, func.name)
                )
                
                if self._is_entrypoint(func.name, func.decorators, file_data.path):
                    self.entrypoints.append(full_name)
        
        for file_data in static_result.files:
            module_name = file_data.path.replace('/', '.').replace('\\', '.').rstrip('.py')
            if module_name.endswith('.__init__'):
                module_name = module_name[:-9]
            
            for func in file_data.functions:
                if func.class_name:
                    caller = f"{module_name}.{func.class_name}.{func.name}"
                else:
                    caller = f"{module_name}.{func.name}"
                
                for call in func.calls:
                    call_parts = call.split('.')
                    call_name = call_parts[-1]
                    
                    if call_name in all_functions:
                        callee, _ = all_functions[call_name]
                        if caller != callee:
                            graph.add_edge(caller, callee)
                    
                    if len(call_parts) > 1:
                        possible_module = '.'.join(call_parts[:-1])
                        possible_full = f"{possible_module}.{call_name}"
                        if possible_full in graph.nodes and caller != possible_full:
                            graph.add_edge(caller, possible_full)
        
        return graph
    
    def _get_code_snippet(self, file_path: str, line_number: int, project_path: str, context: int = 2) -> Optional[str]:
        try:
            full_path = Path(project_path) / file_path
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            start = max(0, line_number - 1 - context)
            end = min(len(lines), line_number + context)
            return ''.join(lines[start:end])
        except Exception:
            return None
    
    def _analyze_long_call_chains(self, static_result: StaticCollectorResult) -> list[FlowFinding]:
        findings = []
        
        if not self.entrypoints:
            return findings
        
        for entrypoint in self.entrypoints:
            if entrypoint not in self.call_graph.nodes:
                continue
            
            try:
                paths = nx.single_source_shortest_path(self.call_graph, entrypoint)
            except Exception:
                continue
            
            for target, path in paths.items():
                hop_count = len(path) - 1
                
                if hop_count >= HOP_THRESHOLDS['very_high']:
                    severity = Severity.HIGH
                elif hop_count >= HOP_THRESHOLDS['high']:
                    severity = Severity.MEDIUM
                elif hop_count >= HOP_THRESHOLDS['medium']:
                    severity = Severity.LOW
                else:
                    continue
                
                node_data = self.call_graph.nodes.get(target, {})
                file_path = node_data.get('file', '')
                line_number = node_data.get('line', 1)
                
                findings.append(FlowFinding(
                    file_path=file_path,
                    line_number=line_number,
                    severity=severity,
                    category=FindingCategory.FLOW,
                    title=f"Long call chain to {target.split('.')[-1]}",
                    description=f"Call chain of {hop_count} hops from entrypoint '{entrypoint.split('.')[-1]}'",
                    code_snippet=self._get_code_snippet(file_path, line_number, static_result.project_path),
                    tags=["long_call_chain", "complexity"],
                    flow_type="long_call_chain",
                    hop_count=hop_count,
                    call_chain=[p.split('.')[-1] for p in path]
                ))
        
        return findings
    
    def _analyze_cross_layer_violations(self, static_result: StaticCollectorResult) -> list[FlowFinding]:
        findings = []
        
        violation_pairs = [
            ('model', 'api'),
            ('model', 'service'),
            ('repository', 'api'),
            ('utility', 'api'),
            ('utility', 'service'),
        ]
        
        for caller, callee in self.call_graph.edges():
            caller_data = self.call_graph.nodes.get(caller, {})
            callee_data = self.call_graph.nodes.get(callee, {})
            
            caller_layer = caller_data.get('layer', 'unknown')
            callee_layer = callee_data.get('layer', 'unknown')
            
            if caller_layer == 'unknown' or callee_layer == 'unknown':
                continue
            
            is_violation = (caller_layer, callee_layer) in violation_pairs
            
            if is_violation:
                file_path = caller_data.get('file', '')
                line_number = caller_data.get('line', 1)
                
                findings.append(FlowFinding(
                    file_path=file_path,
                    line_number=line_number,
                    severity=Severity.MEDIUM,
                    category=FindingCategory.FLOW,
                    title=f"Cross-layer violation: {caller_layer} -> {callee_layer}",
                    description=f"'{caller.split('.')[-1]}' ({caller_layer}) calls '{callee.split('.')[-1]}' ({callee_layer})",
                    code_snippet=self._get_code_snippet(file_path, line_number, static_result.project_path),
                    tags=["cross_layer_violation", "architecture"],
                    flow_type="cross_layer_violation",
                    call_chain=[caller.split('.')[-1], callee.split('.')[-1]],
                    source_layer=caller_layer,
                    target_layer=callee_layer
                ))
        
        return findings
    
    def _analyze_missing_entrypoints(self, static_result: StaticCollectorResult) -> list[FlowFinding]:
        findings = []
        
        if not self.entrypoints:
            has_main_module = False
            for file_data in static_result.files:
                if '__main__' in file_data.path or 'main.py' in file_data.path:
                    has_main_module = True
                    break
            
            if has_main_module:
                findings.append(FlowFinding(
                    file_path="",
                    line_number=1,
                    severity=Severity.LOW,
                    category=FindingCategory.FLOW,
                    title="No clear entrypoints detected",
                    description="Project has main module but no clearly defined entrypoint functions",
                    tags=["missing_entrypoint", "architecture"],
                    flow_type="missing_entrypoint"
                ))
        
        return findings
    
    def _analyze_isolated_functions(self, static_result: StaticCollectorResult) -> list[FlowFinding]:
        findings = []
        
        for node in self.call_graph.nodes():
            in_degree = self.call_graph.in_degree(node)
            out_degree = self.call_graph.out_degree(node)
            
            if in_degree == 0 and out_degree == 0:
                node_data = self.call_graph.nodes.get(node, {})
                file_path = node_data.get('file', '')
                line_number = node_data.get('line', 1)
                func_name = node.split('.')[-1]
                
                if func_name.startswith('_') or func_name.startswith('test'):
                    continue
                
                if node in self.entrypoints:
                    continue
        
        return findings
    
    def analyze(self, static_result: StaticCollectorResult) -> list[FlowFinding]:
        self.call_graph = self._build_call_graph(static_result)
        
        findings = []
        
        findings.extend(self._analyze_long_call_chains(static_result))
        findings.extend(self._analyze_cross_layer_violations(static_result))
        findings.extend(self._analyze_missing_entrypoints(static_result))
        findings.extend(self._analyze_isolated_functions(static_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            f.file_path,
            f.line_number
        ))
        
        return findings
    
    def get_call_graph(self) -> Optional[nx.DiGraph]:
        return self.call_graph
    
    def get_entrypoints(self) -> list[str]:
        return self.entrypoints


