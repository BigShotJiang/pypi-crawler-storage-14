import statistics
from typing import Optional
from collections import defaultdict, Counter
from datetime import datetime

from models.findings import (
    DynamicCollectorResult,
    LoggingFinding,
    Severity,
    FindingCategory,
)


SPAM_THRESHOLD = 1000
SPAM_PERCENTAGE_THRESHOLD = 0.3
STUCK_VALUE_THRESHOLD = 100
HIGH_FREQUENCY_THRESHOLD = 100


class LoggingDynamicAnalyzer:
    def __init__(
        self,
        spam_threshold: int = SPAM_THRESHOLD,
        spam_percentage: float = SPAM_PERCENTAGE_THRESHOLD
    ):
        self.spam_threshold = spam_threshold
        self.spam_percentage = spam_percentage
    
    def _extract_message_template(self, message: str) -> str:
        import re
        template = re.sub(r'\b\d+\.?\d*\b', '<NUM>', message)
        template = re.sub(r'0x[a-fA-F0-9]+', '<HEX>', template)
        template = re.sub(r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}', '<UUID>', template)
        template = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '<EMAIL>', template)
        return template
    
    def _analyze_log_spam(self, dynamic_result: DynamicCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        message_counts: Counter = Counter()
        message_locations: dict[str, tuple[str, int, str]] = {}
        
        for record in dynamic_result.log_records:
            template = self._extract_message_template(record.message_template)
            message_counts[template] += 1
            
            if template not in message_locations:
                message_locations[template] = (record.module, record.line_number, record.level)
        
        total_logs = len(dynamic_result.log_records)
        if total_logs == 0:
            return findings
        
        for template, count in message_counts.most_common():
            percentage = count / total_logs
            
            if count >= self.spam_threshold or percentage >= self.spam_percentage:
                module, line_num, level = message_locations[template]
                file_path = module.replace('.', '/') + '.py'
                
                findings.append(LoggingFinding(
                    file_path=file_path,
                    line_number=line_num,
                    severity=Severity.MEDIUM,
                    category=FindingCategory.LOGGING,
                    title=f"Log spam detected",
                    description=f"Log message emitted {count} times ({percentage:.1%} of all logs): '{template[:80]}...'",
                    tags=["log_spam", "performance", "cleanup"],
                    logging_type="spam",
                    log_level=level,
                    message_template=template[:200],
                    call_count=count,
                    has_variables='<NUM>' in template or '<UUID>' in template,
                    classification="spammy"
                ))
        
        return findings
    
    def _analyze_stuck_log_values(self, dynamic_result: DynamicCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        message_values: dict[str, list[str]] = defaultdict(list)
        message_locations: dict[str, tuple[str, int, str]] = {}
        
        for record in dynamic_result.log_records:
            template = record.message_template
            message_values[template].append(record.message)
            
            if template not in message_locations:
                message_locations[template] = (record.module, record.line_number, record.level)
        
        for template, messages in message_values.items():
            if len(messages) < STUCK_VALUE_THRESHOLD:
                continue
            
            unique_messages = set(messages)
            
            if len(unique_messages) == 1:
                module, line_num, level = message_locations[template]
                file_path = module.replace('.', '/') + '.py'
                
                findings.append(LoggingFinding(
                    file_path=file_path,
                    line_number=line_num,
                    severity=Severity.MEDIUM,
                    category=FindingCategory.LOGGING,
                    title=f"Log message with stuck value",
                    description=f"Log message emitted {len(messages)} times with identical output: '{messages[0][:80]}...'",
                    tags=["stuck_log_value", "metric_stagnation"],
                    logging_type="redundant",
                    log_level=level,
                    message_template=template[:200],
                    call_count=len(messages),
                    has_variables=False,
                    classification="likely_redundant"
                ))
        
        return findings
    
    def _analyze_log_frequency(self, dynamic_result: DynamicCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        if dynamic_result.duration_seconds <= 0:
            return findings
        
        message_timestamps: dict[str, list[datetime]] = defaultdict(list)
        message_locations: dict[str, tuple[str, int, str]] = {}
        
        for record in dynamic_result.log_records:
            template = self._extract_message_template(record.message_template)
            message_timestamps[template].append(record.timestamp)
            
            if template not in message_locations:
                message_locations[template] = (record.module, record.line_number, record.level)
        
        for template, timestamps in message_timestamps.items():
            if len(timestamps) < 10:
                continue
            
            frequency = len(timestamps) / dynamic_result.duration_seconds
            
            if frequency >= HIGH_FREQUENCY_THRESHOLD:
                module, line_num, level = message_locations[template]
                file_path = module.replace('.', '/') + '.py'
                
                findings.append(LoggingFinding(
                    file_path=file_path,
                    line_number=line_num,
                    severity=Severity.MEDIUM,
                    category=FindingCategory.LOGGING,
                    title=f"High-frequency logging",
                    description=f"Log message emitted {frequency:.1f} times/second over {dynamic_result.duration_seconds:.1f}s",
                    tags=["high_frequency_logging", "performance"],
                    logging_type="spammy",
                    log_level=level,
                    message_template=template[:200],
                    call_count=len(timestamps),
                    has_variables=True,
                    classification="spammy"
                ))
        
        return findings
    
    def _analyze_level_distribution(self, dynamic_result: DynamicCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        level_counts: Counter = Counter()
        
        for record in dynamic_result.log_records:
            level_counts[record.level] += 1
        
        total = sum(level_counts.values())
        if total == 0:
            return findings
        
        debug_count = level_counts.get('DEBUG', 0)
        debug_percentage = debug_count / total
        
        if debug_percentage > 0.7 and debug_count > 100:
            findings.append(LoggingFinding(
                file_path="",
                line_number=1,
                severity=Severity.LOW,
                category=FindingCategory.LOGGING,
                title="Excessive debug logging at runtime",
                description=f"{debug_count} DEBUG logs ({debug_percentage:.1%} of total) may indicate debug logging left enabled in production",
                tags=["excessive_debug", "performance"],
                logging_type="spammy",
                log_level="DEBUG",
                message_template="",
                call_count=debug_count,
                has_variables=False,
                classification="spammy"
            ))
        
        return findings
    
    def analyze(self, dynamic_result: DynamicCollectorResult) -> list[LoggingFinding]:
        findings = []
        
        findings.extend(self._analyze_log_spam(dynamic_result))
        findings.extend(self._analyze_stuck_log_values(dynamic_result))
        findings.extend(self._analyze_log_frequency(dynamic_result))
        findings.extend(self._analyze_level_distribution(dynamic_result))
        
        findings.sort(key=lambda f: (
            0 if f.severity == Severity.CRITICAL else
            1 if f.severity == Severity.HIGH else
            2 if f.severity == Severity.MEDIUM else
            3 if f.severity == Severity.LOW else 4,
            -f.call_count,
            f.file_path,
            f.line_number
        ))
        
        return findings
    
    def get_logging_statistics(self, dynamic_result: DynamicCollectorResult) -> dict:
        stats = {
            'total_log_records': len(dynamic_result.log_records),
            'unique_messages': 0,
            'by_level': Counter(),
            'by_module': Counter(),
            'logs_per_second': 0.0,
            'top_messages': [],
            'spam_candidates': 0,
        }
        
        message_counts: Counter = Counter()
        
        for record in dynamic_result.log_records:
            stats['by_level'][record.level] += 1
            stats['by_module'][record.module] += 1
            template = self._extract_message_template(record.message_template)
            message_counts[template] += 1
        
        stats['unique_messages'] = len(message_counts)
        
        if dynamic_result.duration_seconds > 0:
            stats['logs_per_second'] = len(dynamic_result.log_records) / dynamic_result.duration_seconds
        
        stats['top_messages'] = [
            {'template': t[:100], 'count': c}
            for t, c in message_counts.most_common(10)
        ]
        
        total = len(dynamic_result.log_records)
        if total > 0:
            for template, count in message_counts.items():
                if count >= self.spam_threshold or count / total >= self.spam_percentage:
                    stats['spam_candidates'] += 1
        
        return stats


