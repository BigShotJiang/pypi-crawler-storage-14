#!/usr/bin/env python3
import argparse
import sys
import webbrowser
from pathlib import Path
from datetime import datetime

from dotenv import load_dotenv

load_dotenv()

from collectors.static_collector import StaticCollector
from analyzers.placeholder_analyzer import PlaceholderAnalyzer
from analyzers.complexity_analyzer import ComplexityAnalyzer
from analyzers.execution_flow_analyzer import ExecutionFlowAnalyzer
from analyzers.naming_analyzer import NamingAnalyzer
from analyzers.dead_code_analyzer import DeadCodeAnalyzer
from analyzers.security_analyzer import SecurityAnalyzer
from analyzers.duplication_analyzer import DuplicationAnalyzer
from analyzers.logging_static_analyzer import LoggingStaticAnalyzer
from intelligence.rule_engine import RuleEngine
from intelligence.llm_interpreter import LLMInterpreter
from reporting.report_generator import ReportGenerator


def print_progress(message: str, verbose: bool = True):
    if verbose:
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] {message}")


def run_analysis(
    target_path: str,
    output_path: str = "report.html",
    skip_dynamic: bool = False,
    skip_llm: bool = False,
    verbose: bool = True,
    open_browser: bool = True
) -> Path:
    target = Path(target_path).resolve()
    if not target.exists():
        print(f"Error: Target path does not exist: {target}")
        sys.exit(1)
    
    project_name = target.name
    
    print_progress(f"Starting analysis of: {project_name}", verbose)
    print_progress(f"Target path: {target}", verbose)
    
    print_progress("Running static collector...", verbose)
    static_collector = StaticCollector(str(target))
    static_result = static_collector.collect()
    print_progress(f"Collected {static_result.total_files} files, {static_result.total_lines} lines", verbose)
    
    print_progress("Running placeholder analyzer...", verbose)
    placeholder_analyzer = PlaceholderAnalyzer()
    placeholder_findings = placeholder_analyzer.analyze(static_result)
    print_progress(f"Found {len(placeholder_findings)} placeholder issues", verbose)
    
    print_progress("Running complexity analyzer...", verbose)
    complexity_analyzer = ComplexityAnalyzer()
    complexity_findings = complexity_analyzer.analyze(static_result)
    print_progress(f"Found {len(complexity_findings)} complexity issues", verbose)
    
    print_progress("Running execution flow analyzer...", verbose)
    flow_analyzer = ExecutionFlowAnalyzer()
    flow_findings = flow_analyzer.analyze(static_result)
    print_progress(f"Found {len(flow_findings)} flow issues", verbose)
    
    print_progress("Running naming analyzer...", verbose)
    naming_analyzer = NamingAnalyzer()
    naming_findings = naming_analyzer.analyze(static_result)
    print_progress(f"Found {len(naming_findings)} naming issues", verbose)
    
    print_progress("Running dead code analyzer...", verbose)
    dead_code_analyzer = DeadCodeAnalyzer()
    dead_code_findings = dead_code_analyzer.analyze(static_result)
    print_progress(f"Found {len(dead_code_findings)} dead code issues", verbose)
    
    print_progress("Running security analyzer...", verbose)
    security_analyzer = SecurityAnalyzer()
    security_findings = security_analyzer.analyze(static_result)
    print_progress(f"Found {len(security_findings)} security issues", verbose)
    
    print_progress("Running duplication analyzer...", verbose)
    duplication_analyzer = DuplicationAnalyzer()
    duplication_findings = duplication_analyzer.analyze(static_result)
    print_progress(f"Found {len(duplication_findings)} duplication issues", verbose)
    
    print_progress("Running logging static analyzer...", verbose)
    logging_static_analyzer = LoggingStaticAnalyzer()
    logging_findings = logging_static_analyzer.analyze(static_result)
    print_progress(f"Found {len(logging_findings)} logging issues", verbose)
    
    dynamic_result = None
    metric_findings = []
    
    print_progress("Running rule engine...", verbose)
    rule_engine = RuleEngine()
    
    report_generator = ReportGenerator()
    report = report_generator.create_report(
        project_name=project_name,
        project_path=str(target),
        static_result=static_result,
        dynamic_result=dynamic_result,
        placeholder_findings=placeholder_findings,
        complexity_findings=complexity_findings,
        flow_findings=flow_findings,
        naming_findings=naming_findings,
        dead_code_findings=dead_code_findings,
        security_findings=security_findings,
        duplication_findings=duplication_findings,
        logging_findings=logging_findings,
        metric_findings=metric_findings
    )
    
    report = rule_engine.process_report(report)
    print_progress(f"Generated {len(report.recommendations)} recommendations", verbose)
    print_progress(f"Health score: {report.health_score}/100 (Grade: {report.health_grade})", verbose)
    
    if not skip_llm:
        print_progress("Running LLM interpreter...", verbose)
        llm_interpreter = LLMInterpreter()
        if llm_interpreter.is_available():
            report = llm_interpreter.process_report(report)
            print_progress("LLM analysis complete", verbose)
        else:
            print_progress("LLM not available (no API key), using rule-based summary", verbose)
    
    print_progress("Generating HTML report...", verbose)
    output_file = Path(output_path).resolve()
    report_generator.generate_html(report, output_file)
    print_progress(f"Report saved to: {output_file}", verbose)
    
    if open_browser:
        print_progress("Opening report in browser...", verbose)
        webbrowser.open(f"file://{output_file}")
    
    return output_file


def main():
    parser = argparse.ArgumentParser(
        description="Application Analysis Tool - Comprehensive Python code analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  analyze-app ./my_project
  analyze-app ./my_project --output analysis.html
  analyze-app ./my_project --skip-llm --no-browser
        """
    )
    
    parser.add_argument(
        "target",
        help="Path to the Python project to analyze"
    )
    
    parser.add_argument(
        "--output", "-o",
        default="report.html",
        help="Output HTML report path (default: report.html)"
    )
    
    parser.add_argument(
        "--skip-dynamic",
        action="store_true",
        help="Skip dynamic analysis (runtime tracing)"
    )
    
    parser.add_argument(
        "--skip-llm",
        action="store_true",
        help="Skip LLM-powered analysis"
    )
    
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        default=True,
        help="Show progress during analysis (default: True)"
    )
    
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress progress output"
    )
    
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open report in browser after generation"
    )
    
    args = parser.parse_args()
    
    verbose = not args.quiet
    
    try:
        run_analysis(
            target_path=args.target,
            output_path=args.output,
            skip_dynamic=args.skip_dynamic,
            skip_llm=args.skip_llm,
            verbose=verbose,
            open_browser=not args.no_browser
        )
        
        print_progress("Analysis complete!", verbose)
        return 0
        
    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user")
        return 1
    except Exception as e:
        print(f"Error during analysis: {e}")
        if verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())

