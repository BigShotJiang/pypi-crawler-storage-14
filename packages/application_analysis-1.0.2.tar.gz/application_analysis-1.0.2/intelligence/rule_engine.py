from typing import Optional
from collections import defaultdict
import uuid

from models.findings import (
    Severity,
    EffortLevel,
    FindingCategory,
    BaseFinding,
    PlaceholderFinding,
    ComplexityFinding,
    FlowFinding,
    NamingFinding,
    DeadCodeFinding,
    SecurityFinding,
    DuplicationFinding,
    LoggingFinding,
    MetricFinding,
    Recommendation,
    AnalysisReport,
)


class Rule:
    def __init__(
        self,
        name: str,
        condition: callable,
        severity_modifier: Optional[Severity] = None,
        tags_to_add: Optional[list[str]] = None,
        recommendation_template: Optional[str] = None,
        effort: EffortLevel = EffortLevel.MEDIUM,
        impact: str = ""
    ):
        self.name = name
        self.condition = condition
        self.severity_modifier = severity_modifier
        self.tags_to_add = tags_to_add or []
        self.recommendation_template = recommendation_template
        self.effort = effort
        self.impact = impact


PLACEHOLDER_RULES = [
    Rule(
        name="stub_in_production",
        condition=lambda f: f.placeholder_type == "stub_function" and "test" not in f.file_path.lower(),
        severity_modifier=Severity.HIGH,
        tags_to_add=["production_risk"],
        recommendation_template="Implement the stub function '{finding.matched_pattern}' or remove it if unused",
        effort=EffortLevel.MEDIUM,
        impact="Prevents runtime errors from unimplemented functionality"
    ),
    Rule(
        name="excessive_todos",
        condition=lambda f: f.placeholder_type == "keyword" and "todo" in f.matched_pattern.lower(),
        tags_to_add=["technical_debt"],
        recommendation_template="Address TODO item or create a tracking issue",
        effort=EffortLevel.SMALL,
        impact="Reduces technical debt and improves code completeness"
    ),
    Rule(
        name="fixme_high_priority",
        condition=lambda f: f.placeholder_type == "keyword" and "fixme" in f.matched_pattern.lower(),
        severity_modifier=Severity.HIGH,
        tags_to_add=["bug_risk"],
        recommendation_template="FIXME indicates a known issue - prioritize fixing",
        effort=EffortLevel.MEDIUM,
        impact="Addresses known bugs and issues"
    ),
]

COMPLEXITY_RULES = [
    Rule(
        name="god_function",
        condition=lambda f: f.complexity_type == "cyclomatic" and f.metric_value >= 25,
        severity_modifier=Severity.CRITICAL,
        tags_to_add=["refactor_critical", "god_function"],
        recommendation_template="Break down function '{finding.function_name}' into smaller, focused functions",
        effort=EffortLevel.LARGE,
        impact="Significantly improves maintainability and testability"
    ),
    Rule(
        name="deep_nesting_refactor",
        condition=lambda f: f.complexity_type == "nesting" and f.metric_value >= 5,
        severity_modifier=Severity.HIGH,
        tags_to_add=["readability"],
        recommendation_template="Reduce nesting in '{finding.function_name}' using early returns or extracting methods",
        effort=EffortLevel.MEDIUM,
        impact="Improves code readability and reduces cognitive load"
    ),
    Rule(
        name="circular_dependency_critical",
        condition=lambda f: f.complexity_type == "circular_dependency",
        severity_modifier=Severity.CRITICAL,
        tags_to_add=["architecture_violation"],
        recommendation_template="Break circular dependency by introducing interfaces or restructuring modules",
        effort=EffortLevel.LARGE,
        impact="Prevents import issues and improves module independence"
    ),
    Rule(
        name="hub_module_refactor",
        condition=lambda f: f.complexity_type == "coupling" and f.metric_value >= 10,
        tags_to_add=["architecture"],
        recommendation_template="Consider splitting module or introducing abstraction layers",
        effort=EffortLevel.LARGE,
        impact="Reduces coupling and improves modularity"
    ),
]

METRIC_RULES = [
    Rule(
        name="training_metric_constant",
        condition=lambda f: f.metric_type == "constant" and any(t in f.tags for t in ["training_logic_issue"]),
        severity_modifier=Severity.CRITICAL,
        tags_to_add=["optimization_blocker"],
        recommendation_template="Verify that '{finding.metric_name}' is being updated in the training loop",
        effort=EffortLevel.MEDIUM,
        impact="Critical for ensuring training actually occurs"
    ),
    Rule(
        name="metric_near_constant",
        condition=lambda f: f.metric_type == "near_constant",
        severity_modifier=Severity.HIGH,
        tags_to_add=["potential_bug"],
        recommendation_template="Check calculation logic for '{finding.metric_name}' - variance is suspiciously low",
        effort=EffortLevel.MEDIUM,
        impact="May indicate learning rate or gradient issues"
    ),
    Rule(
        name="stuck_loop_metric",
        condition=lambda f: f.metric_type == "stuck_in_loop",
        severity_modifier=Severity.HIGH,
        tags_to_add=["training_stall"],
        recommendation_template="Investigate why '{finding.metric_name}' shows no progress over iterations",
        effort=EffortLevel.MEDIUM,
        impact="Training may not be converging"
    ),
]

LOGGING_RULES = [
    Rule(
        name="log_spam_cleanup",
        condition=lambda f: f.logging_type == "spam" and f.call_count >= 1000,
        severity_modifier=Severity.MEDIUM,
        tags_to_add=["performance_impact"],
        recommendation_template="Throttle or remove excessive logging - {finding.call_count} occurrences detected",
        effort=EffortLevel.SMALL,
        impact="Improves runtime performance and log readability"
    ),
    Rule(
        name="dev_leftover_cleanup",
        condition=lambda f: f.logging_type == "dev_leftover",
        tags_to_add=["cleanup"],
        recommendation_template="Remove development debug print statement",
        effort=EffortLevel.SMALL,
        impact="Cleans up production code"
    ),
    Rule(
        name="missing_logging_add",
        condition=lambda f: f.logging_type == "missing_context",
        recommendation_template="Add structured logging to improve observability",
        effort=EffortLevel.SMALL,
        impact="Improves debugging and monitoring capabilities"
    ),
]

SECURITY_RULES = [
    Rule(
        name="hardcoded_secret_critical",
        condition=lambda f: f.security_type == "hardcoded_secret",
        severity_modifier=Severity.CRITICAL,
        tags_to_add=["security_vulnerability", "immediate_action"],
        recommendation_template="Move secret to environment variable or secrets manager immediately",
        effort=EffortLevel.SMALL,
        impact="Prevents credential exposure"
    ),
    Rule(
        name="eval_injection",
        condition=lambda f: f.security_type == "eval_exec",
        severity_modifier=Severity.CRITICAL,
        tags_to_add=["code_injection_risk"],
        recommendation_template="Replace eval/exec with safe alternatives like ast.literal_eval",
        effort=EffortLevel.MEDIUM,
        impact="Prevents arbitrary code execution"
    ),
    Rule(
        name="sql_injection",
        condition=lambda f: f.security_type == "sql_injection",
        severity_modifier=Severity.CRITICAL,
        tags_to_add=["data_breach_risk"],
        recommendation_template="Use parameterized queries instead of string formatting",
        effort=EffortLevel.MEDIUM,
        impact="Prevents database compromise"
    ),
]

DEAD_CODE_RULES = [
    Rule(
        name="unused_import_cleanup",
        condition=lambda f: f.dead_code_type == "unused_import",
        recommendation_template="Remove unused import '{finding.identifier}'",
        effort=EffortLevel.SMALL,
        impact="Reduces code clutter and import overhead"
    ),
    Rule(
        name="unreachable_code_fix",
        condition=lambda f: f.dead_code_type == "unreachable",
        severity_modifier=Severity.MEDIUM,
        tags_to_add=["logic_error"],
        recommendation_template="Remove unreachable code or fix control flow logic",
        effort=EffortLevel.SMALL,
        impact="Removes dead code and may fix logic bugs"
    ),
]

DUPLICATION_RULES = [
    Rule(
        name="exact_duplicate_refactor",
        condition=lambda f: f.duplication_type == "exact_duplicate" and f.duplicate_count >= 3,
        severity_modifier=Severity.MEDIUM,
        tags_to_add=["dry_violation"],
        recommendation_template="Extract duplicated code into a shared function",
        effort=EffortLevel.MEDIUM,
        impact="Reduces maintenance burden and bug surface"
    ),
    Rule(
        name="near_duplicate_consider",
        condition=lambda f: f.duplication_type == "near_duplicate" and f.similarity_score >= 0.9,
        tags_to_add=["consider_refactor"],
        recommendation_template="Consider unifying similar functions with parameters",
        effort=EffortLevel.MEDIUM,
        impact="Reduces code duplication"
    ),
]


class RuleEngine:
    def __init__(self):
        self.rules: dict[FindingCategory, list[Rule]] = {
            FindingCategory.PLACEHOLDER: PLACEHOLDER_RULES,
            FindingCategory.COMPLEXITY: COMPLEXITY_RULES,
            FindingCategory.METRIC: METRIC_RULES,
            FindingCategory.LOGGING: LOGGING_RULES,
            FindingCategory.SECURITY: SECURITY_RULES,
            FindingCategory.DEAD_CODE: DEAD_CODE_RULES,
            FindingCategory.DUPLICATION: DUPLICATION_RULES,
            FindingCategory.FLOW: [],
            FindingCategory.NAMING: [],
            FindingCategory.PERFORMANCE: [],
        }
    
    def apply_rules(self, finding: BaseFinding) -> tuple[BaseFinding, list[str]]:
        matched_rules = []
        category_rules = self.rules.get(finding.category, [])
        
        for rule in category_rules:
            try:
                if rule.condition(finding):
                    matched_rules.append(rule.name)
                    
                    if rule.severity_modifier:
                        finding.severity = rule.severity_modifier
                    
                    if rule.tags_to_add:
                        finding.tags = list(set(finding.tags + rule.tags_to_add))
            except Exception:
                continue
        
        return finding, matched_rules
    
    def generate_recommendations(self, findings: list[BaseFinding]) -> list[Recommendation]:
        recommendations: dict[str, Recommendation] = {}
        
        for finding in findings:
            category_rules = self.rules.get(finding.category, [])
            
            for rule in category_rules:
                try:
                    if rule.condition(finding) and rule.recommendation_template:
                        rec_key = f"{rule.name}_{finding.category}"
                        
                        if rec_key not in recommendations:
                            title = rule.recommendation_template.split(' - ')[0]
                            if '{finding.' in title:
                                title = self._format_template(rule.recommendation_template, finding)
                            
                            recommendations[rec_key] = Recommendation(
                                id=str(uuid.uuid4())[:8],
                                title=title[:100],
                                category=finding.category,
                                severity=finding.severity,
                                effort=rule.effort,
                                impact=rule.impact,
                                description=self._format_template(rule.recommendation_template, finding),
                                affected_files=[finding.file_path],
                                finding_ids=[]
                            )
                        else:
                            if finding.file_path not in recommendations[rec_key].affected_files:
                                recommendations[rec_key].affected_files.append(finding.file_path)
                            
                            if finding.severity.value < recommendations[rec_key].severity.value:
                                recommendations[rec_key].severity = finding.severity
                except Exception:
                    continue
        
        recs = list(recommendations.values())
        recs.sort(key=lambda r: (
            0 if r.severity == Severity.CRITICAL else
            1 if r.severity == Severity.HIGH else
            2 if r.severity == Severity.MEDIUM else
            3 if r.severity == Severity.LOW else 4,
            len(r.affected_files) * -1
        ))
        
        return recs
    
    def _format_template(self, template: str, finding: BaseFinding) -> str:
        result = template
        
        replacements = {
            '{finding.file_path}': finding.file_path,
            '{finding.line_number}': str(finding.line_number),
            '{finding.title}': finding.title,
        }
        
        if hasattr(finding, 'function_name') and finding.function_name:
            replacements['{finding.function_name}'] = finding.function_name
        if hasattr(finding, 'class_name') and finding.class_name:
            replacements['{finding.class_name}'] = finding.class_name
        if hasattr(finding, 'metric_name'):
            replacements['{finding.metric_name}'] = finding.metric_name
        if hasattr(finding, 'identifier'):
            replacements['{finding.identifier}'] = finding.identifier
        if hasattr(finding, 'matched_pattern'):
            replacements['{finding.matched_pattern}'] = finding.matched_pattern
        if hasattr(finding, 'call_count'):
            replacements['{finding.call_count}'] = str(finding.call_count)
        
        for key, value in replacements.items():
            result = result.replace(key, str(value) if value else '')
        
        return result
    
    def calculate_health_score(self, findings: list[BaseFinding]) -> tuple[int, str]:
        if not findings:
            return 100, 'A'
        
        severity_weights = {
            Severity.CRITICAL: 3,
            Severity.HIGH: 1.5,
            Severity.MEDIUM: 0.5,
            Severity.LOW: 0.1,
            Severity.INFO: 0
        }
        
        total_penalty = 0
        for finding in findings:
            total_penalty += severity_weights.get(finding.severity, 0)
        
        import math
        score = int(100 * math.exp(-total_penalty / 50))
        score = max(0, min(100, score))
        
        if score >= 85:
            grade = 'A'
        elif score >= 70:
            grade = 'B'
        elif score >= 55:
            grade = 'C'
        elif score >= 40:
            grade = 'D'
        else:
            grade = 'F'
        
        return score, grade
    
    def process_report(self, report: AnalysisReport) -> AnalysisReport:
        all_findings: list[BaseFinding] = []
        all_findings.extend(report.placeholder_findings)
        all_findings.extend(report.complexity_findings)
        all_findings.extend(report.flow_findings)
        all_findings.extend(report.naming_findings)
        all_findings.extend(report.dead_code_findings)
        all_findings.extend(report.security_findings)
        all_findings.extend(report.duplication_findings)
        all_findings.extend(report.logging_findings)
        all_findings.extend(report.metric_findings)
        
        for finding in all_findings:
            self.apply_rules(finding)
        
        report.recommendations = self.generate_recommendations(all_findings)
        
        report.health_score, report.health_grade = self.calculate_health_score(all_findings)
        
        return report


