import os
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel

from models.findings import (
    AnalysisReport,
    LoggingFinding,
    MetricFinding,
    Severity,
)

load_dotenv(override=True)


class LogClassification(BaseModel):
    message: str
    classification: str
    rewrite_suggestion: str


class LogClassificationBatch(BaseModel):
    classifications: list[LogClassification]


class MetricAnalysis(BaseModel):
    metric_name: str
    likely_cause: str
    recommended_fix: str


class MetricAnalysisBatch(BaseModel):
    analyses: list[MetricAnalysis]


class ExecutiveSummary(BaseModel):
    health_grade: str
    key_issues: list[str]
    narrative: str


class FindingExplanation(BaseModel):
    finding_id: str
    plain_language_explanation: str
    technical_details: str
    suggested_action: str


class FindingExplanationBatch(BaseModel):
    explanations: list[FindingExplanation]


class LLMInterpreter:
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-5-nano"):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model = model
        self.client = None
        
        if self.api_key:
            self.client = OpenAI(api_key=self.api_key)
    
    def is_available(self) -> bool:
        return self.client is not None and self.api_key is not None
    
    def classify_logs(self, logs: list[LoggingFinding], max_logs: int = 20) -> list[LogClassification]:
        if not self.is_available():
            return []
        
        sample_logs = logs[:max_logs]
        if not sample_logs:
            return []
        
        log_descriptions = []
        for i, log in enumerate(sample_logs):
            log_descriptions.append(
                f"{i+1}. Level: {log.log_level or 'print'}, "
                f"Message: '{log.message_template[:100]}', "
                f"Has variables: {log.has_variables}, "
                f"File: {log.file_path}"
            )
        
        prompt = f"""Analyze these log messages from a Python application and classify each one.

Log messages:
{chr(10).join(log_descriptions)}

For each log message, determine:
1. Classification: 'useful' (helps understand application flow or debug issues), 'debugging' (useful only for development), or 'noise' (uninformative or redundant)
2. A suggested rewrite that would make the log more useful (include relevant variable values, context, or state information)

Consider:
- Logs with variable values are generally more useful
- Generic messages like 'here', 'debug', 'test' are noise
- Logs that track important state changes are useful
- Excessive detail in hot loops is usually noise"""

        try:
            completion = self.client.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a code quality expert analyzing logging patterns. Provide concise, actionable classifications."},
                    {"role": "user", "content": prompt}
                ],
                temperature=1.0,
                max_completion_tokens=16000,
                response_format=LogClassificationBatch,
            )
            
            result = completion.choices[0].message.parsed
            return result.classifications if result else []
        except Exception:
            return []
    
    def analyze_metrics(self, metrics: list[MetricFinding], max_metrics: int = 10) -> list[MetricAnalysis]:
        if not self.is_available():
            return []
        
        sample_metrics = metrics[:max_metrics]
        if not sample_metrics:
            return []
        
        metric_descriptions = []
        for i, metric in enumerate(sample_metrics):
            metric_descriptions.append(
                f"{i+1}. Name: '{metric.metric_name}', "
                f"Type: {metric.metric_type}, "
                f"Samples: {metric.sample_count}, "
                f"Variance: {metric.variance:.6f}, "
                f"Range: {metric.min_value:.4f} - {metric.max_value:.4f}, "
                f"File: {metric.file_path}"
            )
        
        prompt = f"""Analyze these metrics from a Python application that appear to be stagnant or problematic.

Metrics:
{chr(10).join(metric_descriptions)}

For each metric, provide:
1. The most likely cause for why this metric is not changing (e.g., update function not called, using wrong variable, gradient issues, initialization problem)
2. A specific recommended fix to address the issue

Consider common issues like:
- Training loops that don't actually update weights
- Metrics logged before updates occur
- Using a copy of a value instead of the live value
- Missing gradient calculations
- Incorrect variable references"""

        try:
            completion = self.client.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a machine learning expert analyzing training metrics. Provide specific, technical diagnoses."},
                    {"role": "user", "content": prompt}
                ],
                temperature=1.0,
                max_completion_tokens=16000,
                response_format=MetricAnalysisBatch,
            )
            
            result = completion.choices[0].message.parsed
            return result.analyses if result else []
        except Exception:
            return []
    
    def generate_executive_summary(self, report: AnalysisReport) -> ExecutiveSummary:
        if not self.is_available():
            return ExecutiveSummary(
                health_grade=report.health_grade,
                key_issues=self._extract_key_issues(report),
                narrative=self._generate_fallback_narrative(report)
            )
        
        findings_summary = self._summarize_findings(report)
        
        prompt = f"""Generate an executive summary for this code analysis report.

Project: {report.project_name}
Health Score: {report.health_score}/100 (Grade: {report.health_grade})

Findings Summary:
{findings_summary}

Create a summary that:
1. Is understandable by non-programmers
2. Highlights the most critical issues first
3. Provides a clear narrative of the overall health
4. Lists 3-5 key issues in plain language
5. Is concise but comprehensive

The narrative should explain what the findings mean for the project's quality, maintainability, and risk."""

        try:
            completion = self.client.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a technical writer creating executive summaries of code quality reports. Write clearly for both technical and non-technical audiences."},
                    {"role": "user", "content": prompt}
                ],
                temperature=1.0,
                max_completion_tokens=16000,
                response_format=ExecutiveSummary,
            )
            
            result = completion.choices[0].message.parsed
            return result if result else ExecutiveSummary(
                health_grade=report.health_grade,
                key_issues=self._extract_key_issues(report),
                narrative=self._generate_fallback_narrative(report)
            )
        except Exception:
            return ExecutiveSummary(
                health_grade=report.health_grade,
                key_issues=self._extract_key_issues(report),
                narrative=self._generate_fallback_narrative(report)
            )
    
    def explain_findings(self, findings: list, max_findings: int = 10) -> list[FindingExplanation]:
        if not self.is_available():
            return []
        
        sample_findings = findings[:max_findings]
        if not sample_findings:
            return []
        
        finding_descriptions = []
        for i, finding in enumerate(sample_findings):
            finding_descriptions.append(
                f"{i+1}. [{finding.severity.value.upper()}] {finding.title}\n"
                f"   File: {finding.file_path}:{finding.line_number}\n"
                f"   Description: {finding.description}"
            )
        
        prompt = f"""Explain these code analysis findings in plain language.

Findings:
{chr(10).join(finding_descriptions)}

For each finding, provide:
1. A plain language explanation that a non-programmer could understand
2. Technical details for developers
3. A specific suggested action to fix the issue

Be concise but thorough."""

        try:
            completion = self.client.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a code quality expert explaining technical findings to mixed audiences. Provide clear, actionable explanations."},
                    {"role": "user", "content": prompt}
                ],
                temperature=1.0,
                max_completion_tokens=16000,
                response_format=FindingExplanationBatch,
            )
            
            result = completion.choices[0].message.parsed
            return result.explanations if result else []
        except Exception:
            return []
    
    def _summarize_findings(self, report: AnalysisReport) -> str:
        lines = []
        
        def count_by_severity(findings):
            counts = {s: 0 for s in Severity}
            for f in findings:
                counts[f.severity] += 1
            return counts
        
        categories = [
            ("Placeholders/Stubs", report.placeholder_findings),
            ("Complexity Issues", report.complexity_findings),
            ("Flow Issues", report.flow_findings),
            ("Naming Issues", report.naming_findings),
            ("Dead Code", report.dead_code_findings),
            ("Security Issues", report.security_findings),
            ("Duplication", report.duplication_findings),
            ("Logging Issues", report.logging_findings),
            ("Metric Issues", report.metric_findings),
        ]
        
        for name, findings in categories:
            if findings:
                counts = count_by_severity(findings)
                severity_str = ", ".join(
                    f"{counts[s]} {s.value}" 
                    for s in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]
                    if counts[s] > 0
                )
                lines.append(f"- {name}: {len(findings)} total ({severity_str})")
        
        if report.recommendations:
            lines.append(f"\nTop Recommendations: {len(report.recommendations)}")
            for rec in report.recommendations[:3]:
                lines.append(f"  - [{rec.severity.value}] {rec.title}")
        
        return "\n".join(lines)
    
    def _extract_key_issues(self, report: AnalysisReport) -> list[str]:
        issues = []
        
        critical_security = [f for f in report.security_findings if f.severity == Severity.CRITICAL]
        if critical_security:
            issues.append(f"{len(critical_security)} critical security vulnerabilities found")
        
        critical_metrics = [f for f in report.metric_findings if f.severity == Severity.CRITICAL]
        if critical_metrics:
            issues.append(f"Training metrics appear stuck - optimization may not be working")
        
        complexity_issues = [f for f in report.complexity_findings if f.severity in [Severity.CRITICAL, Severity.HIGH]]
        if complexity_issues:
            issues.append(f"{len(complexity_issues)} high-complexity functions need refactoring")
        
        stubs = [f for f in report.placeholder_findings if "stub" in f.placeholder_type]
        if len(stubs) > 5:
            issues.append(f"{len(stubs)} unimplemented functions found")
        
        log_spam = [f for f in report.logging_findings if f.logging_type == "spam"]
        if log_spam:
            issues.append("Excessive logging may impact performance")
        
        if not issues:
            issues.append("No major issues detected")
        
        return issues[:5]
    
    def _generate_fallback_narrative(self, report: AnalysisReport) -> str:
        total_findings = (
            len(report.placeholder_findings) +
            len(report.complexity_findings) +
            len(report.flow_findings) +
            len(report.naming_findings) +
            len(report.dead_code_findings) +
            len(report.security_findings) +
            len(report.duplication_findings) +
            len(report.logging_findings) +
            len(report.metric_findings)
        )
        
        if report.health_score >= 90:
            quality = "excellent"
            advice = "Continue following current best practices."
        elif report.health_score >= 80:
            quality = "good"
            advice = "Address the identified issues to improve maintainability."
        elif report.health_score >= 70:
            quality = "fair"
            advice = "Prioritize fixing high-severity issues."
        elif report.health_score >= 60:
            quality = "needs improvement"
            advice = "Focus on critical and high-severity issues immediately."
        else:
            quality = "poor"
            advice = "Significant work needed to bring code to acceptable quality."
        
        return (
            f"The project '{report.project_name}' received a health score of {report.health_score}/100 "
            f"(Grade: {report.health_grade}), indicating {quality} overall code quality. "
            f"The analysis found {total_findings} issues across various categories. {advice}"
        )
    
    def process_report(self, report: AnalysisReport) -> AnalysisReport:
        summary = self.generate_executive_summary(report)
        report.executive_summary = summary.narrative
        
        if summary.health_grade:
            report.health_grade = summary.health_grade
        
        if report.metric_findings:
            analyses = self.analyze_metrics(report.metric_findings)
            for analysis in analyses:
                for finding in report.metric_findings:
                    if finding.metric_name == analysis.metric_name:
                        finding.likely_cause = analysis.likely_cause
                        break
        
        return report


