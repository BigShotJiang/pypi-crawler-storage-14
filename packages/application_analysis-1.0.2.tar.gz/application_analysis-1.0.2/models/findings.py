from datetime import datetime
from enum import Enum
from typing import Optional, Any
from pydantic import BaseModel, Field


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class EffortLevel(str, Enum):
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"


class FindingCategory(str, Enum):
    PLACEHOLDER = "placeholder"
    COMPLEXITY = "complexity"
    FLOW = "flow"
    NAMING = "naming"
    DEAD_CODE = "dead_code"
    SECURITY = "security"
    DUPLICATION = "duplication"
    LOGGING = "logging"
    METRIC = "metric"
    PERFORMANCE = "performance"


class BaseFinding(BaseModel):
    file_path: str
    line_number: int
    end_line: Optional[int] = None
    severity: Severity
    category: FindingCategory
    title: str
    description: str
    code_snippet: Optional[str] = None
    tags: list[str] = Field(default_factory=list)


class PlaceholderFinding(BaseFinding):
    category: FindingCategory = FindingCategory.PLACEHOLDER
    placeholder_type: str  # keyword, stub_function, mock_pattern, ai_artifact
    matched_pattern: str


class ComplexityFinding(BaseFinding):
    category: FindingCategory = FindingCategory.COMPLEXITY
    complexity_type: str  # cyclomatic, nesting, loc, coupling, circular_dependency
    metric_value: float
    threshold: float
    function_name: Optional[str] = None
    class_name: Optional[str] = None


class FlowFinding(BaseFinding):
    category: FindingCategory = FindingCategory.FLOW
    flow_type: str  # long_call_chain, cross_layer_violation, missing_entrypoint
    hop_count: Optional[int] = None
    call_chain: list[str] = Field(default_factory=list)
    source_layer: Optional[str] = None
    target_layer: Optional[str] = None


class NamingFinding(BaseFinding):
    category: FindingCategory = FindingCategory.NAMING
    naming_type: str  # magic_identifier, low_clarity, single_letter, numeric_suffix
    identifier: str
    suggested_name: Optional[str] = None
    entropy_score: Optional[float] = None


class DeadCodeFinding(BaseFinding):
    category: FindingCategory = FindingCategory.DEAD_CODE
    dead_code_type: str  # unused_import, unused_function, unused_class, unreachable, commented_code
    identifier: str
    defined_at: Optional[int] = None
    usage_count: int = 0


class SecurityFinding(BaseFinding):
    category: FindingCategory = FindingCategory.SECURITY
    security_type: str  # eval_exec, shell_injection, hardcoded_secret, sql_injection, pickle_deserialize
    risk_level: str
    pattern_matched: str
    remediation: str


class DuplicationFinding(BaseFinding):
    category: FindingCategory = FindingCategory.DUPLICATION
    duplication_type: str  # exact_duplicate, near_duplicate, copy_paste
    similarity_score: float
    duplicate_locations: list[dict] = Field(default_factory=list)  # [{file, line, end_line}]
    duplicate_count: int


class LoggingFinding(BaseFinding):
    category: FindingCategory = FindingCategory.LOGGING
    logging_type: str  # spam, redundant, dev_leftover, missing_context, useful
    log_level: Optional[str] = None
    message_template: Optional[str] = None
    call_count: int = 1
    has_variables: bool = False
    classification: str  # likely_useful, likely_redundant, spammy, dev_leftover


class MetricFinding(BaseFinding):
    category: FindingCategory = FindingCategory.METRIC
    metric_type: str  # constant, near_constant, never_updated, stuck_in_loop
    metric_name: str
    observed_values: list[float] = Field(default_factory=list)
    value_count: int
    variance: float
    min_value: float
    max_value: float
    sample_count: int
    likely_cause: Optional[str] = None


class Recommendation(BaseModel):
    id: str
    title: str
    category: FindingCategory
    severity: Severity
    effort: EffortLevel
    impact: str
    description: str
    affected_files: list[str] = Field(default_factory=list)
    finding_ids: list[str] = Field(default_factory=list)


class ProjectStatistics(BaseModel):
    total_files: int
    total_lines: int
    total_functions: int
    total_classes: int
    total_imports: int
    avg_cyclomatic_complexity: float
    max_cyclomatic_complexity: float
    avg_nesting_depth: float
    max_nesting_depth: int
    circular_dependency_count: int
    total_log_calls: int
    total_print_calls: int
    files_by_type: dict[str, int] = Field(default_factory=dict)
    severity_counts: dict[str, int] = Field(default_factory=dict)


class ImportInfo(BaseModel):
    module: str
    name: Optional[str] = None
    alias: Optional[str] = None
    line_number: int
    is_from_import: bool
    import_type: str  # stdlib, third_party, local


class FunctionInfo(BaseModel):
    name: str
    file_path: str
    line_number: int
    end_line: int
    parameters: list[str]
    decorators: list[str]
    is_async: bool
    is_method: bool
    class_name: Optional[str] = None
    docstring: Optional[str] = None
    body_lines: int
    complexity: Optional[int] = None
    nesting_depth: int = 0
    calls: list[str] = Field(default_factory=list)
    is_stub: bool = False


class ClassInfo(BaseModel):
    name: str
    file_path: str
    line_number: int
    end_line: int
    bases: list[str]
    decorators: list[str]
    methods: list[str]
    attributes: list[str]
    docstring: Optional[str] = None
    is_stub: bool = False


class LogCallInfo(BaseModel):
    file_path: str
    line_number: int
    function_name: Optional[str] = None
    class_name: Optional[str] = None
    log_type: str  # logging or print
    level: Optional[str] = None
    message_template: str
    has_format_args: bool
    format_arg_count: int
    context_before: list[str] = Field(default_factory=list)
    context_after: list[str] = Field(default_factory=list)


class CommentInfo(BaseModel):
    file_path: str
    line_number: int
    content: str
    comment_type: str  # inline, block, docstring
    function_name: Optional[str] = None
    class_name: Optional[str] = None


class IdentifierInfo(BaseModel):
    name: str
    file_path: str
    line_number: int
    identifier_type: str  # variable, parameter, attribute, function, class, module
    context: str
    tokens: list[str] = Field(default_factory=list)


class FileData(BaseModel):
    path: str
    size_bytes: int
    line_count: int
    blank_lines: int
    comment_lines: int
    code_lines: int
    imports: list[ImportInfo] = Field(default_factory=list)
    functions: list[FunctionInfo] = Field(default_factory=list)
    classes: list[ClassInfo] = Field(default_factory=list)
    log_calls: list[LogCallInfo] = Field(default_factory=list)
    comments: list[CommentInfo] = Field(default_factory=list)
    identifiers: list[IdentifierInfo] = Field(default_factory=list)
    ast_tree: Optional[Any] = None


class StaticCollectorResult(BaseModel):
    project_path: str
    scan_timestamp: datetime
    files: list[FileData] = Field(default_factory=list)
    total_files: int = 0
    total_lines: int = 0
    parse_errors: list[dict] = Field(default_factory=list)


class FunctionTrace(BaseModel):
    module: str
    function_name: str
    call_count: int
    total_time_ms: float
    avg_time_ms: float
    max_time_ms: float
    min_time_ms: float
    exception_count: int
    exception_types: list[str] = Field(default_factory=list)
    memory_delta_bytes: int = 0


class LogRecord(BaseModel):
    timestamp: datetime
    level: str
    module: str
    function_name: Optional[str]
    line_number: int
    message: str
    message_template: str
    args: list[Any] = Field(default_factory=list)


class MetricSample(BaseModel):
    timestamp: datetime
    metric_name: str
    value: float
    module: str
    function_name: Optional[str] = None
    iteration: Optional[int] = None


class DynamicCollectorResult(BaseModel):
    project_path: str
    trace_start: datetime
    trace_end: datetime
    duration_seconds: float
    function_traces: list[FunctionTrace] = Field(default_factory=list)
    log_records: list[LogRecord] = Field(default_factory=list)
    metric_samples: list[MetricSample] = Field(default_factory=list)
    total_function_calls: int = 0
    total_log_records: int = 0
    total_exceptions: int = 0
    peak_memory_bytes: int = 0


class AnalysisReport(BaseModel):
    project_name: str
    project_path: str
    scan_date: datetime
    health_score: int  # 0-100
    health_grade: str  # A-F
    executive_summary: str
    
    placeholder_findings: list[PlaceholderFinding] = Field(default_factory=list)
    complexity_findings: list[ComplexityFinding] = Field(default_factory=list)
    flow_findings: list[FlowFinding] = Field(default_factory=list)
    naming_findings: list[NamingFinding] = Field(default_factory=list)
    dead_code_findings: list[DeadCodeFinding] = Field(default_factory=list)
    security_findings: list[SecurityFinding] = Field(default_factory=list)
    duplication_findings: list[DuplicationFinding] = Field(default_factory=list)
    logging_findings: list[LoggingFinding] = Field(default_factory=list)
    metric_findings: list[MetricFinding] = Field(default_factory=list)
    
    recommendations: list[Recommendation] = Field(default_factory=list)
    statistics: Optional[ProjectStatistics] = None
    
    static_data: Optional[StaticCollectorResult] = None
    dynamic_data: Optional[DynamicCollectorResult] = None


