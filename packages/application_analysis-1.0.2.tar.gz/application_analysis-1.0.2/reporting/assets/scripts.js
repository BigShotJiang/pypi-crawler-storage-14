// Application Analysis Report - Interactive Scripts

document.addEventListener('DOMContentLoaded', function() {
    initViewToggle();
    initSectionToggle();
    initTableSort();
    initFilters();
});

// View Toggle (Simple/Detailed)
function initViewToggle() {
    const toggleBtns = document.querySelectorAll('.view-toggle button');
    const body = document.body;
    
    toggleBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            toggleBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            if (this.dataset.view === 'simple') {
                body.classList.add('simple-view');
            } else {
                body.classList.remove('simple-view');
            }
        });
    });
}

// Section Collapse/Expand
function initSectionToggle() {
    const sectionHeaders = document.querySelectorAll('.section-header');
    
    sectionHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const content = this.nextElementSibling;
            const toggle = this.querySelector('.section-toggle');
            
            if (content.classList.contains('collapsed')) {
                content.classList.remove('collapsed');
                toggle.textContent = 'Collapse';
            } else {
                content.classList.add('collapsed');
                toggle.textContent = 'Expand';
            }
        });
    });
}

// Table Sorting
function initTableSort() {
    const tables = document.querySelectorAll('.findings-table');
    
    tables.forEach(table => {
        const headers = table.querySelectorAll('th[data-sortable]');
        
        headers.forEach((header, index) => {
            header.style.cursor = 'pointer';
            header.addEventListener('click', function() {
                sortTable(table, index);
            });
        });
    });
}

function sortTable(table, columnIndex) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const header = table.querySelectorAll('th')[columnIndex];
    const isAscending = header.dataset.sortDirection !== 'asc';
    
    // Reset other headers
    table.querySelectorAll('th').forEach(th => {
        th.dataset.sortDirection = '';
    });
    header.dataset.sortDirection = isAscending ? 'asc' : 'desc';
    
    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.trim();
        const bValue = b.cells[columnIndex].textContent.trim();
        
        // Check if numeric
        const aNum = parseFloat(aValue);
        const bNum = parseFloat(bValue);
        
        if (!isNaN(aNum) && !isNaN(bNum)) {
            return isAscending ? aNum - bNum : bNum - aNum;
        }
        
        return isAscending 
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
    });
    
    rows.forEach(row => tbody.appendChild(row));
}

// Filters
function initFilters() {
    const filterSelects = document.querySelectorAll('.filter-controls select');
    
    filterSelects.forEach(select => {
        select.addEventListener('change', function() {
            applyFilters();
        });
    });
}

function applyFilters() {
    const severityFilter = document.querySelector('#severity-filter');
    const categoryFilter = document.querySelector('#category-filter');
    
    if (!severityFilter && !categoryFilter) return;
    
    const severity = severityFilter ? severityFilter.value : 'all';
    const category = categoryFilter ? categoryFilter.value : 'all';
    
    const rows = document.querySelectorAll('.findings-table tbody tr');
    
    rows.forEach(row => {
        const rowSeverity = row.dataset.severity || '';
        const rowCategory = row.dataset.category || '';
        
        const severityMatch = severity === 'all' || rowSeverity === severity;
        const categoryMatch = category === 'all' || rowCategory === category;
        
        row.style.display = (severityMatch && categoryMatch) ? '' : 'none';
    });
}

// Smooth scroll to section
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
        
        // Expand section if collapsed
        const content = section.querySelector('.section-content');
        if (content && content.classList.contains('collapsed')) {
            content.classList.remove('collapsed');
            const toggle = section.querySelector('.section-toggle');
            if (toggle) toggle.textContent = 'Collapse';
        }
    }
}

// Copy code snippet to clipboard
function copyCode(button) {
    const codeBlock = button.parentElement.querySelector('code');
    if (codeBlock) {
        navigator.clipboard.writeText(codeBlock.textContent).then(() => {
            const originalText = button.textContent;
            button.textContent = 'Copied!';
            setTimeout(() => {
                button.textContent = originalText;
            }, 2000);
        });
    }
}

// Generate sparkline SVG
function generateSparkline(containerId, data) {
    const container = document.getElementById(containerId);
    if (!container || !data || data.length < 2) return;
    
    const width = 100;
    const height = 30;
    const padding = 2;
    
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    
    const points = data.map((value, index) => {
        const x = padding + (index / (data.length - 1)) * (width - 2 * padding);
        const y = height - padding - ((value - min) / range) * (height - 2 * padding);
        return `${x},${y}`;
    }).join(' ');
    
    const svg = `
        <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none">
            <polyline points="${points}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    `;
    
    container.innerHTML = svg;
}

// Expand all sections
function expandAll() {
    document.querySelectorAll('.section-content.collapsed').forEach(content => {
        content.classList.remove('collapsed');
    });
    document.querySelectorAll('.section-toggle').forEach(toggle => {
        toggle.textContent = 'Collapse';
    });
}

// Collapse all sections
function collapseAll() {
    document.querySelectorAll('.section-content').forEach(content => {
        content.classList.add('collapsed');
    });
    document.querySelectorAll('.section-toggle').forEach(toggle => {
        toggle.textContent = 'Expand';
    });
}

// Print report
function printReport() {
    expandAll();
    window.print();
}

// Export as JSON
function exportJSON() {
    const reportData = document.getElementById('report-data');
    if (reportData) {
        const data = JSON.parse(reportData.textContent);
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'analysis-report.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
}


