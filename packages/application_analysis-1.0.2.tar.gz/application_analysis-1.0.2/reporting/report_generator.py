import json
from pathlib import Path
from datetime import datetime
from typing import Optional

from jinja2 import Environment, FileSystemLoader

from models.findings import (
    AnalysisReport,
    ProjectStatistics,
    StaticCollectorResult,
    DynamicCollectorResult,
    Severity,
)


class ReportGenerator:
    def __init__(self, template_dir: Optional[Path] = None, assets_dir: Optional[Path] = None):
        if template_dir is None:
            template_dir = Path(__file__).parent / "templates"
        if assets_dir is None:
            assets_dir = Path(__file__).parent / "assets"
        
        self.template_dir = template_dir
        self.assets_dir = assets_dir
        self.env = Environment(loader=FileSystemLoader(str(template_dir)))
    
    def _load_asset(self, filename: str) -> str:
        asset_path = self.assets_dir / filename
        if asset_path.exists():
            with open(asset_path, 'r', encoding='utf-8') as f:
                return f.read()
        return ""
    
    def _calculate_statistics(self, static_result: Optional[StaticCollectorResult]) -> ProjectStatistics:
        if not static_result:
            return ProjectStatistics(
                total_files=0,
                total_lines=0,
                total_functions=0,
                total_classes=0,
                total_imports=0,
                avg_cyclomatic_complexity=0.0,
                max_cyclomatic_complexity=0.0,
                avg_nesting_depth=0.0,
                max_nesting_depth=0,
                circular_dependency_count=0,
                total_log_calls=0,
                total_print_calls=0
            )
        
        from radon.complexity import cc_visit
        
        total_functions = 0
        total_classes = 0
        total_imports = 0
        total_log_calls = 0
        total_print_calls = 0
        all_complexities = []
        all_nesting_depths = []
        files_by_type: dict[str, int] = {}
        
        for file_data in static_result.files:
            total_functions += len(file_data.functions)
            total_classes += len(file_data.classes)
            total_imports += len(file_data.imports)
            
            for log_call in file_data.log_calls:
                if log_call.log_type == 'logging':
                    total_log_calls += 1
                else:
                    total_print_calls += 1
            
            for func in file_data.functions:
                all_nesting_depths.append(func.nesting_depth)
            
            try:
                full_path = Path(static_result.project_path) / file_data.path
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    source = f.read()
                blocks = cc_visit(source)
                for block in blocks:
                    all_complexities.append(block.complexity)
            except Exception:
                pass
            
            ext = Path(file_data.path).suffix or '.py'
            files_by_type[ext] = files_by_type.get(ext, 0) + 1
        
        avg_complexity = sum(all_complexities) / len(all_complexities) if all_complexities else 0.0
        max_complexity = max(all_complexities) if all_complexities else 0.0
        avg_nesting = sum(all_nesting_depths) / len(all_nesting_depths) if all_nesting_depths else 0.0
        max_nesting = max(all_nesting_depths) if all_nesting_depths else 0
        
        return ProjectStatistics(
            total_files=static_result.total_files,
            total_lines=static_result.total_lines,
            total_functions=total_functions,
            total_classes=total_classes,
            total_imports=total_imports,
            avg_cyclomatic_complexity=round(avg_complexity, 1),
            max_cyclomatic_complexity=round(max_complexity, 1),
            avg_nesting_depth=round(avg_nesting, 1),
            max_nesting_depth=max_nesting,
            circular_dependency_count=0,
            total_log_calls=total_log_calls,
            total_print_calls=total_print_calls,
            files_by_type=files_by_type
        )
    
    def _count_severity(self, findings: list, severity: Severity) -> int:
        return len([f for f in findings if f.severity == severity])
    
    def _prepare_report_json(self, report: AnalysisReport) -> str:
        report_dict = {
            'project_name': report.project_name,
            'project_path': report.project_path,
            'scan_date': report.scan_date.isoformat(),
            'health_score': report.health_score,
            'health_grade': report.health_grade,
            'executive_summary': report.executive_summary,
            'findings_summary': {
                'placeholder': len(report.placeholder_findings),
                'complexity': len(report.complexity_findings),
                'flow': len(report.flow_findings),
                'naming': len(report.naming_findings),
                'dead_code': len(report.dead_code_findings),
                'security': len(report.security_findings),
                'duplication': len(report.duplication_findings),
                'logging': len(report.logging_findings),
                'metric': len(report.metric_findings),
            },
            'severity_counts': {
                'critical': sum(
                    self._count_severity(findings, Severity.CRITICAL)
                    for findings in [
                        report.placeholder_findings, report.complexity_findings,
                        report.flow_findings, report.naming_findings,
                        report.dead_code_findings, report.security_findings,
                        report.duplication_findings, report.logging_findings,
                        report.metric_findings
                    ]
                ),
                'high': sum(
                    self._count_severity(findings, Severity.HIGH)
                    for findings in [
                        report.placeholder_findings, report.complexity_findings,
                        report.flow_findings, report.naming_findings,
                        report.dead_code_findings, report.security_findings,
                        report.duplication_findings, report.logging_findings,
                        report.metric_findings
                    ]
                ),
                'medium': sum(
                    self._count_severity(findings, Severity.MEDIUM)
                    for findings in [
                        report.placeholder_findings, report.complexity_findings,
                        report.flow_findings, report.naming_findings,
                        report.dead_code_findings, report.security_findings,
                        report.duplication_findings, report.logging_findings,
                        report.metric_findings
                    ]
                ),
                'low': sum(
                    self._count_severity(findings, Severity.LOW)
                    for findings in [
                        report.placeholder_findings, report.complexity_findings,
                        report.flow_findings, report.naming_findings,
                        report.dead_code_findings, report.security_findings,
                        report.duplication_findings, report.logging_findings,
                        report.metric_findings
                    ]
                ),
            },
            'recommendations_count': len(report.recommendations),
        }
        
        if report.statistics:
            report_dict['statistics'] = {
                'total_files': report.statistics.total_files,
                'total_lines': report.statistics.total_lines,
                'total_functions': report.statistics.total_functions,
                'total_classes': report.statistics.total_classes,
                'avg_complexity': report.statistics.avg_cyclomatic_complexity,
            }
        
        return json.dumps(report_dict)
    
    def generate_html(self, report: AnalysisReport, output_path: Optional[Path] = None) -> str:
        template = self.env.get_template("report_template.html")
        
        css_content = self._load_asset("styles.css")
        js_content = self._load_asset("scripts.js")
        
        report_json = self._prepare_report_json(report)
        
        html_content = template.render(
            report=report,
            css_content=css_content,
            js_content=js_content,
            report_json=report_json
        )
        
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
        
        return html_content
    
    def generate_json(self, report: AnalysisReport, output_path: Optional[Path] = None) -> str:
        report_dict = report.model_dump(mode='json')
        
        json_content = json.dumps(report_dict, indent=2, default=str)
        
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(json_content)
        
        return json_content
    
    def create_report(
        self,
        project_name: str,
        project_path: str,
        static_result: Optional[StaticCollectorResult] = None,
        dynamic_result: Optional[DynamicCollectorResult] = None,
        placeholder_findings: list = None,
        complexity_findings: list = None,
        flow_findings: list = None,
        naming_findings: list = None,
        dead_code_findings: list = None,
        security_findings: list = None,
        duplication_findings: list = None,
        logging_findings: list = None,
        metric_findings: list = None,
        recommendations: list = None,
        health_score: int = 100,
        health_grade: str = 'A',
        executive_summary: str = ""
    ) -> AnalysisReport:
        statistics = self._calculate_statistics(static_result)
        
        if static_result:
            severity_counts = {}
            all_findings = (
                (placeholder_findings or []) +
                (complexity_findings or []) +
                (flow_findings or []) +
                (naming_findings or []) +
                (dead_code_findings or []) +
                (security_findings or []) +
                (duplication_findings or []) +
                (logging_findings or []) +
                (metric_findings or [])
            )
            for severity in Severity:
                severity_counts[severity.value] = self._count_severity(all_findings, severity)
            statistics.severity_counts = severity_counts
        
        return AnalysisReport(
            project_name=project_name,
            project_path=project_path,
            scan_date=datetime.now(),
            health_score=health_score,
            health_grade=health_grade,
            executive_summary=executive_summary or f"Analysis of {project_name} completed.",
            placeholder_findings=placeholder_findings or [],
            complexity_findings=complexity_findings or [],
            flow_findings=flow_findings or [],
            naming_findings=naming_findings or [],
            dead_code_findings=dead_code_findings or [],
            security_findings=security_findings or [],
            duplication_findings=duplication_findings or [],
            logging_findings=logging_findings or [],
            metric_findings=metric_findings or [],
            recommendations=recommendations or [],
            statistics=statistics,
            static_data=static_result,
            dynamic_data=dynamic_result
        )


