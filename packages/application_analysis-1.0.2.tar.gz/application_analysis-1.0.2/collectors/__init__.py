from collectors.static_collector import StaticCollector
from collectors.dynamic_collector import DynamicCollector

__all__ = ["StaticCollector", "DynamicCollector"]


