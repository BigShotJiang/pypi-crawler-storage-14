import ast
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

from models.findings import (
    StaticCollectorResult,
    FileData,
    ImportInfo,
    FunctionInfo,
    ClassInfo,
    LogCallInfo,
    CommentInfo,
    IdentifierInfo,
)


STDLIB_MODULES = set(sys.stdlib_module_names) if hasattr(sys, 'stdlib_module_names') else {
    'abc', 'aifc', 'argparse', 'array', 'ast', 'asynchat', 'asyncio', 'asyncore',
    'atexit', 'audioop', 'base64', 'bdb', 'binascii', 'binhex', 'bisect', 'builtins',
    'bz2', 'calendar', 'cgi', 'cgitb', 'chunk', 'cmath', 'cmd', 'code', 'codecs',
    'codeop', 'collections', 'colorsys', 'compileall', 'concurrent', 'configparser',
    'contextlib', 'contextvars', 'copy', 'copyreg', 'cProfile', 'crypt', 'csv',
    'ctypes', 'curses', 'dataclasses', 'datetime', 'dbm', 'decimal', 'difflib',
    'dis', 'distutils', 'doctest', 'email', 'encodings', 'enum', 'errno', 'faulthandler',
    'fcntl', 'filecmp', 'fileinput', 'fnmatch', 'fractions', 'ftplib', 'functools',
    'gc', 'getopt', 'getpass', 'gettext', 'glob', 'graphlib', 'grp', 'gzip', 'hashlib',
    'heapq', 'hmac', 'html', 'http', 'idlelib', 'imaplib', 'imghdr', 'imp', 'importlib',
    'inspect', 'io', 'ipaddress', 'itertools', 'json', 'keyword', 'lib2to3', 'linecache',
    'locale', 'logging', 'lzma', 'mailbox', 'mailcap', 'marshal', 'math', 'mimetypes',
    'mmap', 'modulefinder', 'multiprocessing', 'netrc', 'nis', 'nntplib', 'numbers',
    'operator', 'optparse', 'os', 'ossaudiodev', 'pathlib', 'pdb', 'pickle', 'pickletools',
    'pipes', 'pkgutil', 'platform', 'plistlib', 'poplib', 'posix', 'posixpath', 'pprint',
    'profile', 'pstats', 'pty', 'pwd', 'py_compile', 'pyclbr', 'pydoc', 'queue', 'quopri',
    'random', 're', 'readline', 'reprlib', 'resource', 'rlcompleter', 'runpy', 'sched',
    'secrets', 'select', 'selectors', 'shelve', 'shlex', 'shutil', 'signal', 'site',
    'smtpd', 'smtplib', 'sndhdr', 'socket', 'socketserver', 'spwd', 'sqlite3', 'ssl',
    'stat', 'statistics', 'string', 'stringprep', 'struct', 'subprocess', 'sunau',
    'symtable', 'sys', 'sysconfig', 'syslog', 'tabnanny', 'tarfile', 'telnetlib',
    'tempfile', 'termios', 'test', 'textwrap', 'threading', 'time', 'timeit', 'tkinter',
    'token', 'tokenize', 'trace', 'traceback', 'tracemalloc', 'tty', 'turtle', 'turtledemo',
    'types', 'typing', 'unicodedata', 'unittest', 'urllib', 'uu', 'uuid', 'venv', 'warnings',
    'wave', 'weakref', 'webbrowser', 'winreg', 'winsound', 'wsgiref', 'xdrlib', 'xml',
    'xmlrpc', 'zipapp', 'zipfile', 'zipimport', 'zlib', 'zoneinfo',
}


class ASTVisitor(ast.NodeVisitor):
    def __init__(self, file_path: str, source_lines: list[str], project_modules: set[str]):
        self.file_path = file_path
        self.source_lines = source_lines
        self.project_modules = project_modules
        self.imports: list[ImportInfo] = []
        self.functions: list[FunctionInfo] = []
        self.classes: list[ClassInfo] = []
        self.log_calls: list[LogCallInfo] = []
        self.identifiers: list[IdentifierInfo] = []
        self.current_class: Optional[str] = None
        self.current_function: Optional[str] = None
        self._function_stack: list[str] = []
        self._class_stack: list[str] = []
    
    def _get_import_type(self, module_name: str) -> str:
        base_module = module_name.split('.')[0]
        if base_module in STDLIB_MODULES:
            return "stdlib"
        if base_module in self.project_modules:
            return "local"
        return "third_party"
    
    def _get_context_lines(self, line_number: int, before: int = 3, after: int = 3) -> tuple[list[str], list[str]]:
        start = max(0, line_number - 1 - before)
        end = min(len(self.source_lines), line_number + after)
        context_before = self.source_lines[start:line_number - 1]
        context_after = self.source_lines[line_number:end]
        return context_before, context_after
    
    def _extract_decorators(self, node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef) -> list[str]:
        decorators = []
        for dec in node.decorator_list:
            if isinstance(dec, ast.Name):
                decorators.append(dec.id)
            elif isinstance(dec, ast.Attribute):
                decorators.append(ast.unparse(dec))
            elif isinstance(dec, ast.Call):
                if isinstance(dec.func, ast.Name):
                    decorators.append(dec.func.id)
                elif isinstance(dec.func, ast.Attribute):
                    decorators.append(ast.unparse(dec.func))
        return decorators
    
    def _extract_calls(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
        calls = []
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                if isinstance(child.func, ast.Name):
                    calls.append(child.func.id)
                elif isinstance(child.func, ast.Attribute):
                    calls.append(ast.unparse(child.func))
        return calls
    
    def _calculate_nesting_depth(self, node: ast.AST) -> int:
        max_depth = 0
        def walk_depth(n: ast.AST, depth: int):
            nonlocal max_depth
            if isinstance(n, (ast.If, ast.For, ast.While, ast.With, ast.Try, ast.AsyncFor, ast.AsyncWith)):
                depth += 1
                max_depth = max(max_depth, depth)
            for child in ast.iter_child_nodes(n):
                walk_depth(child, depth)
        walk_depth(node, 0)
        return max_depth
    
    def _is_stub_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        body = node.body
        if len(body) == 0:
            return True
        if len(body) == 1:
            stmt = body[0]
            if isinstance(stmt, ast.Pass):
                return True
            if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant):
                return True
            if isinstance(stmt, ast.Raise):
                if isinstance(stmt.exc, ast.Call):
                    if isinstance(stmt.exc.func, ast.Name):
                        if stmt.exc.func.id == "NotImplementedError":
                            return True
                return False
            if isinstance(stmt, ast.Return) and stmt.value is None:
                return True
        if len(body) == 2:
            if isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant):
                if isinstance(body[1], ast.Pass):
                    return True
                if isinstance(body[1], ast.Return) and body[1].value is None:
                    return True
                if isinstance(body[1], ast.Raise):
                    return True
        return False
    
    def _is_stub_class(self, node: ast.ClassDef) -> bool:
        body = node.body
        if len(body) == 0:
            return True
        if len(body) == 1:
            stmt = body[0]
            if isinstance(stmt, ast.Pass):
                return True
            if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant):
                return True
        return False
    
    def _get_docstring(self, node: ast.AST) -> Optional[str]:
        return ast.get_docstring(node)
    
    def _split_identifier(self, name: str) -> list[str]:
        tokens = re.sub(r'([a-z])([A-Z])', r'\1_\2', name).lower().split('_')
        return [t for t in tokens if t]
    
    def visit_Import(self, node: ast.Import):
        for alias in node.names:
            self.imports.append(ImportInfo(
                module=alias.name,
                name=None,
                alias=alias.asname,
                line_number=node.lineno,
                is_from_import=False,
                import_type=self._get_import_type(alias.name)
            ))
        self.generic_visit(node)
    
    def visit_ImportFrom(self, node: ast.ImportFrom):
        module = node.module or ""
        for alias in node.names:
            self.imports.append(ImportInfo(
                module=module,
                name=alias.name,
                alias=alias.asname,
                line_number=node.lineno,
                is_from_import=True,
                import_type=self._get_import_type(module) if module else "local"
            ))
        self.generic_visit(node)
    
    def visit_FunctionDef(self, node: ast.FunctionDef):
        self._visit_function(node, is_async=False)
    
    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        self._visit_function(node, is_async=True)
    
    def _visit_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef, is_async: bool):
        params = []
        for arg in node.args.args:
            params.append(arg.arg)
        for arg in node.args.posonlyargs:
            params.append(arg.arg)
        for arg in node.args.kwonlyargs:
            params.append(arg.arg)
        if node.args.vararg:
            params.append(f"*{node.args.vararg.arg}")
        if node.args.kwarg:
            params.append(f"**{node.args.kwarg.arg}")
        
        func_info = FunctionInfo(
            name=node.name,
            file_path=self.file_path,
            line_number=node.lineno,
            end_line=node.end_lineno or node.lineno,
            parameters=params,
            decorators=self._extract_decorators(node),
            is_async=is_async,
            is_method=bool(self._class_stack),
            class_name=self._class_stack[-1] if self._class_stack else None,
            docstring=self._get_docstring(node),
            body_lines=(node.end_lineno or node.lineno) - node.lineno + 1,
            nesting_depth=self._calculate_nesting_depth(node),
            calls=self._extract_calls(node),
            is_stub=self._is_stub_function(node)
        )
        self.functions.append(func_info)
        
        self.identifiers.append(IdentifierInfo(
            name=node.name,
            file_path=self.file_path,
            line_number=node.lineno,
            identifier_type="function",
            context=f"class {self._class_stack[-1]}" if self._class_stack else "module",
            tokens=self._split_identifier(node.name)
        ))
        
        for param in params:
            clean_param = param.lstrip('*')
            if clean_param:
                self.identifiers.append(IdentifierInfo(
                    name=clean_param,
                    file_path=self.file_path,
                    line_number=node.lineno,
                    identifier_type="parameter",
                    context=f"function {node.name}",
                    tokens=self._split_identifier(clean_param)
                ))
        
        self._function_stack.append(node.name)
        self.generic_visit(node)
        self._function_stack.pop()
    
    def visit_ClassDef(self, node: ast.ClassDef):
        bases = []
        for base in node.bases:
            if isinstance(base, ast.Name):
                bases.append(base.id)
            elif isinstance(base, ast.Attribute):
                bases.append(ast.unparse(base))
        
        methods = []
        attributes = []
        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                methods.append(item.name)
            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        attributes.append(target.id)
            elif isinstance(item, ast.AnnAssign):
                if isinstance(item.target, ast.Name):
                    attributes.append(item.target.id)
        
        class_info = ClassInfo(
            name=node.name,
            file_path=self.file_path,
            line_number=node.lineno,
            end_line=node.end_lineno or node.lineno,
            bases=bases,
            decorators=self._extract_decorators(node),
            methods=methods,
            attributes=attributes,
            docstring=self._get_docstring(node),
            is_stub=self._is_stub_class(node)
        )
        self.classes.append(class_info)
        
        self.identifiers.append(IdentifierInfo(
            name=node.name,
            file_path=self.file_path,
            line_number=node.lineno,
            identifier_type="class",
            context="module",
            tokens=self._split_identifier(node.name)
        ))
        
        self._class_stack.append(node.name)
        self.generic_visit(node)
        self._class_stack.pop()
    
    def visit_Call(self, node: ast.Call):
        call_name = ""
        if isinstance(node.func, ast.Attribute):
            call_name = ast.unparse(node.func)
        elif isinstance(node.func, ast.Name):
            call_name = node.func.id
        
        log_levels = {'debug', 'info', 'warning', 'error', 'critical', 'exception', 'log'}
        is_logging_call = False
        log_level = None
        
        if isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name):
                if node.func.value.id == 'logging' and node.func.attr in log_levels:
                    is_logging_call = True
                    log_level = node.func.attr
                elif node.func.value.id == 'logger' and node.func.attr in log_levels:
                    is_logging_call = True
                    log_level = node.func.attr
            if isinstance(node.func.value, ast.Attribute):
                full_name = ast.unparse(node.func.value)
                if 'logger' in full_name.lower() and node.func.attr in log_levels:
                    is_logging_call = True
                    log_level = node.func.attr
        
        is_print_call = call_name == 'print'
        
        if is_logging_call or is_print_call:
            message_template = ""
            has_format_args = False
            format_arg_count = 0
            
            if node.args:
                first_arg = node.args[0]
                if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
                    message_template = first_arg.value
                elif isinstance(first_arg, ast.JoinedStr):
                    message_template = ast.unparse(first_arg)
                    has_format_args = True
                else:
                    message_template = ast.unparse(first_arg)
                    has_format_args = True
                
                format_arg_count = len(node.args) - 1
                if format_arg_count > 0:
                    has_format_args = True
            
            context_before, context_after = self._get_context_lines(node.lineno)
            
            self.log_calls.append(LogCallInfo(
                file_path=self.file_path,
                line_number=node.lineno,
                function_name=self._function_stack[-1] if self._function_stack else None,
                class_name=self._class_stack[-1] if self._class_stack else None,
                log_type="logging" if is_logging_call else "print",
                level=log_level,
                message_template=message_template,
                has_format_args=has_format_args,
                format_arg_count=format_arg_count,
                context_before=context_before,
                context_after=context_after
            ))
        
        self.generic_visit(node)
    
    def visit_Assign(self, node: ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.identifiers.append(IdentifierInfo(
                    name=target.id,
                    file_path=self.file_path,
                    line_number=node.lineno,
                    identifier_type="variable",
                    context=f"function {self._function_stack[-1]}" if self._function_stack else "module",
                    tokens=self._split_identifier(target.id)
                ))
        self.generic_visit(node)
    
    def visit_AnnAssign(self, node: ast.AnnAssign):
        if isinstance(node.target, ast.Name):
            self.identifiers.append(IdentifierInfo(
                name=node.target.id,
                file_path=self.file_path,
                line_number=node.lineno,
                identifier_type="variable",
                context=f"function {self._function_stack[-1]}" if self._function_stack else "module",
                tokens=self._split_identifier(node.target.id)
            ))
        self.generic_visit(node)


class StaticCollector:
    def __init__(self, project_path: str):
        self.project_path = Path(project_path).resolve()
        self.project_modules: set[str] = set()
        self._discover_project_modules()
    
    def _discover_project_modules(self):
        for py_file in self.project_path.rglob("*.py"):
            rel_path = py_file.relative_to(self.project_path)
            module_parts = list(rel_path.with_suffix("").parts)
            if module_parts:
                self.project_modules.add(module_parts[0])
                for i in range(len(module_parts)):
                    self.project_modules.add(".".join(module_parts[:i+1]))
    
    def _count_lines(self, source: str) -> tuple[int, int, int, int]:
        lines = source.split('\n')
        total = len(lines)
        blank = 0
        comment = 0
        in_multiline = False
        
        for line in lines:
            stripped = line.strip()
            if not stripped:
                blank += 1
                continue
            
            if in_multiline:
                comment += 1
                if '"""' in stripped or "'''" in stripped:
                    in_multiline = False
                continue
            
            if stripped.startswith('#'):
                comment += 1
            elif stripped.startswith('"""') or stripped.startswith("'''"):
                comment += 1
                quote = '"""' if stripped.startswith('"""') else "'''"
                if stripped.count(quote) == 1:
                    in_multiline = True
        
        code = total - blank - comment
        return total, blank, comment, code
    
    def _extract_comments(self, source: str, file_path: str) -> list[CommentInfo]:
        comments = []
        lines = source.split('\n')
        in_multiline = False
        multiline_start = 0
        multiline_content = []
        
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            
            if in_multiline:
                multiline_content.append(line)
                if '"""' in stripped or "'''" in stripped:
                    in_multiline = False
                    comments.append(CommentInfo(
                        file_path=file_path,
                        line_number=multiline_start,
                        content='\n'.join(multiline_content),
                        comment_type="block"
                    ))
                    multiline_content = []
                continue
            
            if '#' in line:
                comment_start = line.index('#')
                if not any(line[:comment_start].count(q) % 2 for q in ['"', "'"]):
                    comment_text = line[comment_start:].strip()
                    comments.append(CommentInfo(
                        file_path=file_path,
                        line_number=i,
                        content=comment_text,
                        comment_type="inline"
                    ))
            
            if stripped.startswith('"""') or stripped.startswith("'''"):
                quote = '"""' if stripped.startswith('"""') else "'''"
                if stripped.count(quote) == 1:
                    in_multiline = True
                    multiline_start = i
                    multiline_content = [line]
                else:
                    comments.append(CommentInfo(
                        file_path=file_path,
                        line_number=i,
                        content=stripped,
                        comment_type="block"
                    ))
        
        return comments
    
    def collect_file(self, file_path: Path) -> Optional[FileData]:
        try:
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                source = f.read()
        except Exception:
            return None
        
        rel_path = str(file_path.relative_to(self.project_path))
        source_lines = source.split('\n')
        total_lines, blank_lines, comment_lines, code_lines = self._count_lines(source)
        
        try:
            tree = ast.parse(source, filename=rel_path)
        except SyntaxError:
            return FileData(
                path=rel_path,
                size_bytes=len(source.encode('utf-8')),
                line_count=total_lines,
                blank_lines=blank_lines,
                comment_lines=comment_lines,
                code_lines=code_lines,
                imports=[],
                functions=[],
                classes=[],
                log_calls=[],
                comments=self._extract_comments(source, rel_path),
                identifiers=[]
            )
        
        visitor = ASTVisitor(rel_path, source_lines, self.project_modules)
        visitor.visit(tree)
        
        comments = self._extract_comments(source, rel_path)
        
        for node in ast.walk(tree):
            docstring = None
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)):
                docstring = ast.get_docstring(node)
            if docstring:
                line_num = node.lineno if hasattr(node, 'lineno') else 1
                comments.append(CommentInfo(
                    file_path=rel_path,
                    line_number=line_num,
                    content=docstring,
                    comment_type="docstring",
                    function_name=node.name if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) else None,
                    class_name=node.name if isinstance(node, ast.ClassDef) else None
                ))
        
        return FileData(
            path=rel_path,
            size_bytes=len(source.encode('utf-8')),
            line_count=total_lines,
            blank_lines=blank_lines,
            comment_lines=comment_lines,
            code_lines=code_lines,
            imports=visitor.imports,
            functions=visitor.functions,
            classes=visitor.classes,
            log_calls=visitor.log_calls,
            comments=comments,
            identifiers=visitor.identifiers
        )
    
    def collect(self) -> StaticCollectorResult:
        files: list[FileData] = []
        parse_errors: list[dict] = []
        total_lines = 0
        
        ignore_patterns = {
            '__pycache__', '.git', '.venv', 'venv', 'env', '.env',
            'node_modules', '.tox', '.pytest_cache', '.mypy_cache',
            'dist', 'build', '*.egg-info'
        }
        
        for py_file in self.project_path.rglob("*.py"):
            skip = False
            for part in py_file.parts:
                if part in ignore_patterns or part.endswith('.egg-info'):
                    skip = True
                    break
            if skip:
                continue
            
            file_data = self.collect_file(py_file)
            if file_data:
                files.append(file_data)
                total_lines += file_data.line_count
            else:
                parse_errors.append({
                    "file": str(py_file.relative_to(self.project_path)),
                    "error": "Failed to read or parse file"
                })
        
        return StaticCollectorResult(
            project_path=str(self.project_path),
            scan_timestamp=datetime.now(),
            files=files,
            total_files=len(files),
            total_lines=total_lines,
            parse_errors=parse_errors
        )


