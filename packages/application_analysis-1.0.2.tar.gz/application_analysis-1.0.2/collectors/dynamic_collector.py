import sys
import time
import logging
import tracemalloc
import threading
from datetime import datetime
from typing import Optional, Any, Callable
from contextlib import contextmanager

from models.findings import (
    DynamicCollectorResult,
    FunctionTrace,
    LogRecord,
    MetricSample,
)


METRIC_PATTERNS = {
    'fitness', 'loss', 'accuracy', 'score', 'reward', 'epoch', 'step',
    'iteration', 'error', 'cost', 'metric', 'progress', 'counter',
    'train_loss', 'val_loss', 'test_loss', 'train_acc', 'val_acc', 'test_acc',
    'lr', 'learning_rate', 'gradient', 'weight', 'bias'
}


class MetricTracker:
    def __init__(self):
        self.samples: list[MetricSample] = []
        self._lock = threading.Lock()
    
    def track(self, metric_name: str, value: float, module: str, function_name: Optional[str] = None, iteration: Optional[int] = None):
        with self._lock:
            self.samples.append(MetricSample(
                timestamp=datetime.now(),
                metric_name=metric_name,
                value=value,
                module=module,
                function_name=function_name,
                iteration=iteration
            ))
    
    def get_samples(self) -> list[MetricSample]:
        with self._lock:
            return list(self.samples)
    
    def clear(self):
        with self._lock:
            self.samples.clear()


class LogInterceptHandler(logging.Handler):
    def __init__(self, collector: 'DynamicCollector'):
        super().__init__()
        self.collector = collector
        self._lock = threading.Lock()
    
    def emit(self, record: logging.LogRecord):
        with self._lock:
            try:
                msg = self.format(record)
                template = record.getMessage() if hasattr(record, 'msg') else msg
                
                self.collector.log_records.append(LogRecord(
                    timestamp=datetime.fromtimestamp(record.created),
                    level=record.levelname,
                    module=record.module,
                    function_name=record.funcName,
                    line_number=record.lineno,
                    message=msg,
                    message_template=str(record.msg) if record.msg else "",
                    args=list(record.args) if record.args else []
                ))
            except Exception:
                pass


class FunctionTracer:
    def __init__(self, collector: 'DynamicCollector'):
        self.collector = collector
        self._call_stack: list[tuple[str, str, float]] = []
        self._traces: dict[str, dict] = {}
        self._lock = threading.Lock()
    
    def _get_key(self, module: str, func_name: str) -> str:
        return f"{module}.{func_name}"
    
    def trace_function(self, frame, event: str, arg):
        if event == 'call':
            code = frame.f_code
            func_name = code.co_name
            module = frame.f_globals.get('__name__', '<unknown>')
            
            if func_name.startswith('_') and not func_name.startswith('__'):
                return self.trace_function
            
            start_time = time.perf_counter() * 1000
            self._call_stack.append((module, func_name, start_time))
            
            key = self._get_key(module, func_name)
            with self._lock:
                if key not in self._traces:
                    self._traces[key] = {
                        'module': module,
                        'function_name': func_name,
                        'call_count': 0,
                        'total_time_ms': 0.0,
                        'times': [],
                        'exception_count': 0,
                        'exception_types': set()
                    }
                self._traces[key]['call_count'] += 1
            
            for var_name, var_value in frame.f_locals.items():
                self._check_metric(var_name, var_value, module, func_name)
            
            return self.trace_function
        
        elif event == 'return':
            if self._call_stack:
                module, func_name, start_time = self._call_stack.pop()
                end_time = time.perf_counter() * 1000
                duration = end_time - start_time
                
                key = self._get_key(module, func_name)
                with self._lock:
                    if key in self._traces:
                        self._traces[key]['total_time_ms'] += duration
                        self._traces[key]['times'].append(duration)
                
                for var_name, var_value in frame.f_locals.items():
                    self._check_metric(var_name, var_value, module, func_name)
            
            return self.trace_function
        
        elif event == 'exception':
            if self._call_stack:
                module, func_name, _ = self._call_stack[-1]
                key = self._get_key(module, func_name)
                exc_type = arg[0].__name__ if arg and arg[0] else 'Unknown'
                
                with self._lock:
                    if key in self._traces:
                        self._traces[key]['exception_count'] += 1
                        self._traces[key]['exception_types'].add(exc_type)
            
            return self.trace_function
        
        return self.trace_function
    
    def _check_metric(self, var_name: str, var_value: Any, module: str, func_name: str):
        var_lower = var_name.lower()
        is_metric = False
        
        for pattern in METRIC_PATTERNS:
            if pattern in var_lower:
                is_metric = True
                break
        
        if is_metric:
            try:
                if isinstance(var_value, (int, float)):
                    self.collector.metric_tracker.track(
                        metric_name=var_name,
                        value=float(var_value),
                        module=module,
                        function_name=func_name
                    )
                elif hasattr(var_value, '__float__'):
                    self.collector.metric_tracker.track(
                        metric_name=var_name,
                        value=float(var_value),
                        module=module,
                        function_name=func_name
                    )
            except (TypeError, ValueError):
                pass
    
    def get_traces(self) -> list[FunctionTrace]:
        traces = []
        with self._lock:
            for key, data in self._traces.items():
                times = data['times']
                if times:
                    avg_time = sum(times) / len(times)
                    max_time = max(times)
                    min_time = min(times)
                else:
                    avg_time = max_time = min_time = 0.0
                
                traces.append(FunctionTrace(
                    module=data['module'],
                    function_name=data['function_name'],
                    call_count=data['call_count'],
                    total_time_ms=data['total_time_ms'],
                    avg_time_ms=avg_time,
                    max_time_ms=max_time,
                    min_time_ms=min_time,
                    exception_count=data['exception_count'],
                    exception_types=list(data['exception_types'])
                ))
        return traces


class DynamicCollector:
    def __init__(self, project_path: str):
        self.project_path = project_path
        self.metric_tracker = MetricTracker()
        self.log_records: list[LogRecord] = []
        self._tracer: Optional[FunctionTracer] = None
        self._log_handler: Optional[LogInterceptHandler] = None
        self._original_trace: Optional[Callable] = None
        self._trace_start: Optional[datetime] = None
        self._trace_end: Optional[datetime] = None
        self._peak_memory: int = 0
    
    def start_tracing(self):
        tracemalloc.start()
        
        self._log_handler = LogInterceptHandler(self)
        self._log_handler.setLevel(logging.DEBUG)
        logging.root.addHandler(self._log_handler)
        
        self._tracer = FunctionTracer(self)
        self._original_trace = sys.gettrace()
        sys.settrace(self._tracer.trace_function)
        
        self._trace_start = datetime.now()
    
    def stop_tracing(self):
        self._trace_end = datetime.now()
        
        sys.settrace(self._original_trace)
        
        if self._log_handler:
            logging.root.removeHandler(self._log_handler)
        
        current, peak = tracemalloc.get_traced_memory()
        self._peak_memory = peak
        tracemalloc.stop()
    
    @contextmanager
    def trace(self):
        self.start_tracing()
        try:
            yield self
        finally:
            self.stop_tracing()
    
    def run_script(self, script_path: str, script_args: Optional[list[str]] = None) -> DynamicCollectorResult:
        import runpy
        
        original_argv = sys.argv.copy()
        if script_args:
            sys.argv = [script_path] + script_args
        else:
            sys.argv = [script_path]
        
        total_exceptions = 0
        
        try:
            with self.trace():
                try:
                    runpy.run_path(script_path, run_name='__main__')
                except SystemExit:
                    pass
                except Exception:
                    total_exceptions += 1
        finally:
            sys.argv = original_argv
        
        return self._build_result(total_exceptions)
    
    def run_callable(self, func: Callable, *args, **kwargs) -> tuple[Any, DynamicCollectorResult]:
        result = None
        total_exceptions = 0
        
        with self.trace():
            try:
                result = func(*args, **kwargs)
            except Exception:
                total_exceptions += 1
                raise
        
        return result, self._build_result(total_exceptions)
    
    def _build_result(self, total_exceptions: int = 0) -> DynamicCollectorResult:
        function_traces = self._tracer.get_traces() if self._tracer else []
        metric_samples = self.metric_tracker.get_samples()
        
        total_calls = sum(t.call_count for t in function_traces)
        total_exc = sum(t.exception_count for t in function_traces)
        
        duration = 0.0
        if self._trace_start and self._trace_end:
            duration = (self._trace_end - self._trace_start).total_seconds()
        
        return DynamicCollectorResult(
            project_path=self.project_path,
            trace_start=self._trace_start or datetime.now(),
            trace_end=self._trace_end or datetime.now(),
            duration_seconds=duration,
            function_traces=function_traces,
            log_records=self.log_records,
            metric_samples=metric_samples,
            total_function_calls=total_calls,
            total_log_records=len(self.log_records),
            total_exceptions=total_exc + total_exceptions,
            peak_memory_bytes=self._peak_memory
        )
    
    def collect_from_tests(self, test_module: Optional[str] = None) -> DynamicCollectorResult:
        import unittest
        
        total_exceptions = 0
        
        with self.trace():
            loader = unittest.TestLoader()
            if test_module:
                suite = loader.loadTestsFromName(test_module)
            else:
                suite = loader.discover(self.project_path, pattern='test_*.py')
            
            runner = unittest.TextTestRunner(verbosity=0)
            result = runner.run(suite)
            total_exceptions = len(result.errors) + len(result.failures)
        
        return self._build_result(total_exceptions)


