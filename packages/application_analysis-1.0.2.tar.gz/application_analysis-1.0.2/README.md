# Application Analysis Tool

A comprehensive Python code analyzer that generates static HTML reports.

## Installation

```bash
pip install application-analysis
```

## Usage

After installation, run from command line:

```bash
analyze-app <path-to-project>
```

### Options

```
analyze-app <path> [options]

Arguments:
  path                    Path to the Python project to analyze

Options:
  -o, --output PATH       Output HTML report path (default: report.html)
  --skip-dynamic          Skip runtime analysis
  --skip-llm              Skip LLM-powered analysis (requires OPENAI_API_KEY)
  -q, --quiet             Suppress progress output
  --no-browser            Don't auto-open report in browser
```

### Examples

```bash
# Basic analysis
analyze-app ./my_project

# Custom output path
analyze-app ./my_project -o analysis_report.html

# Quick analysis without LLM
analyze-app ./my_project --skip-llm

# Silent mode, no browser
analyze-app ./my_project -q --no-browser
```

## Environment Variables

- `OPENAI_API_KEY` - Required for LLM-powered analysis features (optional)

## What It Analyzes

- **Placeholders/Stubs** - TODOs, FIXMEs, stub functions, mock patterns
- **Complexity** - Cyclomatic complexity, nesting depth, lines of code
- **Execution Flow** - Call graphs, entrypoints, architecture violations
- **Naming** - Magic identifiers, naming conventions
- **Dead Code** - Unused imports, functions, unreachable code
- **Security** - Hardcoded secrets, eval/exec, SQL injection patterns
- **Duplication** - Duplicate functions and code blocks
- **Logging** - Log quality, spam detection
- **Metrics** - Training metric stagnation (for ML projects)

## Output

Generates a self-contained HTML report with:
- Health score (0-100) and letter grade (A-F)
- Executive summary
- Detailed findings by category
- Actionable recommendations

