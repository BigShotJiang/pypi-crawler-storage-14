from pyrogram import filters , errors , Client 
from pyrogram.types import Message
from SBself.filters.SBfilters import admin_filter , owner_admin_only
from SBself.config import AllConfig
from SBself.modules.backup.backup_commands import register_backup_commands
from SBself.modules.enemy.enemy_handlers import register as register_enemy_handlers
from SBself.modules.enemy.enemy_commands import register as register_enemy_commands
from SBself.modules.admin import admin_commands
from SBself.modules.text.text_commands import register as register_text_commands
from SBself.modules.mention.mention_commands import register as register_mention_commands
from SBself.modules.chat.chat_commands import register as register_chat_commands
from SBself.modules.forward.forward_commands import register as register_forward_commands
from SBself.modules.profile.profile_commands import register as register_profile_commands
from SBself.modules.spammer.spammer_commands import register as register_spammer_commands
from SBself.modules.get_code_login.getcode_commands import register as register_get_code_commands
from SBself.modules.id.id_commands import register as register_id_commands
from SBself.modules.relay.relay_commands import register_relay_commands
from SBself.modules.anti_login.commands import register_commands as register_anti_login
import logging

def register(app: Client) -> None: 

    @app.on_message(admin_filter & filters.command("addadmin", prefixes=["/", ""]))
    async def _add_admin_cmd(client: Client, m: Message):
        uid, name = await admin_commands._resolve_reply_user(m)
        if not uid:
            return await admin_commands._edit_or_reply(m, "❗روی پیام فرد مورد نظر ریپلای بزن.")
        msg = await admin_commands.add_admin(uid, name)
        AllConfig["auth"]["admin_id"] = uid
        await admin_commands._edit_or_reply(m, msg)

    @app.on_message(admin_filter & filters.command("deladmin", prefixes=["/", ""]))
    async def _del_admin_cmd(client: Client, m: Message):
        uid, name = await admin_commands._resolve_reply_user(m)
        if not uid:
            return await admin_commands._edit_or_reply(m, "❗روی پیام فرد مورد نظر ریپلای بزن.")
        msg = await admin_commands.del_admin(uid, name)
        await admin_commands._edit_or_reply(m, msg)

    @app.on_message(admin_filter & filters.command("cleanadmins", prefixes=["/", ""]))
    async def _clean_admins_cmd(client: Client, m: Message):
        msg = await admin_commands.clean_admins()
        await admin_commands._edit_or_reply(m, msg)

    @app.on_message(admin_filter & filters.command(["admins", "showadmins"], prefixes=["/", ""]))
    async def _list_admins_cmd(client: Client, m: Message):
        msg = await admin_commands.list_admins()
        await admin_commands._edit_or_reply(m, msg)

    # =========================
    #  COMMAND MAPPING
    # =========================
    COMMAND_HANDLERS = {
        "add": add_account,
        "code": set_code,
        "pass": set_2fa,
        "del": delete_account,
        "delall": delete_all_accounts,
        "listacc": list_accounts,

        "givedatasessions": give_data_sessions_handler,
        "delallpvgpchenl": del_all_pv_gp_ch_en,
        "givesessions": give_sessions_handler,

        "text": save_text,
        "ctext": clear_texts,
        "shtext": show_text,
        "shcap": show_caption,
        "cap": add_caption,
        "ccap": clear_caption,

        "textmention": _setmention,
        "mention_user": _mention_user,
        "mention_toggle": _mention_toggle,
        "mention_group_toggle": _mention_group_toggle,
        "mention_gps": _mention_gps,
        "mention_del": _mention_del,
        "mention_clear": _mention_clear,
        "mention_status": _mention_status,

        "gcode": get_code_command,
        "restart": restart_cmd,

        "join": join_command,
        "leave": leave_command,

        "addadmin": _add_admin_cmd,
        "deladmin": _del_admin_cmd,
        "admins": _list_admins_cmd,
        "cleanadmins":_clean_admins_cmd,

        "profilesettings": profilesettings_cmd,
        "setPic": set_profile_photo_cmd,
        "delallprofile": delete_all_photos_cmd,
        "name": change_name_cmd,
        "bio": change_bio_cmd,
        "username": set_username_cmd,
        "remusername": rem_username_cmd,

        "block": block_user_all_accounts,
        "unblock": unblock_user_all_accounts,

        "dbstatus": cmd_db_status,
        "dbrepair": cmd_db_repair,

        "spam": start_spam,
        "stop": stop_spam,
        "speed": set_speed,
        "set": _set_handler,
        "stats": show_stats,
    }

    # =========================
    #  ACCESS CHECK
    # =========================
    async def _has_access(message: Message, meta: CommandMeta) -> bool:
        """
        بر اساس metadata.py تشخیص می‌دهد کاربر اجازهٔ اجرای این کامند را دارد یا نه.
        """
        user = getattr(message, "from_user", None)
        if user is None:
            return False

        uid = int(user.id)

        owner_ids = getattr(config, "OWNER_ID", [])
        try:
            owner_ids = set(owner_ids)
        except TypeError:
            owner_ids = {owner_ids}

        admins = getattr(admin_manager, "ADMINS", set())
        try:
            admins = set(admins)
        except TypeError:
            admins = {admins}

        if meta.access == "owner":
            return uid in owner_ids

        # admin: هر کسی که ادمین است یا owner
        return uid in admins or uid in owner_ids

    # =========================
    #  ROUTER
    # =========================
    @app.on_message(
        filters.command(list(COMMANDS.keys()), prefixes=["", "/", "!", "."])
    )
    async def command_router(client, message: Message):
        if not getattr(message, "command", None):
            return

        cmd_raw = message.command[0]
        cmd = cmd_raw.lstrip("/").lower()

        meta = COMMANDS.get(cmd)
        if meta is None:
            logger.warning("Received unknown command %r in router", cmd)
            return

        if not await _has_access(message, meta):
            try:
                await message.reply("⛔️ شما اجازهٔ استفاده از این دستور را ندارید.")
            except Exception:
                pass
            return

        handler = COMMAND_HANDLERS.get(cmd)
        if handler is None:
            logger.warning("No handler mapped for command %r", cmd)
            try:
                await message.reply("⚠ این دستور فعلاً در دسترس نیست.")
            except Exception:
                pass
            return

        try:
            await handler(client, message)
        except Exception as e:
            logger.exception("Error while handling command %r: %s", cmd, e)
            try:
                await message.reply("💥 خطایی در پردازش دستور رخ داد.")
            except Exception:
                pass
