from SBself.modules.backup.backup_commands import register_backup_commands
from SBself.modules.enemy.enemy_handlers import register as register_enemy_handlers
from SBself.modules.enemy.enemy_commands import register as register_enemy_commands
from SBself.modules.admin.admin_commands import register as register_admin_commands
from SBself.modules.text.text_commands import register as register_text_commands
from SBself.modules.mention.mention_commands import register as register_mention_commands
from SBself.modules.chat.chat_commands import register as register_chat_commands
from SBself.modules.forward.forward_commands import register as register_forward_commands
from SBself.modules.profile.profile_commands import register as register_profile_commands
from SBself.modules.spammer.spammer_commands import register as register_spammer_commands
from SBself.modules.get_code_login.getcode_commands import register as register_get_code_commands
from SBself.modules.id.id_commands import register as register_id_commands
from SBself.modules.relay.relay_commands import register_relay_commands
from SBself.modules.anti_login.commands import register_commands as register_anti_login