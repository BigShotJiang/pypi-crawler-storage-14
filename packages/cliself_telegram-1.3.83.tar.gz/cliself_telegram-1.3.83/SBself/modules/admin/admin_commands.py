from __future__ import annotations

from typing import Optional, Tuple
from pyrogram import Client, filters
from pyrogram.types import Message

from ...config import AllConfig
from ...filters.SBfilters import admin_filter 


# ---------------- Helpers ----------------

def _auth() -> dict:
    """اطمینان از وجود ساختار نقش‌ها در کانفیگ."""
    a = AllConfig.setdefault("auth", {})
    a.setdefault("admin_owner_id", None) 
    a.setdefault("admin_id", None)      
    a.setdefault("names", {})       
    return a

def _set_admin(uid: Optional[int], name: str = "") -> None:
    """تنظیم/جایگزینی ادمین عادی."""
    a = _auth()
    a["admin_id"] = int(uid) if uid is not None else None
    if uid is not None and name:
        try:
            a["names"][int(uid)] = name
        except Exception:
            pass

def _get_names() -> dict:
    return _auth().setdefault("names", {})

async def _resolve_reply_user(m: Message) -> Tuple[Optional[int], str]:
    """اگر روی پیام کسی ریپلای شده باشد، (id, name) او را برمی‌گرداند؛ وگرنه (None, '')."""
    if not (m.reply_to_message and m.reply_to_message.from_user):
        return None, ""
    u = m.reply_to_message.from_user
    full = " ".join([p for p in [(u.first_name or ""), (u.last_name or "")] if p]).strip()
    return int(u.id), (full or (u.username or "") or "")

async def _edit_or_reply(m: Message, text: str):
    """اول تلاش می‌کند ادیت کند؛ اگر نشد ریپلای می‌دهد."""
    try:
        await m.edit_text(text, disable_web_page_preview=True)
    except Exception:
        await m.reply(text, disable_web_page_preview=True)


# --------------- Business ops ---------------

async def add_admin(uid: int, name: str) -> str:
    """
    تنظیم/جایگزینی ادمین عادی.
    اگر uid همان admin_owner باشد، صرفاً اطلاع می‌دهیم که او در لیست ادمین عادی قرار نمی‌گیرد.
    """
    label = f" — {name}" if name else ""
    return f"✅ ادمین تنظیم شد: `{uid}`{label}"

async def del_admin(uid: int, name: str) -> str:
    """
    حذف ادمین عادی.
    اگر uid همان admin_owner باشد، پیام می‌دهیم «این ادمین پیدا نشد.»
    چون ادمین‌ویژه در لیست ادمین‌های عادی اصلاً وجود ندارد.
    """
    a = _auth()
    admin_owner_id = a.get("admin_owner_id")
    if admin_owner_id is not None and int(uid) == int(admin_owner_id):
        return "ℹ️ این ادمین پیدا نشد."

    curr_admin = a.get("admin_id")
    if curr_admin is None:
        return "ℹ️ ادمینی برای حذف ثبت نشده."
    if int(uid) != int(curr_admin):
        return "ℹ️ این ادمین پیدا نشد."

    # حذف ادمین عادی
    a["admin_id"] = None
    _get_names().pop(int(uid), None)
    label = f" — {name}" if name else ""
    return f"🗑 ادمین حذف شد: `{uid}`{label}"

async def clean_admins() -> str:
    """پاکسازی ادمین عادی (ادمین‌ویژه اصلاً در این لیست نیست که بخواهد پاک شود)."""
    a = _auth()
    curr_admin = a.get("admin_id")
    a["admin_id"] = None
    if curr_admin is not None:
        _get_names().pop(int(curr_admin), None)
    return "🧹 ادمین پاک شد."

async def list_admins() -> str:
    """
    نمایش لیست ادمین‌ها:
      - فقط «ادمین عادی» نمایش داده می‌شود.
      - ادمین‌ویژه (admin_owner) هرگز نمایش داده نمی‌شود.
    """
    a = _auth()
    admin_id = a.get("admin_id")
    names = _get_names()

    lines = ["👮‍♂️ **لیست ادمین‌ها:**"]
    if admin_id:
        nm = names.get(int(admin_id), "")
        lines.append(f"- `{admin_id}`{(' — ' + nm) if nm else ''}")
    else:
        lines.append("ℹ️ ادمین ثبت نشده است.")
    return "\n".join(lines)
