class PersistenceError(Exception):
    """Generic persistence error raised when a DynamoDB operation fails after retries."""
    pass