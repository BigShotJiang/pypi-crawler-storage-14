from .auth import LoginError, AuthTimeOut
from .mails import MailError
