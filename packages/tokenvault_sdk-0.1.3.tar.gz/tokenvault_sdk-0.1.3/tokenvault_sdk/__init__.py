"""
TokenVault SDK - Agent Usage Tracking Library

A lightweight Python SDK for AI agents to track LLM usage and forward billing data to TokenVault.
Provides simple functions for balance checking and usage tracking without wrapping your LLM client.
"""

from tokenvault_sdk.config import SDKConfig
from tokenvault_sdk.tracker import UsageTracker
from tokenvault_sdk.exceptions import (
    InsufficientBalanceError,
    SDKConfigurationError,
    TrackingError,
)
from tokenvault_sdk.logging_config import configure_logging, get_logger

__version__ = "0.1.3"
__all__ = [
    "SDKConfig",
    "UsageTracker",
    "InsufficientBalanceError",
    "SDKConfigurationError",
    "TrackingError",
    "configure_logging",
    "get_logger",
]
