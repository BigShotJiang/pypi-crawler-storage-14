prefixes = {
    "CL": "http://purl.obolibrary.org/obo/CL_",
    "UBERON": "http://purl.obolibrary.org/obo/UBERON_",
    "PATO": "http://purl.obolibrary.org/obo/PATO_",
    "MONDO": "http://purl.obolibrary.org/obo/MONDO_",
    "HsapDv": "http://purl.obolibrary.org/obo/HsapDv_",
    "NCBITaxon": "http://purl.obolibrary.org/obo/NCBITaxon_",
    "EFO": "http://www.ebi.ac.uk/efo/EFO_",
}
