from pydantic import BaseModel, Field


class Diff(BaseModel):
    old_value: str = Field(..., alias="oldValue")
    new_value: str = Field(..., alias="newValue")
