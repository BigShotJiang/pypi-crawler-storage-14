import pytest
from moysklad_api.types import Webhook, Event, Audit


@pytest.mark.unit
@pytest.mark.parametrize(
    "payload",
    [
        {
            "auditContext": {
                "meta": {
                    "href": "https://api.moysklad.ru/api/remap/1.2/audit/audit_id",
                    "type": "audit",
                },
                "moment": "2025-11-21 10:19:22",
                "uid": "test@user",
            },
            "events": [
                {
                    "accountId": "account_id",
                    "action": "UPDATE",
                    "meta": {
                        "href": "https://api.moysklad.ru/api/remap/1.2/entity/product/product_id",
                        "type": "product",
                    },
                }
            ],
        },

        {
            "events": [],
            "auditContext": None,
        },

        {
            "auditContext": {
                "meta": {
                    "href": "http://example/audit",
                    "type": "audit",
                },
                "moment": "2025-01-01 12:00:00",
                "uid": "test@user",
            },
            "events": [
                {
                    "accountId": "111",
                    "action": "CREATE",
                    "meta": {
                        "href": "http://entity/1",
                        "type": "product",
                    },
                },
                {
                    "accountId": "222",
                    "action": "UPDATE",
                    "meta": {
                        "href": "http://entity/2",
                        "type": "product",
                    },
                },
            ],
        },
    ],
)
class TestWebhook:
    def test_webhook_parses(self, payload):
        webhook = Webhook(**payload)
        assert isinstance(webhook, Webhook)

    def test_events_parsed(self, payload):
        webhook = Webhook(**payload)

        if "events" not in payload or payload["events"] is None:
            assert webhook.events is None
            return

        assert isinstance(webhook.events, list)
        assert len(webhook.events) == len(payload["events"])

        for i, event in enumerate(payload["events"]):
            parsed = webhook.events[i]
            assert isinstance(parsed, Event)
            assert parsed.action == event.get("action")
            assert parsed.accountId == event.get("accountId")

    def test_audit_context(self, payload):
        webhook = Webhook(**payload)

        if payload.get("auditContext") is None:
            assert webhook.audit_context is None
            return

        audit_raw = payload["auditContext"]
        audit = webhook.audit_context

        assert isinstance(audit, Audit)
        assert audit.uid == audit_raw.get("uid")
        assert audit.moment.strftime("%Y-%m-%d %H:%M:%S") == audit_raw.get("moment")
        assert audit.meta.href == audit_raw["meta"]["href"]
