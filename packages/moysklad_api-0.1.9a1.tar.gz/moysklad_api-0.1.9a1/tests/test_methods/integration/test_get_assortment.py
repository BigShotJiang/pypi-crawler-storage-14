import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Assortment, MetaArray
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetAssortment:
    """
    Example with options: --assortment-id=1234-5678-919dj-5252363
    """

    async def test_method(self, real_client: MoyskladAPI, api_params):
        assortment = await real_client.get_assortment(**api_params)
        assert isinstance(assortment, MetaArray)
        assert all(isinstance(p, Assortment) for p in assortment.rows)

        expanded = api_params.get("expand", None)
        if expanded:
            assert_expand(expanded, assortment)
