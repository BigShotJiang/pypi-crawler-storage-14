from uuid import uuid4

from moysklad_api import MoyskladAPI
from moysklad_api.types import Meta, Product


class MockedClient(MoyskladAPI):
    def __init__(self, token: str = "mocked_token"):
        super().__init__(token=token)

    async def get_products(self, **kwargs) -> list[Product]:
        mock_product_1 = Product(
            account_id=uuid4(),
            archived=False,
            id=uuid4(),
            meta=Meta(href="https://example.com/meta/1", type="product"),
            name="Product 1",
            shared=True,
            uom=Meta(href="https://example.com/meta/uom", type="uom"),
        )

        mock_product_2 = Product(
            account_id=uuid4(),
            archived=False,
            id=uuid4(),
            meta=Meta(href="https://example.com/meta/2", type="product"),
            name="Product 2",
            shared=True,
            uom=Meta(href="https://example.com/meta/uom", type="uom"),
        )
        return [mock_product_1, mock_product_2]
