import pytest

from moysklad_api.utils.string import camel_to_slash


@pytest.mark.asyncio
@pytest.mark.unit
class TestStringUtils:
    async def test_camel_to_slash(self):
        assert camel_to_slash("stockAll") == "stock/all"
        assert camel_to_slash("stockCurrent") == "stock/current"
        assert camel_to_slash("byOperations") == "by/operations"
        assert camel_to_slash("stock") == "stock"
        assert camel_to_slash("profit") == "profit"
        assert camel_to_slash("HTMLParser") == "html/parser"
        assert camel_to_slash("camelCase") == "camel/case"
        assert camel_to_slash("MultipleWordsHere") == "multiple/words/here"
        assert camel_to_slash("") == ""
        assert camel_to_slash("A") == "a"
        assert camel_to_slash("AB") == "a/b"
