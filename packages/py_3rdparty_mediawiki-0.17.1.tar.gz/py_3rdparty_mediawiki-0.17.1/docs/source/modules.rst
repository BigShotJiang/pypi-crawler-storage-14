py-3rdparty-mediawiki
=====================

.. toctree::
   :maxdepth: 4

   setup
   tests
   wikibot
