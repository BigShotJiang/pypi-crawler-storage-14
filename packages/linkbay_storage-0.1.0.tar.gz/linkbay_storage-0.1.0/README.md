# LinkBay-Storage

**Version**: 0.1.0  
**License**: Proprietary  
**Python**: 3.8+

Protocol-based, database-agnostic file storage and management system for multi-tenant SaaS.

---

## Table of Contents

- [Architecture](#architecture)
- [Installation](#installation)
- [Core Components](#core-components)
- [Quick Start](#quick-start)
- [FastAPI Integration](#fastapi-integration)
- [Storage Providers](#storage-providers)
- [Security and Isolation](#security-and-isolation)
- [Limits and Performance](#limits-and-performance)
- [LinkBay Ecosystem](#linkbay-ecosystem)
- [Features](#features)
- [License](#license)
- [Support](#support)

---

## Architecture

Zero-coupling design:
- **Protocol-based**: Storage, permissions, quotas, and scanning rely on Python `Protocol` interfaces to keep adapters swappable.
- **Database-agnostic**: No ORM or schema assumptions for metadata persistence.
- **Multi-tenant first**: Every API requires a `tenant_id`, enabling hard isolation and auditing.
- **Pluggable backends**: S3, MinIO, GCS, Azure Blob, or local filesystem through adapters.
- **RBAC integration**: Works with `linkbay-roles` for access control decisions.
- **Quota enforcement**: Per-tenant limits wired to the subscription layer.

---

## Installation

```bash
pip install linkbay-storage
```

Optional dependencies:
```bash
pip install linkbay-storage[s3]       # AWS S3 support
pip install linkbay-storage[fastapi]  # FastAPI router
```

---

## Core Components

### Protocols
- `FileStorage` - File metadata storage (your database)
- `StorageProvider` - Backend storage (S3, MinIO, etc.)
- `FilePermissionsProvider` - Access control (integrates with linkbay-roles)
- `QuotaProvider` - Tenant quota management
- `VirusScannerProvider` - Virus scanning (ClamAV, VirusTotal)
- `CDNProvider` - CDN integration (Cloudflare, CloudFront)

### Services
- `FileManager` - Core file operations (upload, download, delete)
- `StorageService` - Storage backend wrapper
- `PermissionsService` - Access control enforcement
- `QuotaService` - Quota checking and usage stats

### Built-in Adapters
- `S3StorageProvider` - AWS S3
- `MinIOStorageProvider` - MinIO (S3-compatible)
- `LocalStorageProvider` - Local filesystem (dev/testing)

---

## Quick Start

### 1. Upload File with Quota Check

```python
from linkbay_storage import FileManager, UploadRequest, FileMetadata

manager = FileManager(
    file_storage=your_file_storage,
    storage_provider=s3_provider,
    quota_provider=quota_provider,
)

# Upload PDF invoice with metadata
file = await manager.upload_file(
    tenant_id="tenant_123",
    user_id="user_456",
    file_data=pdf_bytes,
    request=UploadRequest(
        filename="invoice_2024.pdf",
        mime_type="application/pdf",
        metadata=FileMetadata(
            tags={"document_type": "invoice", "invoice_id": "123"},
        ),
        check_virus=True,
    ),
)
```

### 2. Generate Presigned Upload URL (Client-Side Upload)

```python
from linkbay_storage import PresignedUploadRequest

# Generate presigned URL for direct S3 upload
response = await manager.generate_presigned_upload_url(
    tenant_id="tenant_123",
    user_id="user_456",
    request=PresignedUploadRequest(
        filename="document.pdf",
        mime_type="application/pdf",
        size_bytes=1024000,
        expires_in=3600,
    ),
)

# Client uploads directly to response.upload_url
```

### 3. Download File with Permission Check

```python
# Check permissions and download
file_data = await manager.download_file(
    tenant_id="tenant_123",
    file_id="file_789",
    user_id="user_456",
)
```

### 4. List Files with Filters

```python
from linkbay_storage import FileFilter
from datetime import datetime

# Search invoices from 2024
files = await manager.list_files(
    tenant_id="tenant_123",
    filters=FileFilter(
        tags={"document_type": "invoice"},
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
    ),
    skip=0,
    limit=50,
)
```

### 5. Get Storage Usage Stats

```python
from linkbay_storage import QuotaService

quota_service = QuotaService(quota_provider)

usage = await quota_service.get_usage("tenant_123")
print(f"Used: {usage.used_storage_gb:.2f} GB")
print(f"Quota: {usage.quota_info.max_storage_bytes / (1024**3):.2f} GB")
print(f"Usage: {usage.usage_percent:.1f}%")
```

---

## FastAPI Integration

```python
from fastapi import FastAPI
from linkbay_storage import create_storage_router

app = FastAPI()

router = create_storage_router(
    get_file_manager=get_file_manager,
    get_permissions_service=get_permissions_service,
    get_quota_service=get_quota_service,
    prefix="/api/v1/storage",
)

app.include_router(router)
```

### API Endpoints

```
POST   /api/v1/storage/{tenant_id}/upload              - Upload file
POST   /api/v1/storage/{tenant_id}/presigned-upload    - Get presigned URL
GET    /api/v1/storage/{tenant_id}/files               - List files
GET    /api/v1/storage/{tenant_id}/files/{file_id}     - Get file metadata
GET    /api/v1/storage/{tenant_id}/files/{file_id}/download - Download file
GET    /api/v1/storage/{tenant_id}/files/{file_id}/download-url - Get presigned download URL
PUT    /api/v1/storage/{tenant_id}/files/{file_id}     - Update metadata
DELETE /api/v1/storage/{tenant_id}/files/{file_id}     - Delete file
POST   /api/v1/storage/{tenant_id}/files/{file_id}/copy - Copy file
POST   /api/v1/storage/{tenant_id}/files/{file_id}/move - Move file
GET    /api/v1/storage/{tenant_id}/usage               - Get usage stats
```

---

## Storage Providers

### AWS S3

```python
from linkbay_storage.adapters import S3StorageProvider

provider = S3StorageProvider(
    aws_access_key_id="AKIA...",
    aws_secret_access_key="...",
    region_name="us-east-1",
)
```

### MinIO

```python
from linkbay_storage.adapters import MinIOStorageProvider

provider = MinIOStorageProvider(
    endpoint_url="http://localhost:9000",
    access_key="minioadmin",
    secret_key="minioadmin",
)
```

### Local Filesystem

```python
from linkbay_storage.adapters import LocalStorageProvider

provider = LocalStorageProvider(base_path="/var/storage")
```

---

## Security and Isolation

- **Tenant partitioning**: Recommended default is a dedicated S3 bucket per tenant for hard isolation. For high-tenant-count scenarios, use a shared bucket with per-tenant prefixes plus S3 Access Points or IAM scoped down to the prefix.
- **Encryption strategy**: Support envelope encryption with AWS KMS. Generate a customer managed key per tenant (or per plan) and inject the `kms_key_id` into the storage adapter. MinIO deployments can mirror the pattern using Vault or KES for key management.
- **Access policy management**: Delegate authorization to `linkbay-roles` via `FilePermissionsProvider`. Combine RBAC with contextual checks (IP allow-lists, business hours) by enriching permission decisions before calling storage APIs.
- **Virus scanning guarantees**: `VirusScannerProvider` runs post-upload or pre-download scanning. Define fallback behavior (quarantine, block, or warn) when the scanner is unavailable to avoid silent bypasses.
- **Audit trail**: Emit upload/download/delete events to `LinkBay-Audit` to trace data exfiltration attempts and meet regulatory controls (PCI, SOC2, GDPR data subject export tracking).
- **Data retention**: Couple quota enforcement with lifecycle policies (S3 Intelligent-Tiering, Glacier transition, auto-expiration for temp files) and document per-tenant overrides in `LinkBay-Settings`.

---

## Limits and Performance

- **Upload size**: Favor streaming inputs (`UploadFile` in FastAPI) to avoid loading large files in memory. Configure S3 multipart uploads for files over 100 MB.
- **Throughput vs. metadata**: Persist metadata write operations asynchronously when the storage backend provides strong consistency. Use idempotency keys in `UploadRequest` to retry safely.
- **Concurrency controls**: Use `QuotaService` pre-flight checks to short-circuit uploads when tenants are near capacity. Consider back-pressure (429) for bursty tenants.
- **Caching and CDN**: Pair signed CDN URLs with short TTLs. `CDNProvider` can publish purge events to keep cached assets coherent.
- **Lifecycle policies**: Recommend daily cleanup jobs for soft-deleted files and aging artifacts. Expose retention configuration via `LinkBay-Settings` so tenants can align with internal policies.

---

## LinkBay Ecosystem

- **LinkBay-Subscriptions**: Quota tiers map to subscription plans. Implement `QuotaProvider` against plan metadata so upgrades immediately increase storage ceilings.
- **LinkBay-Roles**: Permission checks (`files:upload`, `files:delete`, `files:share`) flow through `PermissionsService`, letting tenants assign granular roles without duplicating logic.
- **LinkBay-Audit**: Route audit hooks from `FileManager` to capture who accessed which asset, from which IP, and whether the action succeeded.
- **LinkBay-Settings**: Store tenant-level configuration (encryption mode, CDN preferences, retention policies) and inject them into adapter factories at runtime.

---

## Features

- **Multi-tenant isolation**: All operations require `tenant_id`.
- **Quota enforcement**: Per-tenant storage limits with real-time usage stats.
- **Permissions**: Role-based and contextual access control via `FilePermissionsProvider`.
- **Virus scanning**: Optional ClamAV or VirusTotal integration with configurable fallback.
- **Presigned URLs**: Direct client-to-storage uploads and downloads.
- **File lifecycle**: Archive old files, auto-expiration, and retention policies.
- **Metadata and tagging**: Custom metadata for search and governance.
- **CDN support**: Optional Cloudflare or CloudFront integration for edge delivery.

---

## License

Proprietary - Copyright (c) 2025 Alessio Quagliara

---

## Support

Email: quagliara.alessio@gmail.com
