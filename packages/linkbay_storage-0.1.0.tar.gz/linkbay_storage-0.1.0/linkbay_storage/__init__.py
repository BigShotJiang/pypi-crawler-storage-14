"""LinkBay-Storage: Protocol-based file storage for multi-tenant SaaS."""

from .constants import (
    FileVisibility,
    VirusScanStatus,
    StorageClass,
    MAX_FILE_SIZE_MB,
    ALLOWED_MIME_TYPES,
)

from .exceptions import (
    StorageError,
    FileNotFoundError,
    QuotaExceededError,
    PermissionDeniedError,
    VirusDetectedError,
    InvalidFileTypeError,
    FileTooLargeError,
)

from .protocols import (
    FileStorage,
    StorageProvider,
    FilePermissionsProvider,
    QuotaProvider,
    VirusScannerProvider,
    CDNProvider,
)

from .schemas import (
    FileDTO,
    FileCreate,
    FileUpdate,
    FileFilter,
    FileResponse,
    FileListResponse,
    UploadRequest,
    PresignedUploadRequest,
    PresignedUploadResponse,
    PresignedDownloadResponse,
    FileMetadata,
    QuotaInfo,
    UsageStats,
    VirusScanResult,
)

from .services import (
    FileManager,
    StorageService,
    PermissionsService,
    QuotaService,
)

from .router import create_storage_router

__all__ = [
    # Constants
    "FileVisibility",
    "VirusScanStatus",
    "StorageClass",
    "MAX_FILE_SIZE_MB",
    "ALLOWED_MIME_TYPES",
    # Exceptions
    "StorageError",
    "FileNotFoundError",
    "QuotaExceededError",
    "PermissionDeniedError",
    "VirusDetectedError",
    "InvalidFileTypeError",
    "FileTooLargeError",
    # Protocols
    "FileStorage",
    "StorageProvider",
    "FilePermissionsProvider",
    "QuotaProvider",
    "VirusScannerProvider",
    "CDNProvider",
    # Schemas
    "FileDTO",
    "FileCreate",
    "FileUpdate",
    "FileFilter",
    "FileResponse",
    "FileListResponse",
    "UploadRequest",
    "PresignedUploadRequest",
    "PresignedUploadResponse",
    "PresignedDownloadResponse",
    "FileMetadata",
    "QuotaInfo",
    "UsageStats",
    "VirusScanResult",
    # Services
    "FileManager",
    "StorageService",
    "PermissionsService",
    "QuotaService",
    # Router
    "create_storage_router",
]

__version__ = "0.1.0"
