"""Constants for file storage."""

from enum import Enum


class FileVisibility(str, Enum):
    """File visibility levels."""
    PRIVATE = "private"  # Only owner/tenant
    SHARED = "shared"    # Specific users/roles
    PUBLIC = "public"    # Anyone with link


class VirusScanStatus(str, Enum):
    """Virus scan status."""
    PENDING = "pending"
    CLEAN = "clean"
    INFECTED = "infected"
    SKIPPED = "skipped"
    FAILED = "failed"


class StorageClass(str, Enum):
    """Storage tier for lifecycle management."""
    STANDARD = "standard"
    INFREQUENT_ACCESS = "infrequent_access"
    GLACIER = "glacier"
    DEEP_ARCHIVE = "deep_archive"


# File size limits
MAX_FILE_SIZE_MB = 100
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024

# Default quotas (override per tenant)
DEFAULT_STORAGE_QUOTA_GB = 10
DEFAULT_MAX_FILES = 10000

# Presigned URL expiration
DEFAULT_UPLOAD_URL_EXPIRES = 3600  # 1 hour
DEFAULT_DOWNLOAD_URL_EXPIRES = 300  # 5 minutes

# Allowed MIME types (customize per tenant)
ALLOWED_MIME_TYPES = [
    # Documents
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    # Images
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "image/svg+xml",
    # Videos
    "video/mp4",
    "video/mpeg",
    "video/quicktime",
    # Archives
    "application/zip",
    "application/x-tar",
    "application/gzip",
    # Text
    "text/plain",
    "text/csv",
    "text/html",
    # JSON
    "application/json",
]

# Virus scan file size limit (MB)
MAX_VIRUS_SCAN_SIZE_MB = 50
