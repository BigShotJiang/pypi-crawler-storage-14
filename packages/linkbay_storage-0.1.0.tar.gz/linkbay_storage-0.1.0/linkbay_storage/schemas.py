"""Pydantic schemas for storage."""

from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field

from .constants import FileVisibility, VirusScanStatus, StorageClass


class FileMetadata(BaseModel):
    """Custom metadata for file."""
    tags: Dict[str, str] = Field(default_factory=dict)
    custom: Dict[str, Any] = Field(default_factory=dict)


class FileDTO(BaseModel):
    """Complete file metadata."""
    id: str
    tenant_id: str
    filename: str
    original_filename: str
    mime_type: str
    size_bytes: int
    bucket: str
    storage_key: str
    uploaded_by: str
    uploaded_at: datetime
    updated_at: datetime
    visibility: FileVisibility
    virus_scan_status: VirusScanStatus
    storage_class: StorageClass = StorageClass.STANDARD
    metadata: FileMetadata = Field(default_factory=FileMetadata)
    description: Optional[str] = None
    download_count: int = 0
    last_accessed_at: Optional[datetime] = None


class FileCreate(BaseModel):
    """Request to create file metadata."""
    filename: str
    original_filename: str
    mime_type: str
    size_bytes: int
    bucket: str
    storage_key: str
    uploaded_by: str
    visibility: FileVisibility = FileVisibility.PRIVATE
    metadata: FileMetadata = Field(default_factory=FileMetadata)
    description: Optional[str] = None


class FileUpdate(BaseModel):
    """Request to update file metadata."""
    filename: Optional[str] = None
    visibility: Optional[FileVisibility] = None
    metadata: Optional[FileMetadata] = None
    description: Optional[str] = None
    storage_class: Optional[StorageClass] = None


class FileFilter(BaseModel):
    """Filters for listing files."""
    mime_type: Optional[str] = None
    visibility: Optional[FileVisibility] = None
    virus_scan_status: Optional[VirusScanStatus] = None
    storage_class: Optional[StorageClass] = None
    uploaded_by: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    tags: Optional[Dict[str, str]] = None
    search_query: Optional[str] = None  # Search in filename, description


class FileResponse(BaseModel):
    """Response with file metadata."""
    file: FileDTO


class FileListResponse(BaseModel):
    """Paginated list of files."""
    files: List[FileDTO]
    total: int
    skip: int
    limit: int


class UploadRequest(BaseModel):
    """Request to upload file."""
    filename: str
    mime_type: str
    visibility: FileVisibility = FileVisibility.PRIVATE
    metadata: FileMetadata = Field(default_factory=FileMetadata)
    description: Optional[str] = None
    check_virus: bool = True


class PresignedUploadRequest(BaseModel):
    """Request for presigned upload URL."""
    filename: str
    mime_type: str
    size_bytes: int
    visibility: FileVisibility = FileVisibility.PRIVATE
    metadata: FileMetadata = Field(default_factory=FileMetadata)
    description: Optional[str] = None
    expires_in: int = 3600  # 1 hour


class PresignedUploadResponse(BaseModel):
    """Response with presigned upload URL."""
    upload_url: str
    file_id: str
    fields: Dict[str, str] = Field(default_factory=dict)
    expires_at: datetime


class PresignedDownloadResponse(BaseModel):
    """Response with presigned download URL."""
    download_url: str
    expires_at: datetime


class QuotaInfo(BaseModel):
    """Tenant quota information."""
    tenant_id: str
    max_storage_bytes: int
    max_files: int
    max_file_size_bytes: int
    allowed_mime_types: Optional[List[str]] = None


class UsageStats(BaseModel):
    """Current storage usage."""
    tenant_id: str
    used_storage_bytes: int
    used_storage_gb: float
    total_files: int
    quota_info: QuotaInfo
    usage_percent: float


class VirusScanResult(BaseModel):
    """Result of virus scan."""
    scan_id: str
    file_id: str
    status: VirusScanStatus
    scanned_at: datetime
    virus_name: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


class FilePermission(BaseModel):
    """File access permission."""
    file_id: str
    user_id: str
    permissions: List[str]  # ["read", "write", "delete"]
    granted_by: str
    granted_at: datetime


class MoveFileRequest(BaseModel):
    """Request to move file."""
    dest_bucket: str
    dest_path: Optional[str] = None


class CopyFileRequest(BaseModel):
    """Request to copy file."""
    dest_bucket: str
    dest_path: Optional[str] = None
    new_filename: Optional[str] = None
