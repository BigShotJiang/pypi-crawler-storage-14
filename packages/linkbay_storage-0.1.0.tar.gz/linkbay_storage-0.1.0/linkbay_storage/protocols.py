"""Protocol definitions for storage providers."""

from typing import Protocol, Dict, Any, List, Optional, AsyncIterator
from datetime import datetime


class FileStorage(Protocol):
    """
    Protocol for file metadata storage.
    
    Stores file metadata (not actual file bytes).
    User implements with their database (PostgreSQL, MongoDB, etc.).
    """
    
    async def create_file(
        self,
        tenant_id: str,
        file_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create file metadata record."""
        ...
    
    async def get_file(
        self,
        tenant_id: str,
        file_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get file metadata by ID."""
        ...
    
    async def update_file(
        self,
        tenant_id: str,
        file_id: str,
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update file metadata."""
        ...
    
    async def delete_file(
        self,
        tenant_id: str,
        file_id: str,
    ) -> bool:
        """Delete file metadata."""
        ...
    
    async def list_files(
        self,
        tenant_id: str,
        filters: Dict[str, Any],
        skip: int = 0,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """List files with filters."""
        ...
    
    async def count_files(
        self,
        tenant_id: str,
        filters: Dict[str, Any],
    ) -> int:
        """Count files matching filters."""
        ...
    
    async def get_storage_usage(
        self,
        tenant_id: str,
    ) -> Dict[str, Any]:
        """Get storage usage stats for tenant."""
        ...


class StorageProvider(Protocol):
    """
    Protocol for storage backend (S3, MinIO, GCS, Azure, etc.).
    
    Handles actual file bytes storage and retrieval.
    """
    
    async def put_object(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """Upload file to storage. Returns storage URL."""
        ...
    
    async def get_object(
        self,
        bucket: str,
        key: str,
    ) -> bytes:
        """Download file from storage."""
        ...
    
    async def delete_object(
        self,
        bucket: str,
        key: str,
    ) -> bool:
        """Delete file from storage."""
        ...
    
    async def list_objects(
        self,
        bucket: str,
        prefix: str = "",
    ) -> List[Dict[str, Any]]:
        """List objects in bucket."""
        ...
    
    async def copy_object(
        self,
        source_bucket: str,
        source_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> bool:
        """Copy object to new location."""
        ...
    
    async def move_object(
        self,
        source_bucket: str,
        source_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> bool:
        """Move object to new location."""
        ...
    
    async def generate_presigned_upload_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
        content_type: str,
    ) -> Dict[str, Any]:
        """Generate presigned URL for direct upload."""
        ...
    
    async def generate_presigned_download_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
    ) -> str:
        """Generate presigned URL for download."""
        ...
    
    async def set_object_storage_class(
        self,
        bucket: str,
        key: str,
        storage_class: str,
    ) -> bool:
        """Change storage tier (for lifecycle management)."""
        ...


class FilePermissionsProvider(Protocol):
    """
    Protocol for file access control.
    
    Integrates with linkbay-roles for RBAC.
    """
    
    async def check_access(
        self,
        tenant_id: str,
        file_id: str,
        user_id: str,
        action: str,
    ) -> bool:
        """Check if user has permission for action on file."""
        ...
    
    async def grant_access(
        self,
        tenant_id: str,
        file_id: str,
        user_id: str,
        permissions: List[str],
    ) -> bool:
        """Grant user permissions on file."""
        ...
    
    async def revoke_access(
        self,
        tenant_id: str,
        file_id: str,
        user_id: str,
    ) -> bool:
        """Revoke user permissions on file."""
        ...
    
    async def list_file_permissions(
        self,
        tenant_id: str,
        file_id: str,
    ) -> List[Dict[str, Any]]:
        """List all permissions for file."""
        ...


class QuotaProvider(Protocol):
    """
    Protocol for storage quota management.
    
    Per-tenant limits based on subscription plan.
    """
    
    async def get_quota(
        self,
        tenant_id: str,
    ) -> Dict[str, Any]:
        """Get quota limits for tenant."""
        ...
    
    async def check_quota(
        self,
        tenant_id: str,
        additional_bytes: int,
        additional_files: int = 1,
    ) -> bool:
        """Check if upload would exceed quota."""
        ...
    
    async def update_usage(
        self,
        tenant_id: str,
        bytes_delta: int,
        files_delta: int = 0,
    ) -> Dict[str, Any]:
        """Update usage stats after upload/delete."""
        ...
    
    async def get_usage(
        self,
        tenant_id: str,
    ) -> Dict[str, Any]:
        """Get current usage stats."""
        ...


class VirusScannerProvider(Protocol):
    """
    Protocol for virus scanning.
    
    Optional integration with ClamAV, VirusTotal, AWS S3 Antivirus.
    """
    
    async def scan_file(
        self,
        file_id: str,
        file_data: bytes,
        filename: str,
    ) -> Dict[str, Any]:
        """Scan file for viruses. Returns scan result."""
        ...
    
    async def get_scan_result(
        self,
        scan_id: str,
    ) -> Dict[str, Any]:
        """Get virus scan result by ID."""
        ...


class CDNProvider(Protocol):
    """
    Protocol for CDN integration.
    
    Optional for public files (Cloudflare, CloudFront).
    """
    
    async def generate_cdn_url(
        self,
        file_url: str,
        tenant_id: str,
    ) -> str:
        """Generate CDN URL for public file."""
        ...
    
    async def purge_cache(
        self,
        urls: List[str],
    ) -> bool:
        """Purge CDN cache for URLs."""
        ...
