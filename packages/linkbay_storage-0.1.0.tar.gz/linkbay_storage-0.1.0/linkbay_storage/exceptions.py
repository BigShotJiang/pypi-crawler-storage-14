"""Custom exceptions for storage operations."""


class StorageError(Exception):
    """Base exception for storage errors."""
    pass


class FileNotFoundError(StorageError):
    """File not found in storage."""
    
    def __init__(self, tenant_id: str, file_id: str):
        self.tenant_id = tenant_id
        self.file_id = file_id
        super().__init__(f"File {file_id} not found for tenant {tenant_id}")


class QuotaExceededError(StorageError):
    """Storage quota exceeded."""
    
    def __init__(self, tenant_id: str, quota_type: str, limit: float, current: float):
        self.tenant_id = tenant_id
        self.quota_type = quota_type
        self.limit = limit
        self.current = current
        super().__init__(
            f"Quota exceeded for tenant {tenant_id}: {quota_type} limit {limit}, current {current}"
        )


class PermissionDeniedError(StorageError):
    """User does not have permission to access file."""
    
    def __init__(self, tenant_id: str, file_id: str, user_id: str, action: str):
        self.tenant_id = tenant_id
        self.file_id = file_id
        self.user_id = user_id
        self.action = action
        super().__init__(
            f"User {user_id} denied {action} access to file {file_id} in tenant {tenant_id}"
        )


class VirusDetectedError(StorageError):
    """Virus detected in file."""
    
    def __init__(self, tenant_id: str, file_id: str, virus_name: str = None):
        self.tenant_id = tenant_id
        self.file_id = file_id
        self.virus_name = virus_name
        super().__init__(
            f"Virus detected in file {file_id} for tenant {tenant_id}: {virus_name or 'unknown'}"
        )


class InvalidFileTypeError(StorageError):
    """File type not allowed."""
    
    def __init__(self, mime_type: str):
        self.mime_type = mime_type
        super().__init__(f"File type not allowed: {mime_type}")


class FileTooLargeError(StorageError):
    """File exceeds size limit."""
    
    def __init__(self, size_bytes: int, max_bytes: int):
        self.size_bytes = size_bytes
        self.max_bytes = max_bytes
        super().__init__(
            f"File too large: {size_bytes} bytes exceeds limit of {max_bytes} bytes"
        )
