"""MinIO storage adapter (S3-compatible)."""

from typing import Dict, Any, List, Optional
from .s3_adapter import S3StorageProvider


class MinIOStorageProvider(S3StorageProvider):
    """
    MinIO storage provider (S3-compatible).
    
    Example:
        provider = MinIOStorageProvider(
            endpoint_url="http://localhost:9000",
            access_key="minioadmin",
            secret_key="minioadmin",
        )
    """
    
    def __init__(
        self,
        endpoint_url: str,
        access_key: str,
        secret_key: str,
        region_name: str = "us-east-1",
    ):
        super().__init__(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region_name,
            endpoint_url=endpoint_url,
        )
        self.endpoint_url = endpoint_url
    
    async def put_object(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """Upload file to MinIO."""
        await super().put_object(bucket, key, data, content_type, metadata)
        return f"{self.endpoint_url}/{bucket}/{key}"
