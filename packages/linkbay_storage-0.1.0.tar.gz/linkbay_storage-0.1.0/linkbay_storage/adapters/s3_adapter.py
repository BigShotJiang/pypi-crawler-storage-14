"""AWS S3 storage adapter."""

from typing import Dict, Any, List, Optional
import boto3
from botocore.exceptions import ClientError


class S3StorageProvider:
    """
    AWS S3 storage provider implementation.
    
    Example:
        provider = S3StorageProvider(
            aws_access_key_id="AKIA...",
            aws_secret_access_key="...",
            region_name="us-east-1",
        )
    """
    
    def __init__(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        region_name: str = "us-east-1",
        endpoint_url: Optional[str] = None,
    ):
        self.s3_client = boto3.client(
            "s3",
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            region_name=region_name,
            endpoint_url=endpoint_url,
        )
        self.region_name = region_name
    
    async def put_object(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """Upload file to S3."""
        try:
            self.s3_client.put_object(
                Bucket=bucket,
                Key=key,
                Body=data,
                ContentType=content_type,
                Metadata=metadata or {},
            )
            
            return f"https://{bucket}.s3.{self.region_name}.amazonaws.com/{key}"
        except ClientError as e:
            raise Exception(f"S3 upload failed: {e}")
    
    async def get_object(self, bucket: str, key: str) -> bytes:
        """Download file from S3."""
        try:
            response = self.s3_client.get_object(Bucket=bucket, Key=key)
            return response["Body"].read()
        except ClientError as e:
            raise Exception(f"S3 download failed: {e}")
    
    async def delete_object(self, bucket: str, key: str) -> bool:
        """Delete file from S3."""
        try:
            self.s3_client.delete_object(Bucket=bucket, Key=key)
            return True
        except ClientError as e:
            raise Exception(f"S3 delete failed: {e}")
    
    async def list_objects(
        self,
        bucket: str,
        prefix: str = "",
    ) -> List[Dict[str, Any]]:
        """List objects in bucket."""
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=bucket, Prefix=prefix
            )
            
            return [
                {
                    "key": obj["Key"],
                    "size": obj["Size"],
                    "last_modified": obj["LastModified"],
                }
                for obj in response.get("Contents", [])
            ]
        except ClientError as e:
            raise Exception(f"S3 list failed: {e}")
    
    async def copy_object(
        self,
        source_bucket: str,
        source_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> bool:
        """Copy object to new location."""
        try:
            self.s3_client.copy_object(
                CopySource={"Bucket": source_bucket, "Key": source_key},
                Bucket=dest_bucket,
                Key=dest_key,
            )
            return True
        except ClientError as e:
            raise Exception(f"S3 copy failed: {e}")
    
    async def move_object(
        self,
        source_bucket: str,
        source_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> bool:
        """Move object to new location."""
        await self.copy_object(source_bucket, source_key, dest_bucket, dest_key)
        await self.delete_object(source_bucket, source_key)
        return True
    
    async def generate_presigned_upload_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
        content_type: str,
    ) -> Dict[str, Any]:
        """Generate presigned URL for upload."""
        try:
            url = self.s3_client.generate_presigned_url(
                "put_object",
                Params={
                    "Bucket": bucket,
                    "Key": key,
                    "ContentType": content_type,
                },
                ExpiresIn=expires_in,
            )
            
            return {"url": url, "fields": {}}
        except ClientError as e:
            raise Exception(f"Presigned URL generation failed: {e}")
    
    async def generate_presigned_download_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
    ) -> str:
        """Generate presigned URL for download."""
        try:
            return self.s3_client.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket, "Key": key},
                ExpiresIn=expires_in,
            )
        except ClientError as e:
            raise Exception(f"Presigned URL generation failed: {e}")
    
    async def set_object_storage_class(
        self,
        bucket: str,
        key: str,
        storage_class: str,
    ) -> bool:
        """Change storage tier."""
        try:
            self.s3_client.copy_object(
                CopySource={"Bucket": bucket, "Key": key},
                Bucket=bucket,
                Key=key,
                StorageClass=storage_class.upper(),
                MetadataDirective="COPY",
            )
            return True
        except ClientError as e:
            raise Exception(f"Storage class change failed: {e}")
