"""Local filesystem storage adapter."""

from typing import Dict, Any, List, Optional
import os
import shutil
from pathlib import Path
from datetime import datetime, timedelta


class LocalStorageProvider:
    """
    Local filesystem storage provider.
    
    For development/testing only.
    
    Example:
        provider = LocalStorageProvider(base_path="/var/storage")
    """
    
    def __init__(self, base_path: str = "/tmp/linkbay-storage"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
    
    def _get_file_path(self, bucket: str, key: str) -> Path:
        """Get full file path."""
        bucket_path = self.base_path / bucket
        bucket_path.mkdir(parents=True, exist_ok=True)
        return bucket_path / key
    
    async def put_object(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """Upload file to local filesystem."""
        file_path = self._get_file_path(bucket, key)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, "wb") as f:
            f.write(data)
        
        return f"file://{file_path}"
    
    async def get_object(self, bucket: str, key: str) -> bytes:
        """Download file from local filesystem."""
        file_path = self._get_file_path(bucket, key)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        with open(file_path, "rb") as f:
            return f.read()
    
    async def delete_object(self, bucket: str, key: str) -> bool:
        """Delete file from local filesystem."""
        file_path = self._get_file_path(bucket, key)
        
        if file_path.exists():
            file_path.unlink()
            return True
        
        return False
    
    async def list_objects(
        self,
        bucket: str,
        prefix: str = "",
    ) -> List[Dict[str, Any]]:
        """List objects in bucket."""
        bucket_path = self.base_path / bucket
        
        if not bucket_path.exists():
            return []
        
        objects = []
        for file_path in bucket_path.rglob("*"):
            if file_path.is_file():
                rel_path = file_path.relative_to(bucket_path)
                if str(rel_path).startswith(prefix):
                    stat = file_path.stat()
                    objects.append({
                        "key": str(rel_path),
                        "size": stat.st_size,
                        "last_modified": datetime.fromtimestamp(stat.st_mtime),
                    })
        
        return objects
    
    async def copy_object(
        self,
        source_bucket: str,
        source_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> bool:
        """Copy object to new location."""
        source_path = self._get_file_path(source_bucket, source_key)
        dest_path = self._get_file_path(dest_bucket, dest_key)
        
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, dest_path)
        
        return True
    
    async def move_object(
        self,
        source_bucket: str,
        source_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> bool:
        """Move object to new location."""
        source_path = self._get_file_path(source_bucket, source_key)
        dest_path = self._get_file_path(dest_bucket, dest_key)
        
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source_path), str(dest_path))
        
        return True
    
    async def generate_presigned_upload_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
        content_type: str,
    ) -> Dict[str, Any]:
        """Generate presigned URL for upload (not supported)."""
        file_path = self._get_file_path(bucket, key)
        return {
            "url": f"file://{file_path}",
            "fields": {},
        }
    
    async def generate_presigned_download_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
    ) -> str:
        """Generate presigned URL for download (not supported)."""
        file_path = self._get_file_path(bucket, key)
        return f"file://{file_path}"
    
    async def set_object_storage_class(
        self,
        bucket: str,
        key: str,
        storage_class: str,
    ) -> bool:
        """Change storage tier (not supported for local)."""
        return True
