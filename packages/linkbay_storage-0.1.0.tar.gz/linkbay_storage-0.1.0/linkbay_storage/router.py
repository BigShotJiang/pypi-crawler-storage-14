"""FastAPI router for storage API."""

from typing import Optional
from fastapi import APIRouter, Depends, File, UploadFile, HTTPException, status, Query
from fastapi.responses import StreamingResponse, RedirectResponse

from .services import FileManager, PermissionsService, QuotaService
from .schemas import (
    FileResponse,
    FileListResponse,
    FileFilter,
    FileUpdate,
    UploadRequest,
    PresignedUploadRequest,
    PresignedUploadResponse,
    PresignedDownloadResponse,
    UsageStats,
    MoveFileRequest,
    CopyFileRequest,
)
from .exceptions import (
    FileNotFoundError,
    QuotaExceededError,
    PermissionDeniedError,
    VirusDetectedError,
)


def create_storage_router(
    get_file_manager: callable,
    get_permissions_service: callable,
    get_quota_service: callable,
    prefix: str = "/storage",
) -> APIRouter:
    """
    Create FastAPI router for storage API.
    
    Example:
        def get_file_manager() -> FileManager:
            return FileManager(
                file_storage=get_file_storage(),
                storage_provider=get_storage_provider(),
                quota_provider=get_quota_provider(),
            )
        
        router = create_storage_router(
            get_file_manager=get_file_manager,
            get_permissions_service=get_permissions_service,
            get_quota_service=get_quota_service,
            prefix="/api/v1/storage",
        )
        
        app.include_router(router)
    """
    router = APIRouter(prefix=prefix, tags=["storage"])
    
    @router.post(
        "/{tenant_id}/upload",
        response_model=FileResponse,
        status_code=status.HTTP_201_CREATED,
    )
    async def upload_file(
        tenant_id: str,
        file: UploadFile = File(...),
        user_id: str = Query(...),
        visibility: str = Query("private"),
        description: Optional[str] = Query(None),
        check_virus: bool = Query(True),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Upload file.
        
        Requires: storage:write permission
        """
        try:
            file_data = await file.read()
            
            from .schemas import FileMetadata
            from .constants import FileVisibility
            
            uploaded = await manager.upload_file(
                tenant_id=tenant_id,
                user_id=user_id,
                file_data=file_data,
                request=UploadRequest(
                    filename=file.filename or "untitled",
                    mime_type=file.content_type or "application/octet-stream",
                    visibility=FileVisibility(visibility),
                    metadata=FileMetadata(),
                    description=description,
                    check_virus=check_virus,
                ),
            )
            
            return FileResponse(file=uploaded)
        except QuotaExceededError as e:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=str(e),
            )
    
    @router.post(
        "/{tenant_id}/presigned-upload",
        response_model=PresignedUploadResponse,
    )
    async def generate_presigned_upload(
        tenant_id: str,
        request: PresignedUploadRequest,
        user_id: str = Query(...),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Generate presigned upload URL for client-side upload.
        
        Requires: storage:write permission
        """
        try:
            return await manager.generate_presigned_upload_url(
                tenant_id, user_id, request
            )
        except QuotaExceededError as e:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=str(e),
            )
    
    @router.get(
        "/{tenant_id}/files",
        response_model=FileListResponse,
    )
    async def list_files(
        tenant_id: str,
        mime_type: Optional[str] = Query(None),
        visibility: Optional[str] = Query(None),
        uploaded_by: Optional[str] = Query(None),
        search_query: Optional[str] = Query(None),
        skip: int = Query(0),
        limit: int = Query(100),
        user_id: Optional[str] = Query(None),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        List files with filters.
        
        Requires: storage:read permission
        """
        from .constants import FileVisibility
        
        filters = FileFilter(
            mime_type=mime_type,
            visibility=FileVisibility(visibility) if visibility else None,
            uploaded_by=uploaded_by,
            search_query=search_query,
        )
        
        return await manager.list_files(
            tenant_id, filters, skip, limit, user_id
        )
    
    @router.get(
        "/{tenant_id}/files/{file_id}",
        response_model=FileResponse,
    )
    async def get_file(
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = Query(None),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Get file metadata.
        
        Requires: storage:read permission
        """
        try:
            file = await manager.get_file(tenant_id, file_id, user_id)
            return FileResponse(file=file)
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except PermissionDeniedError as e:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=str(e),
            )
    
    @router.get(
        "/{tenant_id}/files/{file_id}/download",
    )
    async def download_file(
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = Query(None),
        redirect: bool = Query(False),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Download file.
        
        If redirect=True, returns presigned URL (redirect).
        Otherwise, proxies file through server.
        
        Requires: storage:read permission
        """
        try:
            if redirect:
                # Generate presigned URL and redirect
                presigned = await manager.generate_presigned_download_url(
                    tenant_id, file_id, user_id
                )
                return RedirectResponse(url=presigned.download_url)
            else:
                # Proxy download through server
                file = await manager.get_file(tenant_id, file_id, user_id)
                file_data = await manager.download_file(tenant_id, file_id, user_id)
                
                return StreamingResponse(
                    iter([file_data]),
                    media_type=file.mime_type,
                    headers={
                        "Content-Disposition": f"attachment; filename={file.filename}"
                    },
                )
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except VirusDetectedError as e:
            raise HTTPException(
                status_code=status.HTTP_451_UNAVAILABLE_FOR_LEGAL_REASONS,
                detail=str(e),
            )
        except PermissionDeniedError as e:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=str(e),
            )
    
    @router.get(
        "/{tenant_id}/files/{file_id}/download-url",
        response_model=PresignedDownloadResponse,
    )
    async def get_download_url(
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = Query(None),
        expires_in: int = Query(300),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Generate presigned download URL.
        
        Requires: storage:read permission
        """
        try:
            return await manager.generate_presigned_download_url(
                tenant_id, file_id, user_id, expires_in
            )
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    @router.put(
        "/{tenant_id}/files/{file_id}",
        response_model=FileResponse,
    )
    async def update_file(
        tenant_id: str,
        file_id: str,
        updates: FileUpdate,
        user_id: Optional[str] = Query(None),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Update file metadata.
        
        Requires: storage:write permission
        """
        try:
            updated = await manager.update_file(
                tenant_id, file_id, updates, user_id
            )
            return FileResponse(file=updated)
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except PermissionDeniedError as e:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=str(e),
            )
    
    @router.delete(
        "/{tenant_id}/files/{file_id}",
        status_code=status.HTTP_204_NO_CONTENT,
    )
    async def delete_file(
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = Query(None),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Delete file.
        
        Requires: storage:delete permission
        """
        try:
            await manager.delete_file(tenant_id, file_id, user_id)
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except PermissionDeniedError as e:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=str(e),
            )
    
    @router.post(
        "/{tenant_id}/files/{file_id}/copy",
        response_model=FileResponse,
    )
    async def copy_file(
        tenant_id: str,
        file_id: str,
        request: CopyFileRequest,
        user_id: Optional[str] = Query(None),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Copy file to new location.
        
        Requires: storage:write permission
        """
        try:
            copied = await manager.copy_file(
                tenant_id, file_id, request.dest_bucket, request.dest_path, user_id
            )
            return FileResponse(file=copied)
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    @router.post(
        "/{tenant_id}/files/{file_id}/move",
        response_model=FileResponse,
    )
    async def move_file(
        tenant_id: str,
        file_id: str,
        request: MoveFileRequest,
        user_id: Optional[str] = Query(None),
        manager: FileManager = Depends(get_file_manager),
    ):
        """
        Move file to new location.
        
        Requires: storage:write permission
        """
        try:
            moved = await manager.move_file(
                tenant_id, file_id, request.dest_bucket, request.dest_path, user_id
            )
            return FileResponse(file=moved)
        except FileNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    @router.get(
        "/{tenant_id}/usage",
        response_model=UsageStats,
    )
    async def get_usage_stats(
        tenant_id: str,
        quota_service: QuotaService = Depends(get_quota_service),
    ):
        """
        Get storage usage stats.
        
        Requires: storage:read permission
        """
        return await quota_service.get_usage(tenant_id)
    
    return router
