"""Core file management service."""

from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
import uuid
import mimetypes

from ..protocols import (
    FileStorage,
    StorageProvider,
    FilePermissionsProvider,
    QuotaProvider,
    VirusScannerProvider,
)
from ..schemas import (
    FileDTO,
    FileCreate,
    FileUpdate,
    FileFilter,
    FileListResponse,
    UploadRequest,
    PresignedUploadRequest,
    PresignedUploadResponse,
    PresignedDownloadResponse,
    VirusScanResult,
)
from ..exceptions import (
    FileNotFoundError,
    QuotaExceededError,
    PermissionDeniedError,
    VirusDetectedError,
    InvalidFileTypeError,
    FileTooLargeError,
)
from ..constants import (
    FileVisibility,
    VirusScanStatus,
    MAX_FILE_SIZE_BYTES,
    DEFAULT_UPLOAD_URL_EXPIRES,
    DEFAULT_DOWNLOAD_URL_EXPIRES,
)


class FileManager:
    """
    Core file management service.
    
    Orchestrates file uploads, downloads, metadata, permissions, quotas.
    """
    
    def __init__(
        self,
        file_storage: FileStorage,
        storage_provider: StorageProvider,
        quota_provider: QuotaProvider,
        permissions_provider: Optional[FilePermissionsProvider] = None,
        virus_scanner: Optional[VirusScannerProvider] = None,
    ):
        self.file_storage = file_storage
        self.storage_provider = storage_provider
        self.quota_provider = quota_provider
        self.permissions_provider = permissions_provider
        self.virus_scanner = virus_scanner
    
    async def upload_file(
        self,
        tenant_id: str,
        user_id: str,
        file_data: bytes,
        request: UploadRequest,
    ) -> FileDTO:
        """
        Upload file with quota check and optional virus scan.
        
        Example:
            file = await manager.upload_file(
                tenant_id="tenant_123",
                user_id="user_456",
                file_data=pdf_bytes,
                request=UploadRequest(
                    filename="invoice_2024.pdf",
                    mime_type="application/pdf",
                    metadata=FileMetadata(
                        tags={"document_type": "invoice", "invoice_id": "123"},
                    ),
                ),
            )
        """
        # Check file size
        size_bytes = len(file_data)
        quota = await self.quota_provider.get_quota(tenant_id)
        
        if size_bytes > quota.get("max_file_size_bytes", MAX_FILE_SIZE_BYTES):
            raise FileTooLargeError(size_bytes, quota["max_file_size_bytes"])
        
        # Check quota
        can_upload = await self.quota_provider.check_quota(
            tenant_id, size_bytes, additional_files=1
        )
        if not can_upload:
            usage = await self.quota_provider.get_usage(tenant_id)
            raise QuotaExceededError(
                tenant_id,
                "storage",
                usage["quota_info"]["max_storage_bytes"],
                usage["used_storage_bytes"],
            )
        
        # Check MIME type
        allowed_types = quota.get("allowed_mime_types")
        if allowed_types and request.mime_type not in allowed_types:
            raise InvalidFileTypeError(request.mime_type)
        
        # Generate unique file ID and storage key
        file_id = str(uuid.uuid4())
        storage_key = f"{tenant_id}/{user_id}/{file_id}/{request.filename}"
        bucket = f"tenant-{tenant_id}"
        
        # Upload to storage
        storage_url = await self.storage_provider.put_object(
            bucket=bucket,
            key=storage_key,
            data=file_data,
            content_type=request.mime_type,
            metadata={
                "tenant_id": tenant_id,
                "user_id": user_id,
                "file_id": file_id,
            },
        )
        
        # Create file metadata
        file_create = FileCreate(
            filename=request.filename,
            original_filename=request.filename,
            mime_type=request.mime_type,
            size_bytes=size_bytes,
            bucket=bucket,
            storage_key=storage_key,
            uploaded_by=user_id,
            visibility=request.visibility,
            metadata=request.metadata,
            description=request.description,
        )
        
        file_data_dict = {
            **file_create.model_dump(),
            "id": file_id,
            "tenant_id": tenant_id,
            "uploaded_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "virus_scan_status": VirusScanStatus.PENDING if request.check_virus else VirusScanStatus.SKIPPED,
            "download_count": 0,
        }
        
        created = await self.file_storage.create_file(tenant_id, file_data_dict)
        
        # Update quota
        await self.quota_provider.update_usage(tenant_id, size_bytes, files_delta=1)
        
        # Trigger virus scan if enabled
        if request.check_virus and self.virus_scanner:
            await self._scan_file_async(file_id, file_data, request.filename)
        
        return FileDTO(**created)
    
    async def get_file(
        self,
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = None,
    ) -> FileDTO:
        """Get file metadata."""
        file = await self.file_storage.get_file(tenant_id, file_id)
        
        if not file:
            raise FileNotFoundError(tenant_id, file_id)
        
        # Check permissions
        if user_id and self.permissions_provider:
            has_access = await self.permissions_provider.check_access(
                tenant_id, file_id, user_id, "read"
            )
            if not has_access:
                raise PermissionDeniedError(tenant_id, file_id, user_id, "read")
        
        return FileDTO(**file)
    
    async def download_file(
        self,
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = None,
    ) -> bytes:
        """Download file bytes."""
        file = await self.get_file(tenant_id, file_id, user_id)
        
        # Check virus scan
        if file.virus_scan_status == VirusScanStatus.INFECTED:
            raise VirusDetectedError(tenant_id, file_id)
        
        # Download from storage
        file_data = await self.storage_provider.get_object(
            bucket=file.bucket,
            key=file.storage_key,
        )
        
        # Update download count
        await self.file_storage.update_file(
            tenant_id,
            file_id,
            {
                "download_count": file.download_count + 1,
                "last_accessed_at": datetime.utcnow(),
            },
        )
        
        return file_data
    
    async def delete_file(
        self,
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = None,
    ) -> bool:
        """Delete file and metadata."""
        file = await self.get_file(tenant_id, file_id, user_id)
        
        # Check permissions
        if user_id and self.permissions_provider:
            has_access = await self.permissions_provider.check_access(
                tenant_id, file_id, user_id, "delete"
            )
            if not has_access:
                raise PermissionDeniedError(tenant_id, file_id, user_id, "delete")
        
        # Delete from storage
        await self.storage_provider.delete_object(
            bucket=file.bucket,
            key=file.storage_key,
        )
        
        # Delete metadata
        await self.file_storage.delete_file(tenant_id, file_id)
        
        # Update quota
        await self.quota_provider.update_usage(
            tenant_id, -file.size_bytes, files_delta=-1
        )
        
        return True
    
    async def list_files(
        self,
        tenant_id: str,
        filters: FileFilter,
        skip: int = 0,
        limit: int = 100,
        user_id: Optional[str] = None,
    ) -> FileListResponse:
        """
        List files with filters.
        
        Example:
            files = await manager.list_files(
                tenant_id="tenant_123",
                filters=FileFilter(
                    tags={"document_type": "invoice"},
                    start_date=datetime(2024, 1, 1),
                    end_date=datetime(2024, 12, 31),
                ),
                skip=0,
                limit=50,
            )
        """
        filter_dict = filters.model_dump(exclude_none=True)
        
        files = await self.file_storage.list_files(
            tenant_id, filter_dict, skip, limit
        )
        
        total = await self.file_storage.count_files(tenant_id, filter_dict)
        
        return FileListResponse(
            files=[FileDTO(**f) for f in files],
            total=total,
            skip=skip,
            limit=limit,
        )
    
    async def update_file(
        self,
        tenant_id: str,
        file_id: str,
        updates: FileUpdate,
        user_id: Optional[str] = None,
    ) -> FileDTO:
        """Update file metadata."""
        file = await self.get_file(tenant_id, file_id, user_id)
        
        # Check permissions
        if user_id and self.permissions_provider:
            has_access = await self.permissions_provider.check_access(
                tenant_id, file_id, user_id, "write"
            )
            if not has_access:
                raise PermissionDeniedError(tenant_id, file_id, user_id, "write")
        
        update_dict = updates.model_dump(exclude_none=True)
        update_dict["updated_at"] = datetime.utcnow()
        
        updated = await self.file_storage.update_file(
            tenant_id, file_id, update_dict
        )
        
        return FileDTO(**updated)
    
    async def generate_presigned_upload_url(
        self,
        tenant_id: str,
        user_id: str,
        request: PresignedUploadRequest,
    ) -> PresignedUploadResponse:
        """
        Generate presigned URL for direct client upload.
        
        Example:
            response = await manager.generate_presigned_upload_url(
                tenant_id="tenant_123",
                user_id="user_456",
                request=PresignedUploadRequest(
                    filename="invoice.pdf",
                    mime_type="application/pdf",
                    size_bytes=1024000,
                ),
            )
            
            # Client uploads directly to response.upload_url
        """
        # Check quota
        can_upload = await self.quota_provider.check_quota(
            tenant_id, request.size_bytes, additional_files=1
        )
        if not can_upload:
            usage = await self.quota_provider.get_usage(tenant_id)
            raise QuotaExceededError(
                tenant_id,
                "storage",
                usage["quota_info"]["max_storage_bytes"],
                usage["used_storage_bytes"],
            )
        
        # Generate file ID and storage key
        file_id = str(uuid.uuid4())
        storage_key = f"{tenant_id}/{user_id}/{file_id}/{request.filename}"
        bucket = f"tenant-{tenant_id}"
        
        # Get presigned URL from provider
        presigned_data = await self.storage_provider.generate_presigned_upload_url(
            bucket=bucket,
            key=storage_key,
            expires_in=request.expires_in,
            content_type=request.mime_type,
        )
        
        # Create pending file metadata
        file_create = FileCreate(
            filename=request.filename,
            original_filename=request.filename,
            mime_type=request.mime_type,
            size_bytes=request.size_bytes,
            bucket=bucket,
            storage_key=storage_key,
            uploaded_by=user_id,
            visibility=request.visibility,
            metadata=request.metadata,
            description=request.description,
        )
        
        file_data_dict = {
            **file_create.model_dump(),
            "id": file_id,
            "tenant_id": tenant_id,
            "uploaded_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "virus_scan_status": VirusScanStatus.PENDING,
            "download_count": 0,
        }
        
        await self.file_storage.create_file(tenant_id, file_data_dict)
        
        return PresignedUploadResponse(
            upload_url=presigned_data["url"],
            file_id=file_id,
            fields=presigned_data.get("fields", {}),
            expires_at=datetime.utcnow() + timedelta(seconds=request.expires_in),
        )
    
    async def generate_presigned_download_url(
        self,
        tenant_id: str,
        file_id: str,
        user_id: Optional[str] = None,
        expires_in: int = DEFAULT_DOWNLOAD_URL_EXPIRES,
    ) -> PresignedDownloadResponse:
        """Generate presigned URL for download."""
        file = await self.get_file(tenant_id, file_id, user_id)
        
        # Check virus scan
        if file.virus_scan_status == VirusScanStatus.INFECTED:
            raise VirusDetectedError(tenant_id, file_id)
        
        # Generate presigned URL
        download_url = await self.storage_provider.generate_presigned_download_url(
            bucket=file.bucket,
            key=file.storage_key,
            expires_in=expires_in,
        )
        
        return PresignedDownloadResponse(
            download_url=download_url,
            expires_at=datetime.utcnow() + timedelta(seconds=expires_in),
        )
    
    async def copy_file(
        self,
        tenant_id: str,
        file_id: str,
        dest_bucket: str,
        dest_path: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> FileDTO:
        """Copy file to new location."""
        file = await self.get_file(tenant_id, file_id, user_id)
        
        new_file_id = str(uuid.uuid4())
        new_key = dest_path or f"{tenant_id}/{user_id}/{new_file_id}/{file.filename}"
        
        # Copy in storage
        await self.storage_provider.copy_object(
            source_bucket=file.bucket,
            source_key=file.storage_key,
            dest_bucket=dest_bucket,
            dest_key=new_key,
        )
        
        # Create new metadata
        file_data_dict = {
            **file.model_dump(exclude={"id", "uploaded_at", "updated_at"}),
            "id": new_file_id,
            "bucket": dest_bucket,
            "storage_key": new_key,
            "uploaded_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
        
        created = await self.file_storage.create_file(tenant_id, file_data_dict)
        
        # Update quota
        await self.quota_provider.update_usage(
            tenant_id, file.size_bytes, files_delta=1
        )
        
        return FileDTO(**created)
    
    async def move_file(
        self,
        tenant_id: str,
        file_id: str,
        dest_bucket: str,
        dest_path: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> FileDTO:
        """Move file to new location."""
        file = await self.get_file(tenant_id, file_id, user_id)
        
        new_key = dest_path or f"{tenant_id}/{user_id}/{file_id}/{file.filename}"
        
        # Move in storage
        await self.storage_provider.move_object(
            source_bucket=file.bucket,
            source_key=file.storage_key,
            dest_bucket=dest_bucket,
            dest_key=new_key,
        )
        
        # Update metadata
        updated = await self.file_storage.update_file(
            tenant_id,
            file_id,
            {
                "bucket": dest_bucket,
                "storage_key": new_key,
                "updated_at": datetime.utcnow(),
            },
        )
        
        return FileDTO(**updated)
    
    async def _scan_file_async(
        self,
        file_id: str,
        file_data: bytes,
        filename: str,
    ):
        """Trigger async virus scan (implement as background task)."""
        if not self.virus_scanner:
            return
        
        # In production, submit to background worker (Celery, RQ, etc.)
        # For now, just mark as pending
        pass
