"""Quota management service."""

from typing import Dict, Any
from ..protocols import QuotaProvider
from ..schemas import QuotaInfo, UsageStats
from ..exceptions import QuotaExceededError


class QuotaService:
    """
    Storage quota management service.
    
    Enforces per-tenant limits based on subscription.
    """
    
    def __init__(self, provider: QuotaProvider):
        self.provider = provider
    
    async def get_quota(self, tenant_id: str) -> QuotaInfo:
        """
        Get quota limits for tenant.
        
        Example:
            quota = await service.get_quota("tenant_123")
            print(f"Max storage: {quota.max_storage_bytes / (1024**3)} GB")
        """
        quota_data = await self.provider.get_quota(tenant_id)
        return QuotaInfo(**quota_data)
    
    async def get_usage(self, tenant_id: str) -> UsageStats:
        """
        Get current usage stats.
        
        Example:
            usage = await service.get_usage("tenant_123")
            print(f"Used: {usage.used_storage_gb:.2f} GB ({usage.usage_percent:.1f}%)")
        """
        usage_data = await self.provider.get_usage(tenant_id)
        quota_data = await self.provider.get_quota(tenant_id)
        
        used_gb = usage_data["used_storage_bytes"] / (1024**3)
        max_gb = quota_data["max_storage_bytes"] / (1024**3)
        usage_percent = (usage_data["used_storage_bytes"] / quota_data["max_storage_bytes"]) * 100
        
        return UsageStats(
            tenant_id=tenant_id,
            used_storage_bytes=usage_data["used_storage_bytes"],
            used_storage_gb=used_gb,
            total_files=usage_data["total_files"],
            quota_info=QuotaInfo(**quota_data),
            usage_percent=usage_percent,
        )
    
    async def check_quota(
        self,
        tenant_id: str,
        additional_bytes: int,
        additional_files: int = 1,
    ) -> bool:
        """Check if upload would exceed quota."""
        return await self.provider.check_quota(
            tenant_id, additional_bytes, additional_files
        )
    
    async def enforce_quota(
        self,
        tenant_id: str,
        additional_bytes: int,
        additional_files: int = 1,
    ):
        """
        Enforce quota or raise exception.
        
        Example:
            await service.enforce_quota(
                tenant_id="tenant_123",
                additional_bytes=1024000,  # 1 MB
            )
        """
        can_upload = await self.check_quota(
            tenant_id, additional_bytes, additional_files
        )
        
        if not can_upload:
            usage = await self.get_usage(tenant_id)
            raise QuotaExceededError(
                tenant_id,
                "storage",
                usage.quota_info.max_storage_bytes,
                usage.used_storage_bytes,
            )
    
    async def update_usage(
        self,
        tenant_id: str,
        bytes_delta: int,
        files_delta: int = 0,
    ) -> UsageStats:
        """Update usage after upload/delete."""
        usage_data = await self.provider.update_usage(
            tenant_id, bytes_delta, files_delta
        )
        
        return await self.get_usage(tenant_id)
