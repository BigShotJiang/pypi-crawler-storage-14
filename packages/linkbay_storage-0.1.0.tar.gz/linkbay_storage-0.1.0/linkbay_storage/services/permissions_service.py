"""File permissions service."""

from typing import List, Dict, Any, Optional
from ..protocols import FilePermissionsProvider
from ..exceptions import PermissionDeniedError


class PermissionsService:
    """
    File access control service.
    
    Integrates with linkbay-roles for RBAC.
    """
    
    def __init__(self, provider: Optional[FilePermissionsProvider] = None):
        self.provider = provider
    
    async def check_access(
        self,
        tenant_id: str,
        file_id: str,
        user_id: str,
        action: str,
    ) -> bool:
        """
        Check if user has permission.
        
        Example:
            can_delete = await service.check_access(
                tenant_id="tenant_123",
                file_id="file_456",
                user_id="user_789",
                action="delete",
            )
        """
        if not self.provider:
            return True  # No permissions enforcement
        
        return await self.provider.check_access(
            tenant_id, file_id, user_id, action
        )
    
    async def grant_access(
        self,
        tenant_id: str,
        file_id: str,
        user_id: str,
        permissions: List[str],
    ) -> bool:
        """Grant user permissions on file."""
        if not self.provider:
            return True
        
        return await self.provider.grant_access(
            tenant_id, file_id, user_id, permissions
        )
    
    async def revoke_access(
        self,
        tenant_id: str,
        file_id: str,
        user_id: str,
    ) -> bool:
        """Revoke user permissions."""
        if not self.provider:
            return True
        
        return await self.provider.revoke_access(tenant_id, file_id, user_id)
    
    async def list_permissions(
        self,
        tenant_id: str,
        file_id: str,
    ) -> List[Dict[str, Any]]:
        """List all permissions for file."""
        if not self.provider:
            return []
        
        return await self.provider.list_file_permissions(tenant_id, file_id)
    
    async def require_permission(
        self,
        tenant_id: str,
        file_id: str,
        user_id: str,
        action: str,
    ):
        """Require permission or raise exception."""
        has_access = await self.check_access(tenant_id, file_id, user_id, action)
        
        if not has_access:
            raise PermissionDeniedError(tenant_id, file_id, user_id, action)
