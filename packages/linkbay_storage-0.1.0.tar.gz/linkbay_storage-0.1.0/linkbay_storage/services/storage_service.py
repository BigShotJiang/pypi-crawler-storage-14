"""Storage provider service wrapper."""

from typing import Dict, Any, Optional
from ..protocols import StorageProvider


class StorageService:
    """
    Wrapper for storage provider operations.
    
    Provides high-level storage operations.
    """
    
    def __init__(self, provider: StorageProvider):
        self.provider = provider
    
    async def upload(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """Upload file to storage."""
        return await self.provider.put_object(
            bucket, key, data, content_type, metadata
        )
    
    async def download(self, bucket: str, key: str) -> bytes:
        """Download file from storage."""
        return await self.provider.get_object(bucket, key)
    
    async def delete(self, bucket: str, key: str) -> bool:
        """Delete file from storage."""
        return await self.provider.delete_object(bucket, key)
    
    async def generate_upload_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
        content_type: str,
    ) -> Dict[str, Any]:
        """Generate presigned upload URL."""
        return await self.provider.generate_presigned_upload_url(
            bucket, key, expires_in, content_type
        )
    
    async def generate_download_url(
        self,
        bucket: str,
        key: str,
        expires_in: int,
    ) -> str:
        """Generate presigned download URL."""
        return await self.provider.generate_presigned_download_url(
            bucket, key, expires_in
        )
