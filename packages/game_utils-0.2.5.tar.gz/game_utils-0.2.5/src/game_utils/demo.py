#!/usr/bin/env python3
from typing import Any, Literal

import pygame.display as display
import pygame.draw as draw
import pygame.sprite as sprite
from pygame import Rect, Surface, Vector2

import game_utils.vector_utils as vector_utils

from .controller import DefaultKeyboardController
from .game import Game, SpriteGame
from .physics import PhysicsBody
from .sprites import GameSprite, PhysicsSprite, PlayerSprite

COURT_BOUNDARIES = [
    lambda x, y: Rect(x / 2, 0, y, 0),
    lambda x, y: Rect(x, x / 2, y, 0),
]


class BouncyBallPlayer(PlayerSprite):
    def __init__(
        self,
        image: Surface,
        position: Vector2,
        controller: DefaultKeyboardController,
        color: str = "indigo",
        physics_body: PhysicsBody = PhysicsBody(),
        boundaries: Rect | None = None,
        id: int = 0,
        facing: Literal[1, -1] = 1,
    ):
        super().__init__(image, position, controller, physics_body, boundaries, id)
        self.facing = facing
        self.collided = False
        self.color = color

    def update(self, *args: Any, **kwargs: Any):
        dt = args[0]

        # sync position and physics body
        if not self.controller.stop():
            accel = self.controller.direction()
            self.physics_body.force(accel, dt)
        else:
            self.physics_body.velociy = Vector2()

        # bound positions
        self._update_pos(
            self.physics_body.position,
            xbounds=self._bounds_x,
            ybounds=self._bounds_y,
        )

    def _bounds_x(self):
        self.physics_body.velociy = vector_utils.apply(
            self.physics_body.velociy,
            lambda v: Vector2(0, v.y),
        )

    def _bounds_y(self):
        self.physics_body.velociy = vector_utils.apply(
            self.physics_body.velociy,
            lambda v: Vector2(v.x, 0),
        )

    def _apply_controller_force(self, force: Vector2, dt: float):
        force /= dt if dt > 0 else 1
        self.physics_body.force(force, dt)


class BouncyBallPuck(PhysicsSprite):
    def __init__(
        self,
        image: Surface,
        position: Vector2,
        physics_body: PhysicsBody,
        color: str = "blue",
        boundaries: Rect | None = None,
        id: int = 0,
        speed: int = 50,
    ):
        super().__init__(image, position, physics_body, boundaries, id)
        self.color = color
        self.speed = speed
        self.collided = False
        self.physics_body.velociy = vector_utils.get_random_vector(speed)
        self.start_position = Vector2.copy(position)

    def reset(self, **kwargs: Vector2):
        pos = kwargs.get("position")
        new_position = pos if pos is not None else Vector2.copy(self.start_position)
        self.physics_body.velociy = vector_utils.get_random_vector(self.speed)
        self.position = new_position
        self.physics_body.position = new_position
        self.collided = False

    def update(self, *args: Any, **kwargs: Any):
        reset = kwargs.get("reset")
        if reset is not None:
            self.reset(position=reset)
        collided = kwargs.get("collided")
        if collided is not None:
            self.collided = True

        # sync position and physics body
        # bound positions
        self._update_pos(
            self.physics_body.position,
            xbounds=self.__bounds_x,
            ybounds=self.__bounds_y,
        )

    def __bounds_x(self):
        self.physics_body.velociy = (
            vector_utils.apply(self.physics_body.velociy, lambda v: Vector2(-v.x, v.y))
            * self.physics_body.elasticity
        )

    def __bounds_y(self):
        self.physics_body.velociy = (
            vector_utils.apply(
                self.physics_body.velociy,
                lambda v: Vector2(v.x, -v.y),
            )
            * self.physics_body.elasticity
        )


class BouncyBall(SpriteGame):

    def __init__(
        self,
        settings: ScreenSettings,
        player_sprite: BouncyBallPlayer,
        *other_sprites: BouncyBallPuck,
    ):
        # configure sprites
        super().__init__(settings, player_sprite, *other_sprites)
        self.puck = self.other_sprites[0]
        display.set_caption("Air Hockey")

    def _update(self):
        self._update_sprites()

    def __update_player(self):
        self.player_sprite.update(self.dt)

    def __update_puck(self):
        self.puck.physics_body.move(self.dt)
        self.puck.update()

    def _update_sprites(self):
        self.__update_player()
        self.__update_puck()
        self.__update_collisions()

    def __update_collisions(self):

        if sprite.collide_circle(self.player_sprite, self.puck):
            if not self.player_sprite.collided:
                self.player_sprite.physics_body.on_collide(self.puck.physics_body)
                self.puck.physics_body.on_collide(self.player_sprite.physics_body)
                self.player_sprite.collided = True
        else:
            self.player_sprite.collided = False

    def _update_screen(self):
        # DRAW THE TABLE
        draw.rect(
            surface=self.screen_settings.screen,
            color=self.screen_settings.bg_color,
            rect=(0, 0, self.screen_settings.width, self.screen_settings.height),
            border_radius=15,
        )
        # DRAW PLAYER
        draw.circle(
            self.screen_settings.screen,
            self.player_sprite.color,
            self.player_sprite.position,
            self.player_sprite.rect.h,
        )

        # DRAW PUCK
        for sprite in self.other_sprites:
            assert isinstance(sprite, BouncyBallPuck)
            draw.circle(
                self.screen_settings.screen,
                sprite.color,
                sprite.position,
                self.puck.rect.h,
            )
