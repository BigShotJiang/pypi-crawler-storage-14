import os

import src.game_utils.toolkit as toolkit


def test_package_lib_path():
    assert os.path.exists(os.path.curdir)
    assert os.path.exists(os.path.join(os.path.curdir, "testgame.py"))

    toolkit.package_lib("testgame", os.path.curdir)

    zip_path = os.path.join(os.path.curdir, "testgame.zip")
    assert os.path.exists(zip_path)

    size = os.path.getsize(zip_path)
    print(f"zip size: {size}")
    assert size > 5000

    _clear()


def test_default_package():
    toolkit.package("testgame", os.path.curdir)

    zip_path = os.path.join(os.path.dirname(os.path.curdir), "testgame.zip")
    assert os.path.exists(zip_path)

    size = os.path.getsize(zip_path)
    print(f"zip size: {size}")
    assert size > 100

    _clear()


def _clear():
    os.remove(os.path.join(os.path.curdir, "testgame.zip"))
