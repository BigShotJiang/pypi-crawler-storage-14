"""Setup script for backcraft-cli (compatibility)"""
from setuptools import setup, find_packages

setup(
    name="backcraft-cli",
    packages=find_packages(),
)
