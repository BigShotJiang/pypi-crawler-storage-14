from .fragments import Fragments
from .view import FragmentsView
