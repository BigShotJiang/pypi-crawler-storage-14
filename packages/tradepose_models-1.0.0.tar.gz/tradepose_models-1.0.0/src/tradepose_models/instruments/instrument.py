"""Instrument (trading instrument) models."""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


class AssetClass(str, Enum):
    """Asset class types."""

    CRYPTO_SPOT = "crypto_spot"
    CRYPTO_FUTURES = "crypto_futures"
    CRYPTO_PERPETUAL = "crypto_perpetual"
    FOREX = "forex"
    EQUITY = "equity"
    COMMODITY = "commodity"


class InstrumentStatus(str, Enum):
    """Instrument trading status."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    TRADING_HALT = "trading_halt"


class Instrument(BaseModel):
    """
    Unified instrument (trading instrument) definition.

    Composite Key: (broker, broker_symbol, market_type, settlement_currency, contract_expiry)
    """

    id: UUID
    symbol: str = Field(..., description="Unified symbol (e.g., BTC-USDT)")
    name: Optional[str] = None

    # Composite key components
    broker: str
    broker_symbol: str = Field(..., description="Broker-specific symbol (e.g., BTCUSDT)")
    market_type: str
    settlement_currency: Optional[str] = Field(
        None, description="Settlement currency (USDT/USDC for futures)"
    )
    contract_expiry: Optional[datetime] = Field(
        None, description="Contract expiry date (for quarterly futures)"
    )

    asset_class: AssetClass
    base_currency: str
    quote_currency: str

    # Trading specifications
    min_quantity: Decimal
    max_quantity: Decimal
    quantity_step: Decimal
    quantity_precision: int
    min_price: Decimal
    max_price: Decimal
    price_step: Decimal
    price_precision: int
    min_notional: Decimal

    # Status
    status: InstrumentStatus
    trading_enabled: bool
    is_tradable: bool

    # Metadata
    created_at: datetime
    updated_at: datetime
    metadata: dict = Field(default_factory=dict)
