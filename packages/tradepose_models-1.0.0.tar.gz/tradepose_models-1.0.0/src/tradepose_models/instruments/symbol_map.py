"""Symbol normalization utilities."""


class SymbolNormalizer:
    """
    Symbol normalization utility.

    Converts broker-specific symbols to unified format (BASE-QUOTE).
    """

    # Crypto currency aliases
    CRYPTO_ALIASES = {
        "XBT": "BTC",
        "BCHABC": "BCH",
        "BCHSV": "BSV",
    }

    @staticmethod
    def validate_unified_symbol(symbol: str) -> bool:
        """
        Validate unified symbol format.

        Args:
            symbol: Symbol to validate (e.g., BTC-USDT)

        Returns:
            True if valid, False otherwise
        """
        if "-" not in symbol:
            return False
        parts = symbol.split("-")
        if len(parts) != 2:
            return False
        base, quote = parts
        return all(len(p) in [3, 4] and p.isupper() for p in [base, quote])

    @staticmethod
    def get_base_quote(unified_symbol: str) -> tuple[str, str]:
        """
        Extract base and quote currency from unified symbol.

        Args:
            unified_symbol: Unified symbol (e.g., BTC-USDT)

        Returns:
            Tuple of (base, quote)

        Raises:
            ValueError: If symbol format is invalid
        """
        if "-" not in unified_symbol:
            raise ValueError(f"Invalid unified symbol: {unified_symbol}")
        base, quote = unified_symbol.split("-", 1)
        return base, quote

    @staticmethod
    def normalize_binance_spot(broker_symbol: str) -> str:
        """
        Normalize Binance spot symbol to unified format.

        Args:
            broker_symbol: Binance symbol (e.g., BTCUSDT)

        Returns:
            Unified symbol (e.g., BTC-USDT)
        """
        common_quotes = ["USDT", "USDC", "BUSD", "BTC", "ETH", "BNB", "TUSD", "DAI"]
        for quote in common_quotes:
            if broker_symbol.endswith(quote):
                base = broker_symbol[: -len(quote)]
                return f"{base}-{quote}"
        # Fallback: assume last 3 chars are quote
        return f"{broker_symbol[:-3]}-{broker_symbol[-3:]}"

    @staticmethod
    def normalize_okx(broker_symbol: str) -> str:
        """
        Normalize OKX symbol to unified format.

        Args:
            broker_symbol: OKX symbol (e.g., BTC-USDT-SWAP)

        Returns:
            Unified symbol (e.g., BTC-USDT)
        """
        parts = broker_symbol.split("-")
        if len(parts) >= 2:
            return f"{parts[0]}-{parts[1]}"
        return broker_symbol

    @staticmethod
    def denormalize(unified_symbol: str, broker: str) -> str:
        """
        Convert unified symbol to broker-specific format.

        Args:
            unified_symbol: Unified symbol (e.g., BTC-USDT)
            broker: Broker name (binance, okx, etc.)

        Returns:
            Broker-specific symbol
        """
        if "-" not in unified_symbol:
            return unified_symbol

        base, quote = unified_symbol.split("-", 1)

        if broker == "binance":
            return f"{base}{quote}"
        elif broker == "okx":
            return unified_symbol  # OKX uses hyphen format
        else:
            return unified_symbol
