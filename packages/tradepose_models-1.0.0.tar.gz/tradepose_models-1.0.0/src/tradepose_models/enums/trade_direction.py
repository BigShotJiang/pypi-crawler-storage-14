"""
Trade direction enumeration
"""

from enum import Enum


class TradeDirection(str, Enum):
    """
    Trade direction enum

    Used to specify the trading direction in Blueprint.

    Values:
        LONG: Long trades only
        SHORT: Short trades only
        BOTH: Both long and short trades (currently not fully supported)
    """

    LONG = "Long"
    SHORT = "Short"
    BOTH = "Both"
