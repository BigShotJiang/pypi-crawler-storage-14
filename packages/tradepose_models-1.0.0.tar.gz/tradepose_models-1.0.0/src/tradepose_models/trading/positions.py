"""Position models."""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import BaseModel


class PositionSide(str, Enum):
    """Position side."""

    LONG = "long"
    SHORT = "short"


class Position(BaseModel):
    """Unified position model."""

    symbol: str  # Unified symbol
    broker_symbol: str  # Broker-specific symbol
    side: PositionSide
    quantity: Decimal
    entry_price: Decimal  # Average cost
    current_price: Decimal
    unrealized_pnl: Decimal
    realized_pnl: Decimal
    margin_used: Optional[Decimal] = None
    leverage: Optional[Decimal] = None
    created_at: datetime
    updated_at: datetime
    raw_data: Optional[dict] = None


class ClosedPosition(BaseModel):
    """Closed position (historical)."""

    symbol: str
    side: PositionSide
    quantity: Decimal
    entry_price: Decimal
    exit_price: Decimal
    realized_pnl: Decimal
    commission: Decimal
    opened_at: datetime
    closed_at: datetime
