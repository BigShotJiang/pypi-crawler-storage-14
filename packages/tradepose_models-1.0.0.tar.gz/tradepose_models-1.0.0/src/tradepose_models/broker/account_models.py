"""Account balance and information models."""

from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, Field


class AccountBalance(BaseModel):
    """Account balance information."""

    total_balance: Decimal = Field(..., description="Total equity")
    available_balance: Decimal = Field(..., description="Available balance")
    margin_used: Decimal = Field(..., description="Margin used")
    unrealized_pnl: Decimal = Field(..., description="Unrealized P&L")
    currency: str = Field(..., description="Currency (USD, USDT, TWD, etc.)")


class AccountInfo(BaseModel):
    """Account information."""

    account_id: str
    account_type: str = Field(..., description="CASH, MARGIN, FUTURES, etc.")
    status: str = Field(..., description="ACTIVE, SUSPENDED, etc.")
    trading_enabled: bool
    created_at: Optional[datetime] = None


class MarginInfo(BaseModel):
    """Margin information."""

    initial_margin: Decimal = Field(..., description="Initial margin requirement")
    maintenance_margin: Decimal = Field(..., description="Maintenance margin requirement")
    margin_level: Decimal = Field(..., description="Margin level (%)")
    liquidation_price: Optional[Decimal] = Field(
        None, description="Liquidation price"
    )
