"""Tradepose shared models package.

This package contains Pydantic models, enums, schemas, and types shared
across the Tradepose platform, including gateway, client SDK, and other
components.

Organization:
    - base: Base Pydantic model with standardized configuration
    - enums: Shared enumerations
    - schemas: Shared data schemas (Polars)
    - auth: Authentication and API key models
    - billing: Billing, subscription, and usage models
    - export: Export task and result models
    - gateway: Gateway API response models
    - indicators: Indicator specifications
    - strategy: Strategy configuration models
    - validators: Shared validation utilities
    - types: Common type definitions

Example usage:
    from tradepose_models.base import BaseModel
    from tradepose_models.enums import TaskStatus, ExportType
    from tradepose_models.auth import APIKeyCreate
    from tradepose_models.billing import PlanResponse
    from tradepose_models.export import ExportTaskResponse
"""

from .base import BaseModel

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "BaseModel",
]
