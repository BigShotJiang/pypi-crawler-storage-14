"""Version information for LangWatch."""

__version__ = "0.7.1" # x-release-please-version
