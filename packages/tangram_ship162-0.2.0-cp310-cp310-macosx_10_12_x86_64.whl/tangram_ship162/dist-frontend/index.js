import { defineComponent as F, inject as H, computed as L, ref as U, reactive as ot, watch as P, onUnmounted as nt, createElementBlock as y, createCommentVNode as b, openBlock as _, normalizeStyle as bt, createElementVNode as u, toDisplayString as h, createTextVNode as q } from "vue";
import { PolygonLayer as wt, IconLayer as Mt, PathLayer as kt } from "@deck.gl/layers";
const G = (s, e) => [
  s[0] * e[0] + s[1] * e[1] + s[2] * e[2],
  s[3] * e[0] + s[4] * e[1] + s[5] * e[2],
  s[6] * e[0] + s[7] * e[1] + s[8] * e[2]
], Lt = ([s, e, i]) => [
  s,
  isNaN(i) ? 0 : e * Math.cos(i * Math.PI / 180),
  isNaN(i) ? 0 : e * Math.sin(i * Math.PI / 180)
], St = (s) => s.map(
  (e) => Math.abs(e) > 31308e-7 ? (e < 0 ? -1 : 1) * (1.055 * Math.pow(Math.abs(e), 1 / 2.4) - 0.055) : 12.92 * e
), xt = (s) => {
  const i = G(
    [
      1,
      0.3963377773761749,
      0.2158037573099136,
      1,
      -0.1055613458156586,
      -0.0638541728258133,
      1,
      -0.0894841775298119,
      -1.2914855480194092
    ],
    s
  ).map((t) => t ** 3);
  return G(
    [
      1.2268798758459243,
      -0.5578149944602171,
      0.2813910456659647,
      -0.0405757452148008,
      1.112286803280317,
      -0.0717110580655164,
      -0.0763729366746601,
      -0.4214933324022432,
      1.5869240198367816
    ],
    i
  );
}, jt = (s) => G(
  [
    3.2409699419045226,
    -1.537383177570094,
    -0.4986107602930034,
    -0.9692436362808796,
    1.8759675015077202,
    0.04155505740717559,
    0.05563007969699366,
    -0.20397695888897652,
    1.0569715142428786
  ],
  s
), $t = (s) => St(jt(xt(Lt(s))));
function M(s, e, i, t = 255) {
  const c = $t([s, e, i]);
  return [
    Math.max(0, Math.min(255, Math.round(c[0] * 255))),
    Math.max(0, Math.min(255, Math.round(c[1] * 255))),
    Math.max(0, Math.min(255, Math.round(c[2] * 255))),
    t
  ];
}
const Et = { class: "tooltip-grid" }, Ct = { class: "ship-name" }, It = { class: "ship-type" }, Tt = { class: "mmsi" }, Pt = {
  key: 0,
  class: "speed"
}, At = {
  key: 1,
  class: "course"
}, Wt = {
  key: 2,
  class: "destination"
}, Dt = /* @__PURE__ */ F({
  __name: "ShipLayer",
  setup(s) {
    const e = H("tangramApi");
    if (!e)
      throw new Error("assert: tangram api not provided");
    const i = L(
      () => e.state.getEntitiesByType("ship162_ship").value
    ), t = L(() => e.state.activeEntity.value), c = U(null), n = U(null), m = L(() => e.map.zoom.value), a = ot({ x: 0, y: 0, object: null }), d = {
      passenger: M(0.65, 0.2, 260, 180),
      // blue
      cargo: M(0.65, 0.15, 140, 180),
      // green
      tanker: M(0.65, 0.2, 40, 180),
      // red-orange
      high_speed: M(0.9, 0.25, 90, 180),
      // yellow
      pleasure: M(0.65, 0.2, 330, 180),
      // magenta
      fishing: M(0.7, 0.2, 200, 180),
      // cyan
      special: M(0.75, 0.18, 70, 180),
      // orange
      aton: M(0.9, 0.25, 90, 180),
      // yellow
      sar: M(0.7, 0.25, 50, 180),
      // orange
      default: M(0.6, 0, 0, 180),
      // grey
      selected: M(0.7, 0.25, 20, 220)
      // bright red
    }, x = (o) => o.speed !== void 0 && o.speed < 1 || o.status === "At anchor" || o.status === "Moored" || o.status === "Aground", C = (o) => {
      if (!o) return d.default;
      switch (o.ship_type) {
        case "Passenger":
          return d.passenger;
        case "Cargo":
          return d.cargo;
        case "Tanker":
          return d.tanker;
        case "High Speed Craft":
          return d.high_speed;
        case "Pleasure craft":
        case "Sailing":
          return d.pleasure;
        case "Fishing":
          return d.fishing;
        case "Tug":
        case "Towing":
        case "Towing, large":
        case "Pilot Vessel":
        case "Search and Rescue":
        case "Port Tender":
        case "Dredging or underwater operations":
        case "Diving operations":
        case "Military operations":
        case "Law Enforcement":
        case "Anti-Pollution Equipment":
          return d.special;
      }
      if (o.mmsi_info)
        switch (o.ship_type) {
          case "SAR Aircraft":
            return d.sar;
          case "AIS AtoN":
            return d.aton;
        }
      return d.default;
    }, A = (o) => `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="-12 -12 24 24" fill="${o}" stroke="black" stroke-width="0.5"><path d="M 0 -10 L 4 8 L 0 5 L -4 8 Z"/></svg>`, lt = (o) => `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="-12 -12 24 24" fill="${o}" stroke="black" stroke-width="0.5"><circle cx="0" cy="0" r="4"/></svg>`, ct = (o) => `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="-12 -12 24 24" fill="${o}" stroke="black" stroke-width="0.5"><path d="M 0 -8 L 8 0 L 0 8 L -8 0 Z"/></svg>`, R = /* @__PURE__ */ new Map(), ut = (o, g, w) => "#" + [o, g, w].map((f) => {
      const v = f.toString(16);
      return v.length === 1 ? "0" + v : v;
    }).join(""), dt = (o, g) => {
      const w = x(o), f = o.ship_type === "AIS AtoN", v = g ? d.selected : C(o), k = ut(v[0], v[1], v[2]), j = `${k}-${w}-${f}`;
      if (R.has(j))
        return R.get(j);
      let S;
      f ? S = ct(k) : w ? S = lt(k) : S = A(k);
      const l = `data:image/svg+xml;base64,${btoa(S)}`;
      return R.set(j, l), l;
    }, pt = (o) => {
      const {
        to_bow: g,
        to_stern: w,
        to_port: f,
        to_starboard: v,
        latitude: k,
        longitude: j,
        course: S,
        heading: l
      } = o;
      if (!g || !w || !f || !v)
        return null;
      let $ = l;
      if ($ == null)
        if (S != null && o.speed && o.speed > 1)
          $ = S;
        else
          return null;
      const I = [j, k], p = 0.9999999998770914, T = 1567855942823164e-20, V = Math.PI / 180, W = 180 / Math.PI, K = I[1] * V, Y = ($ + 360) % 360 * V, D = Math.sin(K), N = Math.cos(K), Z = D * p + N * T * Math.cos(Y), ht = Math.asin(Z), gt = Math.atan2(
        Math.sin(Y) * T * N,
        p - D * Z
      ), B = [(ht * W - I[1]) / 100, gt * W / 100], J = ($ + 90 + 360) % 360 * V, Q = D * p + N * T * Math.cos(J), vt = Math.asin(Q), mt = Math.atan2(
        Math.sin(J) * T * N,
        p - D * Q
      ), z = [
        (vt * W - I[1]) / 100,
        mt * W / 100
      ], E = (st, at, it) => [st[0] + at[1] * it, st[1] + at[0] * it], X = E(I, B, -w), tt = E(X, z, v), et = E(X, z, -f), O = E(et, B, 0.8 * (g + w)), yt = E(O, z, 0.5 * (v + f)), _t = E(yt, B, 0.2 * (g + w)), ft = E(O, z, v + f);
      return [tt, et, O, _t, ft, tt];
    };
    return P(
      [i, t, () => e.map.isReady.value, m],
      ([o, g, w, f]) => {
        if (!o || !w) return;
        c.value && c.value.dispose(), n.value && (n.value.dispose(), n.value = null);
        const v = 0.9 * Math.min(Math.max(0.5, Math.pow(2, f - 10)), 2), k = f >= 12;
        if (k) {
          const l = Array.from(o.values()).map((p) => ({
            entity: p,
            polygon: pt(p.state)
          })).filter(({ polygon: p }) => p !== null), $ = new wt({
            id: "ship-hull-layer",
            data: l,
            pickable: !0,
            stroked: !0,
            filled: !0,
            wireframe: !1,
            lineWidthMinPixels: 1,
            getPolygon: (p) => p.polygon,
            getFillColor: (p) => p.entity.id === g?.id ? d.selected : C(p.entity.state),
            getLineColor: (p) => p.entity.id === g?.id ? d.selected : C(p.entity.state),
            getLineWidth: 0.5,
            onClick: ({ object: p }) => {
              p && e.state.setActiveEntity(p.entity);
            },
            updateTriggers: {
              getFillColor: [g?.id]
            }
          }), I = e.map.setLayer($);
          n.value || (n.value = I);
        } else n.value && (n.value.dispose(), n.value = null);
        const j = new Mt({
          id: "ship-layer",
          data: Array.from(o.values()),
          pickable: !0,
          billboard: !1,
          getIcon: (l) => ({
            url: dt(l.state, l.id === g?.id),
            width: 24,
            height: 24,
            anchorY: 12
          }),
          sizeScale: k ? v * 0.5 : v,
          // Smaller icons when hulls shown
          getPosition: (l) => [l.state.longitude, l.state.latitude],
          getSize: 24,
          getAngle: (l) => x(l.state) ? 0 : -(l.state.course || l.state.heading || 0),
          onClick: ({ object: l }) => {
            l && e.state.setActiveEntity(l);
          },
          onHover: (l) => {
            l.object ? (a.object = l.object, a.x = l.x, a.y = l.y) : a.object = null;
          },
          updateTriggers: {
            getIcon: [g?.id],
            sizeScale: [k]
          }
        }), S = e.map.setLayer(j);
        c.value || (c.value = S);
      },
      { immediate: !0 }
    ), nt(() => {
      c.value?.dispose(), n.value?.dispose();
    }), (o, g) => a.object ? (_(), y("div", {
      key: 0,
      class: "deck-tooltip",
      style: bt({ left: `${a.x}px`, top: `${a.y}px` })
    }, [
      u("div", Et, [
        u("div", Ct, h(a.object.state.mmsi_info?.flag) + " " + h(a.object.state.ship_name || "N/A"), 1),
        g[0] || (g[0] = u("div", null, null, -1)),
        u("div", It, h(a.object.state.ship_type), 1),
        u("div", Tt, h(a.object.state.mmsi), 1),
        a.object.state.speed ? (_(), y("div", Pt, h(a.object.state.speed.toFixed(1)) + " kts ", 1)) : b("", !0),
        a.object.state.course ? (_(), y("div", At, h(a.object.state.course.toFixed(0)) + "° ", 1)) : b("", !0),
        a.object.state.destination ? (_(), y("div", Wt, h(a.object.state.destination), 1)) : b("", !0)
      ])
    ], 4)) : b("", !0);
  }
}), Nt = { class: "ship-count-widget" }, zt = { class: "count-display" }, Ft = { id: "visible_ships_count" }, Ht = /* @__PURE__ */ F({
  __name: "ShipCountWidget",
  setup(s) {
    const e = H("tangramApi");
    if (!e)
      throw new Error("assert: tangram api not provided");
    const i = L(
      () => e.state.totalCounts.value?.get("ship162_ship") ?? 0
    ), t = L(
      () => e.state.getEntitiesByType("ship162_ship").value?.size ?? 0
    );
    return (c, n) => (_(), y("div", Nt, [
      u("div", zt, [
        u("span", Ft, h(t.value), 1),
        n[0] || (n[0] = q(" (", -1)),
        u("span", null, h(i.value ?? 0), 1),
        n[1] || (n[1] = q(") ", -1))
      ]),
      n[2] || (n[2] = u("span", { id: "count_ships" }, "visible ships", -1))
    ]));
  }
}), rt = (s, e) => {
  const i = s.__vccOpts || s;
  for (const [t, c] of e)
    i[t] = c;
  return i;
}, Rt = /* @__PURE__ */ rt(Ht, [["__scopeId", "data-v-7e392d1b"]]), Vt = {
  key: 0,
  class: "ship-info-widget"
}, Bt = { id: "metadata" }, Ot = {
  key: 0,
  id: "shiptype"
}, Ut = { id: "mmsi" }, qt = {
  key: 0,
  id: "registration"
}, Gt = ["data-tooltip"], Kt = { key: 1 }, Yt = { class: "details" }, Zt = { key: 0 }, Jt = { key: 1 }, Qt = { key: 2 }, Xt = { key: 3 }, te = /* @__PURE__ */ F({
  __name: "ShipInfoWidget",
  setup(s) {
    const e = H("tangramApi");
    if (!e)
      throw new Error("assert: tangram api not provided");
    const i = L(() => e.state.activeEntity.value), t = L(() => i.value?.state), c = L(() => t.value?.mmsi_info?.flag || ""), n = L(() => {
      if (!t.value) return null;
      const { to_bow: m, to_stern: a, to_port: d, to_starboard: x } = t.value;
      if (m != null && a != null && d != null && x != null) {
        const C = m + a, A = d + x;
        if (C > 0 || A > 0)
          return `${C} x ${A}`;
      }
      return null;
    });
    return (m, a) => i.value && i.value.type === "ship162_ship" && t.value ? (_(), y("div", Vt, [
      u("div", Bt, [
        t.value.ship_type ? (_(), y("span", Ot, h(t.value.ship_type), 1)) : b("", !0),
        u("span", Ut, h(t.value.mmsi), 1),
        a[0] || (a[0] = u("br", null, null, -1))
      ]),
      t.value ? (_(), y("span", qt, [
        u("a", {
          class: "flag",
          "data-tooltip": t.value.mmsi_info?.country
        }, h(c.value), 9, Gt),
        q(" " + h(t.value.ship_name), 1)
      ])) : b("", !0),
      a[5] || (a[5] = u("br", null, null, -1)),
      t.value.status ? (_(), y("span", Kt, h(t.value.status), 1)) : b("", !0),
      u("table", Yt, [
        t.value.destination ? (_(), y("tr", Zt, [
          a[1] || (a[1] = u("td", { class: "label" }, "Destination:", -1)),
          u("td", null, h(t.value.destination), 1)
        ])) : b("", !0),
        t.value.callsign ? (_(), y("tr", Jt, [
          a[2] || (a[2] = u("td", { class: "label" }, "Callsign:", -1)),
          u("td", null, h(t.value.callsign), 1)
        ])) : b("", !0),
        t.value.imo ? (_(), y("tr", Qt, [
          a[3] || (a[3] = u("td", { class: "label" }, "IMO:", -1)),
          u("td", null, h(t.value.imo), 1)
        ])) : b("", !0),
        n.value ? (_(), y("tr", Xt, [
          a[4] || (a[4] = u("td", { class: "label" }, "Dimensions:", -1)),
          u("td", null, h(n.value) + " m", 1)
        ])) : b("", !0)
      ])
    ])) : b("", !0);
  }
}), ee = /* @__PURE__ */ rt(te, [["__scopeId", "data-v-2bbf2ba4"]]), r = ot({
  id: null,
  trajectory: [],
  loading: !1,
  error: null
}), se = /* @__PURE__ */ F({
  __name: "ShipTrailLayer",
  setup(s) {
    const e = H("tangramApi");
    if (!e) throw new Error("assert: tangram api not provided");
    const i = L(() => e.state.activeEntity.value), t = U(null), c = () => {
      if (t.value && (t.value.dispose(), t.value = null), i.value?.type === "ship162_ship" && r.id === i.value.id && r.trajectory.length > 1) {
        const n = r.trajectory.filter((a) => a.latitude != null && a.longitude != null).map((a) => [a.longitude, a.latitude]), m = new kt({
          id: `ship-trail-layer-${i.value.id}`,
          data: [{ path: n }],
          pickable: !1,
          widthScale: 1,
          widthMinPixels: 2,
          getPath: (a) => a.path,
          getColor: [128, 0, 128, 255],
          getWidth: 2
        });
        t.value = e.map.addLayer(m);
      }
    };
    return P(() => r.trajectory.length, c), P(() => i.value?.id, c), nt(() => {
      t.value?.dispose();
    }), () => {
    };
  }
});
function ne(s) {
  s.ui.registerWidget("ship162-count-widget", "TopBar", Rt), s.ui.registerWidget("ship162-info-widget", "SideBar", ee), s.ui.registerWidget("ship162-ship-layer", "MapOverlay", Dt), s.ui.registerWidget("ship162-trail-layer", "MapOverlay", se), s.state.registerEntityType("ship162_ship"), (async () => {
    try {
      const i = await s.realtime.ensureConnected();
      await ae(s, i);
    } catch (i) {
      console.error("failed initializing ship162 realtime subscription", i);
    }
  })(), P(
    () => s.state.activeEntity.value,
    async (i) => {
      if (i?.type === "ship162_ship") {
        if (i.id !== r.id) {
          r.id = i.id, r.trajectory = [], r.loading = !0, r.error = null;
          try {
            const t = await fetch(`/ship162/data/${i.id}`);
            if (!t.ok) throw new Error("Failed to fetch trajectory");
            const c = await t.json();
            r.id === i.id && (r.trajectory = [...c, ...r.trajectory]);
          } catch (t) {
            r.id === i.id && (r.error = t.message);
          } finally {
            r.id === i.id && (r.loading = !1);
          }
        }
      } else
        r.id = null, r.trajectory = [];
    }
  );
  const e = () => {
    const i = s.realtime.getConnectionId();
    if (!i) return;
    const t = s.map.bounds.value;
    if (!t) return;
    const c = {
      connectionId: i,
      northEastLat: t.getNorthEast().lat,
      northEastLng: t.getNorthEast().lng,
      southWestLat: t.getSouthWest().lat,
      southWestLng: t.getSouthWest().lng,
      selectedEntityId: r.id
    };
    s.realtime.publish("system:bound-box", c);
  };
  P(s.map.bounds, e, { deep: !0 }), P(() => r.id, e);
}
async function ae(s, e) {
  const i = `streaming-${e}:new-ship162-data`;
  try {
    await s.realtime.subscribe(i, (t) => {
      const c = t.ship.map((n) => ({
        id: n.mmsi.toString(),
        type: "ship162_ship",
        state: n
      }));
      if (s.state.replaceAllEntitiesByType("ship162_ship", c), s.state.setTotalCount("ship162_ship", t.count), r.id) {
        const m = s.state.getEntitiesByType("ship162_ship").value.get(r.id);
        if (m && m.state && m.state.latitude && m.state.longitude) {
          const a = m.state, d = r.trajectory[r.trajectory.length - 1], x = a.timestamp;
          (!d || Math.abs(d.timestamp - x) > 0.5) && r.trajectory.push({
            ...a,
            timestamp: x
          });
        }
      }
    }), await s.realtime.publish("system:join-streaming", { connectionId: e });
  } catch (t) {
    console.error(`failed to subscribe to ${i}`, t);
  }
}
export {
  ne as install
};
//# sourceMappingURL=index.js.map
