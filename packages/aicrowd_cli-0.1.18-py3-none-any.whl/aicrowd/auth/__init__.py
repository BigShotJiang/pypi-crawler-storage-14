"""
login subcommand
"""

from aicrowd.auth.login import aicrowd_login
