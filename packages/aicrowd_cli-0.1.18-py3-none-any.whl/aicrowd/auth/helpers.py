"""
Auth related tasks
"""

from aicrowd_api.auth import verify_api_key, verify_gitlab_oauth_token
