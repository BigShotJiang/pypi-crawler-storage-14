"""
Challenge subcommand
"""

from aicrowd.challenge.init import init_challenge
