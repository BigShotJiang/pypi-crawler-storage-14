from django.contrib import admin

# Legacy BulkTask model has been removed; this module intentionally left without
# registrations so importing powercrud.admin continues to succeed.
