# reqcode-aj

A Python CLI tool to generate academic practical code files offline.

## Installation

```bash
pip install reqcode-aj
```

## Usage

```bash
# List available subjects
reqcode --list

# Generate all code files
reqcode --all

# Generate specific subject
reqcode --subject compiler_design
reqcode --subject deep_learning
reqcode --subject social_network_analysis

# Save to specific directory
reqcode --all --output ./my_codes

# Create zip file
reqcode --all --zip
```

## Subjects Included

1. **Compiler Design** - Lex and Yacc practical files
2. **Deep Learning** - Deep learning implementations
3. **Social Network Analysis** - Network analysis code

## Features

- Works completely offline
- All practical files bundled in the package
- Perfect for lab practicals and exam preparation
- No internet required after installation

## License

MIT License
