"""RestAPI services for Redis redirects"""
