# 📦 IAToolkit Enterprise

**IAToolkit Enterprise** is the commercial edition of the IAToolkit framework — designed for organizations that need advanced AI assistants, multi-tenant capabilities, secure integrations, and production-grade governance.

While the Community Edition provides the open-source core,  
**Enterprise adds connectors, services, advanced RAG, auditing, and full multi-company architecture.**

## 🚀 What Is IAToolkit Enterprise?

IAToolkit Enterprise extends the Community Edition with everything required to operate a **secure, scalable, private, multi-tenant AI assistant** inside your own infrastructure.

It is built for companies that need:

- Multiple clients, business units, or environments  
- Deep SQL + document retrieval  
- Secure workflows and controlled LLM tool execution  
- Private endpoints and internal integrations  
- Enterprise licensing, updates, and support

## 🧩 Key Features

### ✔ Full Multi-Tenant Architecture
Isolated “Company Modules” with:

- independent prompts  
- dedicated tools  
- custom SQL contexts  
- separate document stores  
- private configurations  

Perfect for SaaS platforms, consultancies, agencies, and large organizations.

### ✔ Advanced RAG & Data Intelligence
Enterprise Edition includes:

- hybrid retrieval (SQL + embeddings)  
- multi-source document integration  
- vector store orchestration  
- multi-tenant document indexing  
- configurable chunking, metadata, and ranking  

Designed for real corporate data: long-form documents, PDFs, financial records, operational logs, and internal repositories.

### ✔ External Connectors
Built-in enterprise integrations such as:

- S3 / Cloud storage  
- API connectors  
- Email pipelines  
- Authentication providers  
- Secure internal microservices  

### ✔ Observability & Governance
Enterprise adds:

- request auditing  
- usage logs  
- company-level metrics  
- licensing and activation  
- advanced configuration controls  

## 🏗 Architecture Overview

IAToolkit Enterprise follows the same architectural principles as the Community Edition:

```text
Interfaces (Chat UI & API)
        ↓
Intelligence Layer (Prompts, SQL, Tools, RAG)
        ↓
Execution Layer (Services & Workflows)
        ↓
Data Layer (SQL + Vector Stores + Connectors)
        ↓
Company Modules (Multi-Tenant Isolation)
```

With Enterprise, all layers support **multiple companies** with isolated contexts, tools, documents, and prompts.

## 🔐 License & Activation

IAToolkit Enterprise requires:

- A commercial license  
- A valid activation key  
- A private key for encrypted distribution  

Enterprise users receive updates, support, and security patches.

## 📘 Documentation

Full documentation is provided to licensed customers, including:

- Architecture & design guide  
- Deployment guide  
- Company Module reference  
- SQL orchestration & tools  
- RAG pipelines  
- Configuration & licensing  

## 🤝 About IAToolkit

IAToolkit is a production-grade framework for building private AI assistants that work with **real corporate data**, **internal workflows**, and **advanced LLM orchestration**.

- Community Edition: MIT open-source  
- Enterprise Edition: commercial + multi-tenant + connectors

## ⭐ Feedback & Support

Enterprise customers receive priority support.  
If you want to evaluate or integrate IAToolkit Enterprise, please contact the project maintainers.
