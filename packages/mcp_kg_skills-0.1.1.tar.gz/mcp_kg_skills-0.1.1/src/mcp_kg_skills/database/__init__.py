"""Database layer for MCP Knowledge Graph Skills."""

from .abstract import DatabaseInterface

__all__ = ["DatabaseInterface"]
