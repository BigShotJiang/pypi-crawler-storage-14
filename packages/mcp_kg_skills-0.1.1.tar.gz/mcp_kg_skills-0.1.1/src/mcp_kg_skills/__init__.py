"""MCP Knowledge Graph Skills - A FastMCP server for managing reusable Python functions in a graph."""

__version__ = "0.1.0"
