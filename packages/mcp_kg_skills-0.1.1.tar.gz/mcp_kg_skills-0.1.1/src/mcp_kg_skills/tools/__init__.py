"""MCP tools for interacting with the knowledge graph."""
