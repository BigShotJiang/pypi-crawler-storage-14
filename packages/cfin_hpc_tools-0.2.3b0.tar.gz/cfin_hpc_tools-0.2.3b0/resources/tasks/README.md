# Tasks
A directory containing some reusable tasks/skeleton tasks for running certain types of array jobs on an HPC. Designed to be used with `pyjasub`.

## `file-split-job-array.ah`
A task template to run a command on a subset of rows from a file. The job array file is expected to have the following columns:   
0: rowidx (row number 1-based)
1: infile - The path to the input file that will be processed in parallel.
2: outfile - The path to an output file (for a specific chunk)
3: start - The start row in the file 0-based with the 0 row being a header. This is inclusive, a start row of 2 will start at row 2 
4: end - The end row. This is exclusive an end row of 3 will not include the row 3 but will include row 2

The job array can be created with `../job_array/file-split-job-array.sh`
