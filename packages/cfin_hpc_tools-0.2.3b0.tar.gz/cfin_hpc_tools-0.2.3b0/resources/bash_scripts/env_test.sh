#!/bin/bash
# Test what environment has been loaded
which python

python -c"import gwas_norm"
echo "*** END ***"
