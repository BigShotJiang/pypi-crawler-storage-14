# job_array
A directory containing some reusable scripts for creating job array files to run as parallel jobs on an HPC.

## `file-split-job-array.ah`
A bash script for generating a job array file of row numbers in an input file that can be subset and processed in a parallel job array.

Arguments:
infile : The path to the file that will have row number subsets,
         can be gzip/bzip2 compressed.
chunk_size : The number of rows in each subset.
split_prefix: A path and prefix that will make an output file name.

Output is to STDOUT.
