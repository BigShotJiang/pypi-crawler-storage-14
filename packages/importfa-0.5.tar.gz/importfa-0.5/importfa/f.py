from . import importfa_set

importfa_set(1)
