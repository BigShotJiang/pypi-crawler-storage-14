"""Tests for SinkVis package."""
