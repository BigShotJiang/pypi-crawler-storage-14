import DocItemContent from '@theme/DocItemContent';
import React from 'react';

export default function DocItem(props) {
    return <DocItemContent {...props} />
}
