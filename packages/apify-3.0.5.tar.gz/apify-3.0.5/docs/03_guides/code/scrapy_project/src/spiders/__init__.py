from .title import TitleSpider

__all__ = ['TitleSpider']
