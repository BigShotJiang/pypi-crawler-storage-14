"""
GRNexus - High-Performance Neural Network Library
==================================================

A neural network library with Keras-like API and high-performance core.

Features:
- 🚀 Pure Python implementation with optimized operations
- 🎯 Keras-like API - familiar and easy to use
- 🧩 Modular architecture with flexible layers
- 💾 Model persistence in .nexus format
- 🎨 50+ activation functions
- 🔧 Multiple optimizers (SGD, Momentum, Adam, RMSprop)
- 📊 Regularization (Dropout, BatchNorm)

Quick Start:
-----------
>>> from grnexus import NeuralNetwork
>>> from grnexus.layers import DenseLayer
>>> from grnexus.activations import ReLU
>>> 
>>> model = NeuralNetwork()
>>> model.add(DenseLayer(128, input_dim=784, activation=ReLU()))
>>> model.compile(loss='cross_entropy', optimizer='adam', learning_rate=0.001)
>>> model.train(x_train, y_train, epochs=10, batch_size=32)

For more information, visit: https://github.com/grcodedigitalsolutions/GRNexus
"""

__version__ = "0.1.9"
__author__ = "GR Code Digital Solutions"
__license__ = "GPL-3.0"

# Import main class
from .grnexus import NeuralNetwork

# Import submodules for cleaner API
from .lib import grnexus_layers as layers
from .lib import grnexus_activations as activations
from .lib import grnexus_callbacks as callbacks
from .lib import grnexus_machine_learning as ml

# Import commonly used classes for convenience
from .lib.grnexus_layers import (
    DenseLayer,
    ActivationLayer,
    DropoutLayer,
    BatchNormLayer,
    SoftmaxLayer,
)

from .lib.grnexus_activations import (
    ReLU,
    Sigmoid,
    Tanh,
    Swish,
    GELU,
    Mish,
    LeakyReLU,
    ELU,
    SELU,
)

from .lib.grnexus_callbacks import (
    EarlyStopping,
    ModelCheckpoint,
    LearningRateScheduler,
    ReduceLROnPlateau,
)

from .lib.grnexus_machine_learning import (
    KNeighborsClassifier,
    KMeans,
    LinearRegression,
    LogisticRegression,
    GaussianNB
)

# Define public API
__all__ = [
    # Main class
    'NeuralNetwork',
    
    # Submodules (for grnexus.layers, grnexus.activations, etc.)
    'layers',
    'activations',
    'callbacks',
    'ml',
    
    # Commonly used layers (for direct import)
    'DenseLayer',
    'ActivationLayer',
    'DropoutLayer',
    'BatchNormLayer',
    'SoftmaxLayer',
    
    # Commonly used activations (for direct import)
    'ReLU',
    'Sigmoid',
    'Tanh',
    'Swish',
    'GELU',
    'Mish',
    'LeakyReLU',
    'ELU',
    'SELU',
    
    # Callbacks (for direct import)
    'EarlyStopping',
    'ModelCheckpoint',
    'LearningRateScheduler',
    'ReduceLROnPlateau',
    
    # ML Algorithms (for direct import)
    'KNeighborsClassifier',
    'KMeans',
    'LinearRegression',
    'LogisticRegression',
    'GaussianNB',
    
    # Metadata
    '__version__',
    '__author__',
    '__license__',
]
