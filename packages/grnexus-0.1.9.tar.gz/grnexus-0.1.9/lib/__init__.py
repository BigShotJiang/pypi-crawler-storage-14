"""GRNexus Library - Core modules for neural network implementation"""

__version__ = "0.1.0"

# Import all public APIs from submodules
from .grnexus_core import *
from .grnexus_activations import *
from .grnexus_layers import *
from .grnexus_normalization import *
from .grnexus_numeric_proccessing import *
from .grnexus_callbacks import *
from .grnexus_machine_learning import *

__all__ = [
    # Core
    'GRalu',
    
    # Activations (50+ functions)
    'ReLU', 'LeakyReLU', 'PReLU', 'ELU', 'SELU', 'GELU', 'Swish', 'Mish',
    'Sigmoid', 'Tanh', 'HardSigmoid', 'HardTanh', 'Softplus', 'Softsign',
    'ReLU6', 'HardSwish', 'Snake', 'SiLU', 'LogSigmoid', 'TanhShrink',
    'SoftExponential', 'BentIdentity', 'Gaussian', 'Sinc', 'SinActivation',
    
    # Layers
    'DenseLayer', 'ActivationLayer', 'DropoutLayer', 'BatchNormLayer',
    'SoftmaxLayer', 'FlattenLayer', 'ReshapeLayer',
    
    # Normalization
    'BatchNorm', 'LayerNorm', 'GroupNorm',
    
    # Numeric Processing
    'Matrix', 'Vector', 'Scaler', 'OneHotEncoder',
    
    # Callbacks
    'Callback', 'EarlyStopping', 'ModelCheckpoint', 'LearningRateScheduler',
    'ReduceLROnPlateau', 'CSVLogger', 'TensorBoard',
    
    # Machine Learning
    'KNNClassifier', 'LinearRegression', 'LogisticRegression',
    'DecisionTree', 'RandomForest',
]
