"""Utility helpers for tesser-py."""
