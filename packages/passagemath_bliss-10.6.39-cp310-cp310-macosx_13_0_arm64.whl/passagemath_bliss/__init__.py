# sage_setup: distribution = sagemath-bliss

from sage.all__sagemath_bliss import *
