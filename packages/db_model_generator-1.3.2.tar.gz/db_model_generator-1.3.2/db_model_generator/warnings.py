class MeaninglessArgumentWarning(Warning):
    pass


class ExtraKwargsWarning(Warning):
    pass
