# MCP Wrapper - Quick Start Guide

Get started with the MCP wrapper for A2A in Synqed in under 5 minutes.

> **Note:** The package is named `synqed_mcp` to avoid conflicts with the `mcp` SDK package.

## Installation

### Prerequisites

- Python 3.10 or higher
- Synqed repository cloned

### Step 1: Install Dependencies

```bash
cd synqed-python
pip install fastmcp mcp
```

**Important:** You need both `fastmcp` (the server framework) and `mcp` (the protocol SDK).

## Running the Demo

### Option 1: Full Demo with Tests (Recommended)

Run the complete demo that creates agents, tests tools, and starts the MCP server:

```bash
python demo.py
```

**What happens:**
1. Creates 3 A2A agents (Salesforce, Zoom, ContentCreator)
2. Registers agents in Synqed's AgentRuntimeRegistry
3. Sets up MessageRouter for inter-agent communication
4. Tests each tool by sending A2A tasks
5. Starts MCP server on stdio transport

**Expected output:**
```
============================================================
mcp wrapper for a2a in synqed - demo
============================================================

step 1: creating a2a agents
created 3 agents: ['salesforce', 'zoom', 'content_creator']

...tests run...

all tests completed successfully!

step 6: mcp server ready
============================================================
available tools:
  1. salesforce_query_leads - Query Salesforce leads
  2. zoom_create_meeting - Create Zoom meetings
  3. content_creator_generate - Generate content
============================================================

starting mcp server: transport=stdio
```

### Option 2: Run Without Tests

Skip the tool tests and start the server directly:

```bash
python demo.py --no-test
```

### Option 3: SSE Transport (for Web Clients)

Run with Server-Sent Events transport for HTTP-based clients:

```bash
python demo.py --transport sse --port 8080
```

Server will be available at `http://localhost:8080/sse`

## Using with Claude Desktop

### Step 1: Configure Claude Desktop

Edit your Claude Desktop configuration file:

**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

Add the MCP server:

```json
{
  "mcpServers": {
    "synqed-a2a": {
      "command": "python",
      "args": ["demo.py", "--no-test"],
      "cwd": "/absolute/path/to/synqed-python"
    }
  }
}
```

**Important:** 
- Replace `/absolute/path/to/synqed-python` with the actual path
- Added `--no-test` to skip tests during startup

### Step 2: Restart Claude Desktop

Quit and restart Claude Desktop to load the configuration.

### Step 3: Use the Tools

Example prompts in Claude:

**Salesforce:**
```
Query Salesforce for leads where Status='Qualified' and Email is not null
```

**Zoom:**
```
Create a Zoom meeting for "Team Standup" tomorrow at 9am PST for 30 minutes
```

**Content Creator:**
```
Generate a professional blog post about the benefits of AI agents in markdown format
```

## Package Structure

After the rename to avoid conflicts:

```
synqed_mcp/              # Renamed from 'mcp'
├── __init__.py
├── __main__.py
├── server.py
├── a2a/
│   ├── __init__.py
│   └── client.py
├── tools/
│   ├── __init__.py
│   ├── salesforce.py
│   ├── zoom.py
│   └── content_creator.py
└── [docs...]

demo.py                  # Example run script
```

## Common Issues

### Issue: "ModuleNotFoundError: No module named 'mcp.types'"

**Solution:** This was caused by our package name conflicting with the MCP SDK. We've renamed the package to `synqed_mcp`. Install both packages:

```bash
pip install fastmcp mcp
```

### Issue: "RuntimeError: Already running asyncio in this thread"

**Solution:** This has been fixed! The demo now properly separates the async setup from the MCP server startup.

### Issue: Claude Desktop doesn't show the tools

**Solution:**
1. Check the config file path is correct
2. Ensure `cwd` points to the `synqed-python` directory (absolute path)
3. Add `--no-test` argument to skip tests during startup
4. Restart Claude Desktop after editing config
5. Check Claude Desktop logs for errors

**macOS logs location:**
```
~/Library/Logs/Claude/
```

## Quick Test

Verify the installation works:

```bash
cd synqed-python
python synqed_mcp/test_mcp.py
```

Expected output:
```
============================================================
mcp wrapper test suite
============================================================

testing tool imports...
✅ salesforce module imported
✅ zoom module imported
✅ content_creator module imported

...

🎉 all tests passed!
```

## Summary

The MCP wrapper is now ready to use:

✅ **Package renamed** to `synqed_mcp` (avoids SDK conflicts)  
✅ **Asyncio fixed** (no more event loop errors)  
✅ **3 tools working** (Salesforce, Zoom, ContentCreator)  
✅ **Claude Desktop ready** (add config and restart)  
✅ **Fully tested** (run `python demo.py`)  

**Start using it:**

```bash
python demo.py
```

For more details, see:
- [README.md](README.md) - Complete documentation
- [ARCHITECTURE.md](ARCHITECTURE.md) - Technical details
