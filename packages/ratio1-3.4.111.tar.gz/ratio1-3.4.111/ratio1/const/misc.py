class COLORS:
  DCT = 'g'
  MAIN = None
  TIMERS = 'd'
  STATUS = 'n'
  SERVING = 'm'
  BIZ = 'c'
  COMM = 'y'
  TIMERS = 'd'


WEEKDAYS_SHORT = [
  'MON',
  'TUE',
  'WED',
  'THU',
  'FRI',
  'SAT',
  'SUN'
]


class SESSION_CT:
  NETSTATS_REPORT = 'report'
  NETSTATS_REPORTER = 'reporter'
  NETSTATS_REPORTER_ALIAS = 'reporter_alias'
  NETSTATS_NR_SUPERVISORS = 'nr_super'
  NETSTATS_ELAPSED = 'elapsed'
  
  