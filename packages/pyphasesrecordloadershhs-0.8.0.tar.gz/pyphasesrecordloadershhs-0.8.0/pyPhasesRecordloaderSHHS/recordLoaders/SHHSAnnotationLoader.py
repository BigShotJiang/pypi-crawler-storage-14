from pyPhasesRecordloaderSHHS.recordLoaders.NSRRAnnotationLoader import NSRRAnnotationLoader


class SHHSAnnotationLoader(NSRRAnnotationLoader):
    pass