# from setuptools import setup, find_packages

# setup(
#     name="drqeh",
#     version="1.0.0",
#     description="DigiRaksha Quantum Encryption Hasher – Python SDK",
#     long_description=open("README.md").read(),
#     long_description_content_type="text/markdown",
#     author="Kallesh D R",
#     packages=find_packages(),
#     install_requires=["requests"],
#     python_requires=">=3.7",
# )
from setuptools import setup, find_packages

setup(
    name="drqeh",
    version="1.0.1",  # updated version
    description="DigiRaksha Quantum Encryption Hasher – Python SDK",
    long_description=open("README.md", encoding="utf-8").read(),  # FIXED
    long_description_content_type="text/markdown",
    author="Kallesh D R",
    packages=find_packages(),
    install_requires=["requests"],
    python_requires=">=3.7",
)
