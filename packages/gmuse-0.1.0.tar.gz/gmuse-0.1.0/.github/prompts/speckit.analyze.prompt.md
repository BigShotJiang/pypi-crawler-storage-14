---
agent: speckit.analyze
---
