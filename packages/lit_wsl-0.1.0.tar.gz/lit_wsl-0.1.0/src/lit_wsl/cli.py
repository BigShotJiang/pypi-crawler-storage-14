from lit_wsl.__about__ import __version__


def main():
    print(f"lit-wsl v{__version__}!")
