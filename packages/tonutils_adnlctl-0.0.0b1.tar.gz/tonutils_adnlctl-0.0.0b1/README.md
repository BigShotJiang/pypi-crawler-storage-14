# 📦 Tonutils ADNLCTL

[![TON](https://img.shields.io/badge/TON-grey?logo=TON&logoColor=40AEF0)](https://ton.org)
![Python Versions](https://img.shields.io/badge/Python-3.10%20--%203.14-black?color=FFE873&labelColor=3776AB)
[![License](https://img.shields.io/github/license/nessshon/tonutils-adnlctl)](LICENSE)

![Downloads](https://pepy.tech/badge/tonutils_adnlctl)
![Downloads](https://pepy.tech/badge/tonutils_adnlctl/month)
![Downloads](https://pepy.tech/badge/tonutils_adnlctl/week)

**Tonutils ADNLCTL** is a minimal command-line tool built on top of `tonutils` (2.x) for inspecting ADNL clients.

## Installation

```bash
pip install tonutils_adnlctl
```

## Usage

**Mainnet**
```commandline
tonutils-adnlctl status -n mainnet
```

**Testnet**
```commandline
tonutils-adnlctl status -n testnet
```

**From config**
```commandline
tonutils-adnlctl status -n mainnet -c /path/to/config.json
tonutils-adnlctl status -n mainnet -c https://example.com/config.json
```

## Contribution

We welcome contributions — issues, feature ideas and pull requests are appreciated.

## Support

Supported by [Igroman787](https://github.com/Igroman787).

## License

MIT License — see [LICENSE](LICENSE).