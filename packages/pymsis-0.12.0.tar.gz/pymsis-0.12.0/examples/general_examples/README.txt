.. _general_examples:

General Examples
----------------

Basic atmospheric modeling examples showing core pymsis functionality for
typical use cases like plotting atmospheric profiles, understanding seasonal
and diurnal variations, and comparing different MSIS versions.
