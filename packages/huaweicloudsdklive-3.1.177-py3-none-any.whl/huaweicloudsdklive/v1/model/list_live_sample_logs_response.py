# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListLiveSampleLogsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total': 'int',
        'domain': 'str',
        'logs': 'list[LogInfo]'
    }

    attribute_map = {
        'total': 'total',
        'domain': 'domain',
        'logs': 'logs'
    }

    def __init__(self, total=None, domain=None, logs=None):
        r"""ListLiveSampleLogsResponse

        The model defined in huaweicloud sdk

        :param total: 符合查询条件的总条目数
        :type total: int
        :param domain: 播放域名
        :type domain: str
        :param logs: 日志信息列表
        :type logs: list[:class:`huaweicloudsdklive.v1.LogInfo`]
        """
        
        super().__init__()

        self._total = None
        self._domain = None
        self._logs = None
        self.discriminator = None

        if total is not None:
            self.total = total
        if domain is not None:
            self.domain = domain
        if logs is not None:
            self.logs = logs

    @property
    def total(self):
        r"""Gets the total of this ListLiveSampleLogsResponse.

        符合查询条件的总条目数

        :return: The total of this ListLiveSampleLogsResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListLiveSampleLogsResponse.

        符合查询条件的总条目数

        :param total: The total of this ListLiveSampleLogsResponse.
        :type total: int
        """
        self._total = total

    @property
    def domain(self):
        r"""Gets the domain of this ListLiveSampleLogsResponse.

        播放域名

        :return: The domain of this ListLiveSampleLogsResponse.
        :rtype: str
        """
        return self._domain

    @domain.setter
    def domain(self, domain):
        r"""Sets the domain of this ListLiveSampleLogsResponse.

        播放域名

        :param domain: The domain of this ListLiveSampleLogsResponse.
        :type domain: str
        """
        self._domain = domain

    @property
    def logs(self):
        r"""Gets the logs of this ListLiveSampleLogsResponse.

        日志信息列表

        :return: The logs of this ListLiveSampleLogsResponse.
        :rtype: list[:class:`huaweicloudsdklive.v1.LogInfo`]
        """
        return self._logs

    @logs.setter
    def logs(self, logs):
        r"""Sets the logs of this ListLiveSampleLogsResponse.

        日志信息列表

        :param logs: The logs of this ListLiveSampleLogsResponse.
        :type logs: list[:class:`huaweicloudsdklive.v1.LogInfo`]
        """
        self._logs = logs

    def to_dict(self):
        import warnings
        warnings.warn("ListLiveSampleLogsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListLiveSampleLogsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
