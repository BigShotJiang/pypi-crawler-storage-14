"""C/C++ parser plugin package."""
