-- add checks.analysis error column

ALTER TABLE checks
ADD analysis_error VARCHAR;
