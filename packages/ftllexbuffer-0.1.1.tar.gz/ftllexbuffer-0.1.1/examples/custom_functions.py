"""Custom Functions Example - Demonstrating FluentBundle.add_function() API.

This example shows how to extend FTLLexBuffer with custom formatting functions
for domain-specific needs:

1. CURRENCY formatting with symbols
2. PHONE number formatting
3. MARKDOWN rendering
4. FILESIZE human-readable formatting
5. DURATION time formatting
6. Locale-aware custom functions using factory pattern (capturing bundle.locale)

WARNING: Examples use use_isolating=False for cleaner terminal output.
NEVER disable bidi isolation in production applications that support RTL languages.

Python 3.13+.
"""

from __future__ import annotations

import re
from typing import Any

from ftllexbuffer import FluentBundle


# Example 1: CURRENCY Formatting
def CURRENCY(amount: float, *, currency_code: str = "USD") -> str:  # noqa: N802  # pylint: disable=invalid-name
    """Format currency with symbol.

    FTL function naming convention: UPPERCASE names match FTL spec (DATETIME, NUMBER, etc.)
    This follows the same pattern as built-in FTL functions.

    Args:
        amount: Monetary amount
        currency_code: ISO 4217 currency code (USD, EUR, GBP, etc.)

    Returns:
        Formatted currency string with symbol
    """
    symbols = {
        "USD": "$",
        "EUR": "€",
        "GBP": "£",
        "PLN": "zł",
        "JPY": "¥",
        "CAD": "CA$",
        "AUD": "A$",
    }
    symbol = symbols.get(currency_code, currency_code)
    return f"{symbol}{amount:,.2f}"


# Example 2: PHONE Formatting
def PHONE(number: str, *, format_style: str = "international") -> str:  # noqa: N802  # pylint: disable=invalid-name
    """Format phone number.

    FTL function naming convention: UPPERCASE name.

    Args:
        number: Phone number (digits only or with separators)
        format_style: "international", "national", or "compact"

    Returns:
        Formatted phone number
    """
    # Remove non-digits
    digits = "".join(c for c in str(number) if c.isdigit())

    if format_style == "international" and len(digits) >= 10:
        # US/Canada format: +1 (555) 123-4567
        return f"+{digits[0]} ({digits[1:4]}) {digits[4:7]}-{digits[7:]}"
    if format_style == "national" and len(digits) >= 10:
        # (555) 123-4567
        return f"({digits[-10:-7]}) {digits[-7:-4]}-{digits[-4:]}"
    if format_style == "compact":
        # 5551234567
        return digits
    return number


# Example 3: MARKDOWN Rendering (Simple)
def MARKDOWN(text: str, *, render: str = "html") -> str:  # noqa: N802  # pylint: disable=invalid-name
    """Render markdown to HTML (simplified).

    FTL function naming convention: UPPERCASE name.

    Args:
        text: Markdown text
        render: Output format ("html" or "plain")

    Returns:
        Rendered text
    """
    if render == "plain":
        # Strip markdown syntax
        # Remove **bold**
        text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
        # Remove *italic*
        text = re.sub(r"\*(.*?)\*", r"\1", text)
        # Remove [links](url)
        return re.sub(r"\[(.*?)\]\(.*?\)", r"\1", text)
    # Simple HTML rendering
    # **bold** → <strong>bold</strong>
    text = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", text)
    # *italic* → <em>italic</em>
    text = re.sub(r"\*(.*?)\*", r"<em>\1</em>", text)
    # [text](url) → <a href="url">text</a>
    return re.sub(r"\[(.*?)\]\((.*?)\)", r'<a href="\2">\1</a>', text)


# Example 4: FILESIZE Formatting
def FILESIZE(bytes_count: int | float, *, precision: int = 2) -> str:  # noqa: N802  # pylint: disable=invalid-name
    """Format file size in human-readable format.

    FTL function naming convention: UPPERCASE name.

    Args:
        bytes_count: Number of bytes
        precision: Decimal precision

    Returns:
        Human-readable file size (e.g., "1.23 MB")
    """
    bytes_count = float(bytes_count)
    units = ["B", "KB", "MB", "GB", "TB", "PB"]

    for unit in units:
        if bytes_count < 1024.0:
            return f"{bytes_count:.{precision}f} {unit}"
        bytes_count /= 1024.0

    return f"{bytes_count:.{precision}f} EB"


# Example 5: DURATION Formatting
def DURATION(seconds: int | float, *, format_style: str = "long") -> str:  # noqa: N802, PLR0912  # pylint: disable=invalid-name,too-many-branches
    """Format duration in human-readable format.

    FTL function naming convention: UPPERCASE name.
    Branch complexity unavoidable for comprehensive time formatting.

    Args:
        seconds: Duration in seconds
        format_style: "long", "short", or "compact"

    Returns:
        Formatted duration
    """
    seconds = int(seconds)
    days, remainder = divmod(seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, secs = divmod(remainder, 60)

    if format_style == "long":
        parts = []
        if days > 0:
            parts.append(f"{days} day{'s' if days != 1 else ''}")
        if hours > 0:
            parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        if secs > 0 or not parts:
            parts.append(f"{secs} second{'s' if secs != 1 else ''}")
        return ", ".join(parts)
    if format_style == "short":
        parts = []
        if days > 0:
            parts.append(f"{days}d")
        if hours > 0:
            parts.append(f"{hours}h")
        if minutes > 0:
            parts.append(f"{minutes}m")
        if secs > 0 or not parts:
            parts.append(f"{secs}s")
        return " ".join(parts)
    if days > 0:
        return f"{days}d{hours}h"
    if hours > 0:
        return f"{hours}h{minutes}m"
    if minutes > 0:
        return f"{minutes}m{secs}s"
    return f"{secs}s"


# Example 6: Locale-Aware Custom Function (Factory Pattern)
def make_greeting_function(bundle_locale: str) -> Any:
    """Factory for locale-aware greeting function.

    Args:
        bundle_locale: The bundle's locale string

    Returns:
        Greeting function customized for the locale
    """
    def GREETING(name: str, *, formal: str = "false") -> str:  # noqa: N802  # pylint: disable=invalid-name
        """Locale-aware greeting.

        FTL function naming convention: UPPERCASE name.

        Args:
            name: Person's name
            formal: "true" for formal greeting, "false" for informal

        Returns:
            Localized greeting
        """
        is_formal = formal.lower() == "true"
        locale_lower = bundle_locale.lower()

        if locale_lower.startswith("lv"):
            return f"Labdien, {name}!" if is_formal else f"Sveiki, {name}!"
        if locale_lower.startswith("de"):
            return f"Guten Tag, {name}!" if is_formal else f"Hallo, {name}!"
        if locale_lower.startswith("pl"):
            return f"Dzień dobry, {name}!" if is_formal else f"Cześć, {name}!"
        return f"Good day, {name}!" if is_formal else f"Hello, {name}!"

    return GREETING


# Demonstration
if __name__ == "__main__":
    print("=" * 60)
    print("Custom Functions Example")
    print("=" * 60)

    bundle = FluentBundle("en_US", use_isolating=False)

    # Register all custom functions
    bundle.add_function("CURRENCY", CURRENCY)
    bundle.add_function("PHONE", PHONE)
    bundle.add_function("MARKDOWN", MARKDOWN)
    bundle.add_function("FILESIZE", FILESIZE)
    bundle.add_function("DURATION", DURATION)
    # Create locale-aware function for English
    bundle.add_function("GREETING", make_greeting_function(bundle.locale))

    # Add FTL resource using custom functions
    bundle.add_resource("""
# E-commerce examples
product-price = { CURRENCY($amount, currency_code: "EUR") }
support-phone = Call us at { PHONE($number, format_style: "international") }

# File management
file-info = { $filename } ({ FILESIZE($bytes) })

# Video player
video-duration = Duration: { DURATION($seconds, format_style: "short") }

# Rich text
welcome-message = { MARKDOWN($text, render: "html") }
welcome-plain = { MARKDOWN($text, render: "plain") }

# Locale-aware greeting
greet = { GREETING($name, formal: "false") }
greet-formal = { GREETING($name, formal: "true") }
""")

    # Example 1: Currency
    print("\n" + "-" * 60)
    print("Example 1: CURRENCY Formatting")
    print("-" * 60)
    result, _ = bundle.format_pattern("product-price", {"amount": 1234.56})
    print(f"Product price: {result}")
    # Output: Product price: €1,234.56

    # Example 2: Phone
    print("\n" + "-" * 60)
    print("Example 2: PHONE Formatting")
    print("-" * 60)
    result, _ = bundle.format_pattern("support-phone", {"number": "15551234567"})
    print(f"Support: {result}")
    # Output: Support: Call us at +1 (555) 123-4567

    # Example 3: File size
    print("\n" + "-" * 60)
    print("Example 3: FILESIZE Formatting")
    print("-" * 60)
    result, _ = bundle.format_pattern("file-info", {
        "filename": "video.mp4",
        "bytes": 157286400  # ~150 MB
    })
    print(f"File: {result}")
    # Output: File: video.mp4 (150.00 MB)

    # Example 4: Duration
    print("\n" + "-" * 60)
    print("Example 4: DURATION Formatting")
    print("-" * 60)
    result, _ = bundle.format_pattern("video-duration", {"seconds": 3725})
    print(f"Video: {result}")
    # Output: Video: Duration: 1h 2m 5s

    # Example 5: Markdown
    print("\n" + "-" * 60)
    print("Example 5: MARKDOWN Rendering")
    print("-" * 60)
    result_html, _ = bundle.format_pattern("welcome-message", {
        "text": "Welcome to **FTLLexBuffer**! Visit [our site](https://example.com)."
    })
    print(f"HTML: {result_html}")
    # Output: HTML: Welcome to <strong>FTLLexBuffer</strong>!
    # Visit <a href="https://example.com">our site</a>.

    result_plain, _ = bundle.format_pattern("welcome-plain", {
        "text": "Welcome to **FTLLexBuffer**! Visit [our site](https://example.com)."
    })
    print(f"Plain: {result_plain}")
    # Output: Plain: Welcome to FTLLexBuffer! Visit our site.

    # Example 6: Locale-aware greeting
    print("\n" + "-" * 60)
    print("Example 6: GREETING (Locale-Aware)")
    print("-" * 60)
    result, _ = bundle.format_pattern("greet", {"name": "Alice"})
    print(f"Informal: {result}")
    # Output: Informal: Hello, Alice!

    result, _ = bundle.format_pattern("greet-formal", {"name": "Dr. Smith"})
    print(f"Formal: {result}")
    # Output: Formal: Good day, Dr. Smith!

    # Test with different locale - demonstrating factory pattern for locale awareness
    print("\nTesting with Latvian locale:")
    lv_bundle = FluentBundle("lv", use_isolating=False)
    # Create locale-specific GREETING function using factory
    lv_bundle.add_function("GREETING", make_greeting_function(lv_bundle.locale))
    lv_bundle.add_resource('greet = { GREETING($name, formal: "false") }')
    result, errors = lv_bundle.format_pattern("greet", {"name": "Anna"})
    if errors:
        print(f"Errors: {errors}")
    print(f"Latvian informal: {result}")
    # Output: Latvian informal: Sveiki, Anna!

    print("\n" + "=" * 60)
    print("[SUCCESS] All custom function examples completed!")
    print("=" * 60)
