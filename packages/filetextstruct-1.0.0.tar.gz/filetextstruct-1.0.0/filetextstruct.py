import os

def _ensure_dir(path):
    """
    Create a directory if it does not already exist.
    """
    if path and not os.path.exists(path):
        os.makedirs(path, exist_ok=True)

def create_file(path, content=""):
    """
    Create a file with the given content.
    Automatically creates parent directories if needed.
    """
    dirpath = os.path.dirname(path)
    _ensure_dir(dirpath)

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def create_folder(path):
    """
    Create a directory (including parents) if it does not exist.
    """
    os.makedirs(path, exist_ok=True)

def create_from_dict(base_path, structure):
    """
    Create a directory tree from a dictionary structure.

    Example structure:
    {
       "src": {
           "main.c": "int main(){}",
           "util.c": ""
       },
       "README.md": "# Project\n"
    }
    """
    for name, value in structure.items():
        full_path = os.path.join(base_path, name)

        # Folder → nested dictionary
        if isinstance(value, dict):
            create_folder(full_path)
            create_from_dict(full_path, value)

        # File → string content
        elif isinstance(value, str):
            create_file(full_path, value)

        else:
            raise ValueError(f"Unsupported value type: {type(value)}")

def create_from_folder(base_path):
    """
    Create a folder only. This allows usage like:
    filetextstruct.create("project/")
    """
    create_folder(base_path)

def create(base_path, structure=None):
    """
    Universal entry point for the library.

    Usage:
        create("project/")                 → create folder only
        create("project/", dict_structure) → create folder + tree
    """
    if structure is None:
        create_folder(base_path)
    else:
        create_folder(base_path)
        create_from_dict(base_path, structure)

def generate_tree(structure: dict, root_name: str = "") -> str:
    """
    Generate a text tree representation of a folder structure.

    Example:
        structure = {
            "src": {
                "main.c": "...",
                "utils": {"helper.c": "..."}
            },
            "README.md": "text"
        }

    Returns:
        project/
         ├── src/
         │     ├── main.c
         │     └── utils/
         │           └── helper.c
         └── README.md
    """

    lines = []

    def walk(tree: dict, prefix: str = ""):
        keys = list(tree.keys())
        last = len(keys) - 1

        for i, key in enumerate(keys):
            is_last = (i == last)
            connector = "└── " if is_last else "├── "

            lines.append(prefix + connector + key)

            # If value is dict → directory
            if isinstance(tree[key], dict):
                new_prefix = prefix + ("    " if is_last else "│   ")
                walk(tree[key], new_prefix)

    if root_name:
        lines.append(root_name + "/")
        walk(structure, " ")
    else:
        walk(structure)

    return "\n".join(lines)
