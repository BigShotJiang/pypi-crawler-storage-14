# filetextstruct

`filetextstruct` is a small Python library for generating and creating folder/file structures from dictionaries.  
It can also generate a visual tree representation (like `tree` command) without creating any files.


## Features

- Create folder/file structures from a Python dictionary  
- Generate tree-like text output  
- Simple API for use in build scripts or generators  
- Pure Python, no dependencies


## Installation

pip install filetextstruct



## Usage Example (creating files)
from filetextstruct import create_structure

project = {
    "src": {
        "main.c": "int main() {return 0;}",
        "utils": {
            "helper.c": "void helper() {}"
        }
    },
    "README.md": "My project"
}

create_structure("project", project)

## Usage Example (printing tree)
from filetextstruct import generate_tree

structure = {
    "src": {
        "main.c": "",
        "utils": {
            "helper.c": ""
        }
    },
    "README.md": ""
}

print(generate_tree(structure, "project"))

## Example Output
project/
 ├── src
 │   ├── main.c
 │   └── utils
 │       └── helper.c
 └── README.md

## License

MIT License