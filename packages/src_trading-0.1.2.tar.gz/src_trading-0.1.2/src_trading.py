import pandas as pd
import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt
import os
import itertools
from typing import Union, List, Dict, Optional, Any, Callable, Tuple
# Importaciones necesarias de librerías externas para indicadores que SÍ funcionan
from ta.trend import EMAIndicator
from ta.momentum import RSIIndicator # Esta sigue siendo necesaria para la estrategia RSI

# --- CONFIGURACIÓN GLOBAL ---
plt.style.use('seaborn-v0_8-darkgrid')
ANNUALIZATION_FACTOR = 252 

# --- INDICADORES INTERNOS (SOLUCIÓN DE DEPENDENCIA) ---

class SuperTrend:
    """
    Clase para calcular el indicador SuperTrend.
    Implementación self-contained para evitar dependencias externas problemáticas.
    """
    def __init__(self, high: pd.Series, low: pd.Series, close: pd.Series, period: int = 10, multiplier: float = 3.0):
        self.high = high
        self.low = low
        self.close = close
        self.period = period
        self.multiplier = multiplier

    def calculate(self) -> Tuple[pd.Series, pd.Series]:
        # Creamos un DataFrame con los datos de entrada, manteniendo el índice original
        df = pd.DataFrame({
            'high': self.high,
            'low': self.low,
            'close': self.close
        })
        
        # 1. Cálculo del HL2
        hl2 = (df['high'] + df['low']) / 2
        
        # 2. Cálculo del True Range (TR) y Average True Range (ATR)
        close_prev = df['close'].shift(1)

        # Vectorización para el True Range (TR)
        tr = np.maximum.reduce([
            df['high'] - df['low'], 
            np.abs(df['high'] - close_prev), 
            np.abs(df['low'] - close_prev)
        ])

        # Cálculo del ATR como la media móvil simple (SMA) del TR
        df['atr'] = pd.Series(tr, index=df.index).rolling(self.period).mean()

        # 3. Cálculo de las Bandas (Upperband y Lowerband)
        df['upperband'] = hl2 + (self.multiplier * df['atr'])
        df['lowerband'] = hl2 - (self.multiplier * df['atr'])

        # Inicialización de la columna 'supertrend' (True = Alcista, False = Bajista)
        df['supertrend'] = True 
        
        # Lógica iterativa para SuperTrend (este cálculo no es fácilmente vectorizable sin Numba)
        # Rellenamos NaNs del inicio con True para la primera iteración (aunque se ignoran por el rango)
        df['supertrend'] = df['supertrend'].fillna(True) 
        
        for i in range(1, len(df)):
            # Lógica para cambiar de tendencia (SuperTrend)
            if df['close'].iloc[i] > df['upperband'].iloc[i - 1]:
                df.at[df.index[i], 'supertrend'] = True  # Alcista
            elif df['close'].iloc[i] < df['lowerband'].iloc[i - 1]:
                df.at[df.index[i], 'supertrend'] = False # Bajista
            else:
                # Mantiene la tendencia anterior
                df.at[df.index[i], 'supertrend'] = df.at[df.index[i - 1], 'supertrend']

                # Lógica para modificar la banda (seguir el mercado)
                if df.at[df.index[i], 'supertrend'] is True:
                    # Si es alcista, la banda inferior solo puede subir
                    df.at[df.index[i], 'lowerband'] = max(df.at[df.index[i], 'lowerband'], df.at[df.index[i - 1], 'lowerband'])

                if df.at[df.index[i], 'supertrend'] is False:
                    # Si es bajista, la banda superior solo puede bajar
                    df.at[df.index[i], 'upperband'] = min(df.at[df.index[i], 'upperband'], df.at[df.index[i - 1], 'upperband'])

        # 5. Línea final del SuperTrend (el valor es la banda opuesta a la tendencia)
        df['supertrend_line'] = df.apply(
            lambda row: row['lowerband'] if row['supertrend'] else row['upperband'], axis=1
        )
        
        # Shiftar por 1 para usar los valores del día anterior para el trading (ejecución al cierre)
        df['supertrend_line'] = df['supertrend_line'].shift(1)
        df['supertrend'] = df['supertrend'].shift(1)
        
        return df['supertrend_line'], df['supertrend']


# --- 1. FUNCIONES DE UTILIDAD (Privadas/Internas de la Librería) ---

def _normalize_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normaliza los nombres de las columnas a 'Open', 'High', 'Low', 'Close', 'Volume'.
    """
    df = df.copy() # Copia segura del input
    col_map = {c.lower().replace(' ', ''): c for c in df.columns}
    rename_map = {}
    
    # Mantenemos las columnas de precios/volumen como float64 (default) o las convertimos
    # si el DataFrame de entrada ya usa un dtype menor.
    if 'open' in col_map: rename_map[col_map['open']] = 'Open'
    if 'high' in col_map: rename_map[col_map['high']] = 'High'
    if 'low' in col_map: rename_map[col_map['low']] = 'Low'
    if 'volume' in col_map: rename_map[col_map['volume']] = 'Volume'
    
    if 'close' in col_map:
        rename_map[col_map['close']] = 'Close'
    elif 'adjclose' in col_map:
        rename_map[col_map['adjclose']] = 'Adj Close' # Mantener el nombre original
        
    df.rename(columns=rename_map, inplace=True)
    
    # Seleccionar 'Close' o 'Adj Close' como el precio principal
    if 'Close' not in df.columns and 'Adj Close' in df.columns:
        df.rename(columns={'Adj Close': 'Close'}, inplace=True)

    required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
    available_cols = [col for col in required_cols if col in df.columns]
    
    if 'Close' not in available_cols:
        raise ValueError("El DataFrame debe contener una columna 'Close' o 'Adj Close'.")
        
    return df[available_cols] 


def _load_data_internal(
    ticker: Union[str, List[str]], 
    timeframe: str, 
    start: Optional[str], 
    end: Optional[str], 
    data_source: Union[str, Dict[str, pd.DataFrame]],
    path: Optional[str]
) -> Dict[str, pd.DataFrame]:
    """Carga datos históricos, estandarizando el formato OHLCV."""
    if not isinstance(ticker, list):
        ticker = [ticker]

    loaded_data = {}
    
    # Lógica de carga desde yfinance
    if isinstance(data_source, str) and data_source.lower() == 'yfinance':
        try:
            df_full = yf.download(ticker, start=start, end=end, interval=timeframe, progress=False)
            
            if len(ticker) == 1:
                try:
                    loaded_data[ticker[0]] = _normalize_ohlcv(df_full)
                except ValueError as e:
                    print(f"ERROR: {e}")
            else:
                for t in ticker:
                    try:
                        # Extraer el sub-DataFrame para cada ticker
                        df_t = df_full.xs(t, axis=1, level=1, drop_level=False) 
                        loaded_data[t] = _normalize_ohlcv(df_t) 
                    except (KeyError, ValueError) as e:
                        print(f"ERROR: No se pudieron normalizar los datos para {t}. {e}")
        except Exception as e:
            print(f"ERROR al cargar datos desde YFinance: {e}")

    elif isinstance(data_source, dict):
        for t, df in data_source.items():
            try:
                loaded_data[t] = _normalize_ohlcv(df)
            except ValueError as e:
                print(f"ERROR: Datos inyectados para {t} no válidos: {e}")
                
    # Validación final: asegurar que Close no tiene NaNs
    for t, df in list(loaded_data.items()): 
        if 'Close' not in df.columns: continue 
        df.dropna(subset=['Close'], inplace=True)
        # Asegurar que los índices sean DatetimeIndex para el backtest
        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index)
            
    return loaded_data


def _calculate_sharpe_ratio(returns: pd.Series, risk_free_rate: float, annualization_factor: int) -> float:
    """Calcula el Ratio de Sharpe (anualizado)."""
    # Convertir Tasa RF anual a diaria
    rf_daily = (1 + risk_free_rate) ** (1 / annualization_factor) - 1 if risk_free_rate != 0 else 0
    
    excess_daily_return = returns.mean() - rf_daily
    std_daily_return = returns.std()
    
    if std_daily_return == 0 or np.isnan(std_daily_return):
        return 0.0 # Evitar divisiones por cero si no hay volatilidad

    sharpe_ratio = (excess_daily_return * annualization_factor) / (std_daily_return * np.sqrt(annualization_factor))
    return sharpe_ratio.item() # .item() para desempacar de NumPy

def _calculate_sortino_ratio(returns: pd.Series, risk_free_rate: float, annualization_factor: int) -> float:
    """Calcula el Ratio de Sortino (anualizado)."""
    rf_daily = (1 + risk_free_rate) ** (1 / annualization_factor) - 1 if risk_free_rate != 0 else 0
    excess_returns = returns - rf_daily
    neg_excess_returns = np.minimum(0, excess_returns)
    mean_neg_sq = np.mean(neg_excess_returns**2)
    downside_dev = np.sqrt(mean_neg_sq)
    
    if downside_dev == 0 or np.isnan(downside_dev):
        return 0.0

    avg_daily_excess_return = excess_returns.mean()
    sortino_ratio = (avg_daily_excess_return * annualization_factor) / (downside_dev * np.sqrt(annualization_factor))
    return sortino_ratio.item()

def _calculate_max_drawdown(cumulative_returns: pd.Series) -> float:
    """Calcula el Max Drawdown."""
    peak = cumulative_returns.cummax()
    # Usamos np.where para vectorización
    drawdown = np.where(peak > 0, (cumulative_returns - peak) / peak, 0)
    return drawdown.min() * 100

def _calculate_costs(df: pd.DataFrame, commission_pct: float, slippage_pct: float) -> pd.Series:
    """
    Implementación Vectorizada de Costos de Transacción (Comisión + Slippage).
    Los costos se aplican solo cuando la posición cambia (entrada, salida, reversión).
    """
    # Delta de posición: indica los días donde hay un trade (entrada o salida)
    delta_position = (df['Position'].shift(1) - df['Position']).abs().fillna(0)
    
    # 1. Impacto de Comisión (en términos de retorno decimal)
    commission_impact = delta_position * commission_pct 
    
    # 2. Impacto de Slippage (reducción en el retorno del día de ejecución)
    slippage_reduction = (df['Returns'].abs() * slippage_pct).fillna(0)
    # Identificar días donde se ejecuta un trade (la posición *a la apertura* del día siguiente será diferente de la actual)
    slippage_reduction_on_trade = (delta_position.shift(-1).fillna(0) > 0) * slippage_reduction
    
    # Costo total (en términos de impacto en el retorno)
    total_cost_impact = commission_impact + slippage_reduction_on_trade.abs()
    
    return total_cost_impact.astype(np.float32)

def _split_data_walk_forward(df: pd.DataFrame, window_size: int, step: int) -> List[Dict[str, pd.DataFrame]]:
    """
    Divide los datos en ventanas superpuestas o no superpuestas para Walk-Forward.
    """
    splits = []
    n = len(df)
    i = window_size # Inicia la primera prueba OOS después de la primera ventana IS

    while i < n:
        # 1. Training Window (In-Sample, IS)
        train_end = i
        train_start = max(0, train_end - window_size)
        
        # 2. Testing Window (Out-of-Sample, OOS)
        test_end = min(n, i + step)
        
        if test_end > train_end:
            splits.append({
                'train': df.iloc[train_start:train_end],
                'test': df.iloc[train_end:test_end]
            })
        
        i += step
        
    return splits


def _run_single_backtest(
    data: Dict[str, pd.DataFrame], 
    strategy_class: type, 
    params: Dict[str, Any],
    initial_capital: float, 
    risk_free_rate: float,
    commission_pct: float, 
    slippage_pct: float
) -> Tuple[float, Optional[pd.DataFrame]]:
    """
    Función auxiliar para ejecutar un backtest con parámetros específicos.
    Devuelve la métrica de fitness (Sharpe Ratio) y el DataFrame de resultados.
    """
    # Crear una instancia de la estrategia con los nuevos parámetros
    temp_strategy = strategy_class(**params)
    
    # Crear una instancia temporal de TradingLab (capital 1.0 para retornos puros)
    temp_lab = TradingLab(
        initial_capital=initial_capital, 
        risk_free_rate=risk_free_rate, 
        commission_pct=commission_pct, 
        slippage_pct=slippage_pct,
        print_output=False # Omitir el output de inicialización
    )
    
    # Inyectar datos y estrategia (saltando la lógica de carga/set de la clase principal)
    temp_lab.raw_data = data 
    temp_lab.strategy = temp_strategy

    try:
        # Ejecutar el backtest (sin salida de consola)
        temp_lab.run(print_output=False) 
        
        if temp_lab.portfolio_results is not None:
            returns = temp_lab.portfolio_results['Portfolio_Return']
            # Métrica de fitness: Sharpe Ratio (maximizamos)
            sharpe = _calculate_sharpe_ratio(returns, risk_free_rate, ANNUALIZATION_FACTOR)
            return sharpe, temp_lab.portfolio_results
        
    except Exception as e:
        # print(f"Error en backtest con params {params}: {e}")
        pass
        
    return 0.0, None # Devolver 0.0 (el peor Sharpe) en caso de error

def _extract_trades(df: pd.DataFrame, ticker: str) -> pd.DataFrame:
    """
    Extrae la secuencia completa de trades. (Implementación iterativa de baja perf.)
    """
    trades = []
    in_trade = False
    entry_date = None
    entry_position = 0
    entry_price = 0
    
    # Shiftamos la Posición para simular la ejecución al cierre del día de la señal
    df['Position_Exec'] = df['Position'].shift(1).fillna(0) 

    for i in range(1, len(df)):
        current_pos = df.iloc[i]['Position_Exec']
        prev_pos = df.iloc[i-1]['Position_Exec']
        date = df.index[i]
        price = df.iloc[i]['Close']
        
        # Inicio de un Trade (Posición cambia de 0 a != 0, o hay reversión)
        if current_pos != 0 and (prev_pos == 0 or prev_pos != current_pos):
            if in_trade:
                # Cierre del trade anterior por reversión
                exit_date = date
                # Calcular el retorno del trade: (1 + R1) * (1 + R2) * ... - 1
                pnl_pct = (1 + df.loc[entry_date:exit_date]['Strategy_Returns']).prod() - 1
                
                trades.append({
                    'Ticker': ticker,
                    'Entry_Date': entry_date,
                    'Exit_Date': exit_date,
                    'Position_Type': 'Long' if entry_position > 0 else 'Short',
                    'Duration': (exit_date - entry_date).days,
                    'Entry_Price': entry_price,
                    'Exit_Price': price,
                    'Trade_Return (%)': pnl_pct * 100,
                    'Result': 'Win' if pnl_pct > 0 else ('Loss' if pnl_pct < 0 else 'Even')
                })
                in_trade = False 

            # Abrir nuevo trade
            in_trade = True
            entry_date = date
            entry_position = current_pos
            entry_price = price

        # Cierre de un Trade (Posición cambia a 0)
        elif current_pos == 0 and prev_pos != 0:
            exit_date = date
            
            if entry_date is None: 
                in_trade = False
                continue
                
            pnl_pct = (1 + df.loc[entry_date:exit_date]['Strategy_Returns']).prod() - 1
            
            trades.append({
                'Ticker': ticker,
                'Entry_Date': entry_date,
                'Exit_Date': exit_date,
                'Position_Type': 'Long' if prev_pos > 0 else 'Short',
                'Duration': (exit_date - entry_date).days,
                'Entry_Price': entry_price,
                'Exit_Price': price,
                'Trade_Return (%)': pnl_pct * 100,
                'Result': 'Win' if pnl_pct > 0 else ('Loss' if pnl_pct < 0 else 'Even')
            })
            in_trade = False
            entry_date = None 

    # Cierre del último trade si el backtest termina con una posición abierta
    if in_trade and entry_date is not None:
        last_date = df.index[-1]
        last_price = df['Close'].iloc[-1]
        pnl_pct = (1 + df.loc[entry_date:last_date]['Strategy_Returns']).prod() - 1
        
        trades.append({
            'Ticker': ticker,
            'Entry_Date': entry_date,
            'Exit_Date': last_date,
            'Position_Type': 'Long' if entry_position > 0 else 'Short',
            'Duration': (last_date - entry_date).days,
            'Entry_Price': entry_price,
            'Exit_Price': last_price,
            'Trade_Return (%)': pnl_pct * 100,
            'Result': 'Open' 
        })

    return pd.DataFrame(trades)

# --- 2. CLASE BASE DE ESTRATEGIA (Interfaz para el usuario) ---
class BaseStrategy:
    """Clase base abstracta para todas las estrategias de trading."""
    def __init__(self, name="Base Strategy"):
        self.name = name
        # Atributo requerido para la optimización:
        self.params = {} 

    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError("El método generate_signals debe ser implementado por la subclase.")

    def __str__(self):
        return f"{self.name} (Params: {self.params})"

# --- 3. IMPLEMENTACIÓN DE ESTRATEGIAS (Optimizadas con float32) ---

class EMA_Cross(BaseStrategy):
    """Estrategia de Cruce de Medias Móviles Exponenciales."""
    def __init__(self, short=20, long=50, hold_position=True):
        self.short = short
        self.long = long
        self.hold_position = hold_position
        self.params = {'short': short, 'long': long, 'hold_position': hold_position}
        super().__init__(f"EMA Cross")

    def generate_signals(self, df):
        # Uso de .astype(np.float32) para reducir el uso de memoria
        df['EMA_Short'] = EMAIndicator(close=df['Close'], window=self.short, fillna=False).ema_indicator().astype(np.float32)
        df['EMA_Long'] = EMAIndicator(close=df['Close'], window=self.long, fillna=False).ema_indicator().astype(np.float32)
        
        signals = pd.Series(0, index=df.index, dtype=np.float32)
        cross_up = (df['EMA_Short'] > df['EMA_Long']) & (df['EMA_Short'].shift(1) <= df['EMA_Long'].shift(1))
        cross_down = (df['EMA_Short'] < df['EMA_Long']) & (df['EMA_Short'].shift(1) >= df['EMA_Long'].shift(1))
        
        signals.loc[cross_up] = 1.0
        signals.loc[cross_down] = -1.0
        
        if self.hold_position:
            df['Position'] = signals.replace(to_replace=0, method='ffill').fillna(0.0)
        else:
            df['Position'] = signals.fillna(0.0)
            
        df['Position'] = df['Position'].fillna(0.0).astype(np.float32)
        return df

# Implementaciones de estrategias básicas (RSI y SuperTrend)
class RSI_MeanReversion(BaseStrategy):
    def __init__(self, window=14, entry_low=30, exit_high=70, hold_position=True):
        self.window = window
        self.entry_low = entry_low
        self.exit_high = exit_high
        self.hold_position = hold_position
        self.params = {'window': window, 'entry_low': entry_low, 'exit_high': exit_high, 'hold_position': hold_position}
        super().__init__(f"RSI Mean Reversion")

    def generate_signals(self, df):
        # Uso de ta.momentum.RSIIndicator (dependencia externa que SÍ funciona)
        df['RSI'] = RSIIndicator(close=df['Close'], window=self.window, fillna=False).rsi().astype(np.float32)
        
        df['Position'] = np.where(df['RSI'] < self.entry_low, 1.0, 
                         np.where(df['RSI'] > self.exit_high, -1.0, 0.0))
        
        if self.hold_position:
            df['Position'] = df['Position'].replace(to_replace=0, method='ffill').fillna(0.0)
        else:
             df['Position'] = df['Position'].fillna(0.0) 
             
        df['Position'] = df['Position'].fillna(0.0).astype(np.float32)
        return df

class SuperTrendStrategy(BaseStrategy):
    def __init__(self, period=10, multiplier=3.0, hold_position=True):
        self.period = period
        self.multiplier = multiplier
        self.hold_position = hold_position
        self.params = {'period': period, 'multiplier': multiplier, 'hold_position': hold_position}
        super().__init__(f"SuperTrend")

    def generate_signals(self, df):
        # Usamos la clase SuperTrend implementada internamente (Solución de dependencia)
        # Corregido: eliminado el doble signo de igualdad 'low=df=df['Low']' -> 'low=df['Low']'
        st = SuperTrend(
            high=df['High'], low=df['Low'], close=df['Close'], period=self.period, multiplier=self.multiplier
        )
        line, trend = st.calculate()
        
        # 'trend' es True (Alcista) o False (Bajista). Mapeamos a 1.0 y -1.0
        signals = np.where(trend == True, 1.0, -1.0)
        signals = pd.Series(signals, index=df.index, dtype=np.float32)

        if self.hold_position:
            # En esta estrategia, la señal de posición es continua (Long o Short)
            # Aunque en SuperTrend ya se mantiene la posición por definición,
            # lo dejamos explícito si cambiamos la lógica a un cruce puntual.
            df['Position'] = signals.replace(to_replace=0, method='ffill').fillna(0.0)
        else:
             df['Position'] = signals.fillna(0.0) 
             
        df['Position'] = df['Position'].fillna(0.0).astype(np.float32)
        return df


# --- 4. CLASE BASE DE OPTIMIZACIÓN ---
class ParameterOptimizer:
    """
    Clase base para optimizar los hiperparámetros de una estrategia.
    Implementa Búsqueda en Rejilla (Grid Search) por defecto.
    """
    def __init__(self, strategy_class: type, param_grid: Dict[str, List[Any]]):
        self.strategy_class = strategy_class
        self.param_grid = param_grid
        self.best_params = None
        self.best_score = -np.inf

    def optimize(self, 
                 data: Dict[str, pd.DataFrame], 
                 initial_capital: float,
                 risk_free_rate: float,
                 commission_pct: float,
                 slippage_pct: float,
                 fitness_metric: Callable = _calculate_sharpe_ratio 
                 ) -> Dict[str, Any]:
        """
        Realiza la búsqueda en rejilla sobre los datos de entrenamiento.
        """
        # Generar todas las combinaciones de parámetros
        keys = self.param_grid.keys()
        values = self.param_grid.values()
        
        # Iteración sobre todas las combinaciones
        all_combinations = [dict(zip(keys, v)) for v in itertools.product(*values)]
        
        print(f"-> Optimizando {len(all_combinations)} combinaciones...")
        
        for params in all_combinations:
            # Ejecutar un backtest para esta combinación de parámetros
            score, _ = _run_single_backtest(
                data, self.strategy_class, params, 
                initial_capital, risk_free_rate, commission_pct, slippage_pct
            )
            
            # Comprobar si el score actual es el mejor
            if score > self.best_score:
                self.best_score = score
                self.best_params = params

        print(f"-> Optimización finalizada. Mejor Score ({fitness_metric.__name__}): {self.best_score:.4f}")
        return self.best_params if self.best_params is not None else {}

# --- 5. CLASE PRINCIPAL DE LA LIBRERÍA: TradingLab ---

class TradingLab:
    """
    Entorno unificado para carga de datos, backtesting, análisis de métricas 
    y visualización de estrategias de trading multi-activo.
    """
    def __init__(self, 
                 initial_capital: float = 10000.0, 
                 risk_free_rate: float = 0.02,
                 commission_pct: float = 0.001, 
                 slippage_pct: float = 0.0005,
                 print_output: bool = True 
                 ):
        self.initial_capital = initial_capital
        self.risk_free_rate = risk_free_rate 
        self.commission_pct = commission_pct 
        self.slippage_pct = slippage_pct 
        self.print_output = print_output # Controla la salida de consola
        self.raw_data: Optional[Dict[str, pd.DataFrame]] = None
        self.strategy: Optional[BaseStrategy] = None
        self.processed_data: Dict[str, pd.DataFrame] = {}
        self.portfolio_results: Optional[pd.DataFrame] = None
        self.trade_log: Optional[pd.DataFrame] = None 
        self.metrics: Optional[Dict[str, float]] = None
        self.walk_forward_results: Optional[pd.DataFrame] = None 
        
        if self.print_output:
            print(f"TradingLab inicializado. Capital: {initial_capital:.2f}. Tasa RF: {risk_free_rate*100:.2f}%. Costo Transacción: {commission_pct*100:.2f}% + {slippage_pct*100:.2f}% slippage.")

    # El método load_data se mantiene igual
    def load_data(self, 
                 ticker: Union[str, List[str]], 
                 timeframe: str = '1d', 
                 start: Optional[str] = '2020-01-01', 
                 end: Optional[str] = None, 
                 data_source: Union[str, Dict[str, pd.DataFrame]] = 'yfinance',
                 path: Optional[str] = None):
        """Carga datos históricos en el laboratorio."""
        self.ticker = ticker if isinstance(ticker, list) else [ticker]
        self.raw_data = _load_data_internal(ticker, timeframe, start, end, data_source, path)
        if not self.raw_data:
            if self.print_output: print("ERROR: La carga de datos falló. Verifique la configuración.")
        else:
            if self.print_output: print(f"Datos cargados exitosamente para {list(self.raw_data.keys())}.")
        return self 

    # El método set_strategy se mantiene igual
    def set_strategy(self, strategy: BaseStrategy):
        """Asigna la estrategia de trading que se va a evaluar."""
        if not isinstance(strategy, BaseStrategy):
            raise TypeError("La estrategia debe ser una instancia de BaseStrategy o sus subclases.")
        self.strategy = strategy
        if self.print_output:
            print(f"Estrategia '{self.strategy.name}' asignada.")
        return self 

    def run(self, allocation_weights: Optional[Dict[str, float]] = None, print_output: bool = True):
        """
        Ejecuta el backtest completo, aplica la estrategia, calcula el rendimiento y aplica costos.
        """
        if not self.raw_data or not self.strategy:
            if print_output: print("ERROR: Debe cargar datos y establecer una estrategia antes de ejecutar.")
            return

        if print_output: 
            print(f"\n--- Ejecutando Backtest: {self.strategy} ---")
            
        self.processed_data.clear()
        all_trades = []

        # 1. Aplicar estrategia a cada activo, calcular retornos individuales y aplicar costos
        for t, df in self.raw_data.items():
            try:
                df_signals = self.strategy.generate_signals(df) 
                
                # Retornos y cálculo vectorizado con dtype float32
                df_signals['Returns'] = df_signals['Close'].pct_change().astype(np.float32)
                
                # Retorno Bruto (antes de costos)
                df_signals['Gross_Strategy_Returns'] = (df_signals['Returns'] * df_signals['Position'].shift(1)).astype(np.float32)
                
                # Cálculo de Costos (Vectorizado)
                df_signals['Transaction_Cost_Impact'] = _calculate_costs(
                    df_signals, self.commission_pct, self.slippage_pct
                )
                
                # Retorno Neto 
                df_signals['Strategy_Returns'] = (df_signals['Gross_Strategy_Returns'] - df_signals['Transaction_Cost_Impact']).astype(np.float32)
                
                # Limpieza y almacenamiento
                df_signals.dropna(subset=['Close', 'Position', 'Strategy_Returns'], inplace=True)
                df_signals.fillna(0.0, inplace=True)
                self.processed_data[t] = df_signals

                # Generar Log de Trades (lógica iterativa)
                asset_trades = _extract_trades(df_signals, t)
                all_trades.append(asset_trades)
                
            except Exception as e:
                if print_output: print(f"ERROR aplicando estrategia a {t}: {e}. Saltando activo.")
        
        if not self.processed_data:
            if print_output: print("ERROR: Ningún activo pudo ser procesado con éxito.")
            return

        # Consolidar Log de Trades
        if all_trades:
            self.trade_log = pd.concat(all_trades, ignore_index=True)
        else:
            self.trade_log = pd.DataFrame()

        # 2. Consolidación de Portafolio
        strategy_returns_series = {t: df['Strategy_Returns'].rename(t) for t, df in self.processed_data.items()}
        portfolio_df = pd.DataFrame(strategy_returns_series).fillna(0.0).astype(np.float32)
        
        tickers_used = list(portfolio_df.columns)
        num_assets = len(tickers_used)
        
        # Lógica de asignación de pesos (Buy and Hold implícito si no hay weights)
        if allocation_weights:
            weights = np.array([allocation_weights.get(t, 0) for t in tickers_used], dtype=np.float32)
            if weights.sum() == 0:
                 weights = np.array([1/num_assets] * num_assets, dtype=np.float32)
            else:
                weights = weights / weights.sum() # Normalizar pesos
        else:
            weights = np.array([1/num_assets] * num_assets, dtype=np.float32)
        
        # Cálculo del Retorno Diario del Portafolio (vectorizado)
        portfolio_df['Portfolio_Return'] = (portfolio_df[tickers_used] * weights).sum(axis=1)
        
        # Cálculo del Rendimiento Acumulado
        portfolio_df['Cumulative_Strategy'] = (1.0 + portfolio_df['Portfolio_Return']).cumprod().fillna(1.0)
        portfolio_df['Cumulative_Strategy'] *= self.initial_capital
        
        self.portfolio_results = portfolio_df
        if print_output: print("Backtest completado, costos aplicados y resultados consolidados.")
        
        return self 

    def analyze(self, print_output: bool = True) -> Dict[str, Any]:
        """
        Calcula y presenta las métricas clave de rendimiento y trade-level.
        """
        if self.portfolio_results is None:
            if print_output: print("ERROR: No hay resultados para analizar. Ejecute .run() primero.")
            return {}

        cumulative_strategy = self.portfolio_results['Cumulative_Strategy']
        portfolio_returns = self.portfolio_results['Portfolio_Return']

        days = (cumulative_strategy.index[-1] - cumulative_strategy.index[0]).days
        years = days / ANNUALIZATION_FACTOR if days > 0 else 1 
        if years < 0.1: years = 1.0 
        
        final_capital = cumulative_strategy.iloc[-1]
        total_return = (final_capital / self.initial_capital - 1) * 100
        cagr = ((final_capital / self.initial_capital) ** (1/years) - 1) * 100
        max_drawdown = _calculate_max_drawdown(cumulative_strategy)
        
        sharpe_ratio = _calculate_sharpe_ratio(portfolio_returns, self.risk_free_rate, ANNUALIZATION_FACTOR)
        sortino_ratio = _calculate_sortino_ratio(portfolio_returns, self.risk_free_rate, ANNUALIZATION_FACTOR)
        
        calmar_ratio = cagr / abs(max_drawdown) if max_drawdown != 0 else np.inf
        mar_ratio = calmar_ratio

        trade_metrics = {}
        if self.trade_log is not None and not self.trade_log.empty:
            closed_trades = self.trade_log[self.trade_log['Result'] != 'Open']
            
            if not closed_trades.empty:
                total_trades = len(closed_trades)
                winning_trades = closed_trades[closed_trades['Result'] == 'Win']
                losing_trades = closed_trades[closed_trades['Result'] == 'Loss']
                
                win_rate = len(winning_trades) / total_trades * 100
                avg_win = winning_trades['Trade_Return (%)'].mean()
                avg_loss = losing_trades['Trade_Return (%)'].mean()
                
                expectancy = (win_rate/100 * avg_win) - ((1 - win_rate/100) * abs(avg_loss)) if avg_loss else (win_rate/100 * avg_win)
                
                trade_metrics = {
                    "Total Trades Cerrados": total_trades,
                    "Win Rate (%)": round(win_rate, 2),
                    "Avg Win (%)": round(avg_win, 2) if not np.isnan(avg_win) else 0.0,
                    "Avg Loss (%)": round(avg_loss, 2) if not np.isnan(avg_loss) else 0.0,
                    "Expectativa (%) (Trade)": round(expectancy, 2) if not np.isnan(expectancy) else 0.0,
                    "Holding Period Promedio (días)": round(closed_trades['Duration'].mean(), 1)
                }

        metrics = {
            "Estrategia": str(self.strategy),
            "Activos": self.ticker,
            "Capital Inicial": self.initial_capital,
            "Periodo Inicio": cumulative_strategy.index[0].date().isoformat(),
            "Periodo Fin": cumulative_strategy.index[-1].date().isoformat(),
            "Retorno Total (%)": round(total_return, 2),
            "CAGR (%)": round(cagr, 2), 
            "Max Drawdown (%)": round(max_drawdown, 2),
            "Ratio de Sharpe": round(sharpe_ratio, 2),
            "Ratio de Sortino": round(sortino_ratio, 2),
            "Ratio de Calmar": round(calmar_ratio, 2), 
            "Ratio MAR": round(mar_ratio, 2), 
            **trade_metrics 
        }
        self.metrics = metrics
        
        if print_output:
            print("\n--- RESUMEN DE MÉTRICAS CONSOLIDADAS ---")
            for key, value in metrics.items():
                print(f"{key}: {value}")
            print("-" * 37)
        
        return metrics

    def plot(self):
        """Genera un gráfico del rendimiento acumulado del portafolio consolidado vs Buy & Hold."""
        if self.portfolio_results is None:
            print("ERROR: No hay resultados para graficar. Ejecute .run() primero.")
            return

        fig, ax = plt.subplots(figsize=(14, 7))
        
        # 1. Rendimiento de la Estrategia
        ax.plot(self.portfolio_results.index, 
                self.portfolio_results['Cumulative_Strategy'], 
                label=f"Estrategia: {self.strategy}", 
                color='#1f77b4', linewidth=2)
        
        # 2. Buy & Hold Consolidado (Benchmark)
        bh_returns_series = {t: df['Returns'].rename(t) for t, df in self.processed_data.items()}
        bh_df = pd.DataFrame(bh_returns_series).fillna(0.0)
        bh_df['BH_Return'] = bh_df.mean(axis=1) # Retorno promedio diario de Buy & Hold (igual peso)
        bh_df['Cumulative_BH'] = (1.0 + bh_df['BH_Return']).cumprod().fillna(1.0) * self.initial_capital
        
        ax.plot(bh_df.index, bh_df['Cumulative_BH'], 
                label=f"Benchmark (Buy & Hold, {len(self.ticker)} Activos)", 
                color='#ff7f0e', linestyle='--', linewidth=1)

        # Formato final del gráfico
        ax.set_title(f"Rendimiento del Portafolio: {self.strategy}", fontsize=16, pad=20)
        ax.set_xlabel("Fecha", fontsize=12)
        ax.set_ylabel("Capital Acumulado (€/USD)", fontsize=12)
        ax.legend(loc='upper left', fontsize=10)
        ax.grid(True, linestyle=':', alpha=0.6)
        plt.tight_layout()
        plt.show()

    def walk_forward_analysis(self, 
                            window_size: int = 500, 
                            step: int = 100,
                            param_grid: Optional[Dict[str, List[Any]]] = None,
                            fitness_metric: Callable = _calculate_sharpe_ratio
                            ):
        """
        Realiza el análisis Walk-Forward (WFA) con Optimización en la Ventana de Entrenamiento (IS).
        
        Args:
            window_size (int): Tamaño de la ventana de entrenamiento (In-Sample, IS).
            step (int): Tamaño del paso de avance (Out-of-Sample, OOS).
            param_grid (Dict): Diccionario con los parámetros y sus rangos a optimizar.
            fitness_metric (Callable): Función a maximizar en la optimización IS.
        """
        if not self.raw_data or not self.strategy:
            print("ERROR: Debe cargar datos y establecer una estrategia antes de ejecutar.")
            return

        if not param_grid:
            print("ERROR: Se requiere 'param_grid' para la optimización WFA. Ej: {'short': [10, 20], 'long': [50, 60]}.")
            return self

        if len(self.raw_data) > 1:
            print("ADVERTENCIA: Walk-Forward Analysis (WFA) actualmente soporta solo un activo. Usando el primer activo cargado.")

        print(f"\n--- Ejecutando Análisis Walk-Forward (Optimización IS / Prueba OOS) ---")
        print(f"Estrategia: {self.strategy.name} | Parámetros: {list(param_grid.keys())}")
        
        ticker = list(self.raw_data.keys())[0]
        master_df = self.raw_data[ticker]

        all_splits = _split_data_walk_forward(master_df, window_size, step)
        oos_results = []
        
        if not all_splits:
            print(f"ERROR: Los datos son insuficientes (len={len(master_df)}) para ventana ({window_size}) y paso ({step}) definidos.")
            return self

        # Acumular retornos OOS para la curva de equity total WFA
        total_oos_returns = pd.Series([], dtype=np.float32)

        for i, split in enumerate(all_splits):
            train_df = split['train']
            test_df = split['test']

            print(f"\nVentana {i + 1}/{len(all_splits)}: IS={train_df.index[0].date().isoformat()} a {train_df.index[-1].date().isoformat()}")
            
            # 1. OPTIMIZACIÓN (IN-SAMPLE)
            optimizer = ParameterOptimizer(self.strategy.__class__, param_grid)
            
            # Ejecutar optimización en la data de entrenamiento
            best_params = optimizer.optimize(
                data={ticker: train_df},
                initial_capital=self.initial_capital,
                risk_free_rate=self.risk_free_rate,
                commission_pct=self.commission_pct,
                slippage_pct=self.slippage_pct
            )
            
            # Crear la estrategia óptima para esta ventana
            optimized_strategy = self.strategy.__class__(**best_params)
            print(f"-> Mejores Parámetros IS: {best_params} (Score: {optimizer.best_score:.4f})")

            # 2. EVALUACIÓN (OUT-OF-SAMPLE)
            temp_lab = TradingLab(
                initial_capital=1.0, # Usar 1.0 para retornos puros
                risk_free_rate=self.risk_free_rate, 
                commission_pct=self.commission_pct, 
                slippage_pct=self.slippage_pct,
                print_output=False
            )
            temp_lab.raw_data = {ticker: test_df} # Inyectar solo la data OOS
            temp_lab.strategy = optimized_strategy
            
            # Ejecutar backtest OOS
            temp_lab.run(print_output=False) 
            metrics = temp_lab.analyze(print_output=False)
            
            # Acumular los retornos OOS
            if temp_lab.portfolio_results is not None:
                total_oos_returns = pd.concat([total_oos_returns, temp_lab.portfolio_results['Portfolio_Return']])

            oos_results.append({
                'Window': i + 1,
                'Opt_IS_Params': str(best_params),
                'Test_Start': test_df.index[0].date().isoformat(),
                'Test_End': test_df.index[-1].date().isoformat(),
                'OOS_CAGR (%)': metrics.get('CAGR (%)', np.nan),
                'OOS_Sharpe': metrics.get('Ratio de Sharpe', np.nan),
                'OOS_MaxDD (%)': metrics.get('Max Drawdown (%)', np.nan),
                'OOS_Return (%)': metrics.get('Retorno Total (%)', np.nan),
            })
            
            print(f"-> Resultados OOS (Sharpe/Retorno): {oos_results[-1]['OOS_Sharpe']:.2f} / {oos_results[-1]['OOS_Return (%)']:.2f}%")

        wf_df = pd.DataFrame(oos_results)
        self.walk_forward_results = wf_df
        
        # 3. RESUMEN FINAL
        print("\n--- RESUMEN DE ROBUSTEZ WALK-FORWARD (OOS) ---")
        print(wf_df[['Window', 'Test_Start', 'Test_End', 'Opt_IS_Params', 'OOS_CAGR (%)', 'OOS_Sharpe']].to_markdown(index=False))
        
        # Métricas consolidadas OOS
        final_sharpe = _calculate_sharpe_ratio(total_oos_returns, self.risk_free_rate, ANNUALIZATION_FACTOR)
        final_cumu = (1.0 + total_oos_returns).cumprod().iloc[-1]
        final_total_return = (final_cumu - 1) * 100
        
        print(f"\nResultado WFA Consolidado:")
        print(f"Sharpe OOS Global: {final_sharpe:.2f}")
        print(f"Retorno OOS Global: {final_total_return:.2f}%")
        print("Una alta consistencia en los resultados OOS (bajo Std Dev) indica robustez.")
        
        return self