TradingLab - src_trading

TradingLab es un entorno unificado y optimizado en Python para el backtesting, análisis y optimización de estrategias de trading algorítmico. Diseñado para manejar múltiples activos y centrado en la robustez a través del análisis Walk-Forward.

Características Principales

Optimización de Rendimiento: Uso de numpy.float32 y operaciones vectorizadas para mejorar la velocidad y reducir el consumo de memoria en backtests con grandes volúmenes de datos.

Análisis Walk-Forward (WFA): Implementación de WFA para probar la solidez de los parámetros optimizados en periodos fuera de la muestra (Out-of-Sample, OOS).

Métricas Financieras Completas: Calcula Sharpe, Sortino, CAGR, Max Drawdown y métricas detalladas a nivel de trade (Win Rate, Expectativa).

Manejo de Costos: Aplicación precisa de comisiones y deslizamiento (slippage) en cada transacción.

Clase Base Extensible: Fácilmente ampliable para crear y probar nuevas estrategias personalizadas.

Instalación

Asegúrate de tener Python 3.9 o superior.

pip install TradingLab-src-trading


(Nota: El nombre del paquete en PyPI puede variar, usa el nombre exacto de tu paquete publicado)

Uso Rápido (Quick Start)

Para iniciar un backtest, simplemente crea una instancia de TradingLab, asigna una estrategia y ejecuta el método run().

from src_trading import TradingLab, EMA_Cross

# 1. Definir la estrategia
strategy = EMA_Cross(short=20, long=50, hold_position=True)

# 2. Inicializar el laboratorio
lab = TradingLab(
    initial_capital=10000.0, 
    commission_pct=0.001,
    slippage_pct=0.0005
)

# 3. Cargar datos y asignar estrategia
lab.load_data(
    ticker='SPY', 
    start='2020-01-01', 
    end='2024-01-01'
).set_strategy(strategy)

# 4. Ejecutar el Backtest y analizar
lab.run()
lab.analyze()
lab.plot()


Estrategias Incluidas

EMA_Cross: Cruce de media móvil exponencial simple (e.g., 20/50 días).

RSI_MeanReversion: Estrategia de reversión a la media basada en el Índice de Fuerza Relativa (RSI).

SuperTrendStrategy: Estrategia de seguimiento de tendencia basada en el indicador SuperTrend.

Análisis Walk-Forward (WFA)

La librería soporta WFA para encontrar parámetros robustos que funcionan tanto en periodos de entrenamiento (In-Sample, IS) como en periodos de prueba (Out-of-Sample, OOS).

from src_trading import TradingLab, EMA_Cross

lab = TradingLab(...)
# ... Cargar datos y asignar estrategia EMA_Cross ...

param_grid = {
    'short': [10, 20, 30],
    'long': [50, 60, 70],
    'hold_position': [True]
}

lab.walk_forward_analysis(
    window_size=500, # Días de entrenamiento (IS)
    step=100,        # Días de prueba (OOS)
    param_grid=param_grid
)

