"""Extra module only in upper package."""

something = 42
