"""Upper package for relative import tests."""

from .extra import something

__all__ = ["something"]
