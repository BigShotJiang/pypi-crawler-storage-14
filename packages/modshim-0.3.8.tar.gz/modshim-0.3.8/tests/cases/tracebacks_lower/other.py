"""A helper module for traceback tests."""

VALUE = 42
