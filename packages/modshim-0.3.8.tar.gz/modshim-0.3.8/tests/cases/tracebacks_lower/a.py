"""A placeholder module for traceback tests."""
