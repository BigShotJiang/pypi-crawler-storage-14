"""Tests for lower traceback handling."""
