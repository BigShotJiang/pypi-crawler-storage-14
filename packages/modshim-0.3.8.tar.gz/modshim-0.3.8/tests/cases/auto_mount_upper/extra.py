"""Extra module in upper package for auto-mount testing."""

y = 20
