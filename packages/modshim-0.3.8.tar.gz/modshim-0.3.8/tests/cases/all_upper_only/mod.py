"""Module in upper package without __all__ defined."""

a = 10
b = 20
