"""Module in lower package for shim call ordering test."""

x = 100
