"""Module in upper package with __all__ defined."""

a = 10
b = 20
y = 22  # Override y from lower

__all__ = ["a", "b", "y"]
