"""Tests for upper traceback handling."""
