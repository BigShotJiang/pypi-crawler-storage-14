"""Lower package for __all__ merging tests."""
