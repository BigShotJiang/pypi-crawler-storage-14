"""Module in lower package with __all__ defined."""

x = 1
y = 2
z = 3
_private = 4

__all__ = ["x", "y"]
