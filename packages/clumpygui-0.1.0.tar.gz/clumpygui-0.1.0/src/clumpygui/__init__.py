def main() -> None:
    print("Hello from clumpygui!")
