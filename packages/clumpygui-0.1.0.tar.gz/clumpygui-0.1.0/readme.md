# ClumpyGUI

ClumpyGUI will provide access to a collection of web apps related to clumped isotopes.