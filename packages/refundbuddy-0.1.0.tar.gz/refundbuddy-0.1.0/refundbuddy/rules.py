def is_student_eligible(is_student):
    if isinstance(is_student, str):
        return bool(is_student.strip())
    return bool(is_student)

def has_full_protection(has_protection):
    return bool(has_protection)
