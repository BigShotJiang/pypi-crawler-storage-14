from .rules import is_student_eligible, has_full_protection

class RefundCalculator:
    def __init__(self, student_refund_percent: float = 50.0):
        self.student_refund_percent = float(student_refund_percent)

    def calculate_refund(self, fare, hours_before_departure,
                         is_student=False, has_refund_protection=False):

        fare = float(fare or 0)
        hours = float(hours_before_departure or 0)

        # Refund protection → full refund
        if has_full_protection(has_refund_protection):
            return {
                "refund_amount": round(fare, 2),
                "reason": "Full refund (Refund Protection)"
            }

        # Cancel ≥ 24 hrs → full refund
        if hours >= 24:
            return {
                "refund_amount": round(fare, 2),
                "reason": "Full refund (>=24 hours)"
            }

        # Student partial <24 hrs
        if is_student_eligible(is_student):
            amount = round(fare * (self.student_refund_percent / 100), 2)
            return {
                "refund_amount": amount,
                "reason": f"Student refund {self.student_refund_percent}% (<24 hours)"
            }

        # No refund
        return {
            "refund_amount": 0.0,
            "reason": "No refund (<24 hours)"
        }
