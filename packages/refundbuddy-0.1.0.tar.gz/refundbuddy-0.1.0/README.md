# refundbuddy

Refund calculation library for ticket apps (student + time rules).
