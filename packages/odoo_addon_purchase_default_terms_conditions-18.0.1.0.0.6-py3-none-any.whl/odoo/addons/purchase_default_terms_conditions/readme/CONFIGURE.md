To configure this module, you need to:

1.  Go to Purchase Settings
2.  Enable Default Terms & Conditions
3.  Set Default Terms & Conditions
4.  Set Terms & Conditions in Suppler
