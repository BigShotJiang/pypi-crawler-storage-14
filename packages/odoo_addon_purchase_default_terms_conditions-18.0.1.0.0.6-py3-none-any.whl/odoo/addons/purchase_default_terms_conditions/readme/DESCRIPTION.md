This module allows purchase default terms & conditions from Supplier or
Company
