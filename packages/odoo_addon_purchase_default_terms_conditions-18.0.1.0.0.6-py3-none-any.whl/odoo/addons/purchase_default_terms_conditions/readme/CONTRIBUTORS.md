- [Escodoo](https://www.escodoo.com.br):
  - Marcel Savegnago \<<marcel.savegnago@escodoo.com.br>\>
  - Murtaza Mithaiwala \<<murtaza.m.serpentcs@gmail.com>\>
  - Quan Nguyen \<<quan.nhm@komit-consulting.com>\>
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia

