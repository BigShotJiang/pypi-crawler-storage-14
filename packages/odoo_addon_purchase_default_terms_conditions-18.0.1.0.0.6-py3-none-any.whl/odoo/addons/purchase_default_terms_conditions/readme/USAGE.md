To use this module, you need to:

1.  Go do Purchase App
2.  Create a New Purchase/Quotation Order
