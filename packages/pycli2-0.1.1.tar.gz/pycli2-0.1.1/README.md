# PyCLI2

Python library to easily parse function arguments from CLI.
