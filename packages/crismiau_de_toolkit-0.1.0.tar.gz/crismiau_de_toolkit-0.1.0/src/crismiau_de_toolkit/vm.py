import click
import subprocess

VM_NAME = "lewagon-crisdev"
VM_ZONE = "us-central1-a"
VM_IP = "34.121.237.198"
VM_USERNAME = "heycristian26"   # ej: heycristian26



@click.command()
def start():
    """Start your vm"""
    subprocess.run(
        ["gcloud", "compute", "instances", "start", f"--zone={VM_ZONE}", VM_NAME],
        check=True
    )


@click.command()
def stop():
    """Stop your vm"""
    subprocess.run(
        ["gcloud", "compute", "instances", "stop", f"--zone={VM_ZONE}", VM_NAME],
        check=True
    )

@click.command()
def connect():
    """Connect to your vm in vscode inside your ~/code/crismiau folder"""
    folder_uri = (
        f"vscode-remote://ssh-remote+{VM_USERNAME}@{VM_IP}/home/{VM_USERNAME}/code/crismiau"
    )
    
    subprocess.run(["code", "--folder-uri", folder_uri], check=True)
