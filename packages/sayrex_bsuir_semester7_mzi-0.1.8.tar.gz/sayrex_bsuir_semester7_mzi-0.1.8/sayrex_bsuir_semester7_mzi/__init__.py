from .lab4 import lab4
from .lab5 import lab5
from .lab6 import lab6
from .lab7 import lab7
from .lab8 import lab8

__all__ = [
    "lab4",
    "lab5",
    "lab6",
    "lab7"
]