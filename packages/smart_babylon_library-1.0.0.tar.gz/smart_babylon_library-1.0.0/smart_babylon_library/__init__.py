# --------------------------------------------------------
# Licensed under the terms of the BSD 3-Clause License
# (see LICENSE for details).
# Copyright © 2025, Alexander Suvorov
# --------------------------------------------------------
# https://github.com/smartlegionlab
# --------------------------------------------------------
"""
Smart Babylon Library - Infinite Deterministic Text Universe
"""
from smart_babylon_library.library.core import SmartBabylonLibrary
from smart_babylon_library.library.coordinates import LibraryCoordinates
from smart_babylon_library.library.book import LibraryBook, LibraryPage
from smart_babylon_library.library.config import LibraryConfig

__all__ = [
    'SmartBabylonLibrary',
    'LibraryCoordinates',
    'LibraryBook',
    'LibraryPage',
    'LibraryConfig'
]
