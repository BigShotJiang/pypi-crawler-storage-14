from scipy.stats import gaussian_kde
import numpy as np

try:
    from sklearn.neighbors import KernelDensity
except Exception as exc:
    raise ImportError("scikit-learn is required for tree-based KDE. Install with `pip install scikit-learn`.") from exc

def _estimate_grid_size(n_points: int, grid_size: int | None) -> int:
    if grid_size is not None:
        return int(grid_size)
    # heuristic: scale with cube-root of N, keep reasonable bounds
    return int(min(64, max(30, int(8 * (n_points ** (1.0 / 3.0))))))

def _cube_bounds(pts: np.ndarray, padding: float = 0.05):
    mins = pts.min(axis=0)
    maxs = pts.max(axis=0)
    center = pts.mean(axis=0)
    spans = maxs - mins
    half_side = spans.max() / 2.0
    if half_side == 0:
        half_side = max(1e-6, np.max(np.abs(pts)) * 0.01)
    half_side *= (1.0 + padding)
    return center - half_side, center + half_side

def kde_3d_tree(points_dict,
                grid_size: int | None = None,
                padding: float = 0.05,
                bandwidth: float | str = 'auto',
                algorithm: str = 'ball_tree',
                leaf_size: int = 40,
                subsample: int | None = 50000,
                n_jobs: int | None = 1):
    """
    Tree-based 3D KDE using sklearn.neighbors.KernelDensity.

    Args:
        points_dict: dict mapping id -> (x,y,z) array-like (output of plane_analysis).
        grid_size: voxels per cube side (heuristic used if None).
        padding: fraction to expand cube around data extent.
        bandwidth: 'auto' for Silverman-like heuristic or float for bandwidth in world units.
        algorithm: 'ball_tree' or 'kd_tree' (tree-based).
        leaf_size: tree leaf_size for speed/memory tuning.
        subsample: max number of points to use (random subsample if N > subsample).
        n_jobs: number of parallel jobs for score_samples (only used indirectly by scikit-learn).

    Returns:
        dict with keys: 'density' (grid_size^3 array), 'X','Y','Z' (1D centers), 'kde' (sklearn object),
                      'grid_size','cube_min','cube_max','points'
    """
    pts = np.asarray(list(points_dict.values()), dtype=float)
    if pts.size == 0:
        raise ValueError("No points provided to compute 3D KDE.")
    if pts.ndim == 1:
        pts = pts.reshape(1, 3)
    if pts.shape[1] != 3:
        raise ValueError("Each point must be 3D (x,y,z).")

    N = pts.shape[0]
    grid_size = _estimate_grid_size(N, grid_size)

    # optional subsample to control fit cost/memory
    if subsample is not None and N > subsample:
        rng = np.random.default_rng(0)
        sel = rng.choice(N, size=subsample, replace=False)
        fit_pts = pts[sel]
    else:
        fit_pts = pts

    # bounding cube
    cube_min, cube_max = _cube_bounds(pts, padding=padding)
    xi = np.linspace(cube_min[0], cube_max[0], grid_size)
    yi = np.linspace(cube_min[1], cube_max[1], grid_size)
    zi = np.linspace(cube_min[2], cube_max[2], grid_size)
    X, Y, Z = np.meshgrid(xi, yi, zi, indexing='xy')
    coords = np.vstack([X.ravel(), Y.ravel(), Z.ravel()]).T  # shape (M, 3)

    # bandwidth heuristic (multivariate Silverman-like for d=3)
    if isinstance(bandwidth, str) and bandwidth == 'auto':
        d = 3
        sigma = np.mean(np.std(fit_pts, axis=0, ddof=1))
        # Silverman-like factor: h = sigma * (c * n)^(-1/(d+4)), c = (d+2)/4
        c = (d + 2.0) / 4.0
        h = sigma * (c * max(1, fit_pts.shape[0])) ** (-1.0 / (d + 4.0))
        bw = max(h, 1e-8)
    else:
        bw = float(bandwidth)

    kde = KernelDensity(bandwidth=bw, kernel='gaussian', algorithm=algorithm, leaf_size=leaf_size)
    kde.fit(fit_pts)

    # evaluate log-density and exponentiate
    log_d = kde.score_samples(coords)
    density = np.exp(log_d).reshape((grid_size, grid_size, grid_size)).astype(np.float32)

    return {
        'density': density,
        'X': xi,
        'Y': yi,
        'Z': zi,
        'grid_size': grid_size,
        'cube_min': cube_min,
        'cube_max': cube_max,
        'points': pts,
        'kde': kde,
        'bandwidth_used': bw,
        'algorithm': algorithm
    }

