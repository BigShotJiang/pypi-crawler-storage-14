"""
test_parabolic.py

Comprehensive test for the ParabolicReflector and Tracer system
in the OPTICAL_RAY_COLLECTOR project.

Displays a formatted table of:
 - Ray Directions
 - Ray Origins
 - Intersection Coordinates
 - Reflected Ray Coordinates
 - XY-plane Projections

Usage:
    pytest -v -s --log-cli-level=INFO optical_ray_tracer/tests/test_parabolic.py
"""

import sys
import pathlib
import pytest
import logging
import numpy as np

# ====================================
# Logging Configuration
# ====================================
logging.basicConfig(level=logging.INFO, format="%(message)s", force=True)
logger = logging.getLogger(__name__)
logger.propagate = True

# ====================================
# Add Project Root to sys.path
# ====================================
project_root = pathlib.Path(__file__).parent.parent.resolve()
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# ====================================
# Import Project Modules
# ====================================
from optical_ray_tracer.configurations.geometries.Parabolic import ParabolicReflector
from optical_ray_tracer.rays.source import point_source
from optical_ray_tracer.rays.raytracer import ray_tracer
from optical_ray_tracer.analyses.optical.density_calculations import kde_3d_tree


# ====================================
# Helper Functions
# ====================================
def dict_to_list(d):
    """Convert dictionary values to a flat list if input is a dict, else return as-is."""
    if isinstance(d, dict):
        return list(d.values())
    return d


def format_coords(coords):
    """
    Universal safe coordinate formatter:
    - Single vector (np.array shape (3,))
    - List of vectors
    - Dict of vectors
    - Scalars
    """
    # Dict → list
    if isinstance(coords, dict):
        coords = list(coords.values())

    # Scalar
    if np.isscalar(coords):
        return str(coords)

    # Single vector
    if isinstance(coords, np.ndarray) and coords.ndim == 1:
        return np.array2string(coords, precision=3, suppress_small=True, separator=", ")

    # List of vectors
    if isinstance(coords, (list, tuple)):
        return ", ".join(
            np.array2string(np.array(c), precision=3, suppress_small=True, separator=", ")
            for c in coords
        )

    # Fallback
    return str(coords)


# ====================================
# Main Test Function
# ====================================
def test_parabolic_reflector_pipeline_full():
    """Full end-to-end test for the parabolic reflector tracing pipeline."""

    logger.info("\n=== Starting Parabolic Reflector Pipeline Test ===\n")

    #---------------------------------------
    # 1. Initialize tracer
    #---------------------------------------
    tracer = ray_tracer.Tracer()
    assert tracer is not None, "Tracer initialization failed."
    logger.info("Tracer initialized successfully.\n")

    #---------------------------------------
    # 2. Create and add parabolic surface
    #---------------------------------------
    parab = ParabolicReflector(surf_pos=[0, 0, 0])
    boundaries = parab.boundaries()
    surface_idx, _ = tracer.add_surface(str(parab.symbolic_equation()), boundaries)
    assert surface_idx is not None, "Surface index is None — add_surface failed."

    logger.info(f"Parabolic surface added (index={surface_idx})")
    logger.info(f"Boundaries: {boundaries}\n")

    #---------------------------------------
    # 3. Generate rays
    #---------------------------------------
    source = point_source.Source(position_x=0.0, position_y=0.0, position_z=1.5e9)
    n_rays = 5
    vec_dir, pt_orig = parab.generate_rays_from_source(n_rays, source)
    assert len(vec_dir) == len(pt_orig) > 0, "Generated ray arrays mismatch or empty."

    logger.info(f"Number of rays generated: {len(vec_dir)}\n")

    #---------------------------------------
    # 4. Add rays
    #---------------------------------------
    tracer.add_rays(vec_dir, pt_orig)

    #---------------------------------------
    # 5. Compute intersections & reflections
    #---------------------------------------
    intersections, reflected = tracer.trace_new_scene()
    assert len(intersections) > 0 and len(reflected) > 0, "Empty intersections/reflections."

    logger.info("Intersections and reflections computed.\n")

    #---------------------------------------
    # 6. XY-plane analysis
    #---------------------------------------
    analyse_plane_pts = tracer.plane_analysis("XY", position=2, rays_dict=reflected)

    intersections_list = dict_to_list(intersections)
    plane_pts_list = dict_to_list(analyse_plane_pts)

    min_len = min(len(intersections_list), len(plane_pts_list))
    assert min_len > 0, "No XY-plane points found."

    # %-------------------Example usage for plotting KDE of intersection points
    # Compute tree-based KDE (returns density grid and coords)
    # import matplotlib.pyplot as plt
    # res = kde_3d_tree(analyse_plane_pts, grid_size=None, padding=0.05, bandwidth='auto', subsample=50000)
    # density = res['density']            # shape (nx, ny, nz)
    # xi, yi, zi = res['X'], res['Y'], res['Z']
    # nx, ny, nz = density.shape

    # # Choose central indices
    # ix = nx // 2
    # iy = ny // 2
    # iz = nz // 2
    # # Normalize densities for nicer colormap scaling (optional)
    # dmin, dmax = density.min(), density.max()
    # if dmax > dmin:
    #     norm = (density - dmin) / (dmax - dmin)
    # else:
    #     norm = density * 0.0 + 0.5

    # fig = plt.figure()
    # ax = fig.add_subplot(111, projection='3d')
    # sc = ax.scatter(xi, yi, zi, c=norm, depthshade=True)
    # ax.set_xlabel('X'); ax.set_ylabel('Y'); ax.set_zlabel('Z')
    # cbar = fig.colorbar(sc, ax=ax, shrink=0.6)
    # cbar.set_label('Normalized density')
    # plt.tight_layout()
    # plt.show()

    # %--------------------Exemple usage of angular deviation calculation--------------------%
    
    # deviations = tracer.compute_slope_error_angular_deviations(tracer.lighting_scene[0][0], tracer.lighting_scene[0][1])
    # for surf_idx, dev_list in deviations.items():
    #     logger.info(f"Surface {surf_idx} angular deviations (radians):")
    #     for ray_idx, dev in enumerate(dev_list):
    #         logger.info(f"  Ray {ray_idx}: dev_x={dev[0]:.6f}, dev_y={dev[1]:.6f}, dev_total={dev[2]:.6f}")

    logger.info("XY-plane analysis complete.\n")

    #---------------------------------------
    # 7. Formatted Table Output
    #---------------------------------------
    logger.info("Complete Ray Data Table:\n")
    header_fmt = "{:<6} {:<35} {:<35} {:<55} {:<55} {:<55}"
    logger.info(header_fmt.format(
        "Ray #", "Direction", "Origin", "Intersection", "Reflected", "XY Projection"
    ))
    logger.info("-" * 240)

    for i, (dir_vec, orig, int_coords, refl_coords, xy_proj) in enumerate(
        zip(vec_dir, pt_orig, intersections.values(), reflected.values(), plane_pts_list[:min_len])
    ):
        logger.info(
            header_fmt.format(
                i,
                format_coords(dir_vec),
                format_coords(orig),
                format_coords(dict_to_list(int_coords)),
                format_coords(dict_to_list(refl_coords)),
                format_coords(dict_to_list(xy_proj)),
            )
        )

    #---------------------------------------
    # 8. Symbolic equation & collection area
    #---------------------------------------
    z_solved = parab.solved_symbolic_equation()
    assert z_solved is not None
    logger.info(f"\nSolved symbolic Z: {z_solved}")

    area = parab.collection_area()
    assert area > 0
    logger.info(f"Collection area: {area:.5f}\n")

    #---------------------------------------
    # 9. Check scene integrity
    #---------------------------------------
    for scene in tracer.lighting_scene:
        for _, (inc_rays, refl_rays) in scene.items():
            assert isinstance(dict_to_list(inc_rays), list)
            assert isinstance(dict_to_list(refl_rays), list)

    logger.info("Lighting scene integrity verified successfully.\n")
    logger.info("=== Test completed successfully ===\n")
