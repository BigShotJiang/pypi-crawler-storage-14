from mcp.server.fastmcp import FsatMCP

mcp = FsatMCP("Demo1")


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b


def main() -> None:
    mcp.run(transport='stdio')
    
