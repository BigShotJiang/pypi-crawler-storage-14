"""内置沙箱工具集成 / Built-in Sandbox Tool Integration

提供沙箱环境的工具集封装,支持代码解释器和浏览器沙箱。
Provides toolset wrappers for sandbox environments, supporting code interpreter and browser sandboxes.
"""

from __future__ import annotations

import atexit
import threading
import time
from typing import Any, Dict, Optional

from agentrun.integration.utils.tool import CommonToolSet, tool
from agentrun.sandbox import Sandbox, TemplateType
from agentrun.utils.config import Config


class CodeInterpreterToolSet(CommonToolSet):
    """代码解释器工具集 / Code Interpreter ToolSet

    将 AgentRun 代码解释器沙箱封装为工具集。
    Wraps AgentRun code interpreter sandbox as a toolset.

    Attributes:
        template_name: 模板名称 / Template name
        template_type: 模板类型 / Template type
        config: 配置对象 / Configuration object
        sandbox_idle_timeout_seconds: 沙箱空闲超时时间(秒) / Sandbox idle timeout in seconds
    """

    def __init__(
        self,
        template_name: str,
        template_type: TemplateType,
        config: Optional[Config],
        sandbox_idle_timeout_seconds: int,
    ) -> None:
        """初始化代码解释器工具集 / Initialize code interpreter toolset

        Args:
            template_name: 模板名称 / Template name
            template_type: 模板类型 / Template type
            config: 配置对象 / Configuration object
            sandbox_idle_timeout_seconds: 沙箱空闲超时时间(秒) / Sandbox idle timeout in seconds
        """
        self.template_name = template_name
        self.template_type = template_type
        self.config = config or Config()
        self.sandbox_idle_timeout_seconds = sandbox_idle_timeout_seconds

        self._sandbox = None
        self._lock = threading.Lock()
        atexit.register(self.close)
        super().__init__()

    def close(self) -> None:
        """关闭并清理沙箱资源 / Close and cleanup sandbox resources"""
        sandbox = self._sandbox
        if sandbox and sandbox.sandbox_id:
            try:
                sandbox.stop(sandbox_id=sandbox.sandbox_id)
            finally:
                self._sandbox = None

    def _ensure_sandbox(self):
        """确保沙箱已创建 / Ensure sandbox is created"""
        if self._sandbox is not None:
            return self._sandbox
        if self.template_type != TemplateType.CODE_INTERPRETER:
            raise NotImplementedError(
                "Only TemplateType.CODE_INTERPRETER is supported"
            )
        with self._lock:
            if self._sandbox is None:
                self._sandbox = Sandbox.create(
                    template_type=self.template_type,
                    template_name=self.template_name,
                    sandbox_idle_timeout_seconds=self.sandbox_idle_timeout_seconds,
                    config=self.config,
                )
                time.sleep(10)

        return self._sandbox

    @tool(
        name="sandbox_execute_code",
        description=(
            "在指定的 Code Interpreter 沙箱中执行代码 / Execute code in Code"
            " Interpreter sandbox"
        ),
    )
    def execute_code(
        self,
        code: str,
        language: str = "python",
        timeout: int = 60,
    ) -> Dict[str, Any]:
        """在沙箱中执行代码 / Execute code in sandbox

        Args:
            code: 要执行的代码 / Code to execute
            language: 编程语言,默认 python / Programming language, default python
            timeout: 超时时间(秒) / Timeout in seconds

        Returns:
            Dict: 执行结果,包含 stdout、stderr 和原始结果 / Execution result with stdout, stderr and raw result
        """

        with self._ensure_sandbox() as sandbox:
            with sandbox.context.create() as ctx:
                # time.sleep(5)
                try:
                    result = ctx.execute(code=code, timeout=timeout)
                finally:
                    try:
                        ctx.delete()
                    except Exception:
                        pass
                return {
                    "stdout": result.get("stdout"),
                    "stderr": result.get("stderr"),
                    "raw": result,
                }

    @tool(
        name="sandbox_list_directory",
        description="列出沙箱中的文件 / List files in sandbox",
    )
    def list_directory(self, path: str = "/") -> Dict[str, Any]:
        """列出沙箱目录中的文件 / List files in sandbox directory

        Args:
            path: 目录路径,默认为根目录 / Directory path, default is root

        Returns:
            Dict: 包含路径和文件列表 / Dict containing path and file list
        """
        sandbox = self._ensure_sandbox()
        return {
            "path": path,
            "entries": sandbox.file_system.list(path=path),
        }

    @tool(
        name="sandbox_read_file",
        description="读取沙箱文件内容 / Read file content from sandbox",
    )
    def read_file(self, path: str) -> Dict[str, Any]:
        """读取沙箱中的文件内容 / Read file content from sandbox

        Args:
            path: 文件路径 / File path

        Returns:
            Dict: 包含路径和文件内容 / Dict containing path and file content
        """
        sandbox = self._ensure_sandbox()
        return {
            "path": path,
            "content": sandbox.file.read(path=path),
        }

    @tool(
        name="sandbox_write_file",
        description="向沙箱写入文本文件 / Write text file to sandbox",
    )
    def write_file(self, path: str, content: str) -> Dict[str, Any]:
        """向沙箱写入文本文件 / Write text file to sandbox

        Args:
            path: 文件路径 / File path
            content: 文件内容 / File content

        Returns:
            Dict: 包含路径和写入结果 / Dict containing path and write result
        """
        sandbox = self._ensure_sandbox()
        return {
            "path": path,
            "result": sandbox.file.write(path=path, content=content),
        }


class BrowserToolSet(CommonToolSet):
    """浏览器工具集 / Browser ToolSet

    将 AgentRun 浏览器沙箱封装为工具集。
    Wraps AgentRun browser sandbox as a toolset.

    Attributes:
        template_name: 模板名称 / Template name
        template_type: 模板类型 / Template type
        config: 配置对象 / Configuration object
        sandbox_idle_timeout_seconds: 沙箱空闲超时时间(秒) / Sandbox idle timeout in seconds
    """

    def __init__(
        self,
        template_name: str,
        template_type: TemplateType,
        config: Optional[Config],
        sandbox_idle_timeout_seconds: int,
    ) -> None:
        """初始化浏览器工具集 / Initialize browser toolset

        Args:
            template_name: 模板名称 / Template name
            template_type: 模板类型 / Template type
            config: 配置对象 / Configuration object
            sandbox_idle_timeout_seconds: 沙箱空闲超时时间(秒) / Sandbox idle timeout in seconds
        """
        self.template_name = template_name
        self.template_type = template_type
        self.config = config or Config()
        self.sandbox_idle_timeout_seconds = sandbox_idle_timeout_seconds

        self._sandbox = None
        self._lock = threading.Lock()
        # atexit.register(self.close)
        super().__init__()

    @tool(
        name="goto",
        description="前往指定页面 / Navigate to specified page",
    )
    def goto(self, query: str, num_results: int = 5):
        """前往指定页面 / Navigate to specified page

        Args:
            query: 查询关键词或URL / Query keyword or URL
            num_results: 结果数量 / Number of results

        Note:
            此功能待实现 / This feature is to be implemented
        """
        # 这里假设有一个 Browser 类可以用来执行搜索
        # from agentrun.browser import Browser

        # browser = Browser(config=self.config)
        # results = browser.search(query=query, num_results=num_results)
        # return {
        #     "query": query,
        #     "results": results,
        # }
        pass


def sandbox_toolset(
    template_name: str,
    *,
    template_type: TemplateType = TemplateType.CODE_INTERPRETER,
    config: Optional[Config] = None,
    sandbox_idle_timeout_seconds: int = 600,
) -> CommonToolSet:
    """将沙箱模板封装为通用工具集 / Wrap sandbox template as CommonToolSet

    根据模板类型创建对应的沙箱工具集。
    Creates corresponding sandbox toolset based on template type.

    Args:
        template_name: 模板名称 / Template name
        template_type: 模板类型,默认为代码解释器 / Template type, default is CODE_INTERPRETER
        config: 配置对象 / Configuration object
        sandbox_idle_timeout_seconds: 沙箱空闲超时时间(秒),默认600秒 / Sandbox idle timeout in seconds, default 600s

    Returns:
        CommonToolSet: 通用工具集实例 / CommonToolSet instance

    Examples:
        >>> # 创建代码解释器工具集 / Create code interpreter toolset
        >>> toolset = sandbox_toolset("python3", template_type=TemplateType.CODE_INTERPRETER)
        >>>
        >>> # 转换为 LangChain 工具 / Convert to LangChain tools
        >>> lc_tools = toolset.to_langchain()
    """

    if template_type != TemplateType.CODE_INTERPRETER:
        return BrowserToolSet(
            template_name=template_name,
            template_type=template_type,
            config=config,
            sandbox_idle_timeout_seconds=sandbox_idle_timeout_seconds,
        )
    else:
        return CodeInterpreterToolSet(
            template_name=template_name,
            template_type=template_type,
            config=config,
            sandbox_idle_timeout_seconds=sandbox_idle_timeout_seconds,
        )
