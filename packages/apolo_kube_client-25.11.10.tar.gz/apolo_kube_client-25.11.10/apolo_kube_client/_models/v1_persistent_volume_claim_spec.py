from typing import Annotated, ClassVar, Final

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field

from .utils import _collection_if_none, _default_if_none
from .v1_label_selector import V1LabelSelector
from .v1_typed_local_object_reference import V1TypedLocalObjectReference
from .v1_typed_object_reference import V1TypedObjectReference
from .v1_volume_resource_requirements import V1VolumeResourceRequirements


__all__ = ("V1PersistentVolumeClaimSpec",)


class V1PersistentVolumeClaimSpec(BaseModel):
    """PersistentVolumeClaimSpec describes the common attributes of storage devices and allows a Source for provider-specific attributes"""

    model_config = ConfigDict(
        extra="forbid",
        serialize_by_alias=True,
        validate_by_alias=True,
        validate_by_name=True,
    )

    kubernetes_ref: ClassVar[Final[str]] = (
        "io.k8s.api.core.v1.PersistentVolumeClaimSpec"
    )

    access_modes: Annotated[
        list[str],
        Field(
            alias="accessModes",
            description="""accessModes contains the desired access modes the volume should have. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#access-modes-1""",
            exclude_if=lambda v: v == [],
        ),
        BeforeValidator(_collection_if_none("[]")),
    ] = []

    data_source: Annotated[
        V1TypedLocalObjectReference | None,
        Field(
            alias="dataSource",
            description="""dataSource field can be used to specify either: * An existing VolumeSnapshot object (snapshot.storage.k8s.io/VolumeSnapshot) * An existing PVC (PersistentVolumeClaim) If the provisioner or an external controller can support the specified data source, it will create a new volume based on the contents of the specified data source. When the AnyVolumeDataSource feature gate is enabled, dataSource contents will be copied to dataSourceRef, and dataSourceRef contents will be copied to dataSource when dataSourceRef.namespace is not specified. If the namespace is specified, then dataSourceRef will not be copied to dataSource.""",
            exclude_if=lambda v: v is None,
        ),
    ] = None

    data_source_ref: Annotated[
        V1TypedObjectReference | None,
        Field(
            alias="dataSourceRef",
            description="""dataSourceRef specifies the object from which to populate the volume with data, if a non-empty volume is desired. This may be any object from a non-empty API group (non core object) or a PersistentVolumeClaim object. When this field is specified, volume binding will only succeed if the type of the specified object matches some installed volume populator or dynamic provisioner. This field will replace the functionality of the dataSource field and as such if both fields are non-empty, they must have the same value. For backwards compatibility, when namespace isn't specified in dataSourceRef, both fields (dataSource and dataSourceRef) will be set to the same value automatically if one of them is empty and the other is non-empty. When namespace is specified in dataSourceRef, dataSource isn't set to the same value and must be empty. There are three important differences between dataSource and dataSourceRef: * While dataSource only allows two specific types of objects, dataSourceRef
  allows any non-core object, as well as PersistentVolumeClaim objects.
* While dataSource ignores disallowed values (dropping them), dataSourceRef
  preserves all values, and generates an error if a disallowed value is
  specified.
* While dataSource only allows local objects, dataSourceRef allows objects
  in any namespaces.
(Beta) Using this field requires the AnyVolumeDataSource feature gate to be enabled. (Alpha) Using the namespace field of dataSourceRef requires the CrossNamespaceVolumeDataSource feature gate to be enabled.""",
            exclude_if=lambda v: v is None,
        ),
    ] = None

    resources: Annotated[
        V1VolumeResourceRequirements,
        Field(
            description="""resources represents the minimum resources the volume should have. If RecoverVolumeExpansionFailure feature is enabled users are allowed to specify resource requirements that are lower than previous value but must still be higher than capacity recorded in the status field of the claim. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#resources""",
            exclude_if=lambda v: not v.__pydantic_fields_set__,
        ),
        BeforeValidator(_default_if_none(V1VolumeResourceRequirements)),
    ] = V1VolumeResourceRequirements()

    selector: Annotated[
        V1LabelSelector,
        Field(
            description="""selector is a label query over volumes to consider for binding.""",
            exclude_if=lambda v: not v.__pydantic_fields_set__,
        ),
        BeforeValidator(_default_if_none(V1LabelSelector)),
    ] = V1LabelSelector()

    storage_class_name: Annotated[
        str | None,
        Field(
            alias="storageClassName",
            description="""storageClassName is the name of the StorageClass required by the claim. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#class-1""",
            exclude_if=lambda v: v is None,
        ),
    ] = None

    volume_attributes_class_name: Annotated[
        str | None,
        Field(
            alias="volumeAttributesClassName",
            description="""volumeAttributesClassName may be used to set the VolumeAttributesClass used by this claim. If specified, the CSI driver will create or update the volume with the attributes defined in the corresponding VolumeAttributesClass. This has a different purpose than storageClassName, it can be changed after the claim is created. An empty string or nil value indicates that no VolumeAttributesClass will be applied to the claim. If the claim enters an Infeasible error state, this field can be reset to its previous value (including nil) to cancel the modification. If the resource referred to by volumeAttributesClass does not exist, this PersistentVolumeClaim will be set to a Pending state, as reflected by the modifyVolumeStatus field, until such as a resource exists. More info: https://kubernetes.io/docs/concepts/storage/volume-attributes-classes/""",
            exclude_if=lambda v: v is None,
        ),
    ] = None

    volume_mode: Annotated[
        str | None,
        Field(
            alias="volumeMode",
            description="""volumeMode defines what type of volume is required by the claim. Value of Filesystem is implied when not included in claim spec.""",
            exclude_if=lambda v: v is None,
        ),
    ] = None

    volume_name: Annotated[
        str | None,
        Field(
            alias="volumeName",
            description="""volumeName is the binding reference to the PersistentVolume backing this claim.""",
            exclude_if=lambda v: v is None,
        ),
    ] = None
