symbolic-compartmental-model
============================

[![PyPI version fury.io](https://badge.fury.io/py/symbolic-compartmental-model.svg)](https://pypi.python.org/pypi/symbolic-compartmental-model/)
[![Python version](https://img.shields.io/pypi/pyversions/symbolic-compartmental-model.svg)](https://www.python.org/downloads)
[![MIT license](https://img.shields.io/pypi/l/symbolic-compartmental-model.svg)](https://mit-license.org/)
[![codecov](https://codecov.io/gl/elad.noor/symbolic-compartmental-model/graph/badge.svg?token=0MEGJMPWVS)](https://codecov.io/gl/elad.noor/symbolic-compartmental-model)
[![ReadTheDocs](https://readthedocs.org/projects/symbolic-compartmental-model/badge/?version=latest)](https://symbolic-compartmental-model.readthedocs.io/en/latest/)

A symbolic package based on SymPy for simulating and fitting Compartmental Models (CMs).
