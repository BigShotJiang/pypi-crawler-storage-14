from setuptools import setup, find_packages

setup(
    name="promptsql", # <--- CAMBIA ESTO OBLIGATORIAMENTE
    version="0.0.3",
    packages=find_packages(),
    description="Library to prompt sql queries",
    author="José-Manuel Martin Coronado",
    author_email="jm@martincoronado.com.pe",
    keywords=["python", "sqlite3", "prompt"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
