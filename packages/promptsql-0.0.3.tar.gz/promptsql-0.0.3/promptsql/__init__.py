
def consulta():
    query=input("ingresa una sentencia:" )
    print(query)
