.. :changelog:

Release Notes
=============

All notable changes to this project will be documented in this file.
This project adheres to `Semantic Versioning <http://semver.org/>`_.

*Don’t let your friends dump git logs into CHANGELOGs™*

`http://keepachangelog.com/ <http://keepachangelog.com/>`_

[0.0.1] - UNRELEASED
--------------------

.. note ::
    Please add new stuff chronologically, we should try chunking up the
    list into components at some point

Added
^^^^^

 - Base setup of Plugin.

Changed
^^^^^^^
