"""
Template Manager Dialogs
========================

Dialog windows for specialized template management operations.
"""

__all__ = []