Changelog
=========


[0.1.9] - April 17, 2025
------------------------

* Typehints added to unit tests, and Mypy, Pylint warnings fixed.
 

[0.1.6] - February 9, 2025
--------------------------

Updated for 'Juham' thread name refactorization.


[0.1.5] - January 26, 2025
--------------------------

- **Changelog:**

* CHANGELOG.rst and README.rst added

