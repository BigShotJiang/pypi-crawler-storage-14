"""Trie-based regex generation via automata construction."""

from __future__ import annotations

import re
from fractions import Fraction
from typing import Iterable

from rector.automata import build_trie

from .examples import normalize_examples
from .trie_compaction import trie_to_regex

RegexPattern = re.Pattern[str]


class TrieRegexGenerator:
    """
    Generate a regular expression from examples using a trie without heuristics.
    """

    def __init__(
        self,
        *,
        anchor_start: bool = True,
        anchor_end: bool = True,
        flags: re.RegexFlag = re.RegexFlag(0),
        dense_threshold: Fraction = Fraction(8, 10),
        aggregate_canonicals: bool = False,
    ) -> None:
        self.anchor_start = anchor_start
        self.anchor_end = anchor_end
        self.flags = flags
        self.dense_threshold = dense_threshold
        self.aggregate_canonicals = aggregate_canonicals

    def generate(self, examples: Iterable[str]) -> RegexPattern:
        example_list = normalize_examples(examples)
        if not example_list:
            raise ValueError("No examples provided for trie regex generation.")

        trie = build_trie(example_list)
        body = trie_to_regex(
            trie.root,
            dense_threshold=self.dense_threshold,
            allow_canonicals_in_aggregation=self.aggregate_canonicals,
        )
        prefix = "^" if self.anchor_start else ""
        suffix = "$" if self.anchor_end else ""
        return re.compile(f"{prefix}{body}{suffix}", self.flags)
