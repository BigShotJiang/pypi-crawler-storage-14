"""Trie and NFA construction from example strings."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import DefaultDict, Dict, Iterable, Set

Label = str | None  # None represents an epsilon transition


@dataclass(eq=False)
class TrieNode:
    """A node in the prefix tree."""

    children: Dict[str, "TrieNode"] = field(default_factory=dict)
    terminal: bool = False

    def insert(self, word: str) -> None:
        node = self
        for char in word:
            node = node.children.setdefault(char, TrieNode())
        node.terminal = True


@dataclass
class Trie:
    root: TrieNode = field(default_factory=TrieNode)

    @classmethod
    def from_words(cls, words: Iterable[str]) -> "Trie":
        trie = cls()
        for word in words:
            trie.root.insert(word)
        return trie


@dataclass
class NFA:
    start_state: int
    accept_states: Set[int]
    transitions: Dict[int, Dict[Label, Set[int]]] = field(default_factory=dict)

    def add_transition(self, src: int, label: Label, dest: int) -> None:
        self.transitions.setdefault(src, {}).setdefault(label, set()).add(dest)

    def alphabet(self) -> Set[str]:
        symbols: Set[str] = set()
        for labelled_edges in self.transitions.values():
            symbols.update(label for label in labelled_edges if label is not None)
        return symbols


def build_trie(words: Iterable[str]) -> Trie:
    return Trie.from_words(words)


def trie_to_nfa(trie: Trie) -> NFA:
    """
    Convert a trie into an equivalent NFA where each trie node becomes a state.
    """

    state_for_node: Dict[TrieNode, int] = {}
    transitions: DefaultDict[int, Dict[Label, Set[int]]] = defaultdict(
        lambda: defaultdict(set)
    )
    accept_states: Set[int] = set()

    def assign_state(node: TrieNode) -> int:
        if node not in state_for_node:
            state_for_node[node] = len(state_for_node)
        return state_for_node[node]

    def walk(node: TrieNode) -> None:
        state = assign_state(node)
        if node.terminal:
            accept_states.add(state)
        for char, child in sorted(node.children.items()):
            child_state = assign_state(child)
            transitions[state][char].add(child_state)
            walk(child)

    walk(trie.root)
    return NFA(
        start_state=state_for_node[trie.root],
        accept_states=accept_states,
        transitions={src: dict(labels) for src, labels in transitions.items()},
    )
