"""Deterministic automata construction."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Dict, Set

from .nfa import NFA


@dataclass
class DFA:
    start_state: int
    accept_states: Set[int]
    transitions: Dict[int, Dict[str, int]]
    alphabet: Set[str] = field(default_factory=set)

    def states(self) -> Set[int]:
        states: Set[int] = {self.start_state}
        states.update(self.accept_states)
        states.update(self.transitions.keys())
        for dests in self.transitions.values():
            states.update(dests.values())
        return states

    def transition(self, state: int, symbol: str) -> int | None:
        return self.transitions.get(state, {}).get(symbol)


def _epsilon_closure(nfa: NFA, states: Set[int]) -> Set[int]:
    closure = set(states)
    stack = list(states)
    while stack:
        state = stack.pop()
        for dest in nfa.transitions.get(state, {}).get(None, set()):
            if dest not in closure:
                closure.add(dest)
                stack.append(dest)
    return closure


def determinize(nfa: NFA) -> DFA:
    alphabet = nfa.alphabet()
    start_set = _epsilon_closure(nfa, {nfa.start_state})

    subset_to_state: Dict[frozenset[int], int] = {frozenset(start_set): 0}
    accept_states: Set[int] = set()
    transitions: Dict[int, Dict[str, int]] = {}

    queue: deque[Set[int]] = deque([start_set])
    while queue:
        current_set = queue.popleft()
        current_state = subset_to_state[frozenset(current_set)]
        if current_set & nfa.accept_states:
            accept_states.add(current_state)

        for symbol in sorted(alphabet):
            next_states: Set[int] = set()
            for state in current_set:
                next_states.update(nfa.transitions.get(state, {}).get(symbol, set()))
            if not next_states:
                continue
            closure = _epsilon_closure(nfa, next_states)
            frozen = frozenset(closure)
            if frozen not in subset_to_state:
                subset_to_state[frozen] = len(subset_to_state)
                queue.append(closure)
            transitions.setdefault(current_state, {})[symbol] = subset_to_state[frozen]

    return DFA(
        start_state=0,
        accept_states=accept_states,
        transitions=transitions,
        alphabet=alphabet,
    )
