"""DFA minimization using Hopcroft's algorithm."""

from __future__ import annotations

from typing import List, Set

from .dfa import DFA


def hopcroft_minimize(dfa: DFA) -> DFA:
    states = dfa.states()
    if not states:
        return dfa

    accept = set(dfa.accept_states)
    non_accept = states - accept

    partition: List[Set[int]] = []
    if accept:
        partition.append(accept)
    if non_accept:
        partition.append(non_accept)

    worklist: List[Set[int]] = partition.copy()
    alphabet = sorted(dfa.alphabet)

    while worklist:
        splitter = worklist.pop()
        for symbol in alphabet:
            predecessors = {
                state for state in states if dfa.transition(state, symbol) in splitter
            }
            if not predecessors:
                continue

            new_partition: List[Set[int]] = []
            for block in partition:
                intersect = block & predecessors
                difference = block - predecessors
                if intersect and difference:
                    new_partition.extend([intersect, difference])
                    if block in worklist:
                        worklist.remove(block)
                        worklist.extend([intersect, difference])
                    else:
                        worklist.append(
                            intersect
                            if len(intersect) <= len(difference)
                            else difference
                        )
                else:
                    new_partition.append(block)
            partition = new_partition

    ordered_blocks = sorted(
        partition, key=lambda block: (dfa.start_state not in block, min(block))
    )

    state_map = {}
    for idx, block in enumerate(ordered_blocks):
        for state in block:
            state_map[state] = idx

    minimized_transitions = {}
    for idx, block in enumerate(ordered_blocks):
        representative = min(block)
        for symbol, dest in dfa.transitions.get(representative, {}).items():
            minimized_transitions.setdefault(idx, {})[symbol] = state_map[dest]

    minimized_accept = {state_map[s] for s in accept}
    start_state = state_map[dfa.start_state]

    return DFA(
        start_state=start_state,
        accept_states=minimized_accept,
        transitions=minimized_transitions,
        alphabet=set(dfa.alphabet),
    )
