"""Regex builders built from automata."""

from .elimination import dfa_to_regex

__all__ = ["dfa_to_regex"]
