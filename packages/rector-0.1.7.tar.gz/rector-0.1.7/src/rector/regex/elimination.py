"""Convert a DFA into an equivalent regular expression using state elimination."""

from __future__ import annotations

import re
from collections import defaultdict
from typing import DefaultDict, Dict, Iterable, Set

from rector.automata.dfa import DFA

Label = str
Graph = DefaultDict[int, Dict[int, Set[Label]]]
EPSILON = ""


def _wrap_union(options: Set[Label]) -> Label:
    if not options:
        return EPSILON

    has_epsilon = EPSILON in options
    terms = sorted(opt for opt in options if opt != EPSILON)

    if not terms:
        return EPSILON

    if len(terms) == 1:
        core = terms[0]
    else:
        core = "(?:" + "|".join(terms) + ")"

    if has_epsilon:
        return f"(?:{core})?"
    return core


def _wrap_concat(parts: Iterable[Label]) -> Label:
    filtered = [part for part in parts if part != EPSILON]
    if not filtered:
        return EPSILON

    def wrap(part: str) -> str:
        if part in {"", EPSILON}:
            return EPSILON
        if len(part) == 1 or (part.startswith("\\") and len(part) == 2):
            return part
        if part.startswith("(?:") and part.endswith(")"):
            return part
        return f"(?:{part})"

    return "".join(wrap(part) for part in filtered)


def _star(expr: Label) -> Label:
    if expr in {"", EPSILON}:
        return EPSILON
    if len(expr) == 1 or (expr.startswith("\\") and len(expr) == 2):
        return f"{expr}*"
    if expr.startswith("(?:") and expr.endswith(")"):
        return f"{expr}*"
    return f"(?:{expr})*"


def _add_edge(graph: Graph, src: int, dest: int, label: Label) -> None:
    graph[src][dest].add(label)


def _eliminate_state(graph: Graph, state: int) -> None:
    incoming = [s for s, targets in graph.items() if state in targets]
    outgoing = list(graph.get(state, {}))

    loop_expr = (
        _wrap_union(graph[state][state])
        if state in graph and state in graph[state]
        else EPSILON
    )
    loop_star = _star(loop_expr) if loop_expr else EPSILON

    for src in incoming:
        for dest in outgoing:
            if src == state or dest == state:
                continue
            for in_label in graph[src][state]:
                for out_label in graph[state][dest]:
                    new_label = _wrap_concat([in_label, loop_star, out_label])
                    _add_edge(graph, src, dest, new_label)

    for src in incoming:
        graph[src].pop(state, None)
    graph.pop(state, None)


def dfa_to_regex(
    dfa: DFA, *, anchor_start: bool = True, anchor_end: bool = True
) -> str:
    if not dfa.accept_states:
        raise ValueError("DFA has no accepting states; cannot build regex.")

    base_states = dfa.states()
    graph: Graph = defaultdict(lambda: defaultdict(set))

    for src, transitions in dfa.transitions.items():
        for symbol, dest in transitions.items():
            graph[src][dest].add(re.escape(symbol))

    next_state = max(base_states) + 1 if base_states else 0
    super_start, super_end = next_state, next_state + 1

    _add_edge(graph, super_start, dfa.start_state, EPSILON)
    for accept in dfa.accept_states:
        _add_edge(graph, accept, super_end, EPSILON)

    all_states = set(base_states) | {super_start, super_end}
    for state in sorted(all_states):
        if state not in {super_start, super_end}:
            _eliminate_state(graph, state)

    final_options = graph.get(super_start, {}).get(super_end, set())
    body = _wrap_union(final_options)
    if anchor_start:
        body = "^" + body
    if anchor_end:
        body = body + "$"
    return body
