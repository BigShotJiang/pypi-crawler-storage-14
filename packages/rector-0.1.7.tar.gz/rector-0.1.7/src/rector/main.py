"""CLI entrypoint for generating a regex from stdin examples."""

from __future__ import annotations

import argparse
import sys
from fractions import Fraction
from typing import Iterable, TextIO

from rector.trie_regex import TrieRegexGenerator


def _read_examples(stream: Iterable[str]) -> list[str]:
    return [line.rstrip("\n") for line in stream]


def generate_pattern(
    examples: list[str],
    *,
    dense_threshold: Fraction | None = None,
    aggregate_canonicals: bool = False,
) -> str:
    if not examples:
        raise ValueError("No examples provided.")

    generator = TrieRegexGenerator(
        dense_threshold=dense_threshold
        if dense_threshold is not None
        else Fraction(8, 10),
        aggregate_canonicals=aggregate_canonicals,
    )
    return generator.generate(examples).pattern


def generate_pattern_from_stream(
    stream: TextIO,
    *,
    dense_threshold: Fraction | None = None,
    aggregate_canonicals: bool = False,
) -> str:
    examples = _read_examples(stream)
    if not examples:
        raise ValueError("No examples provided on stdin.")

    return generate_pattern(
        examples,
        dense_threshold=dense_threshold,
        aggregate_canonicals=aggregate_canonicals,
    )


def main(argv: list[str] | None = None, stream: TextIO | None = None) -> int:  # noqa: ARG001 - CLI interface
    parser = argparse.ArgumentParser(
        description="Generate a regex from stdin or input files."
    )
    parser.add_argument(
        "-t",
        "--dense-threshold",
        nargs="?",
        const="8/10",
        default=None,
        help=(
            "Density threshold (Fractions accepted, e.g. 3/4 or 0.8) for compacting "
            "near-contiguous character sets. Default when flag is present without a "
            "value: 8/10."
        ),
    )
    parser.add_argument(
        "-C",
        "--aggregate-canonicals",
        action="store_true",
        help="Allow canonical classes (\\d, \\s, \\w) in aggregated compaction.",
    )
    parser.add_argument(
        "-j",
        "--join-inputs",
        action="store_true",
        help="Combine all input files into a single pattern instead of one per file.",
    )
    parser.add_argument(
        "files",
        nargs="*",
        help="Input files containing example lines. If omitted, read from stdin.",
    )
    args = parser.parse_args(argv)

    try:
        threshold = (
            Fraction(args.dense_threshold) if args.dense_threshold is not None else None
        )
    except (ValueError, ZeroDivisionError) as exc:
        print(
            f"Error: invalid dense threshold '{args.dense_threshold}': {exc}",
            file=sys.stderr,
        )
        return 1

    patterns: list[str] = []
    if args.files:
        if args.join_inputs:
            all_examples: list[str] = []
            for path in args.files:
                try:
                    with open(path, encoding="utf-8") as handle:
                        all_examples.extend(_read_examples(handle))
                except OSError as exc:
                    print(f"Error reading '{path}': {exc}", file=sys.stderr)
                    return 1

            try:
                patterns.append(
                    generate_pattern(
                        all_examples,
                        dense_threshold=threshold,
                        aggregate_canonicals=args.aggregate_canonicals,
                    )
                )
            except ValueError as exc:
                print(f"Error: {exc}", file=sys.stderr)
                return 1
        else:
            for path in args.files:
                try:
                    with open(path, encoding="utf-8") as handle:
                        examples = _read_examples(handle)
                except OSError as exc:
                    print(f"Error reading '{path}': {exc}", file=sys.stderr)
                    return 1

                try:
                    patterns.append(
                        generate_pattern(
                            examples,
                            dense_threshold=threshold,
                            aggregate_canonicals=args.aggregate_canonicals,
                        )
                    )
                except ValueError as exc:
                    print(f"Error in '{path}': {exc}", file=sys.stderr)
                    return 1
    else:
        input_stream = stream or sys.stdin
        try:
            patterns.append(
                generate_pattern_from_stream(
                    input_stream,
                    dense_threshold=threshold,
                    aggregate_canonicals=args.aggregate_canonicals,
                )
            )
        except ValueError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    for pattern in patterns:
        print(pattern)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
