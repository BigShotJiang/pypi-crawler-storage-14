"""Utilities to compact trie structures into regex fragments."""

from __future__ import annotations

from fractions import Fraction
import string

from rector.automata import TrieNode

from .chars import char_class, escape_for_class, escape_literal, optional

_DIGITS = set(string.digits)
_WORD_CHARS = set(string.ascii_letters + string.digits + "_")


def dense_range_or_class(
    chars: set[str], *, dense_threshold: Fraction, allow_canonical: bool = True
) -> str:
    """
    Collapse a character set to a dense range if coverage over its span meets the threshold.
    """

    if not chars:
        return ""

    if len(chars) == 1:
        return escape_literal(next(iter(chars)))

    if allow_canonical:
        if all(ch.isspace() for ch in chars):
            return r"\s"

        if all(ch.isdigit() for ch in chars) and "0" in chars:
            digit_coverage = Fraction(len(chars), len(_DIGITS))
            if digit_coverage >= dense_threshold:
                return r"\d"

        if chars <= _WORD_CHARS:
            word_coverage = Fraction(len(chars), len(_WORD_CHARS))
            if word_coverage >= dense_threshold:
                return r"\w"

        if chars == _WORD_CHARS:
            return r"\w"

    codes = sorted(ord(c) for c in chars)
    start, end = codes[0], codes[-1]
    span = end - start + 1
    coverage = Fraction(len(chars), span) if span else Fraction(1, 1)

    if coverage >= dense_threshold and len(chars) >= 3:
        first = escape_for_class(chr(start))
        last = escape_for_class(chr(end))
        if first == last:
            return escape_literal(chr(start))
        return f"[{first}-{last}]"

    return char_class(chars)


def uniform_signature(
    root: TrieNode, *, dense_threshold: Fraction
) -> tuple[set[int], list[str]] | None:
    """
    If every depth shares identical terminal flags and child sets, return
    (allowed_lengths, classes_per_depth). Otherwise None.
    """

    allowed_lengths: set[int] = set()
    classes: list[str] = []

    level = [root]
    depth = 0
    while True:
        terminal_flags = {n.terminal for n in level}
        if len(terminal_flags) > 1:
            return None
        if True in terminal_flags:
            allowed_lengths.add(depth)

        child_sets = [tuple(sorted(n.children.keys())) for n in level]
        first = child_sets[0] if child_sets else ()
        if any(cs != first for cs in child_sets):
            return None
        if not first:
            break

        classes.append(
            dense_range_or_class(set(first), dense_threshold=dense_threshold)
        )
        level = [child for node in level for child in node.children.values()]
        depth += 1

    return allowed_lengths, classes


def compact_uniform(root: TrieNode, *, dense_threshold: Fraction) -> str | None:
    """
    If the trie is uniform per depth, emit a compact pattern with optional tails
    or aggregated quantifiers.
    """

    signature = uniform_signature(root, dense_threshold=dense_threshold)
    if signature is None:
        return None

    allowed_lengths, classes = signature
    if not allowed_lengths:
        return None

    max_len = len(classes)
    min_len, max_allowed = min(allowed_lengths), max(allowed_lengths)

    if max_allowed > 1:
        classes = ["[0-9]" if cls == r"\d" else cls for cls in classes]
    if max_allowed != max_len:
        return None
    if len(allowed_lengths) != max_allowed - min_len + 1:
        return None

    if len(set(classes)) == 1:
        cls = classes[0]
        if min_len == max_allowed:
            if max_allowed == 1:
                return cls
            return f"{cls}{{{max_allowed}}}"
        return f"{cls}{{{min_len},{max_allowed}}}"

    required_classes = classes[:min_len]
    optional_classes = classes[min_len:max_allowed]
    required = "".join(required_classes)

    if not optional_classes:
        return required

    if len(set(optional_classes)) == 1:
        tail_cls = optional_classes[0]
        if required_classes and required_classes[-1] == tail_cls:
            head = "".join(required_classes[:-1])
            lower = 1
            upper = 1 + len(optional_classes)
            return f"{head}{tail_cls}{{{lower},{upper}}}"
        return f"{required}{tail_cls}{{0,{len(optional_classes)}}}"

    optional_tail = "".join(f"{cls}?" for cls in optional_classes)
    return required + optional_tail


def aggregate_layers(root: TrieNode) -> tuple[list[set[str]], set[int]] | None:
    """
    Collect union of child labels per depth across all nodes plus allowed lengths.
    Returns (classes_per_depth, lengths) if each depth has at least one label; else None.
    """

    classes: list[set[str]] = []
    lengths: set[int] = set()

    current = [root]
    depth = 0
    while current:
        if any(node.terminal for node in current):
            lengths.add(depth)

        symbols: set[str] = set()
        next_level: list[TrieNode] = []
        for node in current:
            symbols.update(node.children.keys())
            next_level.extend(node.children.values())

        if not symbols:
            break

        classes.append(symbols)
        current = next_level
        depth += 1

    if not classes:
        return None
    return classes, lengths


def compact_aggregated(
    root: TrieNode,
    *,
    dense_threshold: Fraction,
    allow_canonicals_in_aggregation: bool,
) -> str | None:
    """
    If all depths are populated and lengths form a contiguous interval, build a compact
    pattern from the aggregated per-depth symbol unions.
    """

    aggregated = aggregate_layers(root)
    if aggregated is None:
        return None

    classes, lengths = aggregated
    if not lengths:
        return None

    min_len, max_len = min(lengths), max(lengths)
    if len(lengths) != max_len - min_len + 1:
        return None
    if max_len > len(classes):
        return None

    atoms = [
        dense_range_or_class(
            symbols,
            dense_threshold=dense_threshold,
            allow_canonical=allow_canonicals_in_aggregation,
        )
        for symbols in classes[:max_len]
    ]
    if any(not atom for atom in atoms):
        return None

    body_parts: list[str] = []
    index = 0
    while index < max_len:
        atom = atoms[index]
        run_end = index + 1
        while run_end < max_len and atoms[run_end] == atom:
            run_end += 1
        run_len = run_end - index

        if index >= min_len:
            required = 0
        else:
            required = min(min_len - index, run_len)
        optional = run_len - required

        lower = required
        upper = required + optional
        if lower == upper:
            if lower == 1:
                body_parts.append(atom)
            else:
                body_parts.append(f"{atom}{{{lower}}}")
        elif lower == 0 and upper == 1:
            body_parts.append(f"{atom}?")
        elif lower == 0:
            body_parts.append(f"{atom}{{0,{upper}}}")
        else:
            body_parts.append(f"{atom}{{{lower},{upper}}}")

        index = run_end

    body = "".join(body_parts)

    if root.terminal and min_len > 0:
        # Allow empty only if root itself is terminal.
        body = f"(?:{body})?"

    return body


def trie_to_regex(
    node: TrieNode,
    *,
    dense_threshold: Fraction,
    allow_canonicals_in_aggregation: bool = False,
) -> str:
    """
    Produce a compact regex that matches exactly the strings in the trie.
    """

    for strategy in (
        lambda n: compact_uniform(n, dense_threshold=dense_threshold),
        lambda n: compact_aggregated(
            n,
            dense_threshold=dense_threshold,
            allow_canonicals_in_aggregation=allow_canonicals_in_aggregation,
        ),
    ):
        compact = strategy(node)
        if compact is not None:
            return compact

    grouped: dict[str, list[str]] = {}
    for char, child in sorted(node.children.items()):
        suffix = trie_to_regex(child, dense_threshold=dense_threshold)
        grouped.setdefault(suffix, []).append(char)

    options: list[str] = []
    for suffix, chars in sorted(grouped.items()):
        prefix = dense_range_or_class(set(chars), dense_threshold=dense_threshold)
        options.append(prefix + suffix)

    has_empty = node.terminal
    if not options and not has_empty:
        return ""

    if len(options) == 1:
        base = options[0]
    elif options:
        base = "(?:" + "|".join(options) + ")"
    else:
        base = ""

    if has_empty:
        return optional(base)
    return base
