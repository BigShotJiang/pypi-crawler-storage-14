from pytest_bdd import given, parsers, scenario, then, when

from rector import TrieRegexGenerator


@scenario("regex_builder.feature", "Generate ISO date regex from examples")
def test_generate_iso_date():
    pass


@given(parsers.re(r"the example strings (?P<items>.+)"), target_fixture="examples")
def example_strings(items: str):
    values = [part.strip().strip('"').strip("'") for part in items.split(",")]
    return [value for value in values if value]


@when("I generate an optimized regex", target_fixture="compiled_pattern")
def generate_pattern(examples):
    generator = TrieRegexGenerator()
    return generator.generate(examples)


@then(parsers.parse('the pattern matches "{text}"'))
def pattern_matches(compiled_pattern, text: str):
    assert compiled_pattern.fullmatch(text)


@then(parsers.parse('the pattern does not match "{text}"'))
def pattern_does_not_match(compiled_pattern, text: str):
    assert compiled_pattern.fullmatch(text) is None
