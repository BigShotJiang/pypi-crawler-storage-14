import re
import string
from fractions import Fraction
from pathlib import Path
import pytest

from rector.trie_regex import TrieRegexGenerator


def test_trie_generator_matches_examples():
    generator = TrieRegexGenerator()
    pattern = generator.generate(["cat", "car", "cap"])

    assert pattern.fullmatch("cat")
    assert pattern.fullmatch("car")
    assert pattern.fullmatch("cap")
    assert pattern.fullmatch("cab") is None


def test_can_disable_anchors():
    generator = TrieRegexGenerator(anchor_start=False, anchor_end=False)
    pattern = generator.generate(["abc"])

    assert pattern.search("xabcx")


def test_compacts_number_range():
    examples = [str(n) for n in range(10, 1000)]
    pattern = TrieRegexGenerator().generate(examples).pattern

    assert pattern == "^[1-9][0-9]{1,2}$"
    compiled = re.compile(pattern)
    for n in [10, 123, 999]:
        assert compiled.fullmatch(str(n))
    assert compiled.fullmatch("9") is None
    assert compiled.fullmatch("000") is None


def test_uniform_repetition_collapses_to_quantifier():
    examples = [
        "a",
        "b",
        "aa",
        "ab",
        "ba",
        "bb",
        "aaa",
        "aab",
        "aba",
        "abb",
        "baa",
        "bab",
        "bba",
        "bbb",
    ]
    pattern = TrieRegexGenerator().generate(examples).pattern

    assert pattern == "^[ab]{1,3}$"
    compiled = re.compile(pattern)
    for sample in ["a", "bb", "aba", "bba"]:
        assert compiled.fullmatch(sample)


def test_space_fixture_compacts_to_global_classes():
    lines = Path("tests/fixtures/space_variants.txt").read_text().splitlines()
    pattern = TrieRegexGenerator().generate(lines).pattern

    assert pattern == "^[a-z] [a-z]{2}[ a-z]{2}[a-z]{2,3}$"


def test_space_fixture_compresses_identical_runs():
    lines = Path("tests/fixtures/space_variants.txt").read_text().splitlines()
    pattern = TrieRegexGenerator().generate(lines).pattern

    assert pattern == "^[a-z] [a-z]{2}[ a-z]{2}[a-z]{2,3}$"


def test_space_fixture_permissive_threshold_keeps_tight_classes():
    lines = Path("tests/fixtures/space_variants.txt").read_text().splitlines()
    pattern = (
        TrieRegexGenerator(dense_threshold=Fraction(1, 256)).generate(lines).pattern
    )

    # With a very permissive threshold the space-plus-lowercase span collapses to a range.
    assert pattern == "^[a-z] [a-z]{2}[ -z]{2}[a-z]{2,3}$"


def test_aggregated_trie_runs_are_compacted():
    examples = ["a ab c", "b bc d", "c ca f"]
    pattern = TrieRegexGenerator().generate(examples).pattern

    assert pattern == "^[a-c] [a-c]{2} [cdf]$"


def test_does_not_wrap_single_hash_char_in_class():
    pattern = TrieRegexGenerator().generate(["#a", "#b"]).pattern

    assert "[\\#]" not in pattern
    assert pattern.startswith("^#")


def test_does_not_wrap_single_dash_char_in_class():
    pattern = TrieRegexGenerator().generate(["-a", "-b"]).pattern

    assert "[\\-]" not in pattern
    assert pattern.startswith("^-")


def test_space_literal_not_escaped():
    pattern = TrieRegexGenerator().generate(["a b", "a c"]).pattern

    assert pattern == "^a [bc]$"


def test_empty_lines_are_accepted_when_present():
    examples = ["line", ""]
    pattern = TrieRegexGenerator().generate(examples)

    assert pattern.fullmatch("")
    assert pattern.fullmatch("line")


def test_full_digit_set_collapses_to_digit_class():
    pattern = TrieRegexGenerator().generate([str(n) for n in range(10)]).pattern

    assert pattern == r"^\d$"


def test_whitespace_collapses_to_space_class():
    pattern = TrieRegexGenerator().generate([" ", "\t", "\n"]).pattern

    assert pattern == r"^\s$"


def test_sparse_digit_set_defaults_to_explicit_class():
    examples = ["0", "2", "4"]

    pattern = TrieRegexGenerator().generate(examples).pattern
    assert pattern == r"^[024]$"


def test_sparse_digit_set_collapses_to_range_when_dense():
    examples = ["0", "2", "4"]

    pattern = (
        TrieRegexGenerator(dense_threshold=Fraction(1, 2)).generate(examples).pattern
    )
    assert pattern == r"^[0-4]$"


def test_sparse_digit_set_collapses_to_digit_class_when_permissive():
    examples = ["0", "2", "4"]

    pattern = (
        TrieRegexGenerator(dense_threshold=Fraction(2, 10)).generate(examples).pattern
    )
    assert pattern == r"^\d$"


def test_word_char_examples_collapse_to_word_class():
    examples = list(
        string.ascii_lowercase[3:]
        + string.ascii_uppercase[3:]
        + string.digits[1:]
        + "_"
    )

    pattern = TrieRegexGenerator().generate(examples).pattern

    assert pattern == r"^\w$"


def test_word_char_examples_without_underscore_collapse_to_word_class():
    examples = list(
        string.ascii_lowercase[3:] + string.ascii_uppercase[3:] + string.digits[1:]
    )

    pattern = (
        TrieRegexGenerator(dense_threshold=Fraction(1 / 255)).generate(examples).pattern
    )

    assert pattern == r"^\w$"


def test_word_char_examples_without_digits_collapse_to_word_class():
    examples = list(string.ascii_lowercase[3:] + string.ascii_uppercase[3:] + "_")

    pattern = (
        TrieRegexGenerator(dense_threshold=Fraction(1 / 255)).generate(examples).pattern
    )

    assert pattern == r"^\w$"


def test_word_char_examples_with_only_lowercase_collapse_to_word_class():
    examples = list(string.ascii_lowercase[3:])

    pattern = (
        TrieRegexGenerator(dense_threshold=Fraction(1 / 255)).generate(examples).pattern
    )

    assert pattern == r"^\w$"


@pytest.mark.parametrize(
    "examples, threshold, aggregate_canonicals, expected",
    [
        (
            [f"{letter}{digit}" for letter, digit in zip("abcdefghij", "0123456789")],
            Fraction(1, 10),
            False,
            r"^[a-j][0-9]$",
        ),
        (
            [f"{letter}{digit}" for letter, digit in zip("abcdefghij", "0123456789")],
            Fraction(1, 10),
            True,
            r"^\w\d$",
        ),
        (
            [f"{letter}{digit}" for letter, digit in zip("abcdefghij", "0123456789")],
            Fraction(9, 10),
            True,
            r"^[a-j]\d$",
        ),
        (
            [" a", "\tb", "\nc"],
            Fraction(1, 3),
            False,
            "^[\t\n ][a-c]$",
        ),
        (
            [" a", "\tb", "\nc"],
            Fraction(1, 3),
            True,
            r"^\s[a-c]$",
        ),
        (
            ["0a", "1b", "2c"],
            Fraction(1, 10),
            False,
            r"^[0-2][a-c]$",
        ),
        (
            ["0a", "1b", "2c"],
            Fraction(1, 10),
            True,
            r"^\d[a-c]$",
        ),
    ],
)
def test_aggregated_canonical_toggle(
    examples, threshold, aggregate_canonicals, expected
):
    pattern = (
        TrieRegexGenerator(
            dense_threshold=threshold,
            aggregate_canonicals=aggregate_canonicals,
        )
        .generate(examples)
        .pattern
    )

    assert pattern == expected
