import re

from rector.automata import build_trie, determinize, hopcroft_minimize, trie_to_nfa
from rector.regex.elimination import dfa_to_regex


def test_pipeline_builds_minimized_regex():
    examples = ["ab", "ac", "abc"]
    trie = build_trie(examples)
    nfa = trie_to_nfa(trie)
    dfa = determinize(nfa)
    minimized = hopcroft_minimize(dfa)
    regex = dfa_to_regex(minimized)
    compiled = re.compile(regex)

    for example in examples:
        assert compiled.fullmatch(example)
    assert compiled.fullmatch("ad") is None
