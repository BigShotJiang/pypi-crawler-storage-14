# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pkgmagic', 'pkgmagic.events', 'pkgmagic.packages', 'pkgmagic.remotes']

package_data = \
{'': ['*']}

install_requires = \
['pyyaml>=6.0.3,<7.0.0', 'requests>=2.32.5,<3.0.0']

entry_points = \
{'console_scripts': ['pkgmagic = pkgmagic.cli:run_app']}

setup_kwargs = {
    'name': 'pkgmagic',
    'version': '0.1.0',
    'description': '',
    'long_description': '# pkgmagic\n\nTool for easily updating new package versions to registries.\n',
    'author': 'ScriptHoodie',
    'author_email': 'dev@scripthoodie.dev',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
