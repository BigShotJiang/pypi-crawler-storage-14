def run_app():
    import argparse
    import yaml
    import sys
    import logging

    from .main import PkgMagic, EventManager, PackageTypeProvider, RemoteProvider
    from .main import PackageSubmitListener
    from .events.version import ExistsEvent, NotExistsEvent
    from .packages import composer
    from .remotes import gitea


    parser = argparse.ArgumentParser(description="Process a configuration file.")
    parser.add_argument(
        'config',
        type=argparse.FileType('r'),
        help='Path to the configuration file in YAML format'
    )
    parser.add_argument(
        '-v',
        '--verbose',
        action='count',
        default=0,
        help='Increase output verbosity. Use multiple times for more verbosity.'
    )

    args = parser.parse_args()

    if args.verbose == 1:
        logging.basicConfig(stream=sys.stderr, level=logging.WARNING)
    elif args.verbose == 2:
        logging.basicConfig(stream=sys.stderr, level=logging.INFO)
    elif args.verbose == 3:
        logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

    try:
        config = yaml.safe_load(args.config)

        event_manager = EventManager()
        package_provider = PackageTypeProvider()
        remote_provider = RemoteProvider()

        remote_provider.add_factory('gitea', gitea.RemoteFactory())
        package_provider.add_factory('composer', composer.PackageFactory())

        event_manager.add_listener(NotExistsEvent, PackageSubmitListener())

        pkg_magic = PkgMagic(event_manager, package_provider, remote_provider)
        pkg_magic.run(config)
    except Exception as e:
        if not str(e):
            print('The command did not complete successfully!', file=sys.stderr)
        else:
            print('Error: {}'.format(e), file=sys.stderr)

        if args.verbose == 0:
            print('Run the command again with -vvv switch to get more details.', file=sys.stderr)

        sys.exit(1)



