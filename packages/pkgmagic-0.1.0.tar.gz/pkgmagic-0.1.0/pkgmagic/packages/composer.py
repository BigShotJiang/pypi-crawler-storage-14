import os
import json
import tempfile
import subprocess

from ..main import InvalidPackageSpecError


class Package:
    def __init__(self, path):
        self.__load_info(path)

    def __load_info(self, path):
        composer_json_path = os.path.join(path, 'composer.json')
        self.path = path

        try:
            with open(composer_json_path, 'r') as jfp:
                data = json.load(jfp)

                self.name = data['name']
                self.version = data['version']
        except FileNotFoundError as e:
            raise InvalidPackageSpecError(
                "composer.json path '{}' does not exist!".format(
                    e.filename
                )
            )

    def get_version(self):
        return self.version

    def get_name(self):
        return self.name

    def get_archive(self):
        archive_path = tempfile.gettempdir()
        basename = '{}-{}'.format(
            self.get_name().replace('/', '-'),
            self.get_version()
        )

        command = [
            'composer',
            'archive',
            '--working-dir',
            self.path,
            '--format',
            'zip',
            '--dir',
            archive_path,
            '--file',
            basename
        ]

        try:
            subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            return os.path.join(archive_path, basename) + '.zip'
        except subprocess.CalledProcessError:
            raise Exception('Cannot create package archive.')


class PackageFactory:
    def get(self, params):
        if 'path' not in params:
            raise InvalidPackageSpecError(
                "Composer package path is not given in 'path'!"
            )

        return Package(params['path'])