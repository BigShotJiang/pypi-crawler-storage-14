class ExistsEvent():
    def __init__(self, version, package, remote):
        self.version = version
        self.package = package
        self.remote = remote

    def get_version(self):
        return self.version

    def get_package(self):
        return self.package

    def get_remote(self):
        return self.remote


class NotExistsEvent():
    def __init__(self, version, package, remote):
        self.version = version
        self.package = package
        self.remote = remote

    def get_version(self):
        return self.version

    def get_package(self):
        return self.package

    def get_remote(self):
        return self.remote