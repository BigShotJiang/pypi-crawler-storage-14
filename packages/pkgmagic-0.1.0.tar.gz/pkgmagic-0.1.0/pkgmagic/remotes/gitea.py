from urllib.parse import urljoin, quote

from pkgmagic.main import PackageSubmissionFailedError, InvalidRemoteSpecError

import requests
from requests.auth import HTTPBasicAuth


class RemoteFactory:
    def get(self, params):
        required_params = ['host', 'owner', 'username', 'password']

        for required_param in required_params:
            if required_param not in params:
                raise InvalidRemoteSpecError()

            if not isinstance(params[required_param], str):
                raise InvalidRemoteSpecError()

        return Remote(
            params['host'],
            params['owner'],
            params['username'],
            params['password']
        )


class Remote:
    def __init__(self, host, owner, username, password):
        self.host = host
        self.owner = owner
        self.username = username
        self.password = password

    def __get_version_endpoint(self):
        return

    def version_exists(self, package, version):
        url_path = '/api/v1/packages/{owner}/composer/{name}/{version}'.format(
            owner=self.owner,
            name=quote(package.get_name(), safe=''),
            version=version
        )
        url = urljoin(self.host, url_path)

        response = requests.get(url, auth=HTTPBasicAuth(self.username, self.password))

        return response.status_code != 404

    def submit(self, package):
        url_path = '/api/packages/{owner}/composer/'.format(
            owner=self.owner,
        )
        url = urljoin(self.host, url_path)
        archive_path = package.get_archive()

        with open(archive_path, 'rb') as fp:
            response = requests.put(url, data=fp, auth=HTTPBasicAuth(self.username, self.password))

            if response.status_code != 201:
                raise PackageSubmissionFailedError(
                    'Received status code {status_code} from {url}'.format(
                        status_code=response.status_code,
                        url=url
                    )
                )