import logging

from .events.version import NotExistsEvent, ExistsEvent


logger = logging.getLogger(__name__)


class PackageSubmissionFailedError(Exception):
    pass


class InvalidRemoteSpecError(Exception):
    pass


class RemoteNotFoundError(Exception):
    def __init__(self, name):
        message = f"Remote '{name}' not found!".format(name=name)
        self.name = name

        super().__init__(message)


class RemoteProvider:
    def __init__(self):
        self.factories = {}

    def add_factory(self, name, factory):
        self.factories[name] = factory

    def get(self, name, params):
        if name not in self.factories:
            raise RemoteNotFoundError(name)

        return self.factories[name].get(params)


class UnsupportedPackageTypeError(Exception):
    def __init__(self, package):
        super().__init__(
            'Package type \'{}.{}\' is not supported!'.format(
                type(package).__module__,
                type(package).__name__
            )
        )


class InvalidPackageSpecError(Exception):
    pass


class PackageTypeNotFoundError(Exception):
    def __init__(self, name):
        message = f"Package type '{name}' not found!".format(name=name)
        self.name = name

        super().__init__(message)


class PackageTypeProvider:
    def __init__(self):
        self.factories = {}

    def add_factory(self, name, factory):
        self.factories[name] = factory

    def get(self, name, params):
        if name not in self.factories:
            raise PackageTypeNotFoundError(name)

        return self.factories[name].get(params)


class EventManager:
    def __init__(self):
        self.listeners = {}

    def add_listener(self, event_class, listener):
        logger.debug(
            'Adding listener {}.{} for event {}.{}'.format(
                type(listener).__module__,
                type(listener).__name__,
                event_class.__module__,
                event_class.__name__
            )
        )
        if event_class not in self.listeners:
            self.listeners[event_class] = [listener]
        else:
            self.listeners[event_class].append(listener)


    def fire(self, event):
        logger.debug(
            'Firing event {}.{}'.format(
                type(event).__module__,
                type(event).__name__
            )
        )

        for event_class, listeners in self.listeners.items():
            if isinstance(event, event_class):
                for listener in listeners:
                    listener.handle(event)


class InvalidConfigError(Exception):
    pass


class Config:
    def __init__(self, config):
        self.__validate(config)

        self.config = config

    def __validate(self, config):
        if 'remotes' not in config:
            raise InvalidConfigError('No remotes listed in the configuration.')

        if 'packages' not in config:
            raise InvalidConfigError('No packages listed in the configuration.')

    def get_remotes(self):
        return self.config['remotes']

    def get_packages(self):
        return self.config['remotes']


class PackageSubmitListener:
    def handle(self, event):
        event.get_remote().submit(event.get_package())


class PkgMagic:
    def __init__(self, event_manager, package_type_provider, remote_provider):
        self.event_manager = event_manager
        self.package_type_provider = package_type_provider
        self.remote_provider = remote_provider

    def run(self, config):
        for name, package_spec in config['packages'].items():
            logger.debug('Processing package spec {}'.format(name))

            package = self.package_type_provider.get(package_spec['package']['type'], package_spec['package']['params'])

            for remote_name in package_spec['remotes']:
                logger.debug('Processing remote {}'.format(remote_name))
                remote = self.remote_provider.get(config['remotes'][remote_name]['type'], config['remotes'][remote_name]['params'])

                if remote.version_exists(package, package.get_version()):
                    event = ExistsEvent(package.get_version(), package, remote)
                else:
                    event = NotExistsEvent(package.get_version(), package, remote)

                self.event_manager.fire(event)