# pkgmagic

Tool for easily updating new package versions to registries.
