# -*- coding: utf-8 -*-
# (c) Satelligence, see LICENSE.rst.
"""Codecs to compress and decompress data"""
from typing import Any

import lerc
from numcodecs import abc, registry
from numcodecs.compat import ensure_ndarray, ndarray_copy
import numpy as np
from numpy.typing import NDArray


class LERC(abc.Codec):
    """Codec to compress data with the LERC algorithm

    Args:
        precision (float): precision to preserve in the data
    """

    codec_id = 'lerc'
    dtype = np.float32

    def __init__(self, precision: float) -> None:
        self._precision = precision

    def encode(self, buf: NDArray[Any]) -> NDArray[Any]:
        """Encode data

        Args:
            buf (np.ndarray): the data to encode

        Returns:
            np.ndarray: encoded data
        """
        buf = ensure_ndarray(buf)

        shape = buf.shape
        data = buf.reshape((-1, shape[-2], shape[-1]), order='A')

        lerc_encode_result: tuple[Any, Any, NDArray[Any]] = lerc.encode(
            data,
            nValuesPerPixel=1,
            npValidMask=~np.isnan(data),
            nBytesHint=1,
            maxZErr=self._precision,
            bHasMask=True,
        )
        compressed_data: NDArray[Any] = lerc_encode_result[2]
        return compressed_data

    def decode(self, buf: NDArray[Any], out: NDArray[Any] | None = None) -> NDArray[Any]:
        """Decode data

        Args:
            buf (np.ndarray): the data to decode
            out (np.ndarray | None): the array to write the output to

        Returns:
            np.ndarray: the decoded data
        """
        # with the new zarr version, this function receives buf as a np.ndarray and not
        # as bytes anymore. Lerc decode needs bytes as input however.
        buf = ensure_ndarray(buf)
        buf_bytes = buf.tobytes()

        decompressed_data = lerc.decode(buf_bytes)
        data: NDArray[Any] = decompressed_data[1]
        valid_mask: NDArray[Any] | None = decompressed_data[2]

        if valid_mask is None:
            decoded_data = data
        else:
            # Use mask if there is one
            decoded_data = np.where(valid_mask, data, np.nan)

        if out is None:
            return decoded_data
        else:
            ndarray_copy(decoded_data, out)
        return out

    def get_config(self) -> dict[str, Any]:
        """Get configuration to reconstruct this codec

        Returns:
            dict: with configuration to reconstruct this codec with
        """
        return {
            "id": str(self),
            "precision": self._precision,
        }

    def __repr__(self) -> str:
        """String representation

        Returns:
            str: this codec's id
        """
        return str(self.codec_id)


def register_lerc_codec():
    registry.register_codec(LERC)
