# `parstools` documentation

The main way of defining lexers and parsers is via classes,
and is similar to the interface of Python lex-yacc.


## Lexer definition

Lexers are defined by subclassing `StatefulLexer`, for example:

```python
import parstools


class Lexer(
        parstools.StatefulLexer):
    """Grammar for building a lexer."""

    t_NUMBER = r' \d+ '
    t_PLUS = r' \+ '
    t_MINUS = r' \- '
    t_ASTERISK = r' \* '
    t_DIV = r' / '
    t_omit = r' \s* '
```

Each attribute `t_...` is a regular expression.
The attribute `t_omit` is used by the lexer to skip
blankspace or any other characters as defined in its
regular expression. Methods are also possible, for example:

```python
import parstools as _prs


class Lexer(
        _prs.StatefulLexer):
    """A lexer of keywords and identifiers."""

    def __init__(
            self):
        self._keywords = {
            'if':
                'IF',
            'else':
                'ELSE',
            'for':
                'FOR',
            'while':
                'WHILE'}

    def t_NAME(
            self,
            token):
        r"""
        [a-zA-Z]
        [a-zA-Z]*
        """
        symbol = self._keywords.get(
            token.value, 'NAME')
        return _prs.Token(
            symbol=symbol,
            value=token.value)

```

The docstring of the method is used as regex in the grammar.
The regexes are compiled using the module [`re`](
    https://docs.python.org/3/library/re.html), with the
option [`re.VERBOSE`](
    https://docs.python.org/3/library/re.html#re.VERBOSE),
so regexes can include blankspace, and so span multiple lines.

There is also a way to define a parser via a grammar
definition, but the interface is internal and may change.


## Parser definition

Parsers are defined as classes with methods named `p_...`.
Each method takes a parameter `p` and sets `p[0]` with the
result for that grammar production. Example:

```python
import os

import parstools


class Parser:
    """A basic parser."""

    def __init__(
            self):
        self.root_symbol = 'expr'
            # the grammar starts at symbol "expr"
        self._lexer = Lexer()
            # instance of a `StatefulLexer`
        self._parser = None
            # initialized when first parsing

    def parse(
            self,
            text:
                str):
        """Evaluate an expression."""
        self._build()
        tokens = self._lexer.parse(text)
        result = self._parser.parse(tokens)
        return result

    def build(
            self):
        """Create state machine of parser."""
        # already built ?
        if self._parser is not None:
            return
        # JSON filename
        path, _ = os.path.split(__file__)
        filename = 'calculator_parser_op_prec.json'
        cache_filepath = os.path.join(
            path, filename)
        # generate parser
        self._parser = parstools.methods_to_parser(
            self,
            cache_filepath=cache_filepath)

    def p_plus(
            self, p):
        """expr: expr PLUS expr"""
        p[0] = p[1] + p[3]

    ...
```

The JSON file is here stored in the same directory as
the Python file containing the parser definition. This is
convenient for packaging parsers built using `parstools`.

Also, make sure that `parstools` is installed for building
the `sdist` and wheel of your package, and that the JSON files
are copied to the install location. For example, when using
`setuptools` one way to ensure packaging of the JSON files is:

```python
import setuptools


def run_setup():
    ...
    setuptools.setup(
            name='package_name',
            ...
            packages=['package_name'],
            package_dir={'package_name': 'package_name'},
            package_data={
                'package_name': [
                    '_calculator_parser_state_machine.json']},
            include_package_data=True,
            ...
            )
```


### Parser with operator precedence

It is also possible to generate a parser that shifts or
reduces based on a given precedence of tokens, in addition
to the grammar's structure. This precedence is given as
a list of tuples when calling the function `methods_to_parser()`.
For example:

```python
class Parser:

    def __init__(   
            self):
        ...
        # lowest to highest precedence
        self.operator_precedence = [
            ('left', 'PLUS', 'MINUS'),
            ('left', 'ASTERISK', 'DIV')]

    def build(
            self):
        """Create state machine of parser."""
        ...
        # generate parser
        self._parser = parstools.methods_to_parser(
            self,
            operator_precedence=self.operator_precedence,
            cache_filepath=cache_filepath)
```

"left" declares associativity of the tokens in the tuple.
So `ASTERISK` has higher precedence than `PLUS`.
Thus, multiplication `*` will bind tighter than addition `+`.
Therefore, `1 + 2 * 3` is parsed the same as `1 + (2 * 3)`.
This is different than `(1 + 2) * 3`. Placing `PLUS` after
`ASTERISK` in the operator precedence would result in parsing
`1 + 2 * 3` as `(1 + 2) * 3`.
