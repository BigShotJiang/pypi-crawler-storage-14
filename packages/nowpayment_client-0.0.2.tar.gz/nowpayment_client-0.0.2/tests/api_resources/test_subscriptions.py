# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import httpx
import pytest
from respx import MockRouter

from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSubscriptions:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_create(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = client.subscriptions.create(
            email="test@example.com",
            subscription_plan_id=76215585,
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_create(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = client.subscriptions.with_raw_response.create(
            email="test@example.com",
            subscription_plan_id=76215585,
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_create(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.subscriptions.with_streaming_response.create(
            email="test@example.com",
            subscription_plan_id=76215585,
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, StreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_retrieve(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = client.subscriptions.retrieve(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_retrieve(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = client.subscriptions.with_raw_response.retrieve(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_retrieve(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.subscriptions.with_streaming_response.retrieve(
            sub_id="",
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, StreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_path_params_retrieve(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `sub_id` but received ''"):
            client.subscriptions.with_raw_response.retrieve(
                sub_id="",
                x_api_key="{{your_api_key}}",
            )

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_list(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = client.subscriptions.list(
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_list_with_all_params(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = client.subscriptions.list(
            x_api_key="{{your_api_key}}",
            is_active="is_active",
            limit="limit",
            offset="offset",
            status="status",
            subscription_plan_id="subscription_plan_id",
        )
        assert subscription.is_closed
        assert subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_list(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = client.subscriptions.with_raw_response.list(
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_list(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.subscriptions.with_streaming_response.list(
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, StreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_delete(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.delete("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = client.subscriptions.delete(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_delete(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.delete("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = client.subscriptions.with_raw_response.delete(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_delete(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.delete("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.subscriptions.with_streaming_response.delete(
            sub_id="",
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, StreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_path_params_delete(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `sub_id` but received ''"):
            client.subscriptions.with_raw_response.delete(
                sub_id="",
                x_api_key="{{your_api_key}}",
            )


class TestAsyncSubscriptions:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_create(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = await async_client.subscriptions.create(
            email="test@example.com",
            subscription_plan_id=76215585,
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert await subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_create(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = await async_client.subscriptions.with_raw_response.create(
            email="test@example.com",
            subscription_plan_id=76215585,
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_create(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.subscriptions.with_streaming_response.create(
            email="test@example.com",
            subscription_plan_id=76215585,
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_retrieve(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = await async_client.subscriptions.retrieve(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert await subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_retrieve(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = await async_client.subscriptions.with_raw_response.retrieve(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_retrieve(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.get("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.subscriptions.with_streaming_response.retrieve(
            sub_id="",
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_path_params_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `sub_id` but received ''"):
            await async_client.subscriptions.with_raw_response.retrieve(
                sub_id="",
                x_api_key="{{your_api_key}}",
            )

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_list(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = await async_client.subscriptions.list(
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert await subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_list_with_all_params(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = await async_client.subscriptions.list(
            x_api_key="{{your_api_key}}",
            is_active="is_active",
            limit="limit",
            offset="offset",
            status="status",
            subscription_plan_id="subscription_plan_id",
        )
        assert subscription.is_closed
        assert await subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_list(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = await async_client.subscriptions.with_raw_response.list(
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_list(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/subscriptions").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.subscriptions.with_streaming_response.list(
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_delete(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.delete("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        subscription = await async_client.subscriptions.delete(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )
        assert subscription.is_closed
        assert await subscription.json() == {"foo": "bar"}
        assert cast(Any, subscription.is_closed) is True
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_delete(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.delete("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        subscription = await async_client.subscriptions.with_raw_response.delete(
            sub_id="",
            x_api_key="{{your_api_key}}",
        )

        assert subscription.is_closed is True
        assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await subscription.json() == {"foo": "bar"}
        assert isinstance(subscription, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_delete(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.delete("/v1/subscriptions/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.subscriptions.with_streaming_response.delete(
            sub_id="",
            x_api_key="{{your_api_key}}",
        ) as subscription:
            assert not subscription.is_closed
            assert subscription.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await subscription.json() == {"foo": "bar"}
            assert cast(Any, subscription.is_closed) is True
            assert isinstance(subscription, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, subscription.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_path_params_delete(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `sub_id` but received ''"):
            await async_client.subscriptions.with_raw_response.delete(
                sub_id="",
                x_api_key="{{your_api_key}}",
            )
