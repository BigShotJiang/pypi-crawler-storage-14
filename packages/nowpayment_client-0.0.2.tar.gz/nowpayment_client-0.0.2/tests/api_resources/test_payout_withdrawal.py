# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client.types import PayoutWithdrawalRetrieveMinAmountResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPayoutWithdrawal:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_min_amount(self, client: NowpaymentClient) -> None:
        payout_withdrawal = client.payout_withdrawal.retrieve_min_amount(
            coin="",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PayoutWithdrawalRetrieveMinAmountResponse, payout_withdrawal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve_min_amount(self, client: NowpaymentClient) -> None:
        response = client.payout_withdrawal.with_raw_response.retrieve_min_amount(
            coin="",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout_withdrawal = response.parse()
        assert_matches_type(PayoutWithdrawalRetrieveMinAmountResponse, payout_withdrawal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_min_amount(self, client: NowpaymentClient) -> None:
        with client.payout_withdrawal.with_streaming_response.retrieve_min_amount(
            coin="",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout_withdrawal = response.parse()
            assert_matches_type(PayoutWithdrawalRetrieveMinAmountResponse, payout_withdrawal, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve_min_amount(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `coin` but received ''"):
            client.payout_withdrawal.with_raw_response.retrieve_min_amount(
                coin="",
                x_api_key="{{api-key}}",
            )


class TestAsyncPayoutWithdrawal:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_min_amount(self, async_client: AsyncNowpaymentClient) -> None:
        payout_withdrawal = await async_client.payout_withdrawal.retrieve_min_amount(
            coin="",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PayoutWithdrawalRetrieveMinAmountResponse, payout_withdrawal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_min_amount(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout_withdrawal.with_raw_response.retrieve_min_amount(
            coin="",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout_withdrawal = await response.parse()
        assert_matches_type(PayoutWithdrawalRetrieveMinAmountResponse, payout_withdrawal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_min_amount(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout_withdrawal.with_streaming_response.retrieve_min_amount(
            coin="",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout_withdrawal = await response.parse()
            assert_matches_type(PayoutWithdrawalRetrieveMinAmountResponse, payout_withdrawal, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve_min_amount(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `coin` but received ''"):
            await async_client.payout_withdrawal.with_raw_response.retrieve_min_amount(
                coin="",
                x_api_key="{{api-key}}",
            )
