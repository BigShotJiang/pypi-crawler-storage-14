# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client.types import (
    FiatPayoutListPayoutsResponse,
    FiatPayoutListAccountsResponse,
    FiatPayoutCreateAccountResponse,
    FiatPayoutListProvidersResponse,
    FiatPayoutRequestPayoutResponse,
    FiatPayoutListFiatCurrenciesResponse,
    FiatPayoutListCryptoCurrenciesResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestFiatPayouts:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_account(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.create_account(
            country_code="PH",
            currency="php",
            fields={
                "account_number": "1234567890",
                "country": "PH",
                "iban": "qwerty1234567890",
            },
            payment_code="php_aib",
            provider="transfi",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(FiatPayoutCreateAccountResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_account(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.create_account(
            country_code="PH",
            currency="php",
            fields={
                "account_number": "1234567890",
                "country": "PH",
                "iban": "qwerty1234567890",
            },
            payment_code="php_aib",
            provider="transfi",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(FiatPayoutCreateAccountResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_account(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.create_account(
            country_code="PH",
            currency="php",
            fields={
                "account_number": "1234567890",
                "country": "PH",
                "iban": "qwerty1234567890",
            },
            payment_code="php_aib",
            provider="transfi",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(FiatPayoutCreateAccountResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_accounts(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.list_accounts(
            id="id",
            currency="currency",
            date_from="dateFrom",
            date_to="dateTo",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            sort_by="sortBy",
        )
        assert_matches_type(FiatPayoutListAccountsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_accounts(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.list_accounts(
            id="id",
            currency="currency",
            date_from="dateFrom",
            date_to="dateTo",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            sort_by="sortBy",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(FiatPayoutListAccountsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_accounts(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.list_accounts(
            id="id",
            currency="currency",
            date_from="dateFrom",
            date_to="dateTo",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            sort_by="sortBy",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(FiatPayoutListAccountsResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_crypto_currencies(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.list_crypto_currencies(
            currency="currency",
            provider="provider",
        )
        assert_matches_type(FiatPayoutListCryptoCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_crypto_currencies(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.list_crypto_currencies(
            currency="currency",
            provider="provider",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(FiatPayoutListCryptoCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_crypto_currencies(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.list_crypto_currencies(
            currency="currency",
            provider="provider",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(FiatPayoutListCryptoCurrenciesResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_fiat_currencies(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.list_fiat_currencies()
        assert_matches_type(FiatPayoutListFiatCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_fiat_currencies(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.list_fiat_currencies()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(FiatPayoutListFiatCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_fiat_currencies(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.list_fiat_currencies() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(FiatPayoutListFiatCurrenciesResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_payment_methods(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.list_payment_methods(
            currency="currency",
            provider="provider",
        )
        assert_matches_type(object, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_payment_methods(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.list_payment_methods(
            currency="currency",
            provider="provider",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(object, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_payment_methods(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.list_payment_methods(
            currency="currency",
            provider="provider",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(object, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_payouts(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.list_payouts(
            id="id",
            crypto_currency="cryptoCurrency",
            date_from="dateFrom",
            date_to="dateTo",
            fiat_currency="fiatCurrency",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            provider_payout_id="provider_payout_id",
            request_id="requestId",
            sort_by="sortBy",
            status="status",
        )
        assert_matches_type(FiatPayoutListPayoutsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_payouts(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.list_payouts(
            id="id",
            crypto_currency="cryptoCurrency",
            date_from="dateFrom",
            date_to="dateTo",
            fiat_currency="fiatCurrency",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            provider_payout_id="provider_payout_id",
            request_id="requestId",
            sort_by="sortBy",
            status="status",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(FiatPayoutListPayoutsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_payouts(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.list_payouts(
            id="id",
            crypto_currency="cryptoCurrency",
            date_from="dateFrom",
            date_to="dateTo",
            fiat_currency="fiatCurrency",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            provider_payout_id="provider_payout_id",
            request_id="requestId",
            sort_by="sortBy",
            status="status",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(FiatPayoutListPayoutsResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_providers(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.list_providers()
        assert_matches_type(FiatPayoutListProvidersResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_providers(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.list_providers()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(FiatPayoutListProvidersResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_providers(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.list_providers() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(FiatPayoutListProvidersResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_request_payout(self, client: NowpaymentClient) -> None:
        fiat_payout = client.fiat_payouts.request_payout(
            amount=500,
            crypto_currency="bnbbsc",
            fiat_currency="eur",
            provider="transfi",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(FiatPayoutRequestPayoutResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_request_payout(self, client: NowpaymentClient) -> None:
        response = client.fiat_payouts.with_raw_response.request_payout(
            amount=500,
            crypto_currency="bnbbsc",
            fiat_currency="eur",
            provider="transfi",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = response.parse()
        assert_matches_type(FiatPayoutRequestPayoutResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_request_payout(self, client: NowpaymentClient) -> None:
        with client.fiat_payouts.with_streaming_response.request_payout(
            amount=500,
            crypto_currency="bnbbsc",
            fiat_currency="eur",
            provider="transfi",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = response.parse()
            assert_matches_type(FiatPayoutRequestPayoutResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncFiatPayouts:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_account(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.create_account(
            country_code="PH",
            currency="php",
            fields={
                "account_number": "1234567890",
                "country": "PH",
                "iban": "qwerty1234567890",
            },
            payment_code="php_aib",
            provider="transfi",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(FiatPayoutCreateAccountResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_account(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.create_account(
            country_code="PH",
            currency="php",
            fields={
                "account_number": "1234567890",
                "country": "PH",
                "iban": "qwerty1234567890",
            },
            payment_code="php_aib",
            provider="transfi",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(FiatPayoutCreateAccountResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_account(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.create_account(
            country_code="PH",
            currency="php",
            fields={
                "account_number": "1234567890",
                "country": "PH",
                "iban": "qwerty1234567890",
            },
            payment_code="php_aib",
            provider="transfi",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(FiatPayoutCreateAccountResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_accounts(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.list_accounts(
            id="id",
            currency="currency",
            date_from="dateFrom",
            date_to="dateTo",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            sort_by="sortBy",
        )
        assert_matches_type(FiatPayoutListAccountsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_accounts(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.list_accounts(
            id="id",
            currency="currency",
            date_from="dateFrom",
            date_to="dateTo",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            sort_by="sortBy",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(FiatPayoutListAccountsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_accounts(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.list_accounts(
            id="id",
            currency="currency",
            date_from="dateFrom",
            date_to="dateTo",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            sort_by="sortBy",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(FiatPayoutListAccountsResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_crypto_currencies(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.list_crypto_currencies(
            currency="currency",
            provider="provider",
        )
        assert_matches_type(FiatPayoutListCryptoCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_crypto_currencies(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.list_crypto_currencies(
            currency="currency",
            provider="provider",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(FiatPayoutListCryptoCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_crypto_currencies(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.list_crypto_currencies(
            currency="currency",
            provider="provider",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(FiatPayoutListCryptoCurrenciesResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_fiat_currencies(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.list_fiat_currencies()
        assert_matches_type(FiatPayoutListFiatCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_fiat_currencies(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.list_fiat_currencies()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(FiatPayoutListFiatCurrenciesResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_fiat_currencies(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.list_fiat_currencies() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(FiatPayoutListFiatCurrenciesResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_payment_methods(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.list_payment_methods(
            currency="currency",
            provider="provider",
        )
        assert_matches_type(object, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_payment_methods(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.list_payment_methods(
            currency="currency",
            provider="provider",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(object, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_payment_methods(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.list_payment_methods(
            currency="currency",
            provider="provider",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(object, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_payouts(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.list_payouts(
            id="id",
            crypto_currency="cryptoCurrency",
            date_from="dateFrom",
            date_to="dateTo",
            fiat_currency="fiatCurrency",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            provider_payout_id="provider_payout_id",
            request_id="requestId",
            sort_by="sortBy",
            status="status",
        )
        assert_matches_type(FiatPayoutListPayoutsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_payouts(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.list_payouts(
            id="id",
            crypto_currency="cryptoCurrency",
            date_from="dateFrom",
            date_to="dateTo",
            fiat_currency="fiatCurrency",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            provider_payout_id="provider_payout_id",
            request_id="requestId",
            sort_by="sortBy",
            status="status",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(FiatPayoutListPayoutsResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_payouts(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.list_payouts(
            id="id",
            crypto_currency="cryptoCurrency",
            date_from="dateFrom",
            date_to="dateTo",
            fiat_currency="fiatCurrency",
            filter="filter",
            limit="limit",
            order_by="orderBy",
            page="page",
            provider="provider",
            provider_payout_id="provider_payout_id",
            request_id="requestId",
            sort_by="sortBy",
            status="status",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(FiatPayoutListPayoutsResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_providers(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.list_providers()
        assert_matches_type(FiatPayoutListProvidersResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_providers(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.list_providers()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(FiatPayoutListProvidersResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_providers(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.list_providers() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(FiatPayoutListProvidersResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_request_payout(self, async_client: AsyncNowpaymentClient) -> None:
        fiat_payout = await async_client.fiat_payouts.request_payout(
            amount=500,
            crypto_currency="bnbbsc",
            fiat_currency="eur",
            provider="transfi",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(FiatPayoutRequestPayoutResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_request_payout(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.fiat_payouts.with_raw_response.request_payout(
            amount=500,
            crypto_currency="bnbbsc",
            fiat_currency="eur",
            provider="transfi",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        fiat_payout = await response.parse()
        assert_matches_type(FiatPayoutRequestPayoutResponse, fiat_payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_request_payout(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.fiat_payouts.with_streaming_response.request_payout(
            amount=500,
            crypto_currency="bnbbsc",
            fiat_currency="eur",
            provider="transfi",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            fiat_payout = await response.parse()
            assert_matches_type(FiatPayoutRequestPayoutResponse, fiat_payout, path=["response"])

        assert cast(Any, response.is_closed) is True
