# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import httpx
import pytest
from respx import MockRouter

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSubPartner:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_list(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = client.sub_partner.list(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
        )
        assert sub_partner.is_closed
        assert sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_list(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = client.sub_partner.with_raw_response.list(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_list(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.sub_partner.with_streaming_response.list(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, StreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_create_deposit(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/deposit").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = client.sub_partner.create_deposit(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
            x_api_key="{{x-api-token}}",
        )
        assert sub_partner.is_closed
        assert sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_create_deposit(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/deposit").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = client.sub_partner.with_raw_response.create_deposit(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
            x_api_key="{{x-api-token}}",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_create_deposit(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/deposit").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.sub_partner.with_streaming_response.create_deposit(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
            x_api_key="{{x-api-token}}",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, StreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_create_payment(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/payment").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = client.sub_partner.create_payment(
            amount=0.3,
            currency="trx",
            fixed_rate=False,
            sub_partner_id="1631380403",
            x_api_key="{{x-api-key}}",
        )
        assert sub_partner.is_closed
        assert sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_create_payment(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/payment").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = client.sub_partner.with_raw_response.create_payment(
            amount=0.3,
            currency="trx",
            fixed_rate=False,
            sub_partner_id="1631380403",
            x_api_key="{{x-api-key}}",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_create_payment(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/payment").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.sub_partner.with_streaming_response.create_payment(
            amount=0.3,
            currency="trx",
            fixed_rate=False,
            sub_partner_id="1631380403",
            x_api_key="{{x-api-key}}",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, StreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_create_transfer(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/transfer").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = client.sub_partner.create_transfer(
            amount=0.3,
            currency="trx",
            from_id=1111111,
            to_id=1111111,
            x_api_key="{{x-api-token}}",
        )
        assert sub_partner.is_closed
        assert sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_create_transfer(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/transfer").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = client.sub_partner.with_raw_response.create_transfer(
            amount=0.3,
            currency="trx",
            from_id=1111111,
            to_id=1111111,
            x_api_key="{{x-api-token}}",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_create_transfer(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/transfer").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.sub_partner.with_streaming_response.create_transfer(
            amount=0.3,
            currency="trx",
            from_id=1111111,
            to_id=1111111,
            x_api_key="{{x-api-token}}",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, StreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_create_write_off(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/write-off").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = client.sub_partner.create_write_off(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
        )
        assert sub_partner.is_closed
        assert sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_create_write_off(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/write-off").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = client.sub_partner.with_raw_response.create_write_off(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_create_write_off(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/write-off").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.sub_partner.with_streaming_response.create_write_off(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, StreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_payments(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.list_payments()
        assert_matches_type(object, sub_partner, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_payments(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.list_payments()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert_matches_type(object, sub_partner, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_payments(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.list_payments() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert_matches_type(object, sub_partner, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_list_transfers(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner/transfers").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = client.sub_partner.list_transfers(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
            status="status",
        )
        assert sub_partner.is_closed
        assert sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_list_transfers(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner/transfers").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = client.sub_partner.with_raw_response.list_transfers(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
            status="status",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_list_transfers(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner/transfers").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.sub_partner.with_streaming_response.list_transfers(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
            status="status",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, StreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True


class TestAsyncSubPartner:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_list(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = await async_client.sub_partner.list(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
        )
        assert sub_partner.is_closed
        assert await sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_list(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = await async_client.sub_partner.with_raw_response.list(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_list(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.sub_partner.with_streaming_response.list(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_create_deposit(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/deposit").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = await async_client.sub_partner.create_deposit(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
            x_api_key="{{x-api-token}}",
        )
        assert sub_partner.is_closed
        assert await sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_create_deposit(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/deposit").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = await async_client.sub_partner.with_raw_response.create_deposit(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
            x_api_key="{{x-api-token}}",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_create_deposit(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/deposit").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.sub_partner.with_streaming_response.create_deposit(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
            x_api_key="{{x-api-token}}",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_create_payment(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/payment").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = await async_client.sub_partner.create_payment(
            amount=0.3,
            currency="trx",
            fixed_rate=False,
            sub_partner_id="1631380403",
            x_api_key="{{x-api-key}}",
        )
        assert sub_partner.is_closed
        assert await sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_create_payment(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/payment").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = await async_client.sub_partner.with_raw_response.create_payment(
            amount=0.3,
            currency="trx",
            fixed_rate=False,
            sub_partner_id="1631380403",
            x_api_key="{{x-api-key}}",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_create_payment(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/payment").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.sub_partner.with_streaming_response.create_payment(
            amount=0.3,
            currency="trx",
            fixed_rate=False,
            sub_partner_id="1631380403",
            x_api_key="{{x-api-key}}",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_create_transfer(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/transfer").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = await async_client.sub_partner.create_transfer(
            amount=0.3,
            currency="trx",
            from_id=1111111,
            to_id=1111111,
            x_api_key="{{x-api-token}}",
        )
        assert sub_partner.is_closed
        assert await sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_create_transfer(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/transfer").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = await async_client.sub_partner.with_raw_response.create_transfer(
            amount=0.3,
            currency="trx",
            from_id=1111111,
            to_id=1111111,
            x_api_key="{{x-api-token}}",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_create_transfer(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/transfer").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.sub_partner.with_streaming_response.create_transfer(
            amount=0.3,
            currency="trx",
            from_id=1111111,
            to_id=1111111,
            x_api_key="{{x-api-token}}",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_create_write_off(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/sub-partner/write-off").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = await async_client.sub_partner.create_write_off(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
        )
        assert sub_partner.is_closed
        assert await sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_create_write_off(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/write-off").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = await async_client.sub_partner.with_raw_response.create_write_off(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_create_write_off(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/sub-partner/write-off").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.sub_partner.with_streaming_response.create_write_off(
            amount=0.3,
            currency="trx",
            sub_partner_id="1631380403",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_payments(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.list_payments()
        assert_matches_type(object, sub_partner, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_payments(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.list_payments()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert_matches_type(object, sub_partner, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_payments(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.list_payments() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert_matches_type(object, sub_partner, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_list_transfers(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/sub-partner/transfers").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        sub_partner = await async_client.sub_partner.list_transfers(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
            status="status",
        )
        assert sub_partner.is_closed
        assert await sub_partner.json() == {"foo": "bar"}
        assert cast(Any, sub_partner.is_closed) is True
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_list_transfers(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.get("/v1/sub-partner/transfers").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        sub_partner = await async_client.sub_partner.with_raw_response.list_transfers(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
            status="status",
        )

        assert sub_partner.is_closed is True
        assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await sub_partner.json() == {"foo": "bar"}
        assert isinstance(sub_partner, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_list_transfers(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.get("/v1/sub-partner/transfers").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.sub_partner.with_streaming_response.list_transfers(
            id="id",
            limit="limit",
            offset="offset",
            order="order",
            status="status",
        ) as sub_partner:
            assert not sub_partner.is_closed
            assert sub_partner.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await sub_partner.json() == {"foo": "bar"}
            assert cast(Any, sub_partner.is_closed) is True
            assert isinstance(sub_partner, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, sub_partner.is_closed) is True
