# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PayoutCreateResponse", "Withdrawal"]


class Withdrawal(BaseModel):
    id: str

    address: str

    amount: str

    batch_withdrawal_id: str

    created_at: str = FieldInfo(alias="createdAt")

    currency: str

    error: None = None

    extra_id: None = None

    hash: None = None

    ipn_callback_url: str

    is_request_payouts: bool

    payout_description: None = None

    requested_at: None = FieldInfo(alias="requestedAt", default=None)

    status: str

    unique_external_id: None = None

    updated_at: None = FieldInfo(alias="updatedAt", default=None)

    created_at: Optional[str] = None

    fiat_amount: Optional[str] = None

    fiat_currency: Optional[str] = None

    requested_at: None = None

    updated_at: None = None


class PayoutCreateResponse(BaseModel):
    id: str

    withdrawals: List[Withdrawal]
