# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PaymentListResponse", "Data"]


class Data(BaseModel):
    actually_paid: int

    order_description: str

    order_id: str

    outcome_amount: float

    outcome_currency: str

    pay_address: str

    pay_amount: float

    pay_currency: str

    payment_id: int

    payment_status: str

    price_amount: float

    price_currency: str

    purchase_id: str


class PaymentListResponse(BaseModel):
    data: List[Data]

    limit: int

    page: int

    pages_count: int = FieldInfo(alias="pagesCount")

    total: int
