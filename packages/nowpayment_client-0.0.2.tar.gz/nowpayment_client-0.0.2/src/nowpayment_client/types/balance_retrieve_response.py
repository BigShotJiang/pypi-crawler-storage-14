# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["BalanceRetrieveResponse", "Eth", "Trx", "Xmr"]


class Eth(BaseModel):
    amount: float

    pending_amount: int = FieldInfo(alias="pendingAmount")


class Trx(BaseModel):
    amount: int

    pending_amount: int = FieldInfo(alias="pendingAmount")


class Xmr(BaseModel):
    amount: int

    pending_amount: int = FieldInfo(alias="pendingAmount")


class BalanceRetrieveResponse(BaseModel):
    eth: Eth

    trx: Trx

    xmr: Xmr
