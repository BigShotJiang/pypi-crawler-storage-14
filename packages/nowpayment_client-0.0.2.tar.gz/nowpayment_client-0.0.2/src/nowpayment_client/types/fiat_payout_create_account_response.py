# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "FiatPayoutCreateAccountResponse",
    "Result",
    "ResultProviderAccountInfo",
    "ResultProviderAccountInfoMetaData",
]


class ResultProviderAccountInfoMetaData(BaseModel):
    iban: str

    number: str

    swiftbic: str

    vendor: str


class ResultProviderAccountInfo(BaseModel):
    api_v: int = FieldInfo(alias="__v")

    api_id: str = FieldInfo(alias="_id")

    account_number: str = FieldInfo(alias="accountNumber")

    country: str

    created_at: str = FieldInfo(alias="createdAt")

    currency: str

    display_name: str = FieldInfo(alias="displayName")

    last4_digits: str = FieldInfo(alias="last4Digits")

    logo: str

    meta_data: ResultProviderAccountInfoMetaData = FieldInfo(alias="metaData")

    pa_id: str = FieldInfo(alias="paId")

    payment_code: str = FieldInfo(alias="paymentCode")

    status: str

    type: str

    updated_at: str = FieldInfo(alias="updatedAt")

    user_id: str = FieldInfo(alias="userId")


class Result(BaseModel):
    id: str

    country_code: str = FieldInfo(alias="countryCode")

    created_at: str = FieldInfo(alias="createdAt")

    fiat_currency_code: str = FieldInfo(alias="fiatCurrencyCode")

    partner_id: str = FieldInfo(alias="partnerId")

    provider: str

    provider_account_id: str = FieldInfo(alias="providerAccountId")

    provider_account_info: ResultProviderAccountInfo = FieldInfo(alias="providerAccountInfo")

    updated_at: str = FieldInfo(alias="updatedAt")


class FiatPayoutCreateAccountResponse(BaseModel):
    result: Result
