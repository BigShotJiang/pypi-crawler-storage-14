# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["V1ListUsersParams"]


class V1ListUsersParams(TypedDict, total=False):
    id: Required[str]
    """int or array of int (optional)"""

    limit: Required[str]
    """(optional) default 10"""

    offset: Required[str]
    """(optional) default 0"""

    order: Required[str]
    """ASC / DESC (optional) default ASC"""
