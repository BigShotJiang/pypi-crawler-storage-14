# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutRequestPayoutResponse", "Result"]


class Result(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    crypto_currency_amount: str = FieldInfo(alias="cryptoCurrencyAmount")

    crypto_currency_code: str = FieldInfo(alias="cryptoCurrencyCode")

    error: None = None

    fiat_account_code: str = FieldInfo(alias="fiatAccountCode")

    fiat_account_number: str = FieldInfo(alias="fiatAccountNumber")

    fiat_amount: None = FieldInfo(alias="fiatAmount", default=None)

    fiat_currency_code: str = FieldInfo(alias="fiatCurrencyCode")

    payout_description: None = FieldInfo(alias="payoutDescription", default=None)

    provider: str

    request_id: None = FieldInfo(alias="requestId", default=None)

    status: str

    updated_at: str = FieldInfo(alias="updatedAt")


class FiatPayoutRequestPayoutResponse(BaseModel):
    result: Result
