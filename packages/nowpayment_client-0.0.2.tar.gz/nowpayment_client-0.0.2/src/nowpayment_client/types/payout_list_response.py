# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel

__all__ = ["PayoutListResponse", "Payout"]


class Payout(BaseModel):
    id: str

    address: str

    amount: str

    batch_withdrawal_id: str

    created_at: str

    currency: str

    error: None = None

    extra_id: None = None

    hash: str

    ipn_callback_url: None = None

    is_request_payouts: bool

    payout_description: None = None

    requested_at: str

    status: str

    unique_external_id: None = None

    updated_at: str


class PayoutListResponse(BaseModel):
    payouts: List[Payout]
