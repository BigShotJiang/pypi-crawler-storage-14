# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel

__all__ = ["FiatPayoutListProvidersResponse", "Result"]


class Result(BaseModel):
    code: Optional[str] = None

    enabled: Optional[bool] = None

    name: Optional[str] = None


class FiatPayoutListProvidersResponse(BaseModel):
    result: List[Result]
