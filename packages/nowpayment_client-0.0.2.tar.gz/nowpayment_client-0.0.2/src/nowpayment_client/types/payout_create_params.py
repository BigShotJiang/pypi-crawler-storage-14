# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PayoutCreateParams", "Withdrawal"]


class PayoutCreateParams(TypedDict, total=False):
    ipn_callback_url: Required[str]

    payout_description: Required[str]

    withdrawals: Required[Iterable[Withdrawal]]

    x_api_key: Required[Annotated[str, PropertyInfo(alias="x-api-key")]]


class Withdrawal(TypedDict, total=False):
    address: Required[str]

    amount: Required[float]

    currency: Required[str]

    ipn_callback_url: Required[str]
