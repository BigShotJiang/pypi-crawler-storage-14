# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["FiatPayoutListPayoutsParams"]


class FiatPayoutListPayoutsParams(TypedDict, total=False):
    id: Required[str]

    crypto_currency: Required[Annotated[str, PropertyInfo(alias="cryptoCurrency")]]

    date_from: Required[Annotated[str, PropertyInfo(alias="dateFrom")]]

    date_to: Required[Annotated[str, PropertyInfo(alias="dateTo")]]

    fiat_currency: Required[Annotated[str, PropertyInfo(alias="fiatCurrency")]]

    filter: Required[str]

    limit: Required[str]

    order_by: Required[Annotated[str, PropertyInfo(alias="orderBy")]]

    page: Required[str]

    provider: Required[str]

    provider_payout_id: Required[str]

    request_id: Required[Annotated[str, PropertyInfo(alias="requestId")]]

    sort_by: Required[Annotated[str, PropertyInfo(alias="sortBy")]]

    status: Required[str]
