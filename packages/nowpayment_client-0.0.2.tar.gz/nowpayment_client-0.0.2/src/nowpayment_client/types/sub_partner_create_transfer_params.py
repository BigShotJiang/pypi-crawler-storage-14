# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SubPartnerCreateTransferParams"]


class SubPartnerCreateTransferParams(TypedDict, total=False):
    amount: Required[float]

    currency: Required[str]

    from_id: Required[int]

    to_id: Required[int]

    x_api_key: Required[Annotated[str, PropertyInfo(alias="x-api-key")]]
