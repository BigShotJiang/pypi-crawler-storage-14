# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["FiatPayoutCreateAccountParams", "Fields"]


class FiatPayoutCreateAccountParams(TypedDict, total=False):
    country_code: Required[Annotated[str, PropertyInfo(alias="countryCode")]]

    currency: Required[str]

    fields: Required[Fields]

    payment_code: Required[Annotated[str, PropertyInfo(alias="paymentCode")]]

    provider: Required[str]

    x_api_key: Required[Annotated[str, PropertyInfo(alias="x-api-key")]]


class Fields(TypedDict, total=False):
    account_number: Required[Annotated[str, PropertyInfo(alias="accountNumber")]]

    country: Required[str]

    iban: Required[str]
