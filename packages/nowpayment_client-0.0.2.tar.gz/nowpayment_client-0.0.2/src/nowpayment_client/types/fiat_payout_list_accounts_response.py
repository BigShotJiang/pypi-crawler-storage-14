# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutListAccountsResponse", "Result", "ResultRow", "ResultRowProviderAccountInfo"]


class ResultRowProviderAccountInfo(BaseModel):
    account_number: str = FieldInfo(alias="accountNumber")

    currency: str

    display_name: str = FieldInfo(alias="displayName")

    payment_code: str = FieldInfo(alias="paymentCode")


class ResultRow(BaseModel):
    created_at: Optional[str] = FieldInfo(alias="createdAt", default=None)

    fiat_currency_code: Optional[str] = FieldInfo(alias="fiatCurrencyCode", default=None)

    provider: Optional[str] = None

    provider_account_info: Optional[ResultRowProviderAccountInfo] = FieldInfo(alias="providerAccountInfo", default=None)

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)


class Result(BaseModel):
    rows: List[ResultRow]


class FiatPayoutListAccountsResponse(BaseModel):
    result: Result
