# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["PaymentCreateResponse"]


class PaymentCreateResponse(BaseModel):
    amount_received: None = None

    burning_percent: None = None

    created_at: str

    expiration_estimate_date: str

    ipn_callback_url: str

    network: str

    network_precision: int

    order_description: str

    order_id: str

    pay_address: str

    pay_amount: float

    pay_currency: str

    payin_extra_id: None = None

    payment_id: str

    payment_status: str

    price_amount: float

    price_currency: str

    purchase_id: str

    smart_contract: str

    time_limit: None = None

    updated_at: str
