# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Query, Headers, NotGiven, not_given
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.invoice_payment_create_response import InvoicePaymentCreateResponse

__all__ = ["InvoicePaymentResource", "AsyncInvoicePaymentResource"]


class InvoicePaymentResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> InvoicePaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return InvoicePaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> InvoicePaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return InvoicePaymentResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InvoicePaymentCreateResponse:
        """Creates payment by invoice.

        With this method, your customer will be able to
        complete the payment without leaving your website.

        Be sure to consider the details of **repeated and wrong-asset deposits from
        'Repeated Deposits and Wrong-Asset Deposits' section** when processing payments.

        **Data must be sent as a JSON-object payload.**
        Required request fields:

        - iid (required) - invoice id. You can get invoice ID in response of **POST
          Create_invoice** method;
        - pay_currency (required) - the crypto currency in which the pay_amount is
          specified (btc, eth, etc). **NOTE: some of the currencies require a Memo,
          Destination Tag, etc., to complete a payment (AVA, EOS, BNBMAINNET, XLM, XRP).
          This is unique for each payment. This ID is received in “payin_extra_id”
          parameter of the response. Payments made without "payin_extra_id" cannot be
          detected automatically;**
        - order_description (optional) - inner store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - customer_email (optional) - user email to which a notification about the
          successful completion of the payment will be sent;
        - payout_address (optional) - usually the funds will go to the address you
          specify in your Personal account. In case you want to receive funds on another
          address, you can specify it in this parameter;
        - payout_extra_id(optional) - extra id or memo or tag for external
          payout_address;
        - payout_currency (optional) - currency of your external payout_address,
          required when payout_adress is specified;

        Here the list of available statuses of payment:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - refunded - the funds were refunded back to the user;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        **Please note: when you're creating a fiat2crypto payment you also should
        include additional header to your request - "origin-ip : xxx", where xxx is your
        customer IP address.**

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._post(
            "/v1/invoice-payment",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InvoicePaymentCreateResponse,
        )


class AsyncInvoicePaymentResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncInvoicePaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncInvoicePaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncInvoicePaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncInvoicePaymentResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InvoicePaymentCreateResponse:
        """Creates payment by invoice.

        With this method, your customer will be able to
        complete the payment without leaving your website.

        Be sure to consider the details of **repeated and wrong-asset deposits from
        'Repeated Deposits and Wrong-Asset Deposits' section** when processing payments.

        **Data must be sent as a JSON-object payload.**
        Required request fields:

        - iid (required) - invoice id. You can get invoice ID in response of **POST
          Create_invoice** method;
        - pay_currency (required) - the crypto currency in which the pay_amount is
          specified (btc, eth, etc). **NOTE: some of the currencies require a Memo,
          Destination Tag, etc., to complete a payment (AVA, EOS, BNBMAINNET, XLM, XRP).
          This is unique for each payment. This ID is received in “payin_extra_id”
          parameter of the response. Payments made without "payin_extra_id" cannot be
          detected automatically;**
        - order_description (optional) - inner store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - customer_email (optional) - user email to which a notification about the
          successful completion of the payment will be sent;
        - payout_address (optional) - usually the funds will go to the address you
          specify in your Personal account. In case you want to receive funds on another
          address, you can specify it in this parameter;
        - payout_extra_id(optional) - extra id or memo or tag for external
          payout_address;
        - payout_currency (optional) - currency of your external payout_address,
          required when payout_adress is specified;

        Here the list of available statuses of payment:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - refunded - the funds were refunded back to the user;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        **Please note: when you're creating a fiat2crypto payment you also should
        include additional header to your request - "origin-ip : xxx", where xxx is your
        customer IP address.**

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._post(
            "/v1/invoice-payment",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InvoicePaymentCreateResponse,
        )


class InvoicePaymentResourceWithRawResponse:
    def __init__(self, invoice_payment: InvoicePaymentResource) -> None:
        self._invoice_payment = invoice_payment

        self.create = to_raw_response_wrapper(
            invoice_payment.create,
        )


class AsyncInvoicePaymentResourceWithRawResponse:
    def __init__(self, invoice_payment: AsyncInvoicePaymentResource) -> None:
        self._invoice_payment = invoice_payment

        self.create = async_to_raw_response_wrapper(
            invoice_payment.create,
        )


class InvoicePaymentResourceWithStreamingResponse:
    def __init__(self, invoice_payment: InvoicePaymentResource) -> None:
        self._invoice_payment = invoice_payment

        self.create = to_streamed_response_wrapper(
            invoice_payment.create,
        )


class AsyncInvoicePaymentResourceWithStreamingResponse:
    def __init__(self, invoice_payment: AsyncInvoicePaymentResource) -> None:
        self._invoice_payment = invoice_payment

        self.create = async_to_streamed_response_wrapper(
            invoice_payment.create,
        )
