# Changelog

## 0.0.2 (2025-11-28)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/greatpie/nofa-nowpayment-client/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([a0e36fc](https://github.com/greatpie/nofa-nowpayment-client/commit/a0e36fc9c1adafbf2657107a5bc7239ce1bb764d))
* update SDK settings ([99c65b5](https://github.com/greatpie/nofa-nowpayment-client/commit/99c65b5abb284066c4287df3e53ea697feec66d7))
