class ConverterError(Exception):
    pass
