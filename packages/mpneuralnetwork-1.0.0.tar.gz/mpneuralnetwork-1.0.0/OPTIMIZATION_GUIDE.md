# Guide d'Optimisation pour MPNeuralNetwork

Ce guide détaille les actions concrètes pour améliorer drastiquement les performances (temps de calcul et empreinte mémoire) de la bibliothèque, identifiées suite à l'analyse du code.

## 1. Optimisation Mémoire (RAM)

L'analyse révèle que la consommation mémoire est actuellement **doublée** (voire triplée) inutilement.

### 🔴 Priorité 1 : Passage au `float32` (Gain : 50% RAM immédiat)
Actuellement, NumPy utilise par défaut `float64`. Pour le Deep Learning, `float32` (simple précision) est le standard et suffit amplement, tout en divisant la consommation mémoire par 2.

**Actions :**
1.  Définir une constante globale : `DTYPE = np.float32`.
2.  Forcer ce type dans **toutes** les initialisations de tableaux :
    *   `layer1d.py`, `layer2d.py` : `np.random.randn(...).astype(DTYPE)`
    *   `optimizers.py` : `np.zeros_like(..., dtype=DTYPE)`
    *   `im2col` / `col2im` : S'assurer que les matrices générées restent en `float32`.

### 🟠 Priorité 2 : Suppression des Copies Inutiles (Model)
La classe `Model` effectue des copies profondes des données à plusieurs endroits critiques.

**Actions :**
1.  **Dans `train()`** : Supprimer `X_copy = np.copy(X)`. Travailler directement sur `X` (ou une vue).
2.  **Dans `predict()` / `evaluate()`** : Supprimer `batch_copy = np.copy(batch)`. Les couches ne modifient pas l'entrée "in-place", cette copie est donc redondante et coûteuse.

### 🟡 Priorité 3 : Allocations "In-Place"
Beaucoup d'opérations créent des tableaux temporaires invisibles.

**Exemple (Optimiseur) :**
```python
# Actuel (Crée un tableau temporaire pour (lr * grad), puis un autre pour la soustraction)
param -= self.learning_rate * grad 

# Optimisé (Utilise le paramètre 'out' des ufuncs NumPy pour écrire directement dans la mémoire)
np.multiply(grad, self.learning_rate, out=grad) # Si grad n'est plus utilisé après
param -= grad
```

---

## 2. Optimisation Temporelle (CPU/Vitesse)

### 🔴 Priorité 1 : Mélange des Indices (Shuffling)
Actuellement, `model.train` mélange physiquement les données : `X_shuffled = X[permutation]`. Cela crée une copie géante de tout le dataset en RAM à *chaque époque*.

**Action :**
Ne mélanger que les indices.
```python
indices = np.arange(n_samples)
np.random.shuffle(indices)

for i in range(0, n_samples, batch_size):
    batch_idx = indices[i : i + batch_size]
    X_batch = X[batch_idx] # NumPy accède aux données sans tout copier au préalable
```

### 🟠 Priorité 2 : Optimisation `im2col` (Convolution)
La fonction `im2col` génère une matrice très large. C'est le goulot d'étranglement mémoire des CNN.

**Actions :**
1.  S'assurer que `im2col` n'est appelé qu'une fois par `forward`.
2.  Vérifier si `sliding_window_view` (utilisé actuellement) ne crée pas de copie mémoire implicite lors du `reshape` qui suit.
3.  L'utilisation de `float32` est critique ici car la matrice `im2col` est souvent 9x plus grande que l'image originale (pour un kernel 3x3).

### 🟡 Priorité 3 : Calcul des Métriques "Paresseux"
Si l'utilisateur demande des métriques lourdes (ex: `F1Score`, `TopKAccuracy`), les calculer à chaque batch ralentit énormément l'entraînement.

**Action :**
Ajouter une option (ou comportement par défaut) pour ne calculer les métriques complexes qu'à la **fin de l'époque** sur le jeu de validation, et se contenter de la `Loss` (rapide) pour l'affichage batch par batch.

---

## 3. Architecture & Design

### 🛠️ Refactorisation : Gestion d'État Optimiseur
L'utilisation de `id(param)` dans les optimiseurs (`self.velocities[id(param)]`) est fragile (problèmes lors du save/load ou copy).

**Action :**
Créer une classe `Parameter` qui encapsule :
*   La valeur (`data`)
*   Le gradient (`grad`)
*   Un identifiant unique stable (`uuid`)
*   (Optionnel) Le cache de l'optimiseur spécifique à ce paramètre.

Cela permettrait de ne plus dépendre de l'adresse mémoire (`id()`) de l'array NumPy, qui peut changer.
