import numpy as np

DTYPE = np.float32
