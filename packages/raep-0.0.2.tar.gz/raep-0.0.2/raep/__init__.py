"""
RAEP (Rapid Enzyme/Non-Enzyme Prediction) 包

提供酶/非酶预测功能，使用Multi-Property Pseudo-AAC + 序列长度 + CTD + 窗口化AAC + XGBoost算法。

主要功能：
- 单个蛋白质序列预测
- 多个蛋白质序列批量预测
- FASTA文件批量预测

使用方法：
```python
from raep_package import RAEP

# 初始化预测器
predictor = RAEP()

# 预测单个序列
prediction, probability = predictor.predict_sequence("YOUR_PROTEIN_SEQUENCE")
```

版本: 0.0.2
"""

from .model import RAEP

__version__ = "0.0.2"
__author__ = "DHY"
__email__ = "dhy.scut@outlook.com"

__all__ = ['RAEP']  # 定义公共API
