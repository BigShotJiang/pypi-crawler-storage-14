# RAEP: Rapid Enzyme/Non-Enzyme Prediction

[![Python Version](https://img.shields.io/badge/Python-3.8%2B-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

RAEP (Rapid Enzyme/Non-Enzyme Prediction) 是一个高效的蛋白质序列酶/非酶预测工具，基于多理化性质特征和XGBoost机器学习算法构建。

## 功能特性

- **高效预测**: 使用优化的特征提取和XGBoost模型，实现快速准确的酶/非酶分类
- **多模式支持**: 支持单个序列预测、多序列批量预测和FASTA文件批量预测
- **特征丰富**: 采用多理化性质伪氨基酸组成(Pseudo-AAC)、CTD特征和窗口化氨基酸组成
- **用户友好**: 提供简洁的Python API，易于集成到现有项目中
- **多进程优化**: 特征提取过程采用多进程并行处理，提高大规模数据集处理效率

## 安装方法

### 从PyPI安装（推荐）

```bash
pip install raep
```

### 从源码安装

```bash
# 克隆仓库（如果有）
git clone <repository-url>
cd RAEP

# 开发模式安装
pip install -e .
```

## 依赖项

- joblib: 用于模型保存和加载，以及并行处理
- numpy: 数值计算
- pandas: 数据处理
- scikit-learn: 机器学习工具和评估指标
- xgboost: 梯度提升树算法实现

## 基本使用

### 导入和初始化

```python
from raep_package import RAEP

# 默认初始化（使用内置模型）
predictor = RAEP()

# 使用自定义模型路径初始化
# predictor = RAEP(model_path="path/to/your/model.pkl")
```

### 单个序列预测

```python
# 预测单个蛋白质序列
sequence = "MVLSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTYFPHFDLSHGSAQVKGHGKKVADALTNAVAHVDDMPNALSALSDLHAHKLRVDPVNFKLLSHCLLVTLAAHLPAEFTPAVHASLDKFLASVSTVLTSKYR"
prediction, probability = predictor.predict_sequence(sequence)

print(f"预测结果: {'酶' if prediction == 1 else '非酶'}")
print(f"预测概率: 非酶={probability[0]:.4f}, 酶={probability[1]:.4f}")
```

### 多序列批量预测

```python
# 批量预测多个序列
sequences = [
    "MASMTGGQQMGRGSEF",
    "MKVLVVLVLLAVLVLA",
    "MDEKTTGWRGGHVA"
]

results = predictor.predict_sequences(sequences)

for i, (pred, prob) in enumerate(results, 1):
    print(f"序列 {i}: {'酶' if pred == 1 else '非酶'} (酶概率: {prob[1]:.4f})")
```

### FASTA文件批量预测

```python
# 从FASTA文件批量预测
fasta_path = "test_sequences.fasta"
results = predictor.predict_fasta(fasta_path)

print(f"预测结果 ({len(results)} 个序列):")
for i, (pred, prob) in enumerate(results, 1):
    print(f"序列 {i}: {'酶' if pred == 1 else '非酶'} (酶概率: {prob[1]:.4f})")
```

## API参考

### RAEP类

#### 初始化

```python
RAEP(model_path=None)
```

- **参数**:
  - `model_path`: 可选，自定义模型文件路径。如果不提供，将使用内置的`enzyme_xgb_model.pkl`模型。

#### 方法

##### predict_sequence

```python
predict_sequence(sequence)
```

预测单个蛋白质序列是否为酶。

- **参数**:
  - `sequence`: 字符串，蛋白质序列。
- **返回值**:
  - 元组 `(prediction, probability)`:
    - `prediction`: 整数，预测类别，0表示非酶，1表示酶。
    - `probability`: 列表，包含两个浮点数，表示预测为非酶和酶的概率。

##### predict_sequences

```python
predict_sequences(sequences)
```

批量预测多个蛋白质序列。

- **参数**:
  - `sequences`: 列表，包含多个蛋白质序列字符串。
- **返回值**:
  - 列表，每个元素是一个元组 `(prediction, probability)`，对应输入序列的预测结果。

##### predict_fasta

```python
predict_fasta(fasta_path)
```

从FASTA文件批量预测蛋白质序列。

- **参数**:
  - `fasta_path`: 字符串，FASTA文件路径。
- **返回值**:
  - 列表，每个元素是一个元组 `(prediction, probability)`，对应FASTA文件中序列的预测结果。

## 使用示例

查看项目中的 `example_usage.py` 文件，其中包含了完整的使用示例：

```bash
python example_usage.py
```

## 注意事项

1. **序列格式要求**: 输入序列应只包含标准的20种氨基酸的单字母代码（大写）。
2. **序列长度**: 工具会自动处理不同长度的序列，但过短的序列（如<10个氨基酸）可能影响预测准确性。
3. **多进程处理**: 特征提取过程默认使用多进程加速，会根据系统CPU核心数自动调整。
4. **模型文件**: 确保模型文件存在且可访问，特别是使用自定义模型路径时。

## 故障排除

### 常见问题

1. **无法导入RAEP包**: 确保包已正确安装在当前Python环境中。
2. **模型加载失败**: 检查模型文件路径是否正确，以及是否存在于指定位置。
3. **预测错误**: 检查输入序列格式是否正确，是否只包含标准氨基酸字母。
4. **性能问题**: 对于非常大的数据集，可以考虑分批次处理，避免内存溢出。

### 获取帮助

如果遇到问题，请联系作者：

- 作者: DHY
- 邮箱: dhy.scut@outlook.com

## 许可证

本项目采用MIT许可证。详见 [LICENSE](LICENSE) 文件。

## 致谢

本项目的开发得到了多个开源工具的支持，特别是XGBoost、scikit-learn等机器学习库。

---

*版本: 0.0.1*
*最后更新: 2024年*
