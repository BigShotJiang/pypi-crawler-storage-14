#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
解析策略模块

提供 ParseStrategy 抽象基类，所有出版商特定策略都应继承此基类。
"""

from .base import ParseStrategy

__all__ = ['ParseStrategy']
