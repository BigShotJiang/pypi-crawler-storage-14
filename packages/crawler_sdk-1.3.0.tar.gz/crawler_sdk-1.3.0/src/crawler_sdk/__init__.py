#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Crawler SDK - Academic Article Author Extraction SDK

A pluggable SDK for extracting author information from academic publisher websites.
Supports both browser-based (Playwright) and API-based extraction methods.

主要组件:
- strategies: 解析策略基类 (ParseStrategy) - 支持浏览器和 API 两种模式
- extractors: 邮箱提取器基类和责任链 (EmailExtractor, ExtractorChain)
- types: 数据类型定义 (ArticleInfo, AuthorDetail, CrawlResult, AuthorInfo)
- utils: 工具函数 (decorators, validators)
- http: HTTP 客户端模块 (HTTPClient, FingerprintManager, HeadersGenerator)

安装:
    pip install crawler-sdk           # 基础安装
    pip install crawler-sdk[http]     # 包含 HTTP 客户端
    pip install crawler-sdk[browser]  # 包含浏览器自动化
    pip install crawler-sdk[all]      # 全部功能

基本用法 - 浏览器模式:
    >>> from crawler_sdk import ParseStrategy, AuthorInfo
    >>> from crawler_sdk.extractors import ExtractorChain, ButtonClickExtractor
    >>>
    >>> class MyStrategy(ParseStrategy):
    ...     async def extract_authors(self, page):
    ...         # 实现提取逻辑
    ...         return [AuthorInfo(author_index=1, name="John Doe", emails=["john@example.com"])]
    ...
    ...     def get_selectors(self):
    ...         return {'author': '.author', 'email': '.email'}

API 模式用法 (HTTP 客户端):
    >>> from crawler_sdk import ParseStrategy, AuthorInfo
    >>>
    >>> class MyStrategy(ParseStrategy):
    ...     async def extract_authors_api(self, url: str):
    ...         # 使用内置 HTTP 客户端（带反检测）
    ...         response = await self.fetch_page(url, domain="example.com")
    ...         if response.success:
    ...             # 解析 response.text
    ...             pass
    ...         return [AuthorInfo(...)]
    ...
    ...     # 解析 DOI URL
    ...     real_url = await self.resolve_doi("https://doi.org/10.1016/...")
"""

__version__ = '1.2.0'
__author__ = 'Marketing Crawlers Team'

# Strategies
from .strategies import ParseStrategy

# Extractors
from .extractors import (
    EmailExtractor,
    ExtractorChain,
    EMAIL_PATTERN,
    ButtonClickExtractor,
    DirectTextExtractor,
    MetadataExtractor,
    JavaScriptExtractor,
    APIExtractor,
    APIExtractorChain,
)

# Types
from .types import (
    ArticleInfo,
    AuthorDetail,
    CrawlResult,
    AuthorInfo,
)

# Utils
from .utils import (
    retry,
    rate_limit,
    timeout,
    validate_email,
    validate_url,
    validate_doi,
    validate_isbn,
    validate_phone,
    validate_ipv4,
    validate_uuid,
    normalize_publisher_name,
    matches_publisher,
    find_matching_publisher,
)

# HTTP Client (optional - requires curl_cffi)
# Lazy import to avoid ImportError if curl_cffi not installed
def _get_http_exports():
    """Lazy import HTTP client components"""
    try:
        from .http import HTTPClient, FetchResponse, FingerprintManager, HeadersGenerator
        return {
            'HTTPClient': HTTPClient,
            'FetchResponse': FetchResponse,
            'FingerprintManager': FingerprintManager,
            'HeadersGenerator': HeadersGenerator,
        }
    except ImportError:
        return {}

# Make HTTP exports available if curl_cffi is installed
_http_exports = _get_http_exports()
if _http_exports:
    HTTPClient = _http_exports['HTTPClient']
    FetchResponse = _http_exports['FetchResponse']
    FingerprintManager = _http_exports['FingerprintManager']
    HeadersGenerator = _http_exports['HeadersGenerator']


__all__ = [
    # Version
    '__version__',
    # Strategies
    'ParseStrategy',
    # Extractors (Browser-based)
    'EmailExtractor',
    'ExtractorChain',
    'EMAIL_PATTERN',
    'ButtonClickExtractor',
    'DirectTextExtractor',
    'MetadataExtractor',
    'JavaScriptExtractor',
    # Extractors (API-based)
    'APIExtractor',
    'APIExtractorChain',
    # Types
    'ArticleInfo',
    'AuthorDetail',
    'CrawlResult',
    'AuthorInfo',
    # HTTP Client (optional)
    'HTTPClient',
    'FetchResponse',
    'FingerprintManager',
    'HeadersGenerator',
    # Decorators
    'retry',
    'rate_limit',
    'timeout',
    # Validators
    'validate_email',
    'validate_url',
    'validate_doi',
    'validate_isbn',
    'validate_phone',
    'validate_ipv4',
    'validate_uuid',
    # Publisher utils
    'normalize_publisher_name',
    'matches_publisher',
    'find_matching_publisher',
]
