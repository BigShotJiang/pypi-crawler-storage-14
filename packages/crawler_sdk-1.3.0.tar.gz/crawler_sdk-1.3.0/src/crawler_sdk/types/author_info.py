#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
作者信息数据结构

定义插件提取的作者详细信息的标准格式。
用于整个处理管道中的作者数据传递和序列化。
"""

from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class AuthorInfo:
    """
    作者的完整信息

    从插件的 extract_authors() 返回

    Attributes:
        author_index: 作者序号（1-based）
        name: 作者姓名
        emails: 邮箱列表
        affiliations: 机构列表
        extracted_at: 提取时间
        confidence: 信心度 (0-1)

    Example:
        >>> author = AuthorInfo(
        ...     author_index=1,
        ...     name="John Smith",
        ...     emails=["john@example.com"],
        ...     affiliations=["Harvard University"]
        ... )
        >>> author.has_email()  # True
        >>> author.primary_email  # "john@example.com"
    """

    # 必需字段
    author_index: int                      # 作者序号 (1, 2, 3, ...)
    name: str                              # 作者姓名

    # 可选字段
    emails: List[str] = field(default_factory=list)        # 邮箱列表
    affiliations: List[str] = field(default_factory=list)  # 机构列表

    # 元数据
    extracted_at: Optional[datetime] = None                 # 提取时间
    confidence: float = 1.0                                 # 信心度 (0-1)

    def __post_init__(self):
        """验证和规范化数据"""
        if self.author_index < 1:
            raise ValueError("author_index must be >= 1")

        self.name = self.name.strip()

        if self.confidence < 0.0 or self.confidence > 1.0:
            raise ValueError("confidence must be between 0 and 1")

        if self.extracted_at is None:
            self.extracted_at = datetime.now()

    def has_email(self) -> bool:
        """是否有邮箱信息"""
        return len(self.emails) > 0

    def has_affiliation(self) -> bool:
        """是否有机构信息"""
        return len(self.affiliations) > 0

    @property
    def primary_email(self) -> Optional[str]:
        """获取主邮箱（第一个邮箱）"""
        return self.emails[0] if self.emails else None

    @property
    def primary_affiliation(self) -> Optional[str]:
        """获取主机构（第一个机构）"""
        return self.affiliations[0] if self.affiliations else None

    @property
    def email(self) -> Optional[str]:
        """获取主邮箱（别名，兼容旧代码）"""
        return self.primary_email

    @property
    def email_count(self) -> int:
        """邮箱数量"""
        return len(self.emails)

    @property
    def affiliation_count(self) -> int:
        """机构数量"""
        return len(self.affiliations)

    def to_dict(self) -> dict:
        """转换为字典用于JSON序列化"""
        return {
            'name': self.name,
            'emails': self.emails,
            'affiliations': self.primary_affiliation or ""
        }

    def __repr__(self) -> str:
        """字符串表示"""
        return (
            f"AuthorInfo("
            f"index={self.author_index}, "
            f"name='{self.name}', "
            f"emails={self.email_count}, "
            f"affiliations={self.affiliation_count})"
        )
