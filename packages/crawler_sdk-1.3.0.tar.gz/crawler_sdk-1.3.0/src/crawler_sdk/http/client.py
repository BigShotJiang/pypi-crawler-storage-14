#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HTTP Client - Async HTTP client with anti-detection for web scraping

Features:
- Async HTTP requests with curl_cffi
- Browser fingerprint rotation
- Anti-detection headers
- Automatic retry with fingerprint switching
- DOI resolution support
- Rate limiting and cooldown handling
"""

import asyncio
import logging
import random
from typing import Optional, Dict, Any
from dataclasses import dataclass

from .fingerprint import FingerprintManager
from .headers import HeadersGenerator

logger = logging.getLogger(__name__)

# Check if curl_cffi is available
try:
    from curl_cffi.requests import AsyncSession
    CURL_CFFI_AVAILABLE = True
except ImportError:
    CURL_CFFI_AVAILABLE = False
    logger.warning("curl_cffi not installed. HTTP client will not work. Install with: pip install curl-cffi")


@dataclass
class FetchResponse:
    """HTTP response wrapper"""
    success: bool
    status_code: int
    text: str
    url: str
    headers: Dict[str, str]
    error: Optional[str] = None

    @property
    def ok(self) -> bool:
        """Check if response is successful (2xx status code)"""
        return 200 <= self.status_code < 300


class HTTPClient:
    """
    Async HTTP client with anti-detection capabilities

    Features:
    - Uses curl_cffi for TLS fingerprint impersonation
    - Automatic browser fingerprint rotation
    - Handles 429/403 with fingerprint switching
    - DOI URL resolution
    - Configurable retry logic

    Usage:
        client = HTTPClient()

        # Fetch a page
        response = await client.fetch(
            url="https://www.sciencedirect.com/...",
            domain="sciencedirect.com"
        )

        # Resolve DOI
        real_url = await client.resolve_doi("https://doi.org/10.1016/...")

        # Check response
        if response.success:
            html = response.text
    """

    def __init__(
        self,
        fingerprint_manager: Optional[FingerprintManager] = None,
        headers_generator: Optional[HeadersGenerator] = None,
        max_retries: int = 3,
        default_timeout: int = 10
    ):
        """
        Initialize HTTP client

        Args:
            fingerprint_manager: Custom FingerprintManager instance
            headers_generator: Custom HeadersGenerator instance
            max_retries: Maximum retry attempts per request
            default_timeout: Default request timeout in seconds
        """
        if not CURL_CFFI_AVAILABLE:
            raise ImportError(
                "curl_cffi is required for HTTPClient. "
                "Install with: pip install curl-cffi"
            )

        self._fingerprint_manager = fingerprint_manager or FingerprintManager()
        self._headers_generator = headers_generator or HeadersGenerator()
        self._max_retries = max_retries
        self._default_timeout = default_timeout
        self._session: Optional[AsyncSession] = None

    async def _get_session(self, fingerprint: str) -> AsyncSession:
        """Get or create async session with fingerprint"""
        # Always create new session with the specified fingerprint
        return AsyncSession(impersonate=fingerprint)

    async def fetch(
        self,
        url: str,
        domain: str,
        timeout: Optional[int] = None,
        check_content: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        max_retries: Optional[int] = None
    ) -> FetchResponse:
        """
        Fetch a URL with anti-detection

        Args:
            url: URL to fetch
            domain: Target domain for fingerprint selection
            timeout: Request timeout in seconds
            check_content: String that must be in response to be valid
            headers: Additional headers to include
            max_retries: Override default max retries

        Returns:
            FetchResponse with result
        """
        timeout = timeout or self._default_timeout
        retries = max_retries if max_retries is not None else self._max_retries
        last_error = None

        for attempt in range(retries):
            # Get fingerprint for this attempt
            fingerprint = self._fingerprint_manager.get_fingerprint(domain)
            if not fingerprint:
                # All fingerprints blocked, wait for recovery
                wait_time = self._fingerprint_manager.wait_for_recovery(domain)
                if wait_time and wait_time > 0:
                    logger.info(f"All fingerprints blocked, waiting {wait_time:.1f}s for recovery")
                    await asyncio.sleep(min(wait_time, 30))  # Cap at 30s
                    fingerprint = self._fingerprint_manager.get_fingerprint(domain)

                if not fingerprint:
                    return FetchResponse(
                        success=False,
                        status_code=0,
                        text="",
                        url=url,
                        headers={},
                        error="All fingerprints exhausted"
                    )

            try:
                # Generate headers
                request_headers = self._headers_generator.generate(fingerprint, domain)
                if headers:
                    request_headers.update(headers)

                # Make request
                session = await self._get_session(fingerprint)
                async with session:
                    response = await asyncio.wait_for(
                        session.get(url, headers=request_headers, allow_redirects=True),
                        timeout=timeout
                    )

                status_code = response.status_code
                text = response.text

                # Handle rate limiting
                if status_code == 429:
                    logger.warning(f"429 Rate Limited with fingerprint {fingerprint}")
                    self._fingerprint_manager.mark_blocked(domain, fingerprint, "429")
                    await self._random_delay(1, 3)
                    continue

                # Handle forbidden
                if status_code == 403:
                    logger.warning(f"403 Forbidden with fingerprint {fingerprint}")
                    self._fingerprint_manager.mark_blocked(domain, fingerprint, "403")
                    await self._random_delay(2, 5)
                    continue

                # Check content if required
                if check_content and check_content not in text:
                    logger.warning(f"Required content '{check_content}' not found in response")
                    last_error = f"Content check failed: '{check_content}' not in response"
                    continue

                # Success
                self._fingerprint_manager.mark_success(fingerprint)
                return FetchResponse(
                    success=True,
                    status_code=status_code,
                    text=text,
                    url=str(response.url),
                    headers=dict(response.headers)
                )

            except asyncio.TimeoutError:
                logger.warning(f"Timeout with fingerprint {fingerprint} (attempt {attempt + 1}/{retries})")
                self._fingerprint_manager.mark_blocked(domain, fingerprint, "timeout")
                last_error = "Request timeout"
                continue

            except Exception as e:
                logger.warning(f"Request failed with fingerprint {fingerprint}: {e}")
                self._fingerprint_manager.mark_blocked(domain, fingerprint, "unknown")
                last_error = str(e)
                continue

        # All retries exhausted
        return FetchResponse(
            success=False,
            status_code=0,
            text="",
            url=url,
            headers={},
            error=last_error or "Max retries exceeded"
        )

    async def resolve_doi(
        self,
        doi_url: str,
        timeout: Optional[int] = None,
        max_redirects: int = 5
    ) -> Optional[str]:
        """
        Resolve DOI URL to final destination URL

        Follows redirects from doi.org to the actual publisher page.

        Args:
            doi_url: DOI URL (e.g., "https://doi.org/10.1016/...")
            timeout: Request timeout in seconds
            max_redirects: Maximum redirects to follow

        Returns:
            Resolved URL or None if resolution failed
        """
        timeout = timeout or self._default_timeout

        # Get a fingerprint for DOI resolution
        fingerprint = self._fingerprint_manager.get_fingerprint("doi.org")
        if not fingerprint:
            logger.error("No fingerprints available for DOI resolution")
            return None

        try:
            headers = self._headers_generator.generate(fingerprint, "doi.org")

            session = await self._get_session(fingerprint)
            async with session:
                # Don't follow redirects, we want to capture the redirect URL
                response = await asyncio.wait_for(
                    session.get(
                        doi_url,
                        headers=headers,
                        allow_redirects=True,
                        max_redirects=max_redirects
                    ),
                    timeout=timeout
                )

                final_url = str(response.url)

                # Check if we got a real URL (not doi.org)
                if final_url and 'doi.org' not in final_url:
                    logger.debug(f"DOI resolved: {doi_url} -> {final_url}")
                    self._fingerprint_manager.mark_success(fingerprint)
                    return final_url

                # Try to extract from HTML if redirect didn't work
                if response.status_code == 200:
                    import re
                    # Look for meta refresh or canonical URL
                    html = response.text
                    match = re.search(r'<meta[^>]+http-equiv=["\']refresh["\'][^>]+url=([^"\'>\s]+)', html, re.I)
                    if match:
                        return match.group(1)

                    match = re.search(r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)', html, re.I)
                    if match:
                        return match.group(1)

                logger.warning(f"DOI resolution incomplete: {doi_url} -> {final_url}")
                return final_url if final_url != doi_url else None

        except asyncio.TimeoutError:
            logger.warning(f"DOI resolution timeout: {doi_url}")
            self._fingerprint_manager.mark_blocked("doi.org", fingerprint, "timeout")
            return None

        except Exception as e:
            logger.error(f"DOI resolution failed: {e}")
            self._fingerprint_manager.mark_blocked("doi.org", fingerprint, "unknown")
            return None

    async def _random_delay(self, min_seconds: float, max_seconds: float):
        """Add random delay between requests"""
        delay = random.uniform(min_seconds, max_seconds)
        await asyncio.sleep(delay)

    def reset_fingerprints(self, domain: Optional[str] = None):
        """
        Reset fingerprint block states

        Args:
            domain: Specific domain to reset, or None for all
        """
        if domain:
            self._fingerprint_manager.reset_domain(domain)
        else:
            self._fingerprint_manager.reset_all()

    def get_stats(self) -> Dict[str, Any]:
        """Get HTTP client statistics"""
        return {
            'fingerprint_stats': self._fingerprint_manager.get_stats(),
            'max_retries': self._max_retries,
            'default_timeout': self._default_timeout,
        }

    def __repr__(self):
        return f"HTTPClient(max_retries={self._max_retries}, timeout={self._default_timeout})"
