#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fingerprint Manager - Dynamic browser fingerprint management

Features:
- Maintain available fingerprint pool
- Track blocked fingerprints by domain
- Mark fingerprints unavailable on 429/403
- Auto-cooldown recovery mechanism
- Reset all fingerprint states after rounds
"""

import logging
import random
from typing import Dict, List, Optional
from threading import Lock
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class BlockInfo:
    """Block information"""
    blocked_at: datetime
    reason: str
    cooldown_seconds: int = 60  # Default 60 seconds cooldown


@dataclass
class FingerprintStatus:
    """Fingerprint status"""
    name: str
    blocked_domains: Dict[str, BlockInfo] = field(default_factory=dict)
    success_count: int = 0
    fail_count: int = 0
    last_used: Optional[datetime] = None
    last_blocked: Optional[datetime] = None


class FingerprintManager:
    """
    Dynamic browser fingerprint manager with cooldown recovery

    Features:
    - Manage fingerprint blocking independently by domain
    - Auto-rotate available fingerprints
    - Cooldown recovery: blocked fingerprints recover after timeout
    - 429/403 differentiated handling: 429 short cooldown, 403 longer
    - Thread-safe

    Usage:
        manager = FingerprintManager()

        # Get available fingerprint
        fp = manager.get_fingerprint("sciencedirect.com")

        # Mark 429 block (30s auto-recovery)
        manager.mark_blocked("sciencedirect.com", fp, reason="429")

        # Mark 403 block (120s auto-recovery)
        manager.mark_blocked("sciencedirect.com", fp, reason="403")

        # Reset after round
        manager.reset_all()
    """

    # Extended fingerprint library - curl_cffi supported browser fingerprints
    ALL_FINGERPRINTS = [
        # Chrome series (latest versions first)
        "chrome136", "chrome133a", "chrome131", "chrome124",
        "chrome123", "chrome120", "chrome119", "chrome116",
        "chrome110", "chrome107", "chrome104", "chrome101",
        "chrome100", "chrome99",
        # Edge series
        "edge101", "edge99",
        # Safari series
        "safari18_0", "safari17_0", "safari15_5", "safari15_3",
        "safari184", "safari180", "safari172_ios",
        # Firefox series
        "firefox135", "firefox133",
    ]

    # Cooldown times by block reason (seconds)
    COOLDOWN_TIMES = {
        "429": 30,      # 429 Rate Limited - 30s cooldown
        "403": 120,     # 403 Forbidden - 2min cooldown
        "timeout": 15,  # Timeout - 15s cooldown
        "unknown": 60,  # Unknown error - 1min cooldown
    }

    def __init__(
        self,
        fingerprints: Optional[List[str]] = None,
        cooldown_times: Optional[Dict[str, int]] = None
    ):
        """
        Initialize fingerprint manager

        Args:
            fingerprints: Custom fingerprint list, defaults to ALL_FINGERPRINTS
            cooldown_times: Custom cooldown time config
        """
        self._lock = Lock()
        self._fingerprints: Dict[str, FingerprintStatus] = {}

        # Merge custom cooldown times
        self._cooldown_times = {**self.COOLDOWN_TIMES}
        if cooldown_times:
            self._cooldown_times.update(cooldown_times)

        # Initialize fingerprint pool
        fp_list = fingerprints or self.ALL_FINGERPRINTS
        for fp in fp_list:
            self._fingerprints[fp] = FingerprintStatus(name=fp)

        # Statistics
        self._total_requests = 0
        self._total_blocks = 0
        self._total_recoveries = 0

        logger.debug(f"FingerprintManager initialized with {len(self._fingerprints)} fingerprints")

    def _is_fingerprint_available(self, status: FingerprintStatus, domain: str) -> bool:
        """
        Check if fingerprint is available (considering cooldown recovery)

        Args:
            status: Fingerprint status
            domain: Target domain

        Returns:
            True if fingerprint available (not blocked or recovered)
        """
        if domain not in status.blocked_domains:
            return True

        block_info = status.blocked_domains[domain]
        elapsed = (datetime.now() - block_info.blocked_at).total_seconds()

        if elapsed >= block_info.cooldown_seconds:
            # Cooldown complete, auto-recover
            del status.blocked_domains[domain]
            self._total_recoveries += 1
            logger.debug(
                f"Fingerprint '{status.name}' recovered for '{domain}' "
                f"after {elapsed:.1f}s cooldown"
            )
            return True

        return False

    def get_fingerprint(self, domain: str, exclude: Optional[List[str]] = None) -> Optional[str]:
        """
        Get available fingerprint for domain

        Args:
            domain: Target domain (e.g., "sciencedirect.com")
            exclude: Fingerprints to exclude

        Returns:
            Available fingerprint name, or None if all blocked
        """
        with self._lock:
            exclude_set = set(exclude or [])
            available = []

            for fp_name, status in self._fingerprints.items():
                if fp_name in exclude_set:
                    continue
                if self._is_fingerprint_available(status, domain):
                    available.append(fp_name)

            if not available:
                next_recovery = self._get_next_recovery_time(domain)
                if next_recovery:
                    logger.warning(
                        f"No available fingerprints for domain: {domain}, "
                        f"next recovery in {next_recovery:.1f}s"
                    )
                else:
                    logger.warning(f"No available fingerprints for domain: {domain}")
                return None

            # Randomly select an available fingerprint
            selected = random.choice(available)
            self._fingerprints[selected].last_used = datetime.now()
            self._total_requests += 1

            return selected

    def _get_next_recovery_time(self, domain: str) -> Optional[float]:
        """Get remaining time until next fingerprint recovery (seconds)"""
        min_remaining = None
        now = datetime.now()

        for status in self._fingerprints.values():
            if domain in status.blocked_domains:
                block_info = status.blocked_domains[domain]
                elapsed = (now - block_info.blocked_at).total_seconds()
                remaining = block_info.cooldown_seconds - elapsed
                if remaining > 0:
                    if min_remaining is None or remaining < min_remaining:
                        min_remaining = remaining

        return min_remaining

    def get_multiple_fingerprints(self, domain: str, count: int = 3) -> List[str]:
        """
        Get multiple available fingerprints (for retries)

        Args:
            domain: Target domain
            count: Number of fingerprints needed

        Returns:
            List of available fingerprints (may be less than requested)
        """
        with self._lock:
            available = [
                fp_name for fp_name, status in self._fingerprints.items()
                if self._is_fingerprint_available(status, domain)
            ]

            random.shuffle(available)
            return available[:count]

    def mark_blocked(self, domain: str, fingerprint: str, reason: str = "unknown"):
        """
        Mark fingerprint as blocked for domain

        Args:
            domain: Blocked domain
            fingerprint: Blocked fingerprint
            reason: Block reason (e.g., "429", "403", "timeout")
        """
        with self._lock:
            if fingerprint in self._fingerprints:
                status = self._fingerprints[fingerprint]

                # Get cooldown time
                cooldown = self._cooldown_times.get(reason, self._cooldown_times["unknown"])

                # Record block info
                status.blocked_domains[domain] = BlockInfo(
                    blocked_at=datetime.now(),
                    reason=reason,
                    cooldown_seconds=cooldown
                )
                status.fail_count += 1
                status.last_blocked = datetime.now()
                self._total_blocks += 1

                available_count = self._count_available_for_domain(domain)
                logger.debug(
                    f"Fingerprint '{fingerprint}' blocked for '{domain}' "
                    f"(reason: {reason}, cooldown: {cooldown}s, remaining: {available_count})"
                )

    def mark_success(self, fingerprint: str):
        """Mark fingerprint request success"""
        with self._lock:
            if fingerprint in self._fingerprints:
                self._fingerprints[fingerprint].success_count += 1

    def _count_available_for_domain(self, domain: str) -> int:
        """Count available fingerprints for domain (internal, must be called within lock)"""
        return sum(
            1 for status in self._fingerprints.values()
            if self._is_fingerprint_available(status, domain)
        )

    def get_available_count(self, domain: str) -> int:
        """Get available fingerprint count for domain"""
        with self._lock:
            return self._count_available_for_domain(domain)

    def is_domain_exhausted(self, domain: str) -> bool:
        """Check if all fingerprints are blocked for domain"""
        return self.get_available_count(domain) == 0

    def wait_for_recovery(self, domain: str) -> Optional[float]:
        """
        Get recovery wait time

        Returns:
            Seconds to wait, or None if fingerprints available
        """
        with self._lock:
            # First check if any fingerprints available
            for status in self._fingerprints.values():
                if self._is_fingerprint_available(status, domain):
                    return None

            # All blocked, return shortest wait time
            return self._get_next_recovery_time(domain)

    def reset_domain(self, domain: str):
        """
        Reset all block states for domain

        Args:
            domain: Domain to reset
        """
        with self._lock:
            reset_count = 0
            for status in self._fingerprints.values():
                if domain in status.blocked_domains:
                    del status.blocked_domains[domain]
                    reset_count += 1

            logger.debug(f"Reset {reset_count} fingerprints for domain: {domain}")

    def reset_all(self):
        """Reset all fingerprint block states (call at end of round)"""
        with self._lock:
            total_reset = 0
            for status in self._fingerprints.values():
                total_reset += len(status.blocked_domains)
                status.blocked_domains.clear()

            logger.debug(f"Reset all fingerprints, cleared {total_reset} blocks")

    def get_stats(self) -> Dict:
        """Get statistics"""
        with self._lock:
            blocked_by_domain: Dict[str, int] = {}
            for status in self._fingerprints.values():
                for domain in status.blocked_domains:
                    blocked_by_domain[domain] = blocked_by_domain.get(domain, 0) + 1

            return {
                'total_fingerprints': len(self._fingerprints),
                'total_requests': self._total_requests,
                'total_blocks': self._total_blocks,
                'total_recoveries': self._total_recoveries,
                'blocked_by_domain': blocked_by_domain,
                'cooldown_config': self._cooldown_times,
            }

    def __repr__(self):
        stats = self.get_stats()
        return (
            f"FingerprintManager("
            f"total={stats['total_fingerprints']}, "
            f"requests={stats['total_requests']}, "
            f"blocks={stats['total_blocks']}, "
            f"recoveries={stats['total_recoveries']})"
        )
