#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
邮箱提取器基础设施

提供责任链模式的基础架构:
- EmailExtractor: 提取器抽象基类
- ExtractorChain: 责任链管理器
- 通用提取器：ButtonClickExtractor, DirectTextExtractor, MetadataExtractor, JavaScriptExtractor
- API提取器：APIExtractor, APIExtractorChain
"""

from .base import EmailExtractor, EMAIL_PATTERN
from .chain import ExtractorChain
from .button_click import ButtonClickExtractor
from .direct_text import DirectTextExtractor
from .metadata import MetadataExtractor
from .javascript import JavaScriptExtractor
from .api_based import APIExtractor, APIExtractorChain

__all__ = [
    # Browser-based extractors (Playwright)
    'EmailExtractor',
    'ExtractorChain',
    'EMAIL_PATTERN',
    'ButtonClickExtractor',
    'DirectTextExtractor',
    'MetadataExtractor',
    'JavaScriptExtractor',
    # API-based extractors (non-browser)
    'APIExtractor',
    'APIExtractorChain',
]
