#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
邮箱提取器基类模块

实现责任链模式的基础架构,提供EmailExtractor抽象基类和ExtractorChain管理器。
"""

import re
import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Optional

try:
    from playwright.async_api import Page
except ImportError:
    Page = None  # Allow SDK to work without Playwright installed

logger = logging.getLogger(__name__)

# 标准邮箱正则表达式
EMAIL_PATTERN = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'


class EmailExtractor(ABC):
    """
    邮箱提取器抽象基类

    实现责任链模式,每个提取器尝试提取邮箱,失败则传递给下一个提取器。

    Attributes:
        name: 提取器名称,用于日志记录
        next_extractor: 链中的下一个提取器

    Example:
        >>> class CustomExtractor(EmailExtractor):
        ...     async def extract(self, page: Page, selector_config: Dict) -> List[str]:
        ...         # 实现自定义提取逻辑
        ...         return ['email@example.com']
        ...
        >>> extractor = CustomExtractor()
        >>> emails = await extractor.handle(page, config)
    """

    def __init__(self):
        """初始化提取器"""
        self.name = self.__class__.__name__
        self.next_extractor: Optional['EmailExtractor'] = None

    def set_next(self, extractor: 'EmailExtractor') -> 'EmailExtractor':
        """
        设置链中的下一个提取器

        Args:
            extractor: 下一个提取器实例

        Returns:
            设置的提取器实例(支持链式调用)

        Example:
            >>> extractor1.set_next(extractor2).set_next(extractor3)
        """
        self.next_extractor = extractor
        return extractor

    async def handle(self, page, selector_config: Dict) -> List[str]:
        """
        处理邮箱提取请求

        尝试提取邮箱,如果当前提取器无法提取,则传递给下一个提取器。

        Args:
            page: Playwright Page对象
            selector_config: 选择器配置字典

        Returns:
            提取到的邮箱地址列表

        Raises:
            Exception: 提取过程中的错误会被记录但不中断流程
        """
        logger.debug(f"🔍 {self.name} attempting extraction")

        try:
            # 尝试提取
            emails = await self.extract(page, selector_config)

            if emails:
                logger.info(f"✅ {self.name} extracted {len(emails)} emails")
                return emails
            else:
                logger.debug(f"⏭️  {self.name} found no emails, passing to next")

        except Exception as e:
            logger.warning(f"⚠️  {self.name} extraction failed: {e}")

        # 如果当前提取器失败或未找到邮箱,传递给下一个
        if self.next_extractor:
            return await self.next_extractor.handle(page, selector_config)

        # 链末端,返回空列表
        logger.debug(f"🔚 End of chain reached, no emails found")
        return []

    @abstractmethod
    async def extract(self, page, selector_config: Dict) -> List[str]:
        """
        实际的邮箱提取逻辑(子类必须实现)

        Args:
            page: Playwright Page对象
            selector_config: 选择器配置字典,包含各类CSS选择器

        Returns:
            提取到的邮箱地址列表

        Raises:
            NotImplementedError: 子类未实现此方法
        """
        pass

    def _validate_emails(self, emails: List[str]) -> List[str]:
        """
        验证和过滤邮箱地址

        Args:
            emails: 原始邮箱列表

        Returns:
            过滤后的有效邮箱列表
        """
        if not emails:
            return []

        # 去重
        emails = list(set(emails))

        # 过滤黑名单域名
        blacklist_domains = [
            'example.com',
            'example.org',
            'test.com',
            'localhost',
            'dummy.com',
            'sample.com',
            'noreply',
            'no-reply',
            'donotreply',
        ]

        filtered = []
        for email in emails:
            email_lower = email.lower()

            # 检查是否包含黑名单关键词
            if not any(bad in email_lower for bad in blacklist_domains):
                # 再次验证邮箱格式
                if re.match(EMAIL_PATTERN, email):
                    filtered.append(email)

        return filtered

    def _extract_emails_from_text(self, text: str) -> List[str]:
        """
        从文本中提取邮箱地址

        Args:
            text: 待提取的文本

        Returns:
            提取到的邮箱列表
        """
        if not text:
            return []

        # 移除常见的邮箱混淆字符
        text = text.replace('[at]', '@').replace('(at)', '@')
        text = text.replace('[dot]', '.').replace('(dot)', '.')
        text = text.replace(' at ', '@').replace(' dot ', '.')

        # 提取邮箱
        emails = re.findall(EMAIL_PATTERN, text)

        return self._validate_emails(emails)

    def __repr__(self) -> str:
        """字符串表示"""
        return f"<{self.name}>"
