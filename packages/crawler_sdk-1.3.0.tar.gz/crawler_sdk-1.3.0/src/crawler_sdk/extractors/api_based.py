#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API-based extractor (non-browser extraction approach)

提供基于API调用的作者信息提取接口，不依赖Playwright浏览器自动化。
用户可以实现基于HTTP API、反向工程、爬虫等各种方式的提取器。

This allows users to implement extraction methods like:
- curl_cffi (绕过Cloudflare的API调用)
- 反向工程 (Reverse engineering)
- 直接API调用 (Direct API calls)
- 自定义HTTP请求 (Custom HTTP requests)
"""

import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ..types import AuthorInfo

logger = logging.getLogger(__name__)


class APIExtractor(ABC):
    """
    API-based author extraction base class

    Provides an interface for extracting author information without browser automation.
    Different from EmailExtractor which works with Playwright Page objects.

    This is for methods like:
    - Reverse engineering (逆向工程)
    - Direct API calls
    - HTTP requests with curl_cffi or requests
    - Any non-browser approach

    Attributes:
        name: Extractor name for logging
        next_extractor: Next extractor in chain (for composition)

    Example:
        >>> class MyAPIExtractor(APIExtractor):
        ...     async def extract(self, article_data: Dict) -> List[AuthorInfo]:
        ...         # 自定义提取逻辑 - Custom extraction logic
        ...         return [AuthorInfo(...), ...]
        ...
        >>> extractor = MyAPIExtractor()
        >>> authors = await extractor.handle(article_data)
    """

    def __init__(self):
        """Initialize API extractor"""
        self.name = self.__class__.__name__
        self.next_extractor: Optional['APIExtractor'] = None

    def set_next(self, extractor: 'APIExtractor') -> 'APIExtractor':
        """
        Set next extractor in chain for composition

        Args:
            extractor: Next extractor instance

        Returns:
            The extractor (supports chaining)

        Example:
            >>> extractor1.set_next(extractor2).set_next(extractor3)
        """
        self.next_extractor = extractor
        return extractor

    async def handle(self, article_data: Dict[str, Any]) -> List[Any]:
        """
        Handle author extraction request

        Attempts extraction. If current extractor succeeds, returns results.
        Otherwise, passes to next extractor in chain.

        Args:
            article_data: Article information dict
                - May contain: url, doi, pii, title, etc.

        Returns:
            List of author objects (AuthorInfo or compatible)

        Example:
            >>> authors = await extractor.handle({'url': 'https://...', 'doi': '10.1234/...'})
        """
        logger.debug(f"🔍 {self.name} attempting extraction")

        try:
            authors = await self.extract(article_data)

            if authors:
                logger.info(f"✅ {self.name} extracted {len(authors)} authors")
                return authors
            else:
                logger.debug(f"⏭️  {self.name} found no authors, passing to next")

        except Exception as e:
            logger.warning(f"⚠️  {self.name} extraction failed: {e}")

        if self.next_extractor:
            return await self.next_extractor.handle(article_data)

        logger.debug(f"🔚 End of chain reached, no authors found")
        return []

    @abstractmethod
    async def extract(self, article_data: Dict[str, Any]) -> List[Any]:
        """
        Actual author extraction logic (subclasses must implement)

        Args:
            article_data: Article information dict
                - url: Article URL (optional)
                - doi: DOI string (optional)
                - pii: Elsevier PII (optional)
                - title: Article title (optional)
                - Other fields as needed

        Returns:
            List of author objects (can be empty)

        Raises:
            NotImplementedError: If subclass doesn't implement
        """
        pass

    def __repr__(self) -> str:
        """String representation"""
        return f"<{self.name}>"


class APIExtractorChain:
    """
    API-based extractor chain manager

    负责构建和执行API提取器链，允许多个API提取方法的组合。
    Manages building and executing chain of API extractors for flexible extraction.

    Attributes:
        head: Head extractor in chain
        extractors: List of all extractors

    Example:
        >>> chain = APIExtractorChain()
        >>> chain.add(ElsevierAPIExtractor())
        >>> chain.add(CustomAPIExtractor())
        >>> authors = await chain.execute({'doi': '10.1234/...'})

    用户可以:
    - 实现自己的API提取器 (Implement custom API extractors)
    - 组合多个方法 (Combine multiple methods)
    - 通过责任链实现灵活的降级方案 (Implement flexible fallback using chain)
    """

    def __init__(self):
        """Initialize API extractor chain"""
        self.head: Optional[APIExtractor] = None
        self.extractors: List[APIExtractor] = []

    def add(self, extractor: APIExtractor) -> 'APIExtractorChain':
        """
        Add extractor to end of chain

        Args:
            extractor: APIExtractor instance to add

        Returns:
            self (supports chaining)

        Example:
            >>> chain.add(extractor1).add(extractor2).add(extractor3)
        """
        if not isinstance(extractor, APIExtractor):
            raise TypeError(f"Expected APIExtractor, got {type(extractor)}")

        self.extractors.append(extractor)

        if not self.head:
            self.head = extractor
        else:
            current = self.head
            while current.next_extractor:
                current = current.next_extractor
            current.set_next(extractor)

        logger.debug(f"➕ Added {extractor.name} to API chain (position {len(self.extractors)})")

        return self

    async def execute(self, article_data: Dict[str, Any]) -> List[Any]:
        """
        Execute API extractor chain

        从头部开始，依次执行每个提取器。
        Starts from head and executes each extractor until success or chain ends.

        Args:
            article_data: Article information dict

        Returns:
            List of author objects

        Example:
            >>> authors = await chain.execute({'url': 'https://...', 'doi': '10.1234/...'})
        """
        if not self.head:
            logger.warning("⚠️  API Extractor chain is empty")
            return []

        logger.info(f"🚀 Starting API extractor chain with {len(self.extractors)} extractors")

        authors = await self.head.handle(article_data)

        if authors:
            logger.info(f"🎯 API chain completed: extracted {len(authors)} authors")
        else:
            logger.warning("❌ API chain completed: no authors found")

        return authors

    def get_extractors(self) -> List[str]:
        """
        Get list of all extractor names

        Returns:
            List of extractor name strings
        """
        return [e.name for e in self.extractors]

    def clear(self) -> None:
        """Clear all extractors from chain"""
        self.head = None
        self.extractors = []
        logger.debug("🧹 API extractor chain cleared")

    def __len__(self) -> int:
        """Return number of extractors in chain"""
        return len(self.extractors)

    def __repr__(self) -> str:
        """String representation"""
        extractor_names = ' -> '.join(self.get_extractors())
        return f"<APIExtractorChain: {extractor_names}>"
