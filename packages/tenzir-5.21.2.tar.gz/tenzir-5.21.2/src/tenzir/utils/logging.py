"""Compatibility wrapper that re-exports logging helpers from tenzir-common."""

from tenzir_common.logging import configure, get  # noqa: F401
