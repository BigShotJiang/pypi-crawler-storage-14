#!/usr/bin/env python3
import os
import sys
import base64
import re
import urllib.request
import ssl
from datetime import datetime
from pathlib import Path
from io import BytesIO
import asyncio

from mcp.server import Server
from mcp.types import Tool, TextContent
import mcp.server.stdio
from google import genai
from google.genai import types
from PIL import Image

# Configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    print("❌ Erreur : La variable GEMINI_API_KEY n'est pas définie", file=sys.stderr)
    sys.exit(1)

OUTPUT_DIR = Path.home() / "Downloads" / "nano-banana-outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Initialiser le client Gemini
client = genai.Client(api_key=GEMINI_API_KEY)

# Créer le serveur MCP
server = Server("nano-banana-mcp")


def generate_filename(prefix: str = "generated") -> str:
    """Génère un nom de fichier unique avec timestamp"""
    timestamp = datetime.now().isoformat().replace(":", "-").replace(".", "-")
    return f"{prefix}_{timestamp}.png"


def load_image_from_source(source: str) -> Image.Image:
    """
    Charge une image depuis différentes sources :
    - Chemin de fichier local
    - URL (http:// ou https://)
    - Base64 (data:image/... ou juste le base64)
    """
    ssl_context = ssl._create_unverified_context()
    
    # Détection base64
    if source.startswith("data:image"):
        base64_data = source.split(",", 1)[1]
        image_data = base64.b64decode(base64_data)
        return Image.open(BytesIO(image_data))
    elif re.match(r'^[A-Za-z0-9+/=]+$', source) and len(source) > 100:
        try:
            image_data = base64.b64decode(source)
            return Image.open(BytesIO(image_data))
        except:
            pass
    
    # Détection URL
    if source.startswith("http://") or source.startswith("https://"):
        with urllib.request.urlopen(source, context=ssl_context) as response:
            image_data = response.read()
            return Image.open(BytesIO(image_data))
    
    # Sinon, c'est un chemin local
    return Image.open(source)


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Liste tous les outils disponibles"""
    return [
        Tool(
            name="generate_image",
            description="Génère une image avec Gemini. "
                       "Supporte les ratios personnalisés, résolutions jusqu'à 4K, "
                       "et le grounding avec Google Search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "Description détaillée de l'image à générer",
                    },
                    "model": {
                        "type": "string",
                        "enum": ["flash", "pro"],
                        "default": "pro",
                        "description": 'Modèle à utiliser : "flash" (rapide, 1K) ou "pro" (avancé, jusqu\'à 4K)',
                    },
                    "aspect_ratio": {
                        "type": "string",
                        "enum": ["1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"],
                        "default": "1:1",
                        "description": "Ratio d'aspect de l'image",
                    },
                    "image_size": {
                        "type": "string",
                        "enum": ["1K", "2K", "4K"],
                        "default": "2K",
                        "description": 'Résolution de l\'image (uniquement pour le modèle "pro")',
                    },
                    "use_grounding": {
                        "type": "boolean",
                        "default": False,
                        "description": "Activer le grounding avec Google Search pour des informations en temps réel",
                    },
                },
                "required": ["prompt"],
            },
        ),
        Tool(
            name="generate_image_with_references",
            description="Génère une image en utilisant des images de référence. "
                       "Le modèle Pro supporte jusqu'à 14 images, Flash jusqu'à 3 images. "
                       "Les images peuvent être : URLs publiques, chemins locaux, ou base64.",
            inputSchema={
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "Description de l'image à générer",
                    },
                    "reference_images": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "URLs, chemins locaux ou base64 des images de référence. Max 14 pour Pro, 3 pour Flash",
                    },
                    "model": {
                        "type": "string",
                        "enum": ["flash", "pro"],
                        "default": "pro",
                        "description": "Modèle à utiliser",
                    },
                    "aspect_ratio": {
                        "type": "string",
                        "enum": ["1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"],
                        "default": "1:1",
                        "description": "Ratio d'aspect",
                    },
                    "image_size": {
                        "type": "string",
                        "enum": ["1K", "2K", "4K"],
                        "default": "2K",
                        "description": "Résolution (Pro uniquement)",
                    },
                },
                "required": ["prompt", "reference_images"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Gère les appels d'outils"""
    try:
        if name == "generate_image":
            return await generate_image(arguments)
        elif name == "generate_image_with_references":
            return await generate_image_with_references(arguments)
        else:
            raise ValueError(f"Outil inconnu : {name}")
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        return [TextContent(type="text", text=f"❌ Erreur : {str(e)}\n\nDétails:\n{error_details}")]


async def generate_image(args: dict) -> list[TextContent]:
    """Génère une image simple"""
    prompt = args["prompt"]
    model_type = args.get("model", "pro")
    aspect_ratio = args.get("aspect_ratio", "1:1")
    image_size = args.get("image_size", "2K")
    use_grounding = args.get("use_grounding", False)

    model_name = "gemini-2.5-flash-image" if model_type == "flash" else "gemini-3-pro-image-preview"

    config_params = {
        "response_modalities": ["TEXT", "IMAGE"],
        "image_config": types.ImageConfig(aspect_ratio=aspect_ratio),
    }

    if model_type != "flash":
        config_params["image_config"] = types.ImageConfig(
            aspect_ratio=aspect_ratio,
            image_size=image_size
        )

    if use_grounding:
        config_params["tools"] = [{"google_search": {}}]

    config = types.GenerateContentConfig(**config_params)

    response = client.models.generate_content(
        model=model_name,
        contents=[prompt],
        config=config
    )

    image_data = None
    text_response = ""

    for part in response.parts:
        if part.text is not None:
            text_response = part.text
        elif part.inline_data is not None:
            image = part.as_image()
            filename = generate_filename("nano-banana")
            filepath = OUTPUT_DIR / filename
            image.save(str(filepath))
            image_data = str(filepath)

    if not image_data:
        raise Exception("Aucune image générée dans la réponse")

    result = f"""✅ Image générée avec succès !

📁 Fichier : {image_data}
📐 Ratio : {aspect_ratio}
🎨 Modèle : {model_name}
"""

    if text_response:
        result += f"\n💬 Commentaire : {text_response}"

    return [TextContent(type="text", text=result)]


async def generate_image_with_references(args: dict) -> list[TextContent]:
    """Génère une image avec des images de référence"""
    prompt = args["prompt"]
    reference_images = args["reference_images"]
    model_type = args.get("model", "pro")
    aspect_ratio = args.get("aspect_ratio", "1:1")
    image_size = args.get("image_size", "2K")

    max_images = 3 if model_type == "flash" else 14
    if len(reference_images) > max_images:
        raise ValueError(f"Le modèle {model_type} supporte maximum {max_images} images de référence")

    model_name = "gemini-2.5-flash-image" if model_type == "flash" else "gemini-3-pro-image-preview"

    loaded_images = []
    for i, img_source in enumerate(reference_images):
        try:
            img = load_image_from_source(img_source)
            loaded_images.append(img)
            print(f"✓ Image {i+1}/{len(reference_images)} chargée", file=sys.stderr)
        except Exception as e:
            raise ValueError(f"Impossible de charger l'image {i+1} ({img_source[:50]}...): {str(e)}")

    contents = [prompt] + loaded_images

    config_params = {
        "response_modalities": ["TEXT", "IMAGE"],
        "image_config": types.ImageConfig(aspect_ratio=aspect_ratio),
    }

    if model_type != "flash":
        config_params["image_config"] = types.ImageConfig(
            aspect_ratio=aspect_ratio,
            image_size=image_size
        )

    config = types.GenerateContentConfig(**config_params)

    response = client.models.generate_content(
        model=model_name,
        contents=contents,
        config=config
    )

    image_data = None
    text_response = ""

    for part in response.parts:
        if part.text is not None:
            text_response = part.text
        elif part.inline_data is not None:
            image = part.as_image()
            filename = generate_filename("nano-banana-ref")
            filepath = OUTPUT_DIR / filename
            image.save(str(filepath))
            image_data = str(filepath)

    if not image_data:
        raise Exception("Aucune image générée dans la réponse")

    result = f"""✅ Image générée avec {len(reference_images)} référence(s) !

📁 Fichier : {image_data}
📐 Ratio : {aspect_ratio}
🎨 Modèle : {model_name}
"""

    if text_response:
        result += f"\n💬 Commentaire : {text_response}"

    return [TextContent(type="text", text=result)]


async def main():
    """Point d'entrée principal"""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        print("🎨 Nano Banana MCP Server démarré !", file=sys.stderr)
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def run():
    """Point d'entrée pour le package"""
    asyncio.run(main())


if __name__ == "__main__":
    run()