"""
OpsPilot TUI Module

Contains terminal user interface components.
"""

from .app import create_app

__all__ = ["create_app"]
