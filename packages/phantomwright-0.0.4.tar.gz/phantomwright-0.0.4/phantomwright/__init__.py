"""
Patchright + Stealth Plugin + User Behavior Simulation = PhantomWright
"""

__version__ = "0.0.4"