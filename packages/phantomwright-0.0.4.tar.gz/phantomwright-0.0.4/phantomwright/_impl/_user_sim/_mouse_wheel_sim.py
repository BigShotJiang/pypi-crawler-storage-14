import random
import logging

logger = logging.getLogger(__name__)

async def async_mouse_wheel(page):
    try:
        scroll_amount = random.randint(100, 300)
        await page.mouse.wheel(0, scroll_amount)
    except Exception as e:
        logger.error(f"Error simulating mouse wheel activity: {e}")

def sync_mouse_wheel(page):
    try:
        scroll_amount = random.randint(100, 300)
        page.mouse.wheel(0, scroll_amount)
    except Exception as e:
        logger.error(f"Error simulating mouse wheel activity: {e}")