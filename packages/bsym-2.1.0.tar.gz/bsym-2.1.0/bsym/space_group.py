from bsym import SymmetryGroup

class SpaceGroup(SymmetryGroup):

    class_str = 'SymmetryGroup'
