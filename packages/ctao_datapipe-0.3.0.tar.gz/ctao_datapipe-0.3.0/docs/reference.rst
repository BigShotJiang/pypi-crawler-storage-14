API Reference
=============

.. currentmodule:: datapipe

.. automodule:: datapipe
   :members:
