# Scripts for generating test data

These are just to help in generating the test data used by the OPTIMIZE and
COMPUTE use workflows, in case the data need to be re-produced in the future.
