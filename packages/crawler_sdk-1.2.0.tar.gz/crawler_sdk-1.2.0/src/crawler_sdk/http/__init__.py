#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HTTP Client Module - SDK HTTP utilities with anti-detection

Provides HTTP client functionality with browser fingerprint rotation,
anti-detection headers, and rate limiting for web scraping.

Components:
- HTTPClient: Async HTTP client with anti-detection
- FingerprintManager: Browser fingerprint rotation and blocking management
- HeadersGenerator: Generate realistic browser headers
- FetchResponse: HTTP response wrapper

Example:
    >>> from crawler_sdk.http import HTTPClient, FingerprintManager
    >>>
    >>> client = HTTPClient()
    >>> response = await client.fetch("https://example.com", domain="example.com")
    >>> print(response.text)
"""

from .client import HTTPClient, FetchResponse
from .fingerprint import FingerprintManager
from .headers import HeadersGenerator

__all__ = [
    'HTTPClient',
    'FetchResponse',
    'FingerprintManager',
    'HeadersGenerator',
]
