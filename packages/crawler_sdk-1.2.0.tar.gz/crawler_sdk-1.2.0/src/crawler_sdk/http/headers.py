#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Headers Generator - Generate realistic browser headers for anti-detection

Features:
- Generate realistic browser headers based on fingerprint
- Support multiple browser types (Chrome, Safari, Firefox, Edge)
- Randomize Accept-Language and other headers
- Domain-specific header customization
"""

import random
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class HeadersGenerator:
    """
    Generate realistic browser headers for HTTP requests

    Supports generating headers that match the browser fingerprint
    being used, with realistic Accept-Language, User-Agent, and
    other headers to avoid detection.

    Usage:
        generator = HeadersGenerator()

        # Generate headers for a fingerprint
        headers = generator.generate("chrome120", domain="sciencedirect.com")

        # Use with requests/curl_cffi
        response = session.get(url, headers=headers)
    """

    # Common Accept-Language values
    ACCEPT_LANGUAGES = [
        "en-US,en;q=0.9",
        "en-GB,en;q=0.9,en-US;q=0.8",
        "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
        "en,zh-CN;q=0.9,zh;q=0.8",
        "en-US,en;q=0.8",
    ]

    # Common Accept values
    ACCEPT_VALUES = [
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ]

    # Browser-specific Sec-CH-UA values
    SEC_CH_UA_MAP = {
        "chrome": '"Chromium";v="{version}", "Google Chrome";v="{version}", "Not-A.Brand";v="99"',
        "edge": '"Microsoft Edge";v="{version}", "Chromium";v="{version}", "Not-A.Brand";v="99"',
        "safari": None,  # Safari doesn't send Sec-CH-UA
        "firefox": None,  # Firefox doesn't send Sec-CH-UA
    }

    # Platform hints
    PLATFORMS = [
        ("Windows", '"Windows"'),
        ("macOS", '"macOS"'),
        ("Linux", '"Linux"'),
    ]

    def __init__(self):
        """Initialize headers generator"""
        self._cache: Dict[str, Dict[str, str]] = {}

    def generate(
        self,
        fingerprint: str,
        domain: Optional[str] = None,
        referer: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate headers for a fingerprint

        Args:
            fingerprint: Browser fingerprint (e.g., "chrome120", "safari18_0")
            domain: Target domain for Referer/Origin headers
            referer: Custom Referer URL

        Returns:
            Dictionary of HTTP headers
        """
        headers = {}

        # Parse browser type and version from fingerprint
        browser_type, version = self._parse_fingerprint(fingerprint)

        # Basic headers
        headers["Accept"] = random.choice(self.ACCEPT_VALUES)
        headers["Accept-Language"] = random.choice(self.ACCEPT_LANGUAGES)
        headers["Accept-Encoding"] = "gzip, deflate, br"
        headers["Connection"] = "keep-alive"
        headers["Upgrade-Insecure-Requests"] = "1"

        # Browser-specific headers
        if browser_type in ("chrome", "edge"):
            # Chromium-based browsers send Sec-CH-* headers
            platform, platform_hint = random.choice(self.PLATFORMS)

            headers["Sec-CH-UA-Mobile"] = "?0"
            headers["Sec-CH-UA-Platform"] = platform_hint
            headers["Sec-Fetch-Dest"] = "document"
            headers["Sec-Fetch-Mode"] = "navigate"
            headers["Sec-Fetch-Site"] = "none" if not referer else "same-origin"
            headers["Sec-Fetch-User"] = "?1"

            # Sec-CH-UA header
            sec_ch_ua_template = self.SEC_CH_UA_MAP.get(browser_type)
            if sec_ch_ua_template and version:
                headers["Sec-CH-UA"] = sec_ch_ua_template.format(version=version)

        # DNT (Do Not Track)
        if random.random() > 0.7:
            headers["DNT"] = "1"

        # Referer and Origin for domain
        if domain:
            if referer:
                headers["Referer"] = referer
            else:
                headers["Referer"] = f"https://www.{domain}/"

        # Cache control
        if random.random() > 0.5:
            headers["Cache-Control"] = "max-age=0"

        return headers

    def _parse_fingerprint(self, fingerprint: str) -> tuple:
        """
        Parse browser type and version from fingerprint string

        Args:
            fingerprint: Fingerprint string (e.g., "chrome120", "safari18_0")

        Returns:
            Tuple of (browser_type, version)
        """
        fingerprint = fingerprint.lower()

        # Chrome
        if fingerprint.startswith("chrome"):
            version_str = fingerprint.replace("chrome", "").replace("a", "")
            return ("chrome", version_str)

        # Edge
        if fingerprint.startswith("edge"):
            version_str = fingerprint.replace("edge", "")
            return ("edge", version_str)

        # Safari
        if fingerprint.startswith("safari"):
            version_str = fingerprint.replace("safari", "").replace("_", ".")
            return ("safari", version_str)

        # Firefox
        if fingerprint.startswith("firefox"):
            version_str = fingerprint.replace("firefox", "")
            return ("firefox", version_str)

        # Unknown
        return ("unknown", None)

    def generate_for_api(
        self,
        fingerprint: str,
        domain: Optional[str] = None,
        content_type: str = "application/json"
    ) -> Dict[str, str]:
        """
        Generate headers for API requests

        Similar to generate() but with API-specific headers

        Args:
            fingerprint: Browser fingerprint
            domain: Target domain
            content_type: Content-Type header value

        Returns:
            Dictionary of HTTP headers
        """
        headers = self.generate(fingerprint, domain)

        # Override Accept for API
        headers["Accept"] = "application/json, text/plain, */*"

        # Add Content-Type if needed
        if content_type:
            headers["Content-Type"] = content_type

        # XHR indicator
        headers["X-Requested-With"] = "XMLHttpRequest"

        return headers

    def __repr__(self):
        return f"HeadersGenerator(cached={len(self._cache)})"
