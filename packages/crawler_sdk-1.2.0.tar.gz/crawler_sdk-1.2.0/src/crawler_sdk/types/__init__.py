#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SDK 数据类型定义

提供核心数据模型，定义系统中各组件之间的数据契约。
"""

from .models import ArticleInfo, AuthorDetail, CrawlResult
from .author_info import AuthorInfo

__all__ = [
    'ArticleInfo',
    'AuthorDetail',
    'CrawlResult',
    'AuthorInfo',
]
