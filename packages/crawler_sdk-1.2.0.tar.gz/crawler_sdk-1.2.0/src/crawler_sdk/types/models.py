#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
核心数据模型定义

定义系统中各组件之间的数据契约：
- ArticleInfo: 数据源爬虫 → 模板
- AuthorDetail: 插件 → 模板
- CrawlResult: 模板最终输出
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any


@dataclass
class ArticleInfo:
    """
    数据源爬虫输出的文章信息

    这是数据源（如 Scilit）提供给模板的数据结构。
    包含文章的基本信息和初步的作者列表。

    Attributes:
        title: 文章标题（必需）
        url: 文章最终URL（可选）
        authors_raw: 初步作者名单（来自数据源 API）
        doi: 数字对象标识符（可选）
        publisher: 出版商名称
        year: 发表年份
        journal: 期刊名称
        source: 数据源标识（如 'scilit', 'pubmed'）
        fetched_at: 获取时间
    """
    # 必需字段
    title: str

    # 可选字段（但至少需要 url 或 doi 之一）
    url: Optional[str] = None
    authors_raw: List[str] = field(default_factory=list)
    doi: Optional[str] = None
    publisher: Optional[str] = None
    year: Optional[int] = None
    journal: Optional[str] = None
    source: str = ""
    fetched_at: Optional[datetime] = None

    # 扩展元数据
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """验证和规范化数据"""
        if not self.title:
            raise ValueError("title is required")

        if not self.url and not self.doi:
            raise ValueError("Article must have either url or doi")

        self.title = self.title.strip()
        if self.url:
            self.url = self.url.strip()
        if self.doi:
            self.doi = self.doi.strip()

        if self.fetched_at is None:
            self.fetched_at = datetime.now()

    @property
    def domain(self) -> str:
        """提取 URL 的域名"""
        if not self.url:
            return ""

        from urllib.parse import urlparse
        parsed = urlparse(self.url)
        return parsed.netloc.lower().replace('www.', '')

    @property
    def author_count(self) -> int:
        """初步作者数量"""
        return len(self.authors_raw)

    def to_dict(self, authors_info: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'title': self.title,
            'author': ', '.join(self.authors_raw) if self.authors_raw else '',
            'publisher': self.publisher,
            'url': self.url,
            'authors_info': authors_info if authors_info is not None else [],
        }


@dataclass
class AuthorDetail:
    """
    作者采集插件输出的详细信息

    这是解析插件提供给模板的作者详细信息。
    包含邮箱、机构等需要从出版商页面提取的信息。

    Attributes:
        author_index: 作者序号（从1开始）
        name: 作者姓名
        emails: 邮箱列表
        affiliations: 机构列表
    """
    author_index: int
    name: str
    emails: List[str] = field(default_factory=list)
    affiliations: List[str] = field(default_factory=list)

    def __post_init__(self):
        """验证数据"""
        if self.author_index < 1:
            raise ValueError("author_index must be >= 1")
        if not self.name:
            raise ValueError("name is required")

        self.name = self.name.strip()
        self.emails = list(dict.fromkeys(e.strip().lower() for e in self.emails if e.strip()))
        self.affiliations = list(dict.fromkeys(a.strip() for a in self.affiliations if a.strip()))

    @property
    def has_email(self) -> bool:
        """是否有邮箱"""
        return len(self.emails) > 0

    @property
    def primary_email(self) -> Optional[str]:
        """主邮箱（第一个）"""
        return self.emails[0] if self.emails else None

    @property
    def primary_affiliation(self) -> Optional[str]:
        """主机构（第一个）"""
        return self.affiliations[0] if self.affiliations else None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'name': self.name,
            'emails': '; '.join(self.emails),
            'affiliations': '; '.join(self.affiliations),
        }


@dataclass
class CrawlResult:
    """
    单篇文章的完整采集结果

    这是模板方法最终输出的数据结构，包含文章信息、
    作者详情、处理状态等完整信息。

    Attributes:
        article: 原始文章信息
        authors: 作者详细信息列表
        success: 是否成功
        error_message: 错误信息（如果失败）
        parsed_at: 解析时间
        parser_name: 使用的解析器名称
    """
    article: ArticleInfo
    authors: List[AuthorDetail]
    success: bool
    error_message: Optional[str] = None
    parsed_at: Optional[datetime] = None
    parser_name: Optional[str] = None

    def __post_init__(self):
        """设置默认值"""
        if self.parsed_at is None:
            self.parsed_at = datetime.now()

    @property
    def author_count(self) -> int:
        """作者数量"""
        return len(self.authors)

    @property
    def email_count(self) -> int:
        """提取到的邮箱总数"""
        return sum(len(author.emails) for author in self.authors)

    @property
    def authors_with_email(self) -> int:
        """有邮箱的作者数量"""
        return sum(1 for author in self.authors if author.has_email)

    @property
    def email_rate(self) -> float:
        """邮箱提取率"""
        if not self.authors:
            return 0.0
        return self.authors_with_email / len(self.authors)

    def get_all_emails(self) -> List[str]:
        """获取所有邮箱"""
        emails = []
        for author in self.authors:
            emails.extend(author.emails)
        return emails

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'article': self.article.to_dict(),
            'authors': [author.to_dict() for author in self.authors],
            'success': self.success,
            'error_message': self.error_message,
            'parsed_at': self.parsed_at.isoformat() if self.parsed_at else None,
            'parser_name': self.parser_name,
            'stats': {
                'email_count': self.email_count,
                'authors_with_email': self.authors_with_email,
                'email_rate': self.email_rate,
            }
        }

    @classmethod
    def from_error(cls, article: ArticleInfo, error: str, parser_name: Optional[str] = None) -> 'CrawlResult':
        """创建错误结果的便捷方法"""
        return cls(
            article=article,
            authors=[],
            success=False,
            error_message=error,
            parser_name=parser_name
        )
