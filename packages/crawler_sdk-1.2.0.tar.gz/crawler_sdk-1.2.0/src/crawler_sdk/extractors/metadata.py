#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
元数据邮箱提取器

从页面元数据和结构化数据中提取邮箱地址。
支持meta标签、JSON-LD、Open Graph等格式。
"""

import json
import logging
from typing import List, Dict, Any

from .base import EmailExtractor

logger = logging.getLogger(__name__)


class MetadataExtractor(EmailExtractor):
    """
    元数据提取器

    策略:
    1. 从HTML meta标签提取邮箱信息
    2. 从JSON-LD结构化数据提取
    3. 从microdata和RDFa提取

    适用场景:
    - 包含结构化数据的学术网站
    - 使用Schema.org标记的网站
    - 提供完整元数据的出版商网站

    Example:
        >>> extractor = MetadataExtractor()
        >>> emails = await extractor.extract(page, {})
    """

    async def extract(self, page, selector_config: Dict) -> List[str]:
        """
        从元数据和结构化数据提取邮箱

        Args:
            page: Playwright Page对象
            selector_config: 选择器配置

        Returns:
            提取到的邮箱列表
        """
        emails = []

        try:
            logger.debug("Extracting from meta tags")
            emails.extend(await self._extract_from_meta_tags(page))

            logger.debug("Extracting from JSON-LD")
            emails.extend(await self._extract_from_jsonld(page))

            logger.debug("Extracting from microdata")
            emails.extend(await self._extract_from_microdata(page))

            logger.debug("Extracting from RDFa")
            emails.extend(await self._extract_from_rdfa(page))

            emails = self._validate_emails(emails)

            if emails:
                logger.info(f"✅ Metadata extraction found {len(emails)} emails")

        except Exception as e:
            logger.warning(f"Metadata extraction failed: {e}")
            return []

        return emails

    async def _extract_from_meta_tags(self, page) -> List[str]:
        """从meta标签提取邮箱"""
        emails = []

        try:
            meta_data = await page.evaluate('''() => {
                const metas = [];
                const metaTags = document.querySelectorAll('meta');
                const emailAttributes = [
                    'author-email', 'contact-email', 'correspondence-email',
                    'email', 'dc.creator.email', 'citation_author_email'
                ];

                metaTags.forEach(meta => {
                    const name = meta.getAttribute('name') || meta.getAttribute('property') || '';
                    const content = meta.getAttribute('content') || '';
                    if (content && emailAttributes.some(attr => name.toLowerCase().includes(attr))) {
                        metas.push(content);
                    }
                });

                return metas;
            }''')

            if meta_data:
                for data in meta_data:
                    extracted = self._extract_emails_from_text(data)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from meta tags")

        except Exception as e:
            logger.debug(f"Failed to extract from meta tags: {e}")

        return emails

    async def _extract_from_jsonld(self, page) -> List[str]:
        """从JSON-LD结构化数据提取邮箱"""
        emails = []

        try:
            jsonld_scripts = await page.evaluate('''() => {
                const scripts = document.querySelectorAll('script[type="application/ld+json"]');
                return Array.from(scripts).map(script => script.textContent);
            }''')

            if jsonld_scripts:
                for script_content in jsonld_scripts:
                    try:
                        data = json.loads(script_content)
                        emails.extend(self._extract_emails_from_jsonld_data(data))
                    except json.JSONDecodeError:
                        continue

                logger.debug(f"Found {len(emails)} emails from JSON-LD")

        except Exception as e:
            logger.debug(f"Failed to extract from JSON-LD: {e}")

        return emails

    def _extract_emails_from_jsonld_data(self, data: Any) -> List[str]:
        """递归提取JSON-LD数据中的邮箱"""
        emails = []

        if isinstance(data, dict):
            email_fields = ['email', 'contactPoint', 'author', 'creator', 'correspondence']

            for key, value in data.items():
                if any(field in key.lower() for field in email_fields):
                    if isinstance(value, str):
                        extracted = self._extract_emails_from_text(value)
                        emails.extend(extracted)
                    elif isinstance(value, dict) and 'email' in value:
                        extracted = self._extract_emails_from_text(str(value['email']))
                        emails.extend(extracted)

                emails.extend(self._extract_emails_from_jsonld_data(value))

        elif isinstance(data, list):
            for item in data:
                emails.extend(self._extract_emails_from_jsonld_data(item))

        elif isinstance(data, str):
            extracted = self._extract_emails_from_text(data)
            emails.extend(extracted)

        return emails

    async def _extract_from_microdata(self, page) -> List[str]:
        """从HTML5 microdata提取邮箱"""
        emails = []

        try:
            microdata_emails = await page.evaluate('''() => {
                const emails = [];

                const emailProps = document.querySelectorAll('[itemprop*="email"]');
                emailProps.forEach(el => {
                    const content = el.getAttribute('content') || el.textContent || '';
                    if (content) emails.push(content);
                });

                const persons = document.querySelectorAll('[itemtype*="Person"], [itemtype*="Organization"]');
                persons.forEach(person => {
                    const emailProp = person.querySelector('[itemprop="email"]');
                    if (emailProp) {
                        const content = emailProp.getAttribute('content') || emailProp.textContent || '';
                        if (content) emails.push(content);
                    }
                });

                return emails;
            }''')

            if microdata_emails:
                for email_data in microdata_emails:
                    extracted = self._extract_emails_from_text(email_data)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from microdata")

        except Exception as e:
            logger.debug(f"Failed to extract from microdata: {e}")

        return emails

    async def _extract_from_rdfa(self, page) -> List[str]:
        """从RDFa标记提取邮箱"""
        emails = []

        try:
            rdfa_emails = await page.evaluate('''() => {
                const emails = [];

                const emailProps = document.querySelectorAll(
                    '[property*="email"], [rel*="email"], [property*="contactPoint"]'
                );

                emailProps.forEach(el => {
                    const content = el.getAttribute('content') ||
                                  el.getAttribute('resource') ||
                                  el.textContent || '';
                    if (content) emails.push(content);
                });

                return emails;
            }''')

            if rdfa_emails:
                for email_data in rdfa_emails:
                    extracted = self._extract_emails_from_text(email_data)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from RDFa")

        except Exception as e:
            logger.debug(f"Failed to extract from RDFa: {e}")

        return emails
