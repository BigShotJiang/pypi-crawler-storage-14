#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按钮点击邮箱提取器

通过点击包含邮箱相关文本的按钮来显示和提取邮箱地址。
适用于将邮箱信息隐藏在按钮点击后的弹窗或展开区域中的网站。
"""

import logging
from typing import List, Dict

from .base import EmailExtractor

logger = logging.getLogger(__name__)


class ButtonClickExtractor(EmailExtractor):
    """
    按钮点击提取器

    策略:
    1. 查找包含邮箱相关文本的按钮(email, contact, correspondence等)
    2. 点击按钮触发邮箱显示
    3. 等待邮箱内容出现(弹窗、展开区域等)
    4. 从新出现的内容中提取邮箱地址

    适用场景:
    - Elsevier/ScienceDirect等学术网站
    - 需要点击"Show email"按钮的网站
    - 邮箱信息在模态框中显示的页面

    Example:
        >>> extractor = ButtonClickExtractor()
        >>> emails = await extractor.extract(page, {
        ...     'email_button': 'button.email-btn',
        ...     'email_content': '.email-address'
        ... })
    """

    async def extract(self, page, selector_config: Dict) -> List[str]:
        """
        通过点击按钮提取邮箱

        Args:
            page: Playwright Page对象
            selector_config: 选择器配置,需要包含:
                - email_button: 邮箱按钮选择器
                - email_content: 邮箱内容选择器(可选)
                - close_modal: 关闭按钮选择器(可选)

        Returns:
            提取到的邮箱列表
        """
        emails = []

        button_selector = selector_config.get(
            'email_button',
            'button[class*="email"], button[aria-label*="email"], a[href^="mailto:"]'
        )

        content_selector = selector_config.get(
            'email_content',
            '.e-address, [class*="email"], [data-email]'
        )

        close_selector = selector_config.get(
            'close_modal',
            'button.close, button[aria-label="Close"], .modal-close'
        )

        try:
            buttons = await self._find_email_buttons(page, button_selector)

            if not buttons:
                logger.debug(f"No email buttons found with selector: {button_selector}")
                return []

            logger.info(f"📧 Found {len(buttons)} email buttons")

            for idx, button in enumerate(buttons, 1):
                try:
                    button_emails = await self._extract_from_button(
                        page=page,
                        button=button,
                        button_index=idx,
                        content_selector=content_selector,
                        close_selector=close_selector
                    )

                    if button_emails:
                        emails.extend(button_emails)
                        logger.debug(f"Button {idx}: extracted {len(button_emails)} emails")

                except Exception as e:
                    logger.debug(f"Failed to extract from button {idx}: {e}")
                    await self._safe_close_modal(page, close_selector)
                    continue

            emails = self._validate_emails(emails)

        except Exception as e:
            logger.warning(f"Button click extraction failed: {e}")
            return []

        return emails

    async def _find_email_buttons(self, page, selector: str) -> List:
        """查找邮箱相关按钮"""
        try:
            await page.wait_for_selector(selector, timeout=5000, state='attached')
            buttons = await page.query_selector_all(selector)

            visible_buttons = []
            for button in buttons:
                try:
                    if await button.is_visible():
                        visible_buttons.append(button)
                except Exception:
                    continue

            return visible_buttons

        except Exception as e:
            logger.debug(f"Failed to find email buttons: {e}")
            return []

    async def _extract_from_button(
        self,
        page,
        button,
        button_index: int,
        content_selector: str,
        close_selector: str
    ) -> List[str]:
        """从单个按钮点击提取邮箱"""
        emails = []

        try:
            await button.scroll_into_view_if_needed()
            await page.wait_for_timeout(300)

            is_enabled = await button.is_enabled()
            if not is_enabled:
                logger.debug(f"Button {button_index} is disabled")
                return []

            await button.click()
            logger.debug(f"✓ Clicked button {button_index}")

            await page.wait_for_timeout(1000)

            emails.extend(await self._extract_from_selector(page, content_selector))

            modal_selectors = ['.modal', '.popup', '[role="dialog"]', '.overlay', '[class*="modal"]']

            for modal_sel in modal_selectors:
                modal_emails = await self._extract_from_selector(page, f'{modal_sel} {content_selector}')
                emails.extend(modal_emails)

            if not emails:
                page_text = await page.evaluate('''() => {
                    const elements = document.querySelectorAll('[class*="email"], [data-email]');
                    return Array.from(elements).map(el => el.textContent || el.getAttribute('data-email') || '').join(' ');
                }''')

                if page_text:
                    emails.extend(self._extract_emails_from_text(page_text))

            await self._safe_close_modal(page, close_selector)
            await page.wait_for_timeout(300)

        except Exception as e:
            logger.debug(f"Error in _extract_from_button: {e}")

        return emails

    async def _extract_from_selector(self, page, selector: str) -> List[str]:
        """从指定选择器提取邮箱"""
        emails = []

        try:
            elements = await page.query_selector_all(selector)

            for elem in elements:
                try:
                    if not await elem.is_visible():
                        continue

                    text = await elem.inner_text()
                    if text:
                        emails.extend(self._extract_emails_from_text(text))

                    for attr in ['href', 'data-email', 'data-author-email', 'value']:
                        attr_value = await elem.get_attribute(attr)
                        if attr_value:
                            attr_value = attr_value.replace('mailto:', '')
                            emails.extend(self._extract_emails_from_text(attr_value))

                except Exception:
                    continue

        except Exception as e:
            logger.debug(f"Failed to extract from selector '{selector}': {e}")

        return emails

    async def _safe_close_modal(self, page, close_selector: str) -> bool:
        """安全关闭模态框"""
        try:
            close_btn = await page.query_selector(close_selector)
            if close_btn and await close_btn.is_visible():
                await close_btn.click()
                await page.wait_for_timeout(200)
                logger.debug("✓ Modal closed by button")
                return True

            await page.keyboard.press('Escape')
            await page.wait_for_timeout(200)
            logger.debug("✓ Modal closed by ESC")
            return True

        except Exception as e:
            logger.debug(f"Failed to close modal: {e}")
            return False
