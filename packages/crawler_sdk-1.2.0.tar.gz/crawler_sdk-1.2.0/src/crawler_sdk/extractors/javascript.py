#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JavaScript邮箱提取器

通过执行JavaScript代码来提取隐藏或混淆的邮箱地址。
适用于使用JavaScript动态生成或反爬虫混淆的邮箱。
"""

import logging
from typing import List, Dict

from .base import EmailExtractor

logger = logging.getLogger(__name__)


class JavaScriptExtractor(EmailExtractor):
    """
    JavaScript提取器

    策略:
    1. 执行JavaScript解码混淆的邮箱
    2. 查询window对象中的邮箱数据
    3. 检查全局变量和配置对象
    4. 触发页面JavaScript事件来显示邮箱
    5. 解析Base64或其他编码的邮箱

    适用场景:
    - 使用JavaScript混淆邮箱的网站
    - 邮箱存储在JavaScript变量中的页面
    - 需要执行特定JavaScript才能获取邮箱的网站

    Example:
        >>> extractor = JavaScriptExtractor()
        >>> emails = await extractor.extract(page, {})
    """

    async def extract(self, page, selector_config: Dict) -> List[str]:
        """
        通过JavaScript提取邮箱

        Args:
            page: Playwright Page对象
            selector_config: 选择器配置

        Returns:
            提取到的邮箱列表
        """
        emails = []

        try:
            logger.debug("Extracting from window object")
            emails.extend(await self._extract_from_window_object(page))

            logger.debug("Decoding Base64 emails")
            emails.extend(await self._decode_base64_emails(page))

            logger.debug("Executing deobfuscation functions")
            emails.extend(await self._execute_deobfuscation(page))

            logger.debug("Extracting from JS variables")
            emails.extend(await self._extract_from_js_variables(page))

            logger.debug("Triggering page events")
            emails.extend(await self._trigger_email_reveal_events(page))

            emails = self._validate_emails(emails)

            if emails:
                logger.info(f"✅ JavaScript extraction found {len(emails)} emails")

        except Exception as e:
            logger.warning(f"JavaScript extraction failed: {e}")
            return []

        return emails

    async def _extract_from_window_object(self, page) -> List[str]:
        """从window对象提取邮箱"""
        emails = []

        try:
            window_emails = await page.evaluate('''() => {
                const emails = [];

                function searchObject(obj, depth = 0, maxDepth = 3) {
                    if (depth > maxDepth) return;
                    if (!obj || typeof obj !== 'object') return;

                    for (const key in obj) {
                        try {
                            const value = obj[key];
                            if (typeof key === 'string' &&
                                (key.toLowerCase().includes('email') ||
                                 key.toLowerCase().includes('contact') ||
                                 key.toLowerCase().includes('author'))) {

                                if (typeof value === 'string' && value.includes('@')) {
                                    emails.push(value);
                                } else if (Array.isArray(value)) {
                                    value.forEach(v => {
                                        if (typeof v === 'string' && v.includes('@')) {
                                            emails.push(v);
                                        }
                                    });
                                }
                            }

                            if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                                searchObject(value, depth + 1, maxDepth);
                            }
                        } catch (e) {}
                    }
                }

                searchObject(window);

                const commonVars = ['authorData', 'articleData', 'contactInfo', 'pageData', 'config'];
                commonVars.forEach(varName => {
                    if (window[varName]) {
                        searchObject(window[varName]);
                    }
                });

                return [...new Set(emails)];
            }''')

            if window_emails:
                for email in window_emails:
                    extracted = self._extract_emails_from_text(email)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from window object")

        except Exception as e:
            logger.debug(f"Failed to extract from window object: {e}")

        return emails

    async def _decode_base64_emails(self, page) -> List[str]:
        """解码Base64编码的邮箱"""
        emails = []

        try:
            decoded_emails = await page.evaluate('''() => {
                const emails = [];
                const base64Attrs = ['data-email-base64', 'data-encoded-email', 'data-b64'];

                base64Attrs.forEach(attr => {
                    const elements = document.querySelectorAll(`[${attr}]`);
                    elements.forEach(el => {
                        try {
                            const encoded = el.getAttribute(attr);
                            if (encoded) {
                                const decoded = atob(encoded);
                                if (decoded.includes('@')) {
                                    emails.push(decoded);
                                }
                            }
                        } catch (e) {}
                    });
                });

                return [...new Set(emails)];
            }''')

            if decoded_emails:
                for email in decoded_emails:
                    extracted = self._extract_emails_from_text(email)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from Base64 decoding")

        except Exception as e:
            logger.debug(f"Failed to decode Base64 emails: {e}")

        return emails

    async def _execute_deobfuscation(self, page) -> List[str]:
        """执行常见的邮箱解混淆函数"""
        emails = []

        try:
            deobfuscated_emails = await page.evaluate('''() => {
                const emails = [];

                document.querySelectorAll('[data-email-reversed]').forEach(el => {
                    const reversed = el.getAttribute('data-email-reversed');
                    if (reversed) {
                        const email = reversed.split('').reverse().join('');
                        emails.push(email);
                    }
                });

                function rot13(str) {
                    return str.replace(/[a-zA-Z]/g, c =>
                        String.fromCharCode((c <= 'Z' ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26)
                    );
                }

                document.querySelectorAll('[data-email-rot13]').forEach(el => {
                    const encoded = el.getAttribute('data-email-rot13');
                    if (encoded) {
                        const decoded = rot13(encoded);
                        emails.push(decoded);
                    }
                });

                const userParts = document.querySelectorAll('[data-user]');
                const domainParts = document.querySelectorAll('[data-domain]');

                if (userParts.length > 0 && domainParts.length > 0) {
                    for (let i = 0; i < Math.min(userParts.length, domainParts.length); i++) {
                        const user = userParts[i].getAttribute('data-user');
                        const domain = domainParts[i].getAttribute('data-domain');
                        if (user && domain) {
                            emails.push(`${user}@${domain}`);
                        }
                    }
                }

                return [...new Set(emails)];
            }''')

            if deobfuscated_emails:
                for email in deobfuscated_emails:
                    extracted = self._extract_emails_from_text(email)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from deobfuscation")

        except Exception as e:
            logger.debug(f"Failed to execute deobfuscation: {e}")

        return emails

    async def _extract_from_js_variables(self, page) -> List[str]:
        """从JavaScript变量和配置对象提取邮箱"""
        emails = []

        try:
            var_emails = await page.evaluate('''() => {
                const emails = [];
                const scripts = document.querySelectorAll('script:not([src])');

                scripts.forEach(script => {
                    const content = script.textContent || '';
                    const patterns = [
                        /(?:var|let|const)\\s+\\w*email\\w*\\s*=\\s*["']([^"']+@[^"']+)["']/gi,
                        /(?:email|contact)\\s*:\\s*["']([^"']+@[^"']+)["']/gi,
                        /["']email["']\\s*:\\s*["']([^"']+@[^"']+)["']/gi
                    ];

                    patterns.forEach(pattern => {
                        let match;
                        while ((match = pattern.exec(content)) !== null) {
                            if (match[1]) {
                                emails.push(match[1]);
                            }
                        }
                    });
                });

                return [...new Set(emails)];
            }''')

            if var_emails:
                for email in var_emails:
                    extracted = self._extract_emails_from_text(email)
                    emails.extend(extracted)

                logger.debug(f"Found {len(emails)} emails from JS variables")

        except Exception as e:
            logger.debug(f"Failed to extract from JS variables: {e}")

        return emails

    async def _trigger_email_reveal_events(self, page) -> List[str]:
        """触发页面事件来显示邮箱"""
        emails = []

        try:
            before_text = await page.evaluate('() => document.body.innerText')

            await page.evaluate('''() => {
                const emailElements = document.querySelectorAll(
                    '[class*="email"], [id*="email"], [data-email]'
                );

                emailElements.forEach(el => {
                    ['mouseenter', 'mouseover', 'click', 'focus'].forEach(eventType => {
                        try {
                            const event = new Event(eventType, { bubbles: true });
                            el.dispatchEvent(event);
                        } catch (e) {}
                    });
                });
            }''')

            await page.wait_for_timeout(1000)

            after_text = await page.evaluate('() => document.body.innerText')

            if after_text != before_text:
                new_emails = self._extract_emails_from_text(after_text)
                before_emails = self._extract_emails_from_text(before_text)

                for email in new_emails:
                    if email not in before_emails:
                        emails.append(email)

                if emails:
                    logger.debug(f"Found {len(emails)} emails after triggering events")

        except Exception as e:
            logger.debug(f"Failed to trigger email reveal events: {e}")

        return emails
