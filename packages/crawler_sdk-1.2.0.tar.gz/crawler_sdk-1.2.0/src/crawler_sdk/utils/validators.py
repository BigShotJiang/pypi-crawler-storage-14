#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据验证函数集合

提供邮箱、URL、DOI等通用格式验证。
"""

import re


def validate_email(email: str) -> bool:
    """
    验证邮箱格式

    使用正则表达式验证邮箱是否符合基本格式要求。

    参数:
        email (str): 待验证的邮箱地址

    返回:
        bool: True 表示邮箱格式有效，False 表示无效

    例子:
        >>> validate_email("user@example.com")
        True
        >>> validate_email("invalid@")
        False
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_url(url: str) -> bool:
    """
    验证URL格式

    验证 URL 是否以正确的协议开头，并包含有效的域名。

    参数:
        url (str): 待验证的 URL

    返回:
        bool: True 表示 URL 格式有效，False 表示无效

    例子:
        >>> validate_url("https://www.example.com")
        True
        >>> validate_url("not a url")
        False
    """
    pattern = r'^https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(:[0-9]+)?(/.*)?(\?.*)?$'
    return bool(re.match(pattern, url))


def validate_doi(doi: str) -> bool:
    """
    验证 DOI (Digital Object Identifier) 格式

    验证 DOI 是否符合标准格式。

    参数:
        doi (str): 待验证的 DOI

    返回:
        bool: True 表示 DOI 格式有效，False 表示无效

    例子:
        >>> validate_doi("10.1016/j.example.2023.001")
        True
        >>> validate_doi("invalid-doi")
        False
    """
    pattern = r'^10\.\d+/[^/\s]+(/[^\s]*)?$'
    return bool(re.match(pattern, doi))


def validate_isbn(isbn: str) -> bool:
    """
    验证 ISBN (国际标准书号) 格式

    支持 ISBN-10 和 ISBN-13 两种格式。

    参数:
        isbn (str): 待验证的 ISBN（可包含连字符或空格）

    返回:
        bool: True 表示 ISBN 格式有效，False 表示无效

    例子:
        >>> validate_isbn("978-0-306-40615-2")
        True
        >>> validate_isbn("invalid-isbn")
        False
    """
    cleaned = isbn.replace('-', '').replace(' ', '')

    if len(cleaned) == 10:
        return bool(re.match(r'^\d{9}[\dX]$', cleaned))

    if len(cleaned) == 13:
        return bool(re.match(r'^\d{13}$', cleaned))

    return False


def validate_phone(phone: str, region: str = 'US') -> bool:
    """
    验证电话号码格式

    支持多个地区的电话号码格式验证。

    参数:
        phone (str): 待验证的电话号码
        region (str): 地区代码，支持 'US', 'CN', 'EU' 等，默认 'US'

    返回:
        bool: True 表示电话号码格式有效，False 表示无效

    例子:
        >>> validate_phone("(123) 456-7890", "US")
        True
        >>> validate_phone("18612345678", "CN")
        True
    """
    cleaned = phone.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')

    if region == 'US':
        pattern = r'^\+?1?\d{10}$'
    elif region == 'CN':
        pattern = r'^(\+86|0)?1[3-9]\d{9}$'
    elif region == 'EU':
        pattern = r'^\+[1-9]\d{1,14}$'
    else:
        pattern = r'^(\+\d{1,3})?\d{7,15}$'

    return bool(re.match(pattern, cleaned))


def validate_ipv4(ip: str) -> bool:
    """
    验证 IPv4 地址格式

    参数:
        ip (str): 待验证的 IPv4 地址

    返回:
        bool: True 表示 IPv4 地址格式有效，False 表示无效

    例子:
        >>> validate_ipv4("192.168.1.1")
        True
        >>> validate_ipv4("256.1.1.1")
        False
    """
    pattern = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    return bool(re.match(pattern, ip))


def validate_uuid(uuid_str: str) -> bool:
    """
    验证 UUID 格式

    支持 UUID v1-v5 的标准格式和非标准格式（无连字符）。

    参数:
        uuid_str (str): 待验证的 UUID

    返回:
        bool: True 表示 UUID 格式有效，False 表示无效

    例子:
        >>> validate_uuid("550e8400-e29b-41d4-a716-446655440000")
        True
        >>> validate_uuid("invalid-uuid")
        False
    """
    pattern = r'^[a-f0-9]{8}-?[a-f0-9]{4}-?[a-f0-9]{4}-?[a-f0-9]{4}-?[a-f0-9]{12}$'
    return bool(re.match(pattern, uuid_str, re.IGNORECASE))
