#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Publisher name normalization utilities

Provides functions for normalizing and matching publisher names
for consistent strategy selection.
"""

import re
from typing import List, Optional


def normalize_publisher_name(publisher: str) -> str:
    """
    Normalize publisher name for consistent matching

    Transformations:
    - Convert to lowercase
    - Strip whitespace
    - Remove common suffixes: "Publishing", "Group", "Nature", "Inc.", "Ltd.", "B.V."
    - Remove punctuation

    Args:
        publisher: Raw publisher name from Scilit API

    Returns:
        Normalized publisher name

    Example:
        >>> normalize_publisher_name("Elsevier B.V.")
        'elsevier'
        >>> normalize_publisher_name("Springer Nature")
        'springer'
        >>> normalize_publisher_name("IEEE Inc.")
        'ieee'
    """
    if not publisher:
        return ""

    # Convert to lowercase
    normalized = publisher.lower().strip()

    # Remove common suffixes (order matters - specific before general)
    suffixes = [
        r'\s+publishing\s+group',
        r'\s+publishing\s+ltd',
        r'\s+publishing\s+inc',
        r'\s+publishing',
        r'\s+publishers?',
        r'\s+nature',
        r'\s+group',
        r'\s+inc\.?',
        r'\s+ltd\.?',
        r'\s+llc\.?',
        r'\s+b\.v\.?',
        r'\s+ag\.?',
        r'\s+gmbh\.?',
    ]

    for suffix in suffixes:
        normalized = re.sub(suffix, '', normalized, flags=re.IGNORECASE)

    # Remove punctuation and extra whitespace
    normalized = re.sub(r'[^\w\s]', '', normalized)
    normalized = re.sub(r'\s+', ' ', normalized).strip()

    return normalized


def matches_publisher(publisher: str, supported_publishers: List[str]) -> bool:
    """
    Check if a publisher name matches any in the supported list

    Uses fuzzy matching with normalization:
    - Exact match after normalization
    - Contains match (normalized publisher in normalized supported name)

    Args:
        publisher: Publisher name to check
        supported_publishers: List of supported publisher names

    Returns:
        True if match found, False otherwise

    Example:
        >>> matches_publisher("Elsevier B.V.", ["elsevier", "sciencedirect"])
        True
        >>> matches_publisher("Springer Nature", ["springer"])
        True
        >>> matches_publisher("Unknown Publisher", ["elsevier"])
        False
    """
    if not publisher or not supported_publishers:
        return False

    normalized_publisher = normalize_publisher_name(publisher)

    if not normalized_publisher:
        return False

    # Check each supported publisher name
    for supported in supported_publishers:
        normalized_supported = normalize_publisher_name(supported)

        if not normalized_supported:
            continue

        # Exact match
        if normalized_publisher == normalized_supported:
            return True

        # Contains match (handles cases like "elsevier" matching "elsevier science")
        if normalized_publisher in normalized_supported or normalized_supported in normalized_publisher:
            return True

    return False


def find_matching_publisher(publisher: str, supported_publishers: List[str]) -> Optional[str]:
    """
    Find the matching publisher from supported list

    Args:
        publisher: Publisher name to match
        supported_publishers: List of supported publisher names

    Returns:
        The matched publisher name from supported list, or None

    Example:
        >>> find_matching_publisher("Elsevier B.V.", ["elsevier", "springer"])
        'elsevier'
    """
    if not publisher or not supported_publishers:
        return None

    normalized_publisher = normalize_publisher_name(publisher)

    if not normalized_publisher:
        return None

    # Try exact match first
    for supported in supported_publishers:
        if normalize_publisher_name(supported) == normalized_publisher:
            return supported

    # Try contains match
    for supported in supported_publishers:
        normalized_supported = normalize_publisher_name(supported)
        if normalized_publisher in normalized_supported or normalized_supported in normalized_publisher:
            return supported

    return None
