#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
爬虫工具装饰器集合

提供自动重试、限速、超时等通用功能。
"""

import time
import logging
import functools
import random
import threading
from typing import Any, Callable, TypeVar

logger = logging.getLogger(__name__)

F = TypeVar('F', bound=Callable[..., Any])


def retry(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0) -> Callable[[F], F]:
    """
    自动重试装饰器 - 指数退避重试

    当函数抛出异常时，自动重试指定次数。每次重试前等待指定秒数，
    延迟时间按指数级增长（delay * backoff^n）。

    参数:
        max_attempts (int): 最大重试次数，默认3次
        delay (float): 首次重试延迟秒数，默认1.0秒
        backoff (float): 延迟倍增因子，默认2.0（每次翻倍）

    行为:
        - 捕获所有异常并记录日志
        - 每次重试前等待 delay * (backoff ** attempt) 秒
        - 最后一次失败则抛出异常
        - 记录重试次数和延迟信息

    例子:
        @retry(max_attempts=3, delay=1.0, backoff=2.0)
        def fetch_data(url):
            return requests.get(url, timeout=5).json()

        # 首次失败延迟1秒，第二次延迟2秒，第三次延迟4秒

    返回:
        Callable: 装饰后的函数
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception = None

            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e

                    if attempt < max_attempts:
                        wait_time = delay * (backoff ** (attempt - 1))
                        logger.warning(
                            f"Function '{func.__name__}' failed on attempt {attempt}/{max_attempts}. "
                            f"Retrying in {wait_time:.2f}s. Error: {type(e).__name__}: {str(e)}"
                        )
                        time.sleep(wait_time)
                    else:
                        logger.error(
                            f"Function '{func.__name__}' failed after {max_attempts} attempts. "
                            f"Final error: {type(e).__name__}: {str(e)}"
                        )

            raise last_exception

        return wrapper  # type: ignore

    return decorator


def rate_limit(min_delay: float = 1.0, max_delay: float = 2.0) -> Callable[[F], F]:
    """
    限速装饰器 - 在函数执行前等待随机延迟

    每次调用函数前，等待指定范围内的随机秒数。用于避免对服务器
    造成过大压力，模拟人工操作的节奏。

    参数:
        min_delay (float): 最小延迟秒数，默认1.0秒
        max_delay (float): 最大延迟秒数，默认2.0秒

    行为:
        - 每次调用前等待 random.uniform(min_delay, max_delay) 秒
        - 避免规律化的请求模式
        - 记录每次延迟时间

    例子:
        @rate_limit(min_delay=1.0, max_delay=3.0)
        def api_call(url):
            return requests.get(url)

        # 每次调用前等待1-3秒的随机延迟

    返回:
        Callable: 装饰后的函数
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            wait_time = random.uniform(min_delay, max_delay)
            logger.debug(f"Rate limit: sleeping {wait_time:.2f}s before {func.__name__}")
            time.sleep(wait_time)
            return func(*args, **kwargs)

        return wrapper  # type: ignore

    return decorator


def timeout(seconds: float = 30) -> Callable[[F], F]:
    """
    超时装饰器 - 设置函数执行的最大时间

    如果函数执行超过指定时间，抛出 TimeoutError。使用线程实现，
    支持同步函数。注意：此实现在超时时不能真正终止线程，而是
    抛出异常。

    参数:
        seconds (float): 超时秒数，默认30秒

    行为:
        - 如果函数超过指定时间未完成，抛出 TimeoutError
        - 记录超时信息
        - 对于长时间运行的函数，可能无法立即终止

    例子:
        @timeout(seconds=10)
        def slow_function():
            time.sleep(20)  # 会在10秒后超时

    返回:
        Callable: 装饰后的函数
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            result = [None]
            exception = [None]

            def target() -> None:
                try:
                    result[0] = func(*args, **kwargs)
                except Exception as e:
                    exception[0] = e

            thread = threading.Thread(target=target, daemon=True)
            thread.start()
            thread.join(timeout=seconds)

            if thread.is_alive():
                logger.error(f"Function '{func.__name__}' exceeded timeout of {seconds}s")
                raise TimeoutError(f"Function '{func.__name__}' exceeded timeout of {seconds}s")

            if exception[0] is not None:
                raise exception[0]

            return result[0]

        return wrapper  # type: ignore

    return decorator
