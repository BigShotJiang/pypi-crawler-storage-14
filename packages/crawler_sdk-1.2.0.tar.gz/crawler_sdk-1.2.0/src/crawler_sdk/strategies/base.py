#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
解析策略基类模块

提供 ParseStrategy 抽象基类和通用辅助方法。
所有出版商特定策略都应继承此基类。

Features:
- Browser-based extraction via Playwright
- API-based extraction via HTTP client with anti-detection
- Extractor chain pattern for email extraction
- Common utility methods for web scraping
"""

import re
import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Optional, TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import AuthorInfo
    from ..http import HTTPClient, FetchResponse

logger = logging.getLogger(__name__)

# Lazy import for HTTP client (optional dependency)
_http_client_instance = None


class ParseStrategy(ABC):
    """
    解析策略抽象基类

    定义通用接口和辅助方法，具体出版商策略需要继承并实现抽象方法。
    支持浏览器模式（Playwright）和 API 模式（HTTP 客户端）两种提取方式。

    Attributes:
        name: 策略名称，用于日志和调试
        extractor_chain: 邮箱提取器责任链
        http_client: HTTP 客户端实例（懒加载）

    Example - Browser mode:
        >>> class ElsevierStrategy(ParseStrategy):
        ...     async def extract_authors(self, page) -> List[AuthorInfo]:
        ...         # 实现 Elsevier 特定的提取逻辑
        ...         pass
        ...
        ...     def get_selectors(self) -> Dict:
        ...         return {'author': '.author-name', 'email': '.author-email'}

    Example - API mode:
        >>> class MyStrategy(ParseStrategy):
        ...     async def extract_authors_api(self, url: str) -> List[AuthorInfo]:
        ...         response = await self.fetch_page(url, domain="example.com")
        ...         if response.success:
        ...             # Parse response.text
        ...             pass
    """

    # Class-level HTTP client (shared across instances)
    _shared_http_client = None

    def __init__(self):
        """初始化策略"""
        self.name = self.__class__.__name__
        self.extractor_chain = self._build_extractor_chain()
        self._http_client = None  # Instance-level client (lazy loaded)

    def _build_extractor_chain(self):
        """
        构建邮箱提取器责任链

        默认返回 None，子类可以重写此方法来自定义提取器链。

        Returns:
            ExtractorChain: 配置好的提取器链，或 None

        Example:
            >>> def _build_extractor_chain(self):
            ...     from crawler_sdk.extractors import ExtractorChain, ButtonClickExtractor
            ...     chain = ExtractorChain()
            ...     chain.add(ButtonClickExtractor())
            ...     return chain
        """
        return None

    @abstractmethod
    async def extract_authors(self, page) -> List:
        """
        提取作者信息（子类必须实现）

        Args:
            page: Playwright Page 对象

        Returns:
            作者信息列表，每个元素为 AuthorInfo 对象

        Raises:
            NotImplementedError: 子类未实现此方法
        """
        pass

    @abstractmethod
    def get_selectors(self) -> Dict[str, str]:
        """
        获取 CSS 选择器配置（子类必须实现）

        Returns:
            选择器字典，包含该策略需要的所有 CSS 选择器

        Raises:
            NotImplementedError: 子类未实现此方法
        """
        pass

    async def _extract_emails_with_chain(self, page) -> List[str]:
        """
        使用提取器责任链提取邮箱

        优先使用提取器链进行邮箱提取，如果链不可用则回退到传统方法。

        Args:
            page: Playwright Page 对象

        Returns:
            邮箱地址列表

        Example:
            >>> emails = await self._extract_emails_with_chain(page)
        """
        if self.extractor_chain:
            try:
                selector_config = self.get_selectors()
                emails = await self.extractor_chain.execute(page, selector_config)
                if emails:
                    logger.info(f"✅ Extractor chain found {len(emails)} emails")
                    return emails
            except Exception as e:
                logger.warning(f"Extractor chain failed: {e}, falling back to traditional method")

        return []

    async def _extract_emails_from_element(
        self,
        page,
        selector: str,
        timeout: int = 5000
    ) -> List[str]:
        """
        通用邮箱提取逻辑

        从指定选择器的元素中提取邮箱地址，支持文本和属性提取。

        Args:
            page: Playwright Page 对象
            selector: CSS 选择器
            timeout: 等待超时时间（毫秒），默认5秒

        Returns:
            邮箱地址列表（已去重）

        Example:
            >>> emails = await self._extract_emails_from_element(
            ...     page,
            ...     '.author-email, [data-email]'
            ... )
        """
        emails = []
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

        try:
            await page.wait_for_selector(selector, timeout=timeout, state='attached')
            elements = await page.query_selector_all(selector)

            for elem in elements:
                try:
                    if not await elem.is_visible():
                        continue

                    text = await elem.inner_text()
                    if text:
                        found = re.findall(email_pattern, text)
                        emails.extend(found)

                    for attr in ['href', 'data-email', 'data-author-email', 'value']:
                        attr_value = await elem.get_attribute(attr)
                        if attr_value:
                            attr_value = attr_value.replace('mailto:', '')
                            found = re.findall(email_pattern, attr_value)
                            emails.extend(found)

                except Exception as e:
                    logger.debug(f"Failed to extract email from element: {e}")
                    continue

        except Exception as e:
            logger.debug(f"No elements found for selector '{selector}': {e}")

        emails = list(set(emails))
        emails = self._filter_emails(emails)

        logger.debug(f"Extracted {len(emails)} emails from '{selector}'")
        return emails

    async def _extract_affiliations(
        self,
        page,
        selector: str,
        min_length: int = 5
    ) -> List[str]:
        """
        通用机构信息提取逻辑

        Args:
            page: Playwright Page 对象
            selector: CSS 选择器
            min_length: 最小文本长度，默认5

        Returns:
            机构名称列表
        """
        affiliations = []

        try:
            await page.wait_for_selector(selector, timeout=5000, state='attached')
            elements = await page.query_selector_all(selector)

            for elem in elements:
                try:
                    if not await elem.is_visible():
                        continue

                    text = await elem.inner_text()
                    if text and len(text) >= min_length:
                        text = text.strip()
                        text = re.sub(r'\s+', ' ', text)
                        affiliations.append(text)

                except Exception as e:
                    logger.debug(f"Failed to extract affiliation: {e}")
                    continue

        except Exception as e:
            logger.debug(f"No affiliation elements found: {e}")

        logger.debug(f"Extracted {len(affiliations)} affiliations")
        return affiliations

    async def _close_modal(
        self,
        page,
        close_selector: Optional[str] = None,
        use_escape: bool = True
    ) -> bool:
        """
        关闭弹窗的通用方法

        Args:
            page: Playwright Page 对象
            close_selector: 关闭按钮的 CSS 选择器
            use_escape: 是否尝试 ESC 键

        Returns:
            是否成功关闭弹窗
        """
        closed = False

        if close_selector:
            try:
                close_btn = await page.query_selector(close_selector)
                if close_btn and await close_btn.is_visible():
                    await close_btn.click()
                    await page.wait_for_timeout(300)
                    closed = True
                    logger.debug("Modal closed by button click")
            except Exception as e:
                logger.debug(f"Failed to close modal by button: {e}")

        if not closed and use_escape:
            try:
                await page.keyboard.press('Escape')
                await page.wait_for_timeout(300)
                closed = True
                logger.debug("Modal closed by ESC key")
            except Exception as e:
                logger.debug(f"Failed to close modal by ESC: {e}")

        return closed

    def _filter_emails(self, emails: List[str]) -> List[str]:
        """
        过滤无效或测试邮箱

        Args:
            emails: 原始邮箱列表

        Returns:
            过滤后的邮箱列表
        """
        blacklist_domains = [
            'example.com',
            'example.org',
            'test.com',
            'localhost',
            'dummy.com',
            'sample.com',
            'noreply',
            'no-reply',
        ]

        filtered = []
        for email in emails:
            email_lower = email.lower()
            if not any(bad in email_lower for bad in blacklist_domains):
                filtered.append(email)

        return filtered

    # =========================================================================
    # HTTP Client Methods (API Mode)
    # =========================================================================

    @property
    def http_client(self) -> "HTTPClient":
        """
        获取 HTTP 客户端实例（懒加载）

        Returns:
            HTTPClient 实例

        Raises:
            ImportError: 如果 curl_cffi 未安装

        Example:
            >>> client = self.http_client
            >>> response = await client.fetch(url, domain="example.com")
        """
        if self._http_client is None:
            self._http_client = self._create_http_client()
        return self._http_client

    def _create_http_client(self) -> "HTTPClient":
        """
        创建 HTTP 客户端实例

        子类可以重写此方法来自定义 HTTP 客户端配置。

        Returns:
            HTTPClient 实例
        """
        try:
            from ..http import HTTPClient
            return HTTPClient()
        except ImportError as e:
            raise ImportError(
                "HTTP client requires curl_cffi. "
                "Install with: pip install crawler-sdk[http]"
            ) from e

    async def fetch_page(
        self,
        url: str,
        domain: str,
        timeout: Optional[int] = None,
        check_content: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        max_retries: Optional[int] = None
    ) -> "FetchResponse":
        """
        使用 HTTP 客户端获取页面（带反检测）

        Args:
            url: 要获取的 URL
            domain: 目标域名（用于指纹选择）
            timeout: 请求超时时间（秒）
            check_content: 响应中必须包含的字符串
            headers: 额外的请求头
            max_retries: 最大重试次数

        Returns:
            FetchResponse 响应对象

        Example:
            >>> response = await self.fetch_page(
            ...     url="https://www.sciencedirect.com/...",
            ...     domain="sciencedirect.com",
            ...     check_content="__PRELOADED_STATE__"
            ... )
            >>> if response.success:
            ...     html = response.text
        """
        return await self.http_client.fetch(
            url=url,
            domain=domain,
            timeout=timeout,
            check_content=check_content,
            headers=headers,
            max_retries=max_retries
        )

    async def resolve_doi(
        self,
        doi_url: str,
        timeout: Optional[int] = None,
        max_redirects: int = 5
    ) -> Optional[str]:
        """
        解析 DOI URL 到最终目标 URL

        跟踪 doi.org 的重定向到实际出版商页面。

        Args:
            doi_url: DOI URL (如 "https://doi.org/10.1016/...")
            timeout: 请求超时时间（秒）
            max_redirects: 最大重定向次数

        Returns:
            解析后的 URL，如果解析失败返回 None

        Example:
            >>> real_url = await self.resolve_doi("https://doi.org/10.1016/j.example.2025.123")
            >>> print(real_url)  # https://www.sciencedirect.com/science/article/pii/...
        """
        return await self.http_client.resolve_doi(
            doi_url=doi_url,
            timeout=timeout,
            max_redirects=max_redirects
        )

    def reset_http_client(self, domain: Optional[str] = None):
        """
        重置 HTTP 客户端的指纹封禁状态

        Args:
            domain: 要重置的特定域名，或 None 重置所有

        Example:
            >>> self.reset_http_client("sciencedirect.com")  # 重置特定域名
            >>> self.reset_http_client()  # 重置所有
        """
        if self._http_client:
            self._http_client.reset_fingerprints(domain)

    def __repr__(self) -> str:
        """字符串表示"""
        return f"<{self.name}>"
