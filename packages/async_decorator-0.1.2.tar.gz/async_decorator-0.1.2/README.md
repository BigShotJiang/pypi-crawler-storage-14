# Async Decorator

一个灵活的 Python 库，用于通过专用线程池管理异步/同步函数执行。

## 使用场景

- 确保主进程不被阻塞
- 为特定函数提供并发能力
- 同时，保障某些无法使用并发的功能
- 对非并发功能使用 EXCLUSIVE 类型进行隔离
- 使用 SHARED_POOL 类型保证其他功能的并发需求
- 多功能共用一个线程，确保数据串行处理。例如：Transformer 大模型推理上的使用

## 功能特点

- **专用线程池**：隔离同步函数执行
- **共享线程池**：在线程中高效执行异步函数
- **灵活的ExecType**：EXCLUSIVE、SHARED_POOL
- **线程安全**：管理线程池生命周期
- **易于集成**：基于装饰器的简单 API

## 安装

```bash
pip install async-decorator
```

## 快速开始

```python
import asyncio
import aiohttp
from async_decorator import async_decorator, ExecType

@async_decorator(ExecType.EXCLUSIVE)
def process_data(data):
    # CPU 密集型同步工作
    return len(data)

@async_decorator(ExecType.SHARED_POOL)
async def fetch_data(url):
    # I/O 密集型异步工作
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

async def main():
    # 这些函数在适当的线程池中运行
    result1 = process_data("hello world")
    result2 = await fetch_data("https://example.com")
    
    print(f"处理结果: {result1}, 获取数据: {len(result2)} 字节")

asyncio.run(main())
```

## 执行类型

- `EXCLUSIVE`：在专用线程池中运行同步函数
- `SHARED_POOL`：在共享线程池中运行异步函数

## 高级用法

### 示例 1

```python
from async_decorator import ExecType, async_decorator

# 自定义共享异步池的最大工作线程数
shared_pool_size = 200

@async_decorator(ExecType.SHARED_POOL, shared_pool_size=shared_pool_size)
def custom_processing():
    return "已处理"

```

### 示例 2

```python
from async_decorator import DedicatedThreadManager, ExecType, async_decorator

# 自定义线程管理器，但 shared_pool_size 将失效
manager = DedicatedThreadManager(
    shared_pool_size=20,
    max_dedicated_pools=50
)

@async_decorator(ExecType.EXCLUSIVE, "my_exclusive", thread_manager=manager)
def custom_processing():
    return "已处理"

# 清理
manager.shutdown()
```