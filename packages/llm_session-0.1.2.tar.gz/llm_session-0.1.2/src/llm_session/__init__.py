from .automator import Automator

__all__ = ["Automator"]
