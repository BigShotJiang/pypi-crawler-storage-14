"""Configuration settings for SNPraefentia."""

# UniProt search parameters
DEFAULT_UNIPROT_TOLERANCE = 50
