"""SSB POC Statlog Model."""
