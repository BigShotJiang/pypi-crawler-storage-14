"""
General utility functions
"""

__all__ = []