"""
Web scraping and HTTP utilities
"""

__all__ = []