#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.systemcoupling.core.adaptor.impl.types import *


class get_machines(Command):
    """
    Get currently available machines.
    """

    syc_name = "GetMachines"
