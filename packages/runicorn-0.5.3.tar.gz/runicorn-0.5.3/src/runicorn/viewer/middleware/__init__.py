"""
Middleware for the viewer application.
"""
