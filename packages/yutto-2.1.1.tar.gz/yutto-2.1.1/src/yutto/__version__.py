# 发版需要同时改这里和 pyproject.toml
from __future__ import annotations

VERSION = "2.1.1"
