#!/usr/bin/env bash
conda activate napari
napari
