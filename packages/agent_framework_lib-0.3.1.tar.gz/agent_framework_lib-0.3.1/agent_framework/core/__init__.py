"""Core components of the agent framework."""
