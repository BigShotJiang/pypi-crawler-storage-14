"""Main entry point for the ShotGrid MCP server."""

# Import local modules
from shotgrid_mcp_server.server import main

if __name__ == "__main__":
    main()
