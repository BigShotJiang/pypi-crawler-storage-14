import json
import pdfkit
from jinja2 import Environment, FileSystemLoader

# --- 1. Define the HTML Template (Policy Layout) ---
# In a real application, this would be in a separate file (e.g., 'policy_template.html')
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Mobishield Policy Document</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; }
        h1 { color: #007bff; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
        .policy-section { margin-bottom: 20px; padding: 15px; border: 1px solid #eee; border-radius: 5px; }
        .data-row { display: flex; justify-content: space-between; margin-bottom: 5px; }
        .label { font-weight: bold; width: 40%; }
        .value { width: 60%; text-align: right; }
    </style>
</head>
<body>
    <h1>Mobishield Policy Confirmation</h1>

    <div class="policy-section">
        <h2>Customer Information</h2>
        <div class="data-row"><span class="label">Policy Holder:</span><span class="value">{{ customer_name }}</span></div>
        <div class="data-row"><span class="label">Email:</span><span class="value">{{ email }}</span></div>
        <div class="data-row"><span class="label">Policy ID:</span><span class="value">{{ policy_id }}</span></div>
    </div>

    <div class="policy-section">
        <h2>Device & Coverage</h2>
        <div class="data-row"><span class="label">Device:</span><span class="value">{{ device_make }} {{ device_model }}</span></div>
        <div class="data-row"><span class="label">IMEI:</span><span class="value">{{ imei }}</span></div>
        <div class="data-row"><span class="label">Coverage Type:</span><span class="value">{{ coverage_type }}</span></div>
        <div class="data-row"><span class="label">Premium:</span><span class="value">${{ premium_amount }}</span></div>
    </div>
</body>
</html>
"""

def generate_policy_pdf_from_json(json_data: str, output_filename: str = 'policy_document.pdf'):
    """
    Parses JSON data, renders it into an HTML template, and converts the HTML to PDF.

    Args:
        json_data (str): A JSON string containing policy details.
        output_filename (str): The name of the output PDF file.
    """
    try:
        # 1. Parse JSON Input
        policy_data = json.loads(json_data)
        
        # 2. Setup Jinja2 Environment and Load Template
        # In this example, we load the template directly from the string
        env = Environment(loader=FileSystemLoader('.')) # Dummy loader path
        template = Environment(loader=FileSystemLoader(".")).from_string(HTML_TEMPLATE)

        # 3. Render Template with JSON Data
        # We pass the dictionary unpacked as keyword arguments to the render method
        html_output = template.render(**policy_data)
        
        # 4. Convert HTML to PDF using pdfkit (requires wkhtmltopdf)
        pdfkit.from_string(html_output, output_filename)
        
        print(f"✅ Success: Policy PDF generated at '{output_filename}'")
        
    except json.JSONDecodeError:
        print("❌ Error: Invalid JSON input provided.")
    except IOError as e:
        # This usually catches errors if wkhtmltopdf is not installed or not in PATH
        print(f"❌ Error: Could not generate PDF. Is 'wkhtmltopdf' installed and in your system PATH? Details: {e}")
    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")
