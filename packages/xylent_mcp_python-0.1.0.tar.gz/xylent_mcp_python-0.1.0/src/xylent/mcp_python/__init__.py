"""Production-ready MCP (Model Context Protocol) client for Xylent services.

This package provides a robust client implementation for interacting with MCP servers,
with features including:
- Lazy connection establishment
- Automatic retry with exponential backoff
- Pluggable authentication strategies
- Singleton registry for connection pooling
- Type-safe with full typing support
"""

from typing import Any

from .auth import AuthStrategy, BasicHTTPAuth, NoAuth
from .client import MCPClient
from .client_utils import get_auth_strategy, parse_mcp_servers
from .config import MCPClientConfig
from .errors import MCPConnectionError, MCPError, MCPTimeout
from .registry import MCPClientRegistry


# Dynamic version reading - single source of truth in pyproject.toml
def _read_version() -> str:
    """Best-effort version reader supporting editable installs."""
    try:
        from importlib.metadata import PackageNotFoundError, version
    except ImportError:  # pragma: no cover - very old Python
        return "unknown"

    try:
        return version("xylent-mcp-python")
    except PackageNotFoundError:
        pass

    try:
        import tomllib
        from pathlib import Path

        pyproject = Path(__file__).parent.parent.parent.parent / "pyproject.toml"
        if not pyproject.exists():
            return "unknown"

        with open(pyproject, "rb") as f:
            data = tomllib.load(f)

        for section in ("project", "tool", "tool.poetry"):  # tool entry handled below
            if section == "tool":
                tool = data.get("tool") or {}
                poetry = tool.get("poetry") if isinstance(tool, dict) else None
                if poetry and "version" in poetry:
                    return str(poetry["version"])
                continue
            section_data = data.get(section)
            if section_data and "version" in section_data:
                return str(section_data["version"])
    except Exception:
        return "unknown"

    return "unknown"


__version__ = _read_version()

# Lazy import server helpers so client-only consumers do not need FastAPI installed
try:
    from .serverkit import attach_mcp
except ImportError:  # pragma: no cover - exercised only when server extras missing

        def attach_mcp(*args: Any, **kwargs: Any) -> Any:  # type: ignore[misc]
            raise ImportError(
                "attach_mcp requires server dependencies. Install with the 'server' extra: pip install 'xylent-mcp-python[server]' or poetry add 'xylent-mcp-python[server]'."
            ) from None


__all__ = [
    # Core classes
    "MCPClient",
    "MCPClientRegistry",
    "MCPClientConfig",
    # Server adapter
    "attach_mcp",
    # Auth
    "AuthStrategy",
    "NoAuth",
    "BasicHTTPAuth",
    # Client utilities
    "parse_mcp_servers",
    "get_auth_strategy",
    # Errors
    "MCPError",
    "MCPConnectionError",
    "MCPTimeout",
    # Version
    "__version__",
]
