# xylent-mcp-python

Production-ready MCP (Model Context Protocol) implementation for Xylent services, including client wrapper and FastAPI server integration.

## Features

### Client Features

- 🚀 Lazy connection establishment - connects only when needed
- 🔄 Automatic retry with exponential backoff for transient failures
- 🔐 Pluggable authentication strategies (Basic, Token, Custom)
- 📦 Singleton registry with per-URL connection pooling
- 🛡️ Type-safe with full typing support
- ⚡ Async/await native implementation with concurrent optimization
- 🎯 Comprehensive error taxonomy for better error handling

### Server Features (v0.1.0+)

- 🌐 FastAPI integration via `attach_mcp()` for serving MCP tools
- 🔒 Production-ready `BasicAuth` for MCP server authentication
- 🤝 Seamless client-server authentication alignment
- 🛡️ CORS support and exception handling
- 📊 Path allowlisting for health checks and metrics

## Requirements

- Python 3.11+ (Python 3.13 recommended)

## Installation

> **Note**: If upgrading from versions with beta/RC tags, simply switch to the corresponding stable version (e.g., `v0.3.0-rc.1` → `v0.3.0`).
> Base package installs the client only. Install with the `[server]` extra to pull FastAPI/Starlette/Uvicorn.

### Using Poetry

```bash
# Client only (recommended for production)
poetry add "xylent-mcp-python @ git+ssh://git@bitbucket.org/xylent/mcp-python.git@v0.1.0"

# Client and server with FastAPI integration
poetry add "xylent-mcp-python[server] @ git+ssh://git@bitbucket.org/xylent/mcp-python.git@v0.1.0"

# Or install directly
poetry add "xylent-mcp-python @ git+ssh://git@bitbucket.org/xylent/mcp-python.git@v0.1.0"
```

### In pyproject.toml

```toml
[project.dependencies]
# Client only
xylent-mcp-python = { git = "ssh://git@bitbucket.org/xylent/mcp-python.git", tag = "v0.1.0" }

# Or with server support
# xylent-mcp-python = { git = "ssh://git@bitbucket.org/xylent/mcp-python.git", tag = "v0.1.0", extras = ["server"] }
```

## Version Management

This library follows **semantic versioning** with a simple release process:

- Each merge to `main` with a version bump creates a new release tag
- Consumers control when and which version to adopt
- Newer versions = latest features but less battle-tested
- Older versions = more stable and widely tested

### Installing Specific Versions

```bash
# Install a specific version (recommended)
poetry add "xylent-mcp-python @ git+ssh://git@bitbucket.org/xylent/mcp-python.git@v0.1.0"

# Or specify in pyproject.toml
[tool.uv.sources]
xylent-mcp-python = { git = "ssh://git@bitbucket.org/xylent/mcp-python.git", tag = "v0.1.0" }
```

### Version Selection Strategy

- **Conservative**: Use versions that have been out for a while (e.g., `v0.5.0`)
- **Balanced**: Use recent stable versions (e.g., `v0.6.0`)
- **Early Adopter**: Use the latest version (e.g., `v0.1.0`)

Consumers manage their own risk by choosing when to upgrade. See [Consumer Guide](docs/CONSUMER_GUIDE.md) for integration details.

## Quick Start

### Client Usage

```python
import asyncio
from xylent.mcp_python import MCPClientRegistry, MCPClientConfig, BasicHTTPAuth

async def main():
    # Option 1: Direct auth creation (recommended)
    auth = BasicHTTPAuth("username", "password")
    client = await MCPClientRegistry.get(
        "https://mcp-server.example.com",
        auth=auth
    )

    # Option 2: Using config object
    config = MCPClientConfig(
        server_url="https://mcp-server.example.com",
        auth_type="basic",
        basic_username="username",
        basic_password="password"
    )
    client = await MCPClientRegistry.get(
        "https://mcp-server.example.com",
        config
    )

    # List available tools
    tools = await client.list_tools()
    print(f"Available tools: {[tool.name for tool in tools]}")

    # Call a tool
    result = await client.call_tool(
        "search",
        {"query": "example"}
    )

    # Call a tool with metadata (not visible to LLM, but accessible to server)
    result = await client.call_tool(
        "search",
        {"query": "example"},
        meta={"user_id": "user123", "session_id": "abc-456"}
    )

    if result.isError:
        print(f"Error: {result.error}")
    else:
        print(f"Result: {result.content}")

    # Cleanup all clients
    await MCPClientRegistry.aclose_all()

if __name__ == "__main__":
    asyncio.run(main())
```

### Server Usage (v0.1.0+)

```python
# Requires installing with the [server] extra
from contextlib import asynccontextmanager
from fastapi import FastAPI
from mcp import Tool
from xylent.mcp_python.serverkit import attach_mcp, BasicAuth, NoAuth

# Create FastAPI app
app = FastAPI()

@asynccontextmanager
async def app_context():
    # Initialize your resources here (db connections, clients, etc.)
    yield {"ready": True}

# Define your MCP tools
@Tool
async def search(query: str) -> str:
    """Search for information"""
    return f"Results for: {query}"

# Default: Uses BasicAuth with BASIC_USERNAME/BASIC_PASSWORD from environment
handle = attach_mcp(
    app,
    name="my-mcp-service",
    tools=[search],
    app_context=app_context,
    path="/mcp",
    cors=True,
)

# Development: Explicit NoAuth
# handle = attach_mcp(app, ..., auth=NoAuth())

# Custom auth: Override with specific credentials
# custom_auth = BasicAuth(username="custom", password="secret")
# handle = attach_mcp(app, ..., auth=custom_auth)

# Regular FastAPI endpoints work alongside MCP
@app.get("/health")
async def health():
    return {"status": "ok"}
```

## Authentication

### Basic HTTP Authentication

#### Direct Credentials (Recommended)

```python
from xylent.mcp_python import MCPClientRegistry, BasicHTTPAuth

auth = BasicHTTPAuth("username", "password")
client = await MCPClientRegistry.get(url, auth=auth)
```

#### Using get_auth_strategy Helper

```python
from xylent.mcp_python import MCPClientRegistry, get_auth_strategy, MCPClientConfig

# Create config with auth credentials
config = MCPClientConfig(
    server_url=url,
    auth_type="basic",
    basic_username="username",
    basic_password="password"
)
auth = get_auth_strategy(config)
client = await MCPClientRegistry.get(url, auth=auth)
```

### No Authentication

```python
from xylent.mcp_python import MCPClientRegistry, NoAuth

# Explicitly indicate no authentication is needed
auth = NoAuth()
client = await MCPClientRegistry.get(url, auth=auth)
```

### Custom Authentication

```python
from xylent.mcp_python import MCPClientRegistry, AuthStrategy

class CustomAuth(AuthStrategy):
    def get_auth_headers(self) -> dict[str, str] | None:
        return {"X-Custom-Auth": "secret"}

auth = CustomAuth()
client = await MCPClientRegistry.get(url, auth=auth)
```

### No Authentication

```python
from xylent.mcp_python import MCPClientRegistry, NoAuth

auth = NoAuth()
client = await MCPClientRegistry.get(url, auth=auth)

# Or simply omit auth parameter
client = await MCPClientRegistry.get(url)
```

## Error Handling

The library provides a streamlined error hierarchy for robust error handling:

```python
from xylent.mcp_python import MCPError, MCPConnectionError, MCPTimeout

try:
    result = await client.call_tool("some_tool", {})
except MCPTimeout as e:
    # Handle timeout specifically
    print(f"Operation timed out: {e}")
except MCPConnectionError as e:
    # Handle connection issues
    print(f"Connection failed: {e}")
except MCPError as e:
    # Catch any other MCP-related errors
    print(f"MCP error: {e}")
```

## Configuration

### Basic Configuration

```python
from xylent.mcp_python import MCPClientConfig
from datetime import timedelta

config = MCPClientConfig(
    server_url="https://mcp-server.example.com",
    connect_timeout_s=timedelta(seconds=30),
    call_timeout=timedelta(seconds=60),
    max_attempts=5,
    retry_min_wait_s=1.0,
    retry_max_wait_s=10.0
)

client = await MCPClientRegistry.get(url, config=config, auth=auth)
```

### Environment Variables

The configuration can also be set via environment variables:

```bash
export MCP_SERVER_URL="https://mcp-server.example.com"
export MCP_CONNECT_TIMEOUT_S=30
export MCP_CALL_TIMEOUT=60
export MCP_MAX_ATTEMPTS=5
```

## Advanced Usage

### Client Registry Management

```python
# Get or create a client (singleton per URL)
client = await MCPClientRegistry.get(url, auth=auth)

# Remove a specific client
await MCPClientRegistry.remove_client(url)

# Close all managed clients
await MCPClientRegistry.aclose_all()
```

### Using Meta Parameters

The `call_tool` method supports an optional `meta` parameter for passing metadata to the MCP server. This metadata is **not visible to the LLM** but can be accessed by the server for logging, authentication context, or other server-side processing:

```python
# Pass metadata with tool calls
result = await client.call_tool(
    "database_query",
    {"sql": "SELECT * FROM users"},
    meta={
        "user_id": "user-123",
        "organization_id": "org-456",
        "session_id": "sess-789",
        "request_id": "req-abc",
        "feature_flags": {"new_ui": True}
    }
)
```

Common use cases for meta parameters:

- User/session identification for audit logging
- Organization context for multi-tenant systems
- Request tracing and debugging
- Feature flags and A/B testing
- Rate limiting context

### Direct Client Usage (without Registry)

```python
from xylent.mcp_python import MCPClient, MCPClientConfig, BasicHTTPAuth
from xylent.mcp_python.retry import MCPRetryHandler

config = MCPClientConfig(server_url=url)
retry_handler = MCPRetryHandler(config)
auth = BasicHTTPAuth("user", "pass")

client = MCPClient(config, retry_handler, auth)
async with client:
    tools = await client.list_tools()
    result = await client.call_tool("tool_name", {"arg": "value"})
    # With meta parameters
    result = await client.call_tool(
        "tool_name",
        {"arg": "value"},
        meta={"context": "production"}
    )
```

## Migration from bot-agent

If you're migrating from the embedded version in bot-agent:

### Old Usage (bot-agent)

```python
from bot_agent.core.services.mcp_service import MCPClientRegistry
# Auth was hardcoded from global config
client = await MCPClientRegistry.get(url)
```

### New Usage (xylent-mcp-python v0.5.0+)

```python
from xylent.mcp_python import MCPClientRegistry, BasicHTTPAuth

# Option 1: Explicit credentials (recommended)
auth = BasicHTTPAuth("username", "password")
client = await MCPClientRegistry.get(url, auth=auth)

# Option 2: From config object (for backward compatibility)
auth = BasicHTTPAuth.from_config(config)  # config must have basic_username and basic_password
client = await MCPClientRegistry.get(url, auth=auth)
```

## Key Changes:

1. **BREAKING (v0.5.0)**: `MCPClientRegistry` reverted to singleton pattern (class-based)
2. **BREAKING (v0.3.0)**: Global configuration system removed - all auth must be explicit
3. **BREAKING (v0.3.0)**: `BasicHTTPAuth` requires explicit credentials or use `from_config()` method
4. Authentication is now pluggable and explicit
5. Class renamed: `MCPClientCfg` → `MCPClientConfig`
6. Import path changed from `bot_agent.core.services.mcp_service` to `xylent.mcp_python`
7. Error taxonomy added for better error handling
8. Support for authentication strategies (Basic, No Auth)
9. Per-URL locking for 50-80% better concurrent performance (retained from v0.4.0)

## Development

### Setup

```bash
# Clone repository
git clone git@bitbucket.org:xylent/mcp-python.git
cd mcp-python

# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install project with dev dependencies
poetry install --extra dev
```

### Running Tests

```bash
# Unit tests
poetry run pytest tests/unit -v

# Integration tests
poetry run pytest tests/integration -v

# All tests with coverage
poetry run pytest -v --cov=xylent.mcp_python
```

### Code Quality

```bash
# Linting
poetry run ruff check src tests

# Formatting
poetry run ruff format src tests

# Type checking (strict mode enabled by default)
poetry run mypy src
```

## Documentation

- **[Architecture Overview](docs/ARCHITECTURE_OVERVIEW.md)** - System architecture, MCP protocol explanation, and component relationships
- **[Consumer Guide](docs/CONSUMER_GUIDE.md)** - Integration guide for consuming services
- **[Implementation Details](docs/IMPLEMENTATION_DETAILS.md)** - Deep technical patterns and advanced usage
- **[Roadmap & Improvements](docs/ROADMAP_AND_IMPROVEMENTS.md)** - Future development plans and technical debt tracking

## Architecture

The library is built with production reliability in mind:

- **Lazy Connections**: Connections are established only when the first tool call is made
- **Retry Logic**: Automatic retry with exponential backoff for transient failures
- **Connection Pooling**: Singleton registry ensures one client per URL across entire application
- **Concurrent Optimization**: Per-URL locks allow 50-80% better performance for parallel operations
- **Type Safety**: Full typing support with `py.typed` marker
- **Clean Separation**: Auth strategies, retry logic, and core client are decoupled

## License

Proprietary - Xylent AI Inc.

## Support

For issues and questions, please contact the Xylent engineering team.
