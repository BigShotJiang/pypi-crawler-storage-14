"""Allow execution as python -m backcraft_cli"""
from . import main

if __name__ == "__main__":
    main()
