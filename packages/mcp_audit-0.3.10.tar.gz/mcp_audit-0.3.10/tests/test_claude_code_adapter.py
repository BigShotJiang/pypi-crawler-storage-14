#!/usr/bin/env python3
"""
Integration tests for Claude Code adapter.

Tests the ClaudeCodeAdapter's ability to:
1. Find Claude Code directories
2. Parse JSONL events
3. Track tokens from new content
4. Handle session-level events (__session__)
5. Handle MCP tool call events
"""

import json
import tempfile
import threading
import time
from pathlib import Path
from typing import Generator

import pytest

from mcp_audit.claude_code_adapter import ClaudeCodeAdapter
from mcp_audit.display import NullDisplay


@pytest.fixture
def mock_claude_dir() -> Generator[Path, None, None]:
    """Create a temporary Claude Code directory for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def sample_jsonl_content() -> str:
    """Sample JSONL content with various event types."""
    events = [
        # Summary event (skipped)
        {"type": "summary", "summary": "Test session"},
        # User message (skipped - no usage)
        {
            "type": "user",
            "message": {"role": "user", "content": "Hello"},
        },
        # Assistant message with usage (session event)
        {
            "type": "assistant",
            "message": {
                "model": "claude-opus-4-5-20251101",
                "role": "assistant",
                "content": [{"type": "text", "text": "Hello!"}],
                "usage": {
                    "input_tokens": 100,
                    "output_tokens": 50,
                    "cache_creation_input_tokens": 1000,
                    "cache_read_input_tokens": 500,
                },
            },
        },
        # Assistant message with MCP tool call
        {
            "type": "assistant",
            "message": {
                "model": "claude-opus-4-5-20251101",
                "role": "assistant",
                "content": [
                    {
                        "type": "tool_use",
                        "name": "mcp__zen__chat",
                        "input": {"prompt": "test"},
                    }
                ],
                "usage": {
                    "input_tokens": 200,
                    "output_tokens": 100,
                    "cache_creation_input_tokens": 2000,
                    "cache_read_input_tokens": 1000,
                },
            },
        },
    ]
    return "\n".join(json.dumps(e) for e in events)


class TestClaudeCodeAdapterInitialization:
    """Test adapter initialization and directory detection."""

    def test_initialization_with_claude_dir(self, mock_claude_dir: Path) -> None:
        """Test adapter initialization with explicit claude_dir."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        assert adapter.project == "test-project"
        assert adapter.claude_dir == mock_claude_dir
        assert adapter.platform == "claude-code"

    def test_find_jsonl_files_empty_dir(self, mock_claude_dir: Path) -> None:
        """Test finding JSONL files in empty directory."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        files = adapter._find_jsonl_files()
        assert files == []

    def test_find_jsonl_files_with_files(self, mock_claude_dir: Path) -> None:
        """Test finding JSONL files in directory with files."""
        # Create test files
        (mock_claude_dir / "session1.jsonl").write_text('{"type": "test"}')
        (mock_claude_dir / "session2.jsonl").write_text('{"type": "test"}')
        (mock_claude_dir / "other.txt").write_text("not jsonl")

        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        files = adapter._find_jsonl_files()

        assert len(files) == 2
        assert all(f.suffix == ".jsonl" for f in files)


class TestEventParsing:
    """Test JSONL event parsing."""

    def test_parse_summary_event(self, mock_claude_dir: Path) -> None:
        """Summary events should return None (skipped)."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        event = '{"type": "summary", "summary": "Test"}'
        result = adapter.parse_event(event)
        assert result is None

    def test_parse_user_event(self, mock_claude_dir: Path) -> None:
        """User events should return None (skipped)."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        event = '{"type": "user", "message": {"role": "user", "content": "Hi"}}'
        result = adapter.parse_event(event)
        assert result is None

    def test_parse_assistant_event_with_usage(self, mock_claude_dir: Path) -> None:
        """Assistant events with usage should return __session__ data."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        event = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "model": "claude-opus-4-5-20251101",
                    "role": "assistant",
                    "content": [{"type": "text", "text": "Hello!"}],
                    "usage": {
                        "input_tokens": 100,
                        "output_tokens": 50,
                        "cache_creation_input_tokens": 1000,
                        "cache_read_input_tokens": 500,
                    },
                },
            }
        )
        result = adapter.parse_event(event)

        assert result is not None
        tool_name, usage = result
        assert tool_name == "__session__"
        assert usage["input_tokens"] == 100
        assert usage["output_tokens"] == 50
        assert usage["cache_created_tokens"] == 1000
        assert usage["cache_read_tokens"] == 500

    def test_parse_assistant_event_with_mcp_tool(self, mock_claude_dir: Path) -> None:
        """Assistant events with MCP tools should return tool name and usage."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        event = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "model": "claude-opus-4-5-20251101",
                    "role": "assistant",
                    "content": [
                        {
                            "type": "tool_use",
                            "name": "mcp__zen__chat",
                            "input": {"prompt": "test"},
                        }
                    ],
                    "usage": {
                        "input_tokens": 200,
                        "output_tokens": 100,
                        "cache_creation_input_tokens": 2000,
                        "cache_read_input_tokens": 1000,
                    },
                },
            }
        )
        result = adapter.parse_event(event)

        assert result is not None
        tool_name, usage = result
        assert tool_name == "mcp__zen__chat"
        assert usage["input_tokens"] == 200
        assert usage["output_tokens"] == 100

    def test_parse_invalid_json(self, mock_claude_dir: Path) -> None:
        """Invalid JSON should return None."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        result = adapter.parse_event("not valid json")
        assert result is None


class TestTokenAccumulation:
    """Test token accumulation via _process_tool_call."""

    def test_process_session_event(self, mock_claude_dir: Path) -> None:
        """Session events should accumulate tokens."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        usage = {
            "input_tokens": 100,
            "output_tokens": 50,
            "cache_created_tokens": 1000,
            "cache_read_tokens": 500,
        }
        adapter._process_tool_call("__session__", usage)

        assert adapter.session.token_usage.input_tokens == 100
        assert adapter.session.token_usage.output_tokens == 50
        assert adapter.session.token_usage.cache_created_tokens == 1000
        assert adapter.session.token_usage.cache_read_tokens == 500
        assert adapter.session.token_usage.total_tokens == 1650

    def test_process_mcp_tool_call(self, mock_claude_dir: Path) -> None:
        """MCP tool calls should be recorded and tokens accumulated."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        usage = {
            "input_tokens": 200,
            "output_tokens": 100,
            "cache_created_tokens": 2000,
            "cache_read_tokens": 1000,
        }
        adapter._process_tool_call("mcp__zen__chat", usage)

        # Check tokens accumulated
        assert adapter.session.token_usage.total_tokens == 3300

        # Check server session created
        assert "zen" in adapter.server_sessions
        assert adapter.server_sessions["zen"].total_calls == 1

    def test_multiple_tool_calls(self, mock_claude_dir: Path) -> None:
        """Multiple tool calls should accumulate correctly."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )

        # First call
        adapter._process_tool_call(
            "__session__",
            {
                "input_tokens": 100,
                "output_tokens": 50,
                "cache_created_tokens": 0,
                "cache_read_tokens": 0,
            },
        )

        # Second call (MCP)
        adapter._process_tool_call(
            "mcp__zen__chat",
            {
                "input_tokens": 200,
                "output_tokens": 100,
                "cache_created_tokens": 0,
                "cache_read_tokens": 0,
            },
        )

        # Third call (MCP)
        adapter._process_tool_call(
            "mcp__zen__chat",
            {
                "input_tokens": 300,
                "output_tokens": 150,
                "cache_created_tokens": 0,
                "cache_read_tokens": 0,
            },
        )

        assert adapter.session.token_usage.total_tokens == 900
        assert adapter.server_sessions["zen"].total_calls == 2


class TestFileMonitoring:
    """Test file monitoring functionality."""

    def test_monitor_detects_new_content(
        self,
        mock_claude_dir: Path,
        sample_jsonl_content: str,
    ) -> None:
        """Monitor should detect and process new content written to files."""
        # Create initial file
        test_file = mock_claude_dir / "session.jsonl"
        test_file.write_text("")

        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )

        # Initialize monitoring state
        adapter._tracking_start_time = time.time()
        adapter._start_time = __import__("datetime").datetime.now()
        adapter._last_display_update = 0.0
        adapter._display = NullDisplay()

        # Initialize file positions
        files = adapter._find_jsonl_files()
        for file_path in files:
            adapter.file_positions[file_path] = file_path.stat().st_size

        # Write new content
        test_file.write_text(sample_jsonl_content)

        # Run one iteration of monitoring
        files = adapter._find_jsonl_files()
        for file_path in files:
            if file_path in adapter.file_positions:
                with open(file_path) as f:
                    f.seek(adapter.file_positions[file_path])
                    new_content = f.read()
                    if new_content:
                        for line in new_content.split("\n"):
                            if line.strip():
                                result = adapter.parse_event(line)
                                if result:
                                    tool_name, usage = result
                                    adapter._process_tool_call(tool_name, usage)
                    adapter.file_positions[file_path] = f.tell()

        # Verify tokens were accumulated
        # From sample content: 2 assistant messages
        # Session event: 100+50+1000+500 = 1650
        # MCP event: 200+100+2000+1000 = 3300
        # Total: 4950
        assert adapter.session.token_usage.total_tokens == 4950

    def test_monitor_handles_new_files(self, mock_claude_dir: Path) -> None:
        """Monitor should detect and handle new files created during monitoring."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )

        # Initialize with empty directory
        adapter._tracking_start_time = time.time()
        files = adapter._find_jsonl_files()
        assert len(files) == 0

        # Create new file after tracking starts
        time.sleep(0.1)  # Ensure creation time is after tracking start
        new_file = mock_claude_dir / "new_session.jsonl"
        new_file.write_text(
            json.dumps(
                {
                    "type": "assistant",
                    "message": {
                        "model": "claude-opus-4-5-20251101",
                        "role": "assistant",
                        "content": [],
                        "usage": {
                            "input_tokens": 100,
                            "output_tokens": 50,
                            "cache_creation_input_tokens": 0,
                            "cache_read_input_tokens": 0,
                        },
                    },
                }
            )
        )

        # Find new files
        files = adapter._find_jsonl_files()
        assert len(files) == 1

        # New file should be read from beginning
        for file_path in files:
            if file_path not in adapter.file_positions:
                creation_time = adapter._get_file_creation_time(file_path)
                if creation_time >= adapter._tracking_start_time:
                    adapter.file_positions[file_path] = 0
                else:
                    adapter.file_positions[file_path] = file_path.stat().st_size

        assert adapter.file_positions[new_file] == 0


class TestDisplaySnapshot:
    """Test display snapshot building."""

    def test_build_display_snapshot(self, mock_claude_dir: Path) -> None:
        """Display snapshot should reflect current session state."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        adapter._start_time = __import__("datetime").datetime.now()

        # Add some data
        adapter._process_tool_call(
            "mcp__zen__chat",
            {
                "input_tokens": 100,
                "output_tokens": 50,
                "cache_created_tokens": 1000,
                "cache_read_tokens": 500,
            },
        )

        snapshot = adapter._build_display_snapshot()

        assert snapshot.project == "test-project"
        assert snapshot.platform == "claude-code"
        assert snapshot.total_tokens == 1650
        assert snapshot.total_tool_calls == 1
        assert snapshot.unique_tools == 1


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_file(self, mock_claude_dir: Path) -> None:
        """Empty files should be handled gracefully."""
        (mock_claude_dir / "empty.jsonl").write_text("")

        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )

        files = adapter._find_jsonl_files()
        assert len(files) == 1  # Empty files should be included

    def test_malformed_json_line(self, mock_claude_dir: Path) -> None:
        """Malformed JSON lines should be handled gracefully."""
        test_file = mock_claude_dir / "test.jsonl"
        test_file.write_text("not json\n{invalid\n")

        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )

        # Should not raise
        for line in test_file.read_text().split("\n"):
            result = adapter.parse_event(line)
            assert result is None

    def test_missing_usage_field(self, mock_claude_dir: Path) -> None:
        """Assistant messages without usage should return None."""
        adapter = ClaudeCodeAdapter(
            project="test-project",
            claude_dir=mock_claude_dir,
        )
        event = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": [],
                    # No usage field
                },
            }
        )
        result = adapter.parse_event(event)
        assert result is None
