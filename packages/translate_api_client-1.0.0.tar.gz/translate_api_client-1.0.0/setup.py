from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="translate-api-client",
    version="1.0.0",
    author="Translate API",
    author_email="support@translate-api.com",
    description="Official Python SDK for Translate API - Easy text translation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://translate-api.com",
    project_urls={
        "Documentation": "https://translate-api.com/documentation",
        "Bug Tracker": "https://github.com/Translate-api/translate-api-python-sdk/issues",
        "Source": "https://github.com/Translate-api/translate-api-python-sdk",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Linguistic",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
    ],
    keywords="translate translation api sdk language i18n localization",
)