# Translate API - Python SDK

Official Python SDK for [Translate API](https://translate-api.com).

## 🚀 Quick Start (For Beginners)

### Step 1: Get Your API Key
1. Go to [https://translate-api.com](https://translate-api.com)
2. Click "Login" or "Get Started"
3. Create an account (it's free to start!)
4. Go to your Dashboard
5. Click "Create API Key"
6. Copy your API key - you'll need it!

### Step 2: Install the SDK
Open your terminal/command prompt and run:

```bash
pip install translate-api-client
```

### Step 3: Use It!

```python
from translate_api import TranslateAPI

# Replace 'your-api-key' with your actual API key from translate-api.com
client = TranslateAPI('your-api-key')

# Translate to one language
result = client.translate('Hello world', 'es')
print(result['translations']['es'])  # Output: "Hola mundo"

# Translate to multiple languages at once
result = client.translate('Hello world', ['es', 'fr', 'de'])
print(result['translations'])
# Output: {'es': 'Hola mundo', 'fr': 'Bonjour le monde', 'de': 'Hallo Welt'}
```

## 📖 Full API Reference

### Constructor
```python
client = TranslateAPI(api_key, base_url='https://translate-api.com/v1')
```
- `api_key` (required): Your API key from translate-api.com
- `base_url` (optional): Custom API URL

### translate(text, target_language)
Translate text to one or more languages.

**Parameters:**
- `text`: The text you want to translate
- `target_language`: A language code ('es') or list of codes (['es', 'fr'])

**Returns:** Dictionary with translation results

### translate_batch(items)
Translate multiple texts at once.

```python
results = client.translate_batch([
    {'text': 'Hello', 'target_language': 'es'},
    {'text': 'Goodbye', 'target_language': 'fr'}
])
```

## 🌍 Supported Languages
Visit [translate-api.com/documentation](https://translate-api.com/documentation) for a full list.

Common codes: en, es, fr, de, it, pt, zh, ja, ko, ar

## ❓ Need Help?
- Documentation: [translate-api.com/documentation](https://translate-api.com/documentation)
- Support: support@translate-api.com

## 📝 License
MIT License
