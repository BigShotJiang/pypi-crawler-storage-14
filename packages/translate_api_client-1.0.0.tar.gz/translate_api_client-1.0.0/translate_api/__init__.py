"""
Translate API - Official Python SDK

Get your API key at: https://translate-api.com
Documentation: https://translate-api.com/documentation
"""

import requests
from typing import Union, List, Dict, Optional

__version__ = "1.0.0"
__author__ = "Translate API"

class TranslateAPI:
    """
    Official Python SDK for Translate API
    
    Get your API key at: https://translate-api.com
    
    Example:
        >>> client = TranslateAPI('your-api-key')
        >>> result = client.translate('Hello', 'es')
        >>> print(result['translations']['es'])
        'Hola'
    """
    
    def __init__(self, api_key: str, base_url: str = "https://translate-api.com/v1"):
        """
        Create a new Translate API client.
        
        Args:
            api_key: Your API key from translate-api.com
            base_url: Optional custom API URL
        """
        if not api_key:
            raise ValueError("API key is required. Get one at https://translate-api.com")
        
        self.api_key = api_key
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def translate(
        self, 
        text: str, 
        target_language: Union[str, List[str]]
    ) -> Dict:
        """
        Translate text to one or more target languages.
        
        Args:
            text: The text to translate
            target_language: Single language code ('es') or list of codes (['es', 'fr'])
            
        Returns:
            Dictionary with 'translations', 'success', 'characters_used'
            
        Example:
            >>> result = client.translate('Hello', ['es', 'fr'])
            >>> print(result['translations'])
            {'es': 'Hola', 'fr': 'Bonjour'}
        """
        response = self.session.post(
            f"{self.base_url}/translate",
            json={
                "text": text,
                "target_language": target_language
            }
        )
        response.raise_for_status()
        return response.json()
    
    def translate_batch(
        self, 
        items: List[Dict[str, Union[str, List[str]]]]
    ) -> List[Dict]:
        """
        Translate multiple texts in batch.
        
        Args:
            items: List of dicts with 'text' and 'target_language' keys
            
        Returns:
            List of translation responses
            
        Example:
            >>> results = client.translate_batch([
            ...     {'text': 'Hello', 'target_language': 'es'},
            ...     {'text': 'Goodbye', 'target_language': 'fr'}
            ... ])
        """
        return [
            self.translate(item["text"], item["target_language"])
            for item in items
        ]


# Convenience export
__all__ = ["TranslateAPI", "__version__"]
