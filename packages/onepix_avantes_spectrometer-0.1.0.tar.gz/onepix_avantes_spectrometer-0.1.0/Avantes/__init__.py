# Avantes/__init__.py
from importlib import import_module

# Importer la classe Avantes depuis le fichier Avantes.py sans créer de boucle
Avantes = import_module(".Avantes", package=__package__).Avantes

__all__ = ["Avantes"]