# VRRPVR

VRRP VR summary.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vrid** | **int** | VRRP VR ID. | 
**interface_name** | **str** | Name of the interface. | [optional] 
**priority** | **int** | Priority of the VR. | 
**state** | **str** | State of the VR. Either init, intf-down, backup or master.  | 
**addresses** | **List[str]** | IP addresses configured on the VR. | 
**peers** | **List[str]** | IP addresses of the VRRP peers. | [optional] 

## Example

```python
from anapaya.appliance.models.vrrpvr import VRRPVR

# TODO update the JSON string below
json = "{}"
# create an instance of VRRPVR from a JSON string
vrrpvr_instance = VRRPVR.from_json(json)
# print the JSON string representation of the object
print VRRPVR.to_json()

# convert the object into a dict
vrrpvr_dict = vrrpvr_instance.to_dict()
# create an instance of VRRPVR from a dict
vrrpvr_form_dict = vrrpvr.from_dict(vrrpvr_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


