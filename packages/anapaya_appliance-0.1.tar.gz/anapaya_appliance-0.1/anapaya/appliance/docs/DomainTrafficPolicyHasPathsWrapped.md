# DomainTrafficPolicyHasPathsWrapped


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**check_id** | **str** | The identifier of the health check type. There can be multiple instances of the same health check in the response.  See the description of the &#x60;data&#x60; field for more information on how the health check is evaluated.  | 
**name** | **str** | The human readable name of the health check type. To identify the type of health check in automated systems, use the &#x60;id&#x60; field instead.  | 
**status** | [**HealthStatus**](HealthStatus.md) |  | 
**detail** | **str** | A human readable explanation of the health check status.  | [optional] 
**data** | [**DomainTrafficPolicyHasPathsData**](DomainTrafficPolicyHasPathsData.md) |  | 
**component** | [**HealthComponent**](HealthComponent.md) |  | 
**service_name** | **str** | Name of the service that the health check applies to. | 

## Example

```python
from anapaya.appliance.models.domain_traffic_policy_has_paths_wrapped import DomainTrafficPolicyHasPathsWrapped

# TODO update the JSON string below
json = "{}"
# create an instance of DomainTrafficPolicyHasPathsWrapped from a JSON string
domain_traffic_policy_has_paths_wrapped_instance = DomainTrafficPolicyHasPathsWrapped.from_json(json)
# print the JSON string representation of the object
print DomainTrafficPolicyHasPathsWrapped.to_json()

# convert the object into a dict
domain_traffic_policy_has_paths_wrapped_dict = domain_traffic_policy_has_paths_wrapped_instance.to_dict()
# create an instance of DomainTrafficPolicyHasPathsWrapped from a dict
domain_traffic_policy_has_paths_wrapped_form_dict = domain_traffic_policy_has_paths_wrapped.from_dict(domain_traffic_policy_has_paths_wrapped_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


