# anapaya.appliance.SecretsApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**secrets_batch_post**](SecretsApi.md#secrets_batch_post) | **POST** /secrets/batch | Add secrets batch
[**secrets_get**](SecretsApi.md#secrets_get) | **GET** /secrets | List secret IDs
[**secrets_id_delete**](SecretsApi.md#secrets_id_delete) | **DELETE** /secrets/{id} | Delete secret
[**secrets_post**](SecretsApi.md#secrets_post) | **POST** /secrets | Add secret


# **secrets_batch_post**
> secrets_batch_post(secrets_batch_request_json=secrets_batch_request_json)

Add secrets batch

Add a batch of new secrets.  If one secret is invalid (e.g. secret ID already exists or invalid), the entire request will fail and no secret is created. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.secrets_batch_request_json import SecretsBatchRequestJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SecretsApi(api_client)
    secrets_batch_request_json = anapaya.appliance.SecretsBatchRequestJson() # SecretsBatchRequestJson |  (optional)

    try:
        # Add secrets batch
        api_instance.secrets_batch_post(secrets_batch_request_json=secrets_batch_request_json)
    except Exception as e:
        print("Exception when calling SecretsApi->secrets_batch_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **secrets_batch_request_json** | [**SecretsBatchRequestJson**](SecretsBatchRequestJson.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | success |  -  |
**400** | bad request |  -  |
**409** | The request contains a secret id that already exists or is invalid. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **secrets_get**
> SecretsGetResponseJson secrets_get()

List secret IDs

Get all IDs of all available secrets.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.secrets_get_response_json import SecretsGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SecretsApi(api_client)

    try:
        # List secret IDs
        api_response = api_instance.secrets_get()
        print("The response of SecretsApi->secrets_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SecretsApi->secrets_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SecretsGetResponseJson**](SecretsGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **secrets_id_delete**
> secrets_id_delete(id)

Delete secret

Delete a secret by its ID. Delete a secret using its ID. It is only possible to delete secrets that are not contained in the appliance configuration. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SecretsApi(api_client)
    id = 'forwarding-key_1-ff00:0:110@1' # str | The secret ID.

    try:
        # Delete secret
        api_instance.secrets_id_delete(id)
    except Exception as e:
        print("Exception when calling SecretsApi->secrets_id_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| The secret ID. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | success |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**409** | request in conflict with current server state |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **secrets_post**
> secrets_post(secrets_post_request_json=secrets_post_request_json)

Add secret

Adds a new secret into the secret store.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.secrets_post_request_json import SecretsPostRequestJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SecretsApi(api_client)
    secrets_post_request_json = anapaya.appliance.SecretsPostRequestJson() # SecretsPostRequestJson |  (optional)

    try:
        # Add secret
        api_instance.secrets_post(secrets_post_request_json=secrets_post_request_json)
    except Exception as e:
        print("Exception when calling SecretsApi->secrets_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **secrets_post_request_json** | [**SecretsPostRequestJson**](SecretsPostRequestJson.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | success |  -  |
**400** | bad request |  -  |
**409** | The secret id already exists or is invalid. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

