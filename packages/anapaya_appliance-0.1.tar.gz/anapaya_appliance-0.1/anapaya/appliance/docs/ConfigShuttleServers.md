# ConfigShuttleServers

The necessary configuration data for Shuttle servers on the Anapaya appliance.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**servers** | [**List[ConfigShuttleServersServer]**](ConfigShuttleServersServer.md) | The necessary configuration data for Shuttle servers on the Anapaya appliance. | [optional] 

## Example

```python
from anapaya.appliance.models.config_shuttle_servers import ConfigShuttleServers

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigShuttleServers from a JSON string
config_shuttle_servers_instance = ConfigShuttleServers.from_json(json)
# print the JSON string representation of the object
print ConfigShuttleServers.to_json()

# convert the object into a dict
config_shuttle_servers_dict = config_shuttle_servers_instance.to_dict()
# create an instance of ConfigShuttleServers from a dict
config_shuttle_servers_form_dict = config_shuttle_servers.from_dict(config_shuttle_servers_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


