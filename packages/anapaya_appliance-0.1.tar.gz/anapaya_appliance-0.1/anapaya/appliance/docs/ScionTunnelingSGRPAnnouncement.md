# ScionTunnelingSGRPAnnouncement


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**local_isd_as** | **str** |  | 
**remotes** | [**List[ScionTunnelingSGRPAnnouncementRemote]**](ScionTunnelingSGRPAnnouncementRemote.md) |  | 

## Example

```python
from anapaya.appliance.models.scion_tunneling_sgrp_announcement import ScionTunnelingSGRPAnnouncement

# TODO update the JSON string below
json = "{}"
# create an instance of ScionTunnelingSGRPAnnouncement from a JSON string
scion_tunneling_sgrp_announcement_instance = ScionTunnelingSGRPAnnouncement.from_json(json)
# print the JSON string representation of the object
print ScionTunnelingSGRPAnnouncement.to_json()

# convert the object into a dict
scion_tunneling_sgrp_announcement_dict = scion_tunneling_sgrp_announcement_instance.to_dict()
# create an instance of ScionTunnelingSGRPAnnouncement from a dict
scion_tunneling_sgrp_announcement_form_dict = scion_tunneling_sgrp_announcement.from_dict(scion_tunneling_sgrp_announcement_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


