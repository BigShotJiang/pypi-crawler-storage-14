# ConfigManagementPam

Configuration for the Pluggable Authentication Module (PAM) of the Anapaya appliance.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**services** | [**List[ConfigManagementPamService]**](ConfigManagementPamService.md) | List of services that are configured to use the Pluggable Authentication Module (PAM) of the Anapaya appliance. | [optional] 

## Example

```python
from anapaya.appliance.models.config_management_pam import ConfigManagementPam

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigManagementPam from a JSON string
config_management_pam_instance = ConfigManagementPam.from_json(json)
# print the JSON string representation of the object
print ConfigManagementPam.to_json()

# convert the object into a dict
config_management_pam_dict = config_management_pam_instance.to_dict()
# create an instance of ConfigManagementPam from a dict
config_management_pam_form_dict = config_management_pam.from_dict(config_management_pam_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


