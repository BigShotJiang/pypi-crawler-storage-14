# ConfigManagementPamService

Customized PAM service configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_modules** | **List[str]** | List of PAM account modules that are used for the service. | [optional] 
**auth_modules** | **List[str]** | List of PAM authentication modules that are used for the service. | [optional] 
**description** | **str** | Description or comment for the service. | [optional] 
**enabled** | **bool** | Whether the PAM service is enabled. | [optional] [default to False]
**password_modules** | **List[str]** | List of PAM password modules that are used for the service. | [optional] 
**service** | **str** | The name of the PAM service. The service name must be a valid service name according to the PAM specification. The service name is used to identify the service in the PAM configuration files. | [optional] 
**session_modules** | **List[str]** | List of PAM session modules that are used for the service. | [optional] 

## Example

```python
from anapaya.appliance.models.config_management_pam_service import ConfigManagementPamService

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigManagementPamService from a JSON string
config_management_pam_service_instance = ConfigManagementPamService.from_json(json)
# print the JSON string representation of the object
print ConfigManagementPamService.to_json()

# convert the object into a dict
config_management_pam_service_dict = config_management_pam_service_instance.to_dict()
# create an instance of ConfigManagementPamService from a dict
config_management_pam_service_form_dict = config_management_pam_service.from_dict(config_management_pam_service_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


