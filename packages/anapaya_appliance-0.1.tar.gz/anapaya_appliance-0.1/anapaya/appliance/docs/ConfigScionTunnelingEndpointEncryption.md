# ConfigScionTunnelingEndpointEncryption

Payload encryption configuration for the IP-in-SCION tunnel endpoint.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** | Whether the payload encryption module is enabled. With payload encryption enabled, the IP packets are encrypted and authenticated before being sent to a remote tunnel endpoint for domains that have the payload encryption enabled. Note that this flag only enables the payload encryption system. Each domain for which payload encryption should be used must still explicitly enable it. | [optional] 
**per_remote_sa_limit** | **int** | The maximum number of Security Associations (SAs) that can be established with a single remote AS. If the limit is reached, new SAs from all endpoints in that AS will be rejected. | [optional] [default to 1000]
**port** | **int** | Port number for the secure data traffic. The address is constructed from the endpoint IP address and this port. If not set, or zero, the secure data port will be dynamically allocated. | [optional] 
**total_sa_limit** | **int** | The maximum number of Security Associations (SAs) that can be established with remote tunnel endpoints. If the limit is reached, new SAs will be rejected. | [optional] [default to 100000]

## Example

```python
from anapaya.appliance.models.config_scion_tunneling_endpoint_encryption import ConfigScionTunnelingEndpointEncryption

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigScionTunnelingEndpointEncryption from a JSON string
config_scion_tunneling_endpoint_encryption_instance = ConfigScionTunnelingEndpointEncryption.from_json(json)
# print the JSON string representation of the object
print ConfigScionTunnelingEndpointEncryption.to_json()

# convert the object into a dict
config_scion_tunneling_endpoint_encryption_dict = config_scion_tunneling_endpoint_encryption_instance.to_dict()
# create an instance of ConfigScionTunnelingEndpointEncryption from a dict
config_scion_tunneling_endpoint_encryption_form_dict = config_scion_tunneling_endpoint_encryption.from_dict(config_scion_tunneling_endpoint_encryption_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


