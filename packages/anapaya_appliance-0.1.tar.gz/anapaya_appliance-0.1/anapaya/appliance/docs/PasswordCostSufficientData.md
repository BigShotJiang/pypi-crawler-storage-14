# PasswordCostSufficientData

The complexity for the bcrypt algorithm used in the password hash is not sufficient. We will soon require a cost of at least 8. This is a security risk and you should re-hash your password with a higher cost. We recommend a cost of at least 12, however, you should choose the value based on your threat model. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cost** | **int** | The effective cost of the bcrypt algorithm used in the password.  | 
**username** | **str** | The name of the user with the low password cost.  | 

## Example

```python
from anapaya.appliance.models.password_cost_sufficient_data import PasswordCostSufficientData

# TODO update the JSON string below
json = "{}"
# create an instance of PasswordCostSufficientData from a JSON string
password_cost_sufficient_data_instance = PasswordCostSufficientData.from_json(json)
# print the JSON string representation of the object
print PasswordCostSufficientData.to_json()

# convert the object into a dict
password_cost_sufficient_data_dict = password_cost_sufficient_data_instance.to_dict()
# create an instance of PasswordCostSufficientData from a dict
password_cost_sufficient_data_form_dict = password_cost_sufficient_data.from_dict(password_cost_sufficient_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


