# ConfigsPostRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | [**Config**](Config.md) |  | 

## Example

```python
from anapaya.appliance.models.configs_post_request import ConfigsPostRequest

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigsPostRequest from a JSON string
configs_post_request_instance = ConfigsPostRequest.from_json(json)
# print the JSON string representation of the object
print ConfigsPostRequest.to_json()

# convert the object into a dict
configs_post_request_dict = configs_post_request_instance.to_dict()
# create an instance of ConfigsPostRequest from a dict
configs_post_request_form_dict = configs_post_request.from_dict(configs_post_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


