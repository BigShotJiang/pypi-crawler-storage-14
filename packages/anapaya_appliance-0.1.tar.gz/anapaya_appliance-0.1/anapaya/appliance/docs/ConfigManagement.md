# ConfigManagement

The necessary configuration data for the management of the  Anapaya appliance.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api** | [**ConfigManagementApi**](ConfigManagementApi.md) |  | [optional] 
**hostname** | **str** | The hostname of the Anapaya appliance host. It is used to identify the host in the telemetry data; thus, each host should have a unique hostname. The hostname must be a valid hostname according to the RFC 1123 specification. By default, the appliance API disallows changing the hostname, except when it is still unset. If the hostname is already set, the API will return a validation error. This is a safety measure to prevent accidental deployment of a configuration meant for a different appliance. If you want to change the hostname after it has been set, you need to set the &#x60;allow_hostname_change&#x60; query parameter to &#x60;true&#x60;. | [optional] [default to 'anapaya-appliance']
**pam** | [**ConfigManagementPam**](ConfigManagementPam.md) |  | [optional] 
**ssh** | [**ConfigManagementSsh**](ConfigManagementSsh.md) |  | [optional] 
**telemetry** | [**ConfigManagementTelemetry**](ConfigManagementTelemetry.md) |  | [optional] 

## Example

```python
from anapaya.appliance.models.config_management import ConfigManagement

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigManagement from a JSON string
config_management_instance = ConfigManagement.from_json(json)
# print the JSON string representation of the object
print ConfigManagement.to_json()

# convert the object into a dict
config_management_dict = config_management_instance.to_dict()
# create an instance of ConfigManagement from a dict
config_management_form_dict = config_management.from_dict(config_management_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


