# ConfigNatDnatPortMapping

List of port mappings.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** | An optional textual description of the port mapping configuration. | [optional] 
**destination_port** | **int** | The mapped destination port. The destination port of matched packets is replaced by this port. | [optional] 
**port** | **int** | The destination port that needs to be translated. This is an exact match on the destination port of packets received from the IP-in-SCION tunnel. | [optional] 
**protocol** | **str** | Transmission layer protocol. Supported protocols are (tcp, udp).  | [optional] 

## Example

```python
from anapaya.appliance.models.config_nat_dnat_port_mapping import ConfigNatDnatPortMapping

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigNatDnatPortMapping from a JSON string
config_nat_dnat_port_mapping_instance = ConfigNatDnatPortMapping.from_json(json)
# print the JSON string representation of the object
print ConfigNatDnatPortMapping.to_json()

# convert the object into a dict
config_nat_dnat_port_mapping_dict = config_nat_dnat_port_mapping_instance.to_dict()
# create an instance of ConfigNatDnatPortMapping from a dict
config_nat_dnat_port_mapping_form_dict = config_nat_dnat_port_mapping.from_dict(config_nat_dnat_port_mapping_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


