# InterfaceExistsData

The configured interface exists on the system. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**interface** | **str** | Name of the interface. | 

## Example

```python
from anapaya.appliance.models.interface_exists_data import InterfaceExistsData

# TODO update the JSON string below
json = "{}"
# create an instance of InterfaceExistsData from a JSON string
interface_exists_data_instance = InterfaceExistsData.from_json(json)
# print the JSON string representation of the object
print InterfaceExistsData.to_json()

# convert the object into a dict
interface_exists_data_dict = interface_exists_data_instance.to_dict()
# create an instance of InterfaceExistsData from a dict
interface_exists_data_form_dict = interface_exists_data.from_dict(interface_exists_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


