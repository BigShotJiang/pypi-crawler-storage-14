# anapaya.appliance.NetworkApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**network_physical_interfaces_get**](NetworkApi.md#network_physical_interfaces_get) | **GET** /network/physical-interfaces | List physical interfaces
[**network_shuttle_get**](NetworkApi.md#network_shuttle_get) | **GET** /network/shuttles/{interface_name} | Get shuttle client
[**network_shuttle_server_get**](NetworkApi.md#network_shuttle_server_get) | **GET** /network/shuttle-servers/{interface_name} | Get shuttle server
[**network_shuttle_servers_get**](NetworkApi.md#network_shuttle_servers_get) | **GET** /network/shuttle-servers | List shuttle servers
[**network_shuttles_get**](NetworkApi.md#network_shuttles_get) | **GET** /network/shuttles | List shuttle clients
[**network_wireguards_get**](NetworkApi.md#network_wireguards_get) | **GET** /network/wireguards | List Wireguard interfaces
[**network_wireguards_interface_get**](NetworkApi.md#network_wireguards_interface_get) | **GET** /network/wireguards/{interface_name} | Get Wireguard interface


# **network_physical_interfaces_get**
> NetworkPhysicalInterfacesGetResponseJson network_physical_interfaces_get()

List physical interfaces

List the available physical interfaces of the appliance. The result includes the interface name and the PCI-E Bus/Device/Function (BDF) address for each interface. Only physical interfaces are listed here. To configure them use the config endpoint of the API. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_physical_interfaces_get_response_json import NetworkPhysicalInterfacesGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.NetworkApi(api_client)

    try:
        # List physical interfaces
        api_response = api_instance.network_physical_interfaces_get()
        print("The response of NetworkApi->network_physical_interfaces_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling NetworkApi->network_physical_interfaces_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**NetworkPhysicalInterfacesGetResponseJson**](NetworkPhysicalInterfacesGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **network_shuttle_get**
> NetworkShuttleGetResponseJson network_shuttle_get(interface_name)

Get shuttle client

Provide information about a shuttle client. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_shuttle_get_response_json import NetworkShuttleGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.NetworkApi(api_client)
    interface_name = 'interface_name_example' # str | Name of the interface to list.

    try:
        # Get shuttle client
        api_response = api_instance.network_shuttle_get(interface_name)
        print("The response of NetworkApi->network_shuttle_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling NetworkApi->network_shuttle_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **interface_name** | **str**| Name of the interface to list. | 

### Return type

[**NetworkShuttleGetResponseJson**](NetworkShuttleGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **network_shuttle_server_get**
> NetworkShuttleServerGetResponseJson network_shuttle_server_get(interface_name)

Get shuttle server

Provide information about a shuttle server and clients configured on and connected to it. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_shuttle_server_get_response_json import NetworkShuttleServerGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.NetworkApi(api_client)
    interface_name = 'interface_name_example' # str | Name of the interface to list.

    try:
        # Get shuttle server
        api_response = api_instance.network_shuttle_server_get(interface_name)
        print("The response of NetworkApi->network_shuttle_server_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling NetworkApi->network_shuttle_server_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **interface_name** | **str**| Name of the interface to list. | 

### Return type

[**NetworkShuttleServerGetResponseJson**](NetworkShuttleServerGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **network_shuttle_servers_get**
> NetworkShuttleServersGetResponseJson network_shuttle_servers_get()

List shuttle servers

List the information about all shuttle servers and clients configured on and connected to them. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_shuttle_servers_get_response_json import NetworkShuttleServersGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.NetworkApi(api_client)

    try:
        # List shuttle servers
        api_response = api_instance.network_shuttle_servers_get()
        print("The response of NetworkApi->network_shuttle_servers_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling NetworkApi->network_shuttle_servers_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**NetworkShuttleServersGetResponseJson**](NetworkShuttleServersGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **network_shuttles_get**
> NetworkShuttlesGetResponseJson network_shuttles_get()

List shuttle clients

List the information about all shuttle clients. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_shuttles_get_response_json import NetworkShuttlesGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.NetworkApi(api_client)

    try:
        # List shuttle clients
        api_response = api_instance.network_shuttles_get()
        print("The response of NetworkApi->network_shuttles_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling NetworkApi->network_shuttles_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**NetworkShuttlesGetResponseJson**](NetworkShuttlesGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **network_wireguards_get**
> NetworkWireguardsGetResponseJson network_wireguards_get()

List Wireguard interfaces

List the configured wireguard interfaces. The result includes the interface name and the public key. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_wireguards_get_response_json import NetworkWireguardsGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.NetworkApi(api_client)

    try:
        # List Wireguard interfaces
        api_response = api_instance.network_wireguards_get()
        print("The response of NetworkApi->network_wireguards_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling NetworkApi->network_wireguards_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**NetworkWireguardsGetResponseJson**](NetworkWireguardsGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **network_wireguards_interface_get**
> NetworkWireguardsInterfaceGetResponseJson network_wireguards_interface_get(interface_name)

Get Wireguard interface

Returns the configured wireguard interface and the public key. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_wireguards_interface_get_response_json import NetworkWireguardsInterfaceGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.NetworkApi(api_client)
    interface_name = 'interface_name_example' # str | Name of the interface to list.

    try:
        # Get Wireguard interface
        api_response = api_instance.network_wireguards_interface_get(interface_name)
        print("The response of NetworkApi->network_wireguards_interface_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling NetworkApi->network_wireguards_interface_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **interface_name** | **str**| Name of the interface to list. | 

### Return type

[**NetworkWireguardsInterfaceGetResponseJson**](NetworkWireguardsInterfaceGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

