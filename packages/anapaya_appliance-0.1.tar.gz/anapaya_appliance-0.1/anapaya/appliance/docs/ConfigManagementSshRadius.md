# ConfigManagementSshRadius

Configuration for RADIUS access to the Anapaya appliance. The resulting RADIUS configuration on the appliance is written to /etc/pam_radius_auth.conf, and can be referenced in the PAM configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**servers** | [**List[ConfigManagementSshRadiusServer]**](ConfigManagementSshRadiusServer.md) | RADIUS server configurations. | [optional] 

## Example

```python
from anapaya.appliance.models.config_management_ssh_radius import ConfigManagementSshRadius

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigManagementSshRadius from a JSON string
config_management_ssh_radius_instance = ConfigManagementSshRadius.from_json(json)
# print the JSON string representation of the object
print ConfigManagementSshRadius.to_json()

# convert the object into a dict
config_management_ssh_radius_dict = config_management_ssh_radius_instance.to_dict()
# create an instance of ConfigManagementSshRadius from a dict
config_management_ssh_radius_form_dict = config_management_ssh_radius.from_dict(config_management_ssh_radius_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


