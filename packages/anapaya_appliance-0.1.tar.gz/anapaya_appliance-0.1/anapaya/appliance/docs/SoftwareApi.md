# anapaya.appliance.SoftwareApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**software_scion_install_get**](SoftwareApi.md#software_scion_install_get) | **GET** /software/scion/install/{id} | Get SCION package installation status
[**software_scion_install_post**](SoftwareApi.md#software_scion_install_post) | **POST** /software/scion/install | Install SCION package
[**software_scion_installed_get**](SoftwareApi.md#software_scion_installed_get) | **GET** /software/scion/installed | Get installed SCION version
[**software_scion_package_local_cleanup_post**](SoftwareApi.md#software_scion_package_local_cleanup_post) | **POST** /software/scion/packages/local/cleanup | Clean up scion packages
[**software_scion_package_local_delete**](SoftwareApi.md#software_scion_package_local_delete) | **DELETE** /software/scion/packages/local/{version} | Delete SCION package
[**software_scion_package_local_get**](SoftwareApi.md#software_scion_package_local_get) | **GET** /software/scion/packages/local/{version} | Get SCION package information
[**software_scion_packages_local_get**](SoftwareApi.md#software_scion_packages_local_get) | **GET** /software/scion/packages/local | List SCION packages
[**software_scion_packages_local_post**](SoftwareApi.md#software_scion_packages_local_post) | **POST** /software/scion/packages/local | Add SCION package
[**software_system_install_get**](SoftwareApi.md#software_system_install_get) | **GET** /software/system/install/{id} | Get system package installation status
[**software_system_install_post**](SoftwareApi.md#software_system_install_post) | **POST** /software/system/install | Install system package
[**software_system_installed_get**](SoftwareApi.md#software_system_installed_get) | **GET** /software/system/installed | Get installed system version
[**software_system_package_local_cleanup_post**](SoftwareApi.md#software_system_package_local_cleanup_post) | **POST** /software/system/packages/local/cleanup | Clean up system packages
[**software_system_package_local_delete**](SoftwareApi.md#software_system_package_local_delete) | **DELETE** /software/system/packages/local/{version} | Delete system package
[**software_system_package_local_get**](SoftwareApi.md#software_system_package_local_get) | **GET** /software/system/packages/local/{version} | Get system package information
[**software_system_packages_local_get**](SoftwareApi.md#software_system_packages_local_get) | **GET** /software/system/packages/local | List system packages
[**software_system_packages_local_post**](SoftwareApi.md#software_system_packages_local_post) | **POST** /software/system/packages/local | Add system package


# **software_scion_install_get**
> SoftwareInstallGetResponseJson software_scion_install_get(id)

Get SCION package installation status

Get the status of the installation process of the scion package for the given id. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_install_get_response_json import SoftwareInstallGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    id = 'id_example' # str | Identifier of the installation process for the specific scion package version. 

    try:
        # Get SCION package installation status
        api_response = api_instance.software_scion_install_get(id)
        print("The response of SoftwareApi->software_scion_install_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_install_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Identifier of the installation process for the specific scion package version.  | 

### Return type

[**SoftwareInstallGetResponseJson**](SoftwareInstallGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Installation status. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_scion_install_post**
> SoftwareInstallPostResponseJson software_scion_install_post(software_install_post_request_json)

Install SCION package

Trigger the installation of the SCION package with the version specified in the request body. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_install_post_request_json import SoftwareInstallPostRequestJson
from anapaya.appliance.models.software_install_post_response_json import SoftwareInstallPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    software_install_post_request_json = anapaya.appliance.SoftwareInstallPostRequestJson() # SoftwareInstallPostRequestJson | 

    try:
        # Install SCION package
        api_response = api_instance.software_scion_install_post(software_install_post_request_json)
        print("The response of SoftwareApi->software_scion_install_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_install_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **software_install_post_request_json** | [**SoftwareInstallPostRequestJson**](SoftwareInstallPostRequestJson.md)|  | 

### Return type

[**SoftwareInstallPostResponseJson**](SoftwareInstallPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Package version and installation ID. |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**409** | request in conflict with current server state |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_scion_installed_get**
> SoftwareInstalledGetResponseJson software_scion_installed_get()

Get installed SCION version

Get the version of scion package currently installed. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_installed_get_response_json import SoftwareInstalledGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)

    try:
        # Get installed SCION version
        api_response = api_instance.software_scion_installed_get()
        print("The response of SoftwareApi->software_scion_installed_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_installed_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SoftwareInstalledGetResponseJson**](SoftwareInstalledGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Installed scion version. |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_scion_package_local_cleanup_post**
> software_scion_package_local_cleanup_post(all=all)

Clean up scion packages

Remove all the unused scion packages from the local repository. By default, the currently installed scion package is not removed to allow rollback in case the next update fails.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    all = True # bool | If all is true, the currently installed scion package is also removed. (optional)

    try:
        # Clean up scion packages
        api_instance.software_scion_package_local_cleanup_post(all=all)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_package_local_cleanup_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **all** | **bool**| If all is true, the currently installed scion package is also removed. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_scion_package_local_delete**
> SoftwarePackageDeleteResponseJson software_scion_package_local_delete(version)

Delete SCION package

Delete the scion package for the given version if it is available locally on the appliance. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_package_delete_response_json import SoftwarePackageDeleteResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    version = 'version_example' # str | Version of the scion package.

    try:
        # Delete SCION package
        api_response = api_instance.software_scion_package_local_delete(version)
        print("The response of SoftwareApi->software_scion_package_local_delete:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_package_local_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**| Version of the scion package. | 

### Return type

[**SoftwarePackageDeleteResponseJson**](SoftwarePackageDeleteResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Package information. |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_scion_package_local_get**
> SoftwarePackageGetResponseJson software_scion_package_local_get(version)

Get SCION package information

Get the package information of the scion package for the given version. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_package_get_response_json import SoftwarePackageGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    version = 'version_example' # str | Version of the scion package.

    try:
        # Get SCION package information
        api_response = api_instance.software_scion_package_local_get(version)
        print("The response of SoftwareApi->software_scion_package_local_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_package_local_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**| Version of the scion package. | 

### Return type

[**SoftwarePackageGetResponseJson**](SoftwarePackageGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Package information. |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_scion_packages_local_get**
> SoftwarePackagesGetResponseJson software_scion_packages_local_get()

List SCION packages

List the package information (e.g., version) for all the SCION packages which are available locally on the appliance. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_packages_get_response_json import SoftwarePackagesGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)

    try:
        # List SCION packages
        api_response = api_instance.software_scion_packages_local_get()
        print("The response of SoftwareApi->software_scion_packages_local_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_packages_local_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SoftwarePackagesGetResponseJson**](SoftwarePackagesGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_scion_packages_local_post**
> SoftwarePackagesPostResponseJson software_scion_packages_local_post(body, force=force)

Add SCION package

Upload the SCION package to the local repository of the appliance.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_packages_post_response_json import SoftwarePackagesPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    body = None # bytearray | 
    force = False # bool | If force is true, the package is stored regardless of whether it already exists. (optional) (default to False)

    try:
        # Add SCION package
        api_response = api_instance.software_scion_packages_local_post(body, force=force)
        print("The response of SoftwareApi->software_scion_packages_local_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_scion_packages_local_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **bytearray**|  | 
 **force** | **bool**| If force is true, the package is stored regardless of whether it already exists. | [optional] [default to False]

### Return type

[**SoftwarePackagesPostResponseJson**](SoftwarePackagesPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Package information. |  -  |
**400** | bad request |  -  |
**409** | request in conflict with current server state |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_install_get**
> SoftwareInstallGetResponseJson software_system_install_get(id)

Get system package installation status

Get the status of the installation process of the system package for the given id. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_install_get_response_json import SoftwareInstallGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    id = 'id_example' # str | Identifier of the installation process for the specific system package version. 

    try:
        # Get system package installation status
        api_response = api_instance.software_system_install_get(id)
        print("The response of SoftwareApi->software_system_install_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_install_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Identifier of the installation process for the specific system package version.  | 

### Return type

[**SoftwareInstallGetResponseJson**](SoftwareInstallGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Installation status. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_install_post**
> SoftwareInstallPostResponseJson software_system_install_post(software_install_post_request_json)

Install system package

Trigger the installation of the system package with the version specified in the request body. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_install_post_request_json import SoftwareInstallPostRequestJson
from anapaya.appliance.models.software_install_post_response_json import SoftwareInstallPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    software_install_post_request_json = anapaya.appliance.SoftwareInstallPostRequestJson() # SoftwareInstallPostRequestJson | 

    try:
        # Install system package
        api_response = api_instance.software_system_install_post(software_install_post_request_json)
        print("The response of SoftwareApi->software_system_install_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_install_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **software_install_post_request_json** | [**SoftwareInstallPostRequestJson**](SoftwareInstallPostRequestJson.md)|  | 

### Return type

[**SoftwareInstallPostResponseJson**](SoftwareInstallPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Package version and installation ID. |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**409** | request in conflict with current server state |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_installed_get**
> SoftwareInstalledGetResponseJson software_system_installed_get()

Get installed system version

Get the version of system package currently installed. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_installed_get_response_json import SoftwareInstalledGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)

    try:
        # Get installed system version
        api_response = api_instance.software_system_installed_get()
        print("The response of SoftwareApi->software_system_installed_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_installed_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SoftwareInstalledGetResponseJson**](SoftwareInstalledGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Installed system version. |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_package_local_cleanup_post**
> software_system_package_local_cleanup_post()

Clean up system packages

Remove all the unused system packages from the local repository.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)

    try:
        # Clean up system packages
        api_instance.software_system_package_local_cleanup_post()
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_package_local_cleanup_post: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_package_local_delete**
> SoftwarePackageDeleteResponseJson software_system_package_local_delete(version)

Delete system package

Delete the system package for the given version if it is available locally on the appliance. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_package_delete_response_json import SoftwarePackageDeleteResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    version = 'version_example' # str | Version of the system package.

    try:
        # Delete system package
        api_response = api_instance.software_system_package_local_delete(version)
        print("The response of SoftwareApi->software_system_package_local_delete:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_package_local_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**| Version of the system package. | 

### Return type

[**SoftwarePackageDeleteResponseJson**](SoftwarePackageDeleteResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Package information. |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_package_local_get**
> SoftwarePackageGetResponseJson software_system_package_local_get(version)

Get system package information

Get the package information of the system package for the given version. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_package_get_response_json import SoftwarePackageGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    version = 'version_example' # str | Version of the system package.

    try:
        # Get system package information
        api_response = api_instance.software_system_package_local_get(version)
        print("The response of SoftwareApi->software_system_package_local_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_package_local_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**| Version of the system package. | 

### Return type

[**SoftwarePackageGetResponseJson**](SoftwarePackageGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Package information. |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_packages_local_get**
> SoftwarePackagesGetResponseJson software_system_packages_local_get()

List system packages

List the package information (e.g., version) for all the system packages which are available locally on the appliance. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_packages_get_response_json import SoftwarePackagesGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)

    try:
        # List system packages
        api_response = api_instance.software_system_packages_local_get()
        print("The response of SoftwareApi->software_system_packages_local_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_packages_local_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**SoftwarePackagesGetResponseJson**](SoftwarePackagesGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **software_system_packages_local_post**
> SoftwarePackagesPostResponseJson software_system_packages_local_post(body, force=force)

Add system package

Upload the system package to the local repository of the appliance.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.software_packages_post_response_json import SoftwarePackagesPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareApi(api_client)
    body = None # bytearray | 
    force = False # bool | If force is true, the package is stored regardless of whether it already exists. (optional) (default to False)

    try:
        # Add system package
        api_response = api_instance.software_system_packages_local_post(body, force=force)
        print("The response of SoftwareApi->software_system_packages_local_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareApi->software_system_packages_local_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **bytearray**|  | 
 **force** | **bool**| If force is true, the package is stored regardless of whether it already exists. | [optional] [default to False]

### Return type

[**SoftwarePackagesPostResponseJson**](SoftwarePackagesPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Package information. |  -  |
**400** | bad request |  -  |
**409** | request in conflict with current server state |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

