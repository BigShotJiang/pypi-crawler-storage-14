# ConfigInterfacesShuttle

List of Shuttle interfaces.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disable** | **bool** | Disable the Shuttle interface. By default, it is false. If disabled, the Shuttle interface is not created and existing Shuttle interface will be removed. Disabling an existing interface preserves the corresponding certificate and private key, which can be used after re-enabling the interface. | [optional] [default to False]
**local** | **str** | Local endpoint of the Shuttle tunnel. In two alternative forms &#x60;ISD-AS,IP&#x60;, or &#x60;IP&#x60;, where &#x60;ISD-AS&#x60; is an ISD-AS number, &#x60;IP&#x60; is an IPv4/IPv6 address | [optional] 
**mtu** | **int** | The MTU (Maximum Transmission Unit) to be used on this interface. The user does not need to change this default value. The value is chosen to work in extrem circumstances. | [optional] [default to 1000]
**name** | **str** | The name of the network interface. | 
**servers** | [**List[ConfigInterfacesShuttleServer]**](ConfigInterfacesShuttleServer.md) | The list of Shuttle servers. | [optional] 

## Example

```python
from anapaya.appliance.models.config_interfaces_shuttle import ConfigInterfacesShuttle

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigInterfacesShuttle from a JSON string
config_interfaces_shuttle_instance = ConfigInterfacesShuttle.from_json(json)
# print the JSON string representation of the object
print ConfigInterfacesShuttle.to_json()

# convert the object into a dict
config_interfaces_shuttle_dict = config_interfaces_shuttle_instance.to_dict()
# create an instance of ConfigInterfacesShuttle from a dict
config_interfaces_shuttle_form_dict = config_interfaces_shuttle.from_dict(config_interfaces_shuttle_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


