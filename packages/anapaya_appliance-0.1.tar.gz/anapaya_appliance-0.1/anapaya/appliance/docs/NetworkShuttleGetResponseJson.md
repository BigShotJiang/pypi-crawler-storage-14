# NetworkShuttleGetResponseJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**status** | **str** |  | 
**subject_key_id** | **str** |  | 
**endpoint** | **str** |  | 
**certificate** | **str** |  | 
**mtu** | **int** |  | 
**addresses** | **List[str]** |  | 
**routes** | **List[str]** |  | 
**connected_server** | **str** |  | 
**servers** | **List[str]** | List of servers of which the client can connect to only one at a time. | 
**path** | [**ShuttleClientPath**](ShuttleClientPath.md) |  | 

## Example

```python
from anapaya.appliance.models.network_shuttle_get_response_json import NetworkShuttleGetResponseJson

# TODO update the JSON string below
json = "{}"
# create an instance of NetworkShuttleGetResponseJson from a JSON string
network_shuttle_get_response_json_instance = NetworkShuttleGetResponseJson.from_json(json)
# print the JSON string representation of the object
print NetworkShuttleGetResponseJson.to_json()

# convert the object into a dict
network_shuttle_get_response_json_dict = network_shuttle_get_response_json_instance.to_dict()
# create an instance of NetworkShuttleGetResponseJson from a dict
network_shuttle_get_response_json_form_dict = network_shuttle_get_response_json.from_dict(network_shuttle_get_response_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


