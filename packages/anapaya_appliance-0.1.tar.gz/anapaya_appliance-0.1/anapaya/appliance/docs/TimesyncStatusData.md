# TimesyncStatusData

The status of the timesync service on the appliance. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ntp_synchronized** | **bool** | Whether the appliance is successfully synchronizing the time with the configured NTP servers.  | [optional] 
**ntp_service_active** | **bool** |  | [optional] 
**ntp_servers** | **List[str]** |  | [optional] 
**server_name** | **str** |  | [optional] 
**server_address** | **str** |  | [optional] 
**ntp_message** | **str** |  | [optional] 

## Example

```python
from anapaya.appliance.models.timesync_status_data import TimesyncStatusData

# TODO update the JSON string below
json = "{}"
# create an instance of TimesyncStatusData from a JSON string
timesync_status_data_instance = TimesyncStatusData.from_json(json)
# print the JSON string representation of the object
print TimesyncStatusData.to_json()

# convert the object into a dict
timesync_status_data_dict = timesync_status_data_instance.to_dict()
# create an instance of TimesyncStatusData from a dict
timesync_status_data_form_dict = timesync_status_data.from_dict(timesync_status_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


