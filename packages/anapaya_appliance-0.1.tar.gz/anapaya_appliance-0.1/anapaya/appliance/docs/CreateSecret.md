# CreateSecret


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Secret IDs must refer to the version at which the new secret is stored. For example, a secret loki-password@2 can only be added if loki-password@1 exists.  | 
**value** | **str** |  | 

## Example

```python
from anapaya.appliance.models.create_secret import CreateSecret

# TODO update the JSON string below
json = "{}"
# create an instance of CreateSecret from a JSON string
create_secret_instance = CreateSecret.from_json(json)
# print the JSON string representation of the object
print CreateSecret.to_json()

# convert the object into a dict
create_secret_dict = create_secret_instance.to_dict()
# create an instance of CreateSecret from a dict
create_secret_form_dict = create_secret.from_dict(create_secret_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


