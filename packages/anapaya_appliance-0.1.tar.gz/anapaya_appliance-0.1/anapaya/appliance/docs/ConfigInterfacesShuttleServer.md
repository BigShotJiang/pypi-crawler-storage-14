# ConfigInterfacesShuttleServer

List of Shuttle server configurations.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endpoint** | **str** | Remote endpoint of the Shuttle tunnel. In the form &#x60;host:port&#x60;, where &#x60;host&#x60; is a SCION host address, in &#x60;ISD-AS,IP&#x60; format, where &#x60;ISD-AS&#x60; is the ISD-AS number and &#x60;IP&#x60; is the IPv4 address, and &#x60;port&#x60; is a port number | [optional] 

## Example

```python
from anapaya.appliance.models.config_interfaces_shuttle_server import ConfigInterfacesShuttleServer

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigInterfacesShuttleServer from a JSON string
config_interfaces_shuttle_server_instance = ConfigInterfacesShuttleServer.from_json(json)
# print the JSON string representation of the object
print ConfigInterfacesShuttleServer.to_json()

# convert the object into a dict
config_interfaces_shuttle_server_dict = config_interfaces_shuttle_server_instance.to_dict()
# create an instance of ConfigInterfacesShuttleServer from a dict
config_interfaces_shuttle_server_form_dict = config_interfaces_shuttle_server.from_dict(config_interfaces_shuttle_server_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


