# InterfaceExists

Check data for an explanation of this check. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**check_id** | **str** | The identifier of the health check type. There can be multiple instances of the same health check in the response.  See the description of the &#x60;data&#x60; field for more information on how the health check is evaluated.  | 
**name** | **str** | The human readable name of the health check type. To identify the type of health check in automated systems, use the &#x60;id&#x60; field instead.  | 
**status** | [**HealthStatus**](HealthStatus.md) |  | 
**detail** | **str** | A human readable explanation of the health check status.  | [optional] 
**data** | [**InterfaceExistsData**](InterfaceExistsData.md) |  | 

## Example

```python
from anapaya.appliance.models.interface_exists import InterfaceExists

# TODO update the JSON string below
json = "{}"
# create an instance of InterfaceExists from a JSON string
interface_exists_instance = InterfaceExists.from_json(json)
# print the JSON string representation of the object
print InterfaceExists.to_json()

# convert the object into a dict
interface_exists_dict = interface_exists_instance.to_dict()
# create an instance of InterfaceExists from a dict
interface_exists_form_dict = interface_exists.from_dict(interface_exists_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


