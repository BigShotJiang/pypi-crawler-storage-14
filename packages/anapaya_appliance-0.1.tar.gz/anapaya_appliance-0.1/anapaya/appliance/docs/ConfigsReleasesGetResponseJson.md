# ConfigsReleasesGetResponseJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**releases** | [**List[ConfigsReleaseVersionGetResponseJson]**](ConfigsReleaseVersionGetResponseJson.md) |  | 

## Example

```python
from anapaya.appliance.models.configs_releases_get_response_json import ConfigsReleasesGetResponseJson

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigsReleasesGetResponseJson from a JSON string
configs_releases_get_response_json_instance = ConfigsReleasesGetResponseJson.from_json(json)
# print the JSON string representation of the object
print ConfigsReleasesGetResponseJson.to_json()

# convert the object into a dict
configs_releases_get_response_json_dict = configs_releases_get_response_json_instance.to_dict()
# create an instance of ConfigsReleasesGetResponseJson from a dict
configs_releases_get_response_json_form_dict = configs_releases_get_response_json.from_dict(configs_releases_get_response_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


