# DomainHasReachableEncryptedRemoteData

The list of remotes in a domain with encryption enabled that are reachable. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain** | **str** | The domain the remote gateways are part of.  | 
**local_isd_as** | **str** | The local ISD-AS in the domain.  | 
**remote_gateways** | [**List[DomainRemoteGateway]**](DomainRemoteGateway.md) | The remote gateways in the domain.  | 

## Example

```python
from anapaya.appliance.models.domain_has_reachable_encrypted_remote_data import DomainHasReachableEncryptedRemoteData

# TODO update the JSON string below
json = "{}"
# create an instance of DomainHasReachableEncryptedRemoteData from a JSON string
domain_has_reachable_encrypted_remote_data_instance = DomainHasReachableEncryptedRemoteData.from_json(json)
# print the JSON string representation of the object
print DomainHasReachableEncryptedRemoteData.to_json()

# convert the object into a dict
domain_has_reachable_encrypted_remote_data_dict = domain_has_reachable_encrypted_remote_data_instance.to_dict()
# create an instance of DomainHasReachableEncryptedRemoteData from a dict
domain_has_reachable_encrypted_remote_data_form_dict = domain_has_reachable_encrypted_remote_data.from_dict(domain_has_reachable_encrypted_remote_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


