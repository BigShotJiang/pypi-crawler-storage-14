# anapaya.appliance.SoftwareSignaturesApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_keys**](SoftwareSignaturesApi.md#get_keys) | **GET** /software/keys | List public signing keys
[**get_signatures**](SoftwareSignaturesApi.md#get_signatures) | **GET** /software/signatures/{type}/{version} | Get signature
[**post_keys**](SoftwareSignaturesApi.md#post_keys) | **POST** /software/keys | Install signing keys
[**post_signatures**](SoftwareSignaturesApi.md#post_signatures) | **POST** /software/signatures/{type}/{version} | Install signatures


# **get_keys**
> Keys get_keys()

List public signing keys

Get the currently installed public signing keys. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.keys import Keys
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareSignaturesApi(api_client)

    try:
        # List public signing keys
        api_response = api_instance.get_keys()
        print("The response of SoftwareSignaturesApi->get_keys:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareSignaturesApi->get_keys: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**Keys**](Keys.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Public signing keys. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_signatures**
> Signatures get_signatures(type, version)

Get signature

Get the specified signatures.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.signatures import Signatures
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareSignaturesApi(api_client)
    type = 'type_example' # str | 
    version = 'version_example' # str | 

    try:
        # Get signature
        api_response = api_instance.get_signatures(type, version)
        print("The response of SoftwareSignaturesApi->get_signatures:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SoftwareSignaturesApi->get_signatures: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type** | **str**|  | 
 **version** | **str**|  | 

### Return type

[**Signatures**](Signatures.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Signatures. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_keys**
> post_keys(keys)

Install signing keys

Install new public signing keys. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.keys import Keys
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareSignaturesApi(api_client)
    keys = anapaya.appliance.Keys() # Keys | 

    try:
        # Install signing keys
        api_instance.post_keys(keys)
    except Exception as e:
        print("Exception when calling SoftwareSignaturesApi->post_keys: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **keys** | [**Keys**](Keys.md)|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Public signing keys. |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_signatures**
> post_signatures(type, version, signatures)

Install signatures

Install signatures.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.signatures import Signatures
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.SoftwareSignaturesApi(api_client)
    type = 'type_example' # str | 
    version = 'version_example' # str | 
    signatures = anapaya.appliance.Signatures() # Signatures | 

    try:
        # Install signatures
        api_instance.post_signatures(type, version, signatures)
    except Exception as e:
        print("Exception when calling SoftwareSignaturesApi->post_signatures: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type** | **str**|  | 
 **version** | **str**|  | 
 **signatures** | [**Signatures**](Signatures.md)|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Public signing keys. |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |
**504** | gateway timeout |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

