# ShuttleClientPath


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fingerprint** | **str** | The fingerprint of the path. | 
**human** | **str** | Human readable representation of the SCION path. | 
**hops** | [**List[Hop]**](Hop.md) | List of individual hops on the SCION path. | 
**expiration** | **datetime** | Expiry specifies until when is the path valid. | 
**source** | **str** |  | 
**destination** | **str** |  | 

## Example

```python
from anapaya.appliance.models.shuttle_client_path import ShuttleClientPath

# TODO update the JSON string below
json = "{}"
# create an instance of ShuttleClientPath from a JSON string
shuttle_client_path_instance = ShuttleClientPath.from_json(json)
# print the JSON string representation of the object
print ShuttleClientPath.to_json()

# convert the object into a dict
shuttle_client_path_dict = shuttle_client_path_instance.to_dict()
# create an instance of ShuttleClientPath from a dict
shuttle_client_path_form_dict = shuttle_client_path.from_dict(shuttle_client_path_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


