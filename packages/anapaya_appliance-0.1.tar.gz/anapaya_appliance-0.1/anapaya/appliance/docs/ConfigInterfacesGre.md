# ConfigInterfacesGre

List of GRE tunnels.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accept_ra** | **bool** | Whether to accept the route advertisements for the corresponding interface. (This is currently supported only for the interfaces that are using the Linux driver.) | [optional] [default to False]
**addresses** | **List[str]** | The addresses configured on this interface. Each address must be a valid IP prefix in CIDR notation. | [optional] 
**destination** | **str** | The destination IP address for the GRE tunnel. | 
**gateway** | [**ConfigInterfacesGreGateway**](ConfigInterfacesGreGateway.md) |  | [optional] 
**mac** | **str** | The MAC address to use on this interface. It is of the form &#x60;XX:XX:XX:XX:XX:XX&#x60;. | [optional] 
**mtu** | **int** | The MTU (Maximum Transmission Unit) to be used on this interface. | [optional] [default to 1500]
**name** | **str** | The name of the network interface. | 
**neighbors** | [**List[ConfigInterfacesGreNeighbor]**](ConfigInterfacesGreNeighbor.md) | The static neighbors configured on this network interface. | [optional] 
**routes** | [**List[ConfigInterfacesGreRoute]**](ConfigInterfacesGreRoute.md) | The routes which are configured on this network interface. | [optional] 
**rx_queue_size** | **int** | The number of descriptors in the receive queue. (This option is currently supported only for VPP interfaces.) | [optional] [default to 1024]
**source** | **str** | The source IP address for the GRE tunnel. | 
**tx_queue_size** | **int** | The number of descriptors in the transmit queue. (This is currently supported only for VPP interfaces.) | [optional] [default to 1024]
**vrrp** | [**List[ConfigInterfacesGreVrrp]**](ConfigInterfacesGreVrrp.md) | The VRRP (Virtual Router Redundancy Protocol) configurations for this interface. | [optional] 

## Example

```python
from anapaya.appliance.models.config_interfaces_gre import ConfigInterfacesGre

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigInterfacesGre from a JSON string
config_interfaces_gre_instance = ConfigInterfacesGre.from_json(json)
# print the JSON string representation of the object
print ConfigInterfacesGre.to_json()

# convert the object into a dict
config_interfaces_gre_dict = config_interfaces_gre_instance.to_dict()
# create an instance of ConfigInterfacesGre from a dict
config_interfaces_gre_form_dict = config_interfaces_gre.from_dict(config_interfaces_gre_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


