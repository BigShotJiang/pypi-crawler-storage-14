# DomainEncryptionModeAppropriateData

Encryption on a domain should usually either be enabled or disabled. During a transition phase, it is possible to enable optional encryption. This should only be a temporary state, and the domain should eventually run with encryption enabled. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain** | **str** | The name of the routing domain.  | 
**encryption** | [**EncryptionMode**](EncryptionMode.md) |  | 

## Example

```python
from anapaya.appliance.models.domain_encryption_mode_appropriate_data import DomainEncryptionModeAppropriateData

# TODO update the JSON string below
json = "{}"
# create an instance of DomainEncryptionModeAppropriateData from a JSON string
domain_encryption_mode_appropriate_data_instance = DomainEncryptionModeAppropriateData.from_json(json)
# print the JSON string representation of the object
print DomainEncryptionModeAppropriateData.to_json()

# convert the object into a dict
domain_encryption_mode_appropriate_data_dict = domain_encryption_mode_appropriate_data_instance.to_dict()
# create an instance of DomainEncryptionModeAppropriateData from a dict
domain_encryption_mode_appropriate_data_form_dict = domain_encryption_mode_appropriate_data.from_dict(domain_encryption_mode_appropriate_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


