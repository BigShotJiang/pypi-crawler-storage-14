# NetworkShuttleServerClientJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subject_key_id** | **str** |  | 
**endpoint** | **str** |  | 
**status** | **str** |  | 
**addresses** | **List[str]** |  | 
**routes** | **List[str]** |  | 
**path** | [**ShuttleServerPath**](ShuttleServerPath.md) |  | 

## Example

```python
from anapaya.appliance.models.network_shuttle_server_client_json import NetworkShuttleServerClientJson

# TODO update the JSON string below
json = "{}"
# create an instance of NetworkShuttleServerClientJson from a JSON string
network_shuttle_server_client_json_instance = NetworkShuttleServerClientJson.from_json(json)
# print the JSON string representation of the object
print NetworkShuttleServerClientJson.to_json()

# convert the object into a dict
network_shuttle_server_client_json_dict = network_shuttle_server_client_json_instance.to_dict()
# create an instance of NetworkShuttleServerClientJson from a dict
network_shuttle_server_client_json_form_dict = network_shuttle_server_client_json.from_dict(network_shuttle_server_client_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


