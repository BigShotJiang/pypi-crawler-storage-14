# SecretsPostRequestJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secret** | [**CreateSecret**](CreateSecret.md) |  | 

## Example

```python
from anapaya.appliance.models.secrets_post_request_json import SecretsPostRequestJson

# TODO update the JSON string below
json = "{}"
# create an instance of SecretsPostRequestJson from a JSON string
secrets_post_request_json_instance = SecretsPostRequestJson.from_json(json)
# print the JSON string representation of the object
print SecretsPostRequestJson.to_json()

# convert the object into a dict
secrets_post_request_json_dict = secrets_post_request_json_instance.to_dict()
# create an instance of SecretsPostRequestJson from a dict
secrets_post_request_json_form_dict = secrets_post_request_json.from_dict(secrets_post_request_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


