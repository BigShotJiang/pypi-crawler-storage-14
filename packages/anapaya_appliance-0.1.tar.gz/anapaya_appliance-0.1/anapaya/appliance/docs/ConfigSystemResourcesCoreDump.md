# ConfigSystemResourcesCoreDump

Configuration for core dumps.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keep** | **int** | The number of core dumps to keep. The appliance periodically deletes the least recent core dumps until this number is met. | [optional] [default to 3]

## Example

```python
from anapaya.appliance.models.config_system_resources_core_dump import ConfigSystemResourcesCoreDump

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigSystemResourcesCoreDump from a JSON string
config_system_resources_core_dump_instance = ConfigSystemResourcesCoreDump.from_json(json)
# print the JSON string representation of the object
print ConfigSystemResourcesCoreDump.to_json()

# convert the object into a dict
config_system_resources_core_dump_dict = config_system_resources_core_dump_instance.to_dict()
# create an instance of ConfigSystemResourcesCoreDump from a dict
config_system_resources_core_dump_form_dict = config_system_resources_core_dump.from_dict(config_system_resources_core_dump_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


