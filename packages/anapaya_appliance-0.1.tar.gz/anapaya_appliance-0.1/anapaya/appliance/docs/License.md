# License

Only present if there is a license on the appliance. If there are multiple licenses it contains the details regarding the license that is currently viewed as active by the appliance. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The license ID. | 
**type** | [**LicenseType**](LicenseType.md) |  | 
**issued** | **datetime** | The date and time when the license was issued. | 
**validity** | [**LicenseValidity**](LicenseValidity.md) |  | 

## Example

```python
from anapaya.appliance.models.license import License

# TODO update the JSON string below
json = "{}"
# create an instance of License from a JSON string
license_instance = License.from_json(json)
# print the JSON string representation of the object
print License.to_json()

# convert the object into a dict
license_dict = license_instance.to_dict()
# create an instance of License from a dict
license_form_dict = license.from_dict(license_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


