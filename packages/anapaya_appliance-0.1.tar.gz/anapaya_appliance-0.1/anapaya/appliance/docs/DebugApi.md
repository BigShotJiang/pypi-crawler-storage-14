# anapaya.appliance.DebugApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**debug_bgp_config_get**](DebugApi.md#debug_bgp_config_get) | **GET** /debug/bgp/config | Get BGP configuration
[**debug_bgp_neighbors_get**](DebugApi.md#debug_bgp_neighbors_get) | **GET** /debug/bgp/neighbors | Get BGP neighbors state
[**debug_cluster_status_get**](DebugApi.md#debug_cluster_status_get) | **GET** /debug/cluster/status | Get cluster status
[**debug_lan_monitoring_get**](DebugApi.md#debug_lan_monitoring_get) | **GET** /debug/lan-monitoring | Get LAN statistics
[**debug_logs_entries_get**](DebugApi.md#debug_logs_entries_get) | **GET** /debug/logs/entries | Retrieve logs via systemd-journal-gatewayd compatible interface
[**debug_network_interfaces_get**](DebugApi.md#debug_network_interfaces_get) | **GET** /debug/network/interfaces | List network interfaces
[**debug_network_planner_graph_get**](DebugApi.md#debug_network_planner_graph_get) | **GET** /debug/network/planner/graph | Get graph of dataplane-control planner nodes
[**debug_network_routes_get**](DebugApi.md#debug_network_routes_get) | **GET** /debug/network/routes | List network routes
[**debug_notifications_get**](DebugApi.md#debug_notifications_get) | **GET** /debug/notifications | Get periodic appliance-controller notification status
[**debug_notifications_post**](DebugApi.md#debug_notifications_post) | **POST** /debug/notifications | Trigger appliance-controller notification
[**debug_notifications_put**](DebugApi.md#debug_notifications_put) | **PUT** /debug/notifications | Enable/disable periodic appliance-controller notifications
[**debug_scion_interfaces_get**](DebugApi.md#debug_scion_interfaces_get) | **GET** /debug/scion/interfaces | List SCION interfaces
[**debug_scion_tunneling_discovery_announcements_get**](DebugApi.md#debug_scion_tunneling_discovery_announcements_get) | **GET** /debug/scion-tunneling/discovery/announcements | List announced IP-in-SCION tunneling endpoints
[**debug_scion_tunneling_discovery_get**](DebugApi.md#debug_scion_tunneling_discovery_get) | **GET** /debug/scion-tunneling/discovery | List IP-in-SCION tunneling peers
[**debug_scion_tunneling_domains_config_get**](DebugApi.md#debug_scion_tunneling_domains_config_get) | **GET** /debug/scion-tunneling/domains/config | Get IP-in-SCION tunneling domains configuration
[**debug_scion_tunneling_paths_get**](DebugApi.md#debug_scion_tunneling_paths_get) | **GET** /debug/scion-tunneling/paths | List IP-in-SCION tunneling paths
[**debug_scion_tunneling_paths_search_post**](DebugApi.md#debug_scion_tunneling_paths_search_post) | **POST** /debug/scion-tunneling/paths/search | Search IP-in-SCION tunneling paths
[**debug_scion_tunneling_planner_graph_get**](DebugApi.md#debug_scion_tunneling_planner_graph_get) | **GET** /debug/scion-tunneling/planner/graph | The graph of the planner nodes and dependencies.
[**debug_scion_tunneling_sa_reset_post**](DebugApi.md#debug_scion_tunneling_sa_reset_post) | **POST** /debug/scion-tunneling/sa/reset | Reset the SAs of the SCION tunnels.
[**debug_scion_tunneling_sgrp_announcements_get**](DebugApi.md#debug_scion_tunneling_sgrp_announcements_get) | **GET** /debug/scion-tunneling/sgrp/announcements | List IP-in-SCION tunneling announced prefixes
[**debug_scion_tunneling_sgrp_domains_get**](DebugApi.md#debug_scion_tunneling_sgrp_domains_get) | **GET** /debug/scion-tunneling/sgrp/domains | List IP-in-SCION tunneling SGRP domains
[**debug_scion_tunneling_sgrp_local_prefixes_get**](DebugApi.md#debug_scion_tunneling_sgrp_local_prefixes_get) | **GET** /debug/scion-tunneling/sgrp/local-prefixes | List IP-in-SCION tunneling local prefixes
[**debug_scion_tunneling_sgrp_peers_get**](DebugApi.md#debug_scion_tunneling_sgrp_peers_get) | **GET** /debug/scion-tunneling/sgrp/peers | List IP-in-SCION tunneling SGRP peers
[**debug_scion_tunneling_state_current_get**](DebugApi.md#debug_scion_tunneling_state_current_get) | **GET** /debug/scion-tunneling/state/current | Get IP-in-SCION tunneling state
[**debug_scion_tunneling_state_domains_get**](DebugApi.md#debug_scion_tunneling_state_domains_get) | **GET** /debug/scion-tunneling/state/domains | Get IP-in-SCION tunneling domain configuration
[**debug_scion_tunneling_state_fastpath_get**](DebugApi.md#debug_scion_tunneling_state_fastpath_get) | **GET** /debug/scion-tunneling/state/fastpath | Get IP-in-SCION tunneling fastpath state
[**debug_scion_tunneling_state_monitored_get**](DebugApi.md#debug_scion_tunneling_state_monitored_get) | **GET** /debug/scion-tunneling/state/monitored | Get IP-in-SCION tunneling monitored state
[**debug_scion_tunneling_state_observability_get**](DebugApi.md#debug_scion_tunneling_state_observability_get) | **GET** /debug/scion-tunneling/state/observability | Get IP-in-SCION tunneling observability data
[**debug_scion_tunneling_summary_get**](DebugApi.md#debug_scion_tunneling_summary_get) | **GET** /debug/scion-tunneling/summary | Get IP-in-SCION tunneling summary
[**debug_service_groups_restart_post**](DebugApi.md#debug_service_groups_restart_post) | **POST** /debug/service-groups/{group_name}/restart | Restart group of services
[**debug_services_get**](DebugApi.md#debug_services_get) | **GET** /debug/services | List services and service groups
[**debug_services_health**](DebugApi.md#debug_services_health) | **GET** /debug/services/{service_name}/health | Indicate service health
[**debug_services_health_summary**](DebugApi.md#debug_services_health_summary) | **GET** /debug/service-health | Get service health
[**debug_services_restart**](DebugApi.md#debug_services_restart) | **POST** /debug/services/{service_name}/restart | Restart service


# **debug_bgp_config_get**
> BGPResponseJson debug_bgp_config_get()

Get BGP configuration

Get the BGP configuration of the host.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.bgp_response_json import BGPResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get BGP configuration
        api_response = api_instance.debug_bgp_config_get()
        print("The response of DebugApi->debug_bgp_config_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_bgp_config_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**BGPResponseJson**](BGPResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | BGP configuration. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_bgp_neighbors_get**
> BGPNeighborsResponseJson debug_bgp_neighbors_get()

Get BGP neighbors state

Get the state of the BGP neighbors.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.bgp_neighbors_response_json import BGPNeighborsResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get BGP neighbors state
        api_response = api_instance.debug_bgp_neighbors_get()
        print("The response of DebugApi->debug_bgp_neighbors_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_bgp_neighbors_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**BGPNeighborsResponseJson**](BGPNeighborsResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | BGP neighbor state. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_cluster_status_get**
> DebugClusterStatus debug_cluster_status_get()

Get cluster status

Get the status of the cluster. The status includes for each peer the name, the address, the time of the last synchronization, the status of said synchronization, and if the attempt failed the reason for the failure. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.debug_cluster_status import DebugClusterStatus
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get cluster status
        api_response = api_instance.debug_cluster_status_get()
        print("The response of DebugApi->debug_cluster_status_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_cluster_status_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**DebugClusterStatus**](DebugClusterStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The cluster status. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_lan_monitoring_get**
> LanStats debug_lan_monitoring_get()

Get LAN statistics

Returns statistics about the LAN. Specifically it provides metrics for IP-in-SCION tunneling endpoints. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.lan_stats import LanStats
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get LAN statistics
        api_response = api_instance.debug_lan_monitoring_get()
        print("The response of DebugApi->debug_lan_monitoring_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_lan_monitoring_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**LanStats**](LanStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | LAN statistics |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_logs_entries_get**
> debug_logs_entries_get(range=range, accept=accept)

Retrieve logs via systemd-journal-gatewayd compatible interface

Endpoint that implemenets the interface exposed via the /entries endpoint of the systemd-journal-gatewayd service. By default, all systemd-journal logs are exposed.  See also: https://www.freedesktop.org/software/systemd/man/latest/systemd-journal-gatewayd.service.html 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    range = 'range_example' # str | The range of requested log entries. See systemd-journal-gatewayd documentation. (optional)
    accept = 'accept_example' # str | The format of the log entries (default is text). (optional)

    try:
        # Retrieve logs via systemd-journal-gatewayd compatible interface
        api_instance.debug_logs_entries_get(range=range, accept=accept)
    except Exception as e:
        print("Exception when calling DebugApi->debug_logs_entries_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **range** | **str**| The range of requested log entries. See systemd-journal-gatewayd documentation. | [optional] 
 **accept** | **str**| The format of the log entries (default is text). | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Journald entries |  -  |
**400** | Malformed request parameters. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_network_interfaces_get**
> NetworkInterfaces debug_network_interfaces_get(interface_name=interface_name)

List network interfaces

Network interfaces summary.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_interfaces import NetworkInterfaces
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    interface_name = 'interface_name_example' # str |  (optional)

    try:
        # List network interfaces
        api_response = api_instance.debug_network_interfaces_get(interface_name=interface_name)
        print("The response of DebugApi->debug_network_interfaces_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_network_interfaces_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **interface_name** | **str**|  | [optional] 

### Return type

[**NetworkInterfaces**](NetworkInterfaces.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Network interfaces. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_network_planner_graph_get**
> str debug_network_planner_graph_get()

Get graph of dataplane-control planner nodes

The graph of planner nodes. The graph is in dot format and can be rendered by graphviz, or one of the online dot-rendering tools. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get graph of dataplane-control planner nodes
        api_response = api_instance.debug_network_planner_graph_get()
        print("The response of DebugApi->debug_network_planner_graph_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_network_planner_graph_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The planner graph. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_network_routes_get**
> NetworkRoutes debug_network_routes_get(ip=ip)

List network routes

Network routes summary.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.network_routes import NetworkRoutes
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    ip = 'ip_example' # str |  (optional)

    try:
        # List network routes
        api_response = api_instance.debug_network_routes_get(ip=ip)
        print("The response of DebugApi->debug_network_routes_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_network_routes_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ip** | **str**|  | [optional] 

### Return type

[**NetworkRoutes**](NetworkRoutes.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Network routes. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_notifications_get**
> DebugNotifyStatusJson debug_notifications_get()

Get periodic appliance-controller notification status

Check if the controller notifications are enabled or not. For context: If notifications are enabled, the appliance-controller periodically sends notifications with the latest configuration, which eventually overwrites any manual changes. By default, the controller notifications should be enabled. However, in the case of manual troubleshooting, it may be convenient to temporarily disable the controller notifications. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.debug_notify_status_json import DebugNotifyStatusJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get periodic appliance-controller notification status
        api_response = api_instance.debug_notifications_get()
        print("The response of DebugApi->debug_notifications_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_notifications_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**DebugNotifyStatusJson**](DebugNotifyStatusJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Get the status of appliance-controller notifications |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_notifications_post**
> debug_notifications_post()

Trigger appliance-controller notification

Triggering a notification will re-apply the lastest stored configuration. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Trigger appliance-controller notification
        api_instance.debug_notifications_post()
    except Exception as e:
        print("Exception when calling DebugApi->debug_notifications_post: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The notification was triggered |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_notifications_put**
> DebugNotifyStatusJson debug_notifications_put(debug_notify_status_json)

Enable/disable periodic appliance-controller notifications

Enable or disable the appliance-controller notifications. Optionally, a deadline can be provided, either as absolute time or as a relative duration. The deadline indicates until when the appliance-controller notifications should be disabled. If both absolute and relative times are given, the minimum is taken. For context: If notifications are enabled (default), the appliance-controller periodically sends notifications with the latest configuration, which overwrites any manual changes. Note that disabling notifications should only happen when debugging the configuration of the host. It should not be treated as a permanent solution to configuration changes, meaning that eventually the appliance-controller notifications should be re-enabled. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.debug_notify_status_json import DebugNotifyStatusJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    debug_notify_status_json = anapaya.appliance.DebugNotifyStatusJson() # DebugNotifyStatusJson | 

    try:
        # Enable/disable periodic appliance-controller notifications
        api_response = api_instance.debug_notifications_put(debug_notify_status_json)
        print("The response of DebugApi->debug_notifications_put:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_notifications_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **debug_notify_status_json** | [**DebugNotifyStatusJson**](DebugNotifyStatusJson.md)|  | 

### Return type

[**DebugNotifyStatusJson**](DebugNotifyStatusJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Status of appliance-controller notifications |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_interfaces_get**
> DebugScionInterfaces debug_scion_interfaces_get(local_isd_as=local_isd_as, remote_isd_as=remote_isd_as, interface_id=interface_id)

List SCION interfaces

Get a list of all the SCION interfaces configured on the host. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.debug_scion_interfaces import DebugScionInterfaces
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    local_isd_as = 'local_isd_as_example' # str |  (optional)
    remote_isd_as = 'remote_isd_as_example' # str |  (optional)
    interface_id = 56 # int |  (optional)

    try:
        # List SCION interfaces
        api_response = api_instance.debug_scion_interfaces_get(local_isd_as=local_isd_as, remote_isd_as=remote_isd_as, interface_id=interface_id)
        print("The response of DebugApi->debug_scion_interfaces_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_interfaces_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **local_isd_as** | **str**|  | [optional] 
 **remote_isd_as** | **str**|  | [optional] 
 **interface_id** | **int**|  | [optional] 

### Return type

[**DebugScionInterfaces**](DebugScionInterfaces.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | List of SCION interfaces. |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_discovery_announcements_get**
> object debug_scion_tunneling_discovery_announcements_get()

List announced IP-in-SCION tunneling endpoints

For each local ISD-AS this endpoints lists what IP-in-SCION tunneling endpoints are announced by the Appliance to remote ISD-ASes when they do discovery.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # List announced IP-in-SCION tunneling endpoints
        api_response = api_instance.debug_scion_tunneling_discovery_announcements_get()
        print("The response of DebugApi->debug_scion_tunneling_discovery_announcements_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_discovery_announcements_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Discovery announcements. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_discovery_get**
> ScionTunnelingDiscovery debug_scion_tunneling_discovery_get()

List IP-in-SCION tunneling peers

Lists the current remote IP-in-SCION endpoint discovery sessions and their results.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_discovery import ScionTunnelingDiscovery
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # List IP-in-SCION tunneling peers
        api_response = api_instance.debug_scion_tunneling_discovery_get()
        print("The response of DebugApi->debug_scion_tunneling_discovery_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_discovery_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**ScionTunnelingDiscovery**](ScionTunnelingDiscovery.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Tunneling peers discovery. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_domains_config_get**
> ScionTunnelingDomainsResponseJson debug_scion_tunneling_domains_config_get(domain=domain)

Get IP-in-SCION tunneling domains configuration

Get the SCION tunneling domains configuration. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_domains_response_json import ScionTunnelingDomainsResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    domain = 'domain_example' # str |  (optional)

    try:
        # Get IP-in-SCION tunneling domains configuration
        api_response = api_instance.debug_scion_tunneling_domains_config_get(domain=domain)
        print("The response of DebugApi->debug_scion_tunneling_domains_config_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_domains_config_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**|  | [optional] 

### Return type

[**ScionTunnelingDomainsResponseJson**](ScionTunnelingDomainsResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | SCION tunneling domains configuration. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_paths_get**
> ScionTunnelingPathsSearchResponseJson debug_scion_tunneling_paths_get()

List IP-in-SCION tunneling paths

Returns a list of all SCION paths and their stats.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_paths_search_response_json import ScionTunnelingPathsSearchResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # List IP-in-SCION tunneling paths
        api_response = api_instance.debug_scion_tunneling_paths_get()
        print("The response of DebugApi->debug_scion_tunneling_paths_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_paths_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**ScionTunnelingPathsSearchResponseJson**](ScionTunnelingPathsSearchResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | List of all SCION paths and their stats. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_paths_search_post**
> ScionTunnelingPathsSearchResponseJson debug_scion_tunneling_paths_search_post(scion_tunneling_paths_search_post_request_json=scion_tunneling_paths_search_post_request_json)

Search IP-in-SCION tunneling paths

Returns a list of all SCION paths and their stats filtered by the fingerprints provided in the request body.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_paths_search_post_request_json import ScionTunnelingPathsSearchPostRequestJson
from anapaya.appliance.models.scion_tunneling_paths_search_response_json import ScionTunnelingPathsSearchResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    scion_tunneling_paths_search_post_request_json = anapaya.appliance.ScionTunnelingPathsSearchPostRequestJson() # ScionTunnelingPathsSearchPostRequestJson |  (optional)

    try:
        # Search IP-in-SCION tunneling paths
        api_response = api_instance.debug_scion_tunneling_paths_search_post(scion_tunneling_paths_search_post_request_json=scion_tunneling_paths_search_post_request_json)
        print("The response of DebugApi->debug_scion_tunneling_paths_search_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_paths_search_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scion_tunneling_paths_search_post_request_json** | [**ScionTunnelingPathsSearchPostRequestJson**](ScionTunnelingPathsSearchPostRequestJson.md)|  | [optional] 

### Return type

[**ScionTunnelingPathsSearchResponseJson**](ScionTunnelingPathsSearchResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | List of all SCION paths and their stats filtered by the fingerprints provided in the request body.. |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_planner_graph_get**
> str debug_scion_tunneling_planner_graph_get()

The graph of the planner nodes and dependencies.

The graph of the planner nodes and dependencies. The graph is in the dot format and can be rendered by graphviz, or one of the online dot-rendering tools. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # The graph of the planner nodes and dependencies.
        api_response = api_instance.debug_scion_tunneling_planner_graph_get()
        print("The response of DebugApi->debug_scion_tunneling_planner_graph_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_planner_graph_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The planner graph. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_sa_reset_post**
> debug_scion_tunneling_sa_reset_post()

Reset the SAs of the SCION tunnels.

Reset the SAs of the SCION tunnels.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Reset the SAs of the SCION tunnels.
        api_instance.debug_scion_tunneling_sa_reset_post()
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_sa_reset_post: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successfully reset the SAs of the SCION tunnels. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_sgrp_announcements_get**
> ScionTunnelingSGRPAnnouncements debug_scion_tunneling_sgrp_announcements_get(local_isd_as=local_isd_as, remote_isd_as=remote_isd_as)

List IP-in-SCION tunneling announced prefixes

Prefixes announced to a given remote AS per local AS.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_sgrp_announcements import ScionTunnelingSGRPAnnouncements
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    local_isd_as = 'local_isd_as_example' # str |  (optional)
    remote_isd_as = 'remote_isd_as_example' # str |  (optional)

    try:
        # List IP-in-SCION tunneling announced prefixes
        api_response = api_instance.debug_scion_tunneling_sgrp_announcements_get(local_isd_as=local_isd_as, remote_isd_as=remote_isd_as)
        print("The response of DebugApi->debug_scion_tunneling_sgrp_announcements_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_sgrp_announcements_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **local_isd_as** | **str**|  | [optional] 
 **remote_isd_as** | **str**|  | [optional] 

### Return type

[**ScionTunnelingSGRPAnnouncements**](ScionTunnelingSGRPAnnouncements.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | SGRP announcements. |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_sgrp_domains_get**
> ScionTunnelingSGRPDomains debug_scion_tunneling_sgrp_domains_get(domain=domain)

List IP-in-SCION tunneling SGRP domains

SGRP domains with the associated network prefixes.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_sgrp_domains import ScionTunnelingSGRPDomains
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    domain = 'domain_example' # str |  (optional)

    try:
        # List IP-in-SCION tunneling SGRP domains
        api_response = api_instance.debug_scion_tunneling_sgrp_domains_get(domain=domain)
        print("The response of DebugApi->debug_scion_tunneling_sgrp_domains_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_sgrp_domains_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**|  | [optional] 

### Return type

[**ScionTunnelingSGRPDomains**](ScionTunnelingSGRPDomains.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | SGRP domains. |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_sgrp_local_prefixes_get**
> ScionTunnelingSGRPLocalPrefixesJSON debug_scion_tunneling_sgrp_local_prefixes_get()

List IP-in-SCION tunneling local prefixes

Known local network prefixes, including their source. These are afterwards filtered according to domain definitions and eventually sent to SGRP peers. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_sgrp_local_prefixes_json import ScionTunnelingSGRPLocalPrefixesJSON
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # List IP-in-SCION tunneling local prefixes
        api_response = api_instance.debug_scion_tunneling_sgrp_local_prefixes_get()
        print("The response of DebugApi->debug_scion_tunneling_sgrp_local_prefixes_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_sgrp_local_prefixes_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**ScionTunnelingSGRPLocalPrefixesJSON**](ScionTunnelingSGRPLocalPrefixesJSON.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Known local network prefixes. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_sgrp_peers_get**
> ScionTunnelingSGRPPeers debug_scion_tunneling_sgrp_peers_get(local_isd_as=local_isd_as, remote_isd_as=remote_isd_as)

List IP-in-SCION tunneling SGRP peers

SGRP peers. Peer is a remote SGRP-capable application accessed from a specific local ISD-AS. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_sgrp_peers import ScionTunnelingSGRPPeers
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    local_isd_as = 'local_isd_as_example' # str |  (optional)
    remote_isd_as = 'remote_isd_as_example' # str |  (optional)

    try:
        # List IP-in-SCION tunneling SGRP peers
        api_response = api_instance.debug_scion_tunneling_sgrp_peers_get(local_isd_as=local_isd_as, remote_isd_as=remote_isd_as)
        print("The response of DebugApi->debug_scion_tunneling_sgrp_peers_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_sgrp_peers_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **local_isd_as** | **str**|  | [optional] 
 **remote_isd_as** | **str**|  | [optional] 

### Return type

[**ScionTunnelingSGRPPeers**](ScionTunnelingSGRPPeers.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | SGRP peers. |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_state_current_get**
> object debug_scion_tunneling_state_current_get()

Get IP-in-SCION tunneling state

The full current state of the gateway.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get IP-in-SCION tunneling state
        api_response = api_instance.debug_scion_tunneling_state_current_get()
        print("The response of DebugApi->debug_scion_tunneling_state_current_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_state_current_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The full current state of the gateway. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_state_domains_get**
> object debug_scion_tunneling_state_domains_get()

Get IP-in-SCION tunneling domain configuration

The user-provided domain configuration.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get IP-in-SCION tunneling domain configuration
        api_response = api_instance.debug_scion_tunneling_state_domains_get()
        print("The response of DebugApi->debug_scion_tunneling_state_domains_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_state_domains_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The user-provided domain configuration. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_state_fastpath_get**
> object debug_scion_tunneling_state_fastpath_get()

Get IP-in-SCION tunneling fastpath state

The current state of the fastpath.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get IP-in-SCION tunneling fastpath state
        api_response = api_instance.debug_scion_tunneling_state_fastpath_get()
        print("The response of DebugApi->debug_scion_tunneling_state_fastpath_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_state_fastpath_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The current state of the fastpath. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_state_monitored_get**
> object debug_scion_tunneling_state_monitored_get()

Get IP-in-SCION tunneling monitored state

The state monitored by the gateway.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get IP-in-SCION tunneling monitored state
        api_response = api_instance.debug_scion_tunneling_state_monitored_get()
        print("The response of DebugApi->debug_scion_tunneling_state_monitored_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_state_monitored_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The state monitored by the gateway. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_state_observability_get**
> object debug_scion_tunneling_state_observability_get(filter=filter)

Get IP-in-SCION tunneling observability data

The full dump of observability data.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    filter = ['filter_example'] # List[str] | A list of subsections to return, separated by commas. If empty, all subsections are returned.  (optional)

    try:
        # Get IP-in-SCION tunneling observability data
        api_response = api_instance.debug_scion_tunneling_state_observability_get(filter=filter)
        print("The response of DebugApi->debug_scion_tunneling_state_observability_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_state_observability_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filter** | [**List[str]**](str.md)| A list of subsections to return, separated by commas. If empty, all subsections are returned.  | [optional] 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The full dump of observability data. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_scion_tunneling_summary_get**
> ScionTunnelingSummary debug_scion_tunneling_summary_get()

Get IP-in-SCION tunneling summary

Get summary of the SCION tunneling infrastructure. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.scion_tunneling_summary import ScionTunnelingSummary
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get IP-in-SCION tunneling summary
        api_response = api_instance.debug_scion_tunneling_summary_get()
        print("The response of DebugApi->debug_scion_tunneling_summary_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_scion_tunneling_summary_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**ScionTunnelingSummary**](ScionTunnelingSummary.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | SCION tunneling infrastructure summary |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_service_groups_restart_post**
> DebugServiceGroupsRestartResponseJson debug_service_groups_restart_post(group_name)

Restart group of services

Trigger restart of all the services in a group.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.debug_service_groups_restart_response_json import DebugServiceGroupsRestartResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    group_name = 'group_name_example' # str | Name of the service groups to restart.

    try:
        # Restart group of services
        api_response = api_instance.debug_service_groups_restart_post(group_name)
        print("The response of DebugApi->debug_service_groups_restart_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_service_groups_restart_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_name** | **str**| Name of the service groups to restart. | 

### Return type

[**DebugServiceGroupsRestartResponseJson**](DebugServiceGroupsRestartResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_services_get**
> DebugServicesResponseJson debug_services_get()

List services and service groups

Get the list of services and service groups that must be running on the appliance.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.debug_services_response_json import DebugServicesResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # List services and service groups
        api_response = api_instance.debug_services_get()
        print("The response of DebugApi->debug_services_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_services_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**DebugServicesResponseJson**](DebugServicesResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The list of services and groups. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_services_health**
> HealthResponse debug_services_health(service_name)

Indicate service health

Present the health of the service along with the executed health checks.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.health_response import HealthResponse
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    service_name = 'service_name_example' # str | Name of the service to get health of.

    try:
        # Indicate service health
        api_response = api_instance.debug_services_health(service_name)
        print("The response of DebugApi->debug_services_health:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_services_health: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service_name** | **str**| Name of the service to get health of. | 

### Return type

[**HealthResponse**](HealthResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Service health information. |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_services_health_summary**
> HealthSummaryResponse debug_services_health_summary()

Get service health

Present the health of all the services along with the executed health checks. Deprecated: Use the `/health` endpoint instead.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.health_summary_response import HealthSummaryResponse
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)

    try:
        # Get service health
        api_response = api_instance.debug_services_health_summary()
        print("The response of DebugApi->debug_services_health_summary:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_services_health_summary: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**HealthSummaryResponse**](HealthSummaryResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Service health information. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **debug_services_restart**
> object debug_services_restart(service_name)

Restart service

Restarts the given service.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.DebugApi(api_client)
    service_name = 'service_name_example' # str | Name of the service to restart.

    try:
        # Restart service
        api_response = api_instance.debug_services_restart(service_name)
        print("The response of DebugApi->debug_services_restart:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DebugApi->debug_services_restart: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service_name** | **str**| Name of the service to restart. | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful restart |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

