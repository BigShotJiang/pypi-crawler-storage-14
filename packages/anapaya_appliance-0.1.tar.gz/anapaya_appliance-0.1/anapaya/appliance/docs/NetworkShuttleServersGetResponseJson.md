# NetworkShuttleServersGetResponseJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shuttle_servers** | [**List[NetworkShuttleServerGetResponseJson]**](NetworkShuttleServerGetResponseJson.md) |  | 

## Example

```python
from anapaya.appliance.models.network_shuttle_servers_get_response_json import NetworkShuttleServersGetResponseJson

# TODO update the JSON string below
json = "{}"
# create an instance of NetworkShuttleServersGetResponseJson from a JSON string
network_shuttle_servers_get_response_json_instance = NetworkShuttleServersGetResponseJson.from_json(json)
# print the JSON string representation of the object
print NetworkShuttleServersGetResponseJson.to_json()

# convert the object into a dict
network_shuttle_servers_get_response_json_dict = network_shuttle_servers_get_response_json_instance.to_dict()
# create an instance of NetworkShuttleServersGetResponseJson from a dict
network_shuttle_servers_get_response_json_form_dict = network_shuttle_servers_get_response_json.from_dict(network_shuttle_servers_get_response_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


