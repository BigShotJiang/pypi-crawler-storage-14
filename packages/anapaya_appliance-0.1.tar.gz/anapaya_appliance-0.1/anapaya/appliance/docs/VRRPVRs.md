# VRRPVRs


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vrs** | [**List[VRRPVR]**](VRRPVR.md) |  | 

## Example

```python
from anapaya.appliance.models.vrrpvrs import VRRPVRs

# TODO update the JSON string below
json = "{}"
# create an instance of VRRPVRs from a JSON string
vrrpvrs_instance = VRRPVRs.from_json(json)
# print the JSON string representation of the object
print VRRPVRs.to_json()

# convert the object into a dict
vrrpvrs_dict = vrrpvrs_instance.to_dict()
# create an instance of VRRPVRs from a dict
vrrpvrs_form_dict = vrrpvrs.from_dict(vrrpvrs_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


