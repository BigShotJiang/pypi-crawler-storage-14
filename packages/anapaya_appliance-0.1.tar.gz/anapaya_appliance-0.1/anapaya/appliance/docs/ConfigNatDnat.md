# ConfigNatDnat

List of destination NAT configurations.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | The IP address that needs to be translated. This is an exact match on the destination IP of packets received from the IP-in-SCION tunnel. | [optional] 
**description** | **str** | An optional textual description of the destination NAT configuration. | [optional] 
**destination_address** | **str** | The mapped destination IP address. The destination IP of matched packets is replaced by this IP. | [optional] 
**port_mappings** | [**List[ConfigNatDnatPortMapping]**](ConfigNatDnatPortMapping.md) | The list of port mappings for the destination NAT. Mandatory when ingress source NAT is enabled as well. | [optional] 

## Example

```python
from anapaya.appliance.models.config_nat_dnat import ConfigNatDnat

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigNatDnat from a JSON string
config_nat_dnat_instance = ConfigNatDnat.from_json(json)
# print the JSON string representation of the object
print ConfigNatDnat.to_json()

# convert the object into a dict
config_nat_dnat_dict = config_nat_dnat_instance.to_dict()
# create an instance of ConfigNatDnat from a dict
config_nat_dnat_form_dict = config_nat_dnat.from_dict(config_nat_dnat_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


