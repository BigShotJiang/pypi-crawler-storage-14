# ShuttleServerPath


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**human** | **str** | Human readable representation of the SCION path. | 
**expiration** | **datetime** | Expiry specifies until when is the path valid. | 
**source** | **str** |  | 
**destination** | **str** |  | 

## Example

```python
from anapaya.appliance.models.shuttle_server_path import ShuttleServerPath

# TODO update the JSON string below
json = "{}"
# create an instance of ShuttleServerPath from a JSON string
shuttle_server_path_instance = ShuttleServerPath.from_json(json)
# print the JSON string representation of the object
print ShuttleServerPath.to_json()

# convert the object into a dict
shuttle_server_path_dict = shuttle_server_path_instance.to_dict()
# create an instance of ShuttleServerPath from a dict
shuttle_server_path_form_dict = shuttle_server_path.from_dict(shuttle_server_path_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


