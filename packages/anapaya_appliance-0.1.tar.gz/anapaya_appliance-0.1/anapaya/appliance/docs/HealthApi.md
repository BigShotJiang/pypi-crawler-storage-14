# anapaya.appliance.HealthApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**health_get**](HealthApi.md#health_get) | **GET** /health | Get Appliance health


# **health_get**
> HealthGetResponseJson health_get(check_id=check_id, service_name=service_name, status=status)

Get Appliance health

Report the appliance health along with the executed health checks. The health status is based on a set of health checks that are executed. Check the documentation of the individual health checks for more information.  Note that the status is only based on the health checks that are part of the response. If you filter out non-passing health checks, the top level status will be reported as passing. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.health_get_response_json import HealthGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.HealthApi(api_client)
    check_id = ['check_id_example'] # List[str] | List of check_id (or check_id prefixes) that should be included in the response. If unset, health checks are not filtered by check_id. To exclude a check_id, you can use the \"-\" prefix. E.g., the value \"-1001\" will exclude the health checks that have the prefix 1001 from the response.  (optional)
    service_name = ['service_name_example'] # List[str] | List of service_name (or service_name prefixes) that should be included in the response. If unset, health checks are not filtered by service_name. To exclude a service_name, you can use the \"-\" prefix. E.g., the value \"-control\" will exclude the health checks that have the prefix control from the response.  (optional)
    status = ['status_example'] # List[str] | List of status that should be included in the response. If unset, health checks are not filtered by status. To exclude a status, you can use the \"-\" prefix. E.g., the value \"-passing\" will exclude the health checks that have the status passing from the response.  (optional)

    try:
        # Get Appliance health
        api_response = api_instance.health_get(check_id=check_id, service_name=service_name, status=status)
        print("The response of HealthApi->health_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling HealthApi->health_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **check_id** | [**List[str]**](str.md)| List of check_id (or check_id prefixes) that should be included in the response. If unset, health checks are not filtered by check_id. To exclude a check_id, you can use the \&quot;-\&quot; prefix. E.g., the value \&quot;-1001\&quot; will exclude the health checks that have the prefix 1001 from the response.  | [optional] 
 **service_name** | [**List[str]**](str.md)| List of service_name (or service_name prefixes) that should be included in the response. If unset, health checks are not filtered by service_name. To exclude a service_name, you can use the \&quot;-\&quot; prefix. E.g., the value \&quot;-control\&quot; will exclude the health checks that have the prefix control from the response.  | [optional] 
 **status** | [**List[str]**](str.md)| List of status that should be included in the response. If unset, health checks are not filtered by status. To exclude a status, you can use the \&quot;-\&quot; prefix. E.g., the value \&quot;-passing\&quot; will exclude the health checks that have the status passing from the response.  | [optional] 

### Return type

[**HealthGetResponseJson**](HealthGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Health status |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

