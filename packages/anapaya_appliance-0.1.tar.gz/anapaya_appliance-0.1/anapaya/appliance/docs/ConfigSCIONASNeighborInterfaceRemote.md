# ConfigSCIONASNeighborInterfaceRemote

Remote SCION interface endpoint of the link.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | UDP/IP underlay endpoint of the remote SCION Interface. The address must be specified as host:port. This information is provided by the neighbor AS. | [optional] 
**interface_id** | **int** | The SCION interface identifier of the remote end of the link. This information is provided by the neighbor AS. | 

## Example

```python
from anapaya.appliance.models.config_scionas_neighbor_interface_remote import ConfigSCIONASNeighborInterfaceRemote

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigSCIONASNeighborInterfaceRemote from a JSON string
config_scionas_neighbor_interface_remote_instance = ConfigSCIONASNeighborInterfaceRemote.from_json(json)
# print the JSON string representation of the object
print ConfigSCIONASNeighborInterfaceRemote.to_json()

# convert the object into a dict
config_scionas_neighbor_interface_remote_dict = config_scionas_neighbor_interface_remote_instance.to_dict()
# create an instance of ConfigSCIONASNeighborInterfaceRemote from a dict
config_scionas_neighbor_interface_remote_form_dict = config_scionas_neighbor_interface_remote.from_dict(config_scionas_neighbor_interface_remote_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


