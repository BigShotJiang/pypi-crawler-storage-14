# ScionTunnelingSGRPAnnouncementRemote


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**remote_isd_as** | **str** |  | 
**prefixes** | **List[str]** | Announced IP prefixes in CIDR format. | 

## Example

```python
from anapaya.appliance.models.scion_tunneling_sgrp_announcement_remote import ScionTunnelingSGRPAnnouncementRemote

# TODO update the JSON string below
json = "{}"
# create an instance of ScionTunnelingSGRPAnnouncementRemote from a JSON string
scion_tunneling_sgrp_announcement_remote_instance = ScionTunnelingSGRPAnnouncementRemote.from_json(json)
# print the JSON string representation of the object
print ScionTunnelingSGRPAnnouncementRemote.to_json()

# convert the object into a dict
scion_tunneling_sgrp_announcement_remote_dict = scion_tunneling_sgrp_announcement_remote_instance.to_dict()
# create an instance of ScionTunnelingSGRPAnnouncementRemote from a dict
scion_tunneling_sgrp_announcement_remote_form_dict = scion_tunneling_sgrp_announcement_remote.from_dict(scion_tunneling_sgrp_announcement_remote_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


