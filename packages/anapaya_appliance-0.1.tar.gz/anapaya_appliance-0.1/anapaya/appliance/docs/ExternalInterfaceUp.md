# ExternalInterfaceUp

Check data for an explanation of this health check. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**check_id** | **str** | The identifier of the health check type. There can be multiple instances of the same health check in the response.  See the description of the &#x60;data&#x60; field for more information on how the health check is evaluated.  | 
**name** | **str** | The human readable name of the health check type. To identify the type of health check in automated systems, use the &#x60;id&#x60; field instead.  | 
**status** | [**HealthStatus**](HealthStatus.md) |  | 
**detail** | **str** | A human readable explanation of the health check status.  | [optional] 
**data** | [**ExternalInterfaceUpData**](ExternalInterfaceUpData.md) |  | 

## Example

```python
from anapaya.appliance.models.external_interface_up import ExternalInterfaceUp

# TODO update the JSON string below
json = "{}"
# create an instance of ExternalInterfaceUp from a JSON string
external_interface_up_instance = ExternalInterfaceUp.from_json(json)
# print the JSON string representation of the object
print ExternalInterfaceUp.to_json()

# convert the object into a dict
external_interface_up_dict = external_interface_up_instance.to_dict()
# create an instance of ExternalInterfaceUp from a dict
external_interface_up_form_dict = external_interface_up.from_dict(external_interface_up_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


