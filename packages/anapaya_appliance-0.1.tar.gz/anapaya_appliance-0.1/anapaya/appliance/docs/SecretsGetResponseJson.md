# SecretsGetResponseJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secrets** | [**List[Secret]**](Secret.md) |  | 

## Example

```python
from anapaya.appliance.models.secrets_get_response_json import SecretsGetResponseJson

# TODO update the JSON string below
json = "{}"
# create an instance of SecretsGetResponseJson from a JSON string
secrets_get_response_json_instance = SecretsGetResponseJson.from_json(json)
# print the JSON string representation of the object
print SecretsGetResponseJson.to_json()

# convert the object into a dict
secrets_get_response_json_dict = secrets_get_response_json_instance.to_dict()
# create an instance of SecretsGetResponseJson from a dict
secrets_get_response_json_form_dict = secrets_get_response_json.from_dict(secrets_get_response_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


