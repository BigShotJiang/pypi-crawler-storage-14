# ConfigManagementApi

Anapaya appliance management API configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**basic_auth** | [**ConfigManagementApiBasicAuth**](ConfigManagementApiBasicAuth.md) |  | [optional] 
**disable_local_unix_socket** | **bool** | By default, the management API is exposed on a local UNIX socket, that can only be accessed by a privileged user (the user needs to be part of the caddy group) locally on the appliance. Setting this property to true disables the local UNIX socket. Note this might lock you out of the management API if you have not configured any other listeners or those listeners are not reachable. | [optional] [default to False]
**interfaces** | [**List[ConfigManagementApiInterface]**](ConfigManagementApiInterface.md) | List of network interfaces management API listeners that define where the API is exposed. Use this only if the interface address is unknown at configuration time, i.e., it is assigned dynamically. | [optional] 
**listeners** | [**List[ConfigManagementApiListener]**](ConfigManagementApiListener.md) | List of management API listeners that define where the API is exposed | [optional] 
**oauth** | [**ConfigManagementApiOauth**](ConfigManagementApiOauth.md) |  | [optional] 
**unprotected** | **bool** | Whether the management API is allowed to be exposed without authentication. Always make sure to properly protect your API. | [optional] [default to False]

## Example

```python
from anapaya.appliance.models.config_management_api import ConfigManagementApi

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigManagementApi from a JSON string
config_management_api_instance = ConfigManagementApi.from_json(json)
# print the JSON string representation of the object
print ConfigManagementApi.to_json()

# convert the object into a dict
config_management_api_dict = config_management_api_instance.to_dict()
# create an instance of ConfigManagementApi from a dict
config_management_api_form_dict = config_management_api.from_dict(config_management_api_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


