# ConfigShuttleServersServerClient

List of Shuttle client configurations.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | The IPv4/IPv6 address that will be assigned to the client tunnel interface upon successful connection. Without CIDR mask. Must be in the same family as local tunnel address. | [optional] 
**credential** | **str** | A base64 encoded string that is used to authenticate the client. | [optional] 

## Example

```python
from anapaya.appliance.models.config_shuttle_servers_server_client import ConfigShuttleServersServerClient

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigShuttleServersServerClient from a JSON string
config_shuttle_servers_server_client_instance = ConfigShuttleServersServerClient.from_json(json)
# print the JSON string representation of the object
print ConfigShuttleServersServerClient.to_json()

# convert the object into a dict
config_shuttle_servers_server_client_dict = config_shuttle_servers_server_client_instance.to_dict()
# create an instance of ConfigShuttleServersServerClient from a dict
config_shuttle_servers_server_client_form_dict = config_shuttle_servers_server_client.from_dict(config_shuttle_servers_server_client_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


