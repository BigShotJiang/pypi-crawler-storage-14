# ConfigManagementSshRadiusServer

RADIUS server configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | The IP address of the RADIUS server. | [optional] 
**description** | **str** | Description or comment for the server. | [optional] 
**secret_id_ref** | **str** | Reference to the secret ID used to authenticate the Anapaya appliance to the RADIUS server | [optional] 

## Example

```python
from anapaya.appliance.models.config_management_ssh_radius_server import ConfigManagementSshRadiusServer

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigManagementSshRadiusServer from a JSON string
config_management_ssh_radius_server_instance = ConfigManagementSshRadiusServer.from_json(json)
# print the JSON string representation of the object
print ConfigManagementSshRadiusServer.to_json()

# convert the object into a dict
config_management_ssh_radius_server_dict = config_management_ssh_radius_server_instance.to_dict()
# create an instance of ConfigManagementSshRadiusServer from a dict
config_management_ssh_radius_server_form_dict = config_management_ssh_radius_server.from_dict(config_management_ssh_radius_server_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


