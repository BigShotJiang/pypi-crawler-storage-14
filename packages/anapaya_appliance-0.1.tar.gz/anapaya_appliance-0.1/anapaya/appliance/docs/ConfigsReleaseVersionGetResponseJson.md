# ConfigsReleaseVersionGetResponseJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**release** | **str** | The version of the appliance software. | 
**configs** | [**List[RawConfigWithVersion]**](RawConfigWithVersion.md) |  | 

## Example

```python
from anapaya.appliance.models.configs_release_version_get_response_json import ConfigsReleaseVersionGetResponseJson

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigsReleaseVersionGetResponseJson from a JSON string
configs_release_version_get_response_json_instance = ConfigsReleaseVersionGetResponseJson.from_json(json)
# print the JSON string representation of the object
print ConfigsReleaseVersionGetResponseJson.to_json()

# convert the object into a dict
configs_release_version_get_response_json_dict = configs_release_version_get_response_json_instance.to_dict()
# create an instance of ConfigsReleaseVersionGetResponseJson from a dict
configs_release_version_get_response_json_form_dict = configs_release_version_get_response_json.from_dict(configs_release_version_get_response_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


