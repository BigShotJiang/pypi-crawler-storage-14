# ConfigSCIONASNeighborInterface

SCION interface that links to the neighbor AS.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | UDP/IP underlay endpoint of the SCION Interface. The data plane traffic is received on this address. The address must be specified as host:port. Both host and port must be specified. | [optional] 
**administrative_state** | **str** | The administrative state of the interface with one of the following values:  - &#x60;UP&#x60;   The interface is up and ready to send/receive SCION packets as well as being   advertised during beaconing. - &#x60;DATAPLANE_ONLY&#x60;   The interface is up and ready to send/receive SCION packets, but is not advertised   during beaconing. - &#x60;ADMIN_DOWN&#x60;   The interface is down and neither sends/receives SCION packets nor is it advertised   during beaconing.   Experimental: Currently only UP is supported. | [optional] 
**bfd** | [**ConfigSCIONASNeighborInterfaceBFD**](ConfigSCIONASNeighborInterfaceBFD.md) |  | [optional] 
**description** | **str** | Description, or comment, for the SCION interface. | [optional] 
**enable_scion_rss** | **bool** | Flag to activate SCION RSS for this link. If activated, the router utilizes UDP source port entropy on the underlay such that the remote router can leverage RSS for SCION traffic. This can greatly improve throughput performance. For low throughput SCION links (up to 1 Gbps), enabling SCION RSS is not necessary. Before enabling this feature, please ensure that the remote router supports SCION RSS. | [optional] [default to False]
**interface_id** | **int** | SCION interface identifier. It must be unique in the SCION AS. | 
**remote** | [**ConfigSCIONASNeighborInterfaceRemote**](ConfigSCIONASNeighborInterfaceRemote.md) |  | [optional] 
**scion_mtu** | **int** | The maximum transmission unit in bytes for SCION packets on the external interface. This represents the protocol data unit (PDU) of the SCION layer on this interface and is usually calculated as maximum Ethernet payload - IP Header - UDP Header. Note that the SCION MTU can differ between the various links and also from SCION MTU supported in the internal network of the local AS. | [optional] [default to 1472]

## Example

```python
from anapaya.appliance.models.config_scionas_neighbor_interface import ConfigSCIONASNeighborInterface

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigSCIONASNeighborInterface from a JSON string
config_scionas_neighbor_interface_instance = ConfigSCIONASNeighborInterface.from_json(json)
# print the JSON string representation of the object
print ConfigSCIONASNeighborInterface.to_json()

# convert the object into a dict
config_scionas_neighbor_interface_dict = config_scionas_neighbor_interface_instance.to_dict()
# create an instance of ConfigSCIONASNeighborInterface from a dict
config_scionas_neighbor_interface_form_dict = config_scionas_neighbor_interface.from_dict(config_scionas_neighbor_interface_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


