# anapaya.appliance.InitApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**configs_post**](InitApi.md#configs_post) | **POST** /configs | Add configuration
[**cppki_certificates_post**](InitApi.md#cppki_certificates_post) | **POST** /cppki/certificates | Add certificate
[**cppki_csrs_post**](InitApi.md#cppki_csrs_post) | **POST** /cppki/csrs | Create CSR
[**cppki_trcs_bundle_post**](InitApi.md#cppki_trcs_bundle_post) | **POST** /cppki/trcs/bundle | Add TRC bundle
[**cppki_trcs_post**](InitApi.md#cppki_trcs_post) | **POST** /cppki/trcs | Add TRC
[**secrets_batch_post**](InitApi.md#secrets_batch_post) | **POST** /secrets/batch | Add secrets batch


# **configs_post**
> ConfigPutResponseJson configs_post(configs_post_request, if_match=if_match, force=force, allow_hostname_change=allow_hostname_change, disable_strict_parsing=disable_strict_parsing)

Add configuration

Create a new configuration version. This endpoint is almost identical to the PUT config endpoint. The only difference is that on success, it returns a 201 Created response instead of a 200 OK response.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_put_response_json import ConfigPutResponseJson
from anapaya.appliance.models.configs_post_request import ConfigsPostRequest
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.InitApi(api_client)
    configs_post_request = anapaya.appliance.ConfigsPostRequest() # ConfigsPostRequest | The config to be pushed to the appliance.
    if_match = 'if_match_example' # str |  (optional)
    force = True # bool | Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. (optional)
    allow_hostname_change = True # bool | Once the hostname has been configured, the POST configs endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. (optional)
    disable_strict_parsing = True # bool | Disable strict parsing of the appliance configuration. (optional)

    try:
        # Add configuration
        api_response = api_instance.configs_post(configs_post_request, if_match=if_match, force=force, allow_hostname_change=allow_hostname_change, disable_strict_parsing=disable_strict_parsing)
        print("The response of InitApi->configs_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InitApi->configs_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configs_post_request** | [**ConfigsPostRequest**](ConfigsPostRequest.md)| The config to be pushed to the appliance. | 
 **if_match** | **str**|  | [optional] 
 **force** | **bool**| Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. | [optional] 
 **allow_hostname_change** | **bool**| Once the hostname has been configured, the POST configs endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. | [optional] 
 **disable_strict_parsing** | **bool**| Disable strict parsing of the appliance configuration. | [optional] 

### Return type

[**ConfigPutResponseJson**](ConfigPutResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/yaml
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cppki_certificates_post**
> CppkiCertificatesPostResponseJson cppki_certificates_post(body, force=force)

Add certificate

Add a SCION CPPKI AS certificate chain to the device by promoting an existing certificate signing request. The certificate chain is first verified against the active TRC of the local ISD before it is added. Only verifiable certificate chains are added.  Use the 'force' query parameter to force the addition of the certificate chain regardless of validity or verifiability. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.cppki_certificates_post_response_json import CppkiCertificatesPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.InitApi(api_client)
    body = None # bytearray | 
    force = False # bool | If force is true the certificate chain is added regardless of validity.  (optional) (default to False)

    try:
        # Add certificate
        api_response = api_instance.cppki_certificates_post(body, force=force)
        print("The response of InitApi->cppki_certificates_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InitApi->cppki_certificates_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **bytearray**|  | 
 **force** | **bool**| If force is true the certificate chain is added regardless of validity.  | [optional] [default to False]

### Return type

[**CppkiCertificatesPostResponseJson**](CppkiCertificatesPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/pkcs7-mime, application/x-pem-files
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cppki_csrs_post**
> CppkiCsrsPostResponseJson cppki_csrs_post(certificate_signing_request)

Create CSR

Create a SCION CPPKI AS Certificate Signing Request (CSR). The CSR needs to be signed by a SCION CPPKI Certificate Authority in the local ISD. The fully signed certificate chain then needs to be installed via the /cppki/certificates endpoint. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.certificate_signing_request import CertificateSigningRequest
from anapaya.appliance.models.cppki_csrs_post_response_json import CppkiCsrsPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.InitApi(api_client)
    certificate_signing_request = anapaya.appliance.CertificateSigningRequest() # CertificateSigningRequest | The parameters for the CSR. 

    try:
        # Create CSR
        api_response = api_instance.cppki_csrs_post(certificate_signing_request)
        print("The response of InitApi->cppki_csrs_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InitApi->cppki_csrs_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **certificate_signing_request** | [**CertificateSigningRequest**](CertificateSigningRequest.md)| The parameters for the CSR.  | 

### Return type

[**CppkiCsrsPostResponseJson**](CppkiCsrsPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/x-pem-file, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cppki_trcs_bundle_post**
> CppkiTrcsBundlePostResponseJson cppki_trcs_bundle_post(body, force=force)

Add TRC bundle

Add a bundle SCION CPPKI Trust Root Configuration (TRC) files to the device. The TRCs are first validated before they are added to the trust store. Only valid TRCs are added to the trust store. Use the 'force' query parameter to force the addition of the TRCs regardless of validity. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.cppki_trcs_bundle_post_response_json import CppkiTrcsBundlePostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.InitApi(api_client)
    body = [B@40c4b938 # bytearray | 
    force = False # bool | If force is true, the TRC is added regardless of validity. (optional) (default to False)

    try:
        # Add TRC bundle
        api_response = api_instance.cppki_trcs_bundle_post(body, force=force)
        print("The response of InitApi->cppki_trcs_bundle_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InitApi->cppki_trcs_bundle_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **bytearray**|  | 
 **force** | **bool**| If force is true, the TRC is added regardless of validity. | [optional] [default to False]

### Return type

[**CppkiTrcsBundlePostResponseJson**](CppkiTrcsBundlePostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-pem-files
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cppki_trcs_post**
> CppkiTrcsPostResponseJson cppki_trcs_post(body, force=force)

Add TRC

Add a SCION CPPKI Trust Root Configuration (TRC) file to the device. The TRC is first validated before it is added to the trust store. Only valid TRCs are added to the trust store. Use the 'force' query parameter to force the addition of the TRC regardless of validity. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.cppki_trcs_post_response_json import CppkiTrcsPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.InitApi(api_client)
    body = [B@60a6564c # bytearray | 
    force = False # bool | If force is true, the TRC is added regardless of validity. (optional) (default to False)

    try:
        # Add TRC
        api_response = api_instance.cppki_trcs_post(body, force=force)
        print("The response of InitApi->cppki_trcs_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InitApi->cppki_trcs_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **bytearray**|  | 
 **force** | **bool**| If force is true, the TRC is added regardless of validity. | [optional] [default to False]

### Return type

[**CppkiTrcsPostResponseJson**](CppkiTrcsPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-pem-files
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **secrets_batch_post**
> secrets_batch_post(secrets_batch_request_json=secrets_batch_request_json)

Add secrets batch

Add a batch of new secrets.  If one secret is invalid (e.g. secret ID already exists or invalid), the entire request will fail and no secret is created. 

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.secrets_batch_request_json import SecretsBatchRequestJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.InitApi(api_client)
    secrets_batch_request_json = anapaya.appliance.SecretsBatchRequestJson() # SecretsBatchRequestJson |  (optional)

    try:
        # Add secrets batch
        api_instance.secrets_batch_post(secrets_batch_request_json=secrets_batch_request_json)
    except Exception as e:
        print("Exception when calling InitApi->secrets_batch_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **secrets_batch_request_json** | [**SecretsBatchRequestJson**](SecretsBatchRequestJson.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | success |  -  |
**400** | bad request |  -  |
**409** | The request contains a secret id that already exists or is invalid. |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

