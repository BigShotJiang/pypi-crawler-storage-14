# DomainExchangesIPPrefixes


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**check_id** | **str** | The identifier of the health check type. There can be multiple instances of the same health check in the response.  See the description of the &#x60;data&#x60; field for more information on how the health check is evaluated.  | 
**name** | **str** | The human readable name of the health check type. To identify the type of health check in automated systems, use the &#x60;id&#x60; field instead.  | 
**status** | [**HealthStatus**](HealthStatus.md) |  | 
**detail** | **str** | A human readable explanation of the health check status.  | [optional] 
**data** | [**DomainExchangesIPPrefixesData**](DomainExchangesIPPrefixesData.md) |  | 

## Example

```python
from anapaya.appliance.models.domain_exchanges_ip_prefixes import DomainExchangesIPPrefixes

# TODO update the JSON string below
json = "{}"
# create an instance of DomainExchangesIPPrefixes from a JSON string
domain_exchanges_ip_prefixes_instance = DomainExchangesIPPrefixes.from_json(json)
# print the JSON string representation of the object
print DomainExchangesIPPrefixes.to_json()

# convert the object into a dict
domain_exchanges_ip_prefixes_dict = domain_exchanges_ip_prefixes_instance.to_dict()
# create an instance of DomainExchangesIPPrefixes from a dict
domain_exchanges_ip_prefixes_form_dict = domain_exchanges_ip_prefixes.from_dict(domain_exchanges_ip_prefixes_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


