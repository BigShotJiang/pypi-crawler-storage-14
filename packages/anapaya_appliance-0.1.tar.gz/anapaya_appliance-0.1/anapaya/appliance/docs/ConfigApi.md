# anapaya.appliance.ConfigApi

All URIs are relative to *https://localhost:443/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**config_advanced_service_customization_get**](ConfigApi.md#config_advanced_service_customization_get) | **GET** /config/advanced/service-customization/{service_type} | Get service customization
[**config_advanced_service_customization_template_execute_post**](ConfigApi.md#config_advanced_service_customization_template_execute_post) | **POST** /config/advanced/service-customization/{service_type}/template/execute | Render custom server template
[**config_advanced_service_customization_template_get**](ConfigApi.md#config_advanced_service_customization_template_get) | **GET** /config/advanced/service-customization/{service_type}/template | Get custom service template
[**config_advanced_service_customization_template_put**](ConfigApi.md#config_advanced_service_customization_template_put) | **PUT** /config/advanced/service-customization/{service_type}/template | Set custom service template
[**config_diff_post**](ConfigApi.md#config_diff_post) | **POST** /config/diff | Diff config to provided
[**config_get**](ConfigApi.md#config_get) | **GET** /config | Get configuration
[**config_put**](ConfigApi.md#config_put) | **PUT** /config | Set configuration
[**config_validate_post**](ConfigApi.md#config_validate_post) | **POST** /config/validate | Validate provided configuration
[**configs_get**](ConfigApi.md#configs_get) | **GET** /configs | List configuration versions
[**configs_latest_diff_post**](ConfigApi.md#configs_latest_diff_post) | **POST** /configs/latest/diff | Diff configuration to previous
[**configs_latest_diff_reference_post**](ConfigApi.md#configs_latest_diff_reference_post) | **POST** /configs/latest/diff/{reference} | Diff configuration to reference version
[**configs_latest_get**](ConfigApi.md#configs_latest_get) | **GET** /configs/latest | Get latest configuration
[**configs_post**](ConfigApi.md#configs_post) | **POST** /configs | Add configuration
[**configs_releases_get**](ConfigApi.md#configs_releases_get) | **GET** /configs/releases | List configuration versions across releases
[**configs_releases_release_get**](ConfigApi.md#configs_releases_release_get) | **GET** /configs/releases/{release} | List configuration versions for release
[**configs_releases_release_version_get**](ConfigApi.md#configs_releases_release_version_get) | **GET** /configs/releases/{release}/{version} | Get configuration version for release
[**configs_version_diff_post**](ConfigApi.md#configs_version_diff_post) | **POST** /configs/{version}/diff | Diff configuration version to previous
[**configs_version_diff_reference_post**](ConfigApi.md#configs_version_diff_reference_post) | **POST** /configs/{version}/diff/{reference} | Diff configuration version to reference version
[**configs_version_get**](ConfigApi.md#configs_version_get) | **GET** /configs/{version} | Get configuration version
[**configs_version_reapply_post**](ConfigApi.md#configs_version_reapply_post) | **POST** /configs/{version}/reapply | Reapply previous configuration


# **config_advanced_service_customization_get**
> ConfigServiceCustomizationResponseJson config_advanced_service_customization_get(service_type)

Get service customization

Get the configured customization for a service, along with its state.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_service_customization_response_json import ConfigServiceCustomizationResponseJson
from anapaya.appliance.models.service_type import ServiceType
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    service_type = anapaya.appliance.ServiceType() # ServiceType | Service Type

    try:
        # Get service customization
        api_response = api_instance.config_advanced_service_customization_get(service_type)
        print("The response of ConfigApi->config_advanced_service_customization_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_advanced_service_customization_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service_type** | [**ServiceType**](.md)| Service Type | 

### Return type

[**ConfigServiceCustomizationResponseJson**](ConfigServiceCustomizationResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **config_advanced_service_customization_template_execute_post**
> str config_advanced_service_customization_template_execute_post(service_type, body, isd_as=isd_as)

Render custom server template

Render a new custom template for a service, along with its state.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.service_type import ServiceType
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    service_type = anapaya.appliance.ServiceType() # ServiceType | Service Type
    body = 'body_example' # str | The custom service template to be rendered.
    isd_as = 'isd_as_example' # str |  (optional)

    try:
        # Render custom server template
        api_response = api_instance.config_advanced_service_customization_template_execute_post(service_type, body, isd_as=isd_as)
        print("The response of ConfigApi->config_advanced_service_customization_template_execute_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_advanced_service_customization_template_execute_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service_type** | [**ServiceType**](.md)| Service Type | 
 **body** | **str**| The custom service template to be rendered. | 
 **isd_as** | **str**|  | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: text/plain, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **config_advanced_service_customization_template_get**
> str config_advanced_service_customization_template_get(service_type)

Get custom service template

Get the configured custom template for a service, along with its state.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.service_type import ServiceType
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    service_type = anapaya.appliance.ServiceType() # ServiceType | Service Type

    try:
        # Get custom service template
        api_response = api_instance.config_advanced_service_customization_template_get(service_type)
        print("The response of ConfigApi->config_advanced_service_customization_template_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_advanced_service_customization_template_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service_type** | [**ServiceType**](.md)| Service Type | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **config_advanced_service_customization_template_put**
> ConfigServiceCustomizationResponseJson config_advanced_service_customization_template_put(service_type, body)

Set custom service template

Put a new custom template for a service, along with its state.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_service_customization_response_json import ConfigServiceCustomizationResponseJson
from anapaya.appliance.models.service_type import ServiceType
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    service_type = anapaya.appliance.ServiceType() # ServiceType | Service Type
    body = 'body_example' # str | The custom service template to be pushed to the appliance.

    try:
        # Set custom service template
        api_response = api_instance.config_advanced_service_customization_template_put(service_type, body)
        print("The response of ConfigApi->config_advanced_service_customization_template_put:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_advanced_service_customization_template_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service_type** | [**ServiceType**](.md)| Service Type | 
 **body** | **str**| The custom service template to be pushed to the appliance. | 

### Return type

[**ConfigServiceCustomizationResponseJson**](ConfigServiceCustomizationResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **config_diff_post**
> ConfigDiffPostResponseJson config_diff_post(configs_post_request, disable_strict_parsing=disable_strict_parsing)

Diff config to provided

Display the difference between the current configuration and the provided configuration.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_diff_post_response_json import ConfigDiffPostResponseJson
from anapaya.appliance.models.configs_post_request import ConfigsPostRequest
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    configs_post_request = anapaya.appliance.ConfigsPostRequest() # ConfigsPostRequest | The config to be validated.
    disable_strict_parsing = True # bool | Disable strict parsing of the appliance configuration. (optional)

    try:
        # Diff config to provided
        api_response = api_instance.config_diff_post(configs_post_request, disable_strict_parsing=disable_strict_parsing)
        print("The response of ConfigApi->config_diff_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_diff_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configs_post_request** | [**ConfigsPostRequest**](ConfigsPostRequest.md)| The config to be validated. | 
 **disable_strict_parsing** | **bool**| Disable strict parsing of the appliance configuration. | [optional] 

### Return type

[**ConfigDiffPostResponseJson**](ConfigDiffPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/yaml
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **config_get**
> ConfigGetResponseJson config_get(if_none_match=if_none_match)

Get configuration

Get the currently active appliance configuration. Deprecated: Use GET /configs/latest endpoint instead.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_get_response_json import ConfigGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    if_none_match = 'if_none_match_example' # str |  (optional)

    try:
        # Get configuration
        api_response = api_instance.config_get(if_none_match=if_none_match)
        print("The response of ConfigApi->config_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **if_none_match** | **str**|  | [optional] 

### Return type

[**ConfigGetResponseJson**](ConfigGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**304** | not modified |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **config_put**
> ConfigPutResponseJson config_put(configs_post_request, if_match=if_match, force=force, allow_hostname_change=allow_hostname_change, disable_strict_parsing=disable_strict_parsing)

Set configuration

Put a new configuration to the appliance. Deprecated: Use POST /configs endpoint instead.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_put_response_json import ConfigPutResponseJson
from anapaya.appliance.models.configs_post_request import ConfigsPostRequest
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    configs_post_request = anapaya.appliance.ConfigsPostRequest() # ConfigsPostRequest | The config to be pushed to the appliance.
    if_match = 'if_match_example' # str |  (optional)
    force = True # bool | Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. (optional)
    allow_hostname_change = True # bool | Once the hostname has been configured, the PUT config endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. (optional)
    disable_strict_parsing = True # bool | Disable strict parsing of the appliance configuration. (optional)

    try:
        # Set configuration
        api_response = api_instance.config_put(configs_post_request, if_match=if_match, force=force, allow_hostname_change=allow_hostname_change, disable_strict_parsing=disable_strict_parsing)
        print("The response of ConfigApi->config_put:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configs_post_request** | [**ConfigsPostRequest**](ConfigsPostRequest.md)| The config to be pushed to the appliance. | 
 **if_match** | **str**|  | [optional] 
 **force** | **bool**| Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. | [optional] 
 **allow_hostname_change** | **bool**| Once the hostname has been configured, the PUT config endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. | [optional] 
 **disable_strict_parsing** | **bool**| Disable strict parsing of the appliance configuration. | [optional] 

### Return type

[**ConfigPutResponseJson**](ConfigPutResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/yaml
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**412** | precondition failed |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **config_validate_post**
> ConfigPostResponseJson config_validate_post(configs_post_request, disable_strict_parsing=disable_strict_parsing)

Validate provided configuration

Validates a configuration.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_post_response_json import ConfigPostResponseJson
from anapaya.appliance.models.configs_post_request import ConfigsPostRequest
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    configs_post_request = anapaya.appliance.ConfigsPostRequest() # ConfigsPostRequest | The config to be validated.
    disable_strict_parsing = True # bool | Disable strict parsing of the appliance configuration. (optional)

    try:
        # Validate provided configuration
        api_response = api_instance.config_validate_post(configs_post_request, disable_strict_parsing=disable_strict_parsing)
        print("The response of ConfigApi->config_validate_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->config_validate_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configs_post_request** | [**ConfigsPostRequest**](ConfigsPostRequest.md)| The config to be validated. | 
 **disable_strict_parsing** | **bool**| Disable strict parsing of the appliance configuration. | [optional] 

### Return type

[**ConfigPostResponseJson**](ConfigPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/yaml
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_get**
> ConfigsGetResponseJson configs_get(include_config=include_config)

List configuration versions

Gets the list of all configuration versions. Optionally, the configs themselves can be included in the response. Use the include_configs query parameter.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.configs_get_response_json import ConfigsGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    include_config = True # bool | Include the configs themselves in the response. (optional)

    try:
        # List configuration versions
        api_response = api_instance.configs_get(include_config=include_config)
        print("The response of ConfigApi->configs_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **include_config** | **bool**| Include the configs themselves in the response. | [optional] 

### Return type

[**ConfigsGetResponseJson**](ConfigsGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_latest_diff_post**
> ConfigDiffPostResponseJson configs_latest_diff_post()

Diff configuration to previous

Display config changes from the previous version to the current config.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_diff_post_response_json import ConfigDiffPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)

    try:
        # Diff configuration to previous
        api_response = api_instance.configs_latest_diff_post()
        print("The response of ConfigApi->configs_latest_diff_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_latest_diff_post: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**ConfigDiffPostResponseJson**](ConfigDiffPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_latest_diff_reference_post**
> ConfigDiffPostResponseJson configs_latest_diff_reference_post(reference)

Diff configuration to reference version

Display config changes from the reference version to the current config.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_diff_post_response_json import ConfigDiffPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    reference = 56 # int | The reference version of the config to use as base for the diff.

    try:
        # Diff configuration to reference version
        api_response = api_instance.configs_latest_diff_reference_post(reference)
        print("The response of ConfigApi->configs_latest_diff_reference_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_latest_diff_reference_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **reference** | **int**| The reference version of the config to use as base for the diff. | 

### Return type

[**ConfigDiffPostResponseJson**](ConfigDiffPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_latest_get**
> ConfigGetResponseJson configs_latest_get()

Get latest configuration

Gets the latest configuration. This is the same as the current configuration.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_get_response_json import ConfigGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)

    try:
        # Get latest configuration
        api_response = api_instance.configs_latest_get()
        print("The response of ConfigApi->configs_latest_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_latest_get: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**ConfigGetResponseJson**](ConfigGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  * Cache-Control - Indicates that caching is disabled for this response. <br>  |
**304** | not modified |  -  |
**400** | bad request |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_post**
> ConfigPutResponseJson configs_post(configs_post_request, if_match=if_match, force=force, allow_hostname_change=allow_hostname_change, disable_strict_parsing=disable_strict_parsing)

Add configuration

Create a new configuration version. This endpoint is almost identical to the PUT config endpoint. The only difference is that on success, it returns a 201 Created response instead of a 200 OK response.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_put_response_json import ConfigPutResponseJson
from anapaya.appliance.models.configs_post_request import ConfigsPostRequest
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    configs_post_request = anapaya.appliance.ConfigsPostRequest() # ConfigsPostRequest | The config to be pushed to the appliance.
    if_match = 'if_match_example' # str |  (optional)
    force = True # bool | Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. (optional)
    allow_hostname_change = True # bool | Once the hostname has been configured, the POST configs endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. (optional)
    disable_strict_parsing = True # bool | Disable strict parsing of the appliance configuration. (optional)

    try:
        # Add configuration
        api_response = api_instance.configs_post(configs_post_request, if_match=if_match, force=force, allow_hostname_change=allow_hostname_change, disable_strict_parsing=disable_strict_parsing)
        print("The response of ConfigApi->configs_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configs_post_request** | [**ConfigsPostRequest**](ConfigsPostRequest.md)| The config to be pushed to the appliance. | 
 **if_match** | **str**|  | [optional] 
 **force** | **bool**| Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. | [optional] 
 **allow_hostname_change** | **bool**| Once the hostname has been configured, the POST configs endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. | [optional] 
 **disable_strict_parsing** | **bool**| Disable strict parsing of the appliance configuration. | [optional] 

### Return type

[**ConfigPutResponseJson**](ConfigPutResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/yaml
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_releases_get**
> ConfigsReleasesGetResponseJson configs_releases_get(include_config=include_config)

List configuration versions across releases

Lists all configuration versions of all releases. Optionally all configurations can be included with the include_config query parameter.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.configs_releases_get_response_json import ConfigsReleasesGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    include_config = True # bool | Include the configurations themselves in the response. (optional)

    try:
        # List configuration versions across releases
        api_response = api_instance.configs_releases_get(include_config=include_config)
        print("The response of ConfigApi->configs_releases_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_releases_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **include_config** | **bool**| Include the configurations themselves in the response. | [optional] 

### Return type

[**ConfigsReleasesGetResponseJson**](ConfigsReleasesGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_releases_release_get**
> ConfigsReleaseVersionGetResponseJson configs_releases_release_get(release, include_config=include_config)

List configuration versions for release

Gets the list of all configuration versions for a release. Optionally also all configurations can be requested.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.configs_release_version_get_response_json import ConfigsReleaseVersionGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    release = 'release_example' # str | The release version to get the configurations for.
    include_config = True # bool | Include the configurations themselves in the response. (optional)

    try:
        # List configuration versions for release
        api_response = api_instance.configs_releases_release_get(release, include_config=include_config)
        print("The response of ConfigApi->configs_releases_release_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_releases_release_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **release** | **str**| The release version to get the configurations for. | 
 **include_config** | **bool**| Include the configurations themselves in the response. | [optional] 

### Return type

[**ConfigsReleaseVersionGetResponseJson**](ConfigsReleaseVersionGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_releases_release_version_get**
> RawConfigWithVersion configs_releases_release_version_get(release, version)

Get configuration version for release

Get the configuration for a specific release and version.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.raw_config_with_version import RawConfigWithVersion
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    release = 'release_example' # str | The version of the appliance software release.
    version = 56 # int | The version of the configuration.

    try:
        # Get configuration version for release
        api_response = api_instance.configs_releases_release_version_get(release, version)
        print("The response of ConfigApi->configs_releases_release_version_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_releases_release_version_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **release** | **str**| The version of the appliance software release. | 
 **version** | **int**| The version of the configuration. | 

### Return type

[**RawConfigWithVersion**](RawConfigWithVersion.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_version_diff_post**
> ConfigDiffPostResponseJson configs_version_diff_post(version)

Diff configuration version to previous

Display config changes from `{version} - 1` to `{version}`.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_diff_post_response_json import ConfigDiffPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    version = 56 # int | The target version of the configuration to compare against its predecessor.

    try:
        # Diff configuration version to previous
        api_response = api_instance.configs_version_diff_post(version)
        print("The response of ConfigApi->configs_version_diff_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_version_diff_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **int**| The target version of the configuration to compare against its predecessor. | 

### Return type

[**ConfigDiffPostResponseJson**](ConfigDiffPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_version_diff_reference_post**
> ConfigDiffPostResponseJson configs_version_diff_reference_post(version, reference)

Diff configuration version to reference version

Display config changes from reference version to the target version.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_diff_post_response_json import ConfigDiffPostResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    version = 56 # int | The target version of the configuration to compare against the reference version.
    reference = 56 # int | The reference version of the config to use as the base for the diff.

    try:
        # Diff configuration version to reference version
        api_response = api_instance.configs_version_diff_reference_post(version, reference)
        print("The response of ConfigApi->configs_version_diff_reference_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_version_diff_reference_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **int**| The target version of the configuration to compare against the reference version. | 
 **reference** | **int**| The reference version of the config to use as the base for the diff. | 

### Return type

[**ConfigDiffPostResponseJson**](ConfigDiffPostResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_version_get**
> ConfigGetResponseJson configs_version_get(version)

Get configuration version

Gets the configuration at the specified version. To list the available versions use the GET configs endpoint.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_get_response_json import ConfigGetResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    version = 56 # int | The version of the configuration to retrieve.

    try:
        # Get configuration version
        api_response = api_instance.configs_version_get(version)
        print("The response of ConfigApi->configs_version_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_version_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **int**| The version of the configuration to retrieve. | 

### Return type

[**ConfigGetResponseJson**](ConfigGetResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | bad request |  -  |
**404** | not found |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **configs_version_reapply_post**
> ConfigPutResponseJson configs_version_reapply_post(version, force=force, allow_hostname_change=allow_hostname_change)

Reapply previous configuration

Reapply the specified configuration version.

### Example


```python
import time
import os
import anapaya.appliance
from anapaya.appliance.models.config_put_response_json import ConfigPutResponseJson
from anapaya.appliance.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://localhost:443/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = anapaya.appliance.Configuration(
    host = "https://localhost:443/api/v1"
)


# Enter a context with an instance of the API client
with anapaya.appliance.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anapaya.appliance.ConfigApi(api_client)
    version = 56 # int | The version of the configuration to reapply.
    force = True # bool | Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. (optional)
    allow_hostname_change = True # bool | Once the hostname has been configured, the PUT config endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. (optional)

    try:
        # Reapply previous configuration
        api_response = api_instance.configs_version_reapply_post(version, force=force, allow_hostname_change=allow_hostname_change)
        print("The response of ConfigApi->configs_version_reapply_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigApi->configs_version_reapply_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **int**| The version of the configuration to reapply. | 
 **force** | **bool**| Push the configuration, even if configuration validation fails. This parameter MUST be used with care as it can leave the appliance in a misconfigured state. | [optional] 
 **allow_hostname_change** | **bool**| Once the hostname has been configured, the PUT config endpoint will reject any configuration that changes the hostname, unless this flag is set. This is to prevent accidental deployment of a configuration meant for a different appliance. | [optional] 

### Return type

[**ConfigPutResponseJson**](ConfigPutResponseJson.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/json+problem

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**400** | invalid configuration |  -  |
**500** | internal error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

