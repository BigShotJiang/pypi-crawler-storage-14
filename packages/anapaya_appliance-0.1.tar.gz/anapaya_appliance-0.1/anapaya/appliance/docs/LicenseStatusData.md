# LicenseStatusData

The licensing status of the appliance. this indicates whether a valid license is presences or whether the appliance is in a trial or grace period or whether it's functionality is restricted. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | The status of the licensing. Indicates whether a valid license is present on the appliance, or whether the appliance is in grace period, or if the appliance functionality is restricted.  | 
**expiry** | **datetime** | The time up to which the current status remains unchanged without interaction. Not set in the initial indefinite trial period and if the appliance is running in restricted-functionality mode.  | [optional] 
**license** | [**License**](License.md) |  | [optional] 
**enforcer_disabled** | **bool** | Whether the license enforcer is disabled (only exists in initial releases of the feature).  | [optional] 

## Example

```python
from anapaya.appliance.models.license_status_data import LicenseStatusData

# TODO update the JSON string below
json = "{}"
# create an instance of LicenseStatusData from a JSON string
license_status_data_instance = LicenseStatusData.from_json(json)
# print the JSON string representation of the object
print LicenseStatusData.to_json()

# convert the object into a dict
license_status_data_dict = license_status_data_instance.to_dict()
# create an instance of LicenseStatusData from a dict
license_status_data_form_dict = license_status_data.from_dict(license_status_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


