# ScionPathWithMetrics


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fingerprint** | **str** | The fingerprint of the path. | 
**human** | **str** | Human readable representation of the SCION path. | 
**hops** | [**List[ScionPathHop]**](ScionPathHop.md) | List of individual hops on the SCION path. | 
**status** | **str** | Human readable description of the state of the path. | 
**next_hop** | **str** | Next hop is the address of the local SCION router to use. | 
**expiration** | **datetime** | Expiry specifies until when is the path valid. | 
**mtu** | **int** | MTU of the path. | 
**latency** | **float** | The latency of the path, in milliseconds. | 
**jitter** | **float** | The jitter of the path, in milliseconds. | 
**droprate** | **float** | The drop rate of the path, percent. | 
**throughput_pkts** | **float** | The outgoing throughput of the path in packets per second. | 
**throughput_bytes** | **float** | The outgoing throughput of the path in bytes per second. | 

## Example

```python
from anapaya.appliance.models.scion_path_with_metrics import ScionPathWithMetrics

# TODO update the JSON string below
json = "{}"
# create an instance of ScionPathWithMetrics from a JSON string
scion_path_with_metrics_instance = ScionPathWithMetrics.from_json(json)
# print the JSON string representation of the object
print ScionPathWithMetrics.to_json()

# convert the object into a dict
scion_path_with_metrics_dict = scion_path_with_metrics_instance.to_dict()
# create an instance of ScionPathWithMetrics from a dict
scion_path_with_metrics_form_dict = scion_path_with_metrics.from_dict(scion_path_with_metrics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


