# ConfigSCIONASCAService

SCION CPPKI (Control Plane Public Key Infrastructure) CA service configuration data. This section defines how the anapaya-scion interacts with the SCION CPPKI CA service backend. It is only required for SCION ASes that act as a CA in their respective ISD.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**anapaya_vault** | [**ConfigSCIONASCAServiceAnapayaVault**](ConfigSCIONASCAServiceAnapayaVault.md) |  | [optional] 
**external** | [**ConfigSCIONASCAServiceExternal**](ConfigSCIONASCAServiceExternal.md) |  | [optional] 
**service_type** | **str** | The type of CA service that is used by the appliance.  &#x60;EXTERNAL&#x60; is a generic CA backend not implemented by Anapaya. Note that the external CA backend must implement the [SCION CA API](https://github.com/scionproto/scion/blob/master/spec/ca/spec.yml) to be compatible with the Anapaya appliance. If this service type is used, the &#x60;external&#x60; section must be configured.  &#x60;ANAPAYA_VAULT&#x60; is the SCION CA backend provided by Anapaya. It is based on Hashicorp Vault with a suitable frontend. If this service type is used, the &#x60;anapaya_vault&#x60; section must be configured.  &#x60;IN_PROCESS&#x60; is a CA service that is implemented in the Anapaya appliance. It should only be used for testing purposes and is not suitable for productive use. If this service type is used, no other section needs to be configured.  | [optional] 

## Example

```python
from anapaya.appliance.models.config_scionasca_service import ConfigSCIONASCAService

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigSCIONASCAService from a JSON string
config_scionasca_service_instance = ConfigSCIONASCAService.from_json(json)
# print the JSON string representation of the object
print ConfigSCIONASCAService.to_json()

# convert the object into a dict
config_scionasca_service_dict = config_scionasca_service_instance.to_dict()
# create an instance of ConfigSCIONASCAService from a dict
config_scionasca_service_form_dict = config_scionasca_service.from_dict(config_scionasca_service_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


