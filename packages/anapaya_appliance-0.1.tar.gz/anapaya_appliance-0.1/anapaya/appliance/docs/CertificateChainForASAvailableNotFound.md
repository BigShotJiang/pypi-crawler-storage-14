# CertificateChainForASAvailableNotFound


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isd_as** | **str** |  | 
**data_type** | **str** |  | 

## Example

```python
from anapaya.appliance.models.certificate_chain_for_as_available_not_found import CertificateChainForASAvailableNotFound

# TODO update the JSON string below
json = "{}"
# create an instance of CertificateChainForASAvailableNotFound from a JSON string
certificate_chain_for_as_available_not_found_instance = CertificateChainForASAvailableNotFound.from_json(json)
# print the JSON string representation of the object
print CertificateChainForASAvailableNotFound.to_json()

# convert the object into a dict
certificate_chain_for_as_available_not_found_dict = certificate_chain_for_as_available_not_found_instance.to_dict()
# create an instance of CertificateChainForASAvailableNotFound from a dict
certificate_chain_for_as_available_not_found_form_dict = certificate_chain_for_as_available_not_found.from_dict(certificate_chain_for_as_available_not_found_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


