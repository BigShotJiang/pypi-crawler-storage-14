# MaxOrUnlimited

A maximum value or the string \"unlimited\". 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from anapaya.appliance.models.max_or_unlimited import MaxOrUnlimited

# TODO update the JSON string below
json = "{}"
# create an instance of MaxOrUnlimited from a JSON string
max_or_unlimited_instance = MaxOrUnlimited.from_json(json)
# print the JSON string representation of the object
print MaxOrUnlimited.to_json()

# convert the object into a dict
max_or_unlimited_dict = max_or_unlimited_instance.to_dict()
# create an instance of MaxOrUnlimited from a dict
max_or_unlimited_form_dict = max_or_unlimited.from_dict(max_or_unlimited_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


