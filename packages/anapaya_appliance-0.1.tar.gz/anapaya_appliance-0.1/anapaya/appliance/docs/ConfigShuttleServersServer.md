# ConfigShuttleServersServer

List of Shuttle server configurations.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | The IPv4/IPv6 address of the tunnel with a CIDR mask. | [optional] 
**advertised_routes** | **List[str]** | A list of IPv4/IPv6 addresses with a CIDR mask. The prefixes in the list are advertised to all connected clients. Subsequently, the clients route all traffic to these prefixes via the shuttle server. Must be in the same family as the tunnel address. If empty, it is by default equal to allowed_destinations. It must not be empty if shuttle traffic is NATed. Catch all are expressed as 0.0.0.0/0 (IPv4) and ::/0 (IPv6) | [optional] 
**allowed_destinations** | **List[str]** | A list of IPv4/IPv6 addresses with a CIDR mask. The list indicates the networks that are reachable through the Shuttle server. All other destinations are disallowed. Must be in the same family as local tunnel address. The list is used to configure firewall forwarding rules on the appliance. Catch all are expressed as 0.0.0.0/0 (IPv4) and ::/0 (IPv6) | [optional] 
**clients** | [**List[ConfigShuttleServersServerClient]**](ConfigShuttleServersServerClient.md) | The list of Shuttle clients. | [optional] 
**endpoint** | **str** | The endpoint address on which the server is listening for connection requests from Shuttle clients. In two alternative forms &#x60;[ISD-AS,IP]:port&#x60;, or &#x60;IP:port&#x60;, where &#x60;ISD-AS&#x60; is an ISD-AS number, &#x60;IP&#x60; is an IPv4/IPv6 address | [optional] 
**mtu** | **int** | The MTU (Maximum Transmission Unit) to be used on the shuttle interface. The user usually does not need to change this default value. The value is chosen to work in extreme circumstances. | [optional] [default to 1000]
**name** | **str** | The name of the network interface. | [optional] 

## Example

```python
from anapaya.appliance.models.config_shuttle_servers_server import ConfigShuttleServersServer

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigShuttleServersServer from a JSON string
config_shuttle_servers_server_instance = ConfigShuttleServersServer.from_json(json)
# print the JSON string representation of the object
print ConfigShuttleServersServer.to_json()

# convert the object into a dict
config_shuttle_servers_server_dict = config_shuttle_servers_server_instance.to_dict()
# create an instance of ConfigShuttleServersServer from a dict
config_shuttle_servers_server_form_dict = config_shuttle_servers_server.from_dict(config_shuttle_servers_server_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


