# ConfigSystemVppStatseg

Statseg configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**size** | **str** | The size of the statseg segment. This can be specified in bytes with a suffix of kilo &#39;K&#39;, mega &#39;M&#39;, or giga &#39;G&#39;. WARNING: Changing this value causes the dataplane to restart and therefore interrupts traffic. | [optional] [default to '32M']

## Example

```python
from anapaya.appliance.models.config_system_vpp_statseg import ConfigSystemVppStatseg

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigSystemVppStatseg from a JSON string
config_system_vpp_statseg_instance = ConfigSystemVppStatseg.from_json(json)
# print the JSON string representation of the object
print ConfigSystemVppStatseg.to_json()

# convert the object into a dict
config_system_vpp_statseg_dict = config_system_vpp_statseg_instance.to_dict()
# create an instance of ConfigSystemVppStatseg from a dict
config_system_vpp_statseg_form_dict = config_system_vpp_statseg.from_dict(config_system_vpp_statseg_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


