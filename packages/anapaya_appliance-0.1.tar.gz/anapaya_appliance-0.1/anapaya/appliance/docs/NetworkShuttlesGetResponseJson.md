# NetworkShuttlesGetResponseJson


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shuttle_clients** | [**List[NetworkShuttleGetResponseJson]**](NetworkShuttleGetResponseJson.md) |  | 

## Example

```python
from anapaya.appliance.models.network_shuttles_get_response_json import NetworkShuttlesGetResponseJson

# TODO update the JSON string below
json = "{}"
# create an instance of NetworkShuttlesGetResponseJson from a JSON string
network_shuttles_get_response_json_instance = NetworkShuttlesGetResponseJson.from_json(json)
# print the JSON string representation of the object
print NetworkShuttlesGetResponseJson.to_json()

# convert the object into a dict
network_shuttles_get_response_json_dict = network_shuttles_get_response_json_instance.to_dict()
# create an instance of NetworkShuttlesGetResponseJson from a dict
network_shuttles_get_response_json_form_dict = network_shuttles_get_response_json.from_dict(network_shuttles_get_response_json_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


