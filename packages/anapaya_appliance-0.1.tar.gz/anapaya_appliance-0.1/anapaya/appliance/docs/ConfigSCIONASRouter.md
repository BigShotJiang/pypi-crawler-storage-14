# ConfigSCIONASRouter

The configuration for the SCION router service. The address configures where the router is exposed. AS internal hosts send SCION data plane traffic to this address for forwarding over the local SCION interfaces.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** | Whether the service is enabled. | 
**internal_interface** | **str** | The internal SCION interface is where the appliance receives SCION packets from AS internal hosts/applications for forwarding. It is defined as a UDP/IP network endpoint on which the SCION packets are received from the internal network. The endpoint must be specified as a string in the format &lt;ip&gt;:&lt;port&gt;. If the port is set to 0 it will be automatically assigned. | [optional] 

## Example

```python
from anapaya.appliance.models.config_scionas_router import ConfigSCIONASRouter

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigSCIONASRouter from a JSON string
config_scionas_router_instance = ConfigSCIONASRouter.from_json(json)
# print the JSON string representation of the object
print ConfigSCIONASRouter.to_json()

# convert the object into a dict
config_scionas_router_dict = config_scionas_router_instance.to_dict()
# create an instance of ConfigSCIONASRouter from a dict
config_scionas_router_form_dict = config_scionas_router.from_dict(config_scionas_router_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


