# ConfigSCIONAS

SCION AS

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ca_service** | [**ConfigSCIONASCAService**](ConfigSCIONASCAService.md) |  | [optional] 
**control** | [**ConfigSCIONASControl**](ConfigSCIONASControl.md) |  | [optional] 
**core** | **bool** | Indicate whether the AS is core in its ISD. The &#x60;core&#x60; flag must only be set if the AS is a core AS in its ISD (as indicated in the TRC of the ISD). A core AS provides connectivity to other SCION ISDs and operates the main path directories within its ISD. It also regularly initiates path construction beacons that create path segments to other SCION ASes in the same ISD or to other core ASes in different ISDs. For most of the ASes this is not the case and the flag must be set to &#x60;false&#x60; or not specified (defaults to &#x60;false&#x60;) | [optional] [default to False]
**cppki** | [**ConfigSCIONASCPPKI**](ConfigSCIONASCPPKI.md) |  | [optional] 
**default** | **bool** | Default indicates whether the respective SCION AS should be used by default as the source AS by SCION applications, e.g., &#x60;scion ping&#x60; or &#x60;scion showpaths&#x60;. The configurations with more than one default ASes will be rejected because there can only be one default AS. If there is only a single AS configured, it will be the default. Therefore, this setting is only necessary if multiple ASes are configured on the appliance. | [optional] [default to False]
**details** | [**ConfigSCIONASDetails**](ConfigSCIONASDetails.md) |  | [optional] 
**forwarding_key_ref** | **str** | Reference to the forwarding key of this AS. The forwarding key secret is used to authenticate the hop field of the SCION path which corresponds to this AS. It is a local secret that only needs to be known to the AS. The forwarding key MUST be identical across all appliances in an AS. The referenced secret must be a base64-encoded string. | [optional] 
**isd_as** | **str** | The ISD-AS identifier is the tuple that uniquely identifies the AS within a SCION isolation domain (ISD). This number is usually assigned by a numbering authority. | 
**neighbors** | [**List[ConfigSCIONASNeighbor]**](ConfigSCIONASNeighbor.md) | List of neighbor SCION ASes that this device is connected to via one or multiple SCION interfaces. Each entry is identified by the remote ISD-AS. | [optional] 
**router** | [**ConfigSCIONASRouter**](ConfigSCIONASRouter.md) |  | [optional] 
**scion_mtu** | **int** | The maximum transmission unit in bytes for SCION packets. This represents the protocol data unit (PDU) of the SCION layer on this interface and is usually calculated as maximum Ethernet payload - IP Header - UDP Header. If the Ethernet MTU is 1500, the SCION MTU is 1472 for an IPv4 underlay network and 1452 for an IPv6 underlay network. | [optional] [default to 1472]
**shard_id** | **int** | The control and the data plane of a SCION AS is split into multiple shards. Each shard is responsible for processing and disseminating path information only for a subset of links. Shards are units that operate and fail independently from other shards. Usually, each appliance operates as a separate shard to increase the resiliency of the network. This field is the ID of the shard to which the control service and the router on this appliance belong. | [optional] 

## Example

```python
from anapaya.appliance.models.config_scionas import ConfigSCIONAS

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigSCIONAS from a JSON string
config_scionas_instance = ConfigSCIONAS.from_json(json)
# print the JSON string representation of the object
print ConfigSCIONAS.to_json()

# convert the object into a dict
config_scionas_dict = config_scionas_instance.to_dict()
# create an instance of ConfigSCIONAS from a dict
config_scionas_form_dict = config_scionas.from_dict(config_scionas_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


