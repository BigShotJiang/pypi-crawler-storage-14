# ConfigManagementApiInterface

List of interfaces on which API listeners should be exposed. Use this only if the interface address is unknown at configuration time, i.e., it is assigned dynamically.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** | Description, or comment, for the interface. | [optional] 
**name** | **str** | Network interface name to listen on. | [optional] 
**port** | **int** | The TCP or UDP port to listen on. | [optional] 

## Example

```python
from anapaya.appliance.models.config_management_api_interface import ConfigManagementApiInterface

# TODO update the JSON string below
json = "{}"
# create an instance of ConfigManagementApiInterface from a JSON string
config_management_api_interface_instance = ConfigManagementApiInterface.from_json(json)
# print the JSON string representation of the object
print ConfigManagementApiInterface.to_json()

# convert the object into a dict
config_management_api_interface_dict = config_management_api_interface_instance.to_dict()
# create an instance of ConfigManagementApiInterface from a dict
config_management_api_interface_form_dict = config_management_api_interface.from_dict(config_management_api_interface_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


