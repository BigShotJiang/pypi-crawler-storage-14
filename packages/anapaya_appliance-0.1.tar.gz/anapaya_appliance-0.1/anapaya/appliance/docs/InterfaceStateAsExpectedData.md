# InterfaceStateAsExpectedData

The interface state is as configured. The interface's state corresponds to the admin state of the interface. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**interface** | **str** | Name of the interface. | 
**admin_up** | **bool** | The admin up state of the interface as reported by the system.  | 
**expected_admin_up** | **bool** | The expected admin up state of the interface.  | 
**carrier_up** | **bool** | The carrier up state of the interface as reported by the system.  | 

## Example

```python
from anapaya.appliance.models.interface_state_as_expected_data import InterfaceStateAsExpectedData

# TODO update the JSON string below
json = "{}"
# create an instance of InterfaceStateAsExpectedData from a JSON string
interface_state_as_expected_data_instance = InterfaceStateAsExpectedData.from_json(json)
# print the JSON string representation of the object
print InterfaceStateAsExpectedData.to_json()

# convert the object into a dict
interface_state_as_expected_data_dict = interface_state_as_expected_data_instance.to_dict()
# create an instance of InterfaceStateAsExpectedData from a dict
interface_state_as_expected_data_form_dict = interface_state_as_expected_data.from_dict(interface_state_as_expected_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


