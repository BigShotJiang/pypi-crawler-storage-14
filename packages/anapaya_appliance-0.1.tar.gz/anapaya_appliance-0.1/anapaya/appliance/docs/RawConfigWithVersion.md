# RawConfigWithVersion


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **Dict[str, object]** |  | [optional] 
**version** | **int** | The version of the configuration. | 

## Example

```python
from anapaya.appliance.models.raw_config_with_version import RawConfigWithVersion

# TODO update the JSON string below
json = "{}"
# create an instance of RawConfigWithVersion from a JSON string
raw_config_with_version_instance = RawConfigWithVersion.from_json(json)
# print the JSON string representation of the object
print RawConfigWithVersion.to_json()

# convert the object into a dict
raw_config_with_version_dict = raw_config_with_version_instance.to_dict()
# create an instance of RawConfigWithVersion from a dict
raw_config_with_version_form_dict = raw_config_with_version.from_dict(raw_config_with_version_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


