# Steps to build and publish the anapaya-appliance package to PyPI

```bash
# 1. Build the package using Bazel in the SCION repository
bazel build //anapaya/appliance/api/public:api_client
# 2. Copy the generated package to the appliance-py repository
cp -r bazel-bin/anapaya/appliance/api/public/api_client/anapaya/ ../appliance-py/.
cp -r bazel-bin/anapaya/appliance/api/public/api_client/anapaya/appliance_README.md ../appliance-py/README.md
# 3. Navigate to the appliance-py repository
cd ../appliance-py/
# 4. Ensure correct file permissions
find . -type f -exec chmod 0644 {} +
find . -type d -exec chmod 0755 {} +
rm anapaya/appliance_README.md
# 4. Adapt dependencies in pyproject.toml if needed
# (Make sure the dependencies match the requirements of the generated code)
# 5. Adapt version in pyproject.toml if needed
# 6. Build the distribution packages
# Clean previous builds
rm -r dist/*
python3 -m build --sdist --wheel
# 7. Upload the packages to TestPyPI for testing
python3 -m twine upload --repository testpypi dist/*
# 8. Once verified, upload the packages to the official PyPI
python3 -m twine upload --repository pypi dist/*
```
