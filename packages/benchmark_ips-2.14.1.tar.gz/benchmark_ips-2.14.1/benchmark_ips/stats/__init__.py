"""Statistics modules for benchmark-ips."""

from .stats_metric import StatsMetric
from .sd import SD

__all__ = ['StatsMetric', 'SD']
