"""Tests for benchmark-ips."""
