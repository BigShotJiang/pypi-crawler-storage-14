# Credits

## Original Work

**benchmark-ips** (Ruby version)
- **Author:** Evan Phoenix
- **Repository:** https://github.com/evanphx/benchmark-ips
- **License:** MIT License (2015)
- **Contributors:** Many contributors to the Ruby gem

The original Ruby implementation has been invaluable to the Ruby community for performance benchmarking since 2012.

## Python Port

**benchmark-ips** (Python port)
- **Author:** Igor <igor@igorstechnoclub.com>
- **Port Date:** November 2025
- **Repository:** https://github.com/gogainda/benchmark-ips-python
- **License:** MIT License (maintaining compatibility with original)

### Translation Approach

This Python port was created to bring the excellent benchmark-ips functionality to the Python ecosystem. The port:

1. **Maintains API compatibility** where possible
2. **Preserves the original's design philosophy**
3. **Adds Python-specific enhancements** (e.g., context managers)
4. **Keeps the same MIT License** for maximum compatibility

### Acknowledgments

- **Evan Phoenix** and all Ruby benchmark-ips contributors for the original implementation
- The **Ruby community** for proving the value of this benchmarking approach
- **Claude AI** (Anthropic) for assistance in creating this Python translation

### Differences from Ruby Version

While maintaining functional parity, this Python port includes:
- Context manager support (`with` statement)
- Pythonic naming conventions
- Type-ready structure for future type hints
- pytest-based test suite

### Contributing

If you'd like to contribute to this Python port:
1. Ensure changes maintain compatibility with the original's spirit
2. Follow Python conventions (PEP 8)
3. Include tests for new features
4. Update documentation

### Relationship to Original

This is an **independent port** and **derivative work** of the original Ruby gem. While it maintains functional compatibility, it is a separate implementation in Python.

For the original Ruby version, please visit:
https://github.com/evanphx/benchmark-ips

---

**Thank you to the entire Ruby and Python communities for making open-source software possible!**
