from setuptools import setup, find_packages

setup(
    name="schemaguard",
    version="0.1.0",
    author="Inzamam Yousaf",
    author_email="uniprecisionofficial@gmail.com",
    description="Lightweight DataFrame Schema Validator",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/inzamam1121/schemaguard",
    packages=find_packages(exclude=["examples*", "tests*"]),
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.0",
        "pyyaml>=6.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
