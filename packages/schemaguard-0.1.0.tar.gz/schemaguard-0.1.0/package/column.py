from dataclasses import dataclass
from typing import Optional, Any


@dataclass
class Column:
    name: str
    dtype: Any  # python type like int, float, str, bool
    not_null: bool = False
    unique: bool = False
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    regex: Optional[str] = None

    def __repr__(self):
        return (
            f"Column(name={self.name!r}, dtype={self.dtype}, not_null={self.not_null}, "
            f"unique={self.unique}, min={self.min_value}, max={self.max_value}, regex={self.regex})"
        )
