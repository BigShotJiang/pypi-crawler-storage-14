"""
This module contains the formatter for the CLI.
"""
