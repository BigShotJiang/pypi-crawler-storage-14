"""Backward compatible wrapper"""
from .gcp import GCPStorageWorker
__all__ = ['GCPStorageWorker']
