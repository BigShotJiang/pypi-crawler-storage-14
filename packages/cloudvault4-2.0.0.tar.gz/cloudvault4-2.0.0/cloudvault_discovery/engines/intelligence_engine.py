"""Backward compatible wrapper"""
from .intelligence import ThreatIntelligence
__all__ = ["ThreatIntelligence"]
