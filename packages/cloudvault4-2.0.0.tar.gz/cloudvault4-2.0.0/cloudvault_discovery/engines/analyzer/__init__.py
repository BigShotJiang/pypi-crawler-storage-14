"""Code Analyzer Module"""
from .main_analyzer import CodeAnalyzer

__all__ = ['CodeAnalyzer']
