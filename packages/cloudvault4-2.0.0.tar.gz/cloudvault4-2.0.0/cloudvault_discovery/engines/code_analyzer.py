"""
Backward compatible wrapper for code_analyzer module
"""
from .analyzer import CodeAnalyzer

__all__ = ['CodeAnalyzer']
