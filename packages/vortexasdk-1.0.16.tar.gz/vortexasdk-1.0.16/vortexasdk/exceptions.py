class InvalidAPIDataResponseException(Exception):
    """Vortexa API returned Faulty Data, contact support."""

    pass
