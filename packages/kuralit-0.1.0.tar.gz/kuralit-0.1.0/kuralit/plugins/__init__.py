"""Plugin system for KuralIt."""

__all__ = []

