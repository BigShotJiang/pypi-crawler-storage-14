"""Testing utilities for WebSocket server."""

