"""KuralIt Agent - Standalone agent system."""

from kuralit.agent.agent import Agent

__all__ = ["Agent"]

