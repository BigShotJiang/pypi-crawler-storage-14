API Documentation
=================


Channel:
--------
.. automodule:: sensirion_driver_adapters.channel
   :members:

I2C-Channel
-----------
.. automodule:: sensirion_driver_adapters.i2c_adapter.i2c_channel
   :members:

SHDLC-Channel
-------------
.. automodule:: sensirion_driver_adapters.shdlc_adapter.shdlc_channel
   :members:


Transfer:
---------
.. automodule:: sensirion_driver_adapters.transfer
   :members:

Multi-Device Support:
---------------------
.. automodule:: sensirion_driver_adapters.multi_device_support

Multi-channel SensorBridge:
.. automodule:: sensirion_driver_adapters.multi_sensor_bridge

