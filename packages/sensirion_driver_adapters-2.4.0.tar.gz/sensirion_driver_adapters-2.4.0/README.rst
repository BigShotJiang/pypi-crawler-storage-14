sensirion-i2c-adapter
=====================

Install
-------
.. sourcecode:: bash

    pip install sensirion-driver-adapters

Recommended usage is within a virtualenv.

Usage
-----
.. sourcecode:: python

    import sensirion_driver_adapters
