"""Markov Chain Password Generator"""

__version__ = "1.0.0"
