"""Configuration package"""
