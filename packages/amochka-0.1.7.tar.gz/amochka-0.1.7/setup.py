from pathlib import Path
from setuptools import setup, find_packages

README = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name='amochka',
    version='0.1.7',
    package_dir={"": "amochka"},
    packages=find_packages(where="amochka"),
    install_requires=[
         'requests',
         'ratelimit'
    ],
    author='Timurka',
    author_email='timurdt@gmail.com',
    description='Библиотека для работы с API amoCRM',
    long_description=README,
    long_description_content_type='text/markdown',
    url='',  # Укажите ваш URL репозитория
    classifiers=[
         'Programming Language :: Python :: 3',
         'License :: OSI Approved :: MIT License',
         'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
