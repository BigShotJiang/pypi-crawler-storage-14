"""
Sentinel CLI - Command-line interface for the Sentinel Knowledge Graph
"""

import asyncio
import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()
app = typer.Typer(
    name="sentinel",
    help="🛡️ Sentinel - Self-Healing Temporal Knowledge Graph",
    add_completion=False,
)


@app.command()
def version():
    """Show Sentinel version."""
    console.print("[cyan]Sentinel v0.1.0[/cyan]")
    console.print("[dim]Self-Healing Temporal Knowledge Graph[/dim]")


@app.command()
def status():
    """📊 Show Sentinel system status."""
    from dotenv import load_dotenv
    load_dotenv()
    
    from sentinel_core import GraphManager
    from sentinel_core.scraper import print_scraper_status
    
    console.print(Panel.fit(
        "[bold cyan]🛡️ Sentinel System Status[/bold cyan]",
        border_style="cyan"
    ))
    
    # Check Neo4j
    console.print("\n[bold]Database Connection:[/bold]")
    try:
        graph_manager = GraphManager()
        graph_manager.verify_connectivity()
        console.print("[green]✅ Neo4j connected[/green]")
        
        snapshot = graph_manager.get_graph_snapshot()
        console.print(f"  Nodes: [cyan]{snapshot['metadata']['node_count']}[/cyan]")
        console.print(f"  Edges: [cyan]{snapshot['metadata']['link_count']}[/cyan]")
        
        graph_manager.close()
    except Exception as e:
        console.print(f"[red]❌ Neo4j connection failed: {str(e)}[/red]")
    
    # Check scraper
    console.print("\n[bold]Scraper Status:[/bold]")
    print_scraper_status()
    
    # Check LLM
    console.print("\n[bold]LLM Configuration:[/bold]")
    model = os.getenv("OLLAMA_MODEL", "Not configured")
    console.print(f"  Model: [cyan]{model}[/cyan]")
    
    if "ollama" in model.lower():
        base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        console.print(f"  Ollama URL: [cyan]{base_url}[/cyan]")


@app.command()
def watch(
    url: str = typer.Argument(..., help="URL to process"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output")
):
    """👁️ Process a URL through the Sentinel pipeline."""
    from dotenv import load_dotenv
    load_dotenv()
    
    from sentinel_core import GraphManager, GraphExtractor, Sentinel
    from sentinel_core.scraper import get_scraper
    
    console.print(Panel.fit(
        f"[bold cyan]Processing URL[/bold cyan]\n{url}",
        border_style="cyan"
    ))
    
    async def process():
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Initializing Sentinel...", total=None)
                
                graph_manager = GraphManager()
                scraper = get_scraper()
                extractor = GraphExtractor(
                    model_name=os.getenv("OLLAMA_MODEL", "ollama/llama3")
                )
                sentinel = Sentinel(graph_manager, scraper, extractor)
                
                progress.update(task, completed=True)
            
            console.print(f"[dim]Using scraper: {scraper.get_name()}[/dim]")
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task(f"Processing {url}...", total=None)
                result = await sentinel.process_url(url)
                progress.update(task, completed=True)
            
            if result["status"] == "success":
                console.print("\n[bold green]✅ Success![/bold green]")
                console.print(f"  Extracted [cyan]{result.get('extracted_nodes', 0)}[/cyan] nodes")
                console.print(f"  Extracted [cyan]{result.get('extracted_edges', 0)}[/cyan] edges")
                console.print(f"  Content hash: [dim]{result.get('hash', 'N/A')[:16]}...[/dim]")
            elif result["status"] == "unchanged_verified":
                console.print("\n[yellow]ℹ️  Content unchanged[/yellow]")
                console.print(f"  Verified [cyan]{result.get('edges_updated', 0)}[/cyan] existing edges")
            else:
                console.print(f"\n[red]❌ Error: {result.get('error', 'Unknown error')}[/red]")
            
            if verbose and "stats" in result:
                console.print(f"\n[dim]Stats: {result['stats']}[/dim]")
            
            graph_manager.close()
            
        except Exception as e:
            console.print(f"\n[red]❌ Error: {str(e)}[/red]")
            if verbose:
                import traceback
                console.print(f"[dim]{traceback.format_exc()}[/dim]")
            raise typer.Exit(1)
    
    asyncio.run(process())


def main():
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
