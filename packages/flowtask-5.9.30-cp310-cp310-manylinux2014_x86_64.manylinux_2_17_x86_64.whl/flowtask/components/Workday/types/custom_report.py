"""
Generic type handler for Workday RaaS (Reports as a Service) custom reports.

This handler can execute ANY Workday custom report without requiring
specific type implementations. It uses dynamic parameter passing and
automatic DataFrame generation from JSON responses.
"""
from typing import Optional, Dict, Any
import pandas as pd
from urllib.parse import urlencode

from .base import WorkdayTypeBase
from ..utils import safe_serialize
from ....interfaces.http import HTTPService


class CustomReportType(WorkdayTypeBase):
    """
    Generic handler for ANY Workday RaaS custom report.

    This type can execute any Workday custom report by accepting:
    - report_name: The name of the report in Workday
    - report_owner: The email/ID of the report owner (optional, uses default)
    - **query_params: Any report-specific parameters

    The handler automatically:
    - Builds the correct RaaS URL
    - Authenticates with Basic Auth
    - Converts JSON response to DataFrame with automatic column detection
    - Handles nested structures appropriately

    Example usage:
        # Time blocks report
        df = await custom_report.execute(
            report_name="Extract_Time_Blocks_-_Navigator",
            Start_Date="2025-11-17",
            End_Date="2025-11-17",
            Worker="12345"
        )

        # Different report with different parameters
        df = await custom_report.execute(
            report_name="Absence_Calendar_Report",
            Year="2025",
            Month="11"
        )
    """

    def __init__(self, component):
        super().__init__(component)
        # Initialize HTTP client for REST API access
        self._http_client = None

    def _build_raas_url(
        self,
        report_name: str,
        report_owner: Optional[str] = None,
        query_params: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Build the RaaS (Reports as a Service) REST API URL.

        URL pattern:
        https://<workday-url>/ccx/service/customreport2/<tenant>/<owner>/<report_name>?<params>

        Args:
            report_name: Name of the report (e.g., "Extract_Time_Blocks_-_Navigator")
            report_owner: Email of report owner (defaults to configured owner)
            query_params: Dictionary of query parameters for the report

        Returns:
            Full URL for the RaaS REST API request
        """
        # Get configuration from component
        tenant = getattr(self.component, 'tenant', 'troc')
        owner = report_owner or getattr(
            self.component,
            'report_owner',
            'jleon@trocglobal.com'
        )
        workday_url = getattr(
            self.component,
            'workday_url',
            'https://services1.wd501.myworkday.com'
        )

        # Construct base URL
        # RaaS endpoint pattern: /ccx/service/customreport2/<tenant>/<owner>/<report_name>
        url = f"{workday_url}/ccx/service/customreport2/{tenant}/{owner}/{report_name}"

        # Add query parameters if provided
        if query_params:
            # Always request JSON format
            params = {"format": "json", **query_params}
            query_string = urlencode(params, safe='@')
            url = f"{url}?{query_string}"
        else:
            url = f"{url}?format=json"

        return url

    async def execute(
        self,
        report_name: str,
        report_owner: Optional[str] = None,
        **query_params
    ) -> pd.DataFrame:
        """
        Execute any Workday RaaS custom report.

        This method accepts the report name and any report-specific parameters.
        It automatically handles authentication, request execution, and
        DataFrame conversion.

        Args:
            report_name: Name of the report in Workday (required)
            report_owner: Email/ID of report owner (optional, uses default from config)
            **query_params: Any report-specific parameters (e.g., Start_Date, Worker, etc.)

        Returns:
            DataFrame with automatic column detection from JSON response

        Example:
            df = await custom_report.execute(
                report_name="Extract_Time_Blocks_-_Navigator",
                Start_Date="2025-11-17",
                End_Date="2025-11-17",
                Worker="12345"
            )
        """
        # Build the RaaS URL with all parameters
        url = self._build_raas_url(report_name, report_owner, query_params)

        self._logger.info(f"Executing custom report: {report_name}")
        self._logger.debug(f"RaaS URL: {url}")

        # Initialize HTTP client if needed
        if self._http_client is None:
            # Get credentials from component
            username = getattr(
                self.component,
                'report_username',
                None
            )
            password = getattr(
                self.component,
                'report_password',
                None
            )

            if not username or not password:
                raise ValueError(
                    "Custom report credentials not configured. "
                    "Set WORKDAY_REPORT_USERNAME and WORKDAY_REPORT_PASSWORD"
                )

            # Create HTTP client with Basic Auth
            self._http_client = HTTPService(
                credentials={
                    "username": username,
                    "password": password
                },
                auth_type="basic",
                accept="application/json",
                timeout=60
            )
            # Set logger for HTTP client
            self._http_client._logger = self._logger

        # Execute the REST API request
        try:
            result, error = await self._http_client.async_request(
                url=url,
                method="GET",
                accept="application/json"
            )

            if error:
                self._logger.error(f"Error fetching custom report: {error}")
                raise Exception(f"Failed to fetch custom report: {error}")

            if not result:
                self._logger.warning("Empty response from custom report")
                return pd.DataFrame()

        except Exception as exc:
            self._logger.error(f"Error executing custom report via REST: {exc}")
            raise

        # Parse the JSON response
        # RaaS returns JSON data directly with Report_Entry structure
        raw_response = []
        if isinstance(result, dict):
            # Check for Report_Entry structure (standard RaaS format)
            # Try multiple possible locations
            if "Report_Entry" in result:
                report_entries = result["Report_Entry"]
            elif "Report_Data" in result:
                report_data = result["Report_Data"]
                report_entries = report_data.get("Report_Entry", [])
            else:
                # If no standard structure, try to use the result itself
                report_entries = result

            if not isinstance(report_entries, list):
                report_entries = [report_entries] if report_entries else []
            raw_response = report_entries
        elif isinstance(result, list):
            # Direct list of entries
            raw_response = result

        if not raw_response:
            self._logger.warning("No report entries found in response")
            return pd.DataFrame()

        # Convert to DataFrame directly from JSON
        # Use json_normalize to automatically flatten nested structures
        df = pd.json_normalize(
            raw_response,
            sep='_',
            max_level=None  # Flatten all levels
        )

        # Handle array fields that couldn't be flattened
        # These will be serialized to JSON strings for DataFrame compatibility
        for col in df.columns:
            if df[col].dtype == 'object':
                # Check if column contains lists of dicts (complex nested structures)
                non_null = df[col].dropna()
                sample = non_null.iloc[0] if not non_null.empty else None
                if isinstance(sample, list):
                    # Serialize arrays to JSON strings
                    df[col] = df[col].apply(
                        lambda x: safe_serialize(x) if isinstance(x, list) else x
                    )

        self._logger.info(
            f"Retrieved {len(df)} entries from custom report '{report_name}' "
            f"with {len(df.columns)} columns"
        )

        return df
