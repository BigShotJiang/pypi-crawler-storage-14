"""
CSYSHODAN - Python Utility for Shodan API Code Generation
A simple utility package to print Shodan API code templates.
"""

from .csy_printer import print_csy

__version__ = "0.1.0"
__all__ = ['print_csy']

