import unittest
from src.shodan_client import ShodanClient

class TestShodanClient(unittest.TestCase):

    def setUp(self):
        self.client = ShodanClient(api_key='test_api_key')

    def test_search(self):
        query = 'apache'
        results = self.client.search(query)
        self.assertIsInstance(results, dict)
        self.assertIn('matches', results)

    def test_get_results(self):
        sample_data = {
            'matches': [
                {'ip_str': '1.1.1.1', 'port': 80},
                {'ip_str': '2.2.2.2', 'port': 443}
            ]
        }
        processed_results = self.client.get_results(sample_data)
        self.assertEqual(len(processed_results), 2)
        self.assertIn('ip_str', processed_results[0])
        self.assertIn('port', processed_results[0])

if __name__ == '__main__':
    unittest.main()