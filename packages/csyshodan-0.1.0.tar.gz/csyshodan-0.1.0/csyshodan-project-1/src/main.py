# main.py

from shodan_client import ShodanClient

def main():
    # Initialize the Shodan client
    shodan_client = ShodanClient()

    # Example of user input handling
    while True:
        query = input("Enter your search query (or 'exit' to quit): ")
        if query.lower() == 'exit':
            break
        
        try:
            results = shodan_client.search(query)
            print("Search results:")
            for result in results:
                print(result)
        except Exception as e:
            print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()