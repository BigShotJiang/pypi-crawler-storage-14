class ShodanClient:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.shodan.io"

    def search(self, query):
        import requests
        
        url = f"{self.base_url}/shodan/host/search?key={self.api_key}&query={query}"
        response = requests.get(url)
        
        if response.status_code == 200:
            return response.json()
        else:
            response.raise_for_status()

    def get_results(self, search_response):
        return search_response.get('matches', [])
