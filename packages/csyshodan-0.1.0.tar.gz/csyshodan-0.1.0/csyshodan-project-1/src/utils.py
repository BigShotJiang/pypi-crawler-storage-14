def format_data(data):
    # Function to format data for output
    return str(data)

def handle_error(error):
    # Function to handle errors
    print(f"An error occurred: {error}")

def validate_input(input_data):
    # Function to validate user input
    if not input_data:
        raise ValueError("Input cannot be empty")
    return input_data.strip()