# CSYSHODAN

**Python Utility for Shodan API Code Generation**

A simple utility package that helps you quickly print Shodan API code templates with examples.

## Installation

```bash
pip install csyshodan
```

## Usage

After installing, simply import and use the `print_csy` function:

```python
from csyshodan import print_csy

# Print Shodan API code template
print_csy()
```

## What it does

The `print_csy()` function prints a ready-to-use Shodan API code template, including:

- Shodan API client initialization
- Search functionality example
- Error handling
- Result parsing and display
- Complete working code template

## Example Output

```python
from csyshodan import print_csy
print_csy()

# Output:
# from shodan import Shodan
# 
# # Replace with your Shodan API key
# API_KEY = "YOUR_API_KEY"
# 
# def shodan_search(query):
#     api = Shodan(API_KEY)
#     ...
```

## Requirements

- Python 3.7 or higher

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Author

Your Name

## Version

0.1.0
