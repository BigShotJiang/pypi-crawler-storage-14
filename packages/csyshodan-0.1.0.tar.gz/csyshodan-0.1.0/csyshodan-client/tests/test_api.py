import unittest
from csyshodan_client.api import CsyshodanAPI

class TestCsyshodanAPI(unittest.TestCase):

    def setUp(self):
        self.api = CsyshodanAPI()

    def test_get_data(self):
        response = self.api.get_data()
        self.assertIsNotNone(response)
        # Add more assertions based on expected response structure

    def test_search(self):
        query = "example search"
        response = self.api.search(query)
        self.assertIsNotNone(response)
        # Add more assertions based on expected response structure

    def test_fetch_details(self):
        item_id = "12345"
        response = self.api.fetch_details(item_id)
        self.assertIsNotNone(response)
        # Add more assertions based on expected response structure

if __name__ == '__main__':
    unittest.main()