def format_response(response):
    # Function to format the API response
    return response.json()

def handle_errors(response):
    # Function to handle errors from the API response
    if response.status_code != 200:
        raise Exception(f"Error: {response.status_code} - {response.text}")

# Additional utility functions can be added here as needed.