"""
Setup configuration for CSYSHODAN package.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="csyshodan",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Python Utility for Shodan API - Print Shodan API code templates",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/csyshodan",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.7",
    keywords="shodan, api, security, utilities, code generation",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/csyshodan/issues",
        "Source": "https://github.com/yourusername/csyshodan",
        "Documentation": "https://github.com/yourusername/csyshodan#readme",
    },
)

