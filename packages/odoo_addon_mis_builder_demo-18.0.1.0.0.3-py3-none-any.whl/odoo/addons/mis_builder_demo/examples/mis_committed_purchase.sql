-- pylint: skip-file
CREATE OR REPLACE VIEW mis_committed_purchase AS (
    SELECT ROW_NUMBER() OVER() AS id, mis_committed_purchase.* FROM (

        WITH currency_rate as (
            SELECT
              r.currency_id,
              COALESCE(r.company_id, c.id) as company_id,
              r.rate,
              r.name AS date_start,
              (SELECT name FROM res_currency_rate r2
              WHERE r2.name > r.name AND
                    r2.currency_id = r.currency_id AND
                    (r2.company_id is null or r2.company_id = c.id)
               ORDER BY r2.name ASC
               LIMIT 1) AS date_end
            FROM res_currency_rate r
              JOIN res_company c ON (r.company_id is null or r.company_id = c.id)
        )

    /* UNINVOICED PURCHASES */
    SELECT
        'uninvoiced purchase' AS line_type,
        pol.company_id AS company_id,
        pol.name AS name,
        po.date_planned::date as date,
        pol.id AS res_id,
        'purchase.order.line' AS res_model,
        CASE
          WHEN (pt.property_account_expense_id->>(pol.company_id::TEXT)) IS NOT NULL THEN (pt.property_account_expense_id->>(pol.company_id::TEXT))::INTEGER
          WHEN (pc.property_account_expense_categ_id->>(pol.company_id::TEXT)) IS NOT NULL THEN (pc.property_account_expense_categ_id->>(pol.company_id::TEXT))::INTEGER
          ELSE cast(NULL AS INTEGER)
        END AS account_id,
        CASE
          WHEN (pol.price_unit / COALESCE(cur.rate, 1.0) * (pol.product_qty - pol.qty_invoiced))::decimal(16,2) >= 0.0 THEN (pol.price_unit / COALESCE(cur.rate, 1.0) * (pol.product_qty - pol.qty_invoiced))::decimal(16,2)
          ELSE 0.0
        END AS debit,
        CASE
          WHEN (pol.price_unit / COALESCE(cur.rate, 1.0) * (pol.product_qty - pol.qty_invoiced))::decimal(16,2)  < 0 THEN (pol.price_unit / COALESCE(cur.rate, 1.0) * (pol.product_qty - pol.qty_invoiced))::decimal(16,2)
          ELSE 0.0
        END AS credit
        FROM purchase_order_line pol
            LEFT JOIN purchase_order po on po.id = pol.order_id
            LEFT JOIN product_product pp ON pp.id = pol.product_id
            LEFT JOIN product_template pt ON pt.id = pp.product_tmpl_id
            LEFT JOIN product_category pc ON pc.id = pt.categ_id
            LEFT JOIN currency_rate cur on (cur.currency_id = po.currency_id and
                cur.company_id = po.company_id and
                cur.date_start <= coalesce(po.date_order, now()) and
                (cur.date_end is null or cur.date_end > coalesce(po.date_order, now())))
        WHERE pol.product_qty > pol.qty_invoiced AND po.state != 'cancel' AND po.state != 'draft'

    UNION ALL

    /* DRAFT INVOICES */
    SELECT
        'draft invoice' AS line_type,
        ail.company_id AS company_id,
        ail.name AS name,
        ail.create_date::date as date,
        ail.id AS res_id,
        'account.move.line' AS res_model,
        ail.account_id as account_id,
        CASE
          WHEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2) >= 0.0 THEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2)
          ELSE 0.0
        END AS debit,
        CASE
          WHEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2)  < 0 THEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2)
          ELSE 0.0
        END AS credit
        FROM account_move_line ail
            LEFT JOIN account_move ai ON ai.id = ail.move_id
            LEFT JOIN currency_rate cur on (cur.currency_id = ai.currency_id and
                cur.company_id = ai.company_id and
                cur.date_start <= coalesce(ai.invoice_date, now()) and
                (cur.date_end is null or cur.date_end > coalesce(ai.invoice_date, now())))
        WHERE ai.state = 'draft'
          AND ai.move_type IN ('in_invoice', 'out_refund')
          AND ail.display_type = 'product'

    UNION ALL

    /* DRAFT INVOICES */
    SELECT
        'draft invoice' AS line_type,
                ail.company_id AS company_id,
        ail.name AS name,
        ail.create_date::date as date,
        ail.id AS res_id,
        'account.move.line' AS res_model,
        ail.account_id as account_id,
        CASE
          WHEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2)  < 0 THEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2)
          ELSE 0.0
        END AS debit,
        CASE
          WHEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2) >= 0.0 THEN (ail.price_subtotal / COALESCE(cur.rate, 1.0))::decimal(16,2)
          ELSE 0.0
        END AS credit
        FROM account_move_line ail
            LEFT JOIN account_move ai ON ai.id = ail.move_id
            LEFT JOIN currency_rate cur on (cur.currency_id = ai.currency_id and
                cur.company_id = ai.company_id and
                cur.date_start <= coalesce(ai.invoice_date, now()) and
                (cur.date_end is null or cur.date_end > coalesce(ai.invoice_date, now())))
        WHERE ai.state = 'draft'
          AND ai.move_type IN ('out_invoice', 'in_refund')
          AND ail.display_type = 'product'

    ) AS mis_committed_purchase
)
