This module provide the following demo data based on the Odoo generic
chart of accounts:

- A few styles.
- A budget.
- A report template showing expenses by category
- A sample committed purchase view model, showing uninvoiced purchase
  order lines and draft invoice lines.
- A report instance showing budget, committed purchases, actuals and
  available.
