Demo addon for MIS Builder.
