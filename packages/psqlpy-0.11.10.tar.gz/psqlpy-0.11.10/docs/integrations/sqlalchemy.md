---
title: Integration with SQLAlchemy
---

# OTLP-PSQLPy

There is a library for SQLAlchemy support.
Please follow the [link](https://pypi.org/project/psqlpy-sqlalchemy/)
