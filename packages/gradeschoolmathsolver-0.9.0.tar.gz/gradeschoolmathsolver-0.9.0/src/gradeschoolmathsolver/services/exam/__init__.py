"""Exam Service"""
from .service import ExamService

__all__ = ['ExamService']
