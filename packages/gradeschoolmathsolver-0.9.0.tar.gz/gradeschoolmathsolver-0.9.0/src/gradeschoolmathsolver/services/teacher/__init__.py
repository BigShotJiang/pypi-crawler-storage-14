"""
Teacher Service Module
Provides feedback for wrong answers
"""
from .service import TeacherService

__all__ = ['TeacherService']
