"""Quiz History Service"""
from .service import QuizHistoryService

__all__ = ['QuizHistoryService']
