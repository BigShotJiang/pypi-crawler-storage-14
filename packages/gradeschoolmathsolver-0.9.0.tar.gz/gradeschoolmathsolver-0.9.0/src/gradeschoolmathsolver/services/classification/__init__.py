"""Classification Service"""
from .service import ClassificationService

__all__ = ['ClassificationService']
