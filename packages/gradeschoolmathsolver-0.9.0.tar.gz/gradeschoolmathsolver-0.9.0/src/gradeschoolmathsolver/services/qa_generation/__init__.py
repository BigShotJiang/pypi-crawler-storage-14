"""QA Generation Service"""
from .service import QAGenerationService

__all__ = ['QAGenerationService']
