"""
Block dictionary compression demo.

This script mirrors the reference Colab: load a HuggingFace model, compress each
linear layer with block dictionaries, and compare outputs.
"""

import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

from cymeta.compression.block import (
    BlockDictionaryCompressor,
    compress_model_linears_block,
    replace_linears_with_block,
)


def main():
    model_id = "MBZUAI/LaMini-Flan-T5-248M"
    device = "cuda" if torch.cuda.is_available() else "cpu"

    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_id).to(device)
    model.eval()

    compressor = BlockDictionaryCompressor(
        subvec_len=64,
        num_atoms=32,
        num_iterations=4,
        device=device,
    )

    print("Compressing linear layers...")
    artifacts = compress_model_linears_block(model, compressor)

    print("Replacing modules with compressed variants...")
    compressed_model = AutoModelForSeq2SeqLM.from_pretrained(model_id).to(device)
    replace_linears_with_block(compressed_model, artifacts, device=device)

    prompts = [
        "Translate to English: Hola, ¿cómo estás?",
        "Summarize: Machine learning uses data to train models.",
    ]
    for prompt in prompts:
        inputs = tokenizer(prompt, return_tensors="pt").to(device)
        with torch.no_grad():
            orig = model.generate(**inputs, max_length=64)
            comp = compressed_model.generate(**inputs, max_length=64)
        print("Prompt:", prompt)
        print("Original:", tokenizer.decode(orig[0], skip_special_tokens=True))
        print("Compressed:", tokenizer.decode(comp[0], skip_special_tokens=True))
        print("=" * 40)


if __name__ == "__main__":
    main()

