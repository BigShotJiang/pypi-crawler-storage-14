"""Tests for block dictionary compression."""

import torch
import torch.nn as nn

from cymeta.compression.block import (
    BlockDictionaryCompressor,
    BlockCompressedLinear,
    compress_model_linears_block,
    replace_linears_with_block,
)


def test_block_compress_linear_weight():
    layer = nn.Linear(64, 32, bias=True)
    compressor = BlockDictionaryCompressor(subvec_len=16, num_atoms=8, num_iterations=2)
    artifact = compressor.compress_weight(layer.weight.data)
    assert artifact.meta["out_dim"] == 32
    assert artifact.meta["in_dim"] == 64
    compressed_layer = BlockCompressedLinear(artifact, bias=layer.bias)

    assert isinstance(compressed_layer, BlockCompressedLinear)
    x = torch.randn(4, 64)
    y = compressed_layer(x)
    assert y.shape == (4, 32)


def test_block_compress_model():
    class TinyModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.fc1 = nn.Linear(32, 64)
            self.fc2 = nn.Linear(64, 16)

        def forward(self, x):
            x = self.fc1(x)
            return self.fc2(x)

    model = TinyModel()
    compressor = BlockDictionaryCompressor(subvec_len=16, num_atoms=8, num_iterations=1)
    artifacts = compress_model_linears_block(model, compressor)
    assert len(artifacts) == 2

    compressed_model = TinyModel()
    replaced = replace_linears_with_block(compressed_model, artifacts)
    assert replaced == 2

    x = torch.randn(2, 32)
    y = compressed_model(x)
    assert y.shape == (2, 16)

