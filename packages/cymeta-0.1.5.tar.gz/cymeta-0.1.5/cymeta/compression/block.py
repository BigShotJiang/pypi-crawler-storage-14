"""
Block-dictionary compression utilities.

Implements a per-layer compression scheme inspired by the reference Colab script:
- Partition weight matrices into sub-vectors.
- Learn dictionary atoms via k-means.
- Perform brute-force atom / cyclic shift assignments.
- Fit per-block scalar gates.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


def partition_matrix(weight: torch.Tensor, subvec_len: int) -> Tuple[torch.Tensor, int, int]:
    out_dim, in_dim = weight.shape
    if in_dim % subvec_len != 0:
        raise ValueError(
            f"in_features ({in_dim}) must be divisible by subvec_len ({subvec_len})"
        )
    num_blocks = in_dim // subvec_len
    blocks = (
        weight.view(out_dim, num_blocks, subvec_len)
        .permute(1, 0, 2)
        .contiguous()
    )
    return blocks, num_blocks, subvec_len


def reassemble_blocks(blocks: torch.Tensor) -> torch.Tensor:
    num_blocks, out_dim, subvec_len = blocks.shape
    return (
        blocks.permute(1, 0, 2)
        .contiguous()
        .view(out_dim, num_blocks * subvec_len)
    )


def circular_rotate_tensor(vec: torch.Tensor, shift: int) -> torch.Tensor:
    length = vec.shape[-1]
    shift = int(shift) % length
    if shift == 0:
        return vec
    return torch.cat((vec[-shift:], vec[:-shift]), dim=-1)


def kmeans_init_atoms(
    vectors: torch.Tensor,
    num_atoms: int,
    num_iters: int = 20,
    seed: int = 0,
) -> torch.Tensor:
    if vectors.numel() == 0:
        return torch.zeros((num_atoms, vectors.shape[-1]), device=vectors.device)

    device = vectors.device
    torch.manual_seed(seed)
    n = vectors.shape[0]
    if n < num_atoms:
        indices = torch.randint(0, n, (num_atoms,), device=device)
    else:
        indices = torch.randperm(n, device=device)[:num_atoms]
    atoms = vectors[indices].clone()

    for _ in range(num_iters):
        dists = torch.cdist(vectors, atoms)  # (N, K)
        assign = torch.argmin(dists, dim=1)
        for k in range(num_atoms):
            mask = assign == k
            if mask.any():
                atoms[k] = vectors[mask].mean(dim=0)
            else:
                atoms[k] = vectors[torch.randint(0, n, (1,), device=device)].squeeze(0)
    return atoms


@dataclass
class BlockCompressionArtifact:
    dictionary: torch.Tensor  # (K, L)
    atom_map: torch.Tensor  # (num_blocks, out_dim)
    shift_map: torch.Tensor  # (num_blocks, out_dim)
    gates: torch.Tensor  # (num_blocks, out_dim)
    meta: Dict[str, int]

    def to(self, device: torch.device) -> "BlockCompressionArtifact":
        return BlockCompressionArtifact(
            dictionary=self.dictionary.to(device),
            atom_map=self.atom_map.to(device),
            shift_map=self.shift_map.to(device),
            gates=self.gates.to(device),
            meta=self.meta.copy(),
        )


class BlockDictionaryCompressor:
    def __init__(
        self,
        subvec_len: int = 64,
        num_atoms: int = 32,
        num_iterations: int = 4,
        seed: int = 0,
        device: str = "cpu",
    ):
        self.subvec_len = subvec_len
        self.num_atoms = num_atoms
        self.num_iterations = num_iterations
        self.seed = seed
        self.device = torch.device(device)

    def compress_weight(self, weight: torch.Tensor) -> BlockCompressionArtifact:
        weight = weight.detach().to(self.device)
        out_dim, in_dim = weight.shape
        blocks, num_blocks, subvec_len = partition_matrix(weight, self.subvec_len)

        flat = blocks.reshape(num_blocks * out_dim, subvec_len)
        dictionary = kmeans_init_atoms(
            flat, self.num_atoms, num_iters=20, seed=self.seed
        ).to(self.device)

        atom_map = torch.zeros((num_blocks, out_dim), dtype=torch.long, device=self.device)
        shift_map = torch.zeros_like(atom_map)
        gates = torch.ones((num_blocks, out_dim), dtype=weight.dtype, device=self.device)

        for iteration in range(self.num_iterations):
            rot_cache = self._precompute_rotations(dictionary)
            for b in range(num_blocks):
                for o in range(out_dim):
                    vec = blocks[b, o]
                    best_err = None
                    best_a = 0
                    best_s = 0
                    for a in range(self.num_atoms):
                        rots = rot_cache[a]  # (L, L)
                        diffs = rots - vec.unsqueeze(0)
                        errs = (diffs * diffs).sum(dim=1)
                        err_val, shift_idx = torch.min(errs, dim=0)
                        err_item = err_val.item()
                        if best_err is None or err_item < best_err:
                            best_err = err_item
                            best_a = a
                            best_s = int(shift_idx.item())
                    atom_map[b, o] = best_a
                    shift_map[b, o] = best_s

            dictionary = self._update_dictionary(dictionary, blocks, atom_map, shift_map)
            gates = self._update_gates(dictionary, blocks, atom_map, shift_map)

        artifact = BlockCompressionArtifact(
            dictionary=dictionary.detach().cpu(),
            atom_map=atom_map.detach().cpu(),
            shift_map=shift_map.detach().cpu(),
            gates=gates.detach().cpu(),
            meta={
                "subvec_len": subvec_len,
                "num_blocks": num_blocks,
                "out_dim": out_dim,
                "in_dim": in_dim,
                "num_atoms": self.num_atoms,
            },
        )
        return artifact

    def compress_linear(self, layer: nn.Linear) -> "BlockCompressedLinear":
        artifact = self.compress_weight(layer.weight.data)
        bias = layer.bias.detach().clone() if layer.bias is not None else None
        return BlockCompressedLinear(artifact, bias=bias, device=self.device)

    def _precompute_rotations(self, dictionary: torch.Tensor) -> torch.Tensor:
        rotations = []
        for atom in dictionary:
            rots = [circular_rotate_tensor(atom, shift) for shift in range(atom.shape[-1])]
            rotations.append(torch.stack(rots, dim=0))
        return torch.stack(rotations, dim=0)  # (K, L, L)

    def _update_dictionary(
        self,
        dictionary: torch.Tensor,
        blocks: torch.Tensor,
        atom_map: torch.Tensor,
        shift_map: torch.Tensor,
    ) -> torch.Tensor:
        num_blocks, out_dim, subvec_len = blocks.shape
        new_dict = torch.zeros_like(dictionary)
        counts = torch.zeros(dictionary.shape[0], device=self.device)

        for b in range(num_blocks):
            for o in range(out_dim):
                atom_idx = atom_map[b, o].item()
                shift = shift_map[b, o].item()
                vec = blocks[b, o]
                inv_rot = circular_rotate_tensor(vec, -shift)
                new_dict[atom_idx] += inv_rot
                counts[atom_idx] += 1

        for k in range(new_dict.shape[0]):
            if counts[k] > 0:
                new_dict[k] /= counts[k]
            else:
                new_dict[k] = dictionary[k]
        return new_dict

    def _update_gates(
        self,
        dictionary: torch.Tensor,
        blocks: torch.Tensor,
        atom_map: torch.Tensor,
        shift_map: torch.Tensor,
    ) -> torch.Tensor:
        num_blocks, out_dim, _ = blocks.shape
        gates = torch.ones((num_blocks, out_dim), device=self.device, dtype=blocks.dtype)
        for b in range(num_blocks):
            for o in range(out_dim):
                atom_idx = atom_map[b, o].item()
                shift = shift_map[b, o].item()
                atom = dictionary[atom_idx]
                rotated = circular_rotate_tensor(atom, shift)
                vec = blocks[b, o]
                denom = (rotated * rotated).sum()
                if denom.item() > 1e-8:
                    gates[b, o] = (vec * rotated).sum() / denom
                else:
                    gates[b, o] = 1.0
        return gates


class BlockCompressedLinear(nn.Module):
    def __init__(
        self,
        artifact: BlockCompressionArtifact,
        bias: Optional[torch.Tensor] = None,
        device: Optional[torch.device] = None,
    ):
        super().__init__()
        device = torch.device(device) if device is not None else torch.device("cpu")

        meta = artifact.meta
        self.subvec_len = int(meta["subvec_len"])
        self.num_blocks = int(meta["num_blocks"])
        self.out_dim = int(meta["out_dim"])
        self.in_dim = int(meta["in_dim"])

        self.dictionary = nn.Parameter(
            artifact.dictionary.to(device), requires_grad=False
        )
        self.atom_map = nn.Parameter(
            artifact.atom_map.to(device), requires_grad=False
        )
        self.shift_map = nn.Parameter(
            artifact.shift_map.to(device), requires_grad=False
        )
        self.gates = nn.Parameter(
            artifact.gates.to(device), requires_grad=False
        )

        if bias is not None:
            self.bias = nn.Parameter(bias.to(device))
        else:
            self.register_parameter("bias", None)

    def reconstruct_weight(self) -> torch.Tensor:
        dictionary = self.dictionary
        blocks = torch.zeros(
            (self.num_blocks, self.out_dim, self.subvec_len),
            device=dictionary.device,
            dtype=dictionary.dtype,
        )
        for b in range(self.num_blocks):
            for o in range(self.out_dim):
                atom_idx = self.atom_map[b, o].item()
                shift = self.shift_map[b, o].item()
                atom = dictionary[atom_idx]
                rotated = circular_rotate_tensor(atom, shift)
                blocks[b, o] = self.gates[b, o] * rotated
        weight = torch.zeros(
            self.out_dim, self.in_dim, device=dictionary.device, dtype=dictionary.dtype
        )
        for b in range(self.num_blocks):
            start = b * self.subvec_len
            end = start + self.subvec_len
            weight[:, start:end] = blocks[b]
        if weight.shape != (self.out_dim, self.in_dim):
            raise RuntimeError(
                f"Reconstructed weight shape {weight.shape} does not match expected "
                f"{(self.out_dim, self.in_dim)}"
            )
        return weight

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.reconstruct_weight()
        return F.linear(x, weight, self.bias)


def compress_model_linears_block(
    model: nn.Module,
    compressor: BlockDictionaryCompressor,
    layers_limit: Optional[int] = None,
) -> Dict[str, Dict[str, torch.Tensor]]:
    artifacts: Dict[str, Dict[str, torch.Tensor]] = {}
    count = 0
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            artifact = compressor.compress_weight(module.weight.data)
            bias = module.bias.detach().clone() if module.bias is not None else None
            artifacts[name] = {"artifact": artifact, "bias": bias}
            count += 1
            if layers_limit and count >= layers_limit:
                break
    return artifacts


def replace_linears_with_block(
    model: nn.Module,
    artifacts: Dict[str, Dict[str, torch.Tensor]],
    device: Optional[torch.device] = None,
) -> int:
    replaced = 0
    for path, content in artifacts.items():
        parent = model
        parts = path.split(".")
        for part in parts[:-1]:
            parent = getattr(parent, part)
        attr = parts[-1]
        artifact = content["artifact"]
        bias = content["bias"]
        module = BlockCompressedLinear(
            artifact,
            bias=bias,
            device=device or next(parent.parameters(), torch.zeros(1)).device,
        )
        setattr(parent, attr, module)
        replaced += 1
    return replaced


def save_block_artifacts(artifacts: Dict[str, Dict[str, torch.Tensor]], path: str) -> None:
    serializable = {}
    for name, content in artifacts.items():
        serializable[name] = {
            "artifact": content["artifact"],
            "bias": content["bias"],
        }
    torch.save(serializable, path)


def load_block_artifacts(path: str, device: Optional[str] = None) -> Dict[str, Dict[str, torch.Tensor]]:
    loaded = torch.load(path, map_location=device)
    return loaded

