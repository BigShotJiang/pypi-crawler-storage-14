# -*- coding: utf-8 -*-
"""
Project: China-idiom-without-tone
Original Creator: DoubleThunder
Creator: HSQK
Create time: 2025-11-26 16:53
Introduction:
"""

__title__ = 'china_idiom_without_tone'
__version__ = '0.1.0'
__author__ = 'Thunder Bouble, tangwei-dev'
__license__ = 'MIT'
__description__ = '成语与成语接龙查询工具'
__copyright__ = '''
MIT License
Copyright (c) 2019  Thunder Bouble
Copyright (c) 2025 tangwei-dev
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
'''

from china_idiom.core import *
