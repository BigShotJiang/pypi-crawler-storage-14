VALID_MATERIALS = {"steel", "aluminum", "aluminumhousing", "pouch_foil"}
VALID_ASSEMBLY_TYPES = {"Stacked", "Wound", "ZFolded"}


def get_valid_materials():
    """
    Get a list of valid material types for battery formats.

    Returns:
        list[str]: A sorted list of valid material names.
    """
    return sorted(VALID_MATERIALS)


def get_valid_assembly_types():
    """
    Get a list of valid assembly types for battery formats.

    Returns:
        list[str]: A sorted list of valid assembly type names.
    """
    return sorted(VALID_ASSEMBLY_TYPES)


def validate_material(material):
    if material not in VALID_MATERIALS:
        raise ValueError(
            f"Invalid material: '{material}'. Must be one of {sorted(VALID_MATERIALS)}."
        )


def validate_assembly_type(assembly_type):
    if assembly_type not in VALID_ASSEMBLY_TYPES:
        raise ValueError(
            f"Invalid assembly type: '{assembly_type}'. Must be one of {sorted(VALID_ASSEMBLY_TYPES)}."
        )


def validate_format_parameter(param_name, param_value):
    """Validate a format parameter against its bounds."""
    # Import here to avoid circular imports
    from .parameter_validator import parameter_validator

    bounds = parameter_validator.get_parameter_bounds()

    if param_name not in bounds:
        return  # Skip validation for unknown parameters

    if param_value is None:
        raise ValueError(f"Format parameter '{param_name}' cannot be None")

    if not isinstance(param_value, (int, float)):
        raise ValueError(
            f"Format parameter '{param_name}' must be numeric, got {type(param_value)}"
        )

    min_val, max_val = bounds[param_name]

    if min_val is not None and param_value < min_val:
        raise ValueError(
            f"Format parameter '{param_name}' value {param_value} is below minimum allowed value {min_val}"
        )

    if max_val is not None and param_value > max_val:
        raise ValueError(
            f"Format parameter '{param_name}' value {param_value} is above maximum allowed value {max_val}"
        )


def define_cuboid_format(
    name,
    material,
    housingThickness_mm,
    length_mm,
    width_mm,
    thickness_mm,
    assemblyType=None,
):
    """
    Defines a dictionary for a cuboid battery format.

    .. deprecated::
        Defining new formats is deprecated. Use `get_updated_format()` to modify existing
        battery formats from a base battery instead.

    Raises:
        DeprecationWarning: Always raised as defining new formats is deprecated.
    """
    raise DeprecationWarning(
        "Defining new formats is deprecated. "
        "Please use get_updated_format() to modify existing battery formats from a base battery instead."
    )


def define_cylinder_format(
    name, material, housingThickness_mm, diameter_mm, height_mm, innerDiameter_mm
):
    """
    Defines a dictionary for a cylindrical battery format.

    .. deprecated::
        Defining new formats is deprecated. Use `get_updated_format()` to modify existing
        battery formats from a base battery instead.

    Raises:
        DeprecationWarning: Always raised as defining new formats is deprecated.
    """
    raise DeprecationWarning(
        "Defining new formats is deprecated. "
        "Please use get_updated_format() to modify existing battery formats from a base battery instead."
    )
