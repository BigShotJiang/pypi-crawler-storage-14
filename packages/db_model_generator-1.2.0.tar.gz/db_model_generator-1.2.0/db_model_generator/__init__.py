from .generator import generate

__version__ = "1.2.0"

__all__ = ['generate', '__version__']
