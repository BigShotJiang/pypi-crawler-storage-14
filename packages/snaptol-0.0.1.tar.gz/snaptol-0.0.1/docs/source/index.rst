.. snaptol documentation master file, created by
   sphinx-quickstart on Mon Aug 11 19:45:01 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

snaptol documentation
=====================

A Python tool for snapshot testing with numerical tolerance on floating point numbers.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api
