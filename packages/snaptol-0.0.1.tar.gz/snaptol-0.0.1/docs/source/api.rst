===============
 API Reference
===============

.. autosummary::
   :toctree: generated
   :template: custom-module-template.rst
   :recursive:

   snaptol
