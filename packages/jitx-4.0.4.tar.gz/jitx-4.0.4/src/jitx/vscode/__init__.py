"""
JITX VSCode Integration
=======================

This package contains functions that the VSCode extension uses to interact with
the JITX python library. In particular you'll find functions that generate
launch configurations for the VSCode debugger.
"""
