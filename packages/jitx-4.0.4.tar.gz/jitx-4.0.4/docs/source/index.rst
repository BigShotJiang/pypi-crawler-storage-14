.. py-jitx documentation master file, created by
   sphinx-quickstart on Thu Mar 20 18:52:41 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

py-jitx documentation
=====================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   api/modules

