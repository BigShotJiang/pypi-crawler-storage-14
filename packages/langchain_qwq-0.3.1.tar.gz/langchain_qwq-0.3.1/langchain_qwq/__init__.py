from langchain_qwq.chat_models import ChatQwen, ChatQwQ

__version__ = "1.0.0"

__all__ = [
    "ChatQwQ",
    "ChatQwen",
    "__version__",
]
