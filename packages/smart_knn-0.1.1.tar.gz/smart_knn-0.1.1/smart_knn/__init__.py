from .base_knn import SmartKNN
