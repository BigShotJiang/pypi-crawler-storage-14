# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""azureml.responsibleai sub-package."""

__path__ = __import__('pkgutil').extend_path(__path__, __name__)    # type: ignore

try:
    from ._version import SELF_VERSION
    __version__ = SELF_VERSION
except ImportError:
    __version__ = '0.0.0+dev'

"""Update the user agent with the current package version."""
try:
    import azureml._base_sdk_common.user_agent as user_agent
    import os
    current_package = __package__ or os.path.splitext(os.path.basename(__file__))[0]
    user_agent.append(current_package, "no_version")
except Exception:    # Silently continue if user agent update fails
    pass
