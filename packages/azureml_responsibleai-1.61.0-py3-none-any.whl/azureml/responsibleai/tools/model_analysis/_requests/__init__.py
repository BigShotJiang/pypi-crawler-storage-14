# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Module for model analysis requests.

Note: Files in this directory should not be moved or renamed in order to maintain
backcompat with past SDK versions that rely on the deserialization of these objects.
"""
