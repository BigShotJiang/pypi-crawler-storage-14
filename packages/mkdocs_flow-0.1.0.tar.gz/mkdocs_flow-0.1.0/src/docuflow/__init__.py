#!/usr/bin/env python3
"""
DocuFlow Package - Automated Documentation Project Generator

A comprehensive CLI tool for generating MkDocs-based documentation projects
with automated setup, Git integration, and deployment capabilities.
"""

__version__ = "0.1.0"

# Import main components for easy access
from .models import ProjectConfig
from .config import ConfigManager
from .template import TemplateManager
from .git_manager import GitManager
from .project_manager import ProjectManager

__all__ = [
    "ProjectConfig",
    "ConfigManager", 
    "TemplateManager",
    "GitManager",
    "ProjectManager",
    "__version__"
]
