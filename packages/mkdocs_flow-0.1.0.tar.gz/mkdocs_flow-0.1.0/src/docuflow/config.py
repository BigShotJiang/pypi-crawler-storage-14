#!/usr/bin/env python3
"""
DocuFlow Configuration Manager - Handles application configuration and authentication
"""

import os
import yaml
from pathlib import Path
from typing import Optional, Dict, Any
import keyring
from rich.console import Console
from rich.prompt import Prompt, Confirm

console = Console()


class ConfigManager:
    """Manages DocuFlow configuration"""
    
    def __init__(self):
        self.config_dir = Path.home() / ".docuflow"
        self.config_file = self.config_dir / "config.yml"
        self.ensure_config_dir()
    
    def ensure_config_dir(self):
        """Create configuration directory if it doesn't exist"""
        self.config_dir.mkdir(parents=True, exist_ok=True)
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                return yaml.safe_load(f) or {}
        return self.get_default_config()
    
    def save_config(self, config: Dict[str, Any]):
        """Save configuration to file"""
        with open(self.config_file, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
    
    def get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "default_settings": {
                "git_provider": "github",
                "theme": "material",
                "language": "en",
                "template": "basic"
            },
            "github": {
                "default_visibility": "public",
                "enable_pages": True,
                "branch": "main"
            },
            "gitlab": {
                "default_visibility": "private",
                "enable_pages": True,
                "branch": "main"
            },
            "templates": {
                "basic": {
                    "plugins": ["search", "awesome-pages", "mermaid2"]
                },
                "full": {
                    "plugins": [
                        "search",
                        "awesome-pages",
                        "mermaid2",
                        "git-revision-date-localized",
                        "minify"
                    ]
                }
            }
        }
    
    def get_token(self, provider: str) -> Optional[str]:
        """Get authentication token for git provider"""
        # Try environment variable first
        env_var = f"{provider.upper()}_TOKEN"
        token = os.environ.get(env_var)
        
        if token:
            return token
        
        # Try keyring
        try:
            token = keyring.get_password("docuflow", f"{provider}_token")
            if token:
                return token
        except Exception:
            pass
        
        # Prompt user for token
        console.print(f"\n[yellow]No {provider} token found.[/yellow]")
        console.print(f"Please provide a personal access token for {provider}.")
        console.print(f"You can create one at:")
        if provider == "github":
            console.print("  https://github.com/settings/tokens")
        else:
            console.print("  https://gitlab.com/-/profile/personal_access_tokens")
        
        token = Prompt.ask(f"\n{provider.capitalize()} token", password=True)
        
        if token and Confirm.ask(f"Save token securely for future use?"):
            try:
                keyring.set_password("docuflow", f"{provider}_token", token)
                console.print("[green]Token saved securely![/green]")
            except Exception as e:
                console.print(f"[yellow]Could not save token: {e}[/yellow]")
        
        return token
