#!/usr/bin/env python3
"""
Version management for DocuFlow - Handles mike and git tag integration.
"""

import subprocess
import re
from pathlib import Path
from typing import List, Optional, Tuple
from rich.console import Console

console = Console()


class VersionManager:
    """Manages documentation versions using mike and git tags."""

    def __init__(self, project_path: Path):
        self.project_path = project_path

    def get_git_tags(self) -> List[str]:
        """Get all git tags."""
        result = subprocess.run(
            ['git', 'tag', '-l'],
            cwd=self.project_path,
            capture_output=True,
            text=True
        )
        return result.stdout.strip().split('\n') if result.stdout else []

    def get_mike_versions(self) -> List[str]:
        """Get all mike versions."""
        result = subprocess.run(
            ['mike', 'list'],
            cwd=self.project_path,
            capture_output=True,
            text=True
        )
        # Parse mike list output
        versions = []
        for line in result.stdout.split('\n'):
            if line.strip():
                # Extract version from line like "0.9 [latest]"
                match = re.match(r'^\s*(\S+)', line)
                if match:
                    versions.append(match.group(1))
        return versions

    def validate_version_format(self, version: str) -> bool:
        """Validate version format (semver or simple version)."""
        pattern = r'^\d+\.\d+(\.\d+)?$'
        return re.match(pattern, version) is not None

    def create_version(
        self,
        version: str,
        title: Optional[str] = None,
        aliases: Optional[List[str]] = None,
        create_tag: bool = True,
        tag_message: Optional[str] = None
    ) -> bool:
        """
        Create a new version with mike and optionally create a git tag.

        Args:
            version: Version number (e.g., "1.0", "1.0.0")
            title: Documentation title for this version
            aliases: List of aliases (e.g., ["latest", "stable"])
            create_tag: Whether to create a git tag
            tag_message: Git tag message

        Returns:
            True if successful
        """
        if not self.validate_version_format(version):
            console.print(f"[red]Invalid version format: {version}[/red]")
            return False

        # Deploy with mike
        cmd = ['mike', 'deploy', version]
        if title:
            cmd.extend(['--title', title])
        if aliases:
            cmd.extend(aliases)
        cmd.append('--push')

        result = subprocess.run(
            cmd,
            cwd=self.project_path,
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            console.print(f"[red]Failed to create mike version: {result.stderr}[/red]")
            return False

        console.print(f"[green]✓ Created mike version: {version}[/green]")

        # Create git tag if requested
        if create_tag:
            tag_cmd = ['git', 'tag', '-a', version]
            if tag_message:
                tag_cmd.extend(['-m', tag_message])
            else:
                tag_cmd.extend(['-m', f'Version {version}'])

            result = subprocess.run(
                tag_cmd,
                cwd=self.project_path,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                console.print(f"[yellow]Warning: Failed to create git tag: {result.stderr}[/yellow]")
            else:
                console.print(f"[green]✓ Created git tag: {version}[/green]")

                # Push tag
                subprocess.run(
                    ['git', 'push', 'origin', version],
                    cwd=self.project_path
                )

        return True

    def set_default(self, version: str) -> bool:
        """Set a version as the default."""
        result = subprocess.run(
            ['mike', 'set-default', version],
            cwd=self.project_path,
            capture_output=True,
            text=True
        )
        return result.returncode == 0

    def check_alignment(self) -> Tuple[List[str], List[str], List[str]]:
        """
        Check alignment between git tags and mike versions.

        Returns:
            Tuple of (aligned, only_git, only_mike)
        """
        git_tags = set(self.get_git_tags())
        mike_versions = set(self.get_mike_versions())

        aligned = list(git_tags & mike_versions)
        only_git = list(git_tags - mike_versions)
        only_mike = list(mike_versions - git_tags)

        return aligned, only_git, only_mike
