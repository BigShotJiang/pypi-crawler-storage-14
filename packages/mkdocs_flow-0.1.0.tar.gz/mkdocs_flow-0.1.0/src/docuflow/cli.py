#!/usr/bin/env python3
"""
DocuFlow CLI - Main command-line interface
"""

import os
import sys
import shutil
import subprocess
import yaml
import keyring
import git
from pathlib import Path
from typing import Optional, Dict, Any, List
import click
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.table import Table

# Import our modules
from .models import ProjectConfig
from .config import ConfigManager
from .project_manager import ProjectManager

# Initialize Rich console for beautiful terminal output
console = Console()

# Application version
__version__ = "0.1.0"


@click.group()
@click.version_option(version=__version__)
def cli():
    """DocuFlow - Automated Documentation Project Generator"""
    pass


@cli.command()
@click.argument('project_name', required=False)
@click.option('--name', help='Project name')
@click.option('--description', help='Project description')
@click.option('--author', help='Author name')
@click.option('--email', help='Author email')
@click.option('--git-provider', type=click.Choice(['github', 'gitlab']), help='Git provider')
@click.option('--private', is_flag=True, help='Create private repository')
@click.option('--template', type=click.Choice(['basic', 'full']), default='basic', help='Project template')
@click.option('--no-remote', is_flag=True, help='Skip remote repository creation')
@click.option('--config-file', type=click.Path(exists=True), help='Configuration file')
def init(project_name, name, description, author, email, git_provider, private, template, no_remote, config_file):
    """Initialize a new documentation project"""
    
    console.print(Panel.fit(
        "[bold cyan]DocuFlow[/bold cyan] - Documentation Project Generator\n"
        "Version " + __version__,
        border_style="cyan"
    ))
    
    # Load configuration
    config_manager = ConfigManager()
    base_config = config_manager.load_config()
    
    # Handle configuration file if provided
    if config_file:
        with open(config_file, 'r') as f:
            file_config = yaml.safe_load(f)
            # Merge configurations
            base_config.update(file_config)
    
    # Interactive setup if values not provided
    if not project_name and not name:
        project_name = Prompt.ask(
            "Project name",
            default=Path.cwd().name
        )
    else:
        project_name = name or project_name
    
    if not description:
        description = Prompt.ask(
            "Project description",
            default=f"Documentation for {project_name}"
        )
    
    if not author:
        author = Prompt.ask("Author name")
    
    if not email:
        email = Prompt.ask("Author email")
    
    if not git_provider:
        git_provider = Prompt.ask(
            "Git provider",
            choices=["github", "gitlab"],
            default=base_config["default_settings"]["git_provider"]
        )
    
    # Determine repository visibility
    repository_visibility = "private" if private else None
    if not repository_visibility:
        repository_visibility = "private" if Confirm.ask(
            "Create private repository?",
            default=(base_config[git_provider]["default_visibility"] == "private")
        ) else "public"
    
    # Show configuration summary
    console.print("\n[bold]Configuration Summary:[/bold]")
    summary_table = Table(show_header=False, box=None)
    summary_table.add_column(style="cyan")
    summary_table.add_column()
    
    summary_table.add_row("Project Name:", project_name)
    summary_table.add_row("Description:", description)
    summary_table.add_row("Author:", f"{author} <{email}>")
    summary_table.add_row("Git Provider:", git_provider)
    summary_table.add_row("Repository:", repository_visibility)
    summary_table.add_row("Template:", template)
    summary_table.add_row("Create Remote:", "No" if no_remote else "Yes")
    
    console.print(summary_table)
    
    if not Confirm.ask("\nProceed with project creation?", default=True):
        console.print("[yellow]Project creation cancelled.[/yellow]")
        return
    
    # Create project configuration
    project_config = ProjectConfig(
        name=project_name,
        description=description,
        author_name=author,
        author_email=email,
        git_provider=git_provider,
        repository_visibility=repository_visibility,
        template=template,
        create_remote=not no_remote,
        plugins=base_config["templates"][template]["plugins"]
    )
    
    # Determine project path
    project_path = Path.cwd() / project_name
    
    # Check if directory already exists
    if project_path.exists():
        if not Confirm.ask(f"\n[yellow]Directory '{project_name}' already exists. Continue anyway?[/yellow]", default=False):
            console.print("[red]Project creation cancelled.[/red]")
            return
    else:
        project_path.mkdir(parents=True, exist_ok=True)
    
    # Create project
    console.print(f"\n[cyan]Creating project in {project_path}...[/cyan]\n")
    
    project_manager = ProjectManager(project_config, project_path)
    success = project_manager.setup_project(config_manager)
    
    if success:
        console.print("\n[bold green]✅ Project created successfully![/bold green]\n")
        
        # Display next steps
        console.print("[bold]Next steps:[/bold]")
        console.print(f"1. Navigate to your project: [cyan]cd {project_name}[/cyan]")
        console.print("2. Install dependencies: [cyan]poetry install[/cyan]")
        console.print("3. Start the development server: [cyan]poetry run mkdocs serve[/cyan]")
        console.print("4. Open your browser to: [cyan]http://localhost:8000[/cyan]")
        
        if project_config.create_remote:
            if git_provider == "github":
                console.print(f"\n📦 Repository: [link]https://github.com/{author}/{project_config.repository_name}[/link]")
                console.print(f"📄 Documentation will be available at: [link]https://{author}.github.io/{project_config.repository_name}/[/link]")
            else:
                console.print(f"\n📦 Repository: [link]https://gitlab.com/{author}/{project_config.repository_name}[/link]")
                console.print(f"📄 Documentation will be available at: [link]https://{author}.gitlab.io/{project_config.repository_name}/[/link]")
    else:
        console.print("[bold red]❌ Project creation failed![/bold red]")
        console.print("Please check the error messages above and try again.")


@cli.command()
def config():
    """Manage DocuFlow configuration"""
    config_manager = ConfigManager()
    config_data = config_manager.load_config()
    
    console.print(Panel.fit("[bold cyan]DocuFlow Configuration[/bold cyan]", border_style="cyan"))
    
    # Display current configuration
    console.print("\n[bold]Current Configuration:[/bold]")
    console.print(yaml.dump(config_data, default_flow_style=False))
    
    if Confirm.ask("\nDo you want to modify the configuration?"):
        # Interactive configuration editing
        console.print("\n[bold]Default Settings:[/bold]")
        
        config_data["default_settings"]["git_provider"] = Prompt.ask(
            "Default git provider",
            choices=["github", "gitlab"],
            default=config_data["default_settings"]["git_provider"]
        )
        
        config_data["default_settings"]["theme"] = Prompt.ask(
            "Default theme",
            default=config_data["default_settings"]["theme"]
        )
        
        config_data["default_settings"]["template"] = Prompt.ask(
            "Default template",
            choices=["basic", "full"],
            default=config_data["default_settings"]["template"]
        )
        
        # Save configuration
        config_manager.save_config(config_data)
        console.print("\n[green]Configuration saved successfully![/green]")
    
    # Token management
    if Confirm.ask("\nDo you want to manage authentication tokens?"):
        for provider in ["github", "gitlab"]:
            if Confirm.ask(f"\nUpdate {provider} token?"):
                token = Prompt.ask(f"{provider.capitalize()} token", password=True)
                if token:
                    try:
                        keyring.set_password("docuflow", f"{provider}_token", token)
                        console.print(f"[green]{provider.capitalize()} token saved securely![/green]")
                    except Exception as e:
                        console.print(f"[red]Failed to save token: {e}[/red]")


@cli.command()
@click.argument('project_path', type=click.Path(exists=True), default='.')
def serve(project_path):
    """Serve documentation locally for development"""
    project_path = Path(project_path)
    
    if not (project_path / "mkdocs.yml").exists():
        console.print("[red]Error: mkdocs.yml not found in current directory![/red]")
        console.print("Make sure you're in a DocuFlow project directory.")
        sys.exit(1)
    
    console.print("[cyan]Starting documentation server...[/cyan]")
    console.print("Documentation will be available at: [bold]http://localhost:8000[/bold]")
    console.print("\nPress [bold]Ctrl+C[/bold] to stop the server.\n")
    
    try:
        subprocess.run(["poetry", "run", "mkdocs", "serve"], cwd=project_path)
    except KeyboardInterrupt:
        console.print("\n[yellow]Server stopped.[/yellow]")
    except FileNotFoundError:
        console.print("[red]Error: Poetry not found. Please install Poetry first.[/red]")
        console.print("Visit: https://python-poetry.org/docs/#installation")


@cli.command()
@click.argument('project_path', type=click.Path(exists=True), default='.')
@click.option('--clean', is_flag=True, help='Clean build directory before building')
def build(project_path, clean):
    """Build documentation site"""
    project_path = Path(project_path)
    
    if not (project_path / "mkdocs.yml").exists():
        console.print("[red]Error: mkdocs.yml not found in current directory![/red]")
        console.print("Make sure you're in a DocuFlow project directory.")
        sys.exit(1)
    
    if clean and (project_path / "site").exists():
        console.print("[yellow]Cleaning previous build...[/yellow]")
        shutil.rmtree(project_path / "site")
    
    console.print("[cyan]Building documentation...[/cyan]")
    
    try:
        result = subprocess.run(
            ["poetry", "run", "mkdocs", "build"],
            cwd=project_path,
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            console.print("[green]✅ Documentation built successfully![/green]")
            console.print(f"Output directory: {project_path / 'site'}")
        else:
            console.print("[red]Build failed![/red]")
            console.print(result.stderr)
    except FileNotFoundError:
        console.print("[red]Error: Poetry not found. Please install Poetry first.[/red]")
        console.print("Visit: https://python-poetry.org/docs/#installation")


@cli.command()
@click.argument('project_path', type=click.Path(exists=True), default='.')
@click.option('--force', is_flag=True, help='Force deployment without confirmation')
def deploy(project_path, force):
    """Deploy documentation to GitHub/GitLab Pages"""
    project_path = Path(project_path)
    
    if not (project_path / "mkdocs.yml").exists():
        console.print("[red]Error: mkdocs.yml not found in current directory![/red]")
        console.print("Make sure you're in a DocuFlow project directory.")
        sys.exit(1)
    
    # Check git repository
    if not (project_path / ".git").exists():
        console.print("[red]Error: Not a git repository![/red]")
        console.print("Initialize a git repository first.")
        return
    
    if not force:
        if not Confirm.ask("[yellow]Deploy documentation to GitHub/GitLab Pages?[/yellow]", default=True):
            console.print("Deployment cancelled.")
            return
    
    console.print("[cyan]Deploying documentation...[/cyan]")
    
    try:
        # For GitHub Pages, use mkdocs gh-deploy
        result = subprocess.run(
            ["poetry", "run", "mkdocs", "gh-deploy", "--force"],
            cwd=project_path,
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            console.print("[green]✅ Documentation deployed successfully![/green]")
            
            # Try to determine the URL
            try:
                repo = git.Repo(project_path)
                origin = repo.remote("origin")
                url = origin.url
                
                if "github.com" in url:
                    # Extract username and repo name
                    parts = url.replace(".git", "").split("/")
                    username = parts[-2].split(":")[-1]
                    reponame = parts[-1]
                    docs_url = f"https://{username}.github.io/{reponame}/"
                    console.print(f"\n📄 Documentation: [link]{docs_url}[/link]")
            except:
                pass
        else:
            console.print("[red]Deployment failed![/red]")
            console.print(result.stderr)
    except FileNotFoundError:
        console.print("[red]Error: Poetry not found. Please install Poetry first.[/red]")
        console.print("Visit: https://python-poetry.org/docs/#installation")


@cli.command()
def templates():
    """List available project templates"""
    console.print(Panel.fit("[bold cyan]DocuFlow Templates[/bold cyan]", border_style="cyan"))

    templates_info = {
        "basic": {
            "description": "Minimal setup with essential pages and plugins",
            "plugins": ["search", "awesome-pages", "mermaid2"],
            "structure": [
                "index.md",
                "getting-started.md",
                "Basic sections (user-guide, api-reference, tutorials)"
            ]
        },
        "full": {
            "description": "Comprehensive structure with all features enabled",
            "plugins": [
                "search",
                "awesome-pages",
                "mermaid2",
                "git-revision-date-localized",
                "minify"
            ],
            "structure": [
                "index.md",
                "getting-started.md",
                "All sections with examples",
                "Advanced features configured"
            ]
        }
    }

    for template_name, info in templates_info.items():
        console.print(f"\n[bold cyan]{template_name}[/bold cyan]")
        console.print(f"  {info['description']}")
        console.print("\n  [bold]Plugins:[/bold]")
        for plugin in info['plugins']:
            console.print(f"    • {plugin}")
        console.print("\n  [bold]Structure:[/bold]")
        for item in info['structure']:
            console.print(f"    • {item}")

    console.print("\n[dim]Use --template flag when initializing a project to select a template.[/dim]")


@cli.command()
@click.option('--version', '-v', help='Version to create')
@click.option('--title', help='Version title')
@click.option('--alias', '-a', multiple=True, help='Version aliases (e.g., latest, stable)')
@click.option('--no-tag', is_flag=True, help='Do not create git tag')
@click.option('--message', '-m', help='Tag message')
def version_create(version, title, alias, no_tag, message):
    """Create a new documentation version with mike and git tag"""
    from .version_manager import VersionManager

    project_path = Path.cwd()

    # Check if we're in a documentation project
    if not (project_path / "mkdocs.yml").exists():
        console.print("[red]Error: mkdocs.yml not found in current directory![/red]")
        console.print("Make sure you're in a DocuFlow project directory.")
        sys.exit(1)

    vm = VersionManager(project_path)

    if not version:
        version = Prompt.ask("Version number (e.g., 1.0)")

    if not title:
        title = Prompt.ask("Version title", default=f"Version {version}")

    aliases = list(alias) if alias else []

    success = vm.create_version(
        version=version,
        title=title,
        aliases=aliases,
        create_tag=not no_tag,
        tag_message=message
    )

    if success:
        console.print(f"\n[green]✓ Version {version} created successfully[/green]")
    else:
        console.print(f"\n[red]✗ Failed to create version {version}[/red]")
        sys.exit(1)


@cli.command()
def version_list():
    """List all versions and check alignment between git tags and mike versions"""
    from .version_manager import VersionManager

    project_path = Path.cwd()

    # Check if we're in a documentation project
    if not (project_path / "mkdocs.yml").exists():
        console.print("[red]Error: mkdocs.yml not found in current directory![/red]")
        console.print("Make sure you're in a DocuFlow project directory.")
        sys.exit(1)

    vm = VersionManager(project_path)

    aligned, only_git, only_mike = vm.check_alignment()

    table = Table(title="Version Alignment")
    table.add_column("Status", style="cyan")
    table.add_column("Version", style="magenta")

    for v in sorted(aligned):
        table.add_row("✓ Aligned", v)
    for v in sorted(only_git):
        table.add_row("⚠ Git only", v)
    for v in sorted(only_mike):
        table.add_row("⚠ Mike only", v)

    console.print(table)

    # Summary
    console.print(f"\n[bold]Summary:[/bold]")
    console.print(f"  Aligned: {len(aligned)}")
    console.print(f"  Git tags only: {len(only_git)}")
    console.print(f"  Mike versions only: {len(only_mike)}")


@cli.command()
@click.argument('sections', nargs=-1)
@click.option('--tag', '-t', help='Git tag/version to use (default: latest)')
@click.option('--output-dir', default='pdfs', help='Output directory')
def generate_pdf(sections, tag, output_dir):
    """Generate PDF documentation from markdown files"""
    from .pdf_generator import PDFGenerator

    project_path = Path.cwd()

    # Check if we're in a documentation project
    if not (project_path / "mkdocs.yml").exists():
        console.print("[red]Error: mkdocs.yml not found in current directory![/red]")
        console.print("Make sure you're in a DocuFlow project directory.")
        sys.exit(1)

    console.print(Panel.fit(
        "[bold cyan]PDF Generation[/bold cyan]\n"
        f"Output directory: {output_dir}",
        border_style="cyan"
    ))

    generator = PDFGenerator(project_path, output_dir)

    # Get sections to generate
    sections_to_generate = list(sections) if sections else None

    if sections_to_generate:
        console.print(f"\n[cyan]Generating PDFs for sections: {', '.join(sections_to_generate)}[/cyan]")
    else:
        console.print("\n[cyan]Generating PDFs for all configured sections[/cyan]")

    if tag:
        console.print(f"[cyan]Using version/tag: {tag}[/cyan]\n")

    try:
        pdf_files = generator.generate(sections=sections_to_generate, tag=tag)

        if pdf_files:
            console.print(f"\n[green]✓ Successfully generated {len(pdf_files)} PDF(s):[/green]")
            for pdf_file in pdf_files:
                console.print(f"  • {pdf_file}")
        else:
            console.print("\n[yellow]⚠ No PDFs were generated[/yellow]")

    except Exception as e:
        console.print(f"\n[red]✗ PDF generation failed: {e}[/red]")
        sys.exit(1)


if __name__ == '__main__':
    cli()
