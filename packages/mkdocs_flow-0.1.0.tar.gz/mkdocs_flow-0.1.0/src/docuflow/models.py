#!/usr/bin/env python3
"""
DocuFlow Models - Data classes and configuration structures
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class ProjectConfig:
    """Project configuration data class"""
    name: str
    description: str
    author_name: str
    author_email: str
    language: str = "en"
    git_provider: str = "github"
    repository_visibility: str = "public"
    repository_name: str = ""
    site_title: str = ""
    site_description: str = ""
    theme: str = "material"
    template: str = "basic"
    create_remote: bool = True
    plugins: List[str] = None

    def __post_init__(self):
        if not self.repository_name:
            self.repository_name = self.name
        if not self.site_title:
            self.site_title = self.name.replace("-", " ").title()
        if not self.site_description:
            self.site_description = self.description
        if self.plugins is None:
            self.plugins = ["search", "awesome-pages", "mermaid2"]


@dataclass
class PDFSection:
    """PDF section configuration"""
    name: str
    title: str
    output: str
    docs_dir: str


@dataclass
class PDFConfig:
    """PDF generation configuration"""
    sections: List[PDFSection] = field(default_factory=list)
    include_version_history: bool = True
    include_toc: bool = True
    toc_depth: int = 3
    embed_images: bool = True
    render_mermaid: bool = False
    create_release_zip: bool = False
    release_includes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for YAML serialization."""
        return {
            "sections": [
                {
                    "name": s.name,
                    "title": s.title,
                    "output": s.output,
                    "docs_dir": s.docs_dir
                }
                for s in self.sections
            ],
            "include_version_history": self.include_version_history,
            "include_toc": self.include_toc,
            "toc_depth": self.toc_depth,
            "embed_images": self.embed_images,
            "render_mermaid": self.render_mermaid,
            "create_release_zip": self.create_release_zip,
            "release_includes": self.release_includes
        }


@dataclass
class VersionConfig:
    """Version management configuration"""
    enable_mike: bool = True
    default_version_alias: str = "latest"
