#!/usr/bin/env python3
"""
PDF Generator for DocuFlow - Generate PDFs from markdown documentation.
"""

import base64
import re
import zipfile
from pathlib import Path
from typing import List, Dict, Optional, Any
import yaml
import markdown
from weasyprint import HTML, CSS
from rich.console import Console

from .export_utils import get_git_tags, find_markdown_files

console = Console()


class PDFGenerator:
    """Generates PDF documentation from markdown files."""

    def __init__(self, project_path: Path, output_dir: str = "pdfs"):
        self.project_path = Path(project_path)
        self.output_dir = self.project_path / output_dir
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load PDF configuration from pdf_config.yml."""
        config_file = self.project_path / "pdf_config.yml"
        if config_file.exists():
            with open(config_file, 'r') as f:
                return yaml.safe_load(f)
        return self._get_default_config()

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default PDF configuration."""
        return {
            "sections": [
                {
                    "name": "full-documentation",
                    "title": "Full Documentation",
                    "output": "documentation.pdf",
                    "docs_dir": "docs"
                }
            ],
            "include_version_history": True,
            "include_toc": True,
            "toc_depth": 3,
            "embed_images": True,
            "render_mermaid": False,
            "create_release_zip": False,
            "release_includes": []
        }

    def get_default_sections(self) -> List[str]:
        """Get default section names from config."""
        return [section["name"] for section in self.config.get("sections", [])]

    def generate_version_history_section(self) -> str:
        """Generate version history HTML section."""
        if not self.config.get("include_version_history", True):
            return ""

        tags = get_git_tags()
        if not tags:
            return ""

        html = '<div class="version-history">\n'
        html += '<h1>Version History</h1>\n'
        html += '<table>\n'
        html += '<thead><tr><th>Version</th><th>Date</th><th>Description</th></tr></thead>\n'
        html += '<tbody>\n'

        for tag in tags:
            version = tag['version']
            date = tag['date']
            description = tag['description'] or 'No description'
            # Escape HTML and replace newlines
            description = description.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            description = description.replace('\n', '<br>')

            html += f'<tr><td>{version}</td><td>{date}</td><td>{description}</td></tr>\n'

        html += '</tbody>\n</table>\n</div>\n'
        return html

    def generate_toc_html(self, content: str) -> str:
        """Generate table of contents from markdown headers."""
        if not self.config.get("include_toc", True):
            return ""

        toc_depth = self.config.get("toc_depth", 3)
        pattern = re.compile(r'^(#{1,' + str(toc_depth) + r'})\s+(.+)$', re.MULTILINE)
        matches = pattern.findall(content)

        if not matches:
            return ""

        html = '<div class="table-of-contents">\n'
        html += '<h1>Table of Contents</h1>\n'
        html += '<ul>\n'

        for level_markers, title in matches:
            level = len(level_markers)
            # Create anchor
            anchor = re.sub(r'[^\w\s-]', '', title.lower())
            anchor = re.sub(r'[-\s]+', '-', anchor)

            indent = '  ' * (level - 1)
            html += f'{indent}<li><a href="#{anchor}">{title}</a></li>\n'

        html += '</ul>\n</div>\n'
        return html

    def embed_images(self, html: str, docs_dir: Path) -> str:
        """Embed images as base64 data URIs."""
        if not self.config.get("embed_images", True):
            return html

        # Find all image tags
        pattern = re.compile(r'<img[^>]+src="([^"]+)"[^>]*>', re.IGNORECASE)

        def replace_image(match):
            src = match.group(1)

            # Skip if already a data URI or absolute URL
            if src.startswith('data:') or src.startswith('http'):
                return match.group(0)

            # Resolve image path
            image_path = docs_dir / src
            if not image_path.exists():
                console.print(f"[yellow]Warning: Image not found: {image_path}[/yellow]")
                return match.group(0)

            # Read and encode image
            try:
                with open(image_path, 'rb') as f:
                    image_data = f.read()
                    encoded = base64.b64encode(image_data).decode('utf-8')

                # Determine MIME type
                suffix = image_path.suffix.lower()
                mime_types = {
                    '.png': 'image/png',
                    '.jpg': 'image/jpeg',
                    '.jpeg': 'image/jpeg',
                    '.gif': 'image/gif',
                    '.svg': 'image/svg+xml',
                    '.webp': 'image/webp'
                }
                mime_type = mime_types.get(suffix, 'image/png')

                # Replace src with data URI
                new_src = f'data:{mime_type};base64,{encoded}'
                return match.group(0).replace(src, new_src)
            except Exception as e:
                console.print(f"[yellow]Warning: Failed to embed image {image_path}: {e}[/yellow]")
                return match.group(0)

        return pattern.sub(replace_image, html)

    def process_markdown_content(self, md_files: List[Path], docs_dir: Path) -> str:
        """Convert markdown files to HTML."""
        combined_content = ""

        for md_file in md_files:
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
                combined_content += content + "\n\n"

        # Convert markdown to HTML
        md = markdown.Markdown(extensions=[
            'extra',
            'codehilite',
            'toc',
            'tables',
            'fenced_code',
            'attr_list'
        ])
        html = md.convert(combined_content)

        # Embed images
        html = self.embed_images(html, docs_dir)

        return html

    def generate_pdf_css(self) -> str:
        """Generate CSS for PDF styling."""
        return """
        @page {
            size: A4;
            margin: 2cm;
            @top-center {
                content: string(doctitle);
            }
            @bottom-center {
                content: counter(page);
            }
        }

        body {
            font-family: 'DejaVu Sans', Arial, sans-serif;
            font-size: 11pt;
            line-height: 1.6;
            color: #333;
        }

        h1 {
            color: #2c3e50;
            font-size: 24pt;
            margin-top: 1em;
            margin-bottom: 0.5em;
            page-break-after: avoid;
        }

        h2 {
            color: #34495e;
            font-size: 18pt;
            margin-top: 0.8em;
            margin-bottom: 0.4em;
            page-break-after: avoid;
        }

        h3 {
            color: #34495e;
            font-size: 14pt;
            margin-top: 0.6em;
            margin-bottom: 0.3em;
            page-break-after: avoid;
        }

        code {
            background-color: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'DejaVu Sans Mono', 'Courier New', monospace;
            font-size: 9pt;
        }

        pre {
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            overflow-x: auto;
            page-break-inside: avoid;
        }

        pre code {
            background-color: transparent;
            padding: 0;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin: 1em 0;
            page-break-inside: avoid;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .version-history table {
            font-size: 10pt;
        }

        .table-of-contents {
            page-break-after: always;
        }

        .table-of-contents ul {
            list-style-type: none;
            padding-left: 0;
        }

        .table-of-contents li {
            margin: 0.3em 0;
        }

        .table-of-contents a {
            color: #3498db;
            text-decoration: none;
        }

        img {
            max-width: 100%;
            height: auto;
            page-break-inside: avoid;
        }

        blockquote {
            border-left: 4px solid #3498db;
            padding-left: 1em;
            margin-left: 0;
            font-style: italic;
            color: #555;
        }
        """

    def generate_combined_pdf(
        self,
        section: Dict[str, Any],
        tag: Optional[str] = None
    ) -> Path:
        """Generate a PDF for a documentation section."""
        section_name = section["name"]
        section_title = section["title"]
        output_filename = section["output"]
        docs_dir = self.project_path / section["docs_dir"]

        console.print(f"[cyan]Generating PDF for section: {section_name}[/cyan]")

        # Find markdown files
        try:
            md_files = find_markdown_files(docs_dir)
        except (FileNotFoundError, ValueError) as e:
            console.print(f"[red]Error: {e}[/red]")
            raise

        # Process markdown content
        html_content = self.process_markdown_content(md_files, docs_dir)

        # Build complete HTML document
        html_parts = ['<!DOCTYPE html>', '<html>', '<head>']
        html_parts.append('<meta charset="utf-8">')
        html_parts.append(f'<title>{section_title}</title>')
        html_parts.append('</head>', '<body>')

        # Add version history
        version_history = self.generate_version_history_section()
        if version_history:
            html_parts.append(version_history)

        # Add table of contents
        toc = self.generate_toc_html(html_content)
        if toc:
            html_parts.append(toc)

        # Add main content
        html_parts.append('<div class="content">')
        html_parts.append(html_content)
        html_parts.append('</div>')

        html_parts.append('</body>', '</html>')

        full_html = '\n'.join(html_parts)

        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Generate PDF
        output_path = self.output_dir / output_filename
        css = CSS(string=self.generate_pdf_css())

        console.print(f"[cyan]Writing PDF to: {output_path}[/cyan]")
        HTML(string=full_html).write_pdf(output_path, stylesheets=[css])

        console.print(f"[green]✓ PDF generated: {output_path}[/green]")
        return output_path

    def create_release_zip(
        self,
        pdf_files: List[Path],
        version: str
    ) -> Optional[Path]:
        """Create a release ZIP file with PDFs and additional files."""
        if not self.config.get("create_release_zip", False):
            return None

        zip_filename = f"release-{version}.zip"
        zip_path = self.output_dir / zip_filename

        console.print(f"[cyan]Creating release ZIP: {zip_filename}[/cyan]")

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Add PDFs
            for pdf_file in pdf_files:
                zipf.write(pdf_file, pdf_file.name)

            # Add additional files
            for pattern in self.config.get("release_includes", []):
                for file_path in self.project_path.glob(pattern):
                    if file_path.is_file():
                        zipf.write(file_path, file_path.name)

        console.print(f"[green]✓ Release ZIP created: {zip_path}[/green]")
        return zip_path

    def generate(
        self,
        sections: Optional[List[str]] = None,
        tag: Optional[str] = None
    ) -> List[Path]:
        """
        Generate PDFs for specified sections.

        Args:
            sections: List of section names to generate (None = all)
            tag: Git tag/version to use (None = current state)

        Returns:
            List of generated PDF file paths
        """
        all_sections = self.config.get("sections", [])

        # Filter sections if specified
        if sections:
            all_sections = [s for s in all_sections if s["name"] in sections]

        if not all_sections:
            console.print("[red]No sections found to generate[/red]")
            return []

        pdf_files = []
        for section in all_sections:
            try:
                pdf_path = self.generate_combined_pdf(section, tag)
                pdf_files.append(pdf_path)
            except Exception as e:
                console.print(f"[red]Failed to generate PDF for {section['name']}: {e}[/red]")

        # Create release ZIP if configured
        if pdf_files and tag and self.config.get("create_release_zip", False):
            self.create_release_zip(pdf_files, tag)

        return pdf_files
