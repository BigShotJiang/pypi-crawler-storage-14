#!/usr/bin/env python3
"""
Mermaid diagram renderer for DocuFlow - Converts Mermaid diagrams to images.
Requires playwright to be installed: pip install playwright && playwright install chromium
"""

import re
import base64
from pathlib import Path
from typing import Optional

try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False


class MermaidRenderer:
    """Renders Mermaid diagrams to images using Playwright."""

    def __init__(self):
        if not PLAYWRIGHT_AVAILABLE:
            raise ImportError(
                "Playwright is not installed. "
                "Install it with: pip install playwright && playwright install chromium"
            )

    def render_to_png(self, mermaid_code: str, output_path: Optional[Path] = None) -> bytes:
        """
        Render Mermaid diagram to PNG.

        Args:
            mermaid_code: Mermaid diagram code
            output_path: Optional path to save the PNG file

        Returns:
            PNG image as bytes
        """
        html_template = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
            <script>
                mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
            </script>
        </head>
        <body>
            <div class="mermaid">
{mermaid_code}
            </div>
        </body>
        </html>
        """

        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.set_content(html_template)

            # Wait for mermaid to render
            page.wait_for_selector('.mermaid svg', timeout=5000)

            # Get the SVG element
            svg_element = page.query_selector('.mermaid svg')
            if svg_element:
                # Take screenshot of the SVG
                screenshot = svg_element.screenshot()

                if output_path:
                    with open(output_path, 'wb') as f:
                        f.write(screenshot)

                browser.close()
                return screenshot

            browser.close()
            raise RuntimeError("Failed to render Mermaid diagram")

    def replace_mermaid_blocks_in_html(self, html: str, output_dir: Path) -> str:
        """
        Replace Mermaid code blocks in HTML with rendered images.

        Args:
            html: HTML content containing Mermaid blocks
            output_dir: Directory to save rendered images

        Returns:
            HTML with Mermaid blocks replaced by images
        """
        output_dir.mkdir(parents=True, exist_ok=True)

        # Find Mermaid code blocks
        pattern = re.compile(
            r'<pre><code class="language-mermaid">(.*?)</code></pre>',
            re.DOTALL | re.IGNORECASE
        )

        counter = 0

        def replace_block(match):
            nonlocal counter
            counter += 1
            mermaid_code = match.group(1).strip()

            try:
                # Render to PNG
                png_data = self.render_to_png(mermaid_code)

                # Encode as base64
                encoded = base64.b64encode(png_data).decode('utf-8')
                data_uri = f'data:image/png;base64,{encoded}'

                # Replace with img tag
                return f'<img src="{data_uri}" alt="Mermaid diagram {counter}" class="mermaid-diagram" />'

            except Exception as e:
                print(f"Warning: Failed to render Mermaid diagram {counter}: {e}")
                # Return original block if rendering fails
                return match.group(0)

        return pattern.sub(replace_block, html)

    def replace_mermaid_blocks_in_markdown(self, markdown: str, output_dir: Path) -> str:
        """
        Replace Mermaid code blocks in Markdown with image references.

        Args:
            markdown: Markdown content containing Mermaid blocks
            output_dir: Directory to save rendered images

        Returns:
            Markdown with Mermaid blocks replaced by image references
        """
        output_dir.mkdir(parents=True, exist_ok=True)

        # Find Mermaid code blocks
        pattern = re.compile(
            r'```mermaid\n(.*?)```',
            re.DOTALL | re.IGNORECASE
        )

        counter = 0

        def replace_block(match):
            nonlocal counter
            counter += 1
            mermaid_code = match.group(1).strip()

            try:
                # Render to PNG
                image_filename = f'mermaid-{counter}.png'
                image_path = output_dir / image_filename
                self.render_to_png(mermaid_code, image_path)

                # Replace with markdown image
                return f'![Mermaid diagram {counter}]({image_filename})'

            except Exception as e:
                print(f"Warning: Failed to render Mermaid diagram {counter}: {e}")
                # Return original block if rendering fails
                return match.group(0)

        return pattern.sub(replace_block, markdown)


def is_mermaid_available() -> bool:
    """Check if Mermaid rendering is available."""
    return PLAYWRIGHT_AVAILABLE
