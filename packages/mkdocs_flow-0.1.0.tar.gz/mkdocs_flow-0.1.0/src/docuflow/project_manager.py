#!/usr/bin/env python3
"""
DocuFlow Project Manager - Main project management and orchestration
"""

import yaml
import toml
import shutil
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from .models import ProjectConfig
from .template import TemplateManager
from .git_manager import GitManager
from .config import ConfigManager

console = Console()


class ProjectManager:
    """Main project management class"""
    
    def __init__(self, config: ProjectConfig, project_path: Path):
        self.config = config
        self.project_path = project_path
        self.template_manager = TemplateManager(config.template)
        self.git_manager = GitManager(project_path)
    
    def create_directory_structure(self):
        """Create project directory structure"""
        # Create main directories
        (self.project_path / "docs").mkdir(parents=True, exist_ok=True)
        (self.project_path / "docs" / "assets" / "images").mkdir(parents=True, exist_ok=True)
        (self.project_path / "docs" / "assets" / "css").mkdir(parents=True, exist_ok=True)
        (self.project_path / "docs" / "assets" / "js").mkdir(parents=True, exist_ok=True)
        (self.project_path / "docs" / "sections" / "user-guide").mkdir(parents=True, exist_ok=True)
        (self.project_path / "docs" / "sections" / "api-reference").mkdir(parents=True, exist_ok=True)
        (self.project_path / "docs" / "sections" / "tutorials").mkdir(parents=True, exist_ok=True)
        (self.project_path / "scripts").mkdir(parents=True, exist_ok=True)
        
        if self.config.git_provider == "github":
            (self.project_path / ".github" / "workflows").mkdir(parents=True, exist_ok=True)
    
    def create_configuration_files(self):
        """Create all configuration files"""
        # Create mkdocs.yml
        mkdocs_config = self.template_manager.get_mkdocs_config(self.config)
        with open(self.project_path / "mkdocs.yml", 'w') as f:
            yaml.dump(mkdocs_config, f, default_flow_style=False, sort_keys=False)
        
        # Create pyproject.toml
        pyproject_config = self.template_manager.get_pyproject_toml(self.config)
        with open(self.project_path / "pyproject.toml", 'w') as f:
            toml.dump(pyproject_config, f)
        
        # Create .gitignore
        with open(self.project_path / ".gitignore", 'w') as f:
            f.write(self.template_manager.get_gitignore())
        
        # Create README.md
        with open(self.project_path / "README.md", 'w') as f:
            f.write(self.template_manager.get_readme(self.config))
        
        # Create CI/CD configuration
        if self.config.git_provider == "github":
            # Ensure .github/workflows directory exists
            workflow_dir = self.project_path / ".github" / "workflows"
            workflow_dir.mkdir(parents=True, exist_ok=True)
            workflow_path = workflow_dir / "deploy-docs.yml"
            with open(workflow_path, 'w') as f:
                f.write(self.template_manager.get_github_workflow(self.config))
        else:
            with open(self.project_path / ".gitlab-ci.yml", 'w') as f:
                f.write(self.template_manager.get_gitlab_ci(self.config))
    
    def create_documentation_files(self):
        """Create initial documentation files"""
        # Create index.md
        with open(self.project_path / "docs" / "index.md", 'w') as f:
            f.write(self.template_manager.get_index_page(self.config))
        
        # Create getting-started.md
        with open(self.project_path / "docs" / "getting-started.md", 'w') as f:
            f.write(self.template_manager.get_getting_started_page(self.config))
        
        # Create section index files
        sections = ["user-guide", "api-reference", "tutorials"]
        for section in sections:
            section_path = self.project_path / "docs" / "sections" / section / "index.md"
            with open(section_path, 'w') as f:
                section_title = section.replace("-", " ").title()
                f.write(f"# {section_title}\n\nContent coming soon...")
    
    def create_scripts(self):
        """Create utility scripts"""
        # Create build.sh
        build_script = """#!/bin/bash
# Build documentation locally

echo "Building documentation..."
poetry run mkdocs build

echo "Documentation built in ./site directory
"""
        build_path = self.project_path / "scripts" / "build.sh"
        with open(build_path, 'w') as f:
            f.write(build_script)
        build_path.chmod(0o755)
        
        # Create serve.sh
        serve_script = """#!/bin/bash
# Serve documentation locally for development

echo "Starting documentation server..."
echo "Documentation will be available at http://localhost:8000"
poetry run mkdocs serve
"""
        serve_path = self.project_path / "scripts" / "serve.sh"
        with open(serve_path, 'w') as f:
            f.write(serve_script)
        serve_path.chmod(0o755)

    def create_pdf_generation_files(self):
        """Create PDF generation scripts and configuration in the project"""
        templates_dir = Path(__file__).parent / "templates"

        # Copy export_utils.py template
        export_utils_template = templates_dir / "export_utils.py.template"
        if export_utils_template.exists():
            shutil.copy(
                export_utils_template,
                self.project_path / "export_utils.py"
            )

        # Copy generate_pdf.py template
        generate_pdf_template = templates_dir / "generate_pdf.py.template"
        if generate_pdf_template.exists():
            shutil.copy(
                generate_pdf_template,
                self.project_path / "generate_pdf.py"
            )
            # Make it executable
            (self.project_path / "generate_pdf.py").chmod(0o755)

        # Copy mermaid_renderer.py template (optional)
        mermaid_template = templates_dir / "mermaid_renderer.py.template"
        if mermaid_template.exists():
            shutil.copy(
                mermaid_template,
                self.project_path / "mermaid_renderer.py"
            )

        # Create PDF config file
        pdf_config = self.template_manager.get_pdf_config(self.config)
        with open(self.project_path / "pdf_config.yml", 'w') as f:
            yaml.dump(pdf_config.to_dict(), f, default_flow_style=False, sort_keys=False)

    def setup_project(self, config_manager: ConfigManager) -> bool:
        """Complete project setup"""
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                
                # Create directory structure
                task = progress.add_task("Creating directory structure...", total=1)
                self.create_directory_structure()
                progress.advance(task)
                
                # Create configuration files
                task = progress.add_task("Creating configuration files...", total=1)
                self.create_configuration_files()
                progress.advance(task)
                
                # Create documentation files
                task = progress.add_task("Creating documentation files...", total=1)
                self.create_documentation_files()
                progress.advance(task)
                
                # Create scripts
                task = progress.add_task("Creating utility scripts...", total=1)
                self.create_scripts()
                progress.advance(task)

                # Create PDF generation files
                task = progress.add_task("Creating PDF generation files...", total=1)
                self.create_pdf_generation_files()
                progress.advance(task)

                # Initialize git repository
                task = progress.add_task("Initializing git repository...", total=1)
                self.git_manager.init_repository()
                self.git_manager.create_initial_commit()
                progress.advance(task)
                
                # Create remote repository if requested
                if self.config.create_remote:
                    task = progress.add_task(f"Creating {self.config.git_provider} repository...", total=1)
                    token = config_manager.get_token(self.config.git_provider)
                    
                    if token:
                        if self.config.git_provider == "github":
                            remote_url = self.git_manager.create_github_repo(self.config, token)
                        else:
                            remote_url = self.git_manager.create_gitlab_repo(self.config, token)
                        
                        self.git_manager.add_remote(remote_url)
                        
                        task = progress.add_task("Pushing to remote repository...", total=1)
                        self.git_manager.push_to_remote()
                        progress.advance(task)
                    else:
                        console.print("[yellow]Skipping remote repository creation (no token provided)[/yellow]")
                
            return True
            
        except Exception as e:
            console.print(f"[red]Error during project setup: {e}[/red]")
            return False
