#!/usr/bin/env python3
"""
DocuFlow Template Manager - Handles project templates and file generation
"""

import yaml
import toml
from pathlib import Path
from typing import Dict, Any, List
from .models import ProjectConfig, PDFSection, PDFConfig


class TemplateManager:
    """Manages project templates"""
    
    def __init__(self, template_type: str = "basic"):
        self.template_type = template_type
        self.templates_dir = Path(__file__).parent / "templates"
    
    def get_mkdocs_config(self, config: ProjectConfig) -> Dict[str, Any]:
        """Generate MkDocs configuration"""
        mkdocs_config = {
            "site_name": config.site_title,
            "site_description": config.site_description,
            "site_author": config.author_name,
            "site_url": f"https://{config.author_name}.github.io/{config.repository_name}/" if config.git_provider == "github" else "",
            
            "theme": {
                "name": config.theme,
                "language": config.language,
                "features": [
                    "navigation.tabs",
                    "navigation.sections",
                    "navigation.expand",
                    "navigation.top",
                    "search.suggest",
                    "search.highlight",
                    "content.code.copy"
                ],
                "palette": [
                    {
                        "media": "(prefers-color-scheme: light)",
                        "scheme": "default",
                        "primary": "indigo",
                        "accent": "indigo",
                        "toggle": {
                            "icon": "material/brightness-7",
                            "name": "Switch to dark mode"
                        }
                    },
                    {
                        "media": "(prefers-color-scheme: dark)",
                        "scheme": "slate",
                        "primary": "indigo",
                        "accent": "indigo",
                        "toggle": {
                            "icon": "material/brightness-4",
                            "name": "Switch to light mode"
                        }
                    }
                ]
            },
            
            "plugins": self._get_plugin_config(config.plugins),

            "extra": {
                "version": {
                    "provider": "mike"
                }
            },

            "markdown_extensions": [
                "pymdownx.highlight",
                "pymdownx.superfences",
                "pymdownx.tabbed",
                "pymdownx.details",
                "pymdownx.keys",
                "pymdownx.snippets",
                "admonition",
                "meta",
                "toc",
                "tables",
                "pymdownx.emoji",
                "pymdownx.tasklist"
            ],
            
            "nav": [
                {"Home": "index.md"},
                {"Getting Started": "getting-started.md"}
            ]
        }
        
        if "mermaid2" in config.plugins:
            mkdocs_config["markdown_extensions"].append("pymdownx.superfences")
            mkdocs_config["markdown_extensions"].append("pymdownx.superfences")
        
        return mkdocs_config
    
    def _get_plugin_config(self, plugins: List[str]) -> List[Any]:
        """Get plugin configuration"""
        plugin_configs = []
        
        for plugin in plugins:
            if plugin == "search":
                plugin_configs.append({"search": {"lang": "en"}})
            elif plugin == "git-revision-date-localized":
                plugin_configs.append({"git-revision-date-localized": {"type": "date"}})
            elif plugin == "mermaid2":
                plugin_configs.append({
                    "mermaid2": {
                        "arguments": {
                            "theme": "^(JSON.parse(__md_get('__palette').index == 1)) ? 'dark' : 'light'"
                        }
                    }
                })
            elif plugin == "minify":
                plugin_configs.append({"minify": {"minify_html": True}})
            else:
                plugin_configs.append(plugin)
        
        return plugin_configs
    
    def get_pyproject_toml(self, config: ProjectConfig) -> Dict[str, Any]:
        """Generate pyproject.toml configuration"""
        dependencies = {
            "python": "^3.8",
            "mkdocs": "^1.5.0",
            "mkdocs-material": "^9.4.0",
            "pymdown-extensions": "^10.3.0",
            "mike": "^2.1.3"
        }
        
        # Add plugin dependencies
        if "mermaid2" in config.plugins:
            dependencies["mkdocs-mermaid2-plugin"] = "^1.1.0"
        if "awesome-pages" in config.plugins:
            dependencies["mkdocs-awesome-pages-plugin"] = "^2.9.0"
        if "git-revision-date-localized" in config.plugins:
            dependencies["mkdocs-git-revision-date-localized-plugin"] = "^1.2.0"
        
        dev_dependencies = {}
        if "minify" in config.plugins:
            dev_dependencies["mkdocs-minify-plugin"] = "^0.7.0"
        dev_dependencies["mkdocs-redirects"] = "^1.2.0"
        
        return {
            "tool": {
                "poetry": {
                    "name": config.name,
                    "version": "0.1.0",
                    "description": config.description,
                    "authors": [f"{config.author_name} <{config.author_email}>"],
                    "readme": "README.md",
                    "dependencies": dependencies,
                    "group": {
                        "dev": {
                            "dependencies": dev_dependencies
                        }
                    },
                    "scripts": {
                        "serve": "mkdocs serve",
                        "build": "mkdocs build",
                        "deploy": "mkdocs gh-deploy --force"
                    }
                }
            }
        }
    
    def get_github_workflow(self, config: ProjectConfig) -> str:
        """Generate GitHub Actions workflow with mike support"""
        return """name: Deploy Documentation

on:
  push:
    branches:
      - main
      - master
    tags:
      - '*'
  workflow_dispatch:

permissions:
  contents: write
  pages: write
  id-token: write

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0  # Fetch all history for mike

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'

      - name: Install Poetry
        uses: snok/install-poetry@v1
        with:
          virtualenvs-create: true
          virtualenvs-in-project: true

      - name: Load cached venv
        id: cached-poetry-dependencies
        uses: actions/cache@v3
        with:
          path: .venv
          key: venv-${{ runner.os }}-${{ hashFiles('**/poetry.lock') }}

      - name: Install dependencies
        if: steps.cached-poetry-dependencies.outputs.cache-hit != 'true'
        run: poetry install --no-interaction --no-root

      - name: Configure Git
        run: |
          git config user.name github-actions
          git config user.email github-actions@github.com

      - name: Deploy with Mike
        run: |
          if [[ $GITHUB_REF == refs/tags/* ]]; then
            VERSION=${GITHUB_REF#refs/tags/}
            poetry run mike deploy --push --update-aliases $VERSION latest
          else
            poetry run mike deploy --push dev
          fi

      - name: Set default version
        run: poetry run mike set-default --push latest
"""
    
    def get_gitlab_ci(self, config: ProjectConfig) -> str:
        """Generate GitLab CI configuration"""
        return """image: python:3.10

variables:
  PIP_CACHE_DIR: "$CI_PROJECT_DIR/.cache/pip"

cache:
  paths:
    - .cache/pip
    - .venv/

before_script:
  - pip install poetry
  - poetry config virtualenvs.in-project true
  - poetry install

pages:
  stage: deploy
  script:
    - poetry run mkdocs build --site-dir public
  artifacts:
    paths:
      - public
  only:
    - main
    - master
"""
    
    def get_gitignore(self) -> str:
        """Generate .gitignore file"""
        return """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
.venv/
ENV/
env.bak/
venv.bak/

# MkDocs
site/
.cache/

# Poetry
dist/
*.egg-info/
poetry.lock

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.DS_Store

# Documentation build
docs/_build/

# PDF outputs
pdfs/
*.pdf
"""
    
    def get_readme(self, config: ProjectConfig) -> str:
        """Generate README.md file"""
        return f"""# {config.site_title}

{config.description}

## Documentation

This project uses [MkDocs](https://www.mkdocs.org/) with the [Material theme](https://squidfunk.github.io/mkdocs-material/) for documentation.

### Local Development

1. Install dependencies:
   ```bash
   poetry install
   ```

2. Serve documentation locally:
   ```bash
   poetry run mkdocs serve
   ```
   
   The documentation will be available at `http://localhost:8000`

3. Build documentation:
   ```bash
   poetry run mkdocs build
   ```

### Deployment

Documentation is automatically deployed to {"GitHub Pages" if config.git_provider == "github" else "GitLab Pages"} when changes are pushed to the main branch.

## Project Structure

```
{config.name}/
├── docs/               # Documentation source files
├── mkdocs.yml         # MkDocs configuration
├── pyproject.toml     # Poetry configuration
└── README.md          # This file
```

## Contributing

1. Create a new branch for your changes
2. Make your changes in the `docs/` directory
3. Test locally with `poetry run mkdocs serve`
4. Submit a pull request

## License

[Add your license here]

---

Generated with [DocuFlow](https://github.com/yourusername/docuflow)
"""
    
    def get_index_page(self, config: ProjectConfig) -> str:
        """Generate index.md page"""
        return f"""# Welcome to {config.site_title}

{config.site_description}

## Quick Start

Get started with our documentation:

- [Getting Started](getting-started.md) - Learn the basics
- [User Guide](sections/user-guide/index.md) - Detailed usage instructions
- [API Reference](sections/api-reference/index.md) - API documentation
- [Tutorials](sections/tutorials/index.md) - Step-by-step guides

## Features

!!! info "Key Features"
    - ✨ Feature 1: Description
    - 🚀 Feature 2: Description
    - 🔧 Feature 3: Description
    - 📚 Feature 4: Description

## Installation

```bash
# Add your installation instructions here
pip install your-package
```

## Basic Usage

```python
# Add a simple example here
import your_package

# Example code
result = your_package.do_something()
print(result)
```

## Support

- 📧 Email: {config.author_email}
- 🐛 Issues: [GitHub Issues](https://github.com/{config.author_name}/{config.repository_name}/issues)
- 💬 Discussions: [GitHub Discussions](https://github.com/{config.author_name}/{config.repository_name}/discussions)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
"""
    
    def get_getting_started_page(self, config: ProjectConfig) -> str:
        """Generate getting-started.md page"""
        return f"""# Getting Started

This guide will help you get started with {config.site_title}.

## Prerequisites

Before you begin, ensure you have the following installed:

- Prerequisite 1
- Prerequisite 2
- Prerequisite 3

## Installation

### Method 1: Package Manager

```bash
# Installation command here
```

### Method 2: From Source

```bash
# Clone the repository
git clone https://github.com/{config.author_name}/{config.repository_name}.git
cd {config.repository_name}

# Install dependencies
# Add installation steps
```

## Configuration

Create a configuration file:

```yaml
# Example configuration
setting1: value1
setting2: value2
```

## First Steps

### Step 1: Initialize

```bash
# Initialization command
```

### Step 2: Configure

```bash
# Configuration command
```

### Step 3: Run

```bash
# Run command
```

## Example

Here's a complete example:

```python
# Complete example code
import library

# Setup
config = {{
    'option1': 'value1',
    'option2': 'value2'
}}

# Usage
result = library.process(config)
print(result)
```

## Troubleshooting

### Common Issues

??? question "Issue 1: Problem description"
    
    **Solution**: How to fix it
    
    ```bash
    # Fix command
    ```

??? question "Issue 2: Another problem"
    
    **Solution**: Another fix
    
    ```bash
    # Another fix command
    ```

## Next Steps

- Explore the [User Guide](sections/user-guide/index.md)
- Check out the [API Reference](sections/api-reference/index.md)
- Try our [Tutorials](sections/tutorials/index.md)

## Getting Help

If you need help:

1. Check the [FAQ](faq.md)
2. Search [existing issues](https://github.com/{config.author_name}/{config.repository_name}/issues)
3. Ask in [Discussions](https://github.com/{config.author_name}/{config.repository_name}/discussions)
4. Contact support at {config.author_email}
"""

    def get_pdf_config(self, config: ProjectConfig) -> PDFConfig:
        """Generate PDF export configuration."""
        sections = [
            PDFSection(
                name="user-guide",
                title="User Guide",
                output="user-guide.pdf",
                docs_dir="docs/sections/user-guide"
            ),
            PDFSection(
                name="api-reference",
                title="API Reference",
                output="api-reference.pdf",
                docs_dir="docs/sections/api-reference"
            ),
            PDFSection(
                name="full-documentation",
                title=f"{config.site_title} - Complete Documentation",
                output=f"{config.name}-documentation.pdf",
                docs_dir="docs"
            )
        ]

        return PDFConfig(
            sections=sections,
            include_version_history=True,
            include_toc=True,
            toc_depth=3,
            embed_images=True,
            render_mermaid=False,
            create_release_zip=False,
            release_includes=[]
        )
