#!/usr/bin/env python3
"""
Common utilities for exporting markdown documentation to various formats.
"""

import subprocess
from pathlib import Path
from typing import List, Dict


def get_git_tags() -> List[Dict[str, str]]:
    """
    Get all git tags with their dates and descriptions.

    Returns:
        List of dicts with tag info (version, date, description) sorted by date descending
    """
    try:
        # First get list of tags with dates
        result = subprocess.run(
            [
                'git', 'for-each-ref',
                '--sort=-creatordate',
                '--format=%(refname:short)|%(creatordate:short)',
                'refs/tags'
            ],
            capture_output=True,
            text=True,
            check=True
        )

        tags = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('|')
                if len(parts) >= 2:
                    version = parts[0]
                    date = parts[1]

                    # Get full tag message body separately
                    msg_result = subprocess.run(
                        ['git', 'tag', '-l', '--format=%(contents)', version],
                        capture_output=True,
                        text=True,
                        check=True
                    )
                    description = msg_result.stdout.strip()

                    tags.append({
                        'version': version,
                        'date': date,
                        'description': description
                    })

        return tags
    except subprocess.CalledProcessError:
        return []


def find_markdown_files(docs_dir: Path) -> List[Path]:
    """
    Find all markdown files in the documentation directory.

    Args:
        docs_dir: Path to the documentation directory

    Returns:
        List of paths to markdown files, sorted by name
    """
    if not docs_dir.exists():
        raise FileNotFoundError(f"Documentation directory not found: {docs_dir}")

    md_files = sorted(docs_dir.rglob('*.md'))

    if not md_files:
        raise ValueError(f"No markdown files found in {docs_dir}")

    return md_files


def get_file_from_tag(tag: str, file_path: str) -> str:
    """
    Extract file contents from a specific git tag without checking out.

    Args:
        tag: Git tag name
        file_path: Path to file relative to repository root

    Returns:
        File contents as string
    """
    try:
        result = subprocess.run(
            ['git', 'show', f'{tag}:{file_path}'],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        raise FileNotFoundError(f"File {file_path} not found in tag {tag}: {e}")
