#!/usr/bin/env python3
"""
DocuFlow Git Manager - Handles Git operations and remote repository management
"""

from pathlib import Path
from typing import Optional
import git
from github import Github
from gitlab import Gitlab
from .models import ProjectConfig


class GitManager:
    """Manages Git operations"""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.repo = None
    
    def init_repository(self) -> git.Repo:
        """Initialize local git repository"""
        self.repo = git.Repo.init(self.project_path)
        return self.repo
    
    def create_initial_commit(self):
        """Create initial commit with all files"""
        if not self.repo:
            raise ValueError("Repository not initialized")
        
        self.repo.index.add("*")
        self.repo.index.commit("Initial commit: DocuFlow documentation project setup")
    
    def create_github_repo(self, config: ProjectConfig, token: str) -> str:
        """Create GitHub repository"""
        try:
            g = Github(token)
            user = g.get_user()
            
            repo = user.create_repo(
                name=config.repository_name,
                description=config.description,
                private=(config.repository_visibility == "private"),
                has_issues=True,
                has_wiki=False,
                has_downloads=True,
                has_projects=False,
                auto_init=False
            )
            
            # Enable GitHub Pages
            try:
                repo.create_pages_site(
                    build_type="workflow"
                )
            except Exception:
                # Pages might already be enabled or require different permissions
                pass
            
            return repo.clone_url
        except Exception as e:
            raise Exception(f"Failed to create GitHub repository: {e}")
    
    def create_gitlab_repo(self, config: ProjectConfig, token: str) -> str:
        """Create GitLab repository"""
        try:
            gl = Gitlab("https://gitlab.com", private_token=token)
            gl.auth()
            
            project = gl.projects.create({
                'name': config.repository_name,
                'description': config.description,
                'visibility': config.repository_visibility,
                'issues_enabled': True,
                'wiki_enabled': False,
                'pages_access_level': 'enabled' if config.repository_visibility == 'public' else 'private'
            })
            
            return project.http_url_to_repo
        except Exception as e:
            raise Exception(f"Failed to create GitLab repository: {e}")
    
    def add_remote(self, remote_url: str):
        """Add remote repository"""
        if not self.repo:
            raise ValueError("Repository not initialized")
        
        try:
            self.repo.create_remote("origin", remote_url)
        except git.exc.GitCommandError:
            # Remote might already exist
            origin = self.repo.remote("origin")
            origin.set_url(remote_url)
    
    def push_to_remote(self):
        """Push to remote repository"""
        if not self.repo:
            raise ValueError("Repository not initialized")
        
        origin = self.repo.remote("origin")
        origin.push("main", set_upstream=True)
