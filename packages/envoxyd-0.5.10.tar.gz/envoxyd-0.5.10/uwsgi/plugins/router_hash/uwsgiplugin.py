NAME='router_hash'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_hash']
