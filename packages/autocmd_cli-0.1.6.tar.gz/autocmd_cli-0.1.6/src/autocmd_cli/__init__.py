#!/usr/bin/env python3
import sys, os, re, getpass, shutil
from pathlib import Path
from typing import Optional, Tuple
from anthropic import Anthropic
from dotenv import load_dotenv

DEFAULT_MODEL = "claude-haiku-4-5-20251001"

def get_config_dir() -> Path:
    return Path.home() / ".config" / "autocmd"

def is_shell_setup() -> bool:
    return (get_config_dir() / ".shell_setup_done").exists()

def detect_shell() -> Tuple[Optional[str], Optional[Path]]:
    shell = os.environ.get("SHELL", "")
    if "zsh" in shell:
        return "zsh", Path.home() / ".zshrc"
    elif "bash" in shell:
        bashrc = Path.home() / ".bashrc"
        return "bash", bashrc if bashrc.exists() else Path.home() / ".bash_profile"
    return None, None

def setup_shell_integration() -> bool:
    shell_type, rc_file = detect_shell()
    if not shell_type:
        print("Unsupported shell.", file=sys.stderr)
        return False

    print("\nLet's go through a quick setup.", file=sys.stderr)
    print("Shell integration injects commands into your shell for easy editing.", file=sys.stderr)
    print("Enable? (y/n): ", end='', file=sys.stderr, flush=True)
    if input().strip().lower() != 'y':
        print("Skipping shell integration. Commands will be printed only.", file=sys.stderr)
        get_config_dir().mkdir(parents=True, exist_ok=True)
        (get_config_dir() / ".shell_setup_done").touch()
        return False

    autocmd_cmd = shutil.which("autocmd") or "uv tool run --from autocmd-cli autocmd"

    if shell_type == "zsh":
        wrapper = f'\n# autocmd\nautocmd() {{ local cmd=$({autocmd_cmd} "$@"); [ -n "$cmd" ] && print -z "$cmd"; }}\n'
    else:
        wrapper = f'\n# autocmd\nautocmd() {{ local cmd=$({autocmd_cmd} "$@"); [ -n "$cmd" ] && {{ READLINE_LINE="$cmd"; READLINE_POINT=${{#READLINE_LINE}}; }}; }}\n'

    if rc_file.exists() and "# autocmd" in rc_file.read_text():
        get_config_dir().mkdir(parents=True, exist_ok=True)
        (get_config_dir() / ".shell_setup_done").touch()
        return True

    with open(rc_file, "a") as f:
        f.write(wrapper)

    get_config_dir().mkdir(parents=True, exist_ok=True)
    (get_config_dir() / ".shell_setup_done").touch()
    return True

def get_api_key() -> str:
    if key := os.environ.get("ANTHROPIC_API_KEY"):
        return key

    config_path = get_config_dir() / "config"
    if config_path.exists():
        return config_path.read_text().strip()

    print("Anthropic API key: ", end='', file=sys.stderr, flush=True)
    key = getpass.getpass("").strip()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(key)
    return key

def reset_autocmd() -> None:
    config_dir = get_config_dir()
    if config_dir.exists():
        shutil.rmtree(config_dir)

    shell_type, rc_file = detect_shell()
    if rc_file and rc_file.exists():
        content = rc_file.read_text()
        if "# autocmd" in content:
            lines = content.split('\n')
            new_lines = []
            skip = False
            for line in lines:
                if "# autocmd" in line:
                    skip = True
                elif skip and '}' in line:
                    skip = False
                    continue
                elif not skip:
                    new_lines.append(line)
            rc_file.write_text('\n'.join(new_lines))
            print(f"Reset complete. Run: source {rc_file}", file=sys.stderr)
        else:
            print("Reset complete.", file=sys.stderr)

def main() -> None:
    # Force unbuffered stderr
    if sys.stderr:
        sys.stderr.reconfigure(write_through=True) if hasattr(sys.stderr, 'reconfigure') else None

    load_dotenv()

    if len(sys.argv) > 1 and sys.argv[1] == "--reset":
        reset_autocmd()
        sys.exit(0)

    if not is_shell_setup():
        print("Welcome to autocmd! The text-to-command assistant.", file=sys.stderr)
        setup_shell_integration()
        get_api_key()
        shell_type, rc_file = detect_shell()
        if rc_file:
            print(f"Setup complete! Reload your shell to activate:", file=sys.stderr)
            print(f"  source {rc_file}", file=sys.stderr)
        sys.exit(0)

    api_key = get_api_key()

    if len(sys.argv) < 2:
        print('autocmd: The text-to-command assistant', file=sys.stderr)
        sys.exit(1)

    try:
        client = Anthropic(api_key=api_key)
        with client.messages.stream(
            model=os.environ.get("AUTOCMD_MODEL", DEFAULT_MODEL),
            max_tokens=200,
            messages=[{"role": "user", "content": f"Convert to {os.environ.get('SHELL', 'bash')} command (no markdown): {' '.join(sys.argv[1:])}"}]
        ) as stream:
            full_response = ""
            for text in stream.text_stream:
                # Write directly to buffer to bypass any text wrapper buffering
                if hasattr(sys.stderr, 'buffer'):
                    sys.stderr.buffer.write(text.encode('utf-8'))
                    sys.stderr.buffer.flush()
                else:
                    print(text, end="", flush=True, file=sys.stderr)
                full_response += text
            
            # Clear the streamed output
            if sys.stderr.isatty():
                # Count lines to move up
                num_lines = full_response.count('\n')
                # Move up num_lines, then clear to end of screen (\033[J)
                # \033[2K clears the current line, \033[1G moves to column 1
                if num_lines > 0:
                    print(f"\033[{num_lines}A", end="", file=sys.stderr)
                print("\r\033[J", end="", file=sys.stderr, flush=True)
            else:
                # If not a TTY, just print a newline to separate
                print("", file=sys.stderr)
            
            cmd = re.sub(r'^```\w*\n?|```$', '', full_response).strip()
            if not cmd:
                print("No command generated", file=sys.stderr)
                sys.exit(1)
            print(cmd)

    except KeyboardInterrupt:
        print("\nCancelled", file=sys.stderr)
        sys.exit(130)
    except OSError as e:
        print(f"Error: File system error - {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        error_msg = str(e)
        if "api_key" in error_msg.lower() or "authentication" in error_msg.lower():
            print(f"Error: Invalid API key. Run 'autocmd --reset' to reconfigure.", file=sys.stderr)
        elif "rate" in error_msg.lower() or "quota" in error_msg.lower():
            print(f"Error: API rate limit or quota exceeded. Please try again later.", file=sys.stderr)
        elif "network" in error_msg.lower() or "connection" in error_msg.lower():
            print(f"Error: Network connection failed. Check your internet connection.", file=sys.stderr)
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
