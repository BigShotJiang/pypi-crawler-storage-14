"""
PDF Comment Extractor Module
Extract comments and annotations from PDF files.
"""

import fitz  # PyMuPDF
import json
import csv
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional


class PDFCommentExtractor:
    """
    Extract comments and annotations from PDF files.
    
    This class provides methods to extract all types of PDF annotations including
    highlights, sticky notes, text comments, and more, along with the text they reference.
    
    Attributes:
        pdf_path (Path): Path to the PDF file
        doc (fitz.Document): PyMuPDF document object
        
    Example:
        >>> extractor = PDFCommentExtractor('paper.pdf')
        >>> comments = extractor.extract_all_comments()
        >>> extractor.save_to_json(comments, 'output.json')
        >>> extractor.close()
    """
    
    def __init__(self, pdf_path: str):
        """
        Initialize with path to PDF file.
        
        Args:
            pdf_path: Path to the PDF file to extract comments from
            
        Raises:
            FileNotFoundError: If PDF file doesn't exist
            RuntimeError: If PDF cannot be opened
        """
        self.pdf_path = Path(pdf_path)
        
        if not self.pdf_path.exists():
            raise FileNotFoundError(f"PDF file not found: {pdf_path}")
        
        try:
            self.doc = fitz.open(str(self.pdf_path))
        except Exception as e:
            raise RuntimeError(f"Failed to open PDF: {e}")
        
    def extract_all_comments(self) -> List[Dict[str, Any]]:
        """
        Extract all annotations from the PDF.
        
        Returns:
            List of dictionaries containing comment data with keys:
            - page: Page number (1-indexed)
            - type: Annotation type (Highlight, Text, etc.)
            - subject: Annotation subject/title
            - author: Comment author
            - comment: Comment text content
            - referenced_text: Text that the annotation references
            - position: Dict with x0, y0, x1, y1 coordinates
            - created: Creation date
            - modified: Modification date
            - color: Annotation color
        """
        comments = []
        
        for page_num in range(len(self.doc)):
            page = self.doc[page_num]
            annotations = page.annots()
            
            if annotations:
                for annot in annotations:
                    comment_data = self._extract_annotation_data(annot, page, page_num)
                    if comment_data:
                        comments.append(comment_data)
        
        return comments
    
    def _extract_annotation_data(
        self, 
        annot: fitz.Annot, 
        page: fitz.Page, 
        page_num: int
    ) -> Optional[Dict[str, Any]]:
        """
        Extract data from a single annotation.
        
        Args:
            annot: PyMuPDF annotation object
            page: PyMuPDF page object
            page_num: Page number (0-indexed)
            
        Returns:
            Dictionary with annotation data or None if extraction fails
        """
        try:
            annot_type = annot.type[1]
            rect = annot.rect
            
            # Extract text within the annotation rectangle
            referenced_text = page.get_textbox(rect).strip()
            
            # Get annotation content
            comment_text = annot.info.get("content", "").strip()
            subject = annot.info.get("subject", "")
            author = annot.info.get("title", "")
            created = annot.info.get("creationDate", "")
            modified = annot.info.get("modDate", "")
            color = annot.colors
            
            return {
                "page": page_num + 1,
                "type": annot_type,
                "subject": subject,
                "author": author,
                "comment": comment_text,
                "referenced_text": referenced_text,
                "position": {
                    "x0": rect.x0,
                    "y0": rect.y0,
                    "x1": rect.x1,
                    "y1": rect.y1
                },
                "created": created,
                "modified": modified,
                "color": color
            }
            
        except Exception as e:
            print(f"Warning: Error extracting annotation on page {page_num + 1}: {e}")
            return None
    
    def save_to_json(self, comments: List[Dict], output_path: str) -> None:
        """
        Save extracted comments to JSON file.
        
        Args:
            comments: List of comment dictionaries
            output_path: Path to output JSON file
        """
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump({
                "source_pdf": str(self.pdf_path.name),
                "extraction_date": datetime.now().isoformat(),
                "total_comments": len(comments),
                "comments": comments
            }, f, indent=2, ensure_ascii=False)
        
        print(f"Saved {len(comments)} comments to {output_file}")
    
    def save_to_csv(self, comments: List[Dict], output_path: str) -> None:
        """
        Save extracted comments to CSV file.
        
        Args:
            comments: List of comment dictionaries
            output_path: Path to output CSV file
        """
        if not comments:
            print("No comments to save")
            return
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Flatten nested position dict
        flattened_comments = []
        for comment in comments:
            flat = {
                "page": comment["page"],
                "type": comment["type"],
                "subject": comment["subject"],
                "author": comment["author"],
                "comment": comment["comment"],
                "referenced_text": comment["referenced_text"],
                "position_x0": comment["position"]["x0"],
                "position_y0": comment["position"]["y0"],
                "position_x1": comment["position"]["x1"],
                "position_y1": comment["position"]["y1"],
                "created": comment["created"],
                "modified": comment["modified"],
            }
            flattened_comments.append(flat)
        
        with open(output_file, 'w', encoding='utf-8', newline='') as f:
            if flattened_comments:
                writer = csv.DictWriter(f, fieldnames=flattened_comments[0].keys())
                writer.writeheader()
                writer.writerows(flattened_comments)
        
        print(f"Saved {len(comments)} comments to {output_file}")
    
    def print_summary(self, comments: List[Dict]) -> None:
        """
        Print a summary of extracted comments to console.
        
        Args:
            comments: List of comment dictionaries
        """
        print(f"\n{'='*80}")
        print(f"PDF: {self.pdf_path.name}")
        print(f"Total Comments: {len(comments)}")
        print(f"{'='*80}\n")
        
        for i, comment in enumerate(comments, 1):
            print(f"Comment #{i}")
            print(f"  Page: {comment['page']}")
            print(f"  Type: {comment['type']}")
            if comment['subject']:
                print(f"  Subject: {comment['subject']}")
            if comment['author']:
                print(f"  Author: {comment['author']}")
            if comment['comment']:
                print(f"  Comment: {comment['comment']}")
            if comment['referenced_text']:
                ref_text = comment['referenced_text'][:100]
                print(f"  Referenced Text: {ref_text}{'...' if len(comment['referenced_text']) > 100 else ''}")
            print(f"  {'-'*76}")
    
    def close(self) -> None:
        """Close the PDF document."""
        if hasattr(self, 'doc'):
            self.doc.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

