class AcademicPaperExtractor:
    """Extract structured content from academic papers."""
    
    def __init__(self, pdf_path: str):
        """Initialize with path to PDF file."""
        self.pdf_path = Path(pdf_path)
        self.doc = fitz.open(str(self.pdf_path))
        self.full_text = self._extract_full_text()
        
    def _extract_full_text(self) -> str:
        """Extract all text from the PDF."""
        text = ""
        for page in self.doc:
            text += page.get_text()
        return text
    
    def extract_sections(self) -> Dict[str, str]:
        """Extract main sections of the paper."""
        sections = {}
        
        # Common section patterns in academic papers
        section_patterns = [
            (r'Abstract\s*\n(.*?)(?=\n\s*\d+\s+Introduction|\n\s*Introduction|\n\s*1\.?\s+Introduction)', 'Abstract'),
            (r'(?:\d+\s+)?Introduction\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*2\.?\s+)', 'Introduction'),
            (r'(?:\d+\s+)?Related Work\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*3\.?\s+)', 'Related Work'),
            (r'(?:\d+\s+)?Methodology\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*4\.?\s+)', 'Methodology'),
            (r'(?:\d+\s+)?Methods\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*4\.?\s+)', 'Methods'),
            (r'(?:\d+\s+)?Results\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*5\.?\s+)', 'Results'),
            (r'(?:\d+\s+)?Discussion\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*6\.?\s+)', 'Discussion'),
            (r'(?:\d+\s+)?Conclusion\s*\n(.*?)(?=\n\s*\d+\s+|References|\n\s*7\.?\s+)', 'Conclusion'),
            (r'(?:\d+\s+)?Limitations\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*References)', 'Limitations'),
            (r'(?:\d+\s+)?Future Work\s*\n(.*?)(?=\n\s*\d+\s+|\n\s*References)', 'Future Work'),
        ]
        
        for pattern, section_name in section_patterns:
            match = re.search(pattern, self.full_text, re.DOTALL | re.IGNORECASE)
            if match:
                sections[section_name] = match.group(1).strip()
        
        return sections
    
    def extract_citations(self) -> List[Dict[str, Any]]:
        """Extract all citations with their context."""
        citations = []
        
        # Pattern for common citation formats
        # [Author Year], (Author Year), Author et al. [Year], etc.
        citation_patterns = [
            r'([A-Z][a-zA-Z\s]+(?:et al\.)?)\s*\[(\d{4}[a-z]?)\]',  # Author [2020]
            r'([A-Z][a-zA-Z\s]+(?:et al\.)?)\s*\((\d{4}[a-z]?)\)',   # Author (2020)
            r'\[([A-Z][a-zA-Z\s,]+)\s+(\d{4}[a-z]?)\]',              # [Author, 2020]
            r'([A-Z][a-z]+(?:\s+and\s+[A-Z][a-z]+)?)\s+\[(\d{4}[a-z]?)\]',  # Smith and Jones [2020]
        ]
        
        # Extract context window around citations
        context_window = 200  # characters before and after
        
        for pattern in citation_patterns:
            for match in re.finditer(pattern, self.full_text):
                author = match.group(1).strip()
                year = match.group(2).strip()
                
                # Get surrounding context
                start = max(0, match.start() - context_window)
                end = min(len(self.full_text), match.end() + context_window)
                context = self.full_text[start:end].replace('\n', ' ')
                
                # Find which page this citation is on
                page_num = self._find_page_for_position(match.start())
                
                citations.append({
                    'author': author,
                    'year': year,
                    'citation_text': match.group(0),
                    'context': context,
                    'page': page_num,
                    'position': match.start()
                })
        
        # Remove duplicates while preserving order
        seen = set()
        unique_citations = []
        for citation in citations:
            key = (citation['author'], citation['year'], citation['context'][:50])
            if key not in seen:
                seen.add(key)
                unique_citations.append(citation)
        
        return unique_citations
    
    def extract_references(self) -> List[Dict[str, str]]:
        """Extract the reference list."""
        references = []
        
        # Find the References section
        ref_match = re.search(
            r'(?:References|Bibliography|REFERENCES)\s*\n(.*?)(?:\n\s*Appendix|\n\s*A\s+[A-Z]|\Z)',
            self.full_text,
            re.DOTALL | re.IGNORECASE
        )
        
        if not ref_match:
            return references
        
        ref_text = ref_match.group(1)
        
        # Split references (usually separated by blank lines or start with author name)
        # Pattern: Lines starting with capital letter or number
        ref_pattern = r'(?:^|\n)([A-Z][^\n]+(?:\n(?!\s*\n)[^\n]+)*)'
        
        for match in re.finditer(ref_pattern, ref_text, re.MULTILINE):
            ref_full = match.group(1).strip()
            if len(ref_full) > 20:  # Filter out noise
                # Try to parse author, year, title
                parsed_ref = self._parse_reference(ref_full)
                references.append(parsed_ref)
        
        return references
    
    def _parse_reference(self, ref_text: str) -> Dict[str, str]:
        """Parse a reference into components."""
        # Basic parsing - extract author, year, title
        result = {'full_text': ref_text}
        
        # Try to extract year
        year_match = re.search(r'\b(19|20)\d{2}[a-z]?\b', ref_text)
        if year_match:
            result['year'] = year_match.group(0)
        
        # Try to extract authors (first part before year)
        if 'year' in result:
            author_text = ref_text[:ref_text.find(result['year'])].strip()
            result['authors'] = author_text.rstrip('.,')
        else:
            # First sentence or first 100 chars
            result['authors'] = ref_text.split('.')[0] if '.' in ref_text else ref_text[:100]
        
        # Extract title (text between year and journal/conference)
        # Usually after year and before publication venue
        if 'year' in result:
            after_year = ref_text[ref_text.find(result['year']) + len(result['year']):]
            # Title is usually the next sentence or until we hit "In " or journal name
            title_match = re.search(r'[.]\s*([^.]+?)(?:\.|In\s|Proceedings|\d+\()', after_year)
            if title_match:
                result['title'] = title_match.group(1).strip()
        
        return result
    
    def map_citations_to_references(
        self,
        citations: List[Dict[str, Any]],
        references: List[Dict[str, str]]
    ) -> List[Dict[str, Any]]:
        """Map citations to their full references."""
        mapped = []
        
        for citation in citations:
            citation_author = citation['author'].lower()
            citation_year = citation['year']
            
            # Find matching reference
            matching_ref = None
            for ref in references:
                ref_authors = ref.get('authors', '').lower()
                ref_year = ref.get('year', '')
                
                # Check if citation author appears in reference authors and years match
                if citation_year == ref_year and any(
                    author_part in ref_authors 
                    for author_part in citation_author.split()[:2]  # First two words
                ):
                    matching_ref = ref
                    break
            
            mapped.append({
                'citation': citation,
                'reference': matching_ref
            })
        
        return mapped
    
    def extract_figures_and_tables(self) -> Dict[str, List[Dict[str, Any]]]:
        """Extract figures and tables with captions."""
        elements = {'figures': [], 'tables': []}
        
        # Pattern for figure captions
        fig_pattern = r'(?:Figure|Fig\.?)\s*(\d+)[:\.]?\s*([^\n]+(?:\n(?!Figure|Table|Fig\.)[^\n]+)*)'
        table_pattern = r'Table\s*(\d+)[:\.]?\s*([^\n]+(?:\n(?!Figure|Table|Fig\.)[^\n]+)*)'
        
        # Extract figures
        for match in re.finditer(fig_pattern, self.full_text, re.IGNORECASE):
            fig_num = match.group(1)
            caption = match.group(2).strip()
            page_num = self._find_page_for_position(match.start())
            
            elements['figures'].append({
                'number': fig_num,
                'caption': caption,
                'page': page_num,
                'position': match.start()
            })
        
        # Extract tables
        for match in re.finditer(table_pattern, self.full_text, re.IGNORECASE):
            table_num = match.group(1)
            caption = match.group(2).strip()
            page_num = self._find_page_for_position(match.start())
            
            elements['tables'].append({
                'number': table_num,
                'caption': caption,
                'page': page_num,
                'position': match.start()
            })
        
        return elements
    
    def extract_key_contributions(self) -> List[str]:
        """Extract key contributions and findings."""
        contributions = []
        
        # Look for common patterns indicating contributions
        patterns = [
            r'(?:We\s+(?:present|propose|introduce|develop|demonstrate))\s+([^.]+\.)',
            r'(?:Our\s+(?:contribution|approach|method|system))\s+([^.]+\.)',
            r'(?:This\s+(?:work|paper|research))\s+(?:presents|proposes|introduces)\s+([^.]+\.)',
        ]
        
        for pattern in patterns:
            for match in re.finditer(pattern, self.full_text, re.IGNORECASE):
                contribution = match.group(0).strip()
                if len(contribution) > 20:
                    contributions.append(contribution)
        
        return contributions
    
    def extract_metadata(self) -> Dict[str, Any]:
        """Extract paper metadata."""
        metadata = {
            'pdf_metadata': self.doc.metadata,
            'total_pages': len(self.doc),
            'word_count': len(self.full_text.split()),
        }
        
        # Try to extract title (usually on first page, large font)
        first_page = self.doc[0]
        blocks = first_page.get_text("dict")["blocks"]
        
        # Find largest font text (likely title)
        max_size = 0
        title_text = ""
        for block in blocks:
            if "lines" in block:
                for line in block["lines"]:
                    for span in line["spans"]:
                        if span["size"] > max_size:
                            max_size = span["size"]
                            title_text = span["text"]
        
        if title_text:
            metadata['extracted_title'] = title_text
        
        # Try to extract authors (usually after title, before abstract)
        author_pattern = r'(?:^|\n)([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+(?:,\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)*)\s*\n'
        author_match = re.search(author_pattern, self.full_text[:1000])
        if author_match:
            metadata['extracted_authors'] = author_match.group(1)
        
        return metadata
    
    def _find_page_for_position(self, text_position: int) -> int:
        """Find which page a text position corresponds to."""
        current_pos = 0
        for page_num, page in enumerate(self.doc):
            page_text = page.get_text()
            current_pos += len(page_text)
            if current_pos >= text_position:
                return page_num + 1
        return len(self.doc)
    
    def extract_all(self) -> Dict[str, Any]:
        """Extract all content from the paper."""
        print("Extracting sections...")
        sections = self.extract_sections()
        
        print("Extracting citations...")
        citations = self.extract_citations()
        
        print("Extracting references...")
        references = self.extract_references()
        
        print("Mapping citations to references...")
        citation_mapping = self.map_citations_to_references(citations, references)
        
        print("Extracting figures and tables...")
        figures_tables = self.extract_figures_and_tables()
        
        print("Extracting key contributions...")
        contributions = self.extract_key_contributions()
        
        print("Extracting metadata...")
        metadata = self.extract_metadata()
        
        return {
            'metadata': metadata,
            'sections': sections,
            'citations': citations,
            'references': references,
            'citation_mapping': citation_mapping,
            'figures': figures_tables['figures'],
            'tables': figures_tables['tables'],
            'contributions': contributions,
            'statistics': {
                'total_sections': len(sections),
                'total_citations': len(citations),
                'total_references': len(references),
                'total_figures': len(figures_tables['figures']),
                'total_tables': len(figures_tables['tables']),
                'total_contributions': len(contributions),
            }
        }
    
    def save_to_json(self, data: Dict[str, Any], output_path: str):
        """Save extracted data to JSON."""
        output_file = Path(output_path)
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"\nSaved complete extraction to {output_file}")
    
    def save_to_csv(self, data: Dict[str, Any], output_dir: str):
        """Save extracted data to multiple CSV files."""
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True)
        
        # Save sections
        if data['sections']:
            with open(output_dir / 'sections.csv', 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Section', 'Content'])
                for section, content in data['sections'].items():
                    writer.writerow([section, content])
        
        # Save citations
        if data['citations']:
            with open(output_dir / 'citations.csv', 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=data['citations'][0].keys())
                writer.writeheader()
                writer.writerows(data['citations'])
        
        # Save references
        if data['references']:
            with open(output_dir / 'references.csv', 'w', encoding='utf-8', newline='') as f:
                fieldnames = list(data['references'][0].keys())
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(data['references'])
        
        # Save citation mapping
        if data['citation_mapping']:
            with open(output_dir / 'citation_mapping.csv', 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Citation_Author', 'Citation_Year', 'Citation_Context', 'Reference_Full', 'Page'])
                for item in data['citation_mapping']:
                    cit = item['citation']
                    ref = item['reference']
                    writer.writerow([
                        cit['author'],
                        cit['year'],
                        cit['context'][:200],
                        ref['full_text'][:200] if ref else 'NOT FOUND',
                        cit['page']
                    ])
        
        # Save figures
        if data['figures']:
            with open(output_dir / 'figures.csv', 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=data['figures'][0].keys())
                writer.writeheader()
                writer.writerows(data['figures'])
        
        # Save tables
        if data['tables']:
            with open(output_dir / 'tables.csv', 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=data['tables'][0].keys())
                writer.writeheader()
                writer.writerows(data['tables'])
        
        print(f"\nSaved CSV files to {output_dir}/")
    
    def print_summary(self, data: Dict[str, Any]):
        """Print a summary of extracted content."""
        print(f"\n{'='*80}")
        print(f"EXTRACTION SUMMARY")
        print(f"{'='*80}\n")
        
        # Metadata
        print("METADATA:")
        print(f"  Title: {data['metadata'].get('extracted_title', 'N/A')}")
        print(f"  Authors: {data['metadata'].get('extracted_authors', 'N/A')}")
        print(f"  Pages: {data['metadata']['total_pages']}")
        print(f"  Words: {data['metadata']['word_count']:,}")
        
        # Statistics
        stats = data['statistics']
        print(f"\nSTATISTICS:")
        print(f"  Sections: {stats['total_sections']}")
        print(f"  Citations: {stats['total_citations']}")
        print(f"  References: {stats['total_references']}")
        print(f"  Figures: {stats['total_figures']}")
        print(f"  Tables: {stats['total_tables']}")
        print(f"  Key Contributions: {stats['total_contributions']}")
        
        # Sections found
        print(f"\nSECTIONS FOUND:")
        for section in data['sections'].keys():
            word_count = len(data['sections'][section].split())
            print(f"  - {section} ({word_count} words)")
        
        # Sample citations
        print(f"\nSAMPLE CITATIONS (first 5):")
