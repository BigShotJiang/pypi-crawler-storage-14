"""
Command-line interface for PDF Comments Extractor.
"""

import argparse
import sys
from pathlib import Path
from .comment_extractor import PDFCommentExtractor
from .academic_extractor import AcademicPaperExtractor
from .search import search_text_in_pdf


def extract_comments_cli():
    """CLI for extracting comments from PDFs."""
    parser = argparse.ArgumentParser(
        description="Extract comments and annotations from PDF files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Extract comments from a single PDF
  pdf-comments-extract paper.pdf
  
  # Extract with console output
  pdf-comments-extract paper.pdf --print
  
  # Specify output directory and format
  pdf-comments-extract paper.pdf --output-dir ./comments --format json
  
  # Process multiple PDFs
  pdf-comments-extract file1.pdf file2.pdf file3.pdf
        """
    )
    
    parser.add_argument(
        "pdf_files",
        nargs="+",
        help="Path(s) to PDF file(s)"
    )
    parser.add_argument(
        "--output-dir",
        default="./pdf_comments_output",
        help="Output directory for extracted comments (default: ./pdf_comments_output)"
    )
    parser.add_argument(
        "--format",
        choices=["json", "csv", "both"],
        default="both",
        help="Output format (default: both)"
    )
    parser.add_argument(
        "--print",
        action="store_true",
        dest="print_output",
        help="Print summary to console"
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0"
    )
    
    args = parser.parse_args()
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True, parents=True)
    
    # Process each PDF file
    for pdf_path in args.pdf_files:
        print(f"\nProcessing: {pdf_path}")
        
        try:
            with PDFCommentExtractor(pdf_path) as extractor:
                comments = extractor.extract_all_comments()
                
                if not comments:
                    print(f"No comments found in {pdf_path}")
                    continue
                
                # Generate output filename base
                pdf_name = Path(pdf_path).stem
                
                # Save in requested format(s)
                if args.format in ["json", "both"]:
                    json_output = output_dir / f"{pdf_name}_comments.json"
                    extractor.save_to_json(comments, str(json_output))
                
                if args.format in ["csv", "both"]:
                    csv_output = output_dir / f"{pdf_name}_comments.csv"
                    extractor.save_to_csv(comments, str(csv_output))
                
                # Print summary if requested
                if args.print_output:
                    extractor.print_summary(comments)
                    
        except Exception as e:
            print(f"Error processing {pdf_path}: {e}", file=sys.stderr)
            continue


def extract_academic_cli():
    """CLI for extracting academic paper content."""
    parser = argparse.ArgumentParser(
        description="Extract structured content from academic PDF papers",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Extract all content from a paper
  pdf-academic-extract paper.pdf --print
  
  # Extract to JSON only
  pdf-academic-extract paper.pdf --format json
  
  # Specify output directory
  pdf-academic-extract paper.pdf --output-dir ./analysis
        """
    )
    
    parser.add_argument(
        "pdf_files",
        nargs="+",
        help="Path(s) to PDF file(s)"
    )
    parser.add_argument(
        "--output-dir",
        default="./paper_extraction_output",
        help="Output directory (default: ./paper_extraction_output)"
    )
    parser.add_argument(
        "--format",
        choices=["json", "csv", "both"],
        default="both",
        help="Output format (default: both)"
    )
    parser.add_argument(
        "--print",
        action="store_true",
        dest="print_output",
        help="Print summary to console"
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0"
    )
    
    args = parser.parse_args()
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True, parents=True)
    
    # Process each PDF file
    for pdf_path in args.pdf_files:
        print(f"\n{'#'*80}")
        print(f"Processing: {Path(pdf_path).name}")
        print(f"{'#'*80}\n")
        
        try:
            extractor = AcademicPaperExtractor(pdf_path)
            data = extractor.extract_all()
            
            # Generate output filename base
            pdf_name = Path(pdf_path).stem
            
            # Save in requested format(s)
            if args.format in ["json", "both"]:
                json_output = output_dir / f"{pdf_name}_extraction.json"
                extractor.save_to_json(data, str(json_output))
            
            if args.format in ["csv", "both"]:
                csv_dir = output_dir / pdf_name
                extractor.save_to_csv(data, str(csv_dir))
            
            # Print summary if requested
            if args.print_output:
                extractor.print_summary(data)
            
            extractor.close()
            
        except Exception as e:
            print(f"Error processing {pdf_path}: {e}", file=sys.stderr)
            continue


def search_cli():
    """CLI for searching text in PDFs."""
    parser = argparse.ArgumentParser(
        description="Search for text in PDF files",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        "pdf_file",
        help="Path to PDF file"
    )
    parser.add_argument(
        "search_text",
        help="Text to search for"
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0"
    )
    
    args = parser.parse_args()
    
    try:
        results = search_text_in_pdf(args.pdf_file, args.search_text)
        
        if not results:
            print(f"Text '{args.search_text}' not found in {args.pdf_file}")
        else:
            print(f"\nFound {len(results)} instance(s) of '{args.search_text}':\n")
            for page_num, context in results:
                print(f"Page {page_num}:")
                print(context)
                print("-" * 80)
                
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    extract_comments_cli()

