"""
Search utilities for PDF files.
"""

import fitz  # PyMuPDF
from pathlib import Path
from typing import List, Tuple, Optional


def search_text_in_pdf(pdf_path: str, search_text: str) -> List[Tuple[int, str]]:
    """
    Search for specific text in PDF and return all instances with context.
    
    Args:
        pdf_path: Path to PDF file
        search_text: Text to search for
        
    Returns:
        List of tuples (page_number, context_text)
    """
    doc = fitz.open(pdf_path)
    found_instances = []
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        text_instances = page.search_for(search_text)
        
        if text_instances:
            for inst in text_instances:
                rect = fitz.Rect(
                    max(0, inst.x0 - 200),
                    max(0, inst.y0 - 100),
                    min(page.rect.width, inst.x1 + 200),
                    min(page.rect.height, inst.y1 + 100)
                )
                context = page.get_textbox(rect)
                found_instances.append((page_num + 1, context))
    
    doc.close()
    return found_instances


def search_all_files(
    directory: str,
    search_text: str,
    extensions: Optional[List[str]] = None
) -> dict:
    """
    Search for text in all PDF files in directory.
    
    Args:
        directory: Directory to search in
        search_text: Text to search for
        extensions: List of file extensions to search (default: ['.pdf'])
        
    Returns:
        Dictionary mapping file paths to list of found instances
    """
    if extensions is None:
        extensions = ['.pdf']
    
    directory = Path(directory)
    results = {}
    
    for ext in extensions:
        for file_path in directory.rglob(f'*{ext}'):
            if ext == '.pdf':
                found = search_text_in_pdf(str(file_path), search_text)
                if found:
                    results[str(file_path)] = found
    
    return results

