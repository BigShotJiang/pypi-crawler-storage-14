"""
PDF Comments Extractor
======================

A Python package for extracting comments, annotations, and structured content 
from PDF documents including academic papers.

Main Components:
- PDFCommentExtractor: Extract PDF annotations and comments
- AcademicPaperExtractor: Extract structured academic paper content
- Search utilities for finding text in PDFs

Example:
    >>> from pdf_comments_extractor import PDFCommentExtractor
    >>> extractor = PDFCommentExtractor('paper.pdf')
    >>> comments = extractor.extract_all_comments()
    >>> extractor.save_to_json(comments, 'comments.json')
"""

__version__ = '0.1.0'
__author__ = 'Alexander Goldberg'
__email__ = 'your.email@example.com'

from .comment_extractor import PDFCommentExtractor
from .academic_extractor import AcademicPaperExtractor
from .search import search_text_in_pdf, search_all_files

__all__ = [
    'PDFCommentExtractor',
    'AcademicPaperExtractor',
    'search_text_in_pdf',
    'search_all_files',
]

