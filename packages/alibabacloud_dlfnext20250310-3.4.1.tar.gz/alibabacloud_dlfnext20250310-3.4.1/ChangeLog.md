2025-10-29 Version: 3.4.0
- Support API GetTableCompaction.


2025-10-20 Version: 3.3.0
- Support API ListPartitions.


2025-09-18 Version: 3.2.0
- Support API GetTableToken.
- Update API ListTableDetails: add request parameters type.


2025-08-22 Version: 3.1.1
- Update API AlterShare: add request parameters body.enableWrite.
- Update API CreateShare: add request parameters body.enableWrite.


2025-08-15 Version: 3.1.0
- Support API RefreshUserSync.


2025-08-07 Version: 3.0.0
- Support API AlterReceiver.
- Support API AlterShare.
- Support API AlterShareReceivers.
- Support API AlterShareResources.
- Support API CreateReceiver.
- Support API CreateShare.
- Support API DropReceiver.
- Support API DropShare.
- Support API GetReceiver.
- Support API GetShare.
- Support API GetTableSnapshot.
- Support API ListProvidedShares.
- Support API ListReceivedShares.
- Support API ListReceivers.
- Support API ListShareReceivers.
- Support API ListShareResources.
- Support API ListSnapshots.
- Support API RollbackTable.
- Update API CreateCatalog: add request parameters body.isShared.
- Update API CreateCatalog: add request parameters body.shareId.
- Update API GetCatalogSummary: add request parameters date.
- Update API GetCatalogSummary: add request The number of query or body parameters has changed from zero to many.
- Update API GetDatabaseSummary: add request parameters date.
- Update API GetDatabaseSummary: add request The number of query or body parameters has changed from zero to many.
- Update API GetTableSummary: add request parameters date.
- Update API GetTableSummary: add request The number of query or body parameters has changed from zero to many.


2025-07-31 Version: 2.5.0
- Support API GetIcebergNamespace.
- Support API GetIcebergTable.
- Support API ListIcebergNamespaceDetails.
- Support API ListIcebergSnapshots.
- Support API ListIcebergTableDetails.


2025-07-29 Version: 2.4.0
- Support API GetCatalogById.


2025-07-28 Version: 2.3.0
- Support API ListDatabaseDetails.


2025-07-22 Version: 2.2.0
- Support API ListTableDetails.


2025-07-17 Version: 2.1.0
- Support API AlterDatabase.
- Support API AlterTable.
- Support API CreateDatabase.
- Support API CreateTable.
- Support API DropDatabase.
- Support API DropTable.
- Support API GetDatabase.
- Support API GetTable.
- Support API ListDatabases.
- Support API ListTables.


2025-07-16 Version: 2.0.0
- Update API CreateCatalog: delete request parameters body.optimizationConfig.
- Update API ListRoleUsers: update request parameters maxResults' type has changed.
- Update API ListRoleUsers: update request parameters maxResults' format has changed.
- Update API ListUserRoles: update request parameters maxResults' type has changed.
- Update API ListUserRoles: update request parameters maxResults' format has changed.


2025-07-02 Version: 1.1.3
- Update API ListPermissions: add request parameters function.
- Update API ListPermissions: add request parameters view.


2025-07-02 Version: 1.1.3
- Update API ListPermissions: add request parameters function.
- Update API ListPermissions: add request parameters view.


2025-06-19 Version: 1.1.2
- Update API CreateCatalog: add request parameters body.type.


2025-06-11 Version: 1.1.1
- Generated python 2025-03-10 for DlfNext.

2025-06-09 Version: 1.1.0
- Support API GetCatalogSummary.
- Support API GetCatalogSummaryTrend.
- Support API GetCatalogToken.
- Support API GetDatabaseSummary.
- Support API GetTableSummary.
- Support API ListPartitionSummaries.


2025-05-20 Version: 1.0.0
- Generated python 2025-03-10 for DlfNext.

