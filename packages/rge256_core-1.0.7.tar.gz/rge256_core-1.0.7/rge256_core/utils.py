"""
Utility functions for RGE-256.
"""

def bytes_to_hex(data: bytes) -> str:
    """Convert bytes to hexadecimal string."""
    return data.hex()

def hex_to_bytes(hex_str: str) -> bytes:
    """Convert hexadecimal string to bytes."""
    if hex_str.startswith('0x') or hex_str.startswith('0X'):
        hex_str = hex_str[2:]
    return bytes.fromhex(hex_str)

def int_to_bytes(n: int, length: int = 4, byteorder: str = 'little') -> bytes:
    """Convert an integer to bytes."""
    return n.to_bytes(length, byteorder)

def bytes_to_int(data: bytes, byteorder: str = 'little') -> int:
    """Convert bytes to an integer."""
    return int.from_bytes(data, byteorder)
