from ..lib_types import DataFrame, ndarray, Series

def get_row(dataframe: DataFrame, row: int | str) -> list:
    """
    Returns the specified row from a dataframe as a list of values.

    :param dataframe: The dataframe where to extract the row.
    :type dataframe: DataFrame
    :param row: The index of the row to be extracted or its label. You can only extract by label when the datraframe contains no duplicates. Otherwise, it will raise a ValueError.
    :type row: int | str

    :raises ValueError: If the provided dataframe contains more than one row with the same name.
    """

    row_index: int | ndarray = row if isinstance(row, int) else dataframe.index.get_loc(row)

    if isinstance(row_index, ndarray):
        raise ValueError(f"The provided dataframe contains more than one row with the name '{row}'. Please enter the index number of the desired row instead.")

    row_series: Series = dataframe.iloc[row_index]

    return row_series.to_numpy().tolist()

def get_column(dataframe: DataFrame, column: int | str) -> list:
    """
    Returns the specified column from a dataframe as a list of values.

    :param dataframe: The dataframe where to extract the column.
    :type dataframe: DataFrame
    :param column: The index of the column to be extracted or its label. You can only extract by label when the datraframe contains no duplicates. Otherwise, it will raise a ValueError.
    :type column: int | str

    :raises ValueError: If the provided dataframe contains more than one column with the same name.
    """
    
    column_series: Series | DataFrame = dataframe[column] if isinstance(column, str) else dataframe.iloc[:, column]

    if isinstance(column_series, DataFrame):
        raise ValueError(f"The provided dataframe contains more than one columnn with the name '{column}'. Please enter the index number of the desired column instead.")

    return column_series.to_numpy().tolist()