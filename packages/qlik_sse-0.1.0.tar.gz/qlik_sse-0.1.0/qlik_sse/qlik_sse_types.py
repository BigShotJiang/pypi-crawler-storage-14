from collections.abc import Callable
from typing import ParamSpec

from .proto.qlik.sse import Dual

SingleDataType = float | str | Dual
MultiDataType = list[float] | list[str] | list[Dual]

SingleParams = ParamSpec("SingleParams", bound=SingleDataType)
MultiParams = ParamSpec("MultiParams", bound=MultiDataType)

WrappableScalarFunction = Callable[SingleParams, SingleDataType]
WrappableAggregationFunction = Callable[MultiParams, SingleDataType]
WrappableTensorFunction = Callable[MultiParams, list[MultiDataType]]
WrappableFunction = WrappableScalarFunction | WrappableAggregationFunction | WrappableTensorFunction
