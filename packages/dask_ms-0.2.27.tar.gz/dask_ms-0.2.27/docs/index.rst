Welcome to dask-ms's documentation!
======================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   readme
   installation
   usage
   concepts
   tutorial
   api
   contributing
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
