from enum import Enum


class PostPublicEnvelopeCreateFromTemplateBodyRecipientsItemType1Type(str, Enum):
    CONTACT = "contact"

    def __str__(self) -> str:
        return str(self.value)
