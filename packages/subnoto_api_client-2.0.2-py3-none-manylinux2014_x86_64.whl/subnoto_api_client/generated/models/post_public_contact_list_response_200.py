from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.post_public_contact_list_response_200_contacts_item import (
        PostPublicContactListResponse200ContactsItem,
    )


T = TypeVar("T", bound="PostPublicContactListResponse200")


@_attrs_define
class PostPublicContactListResponse200:
    """
    Attributes:
        contacts (list[PostPublicContactListResponse200ContactsItem]): The list of contacts.
    """

    contacts: list[PostPublicContactListResponse200ContactsItem]

    def to_dict(self) -> dict[str, Any]:
        contacts = []
        for contacts_item_data in self.contacts:
            contacts_item = contacts_item_data.to_dict()
            contacts.append(contacts_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "contacts": contacts,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_contact_list_response_200_contacts_item import (
            PostPublicContactListResponse200ContactsItem,
        )

        d = dict(src_dict)
        contacts = []
        _contacts = d.pop("contacts")
        for contacts_item_data in _contacts:
            contacts_item = PostPublicContactListResponse200ContactsItem.from_dict(
                contacts_item_data
            )

            contacts.append(contacts_item)

        post_public_contact_list_response_200 = cls(
            contacts=contacts,
        )

        return post_public_contact_list_response_200
