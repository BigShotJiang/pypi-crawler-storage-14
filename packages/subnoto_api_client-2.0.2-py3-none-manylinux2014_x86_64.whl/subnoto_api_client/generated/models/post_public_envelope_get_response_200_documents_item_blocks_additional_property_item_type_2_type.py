from enum import Enum


class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType2Type(
    str, Enum
):
    SIGNATURE = "signature"

    def __str__(self) -> str:
        return str(self.value)
