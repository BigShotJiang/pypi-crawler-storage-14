# README checks for Python Projects

See also <https://repo-review.readthedocs.io/en/latest/index.html>
