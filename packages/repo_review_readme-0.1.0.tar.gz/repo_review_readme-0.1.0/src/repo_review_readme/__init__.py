def main() -> None:
    print("Hello from repo-review-readme!")
