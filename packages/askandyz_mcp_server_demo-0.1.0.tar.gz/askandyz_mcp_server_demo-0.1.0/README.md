##Upload stdio MCP to PyPI##
APIKey
``
pypi-AgEIcHlwaS5vcmcCJDBjNTJmNGYwLTMzZTktNDE3Yy1iZDk0LTRkNzMzYzZiYmU4OAACKlszLCIzM2I3MGU3ZC0zZDYzLTQwOTctYWNhYS04M2JhZWNlMDU3MTEiXQAABiBn7K8O1EnlCQSbCux0LNRPtxscbokjg9ifPajPTUVOyg
``

- uv init . --package -p 3.13
- uv add "mcp[cli]"
- 