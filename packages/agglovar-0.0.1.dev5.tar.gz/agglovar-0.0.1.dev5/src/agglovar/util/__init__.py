"""Generally useful utility functions used across modules."""

__all__ = [
    'str',
    'var',
]

from . import str
from . import var
