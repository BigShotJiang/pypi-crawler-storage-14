from y.prices.lending import ib
from y.prices.lending.aave import aave
from y.prices.lending.compound import compound

__all__ = ["aave", "compound", "ib"]
