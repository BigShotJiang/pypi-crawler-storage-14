from y.classes.common import ERC20

__all__ = ["ERC20"]
"""
List of public classes in the y.classes package.
"""
