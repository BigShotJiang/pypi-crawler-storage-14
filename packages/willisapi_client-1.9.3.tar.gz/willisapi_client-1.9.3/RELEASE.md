Release Notes
=============

The list of changes to willisapi_client between each release can be found
[here](https://github.com/bklynhlth/willisapi_client.git). For full
details, see the commit logs at https://github.com/bklynhlth/willisapi_client.git.
