"""Version details for willisapi_client"""

__client__ = "willisapi_client"
__latestVersion__ = "1.9.3"
__url__ = "https://github.com/bklynhlth/willsiapi_client"
__short_description__ = "A Python client for willisapi"
__content_type__ = "text/markdown"
