# Plugin ADK

> 一个独立的、可通过 `pip install` 安装的 Python 包，提供完整的插件生态系统，包括插件开发、运行环境、通信机制、服务发现、存储缓存、AI 能力和沙箱执行。

[![Python Version](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Development Status](https://img.shields.io/badge/status-development-orange.svg)](docs/开发进度.md)

## ✨ 核心特性

- 🚀 **完整生态**: 不仅仅是 ADK，而是完整的插件运行环境
- 📝 **Code-First**: 一切在 Python 代码中定义
- ⚙️ **Runner 模式**: 无状态编排引擎，管理执行循环
- 📦 **App 模式**: 顶层容器，管理 root_plugin 和应用级插件
- 🔌 **插件管理**: 插件管理器管理插件之间的关系
- 📡 **事件总线**: 支持 Request/Response 模式的插件间通信
- 🔍 **服务发现**: 让插件相互发现和利用
- 🏗️ **服务化架构**: SessionService、ArtifactService、MemoryService 等
- 💾 **智能缓存**: 多级缓存系统（L1/L2/L3）和智能路由
- 🤖 **AI 能力**: 内置 AI 能力（统一使用 litellm），让插件具备智能
- 🛡️ **安全沙箱**: 基于 smolagents 的沙箱执行环境
- 🔄 **事件溯源**: 支持 Rewind（时光倒流）和状态恢复
- 📊 **Token 统计**: 完整的 Token Usage 追踪和成本计算

## 📦 安装

```bash
# 基础安装
pip install plugin-adk

# 包含所有可选依赖
pip install plugin-adk[all]

# 仅安装特定功能
pip install plugin-adk[redis,ai,sandbox]
```

## 🚀 快速开始

### 定义插件（Code-First）

```python
# plugins/my_plugin/plugin.py
from plugin_adk import BasePlugin, PluginSDKApp
from plugin_adk.tools import google_search

root_plugin = BasePlugin(
    name="search_assistant",
    description="A search assistant that can search the web.",
    tools=[google_search]
)

# 或者使用 App 模式
app = PluginSDKApp(
    name="my_app",
    root_plugin=root_plugin,
    plugins=[...],  # 应用级插件
)
```

### 使用 Runner

```python
from plugin_adk import PluginRunner, PluginSDKApp
from plugin_adk.sessions import InMemorySessionService
from my_plugin import app

# 创建 Runner
runner = PluginRunner(
    app=app,
    session_service=InMemorySessionService(),
)

# 异步执行
async for event in runner.run_async("Search for Python", session_id="session_1"):
    print(event)

# 同步执行
events = await runner.run("Search for Python", session_id="session_1")
```

### 使用 Builder

```python
from plugin_adk import create_app
from plugin_adk.sessions import InMemorySessionService
from my_plugin import root_plugin

app = (create_app()
    .with_name("my_plugin_app")
    .with_root_plugin(root_plugin)
    .with_session_service(InMemorySessionService())
    .with_service_discovery(ServiceDiscovery())
    .build())

runner = PluginRunner(app=app, session_service=InMemorySessionService())
```

## 📚 文档

- [开发文档](docs/Development/README.md) - 完整的开发文档
- [架构设计](docs/Development/01-架构设计.md) - 核心架构设计
- [移植计划](docs/Development/02-移植计划.md) - 详细实施计划
- [开发进度](docs/开发进度.md) - 当前开发进度

## 🏗️ 项目结构

```
plugin-adk/
├── plugin_adk/              # 主包
│   ├── core/               # 核心模块
│   │   ├── plugin/         # 插件系统
│   │   ├── communication/  # 通信系统
│   │   ├── coordination/   # 协调系统
│   │   ├── storage/        # 存储系统
│   │   ├── ai/             # AI 能力
│   │   ├── sandbox/        # 沙箱系统
│   │   ├── service/        # 服务调用
│   │   ├── models/         # 数据模型
│   │   └── utils/          # 工具函数
│   ├── apps/               # App 定义
│   ├── runners/            # Runner
│   ├── services/           # 服务层
│   └── foundation/         # 基础组件
├── tests/                  # 测试
├── examples/               # 示例代码
└── docs/                   # 文档
```

## 🎯 设计目标

### 1. 专注于插件生态系统
- **插件优先**: 所有设计都围绕插件展开
- **插件关系管理**: 管理插件之间的依赖、调用关系
- **插件通信**: 事件总线支持插件间 Request/Response 通信

### 2. 双重用途的 SDK
- **开发中使用**: 开发者直接使用 SDK 调用插件，具备完整特性
- **沙箱中使用**: AI 沙箱通过 SDK 调用插件，SDK 自动转换为工具
- **统一底层**: SDK 和 Call Service 共享相同的底层实现

### 3. 完整的服务调用能力
- **服务发现**: 自动发现和注册服务
- **负载均衡**: 支持多种负载均衡算法
- **错误重试**: 智能错误重试机制
- **调用追踪**: 完整的调用链追踪

### 4. 结合多种架构优势
- **Runner 模式**: 参考 Google ADK，无状态编排引擎
- **App 模式**: 参考 Google ADK，顶层容器管理
- **Builder 模式**: 参考 OpenMind v1，流式 API 配置
- **完整功能**: 参考 OpenMind v2，完整的事件总线、缓存、存储等

## 🔄 与 OpenMind v2 的兼容性

Plugin ADK 完全兼容 OpenMind v2，可以无缝迁移：

- ✅ **接口兼容**: 插件接口完全兼容 OpenMind v2
- ✅ **功能移植**: 移植了 v2 的核心功能
- ✅ **无缝迁移**: 开发的插件可以直接在 OpenMind v2 中运行
- ✅ **独立使用**: 也可以独立使用，不依赖 OpenMind v2

## 📝 开发状态

当前版本: **0.1.0-dev** (开发中)

查看 [开发进度](docs/开发进度.md) 了解详细的开发计划和进度。

## 🤝 贡献

欢迎贡献！请查看 [贡献指南](CONTRIBUTING.md) 了解详细信息。

## 📄 许可证

本项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

---

**Plugin ADK** - 让插件开发更简单！

