"""Initialize

Revision ID: 6825c778aa3c
Revises:
Create Date: 2023-07-05

"""

# revision identifiers, used by Alembic.
revision = "6825c778aa3c"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    raise NotImplementedError


def downgrade():
    "Nothing to do because this is the initial schema."
    pass
