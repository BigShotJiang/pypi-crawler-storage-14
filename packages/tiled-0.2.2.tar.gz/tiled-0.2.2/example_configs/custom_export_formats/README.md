See docs/source/how-to-custom-export-formats.md for details.
Launch via:

```
tiled serve config --public config.yml
```
