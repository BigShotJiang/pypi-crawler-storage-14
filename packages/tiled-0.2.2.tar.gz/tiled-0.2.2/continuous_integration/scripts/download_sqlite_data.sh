#!/bin/bash
set -e

curl -fsSLO https://github.com/bluesky/tiled-example-database/releases/latest/download/tiled_test_db_sqlite.db
