# Command-line tool

Installing tiled adds a command-line tool, ``tiled``, to the environment.
Use ``tiled --help`` for info, or see the documentation below.


```{eval-rst}
.. click:: tiled.commandline.main:typer_click_object
   :prog: tiled
   :nested: full
```
