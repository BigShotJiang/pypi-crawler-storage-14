function content=getSummaryContent(obj)
% return the error struct that made the test fail
%
% content=getSummaryContent(obj)
%
% Input:
%   obj                     MoxUnitPassedTestOutcome object
%
% Output:
%   content                 The empty array []
%
% See also: lasterror

    content=[];
