function disp(obj)
% display MoxUnitFunctionHandleTestCase object
%
% disp(obj)
%
% Inputs:
%   obj             MoxUnitFunctionHandleTestCase object
%
% NNO 2015

    disp(str(obj));
