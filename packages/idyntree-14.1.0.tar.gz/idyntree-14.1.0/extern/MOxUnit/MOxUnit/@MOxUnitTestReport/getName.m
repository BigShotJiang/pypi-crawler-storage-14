function name=getName(obj)
    name=obj.name;