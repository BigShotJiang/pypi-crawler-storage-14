function s=getName(obj)
% Return name of MoxUnitTestNode instance
%
% s=str(obj)
%
% Input:
%   obj             MOxUnitTestNode instance.
%
% Output:
%   s               name of obj.
%

    s=obj.name;
