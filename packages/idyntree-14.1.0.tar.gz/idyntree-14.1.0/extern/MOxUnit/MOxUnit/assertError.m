function assertError(varargin)
    assertExceptionThrown(varargin{:});