function ptr = iDynTreeSwigGet(self)
  ptr = [];
end
