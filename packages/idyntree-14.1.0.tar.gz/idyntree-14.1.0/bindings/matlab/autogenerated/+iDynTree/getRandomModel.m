function varargout = getRandomModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1294, varargin{:});
end
