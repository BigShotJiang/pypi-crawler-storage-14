function varargout = isDOFBerdyDynamicVariable(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1644, varargin{:});
end
