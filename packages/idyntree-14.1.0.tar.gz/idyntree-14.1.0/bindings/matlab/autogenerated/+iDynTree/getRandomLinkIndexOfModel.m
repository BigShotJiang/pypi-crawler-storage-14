function varargout = getRandomLinkIndexOfModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1291, varargin{:});
end
