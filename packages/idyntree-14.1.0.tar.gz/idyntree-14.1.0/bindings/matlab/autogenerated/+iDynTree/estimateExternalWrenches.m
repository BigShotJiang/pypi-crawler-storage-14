function varargout = estimateExternalWrenches(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1611, varargin{:});
end
