function varargout = getSensorTypeSize(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1121, varargin{:});
end
