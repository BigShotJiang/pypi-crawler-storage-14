function varargout = ForwardPositionKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1457, varargin{:});
end
