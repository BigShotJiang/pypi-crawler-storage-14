function varargout = getRandomLink(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1288, varargin{:});
end
