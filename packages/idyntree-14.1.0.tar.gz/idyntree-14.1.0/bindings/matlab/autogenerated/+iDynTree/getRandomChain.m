function varargout = getRandomChain(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1295, varargin{:});
end
