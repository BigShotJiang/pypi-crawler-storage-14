function v = dynamic_extent()
  v = iDynTreeMEX(746);
end
