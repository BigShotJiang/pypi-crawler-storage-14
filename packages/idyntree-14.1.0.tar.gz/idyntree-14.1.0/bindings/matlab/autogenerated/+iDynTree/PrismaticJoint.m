classdef PrismaticJoint < iDynTree.MovableJointImpl1
  methods
    function self = PrismaticJoint(varargin)
      self@iDynTree.MovableJointImpl1(iDynTreeSwigRef.Null);
      if nargin==1 && strcmp(class(varargin{1}),'iDynTreeSwigRef')
        if ~isnull(varargin{1})
          self.swigPtr = varargin{1}.swigPtr;
        end
      else
        tmp = iDynTreeMEX(1004, varargin{:});
        self.swigPtr = tmp.swigPtr;
        tmp.SwigClear();
      end
    end
    function delete(self)
      if self.swigPtr
        iDynTreeMEX(1005, self);
        self.SwigClear();
      end
    end
    function varargout = clone(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1006, self, varargin{:});
    end
    function varargout = setAttachedLinks(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1007, self, varargin{:});
    end
    function varargout = setRestTransform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1008, self, varargin{:});
    end
    function varargout = setAxis(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1009, self, varargin{:});
    end
    function varargout = getFirstAttachedLink(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1010, self, varargin{:});
    end
    function varargout = getSecondAttachedLink(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1011, self, varargin{:});
    end
    function varargout = getAxis(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1012, self, varargin{:});
    end
    function varargout = getRestTransform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1013, self, varargin{:});
    end
    function varargout = getTransform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1014, self, varargin{:});
    end
    function varargout = getTransformDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1015, self, varargin{:});
    end
    function varargout = getMotionSubspaceVector(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1016, self, varargin{:});
    end
    function varargout = computeChildPosVelAcc(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1017, self, varargin{:});
    end
    function varargout = computeChildVel(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1018, self, varargin{:});
    end
    function varargout = computeChildVelAcc(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1019, self, varargin{:});
    end
    function varargout = computeChildAcc(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1020, self, varargin{:});
    end
    function varargout = computeChildBiasAcc(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1021, self, varargin{:});
    end
    function varargout = computeJointTorque(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1022, self, varargin{:});
    end
    function varargout = hasPosLimits(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1023, self, varargin{:});
    end
    function varargout = enablePosLimits(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1024, self, varargin{:});
    end
    function varargout = getPosLimits(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1025, self, varargin{:});
    end
    function varargout = getMinPosLimit(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1026, self, varargin{:});
    end
    function varargout = getMaxPosLimit(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1027, self, varargin{:});
    end
    function varargout = setPosLimits(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1028, self, varargin{:});
    end
    function varargout = getJointDynamicsType(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1029, self, varargin{:});
    end
    function varargout = setJointDynamicsType(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1030, self, varargin{:});
    end
    function varargout = getDamping(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1031, self, varargin{:});
    end
    function varargout = getStaticFriction(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1032, self, varargin{:});
    end
    function varargout = setDamping(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1033, self, varargin{:});
    end
    function varargout = setStaticFriction(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1034, self, varargin{:});
    end
  end
  methods(Static)
  end
end
