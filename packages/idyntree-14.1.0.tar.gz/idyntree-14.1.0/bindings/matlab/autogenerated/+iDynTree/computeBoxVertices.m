function varargout = computeBoxVertices(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1853, varargin{:});
end
