function v = input_dimensions()
  v = iDynTreeMEX(1806);
end
