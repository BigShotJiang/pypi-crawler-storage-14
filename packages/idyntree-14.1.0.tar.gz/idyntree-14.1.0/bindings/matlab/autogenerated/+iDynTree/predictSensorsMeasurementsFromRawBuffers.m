function varargout = predictSensorsMeasurementsFromRawBuffers(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1406, varargin{:});
end
