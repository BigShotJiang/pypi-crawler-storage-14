function varargout = reportInfo(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(196, varargin{:});
end
