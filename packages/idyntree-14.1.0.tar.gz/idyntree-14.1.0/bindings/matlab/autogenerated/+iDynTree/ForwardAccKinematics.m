function varargout = ForwardAccKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1461, varargin{:});
end
