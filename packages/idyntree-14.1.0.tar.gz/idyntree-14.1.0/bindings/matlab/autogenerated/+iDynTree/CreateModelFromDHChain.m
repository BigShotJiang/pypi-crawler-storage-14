function varargout = CreateModelFromDHChain(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1521, varargin{:});
end
