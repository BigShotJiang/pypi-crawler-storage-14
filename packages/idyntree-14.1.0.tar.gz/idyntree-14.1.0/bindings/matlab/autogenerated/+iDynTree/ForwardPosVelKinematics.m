function varargout = ForwardPosVelKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1460, varargin{:});
end
