function varargout = addRandomAdditionalFrameToModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1290, varargin{:});
end
