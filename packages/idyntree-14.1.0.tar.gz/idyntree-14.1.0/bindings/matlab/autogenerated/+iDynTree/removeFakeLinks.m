function varargout = removeFakeLinks(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1298, varargin{:});
end
