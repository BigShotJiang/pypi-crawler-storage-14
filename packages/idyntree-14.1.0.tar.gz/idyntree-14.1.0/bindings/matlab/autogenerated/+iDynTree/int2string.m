function varargout = int2string(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1293, varargin{:});
end
