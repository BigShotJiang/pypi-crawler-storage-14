function varargout = InverseDynamicsInertialParametersRegressor(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1490, varargin{:});
end
