function varargout = predictSensorsMeasurements(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1405, varargin{:});
end
