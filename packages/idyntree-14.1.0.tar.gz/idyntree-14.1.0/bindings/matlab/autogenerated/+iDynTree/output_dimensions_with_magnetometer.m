function v = output_dimensions_with_magnetometer()
  v = iDynTreeMEX(1804);
end
