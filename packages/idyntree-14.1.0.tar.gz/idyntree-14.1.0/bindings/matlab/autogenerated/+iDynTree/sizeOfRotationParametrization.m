function varargout = sizeOfRotationParametrization(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(2140, varargin{:});
end
