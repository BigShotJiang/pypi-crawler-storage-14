function varargout = ComputeLinearAndAngularMomentumDerivativeBias(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1464, varargin{:});
end
