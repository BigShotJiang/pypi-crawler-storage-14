function varargout = isLinkBerdyDynamicVariable(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1642, varargin{:});
end
