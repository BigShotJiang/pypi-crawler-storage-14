function varargout = getRandomJointPositions(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1296, varargin{:});
end
