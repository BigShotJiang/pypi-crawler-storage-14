classdef TransformDerivative < iDynTreeSwigRef
  methods
    function this = swig_this(self)
      this = iDynTreeMEX(3, self);
    end
    function self = TransformDerivative(varargin)
      if nargin==1 && strcmp(class(varargin{1}),'iDynTreeSwigRef')
        if ~isnull(varargin{1})
          self.swigPtr = varargin{1}.swigPtr;
        end
      else
        tmp = iDynTreeMEX(733, varargin{:});
        self.swigPtr = tmp.swigPtr;
        tmp.SwigClear();
      end
    end
    function delete(self)
      if self.swigPtr
        iDynTreeMEX(734, self);
        self.SwigClear();
      end
    end
    function varargout = getRotationDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(735, self, varargin{:});
    end
    function varargout = getPositionDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(736, self, varargin{:});
    end
    function varargout = setRotationDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(737, self, varargin{:});
    end
    function varargout = setPositionDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(738, self, varargin{:});
    end
    function varargout = asHomogeneousTransformDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(740, self, varargin{:});
    end
    function varargout = asAdjointTransformDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(741, self, varargin{:});
    end
    function varargout = asAdjointTransformWrenchDerivative(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(742, self, varargin{:});
    end
    function varargout = mtimes(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(743, self, varargin{:});
    end
    function varargout = derivativeOfInverse(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(744, self, varargin{:});
    end
    function varargout = transform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(745, self, varargin{:});
    end
  end
  methods(Static)
    function varargout = Zero(varargin)
     [varargout{1:nargout}] = iDynTreeMEX(739, varargin{:});
    end
  end
end
