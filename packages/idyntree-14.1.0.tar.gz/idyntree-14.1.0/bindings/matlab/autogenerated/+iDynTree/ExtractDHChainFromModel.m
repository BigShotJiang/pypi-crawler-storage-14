function varargout = ExtractDHChainFromModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1520, varargin{:});
end
