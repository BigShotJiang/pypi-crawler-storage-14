function varargout = isJointBerdyDynamicVariable(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1643, varargin{:});
end
