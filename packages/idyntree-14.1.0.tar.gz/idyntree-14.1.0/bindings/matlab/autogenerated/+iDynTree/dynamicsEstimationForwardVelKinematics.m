function varargout = dynamicsEstimationForwardVelKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1613, varargin{:});
end
