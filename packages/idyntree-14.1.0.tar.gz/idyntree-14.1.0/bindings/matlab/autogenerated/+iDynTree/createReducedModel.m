function varargout = createReducedModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1299, varargin{:});
end
