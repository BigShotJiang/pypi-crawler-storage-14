function v = NR_OF_SENSOR_TYPES()
  v = iDynTreeMEX(1118);
end
