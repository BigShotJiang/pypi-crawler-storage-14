function varargout = computeTransformToTraversalBase(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1311, varargin{:});
end
