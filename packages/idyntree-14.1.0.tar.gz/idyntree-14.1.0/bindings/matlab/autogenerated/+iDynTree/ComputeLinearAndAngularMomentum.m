function varargout = ComputeLinearAndAngularMomentum(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1463, varargin{:});
end
