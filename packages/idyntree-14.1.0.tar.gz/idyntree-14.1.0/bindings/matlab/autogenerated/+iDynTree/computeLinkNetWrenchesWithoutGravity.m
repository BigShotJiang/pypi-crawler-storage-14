function varargout = computeLinkNetWrenchesWithoutGravity(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1614, varargin{:});
end
