function varargout = isLinkSensor(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1119, varargin{:});
end
