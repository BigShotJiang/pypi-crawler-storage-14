function varargout = estimateLinkContactWrenchesFromLinkNetExternalWrenches(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1615, varargin{:});
end
