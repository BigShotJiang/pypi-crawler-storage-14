function varargout = TransformFromDH(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1519, varargin{:});
end
