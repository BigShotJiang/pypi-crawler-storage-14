function varargout = CompositeRigidBodyAlgorithm(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1466, varargin{:});
end
