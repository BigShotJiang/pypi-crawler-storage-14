function varargout = ArticulatedBodyAlgorithm(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1489, varargin{:});
end
