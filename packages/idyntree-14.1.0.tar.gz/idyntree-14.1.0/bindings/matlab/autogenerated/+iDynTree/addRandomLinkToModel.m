function varargout = addRandomLinkToModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1289, varargin{:});
end
