function varargout = estimateInertialParametersFromLinkBoundingBoxesAndTotalMass(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1851, varargin{:});
end
