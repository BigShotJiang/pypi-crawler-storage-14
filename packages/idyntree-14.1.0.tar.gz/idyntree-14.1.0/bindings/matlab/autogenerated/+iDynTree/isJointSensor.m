function varargout = isJointSensor(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1120, varargin{:});
end
