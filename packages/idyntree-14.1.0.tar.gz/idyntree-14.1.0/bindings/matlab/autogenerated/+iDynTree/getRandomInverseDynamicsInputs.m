function varargout = getRandomInverseDynamicsInputs(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1297, varargin{:});
end
