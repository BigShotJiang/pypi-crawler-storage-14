function varargout = dofsListFromURDF(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1522, varargin{:});
end
