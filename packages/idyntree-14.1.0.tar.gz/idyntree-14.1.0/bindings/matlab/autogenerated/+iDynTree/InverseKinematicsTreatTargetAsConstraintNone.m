function v = InverseKinematicsTreatTargetAsConstraintNone()
  persistent vInitialized;
  if isempty(vInitialized)
    vInitialized = iDynTreeMEX(0, 40);
  end
  v = vInitialized;
end
