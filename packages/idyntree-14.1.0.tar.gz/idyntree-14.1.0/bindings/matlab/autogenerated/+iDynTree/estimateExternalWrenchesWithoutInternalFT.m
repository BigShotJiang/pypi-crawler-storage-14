function varargout = estimateExternalWrenchesWithoutInternalFT(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1610, varargin{:});
end
