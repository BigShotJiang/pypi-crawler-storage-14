function varargout = createModelWithNormalizedJointNumbering(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1300, varargin{:});
end
