function varargout = ForwardBiasAccKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1462, varargin{:});
end
