classdef KinDynComputations < iDynTreeSwigRef
  methods
    function this = swig_this(self)
      this = iDynTreeMEX(3, self);
    end
    function self = KinDynComputations(varargin)
      if nargin==1 && strcmp(class(varargin{1}),'iDynTreeSwigRef')
        if ~isnull(varargin{1})
          self.swigPtr = varargin{1}.swigPtr;
        end
      else
        tmp = iDynTreeMEX(1854, varargin{:});
        self.swigPtr = tmp.swigPtr;
        tmp.SwigClear();
      end
    end
    function delete(self)
      if self.swigPtr
        iDynTreeMEX(1855, self);
        self.SwigClear();
      end
    end
    function varargout = loadRobotModel(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1856, self, varargin{:});
    end
    function varargout = isValid(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1857, self, varargin{:});
    end
    function varargout = setFrameVelocityRepresentation(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1858, self, varargin{:});
    end
    function varargout = getFrameVelocityRepresentation(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1859, self, varargin{:});
    end
    function varargout = getNrOfDegreesOfFreedom(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1860, self, varargin{:});
    end
    function varargout = getDescriptionOfDegreeOfFreedom(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1861, self, varargin{:});
    end
    function varargout = getDescriptionOfDegreesOfFreedom(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1862, self, varargin{:});
    end
    function varargout = getNrOfLinks(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1863, self, varargin{:});
    end
    function varargout = getNrOfFrames(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1864, self, varargin{:});
    end
    function varargout = getFloatingBase(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1865, self, varargin{:});
    end
    function varargout = setFloatingBase(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1866, self, varargin{:});
    end
    function varargout = model(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1867, self, varargin{:});
    end
    function varargout = getRobotModel(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1868, self, varargin{:});
    end
    function varargout = getRelativeJacobianSparsityPattern(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1869, self, varargin{:});
    end
    function varargout = getFrameFreeFloatingJacobianSparsityPattern(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1870, self, varargin{:});
    end
    function varargout = setJointPos(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1871, self, varargin{:});
    end
    function varargout = setWorldBaseTransform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1872, self, varargin{:});
    end
    function varargout = setRobotState(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1873, self, varargin{:});
    end
    function varargout = getRobotState(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1874, self, varargin{:});
    end
    function varargout = getWorldBaseTransform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1875, self, varargin{:});
    end
    function varargout = getBaseTwist(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1876, self, varargin{:});
    end
    function varargout = getJointPos(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1877, self, varargin{:});
    end
    function varargout = getJointVel(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1878, self, varargin{:});
    end
    function varargout = getModelVel(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1879, self, varargin{:});
    end
    function varargout = getFrameIndex(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1880, self, varargin{:});
    end
    function varargout = getFrameName(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1881, self, varargin{:});
    end
    function varargout = getWorldTransform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1882, self, varargin{:});
    end
    function varargout = getWorldTransformsAsHomogeneous(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1883, self, varargin{:});
    end
    function varargout = getRelativeTransformExplicit(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1884, self, varargin{:});
    end
    function varargout = getRelativeTransform(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1885, self, varargin{:});
    end
    function varargout = getFrameVel(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1886, self, varargin{:});
    end
    function varargout = getFrameAcc(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1887, self, varargin{:});
    end
    function varargout = getFrameFreeFloatingJacobian(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1888, self, varargin{:});
    end
    function varargout = getRelativeJacobian(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1889, self, varargin{:});
    end
    function varargout = getRelativeJacobianExplicit(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1890, self, varargin{:});
    end
    function varargout = getFrameBiasAcc(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1891, self, varargin{:});
    end
    function varargout = getCenterOfMassPosition(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1892, self, varargin{:});
    end
    function varargout = getCenterOfMassVelocity(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1893, self, varargin{:});
    end
    function varargout = getCenterOfMassJacobian(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1894, self, varargin{:});
    end
    function varargout = getCenterOfMassBiasAcc(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1895, self, varargin{:});
    end
    function varargout = getAverageVelocity(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1896, self, varargin{:});
    end
    function varargout = getAverageVelocityJacobian(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1897, self, varargin{:});
    end
    function varargout = getRobotLockedInertia(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1898, self, varargin{:});
    end
    function varargout = getCentroidalAverageVelocity(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1899, self, varargin{:});
    end
    function varargout = getCentroidalAverageVelocityJacobian(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1900, self, varargin{:});
    end
    function varargout = getCentroidalRobotLockedInertia(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1901, self, varargin{:});
    end
    function varargout = getLinearAngularMomentum(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1902, self, varargin{:});
    end
    function varargout = getLinearAngularMomentumJacobian(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1903, self, varargin{:});
    end
    function varargout = getCentroidalTotalMomentum(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1904, self, varargin{:});
    end
    function varargout = getCentroidalTotalMomentumJacobian(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1905, self, varargin{:});
    end
    function varargout = getFreeFloatingMassMatrix(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1906, self, varargin{:});
    end
    function varargout = inverseDynamics(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1907, self, varargin{:});
    end
    function varargout = inverseDynamicsWithInternalJointForceTorques(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1908, self, varargin{:});
    end
    function varargout = generalizedBiasForces(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1909, self, varargin{:});
    end
    function varargout = generalizedGravityForces(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1910, self, varargin{:});
    end
    function varargout = generalizedExternalForces(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1911, self, varargin{:});
    end
    function varargout = inverseDynamicsInertialParametersRegressor(self,varargin)
      [varargout{1:nargout}] = iDynTreeMEX(1912, self, varargin{:});
    end
  end
  methods(Static)
  end
end
