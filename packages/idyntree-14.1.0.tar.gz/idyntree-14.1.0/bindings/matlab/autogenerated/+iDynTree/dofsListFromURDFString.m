function varargout = dofsListFromURDFString(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1523, varargin{:});
end
