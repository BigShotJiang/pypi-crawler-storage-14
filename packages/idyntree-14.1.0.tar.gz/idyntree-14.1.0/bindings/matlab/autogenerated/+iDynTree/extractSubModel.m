function varargout = extractSubModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1301, varargin{:});
end
