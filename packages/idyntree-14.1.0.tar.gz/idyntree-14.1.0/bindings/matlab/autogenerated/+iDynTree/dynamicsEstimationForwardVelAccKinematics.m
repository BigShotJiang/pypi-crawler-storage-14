function varargout = dynamicsEstimationForwardVelAccKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1612, varargin{:});
end
