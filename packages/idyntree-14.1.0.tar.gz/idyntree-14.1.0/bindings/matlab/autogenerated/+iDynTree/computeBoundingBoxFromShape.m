function varargout = computeBoundingBoxFromShape(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1852, varargin{:});
end
