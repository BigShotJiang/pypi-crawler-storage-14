function varargout = computeTransformToSubModelBase(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1312, varargin{:});
end
