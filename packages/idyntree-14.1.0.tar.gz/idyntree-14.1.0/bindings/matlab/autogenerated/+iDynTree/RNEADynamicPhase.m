function varargout = RNEADynamicPhase(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1465, varargin{:});
end
