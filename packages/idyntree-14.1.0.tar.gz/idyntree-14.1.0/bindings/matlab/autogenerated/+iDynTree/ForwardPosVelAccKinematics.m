function varargout = ForwardPosVelAccKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1459, varargin{:});
end
