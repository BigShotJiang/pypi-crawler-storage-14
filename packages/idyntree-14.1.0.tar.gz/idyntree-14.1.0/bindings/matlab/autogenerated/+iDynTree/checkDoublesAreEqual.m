function varargout = checkDoublesAreEqual(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(206, varargin{:});
end
