function varargout = ForwardVelAccKinematics(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1458, varargin{:});
end
