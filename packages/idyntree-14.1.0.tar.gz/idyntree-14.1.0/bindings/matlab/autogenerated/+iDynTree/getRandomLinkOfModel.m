function varargout = getRandomLinkOfModel(varargin)
  [varargout{1:nargout}] = iDynTreeMEX(1292, varargin{:});
end
