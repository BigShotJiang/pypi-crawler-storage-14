function v = output_dimensions_without_magnetometer()
  v = iDynTreeMEX(1805);
end
