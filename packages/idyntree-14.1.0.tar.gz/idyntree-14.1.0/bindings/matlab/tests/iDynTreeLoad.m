% iDynTreeLoad Does not do anything on Matlab (or Octave with mex), call iDynTree on octave
if( exist('iDynTree') )
    iDynTree;
end


