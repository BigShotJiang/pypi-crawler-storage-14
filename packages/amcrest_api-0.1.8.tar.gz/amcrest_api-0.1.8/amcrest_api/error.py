"""Amcrest API errors."""


class UnsupportedStreamSubtype(ValueError):
    """Exception raised when accessing unavailable substream."""
