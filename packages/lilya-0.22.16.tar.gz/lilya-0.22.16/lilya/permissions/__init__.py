from .base import DefinePermission, Permission

__all__ = ["DefinePermission", "Permission"]
