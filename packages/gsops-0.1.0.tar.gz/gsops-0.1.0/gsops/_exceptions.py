class AutodiffNotImplementedError(RuntimeError):
    """Raised when autodiff is not implemented."""
