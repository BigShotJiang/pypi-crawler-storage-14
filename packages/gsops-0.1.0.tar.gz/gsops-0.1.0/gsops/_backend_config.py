pytorch_atol = 1e-6
pytorch_rtol = 1e-5

np_atol = 1e-8
np_rtol = 1e-5


DEFAULT_DTYPE = None
DEFAULT_COMPLEX_DTYPE = None
