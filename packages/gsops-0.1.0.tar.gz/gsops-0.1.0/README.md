# `gsops`

Standalone [geomstats](https://github.com/geomstats/geomstats) backend.

(Some early work to potentially let ``geomstats`` backend to have its own life.)
