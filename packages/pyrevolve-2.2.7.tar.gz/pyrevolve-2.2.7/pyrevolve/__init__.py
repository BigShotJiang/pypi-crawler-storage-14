from __future__ import absolute_import

from pyrevolve.pyrevolve import * # noqa
from pyrevolve.crevolve import * # noqa

from . import _version
__version__ = _version.get_versions()['version']
