from typing import (
    Union,
)

TypeStr = str
Decodable = Union[bytes, bytearray]
