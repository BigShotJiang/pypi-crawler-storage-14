"""Package for log analysis"""
