"""
Mdclinica Bot - Умный Telegram бот на Smart Bot Factory
"""

import asyncio
from smart_bot_factory.router import EventRouter
from smart_bot_factory.creation import BotBuilder

from smart_bot_factory.message import send_message_by_human

from rag_tools import rag_router

# Инициализация
event_router = EventRouter("mdclinica")
bot_builder = BotBuilder("mdclinica")

# =============================================================================
# ЗАПУСК
# =============================================================================

@event_router.event_handler("collect_name", notify=False, once_only=False)
async def start_handler(user_id: int, event_data: str):
    """
    Обрабатывает событие "start"
    """
    await send_message_by_human(user_id=user_id, message_text="Привет! Я бот для консультаций по медицине. Как я могу помочь вам?")


async def main():
    # ========== РЕГИСТРАЦИЯ РОУТЕРОВ ==========
    bot_builder.register_routers(event_router)
    
    # Можно добавить Telegram роутеры:
    # from aiogram import Router
    # telegram_router = Router(name="commands")
    # bot_builder.register_telegram_router(telegram_router)
    
    # ========== КАСТОМИЗАЦИЯ (до build) ==========
    # Установить кастомный PromptLoader:
    # from smart_bot_factory.utils import UserPromptLoader
    # custom_loader = UserPromptLoader("mdclinica")
    # bot_builder.set_prompt_loader(custom_loader)
    
    # ========== СБОРКА И ЗАПУСК ==========
    bot_builder.register_rag(rag_router)
    
    await bot_builder.build()
    await bot_builder.start()

if __name__ == "__main__":
    asyncio.run(main())
    
