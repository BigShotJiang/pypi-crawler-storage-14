"""MCP Server for Idealista7"""
