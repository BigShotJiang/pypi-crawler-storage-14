from .data_model import ClassifiedDocument, classify_document

__all__ = [
    "ClassifiedDocument",
    "classify_document",
]
