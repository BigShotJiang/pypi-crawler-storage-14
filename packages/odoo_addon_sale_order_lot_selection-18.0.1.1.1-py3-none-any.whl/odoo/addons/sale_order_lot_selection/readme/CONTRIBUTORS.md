- Nicola Malcontenti \<<nicola.malcontenti@agilebg.com>\>
- Lorenzo Battistini \<<lorenzo.battistini@agilebg.com>\>
- Serpent Consulting Services Pvt. Ltd. \<<support@serpentcs.com>\>
- Bhavesh Odedra \<<bodedra@opensourceintegrators.com>\>
- François Honoré \<<francois.honore@acsone.eu>\>
- Florian da Costa \<<florian.dacosta@akretion.com>\>
- Sander Lienaerts \<<sander.lienaerts@codeforward.nl>\>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez