This module allows you to select a lot number on sale order line. This
selected lot number will be the one delivered to the Customer.
