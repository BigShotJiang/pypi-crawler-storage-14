<p align="center">
 <img src="https://raw.githubusercontent.com/ScottehMax/pyshowdown/main/assets/logo.png" width=300 alt="pyshowdown logo"/>
</p>

<p align="center">
  This is a client library for the Pokémon Showdown! battle simulator.
</p>