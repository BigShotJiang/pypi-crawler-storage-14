# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
# ------------------------------------------------------------------------------
from .trainer import Trainer
from ..models import GPModel

from functools import partial
import typing
from typing import Callable, Dict, Tuple, Optional
import optax
import pyswarms as ps
from jax import value_and_grad, jit, random
from typing import Tuple, Dict, Callable
from jaxtyping import Key, Array, Float, Int, Bool
import jax.numpy as jnp
from jax import vmap
from jax.flatten_util import ravel_pytree
import numpy as np

TypeGPModel = typing.TypeVar("GPModel", bound=GPModel)


class SwarmTrainer(Trainer):

    def __init__(self, 
                 swarm_settings={"c1": 0.5, "c2": 0.3, "w": 0.9},
                 number_iterations: int = 100,
                 number_particles: int = 20,
                 number_restarts: int = 1,
                 bounds: Tuple[Array, Array] = None,
                 **kwargs):
        super().__init__(**kwargs)
        self.swarm_settings = swarm_settings
        self.number_iterations = number_iterations
        self.number_particles = number_particles
        self.number_restarts = number_restarts
        self.bounds = bounds



    def train(self, model):
        self.model = model
        kernel = model.kernel
        nlml = self.nlml  # your stateful NLML function

        # Flatten kernel parameters
        params_template = kernel.get_params()
        flat_template, unravel_fn = ravel_pytree(params_template)
        dim = len(flat_template)

        # --- Set bounds if not provided ---
        if self.bounds is None:
            lb, ub = [], []
            priors = kernel.get_priors()
            keys = params_template.keys()
            for name in priors:
                if name in keys:
                    args = priors[name].get_args()
                    low = args.get("low")
                    high = args.get("high")
                    diff = abs(high - low)
                    lb.extend([low - diff] * len(params_template[name]))
                    ub.extend([high + diff] * len(params_template[name]))
            bounds = (np.array(lb), np.array(ub))
        else:
            bounds = self.bounds

        # --- Define the particle loss function ---
        def single_particle_loss(particles: np.ndarray) -> np.ndarray:
            # particles.shape = (n_particles, dim)
            costs = []
            for flat_params in particles:
                params = unravel_fn(flat_params)   # flat_params is 1D
                kernel.update_params(params)
                costs.append(float(nlml(kernel)))
            return np.array(costs)         # return Python float

        # --- Run PSO with multiple restarts ---
        history = {}
        for r in range(self.number_restarts):
            optimizer = ps.single.GlobalBestPSO(
                n_particles=self.number_particles,
                dimensions=dim,
                options=self.swarm_settings,
                bounds=bounds
            )

            best_cost, best_pos = optimizer.optimize(
                single_particle_loss,
                iters=self.number_iterations,
                verbose=True
            )

            best_params = unravel_fn(best_pos)
            kernel.update_params(best_params)

            history[f"run_{r}"] = {
                "params": best_params,
                "loss": best_cost
            }

            if self.verbose:
                print(f"Run {r}: Best loss = {best_cost:.5f}")

        # Filter out NaN runs
        history = {k: v for k, v in history.items() if not np.isnan(v["loss"])}
        best_key = min(history, key=lambda k: history[k]["loss"])

        if self.verbose:
            print("Overall best run:", best_key, "loss:", history[best_key]["loss"])

        best_run = history[best_key]
        return best_run, history if self.save_history else best_run, {}


def train_swarm(
        model: Callable,
        key: Key,
        bounds: Tuple[Array, Array] = (),
        optimizer: Dict = {"c1": 0.5, "c2": 0.3, "w": 0.9},
        n_restarts: Int = 1,
        n_particles: Int = 20,
        n_iterations: Int = 100,
        save_history: bool = False,
        verbose: bool = True
    ) -> Tuple:
    """
    Trains a model using PySwarms particle swarm optimizer with multiple random restarts.

    Args:
        model (Callable): The GP model containing kernel, likelihood, and data (X, Y, etc.).
        key (KeyArray): JAX random key for initialization.
        bounds (Tuple(Array, Array)) bounds for the optimization, Arrays must be of shape dimension 
        number_restarts (int): Number of random restarts.
        optimizer (Dict): Optimizer options for PySwarms (c1, c2, w).
        number_particles (int): Number of particles.
        number_iterations (int): Number of iterations.
        save_history (bool): If True, returns all optimization runs' history.
        verbose (bool): If True, prints progress and loss values.

    Returns:
        Tuple: (best_run: Dict, history: Dict)
            - best_run: Dictionary containing "params", "loss", and "key" for the best performing restart.
            - history: Dictionary of all optimization runs.
    """
    kernel = model.kernel
    likelihood = model.likelihood

    if "sigma_sq" in model.get_attributes().keys():
        nlml = partial(likelihood, model.X, model.Y, model.sigma_sq, model.jitter)
    else:
        nlml = partial(likelihood, model.X, model.Y, model.jitter)
    

    # function for raveling and unraveling the hyperparameter dictionary of the kernel
    dict_params = dict()
    params_template = kernel.get_params()
    raveled_template, unravel_fn = ravel_pytree(params_template)
    dimensions = len(raveled_template)
    
    
    def single_particle_loss(flat_params: Array) -> float:
        #params = array_to_dict(params)
        params = unravel_fn(flat_params)
        kernel.update_params(params)
        return nlml(kernel)
    
    # loss_fn = jit( vmap(single_particle_loss))
    loss_fn = single_particle_loss


    # for i in tqdm(range(n_restarts)):
    # key, subkey = random.split(key)

    param_keys = params_template.keys()
    priors_template = kernel.get_priors()

    if bounds == ():
        lower_bounds = []
        upper_bounds = []
        for prior_name in priors_template:
            if prior_name in param_keys:
                args = priors_template[prior_name].get_args()
                lower = args.get("low")
                upper = args.get("high")
                diff = abs(upper - lower)
                lower_bounds.extend([lower-diff] * len(params_template[prior_name]))
                upper_bounds.extend([upper+diff] * len(params_template[prior_name]))
        bounds = (lower_bounds, upper_bounds)

    # Particle Swarm Optimization via PySwarms
    optimizer_ = ps.single.GlobalBestPSO(
        n_particles=n_particles,
        dimensions=dimensions,
        options=optimizer,
        bounds=bounds
    )
    i=1
    best_cost, best_pos = optimizer_.optimize(loss_fn, iters=n_iterations, verbose=True)

    optimized_params= unravel_fn(best_pos)

    dict_optimization_run = {"params": optimized_params, "loss": best_cost, "key": key}
    dict_params[f"run_{i}"] = dict_optimization_run

    #if verbose:
    #    print(f"Run {i}: Loss = {best_cost}")

    # Filter out NaN runs if any
    dict_params = {k: v for k, v in dict_params.items() if not np.isnan(v['loss'])}

    # Find the best run
    best_run = min(dict_params, key=lambda x: dict_params[x]['loss'])
    print("Best run:", best_run, ":", dict_params[best_run]['loss'])

    return dict_params[best_run], dict_params if save_history else {}