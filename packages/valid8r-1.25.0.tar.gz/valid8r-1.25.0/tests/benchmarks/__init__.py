"""Performance benchmark tests for valid8r."""

from __future__ import annotations
