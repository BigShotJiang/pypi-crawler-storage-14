"""Security tests for valid8r parsers."""
