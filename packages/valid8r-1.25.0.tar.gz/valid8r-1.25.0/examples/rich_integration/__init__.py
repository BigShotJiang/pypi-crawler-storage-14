"""Rich Integration Example for valid8r.

This package demonstrates how to integrate valid8r with Rich for creating
beautiful, validated CLI applications.
"""

from __future__ import annotations
