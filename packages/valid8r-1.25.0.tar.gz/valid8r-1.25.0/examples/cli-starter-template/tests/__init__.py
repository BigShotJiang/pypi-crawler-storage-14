"""Tests for CLI starter template."""
