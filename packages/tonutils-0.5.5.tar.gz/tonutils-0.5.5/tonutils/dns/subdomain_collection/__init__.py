from .contract import SubdomainCollection

__all__ = [
    "SubdomainCollection",
]
