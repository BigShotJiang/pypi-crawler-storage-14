"""
MetaGuard Data Module

Contains data generation and loading utilities.

Author: Moslem Mohseni
"""

from __future__ import annotations

__all__: list[str] = []
