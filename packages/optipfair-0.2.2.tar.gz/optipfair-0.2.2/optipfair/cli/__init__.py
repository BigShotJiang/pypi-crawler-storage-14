"""
CLI package for OptiPFair.
"""

from .commands import cli

__all__ = ["cli"]