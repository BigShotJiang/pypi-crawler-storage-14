"""
Evaluation package for OptiPFair.

This package provides evaluation utilities for assessing pruned models.
"""