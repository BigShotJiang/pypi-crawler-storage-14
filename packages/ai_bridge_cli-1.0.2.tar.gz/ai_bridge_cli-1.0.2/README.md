# AI Batch Processor (AIB) 🚀

**AIB (AI Bridge)** 是一个专为高并发和大规模数据处理设计的统一 AI 调用桥梁。它封装了 **Kimi (Moonshot)**, **Qwen (Aliyun)**, **Gemini (Google)** 以及 **OpenAI 兼容接口**，提供了一套简单、统一且强大的命令行工具。

无论是需要毫秒级响应的**实时对话**，还是追求极致性价比的**离线批量处理**，AIB 都能轻松搞定。

## ✨ 核心特性

*   **🔌 多厂商统一支持**: 一套代码，无缝切换 Kimi, Qwen, Gemini, OpenAI。
*   **⚡ 双模式引擎**:
    *   **Realtime Mode**: 基于 `asyncio` 的本地高并发请求，适合实时性要求高的场景。
    *   **Offline Batch Mode**: 利用厂商 (Qwen/Gemini) 原生 Batch API，**成本降低 50%**，适合大规模离线任务。
*   **🛡️ 工业级稳定性**:
    *   自动重试 (Exponential Backoff) 与错误处理。
    *   智能速率限制 (Rate Limit) 保护。
    *   **断点续传**: 自动跳过已处理文件，防止重复扣费。
    *   **任务持久化**: Batch 任务状态自动保存到本地，重启不丢失。
*   **📂 智能文件处理**:
    *   支持 PDF, 图片, 视频等多模态输入。
    *   自动进行 Base64 编码或文件上传。
    *   大文件内存熔断保护。

## 📦 安装

推荐使用 `uv` 或 `pip` 进行安装：

```bash
# 使用 uv (推荐)
uv sync

# 或者使用 pip
pip install -r requirements.txt
```

## ⚙️ 配置

AIB 支持 **YAML 配置文件** 和 **环境变量** 两种配置方式。

### 1. 配置文件 (推荐)
在用户目录创建 `~/.aibatch/config.yaml` 或在当前目录创建 `config.yaml`：

```yaml
# 默认使用的厂商
default_vendor: "kimi"

# 默认并发数 (Realtime 模式)
concurrency: 5

# 系统配置
system:
  max_retries: 3

# 厂商凭证
vendors:
  kimi:
    api_key: "sk-xxxxxxxx"
    model: "kimi-latest"
  qwen:
    api_key: "sk-xxxxxxxx"
    model: "qwen-plus"
  gemini:
    api_key: "AIzaSy..."
    model: "gemini-1.5-flash"
  openai:
    api_key: "sk-xxxxxxxx"
    base_url: "https://api.openai.com/v1"
    model: "gpt-4o"
```

### 2. 环境变量
你也可以通过环境变量直接设置 API Key，优先级高于配置文件：
*   `AIBATCH_KIMI_API_KEY`
*   `AIBATCH_QWEN_API_KEY`
*   `AIBATCH_GEMINI_API_KEY`
*   `AIBATCH_OPENAI_API_KEY`

## 🚀 使用指南

### 1. 命令行基础

```bash
# 查看帮助
aib --help
```

### 2. 实时模式 (Realtime)
适合日常对话或少量文件处理。

```bash
# 简单对话
aib -v kimi -p "你好，介绍一下你自己"

# 处理单个文件
aib -v qwen -i ./document.pdf -p "总结这篇文章"

# 批量处理目录下的所有文件 (并发)
aib -v gemini -i "./data/*.txt" -p "提取其中的关键信息" --json
```

### 3. 离线批量模式 (Offline Batch) 💰
适合处理成千上万个文件，价格通常减半，但需要等待数小时。
**目前支持: Qwen, Gemini**

```bash
# 提交批量任务
aib -v qwen --mode offline -i "./large_dataset/*.json" -p "进行情感分析"

# 检查任务状态 (支持断点查询)
aib --check-batch
```

### 4. 常用参数

| 参数 | 简写 | 说明 |
| :--- | :--- | :--- |
| `--vendor` | `-v` | 指定厂商 (kimi, qwen, gemini, openai) |
| `--model` | `-m` | 指定模型名称 (覆盖配置) |
| `--input` | `-i` | 输入文件路径 (支持通配符 `*`) |
| `--prompt` | `-p` | 提示词 |
| `--json` | `-j` | 强制输出 JSON 格式 |
| `--mode` | | `realtime` (默认) 或 `offline` |
| `--check-batch` | | 检查所有后台 Batch 任务的状态 |

## 📝 许可证

MIT License
