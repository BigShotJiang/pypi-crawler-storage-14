import os
import asyncio
from datetime import datetime
from typing import Union, List, Optional
from .handlers import get_handler_by_vendor
from .core.processor import RealtimeBatchProcessor
from .core.manager import QwenBatchManager, GeminiBatchManager

async def smart_process(
    input_target: Union[str, List[str], None] = None, 
    vendor: str = "kimi", 
    api_key: str = "", 
    model: str = "", 
    base_url: Optional[str] = None,
    prompt: str = "",
    json_mode: bool = False,
    mode: str = "realtime", # realtime / offline
    concurrency: int = 5,
    log_path: Optional[str] = None, 
    delete_temp_on_success: bool = False,
    max_retries: int = 3,
    **kwargs
):
    if not api_key or not model: raise ValueError("API Key and Model are required.")

    # 自动生成日志名 (仅针对批量列表)
    if not log_path and isinstance(input_target, list):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = f"batch_log_{vendor}_{ts}.jsonl"

    # === 分流 A: 离线 Batch API (省钱模式) ===
    if mode == "offline" and isinstance(input_target, list):
        if vendor.lower() == "qwen":
            mgr = QwenBatchManager(api_key, base_url)
            return await mgr.run_batch_job(input_target, model, prompt)
        
        if vendor.lower() == "gemini":
            mgr = GeminiBatchManager(api_key, base_url)
            return await mgr.run_batch_job(input_target, model, prompt)
            
        print(f"⚠️ Vendor {vendor} does not support offline batch, falling back to realtime.")

    # === 分流 B: 实时处理 (Real-time) ===
    handler = get_handler_by_vendor(vendor)
    exec_kwargs = {"api_key": api_key, "model": model, "base_url": base_url, "json_mode": json_mode, **kwargs}

    # B1. 纯对话 / 单文件直连
    if not input_target or isinstance(input_target, str):
        # 兼容空字符串作为占位符
        f_path = input_target if input_target else None
        # 如果是纯对话(None)，analyze_file应为 False
        do_analyze = True if f_path else False
        return await asyncio.to_thread(handler, file_path=f_path, prompt=prompt, analyze_file=do_analyze, **exec_kwargs)
    
    # B2. 批量并发
    elif isinstance(input_target, list):
        if not input_target: return {}
        
        proc = RealtimeBatchProcessor(
            concurrency=concurrency, 
            log_path=log_path,
            max_retries=max_retries 
        )
        
        final = await proc.run(input_target, handler, prompt=prompt, analyze_file=True, **exec_kwargs)
        
        if delete_temp_on_success and log_path and os.path.exists(log_path):
            try: os.remove(log_path)
            except: pass
        elif log_path: 
            print(f"✅ Log saved: {os.path.abspath(log_path)}")
            
        return final
    
    else:
        raise ValueError("Invalid input_target type")