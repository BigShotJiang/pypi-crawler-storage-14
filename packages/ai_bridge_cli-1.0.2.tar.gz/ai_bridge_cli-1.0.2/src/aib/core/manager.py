import os
import json
import asyncio
import time
import mimetypes
from datetime import datetime
from pathlib import Path
from openai import OpenAI
from ..utils.common import encode_image, parse_result

class BaseBatchManager:
    JOBS_FILE = os.path.expanduser("~/.aibatch/jobs.json")

    def __init__(self, api_key, base_url=None):
        self.api_key = api_key
        self.base_url = base_url

    def _save_job_record(self, job_id, vendor, model, status="running", note=""):
        """Persist job status to local file"""
        record = {
            "job_id": job_id,
            "vendor": vendor,
            "model": model,
            "status": status,
            "timestamp": int(time.time()),
            "last_check": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "note": note
        }
        
        jobs = []
        if os.path.exists(self.JOBS_FILE):
            try:
                with open(self.JOBS_FILE, 'r', encoding='utf-8') as f:
                    jobs = json.load(f)
            except: pass
        
        # Update existing or append new
        found = False
        for j in jobs:
            if j["job_id"] == job_id:
                j.update(record)
                found = True
                break
        if not found:
            jobs.append(record)
            
        try:
            os.makedirs(os.path.dirname(self.JOBS_FILE), exist_ok=True)
            with open(self.JOBS_FILE, 'w', encoding='utf-8') as f:
                json.dump(jobs, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"⚠️ Failed to save job record: {e}")

    async def check_status(self, job_id):
        raise NotImplementedError

    @staticmethod
    async def check_all_jobs(config):
        """Check status of all active jobs"""
        jobs_file = os.path.expanduser("~/.aibatch/jobs.json")
        if not os.path.exists(jobs_file):
            print("📭 No batch jobs found.")
            return

        try:
            with open(jobs_file, 'r', encoding='utf-8') as f:
                jobs = json.load(f)
        except:
            print("❌ Failed to load jobs file.")
            return

        active_jobs = [j for j in jobs if j.get("status") not in ["completed", "failed", "cancelled", "expired"]]
        if not active_jobs:
            print("✅ No active batch jobs.")
            return

        print(f"🔄 Checking {len(active_jobs)} active jobs...")
        
        from ..config import get_vendor_config
        
        for job in active_jobs:
            vendor = job["vendor"]
            job_id = job["job_id"]
            
            # Get credentials
            v_cfg = get_vendor_config(config, vendor)
            api_key = v_cfg.get("api_key")
            base_url = v_cfg.get("base_url")
            
            if not api_key:
                print(f"⚠️ Skipping {vendor} job {job_id}: No API Key found.")
                continue
                
            manager = None
            if vendor == "qwen":
                manager = QwenBatchManager(api_key, base_url)
            elif vendor == "gemini":
                manager = GeminiBatchManager(api_key, base_url)
                
            if manager:
                try:
                    status = await manager.check_status(job_id)
                    print(f"   [{vendor}] {job_id} -> {status}")
                    # Update record
                    manager._save_job_record(job_id, vendor, job.get("model"), status)
                except Exception as e:
                    print(f"   [{vendor}] {job_id} -> Error: {str(e)}")

# Qwen Batch Manager
class QwenBatchManager(BaseBatchManager):
    def __init__(self, api_key, base_url=None):
        super().__init__(api_key, base_url)
        self.base_url = base_url if base_url else "https://dashscope.aliyuncs.com/compatible-mode/v1"
        self.client = OpenAI(api_key=api_key, base_url=self.base_url)

    async def _upload_single_helper(self, file_path):
        try:
            return await asyncio.to_thread(self.client.files.create, file=open(file_path, "rb"), purpose="file-extract")
        except: return None

    async def check_status(self, job_id):
        job = await asyncio.to_thread(self.client.batches.retrieve, job_id)
        return job.status

    async def run_batch_job(self, file_list: list, model: str, prompt: str, poll_interval=30):
        is_vision = "vl" in model.lower()
        batch_reqs = []
        
        if not is_vision: # 文档模式
            print(f"📦 [Qwen Batch] Doc Mode: Uploading {len(file_list)} files...")
            tasks = [self._upload_single_helper(fp) for fp in file_list if os.path.exists(fp)]
            uploads = await asyncio.gather(*tasks)
            valid = [(file_list[i], up.id) for i, up in enumerate(uploads) if up]
            if not valid: return {"error": "Upload failed"}
            
            for fp, fid in valid:
                batch_reqs.append({
                    "custom_id": os.path.basename(fp), "method": "POST", "url": "/v1/chat/completions",
                    "body": {"model": model, "messages": [{"role": "system", "content": f"fileid://{fid}"}, {"role": "user", "content": prompt}]}
                })
        else: # 视觉模式
            print(f"📦 [Qwen Batch] Vision Mode: Encoding images...")
            for fp in file_list:
                if not os.path.exists(fp): continue
                try:
                    mime = mimetypes.guess_type(fp)[0] or "image/jpeg"
                    b64 = encode_image(fp)
                    batch_reqs.append({
                        "custom_id": os.path.basename(fp), "method": "POST", "url": "/v1/chat/completions",
                        "body": {"model": model, "messages": [{"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}}]}]}
                    })
                except: pass

        if not batch_reqs: return {"error": "No valid requests"}
        
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        f_name = f"qwen_batch_{ts}.jsonl"
        with open(f_name, "w", encoding="utf-8") as f: 
            for r in batch_reqs: f.write(json.dumps(r, ensure_ascii=False)+"\n")
            
        try:
            print(f"📦 Submitting Batch Job (Size: {os.path.getsize(f_name)/1024:.2f} KB)...")
            bf = self.client.files.create(file=Path(f_name), purpose="batch")
            job = self.client.batches.create(input_file_id=bf.id, endpoint="/v1/chat/completions", completion_window="24h")
            print(f"🚀 Job Created: {job.id}")
            
            # Save Job Record
            self._save_job_record(job.id, "qwen", model, "validating")
            
        except Exception as e: return {"error": str(e)}
        finally: 
            try: os.remove(f_name)
            except: pass

        print("⏳ Waiting for Qwen...")
        while True:
            job = self.client.batches.retrieve(job.id)
            
            # Update status periodically
            if job.status != "validating":
                 self._save_job_record(job.id, "qwen", model, job.status)
                 
            if job.status in ["completed", "failed", "expired", "cancelled"]: break
            await asyncio.sleep(poll_interval)
            
        if job.status != "completed": return {"error": f"Job {job.status}"}
        
        print("📥 Downloading results...")
        res_map = {}
        if job.output_file_id:
            content = self.client.files.content(job.output_file_id).text
            for line in content.splitlines():
                if not line: continue
                obj = json.loads(line)
                try: res_map[obj["custom_id"]] = parse_result(obj["response"]["body"]["choices"][0]["message"]["content"])
                except: res_map[obj["custom_id"]] = obj
        return res_map

# Gemini Batch Manager
class GeminiBatchManager(BaseBatchManager):
    def __init__(self, api_key, base_url=None):
        super().__init__(api_key, base_url)
        from google import genai
        client_kwargs = {"api_key": api_key}
        if base_url: client_kwargs["http_options"] = {"api_endpoint": base_url}
        self.client = genai.Client(**client_kwargs)

    async def _upload_single(self, file_path):
        from google.genai import types
        if not os.path.exists(file_path): return None, None
        try:
            mime = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
            with open(file_path, "rb") as f:
                up_file = await asyncio.to_thread(
                    self.client.files.upload, 
                    file=f, 
                    config=types.UploadFileConfig(display_name="batch_doc", mime_type=mime)
                )
            # 等待就绪
            retry = 0
            while retry < 10:
                if up_file.state.name == "ACTIVE": return file_path, up_file.uri
                if up_file.state.name == "FAILED": return file_path, None
                await asyncio.sleep(2)
                try: up_file = await asyncio.to_thread(self.client.files.get, name=up_file.name)
                except: pass
                retry += 1
            return file_path, None
        except: return file_path, None

    async def check_status(self, job_id):
        job = self.client.batches.get(name=job_id)
        return job.state

    async def run_batch_job(self, file_list, model, prompt, poll_interval=30):
        print(f"📦 [Gemini Batch] Uploading {len(file_list)} files...")
        tasks = [self._upload_single(fp) for fp in file_list]
        uploads = await asyncio.gather(*tasks)
        valid = [x for x in uploads if x[1]]
        if not valid: return {"error": "Upload failed"}
        
        batch_requests = []
        for fp, uri in valid:
            req = {
                "request": {
                    "contents": [{"role": "user", "parts": [{"file_data": {"file_uri": uri, "mime_type": mimetypes.guess_type(fp)[0]}}, {"text": prompt}]}],
                    "generation_config": {"response_mime_type": "application/json", "temperature": 0.1}
                },
                "key": os.path.basename(fp)
            }
            batch_requests.append(req)

        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        f_name = f"gemini_batch_{ts}.jsonl"
        with open(f_name, "w", encoding="utf-8") as f:
            for r in batch_requests: f.write(json.dumps(r, ensure_ascii=False) + "\n")

        print("📦 Submitting Gemini Job...")
        try:
            from google.genai import types
            bf = self.client.files.upload(file=f_name, config=types.UploadFileConfig(display_name="batch_in", mime_type="application/json"))
            job = self.client.batches.create(model=model, src=bf.name, config=types.CreateBatchJobConfig(display_name=f"job_{ts}"))
            print(f"🚀 Job Created: {job.name}")
            
            # Save Job Record
            self._save_job_record(job.name, "gemini", model, "ACTIVE")
            
        except Exception as e: return {"error": str(e)}
        finally:
            try: os.remove(f_name)
            except: pass

        print("⏳ Waiting for Gemini (with heartbeat)...")
        start_time = time.time()
        fail_count = 0
        while True:
            try:
                job = self.client.batches.get(name=job.name)
                elapsed = int(time.time() - start_time)
                print(f"   [{datetime.now().strftime('%H:%M:%S')}] Status: {job.state} | Elapsed: {elapsed}s")
                
                # Update Record
                self._save_job_record(job.name, "gemini", model, job.state)
                
                if job.state in ["COMPLETED", "FAILED", "CANCELLED"]: break
                fail_count = 0 
                await asyncio.sleep(poll_interval)
            except Exception as e:
                err = str(e)
                # 增强型重试逻辑
                if any(k in err for k in ["400", "location", "precondition", "network", "server"]):
                    fail_count += 1
                    wait = min(60, 5 * fail_count)
                    print(f"⚠️ Network error (Attempt {fail_count}), retrying in {wait}s...")
                    await asyncio.sleep(wait)
                else:
                    return {"error": f"Polling crashed: {err}"}

        if job.state != "COMPLETED": return {"error": f"Job {job.state}"}

        print("📥 Downloading results...")
        res_map = {}
        try:
            content = self.client.files.content(name=job.output_file).text
            for line in content.splitlines():
                if not line: continue
                obj = json.loads(line)
                key = obj.get("key", "unknown")
                try: res_map[key] = parse_result(obj["response"]["candidates"][0]["content"]["parts"][0]["text"])
                except: res_map[key] = obj
        except Exception as e: return {"error": f"Download failed: {str(e)}"}
        return res_map