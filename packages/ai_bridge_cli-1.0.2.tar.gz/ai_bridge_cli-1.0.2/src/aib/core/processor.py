import asyncio
import os
import json
import time
from typing import List, Callable
from ..utils.common import sanitize_content

# 尝试导入可选库
try:
    import aiofiles
    HAS_AIOFILES = True
except ImportError: HAS_AIOFILES = False
try:
    from tqdm.asyncio import tqdm
    HAS_TQDM = True
except ImportError: HAS_TQDM = False

class RealtimeBatchProcessor:
    def __init__(self, concurrency: int = 5, log_path: str = None, max_retries: int = 3):
        self.semaphore = asyncio.Semaphore(concurrency)
        self.log_path = log_path
        self.lock = asyncio.Lock()
        self.max_retries = max_retries
        
        if self.log_path:
            log_dir = os.path.dirname(self.log_path)
            if log_dir and not os.path.exists(log_dir):
                 try: os.makedirs(log_dir)
                 except: pass

    def _load_processed_history(self) -> set:
        """读取日志，获取已完成任务"""
        processed = set()
        if not self.log_path or not os.path.exists(self.log_path):
            return processed
            
        print(f"📖 Scanning history log: {self.log_path}")
        try:
            with open(self.log_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line: continue
                    try:
                        record = json.loads(line)
                        # 只有非 error 的结果才算成功
                        result = record.get("result", {})
                        is_error = False
                        if isinstance(result, dict) and "error" in result: is_error = True
                        elif isinstance(result, str) and "error" in result.lower(): is_error = True
                            
                        if not is_error:
                            file_path = record.get("file")
                            if file_path: processed.add(file_path)
                    except: pass
        except Exception as e:
            print(f"⚠️ Failed to read history: {e}")
        return processed

    async def _worker(self, file_path: str, handler_func: Callable, **kwargs):
        async with self.semaphore:
            result = None
            attempt = 0
            while attempt <= self.max_retries:
                try:
                    result = await asyncio.to_thread(handler_func, file_path=file_path, **kwargs)
                    # 智能错误重试检测
                    if isinstance(result, dict) and "error" in result:
                        err = str(result["error"]).lower()
                        if any(k in err for k in ["429", "overload", "rate limit", "timeout", "location", "precondition"]):
                            raise Exception(err)
                        break 
                    break 
                except Exception as e:
                    attempt += 1
                    if attempt <= self.max_retries:
                        sleep_time = 2 ** attempt
                        await asyncio.sleep(sleep_time)
                    else:
                        result = {"error": f"Max retries exceeded: {str(e)}"}

            # 实时存档 (脱敏)
            if self.log_path:
                record = {"file": file_path, "timestamp": time.time(), "result": result}
                safe_record = sanitize_content(record)
                async with self.lock:
                    try:
                        line = json.dumps(safe_record, ensure_ascii=False) + "\n"
                        mode = 'a'
                        if HAS_AIOFILES:
                            async with aiofiles.open(self.log_path, mode, encoding='utf-8') as f: await f.write(line)
                        else:
                            # Non-blocking fallback
                            loop = asyncio.get_running_loop()
                            await loop.run_in_executor(None, lambda: open(self.log_path, mode, encoding='utf-8').write(line))
                    except: pass
            return file_path, result

    async def run(self, file_list: List[str], handler_func: Callable, resume: bool = False, **kwargs):
        skipped_files = set()
        if resume and self.log_path and os.path.exists(self.log_path):
            skipped_files = self._load_processed_history()
            if skipped_files: print(f"⏭️ Resuming: Skipping {len(skipped_files)} completed tasks.")
        elif self.log_path and os.path.exists(self.log_path):
            try: os.remove(self.log_path)
            except: pass

        tasks = []
        for fp in file_list:
            if not os.path.exists(fp):
                print(f"⚠️ File not found: {fp}")
                continue
            if fp in skipped_files: continue
            tasks.append(self._worker(fp, handler_func, **kwargs))

        if not tasks:
            print("✅ All tasks completed.")
            return {}

        print(f"🚀 [Realtime] Tasks: {len(tasks)} | Concurrency: {self.semaphore._value} | Log: {self.log_path}")
        
        if HAS_TQDM: results = await tqdm.gather(*tasks, desc="Progress")
        else: results = await asyncio.gather(*tasks)
        
        return {k: v for k, v in results}