import os
import re
import json
import base64
from typing import Any

# 常量定义
MAX_FILE_SIZE_MB = 20 
MAX_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024
THRESHOLD_LONG_CONTEXT = 7000   
THRESHOLD_K2_SWITCH = 100000    

def check_file_size(file_path):
    """防止内存溢出"""
    if not os.path.exists(file_path): return 
    size = os.path.getsize(file_path)
    if size > MAX_BYTES:
        raise ValueError(f"File too large ({size/1024/1024:.2f}MB). Limit {MAX_FILE_SIZE_MB}MB.")

def encode_image(image_path):
    """图片转 Base64"""
    check_file_size(image_path)
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def clean_json_string(raw_str):
    """深度清洗 JSON 字符串"""
    if not isinstance(raw_str, str): return str(raw_str)
    # 移除 Markdown 代码块
    cleaned = re.sub(r'^```json\s*', '', raw_str, flags=re.MULTILINE)
    cleaned = re.sub(r'^```\s*', '', cleaned, flags=re.MULTILINE)
    cleaned = re.sub(r'```$', '', cleaned, flags=re.MULTILINE)
    return cleaned.strip()

def parse_result(raw_content, force_json=False):
    """
    通用结果解析器
    force_json=True: 必须返回 Dict，解析失败返回 Error Dict
    force_json=False: 尝试解析，失败返回原始 String (适合聊天)
    """
    if not isinstance(raw_content, str): return raw_content
    
    # 1. 尝试正则提取 JSON
    try:
        match = re.search(r"\{.*\}|\[.*\]", raw_content, re.DOTALL)
        if match:
            return json.loads(match.group())
    except: pass

    # 2. 尝试清洗后解析
    try:
        return json.loads(clean_json_string(raw_content))
    except: pass
    
    # 3. 解析失败后的处理
    if force_json:
        return {"error": "Failed to parse JSON", "raw": raw_content}
        
    return raw_content

def sanitize_content(data: Any) -> Any:
    """
    【安全守门员】递归清洗数据中的敏感信息 (API Key)
    """
    if isinstance(data, str):
        # 匹配 sk- 开头
        data = re.sub(r'(sk-[a-zA-Z0-9]{10})[a-zA-Z0-9]+', r'\1***', data)
        # 匹配 AIza 开头 (Google)
        data = re.sub(r'(AIza[a-zA-Z0-9]{10})[a-zA-Z0-9-_]+', r'\1***', data)
        return data
    elif isinstance(data, dict):
        return {k: sanitize_content(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [sanitize_content(i) for i in data]
    else:
        return data