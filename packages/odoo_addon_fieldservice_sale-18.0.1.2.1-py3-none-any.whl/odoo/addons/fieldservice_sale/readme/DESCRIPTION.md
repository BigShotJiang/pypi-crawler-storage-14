The module integrates the Field Service application with the Sales one
and allows you to sell products that generate field service orders.
