- Go to Sales

- Create a new Quotation/Sale Order

- Set the FSM Location to be used

- On a Sale Order Line, select a product configured for field service
  orders

- Confirm the Sale Order

- Field Service orders linked to SO lines are created

- When a Field Service order is completed, the quantity delivered for its  
  linked sale order line will be updated to the quantity ordered,
  indicating this line is ready for invoicing.
