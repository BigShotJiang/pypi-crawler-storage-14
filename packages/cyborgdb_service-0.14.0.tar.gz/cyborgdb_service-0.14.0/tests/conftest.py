"""
Pytest configuration and fixtures for tests
"""

import os
import pytest

# Fix OpenMP conflict between cyborgdb_core (FAISS) and PyTorch
# This must be set before any libraries are imported
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


@pytest.fixture(scope="session", autouse=True)
def setup_environment():
    """Set up environment variables for all tests"""
    # Ensure the OpenMP fix is applied
    os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
    yield
