"""
Test valkeylite integration for CyborgDB Service.
"""

import os
import tempfile
import pytest
from pathlib import Path


class TestValkeyLiteIntegration:
    """Test valkeylite fallback functionality"""

    def test_valkeylite_connection_string_format(self):
        """Test that valkeylite generates a valid connection string"""
        from cyborgdb_service.core.valkeylite_manager import (
            get_valkeylite_connection_string,
        )

        # Use a temporary directory for the test database
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            conn_string = get_valkeylite_connection_string(db_path=db_path)

            # Verify the connection string format
            assert conn_string is not None
            assert "host:" in conn_string
            assert "port:" in conn_string
            assert "db:" in conn_string

            # Parse and validate the connection string
            parts = {}
            for part in conn_string.split(","):
                key, value = part.split(":", 1)
                parts[key] = value

            assert "host" in parts
            assert "port" in parts
            assert "db" in parts

    def test_config_uses_valkeylite_when_no_db_type(self):
        """Test that config automatically uses valkeylite when no db type is provided"""
        # Save current environment variables
        saved_conn_string = os.environ.get("CYBORGDB_CONNECTION_STRING")
        saved_db_type = os.environ.get("CYBORGDB_DB_TYPE")

        try:
            # Clear environment variables
            if "CYBORGDB_CONNECTION_STRING" in os.environ:
                del os.environ["CYBORGDB_CONNECTION_STRING"]
            if "CYBORGDB_DB_TYPE" in os.environ:
                del os.environ["CYBORGDB_DB_TYPE"]

            # Import and create settings (this will trigger set_fallbacks)
            # Note: We need to reload the module to get fresh settings
            import importlib
            from cyborgdb_service.core import config

            importlib.reload(config)
            settings = config.settings

            # Verify that connection strings were set by valkeylite
            assert settings.CYBORGDB_CONNECTION_STRING is not None
            assert settings.INDEX_LOCATION == "redis"
            assert settings.CONFIG_LOCATION == "redis"
            assert settings.ITEMS_LOCATION == "redis"
            assert "host:" in settings.CYBORGDB_CONNECTION_STRING

        finally:
            # Restore environment variables
            if saved_conn_string is not None:
                os.environ["CYBORGDB_CONNECTION_STRING"] = saved_conn_string
            elif "CYBORGDB_CONNECTION_STRING" in os.environ:
                del os.environ["CYBORGDB_CONNECTION_STRING"]

            if saved_db_type is not None:
                os.environ["CYBORGDB_DB_TYPE"] = saved_db_type
            elif "CYBORGDB_DB_TYPE" in os.environ:
                del os.environ["CYBORGDB_DB_TYPE"]

    def test_config_error_with_connection_string_but_no_db_type(self):
        """Test that config raises error when connection string is provided without db type"""
        # Save current environment variables
        saved_conn_string = os.environ.get("CYBORGDB_CONNECTION_STRING")
        saved_db_type = os.environ.get("CYBORGDB_DB_TYPE")

        try:
            # Set connection string but no db type
            os.environ["CYBORGDB_CONNECTION_STRING"] = "host:localhost,port:6379,db:0"
            if "CYBORGDB_DB_TYPE" in os.environ:
                del os.environ["CYBORGDB_DB_TYPE"]

            # Import and try to create settings
            import importlib
            from cyborgdb_service.core import config

            # This should raise a ValueError
            with pytest.raises(ValueError) as exc_info:
                importlib.reload(config)

            assert (
                "CYBORGDB_CONNECTION_STRING is provided but CYBORGDB_DB_TYPE is not set"
                in str(exc_info.value)
            )

        finally:
            # Restore environment variables
            if saved_conn_string is not None:
                os.environ["CYBORGDB_CONNECTION_STRING"] = saved_conn_string
            elif "CYBORGDB_CONNECTION_STRING" in os.environ:
                del os.environ["CYBORGDB_CONNECTION_STRING"]

            if saved_db_type is not None:
                os.environ["CYBORGDB_DB_TYPE"] = saved_db_type
            elif "CYBORGDB_DB_TYPE" in os.environ:
                del os.environ["CYBORGDB_DB_TYPE"]

    def test_config_error_with_db_type_but_no_connection_string(self):
        """Test that config raises error when db type is provided without connection string"""
        # Save current environment variables
        saved_conn_string = os.environ.get("CYBORGDB_CONNECTION_STRING")
        saved_db_type = os.environ.get("CYBORGDB_DB_TYPE")

        try:
            # Set db type but no connection string
            os.environ["CYBORGDB_DB_TYPE"] = "redis"
            if "CYBORGDB_CONNECTION_STRING" in os.environ:
                del os.environ["CYBORGDB_CONNECTION_STRING"]

            # Import and try to create settings
            import importlib
            from cyborgdb_service.core import config

            # This should raise a ValueError
            with pytest.raises(ValueError) as exc_info:
                importlib.reload(config)

            assert (
                "CYBORGDB_DB_TYPE is provided but CYBORGDB_CONNECTION_STRING is not set"
                in str(exc_info.value)
            )

        finally:
            # Restore environment variables
            if saved_conn_string is not None:
                os.environ["CYBORGDB_CONNECTION_STRING"] = saved_conn_string
            elif "CYBORGDB_CONNECTION_STRING" in os.environ:
                del os.environ["CYBORGDB_CONNECTION_STRING"]

            if saved_db_type is not None:
                os.environ["CYBORGDB_DB_TYPE"] = saved_db_type
            elif "CYBORGDB_DB_TYPE" in os.environ:
                del os.environ["CYBORGDB_DB_TYPE"]

    def test_valkeylite_instance_is_singleton(self):
        """Test that valkeylite returns the same connection string on multiple calls"""
        from cyborgdb_service.core.valkeylite_manager import (
            get_valkeylite_connection_string,
        )

        # Use a temporary directory for the test database
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"

            # Get connection string twice
            conn_string1 = get_valkeylite_connection_string(db_path=db_path)
            conn_string2 = get_valkeylite_connection_string(db_path=db_path)

            # Should return the same cached connection string
            assert conn_string1 == conn_string2
