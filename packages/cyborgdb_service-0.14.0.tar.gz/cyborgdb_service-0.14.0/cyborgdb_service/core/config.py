# cyborgdb_service/core/config.py
import os
import secrets
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import model_validator
from importlib.metadata import version, PackageNotFoundError


def get_package_version() -> str:
    """Get the package version from installed metadata or fallback to development version."""
    try:
        return version("cyborgdb-service")
    except PackageNotFoundError:
        return "0.13.0"


class Settings(BaseSettings):
    # API configuration
    APP_NAME: str = "CyborgDB Service"
    APP_DESCRIPTION: str = "REST API for CyborgDB: The Confidential Vector Database"
    APP_VERSION: str = get_package_version()
    API_VERSION: str = "v1"

    @property
    def API_PREFIX(self) -> str:
        """Construct the API prefix dynamically based on the API version."""
        return f"/{self.API_VERSION}"

    # Server configuration
    PORT: int = 8000

    # SSL/HTTPS Configuration - simple path-based approach
    SSL_CERT_PATH: Optional[str] = None
    SSL_KEY_PATH: Optional[str] = None

    @property
    def is_https_enabled(self) -> bool:
        """Check if HTTPS is enabled via certificate path"""
        return (
            self.SSL_CERT_PATH is not None
            and self.SSL_KEY_PATH is not None
            and os.path.exists(self.SSL_CERT_PATH)
            and os.path.exists(self.SSL_KEY_PATH)
        )

    # Security
    REQUIRE_API_KEY: bool = True
    CYBORGDB_API_KEY: Optional[str] = None

    # Logging
    CYBORGDB_SERVICE_LOG_LEVEL: str = "INFO"

    # Make sure these are settable via .env file
    CYBORGDB_DB_TYPE: Optional[str] = None
    CYBORGDB_CONNECTION_STRING: Optional[str] = None

    # CyborgDB configuration
    INDEX_LOCATION: Optional[str] = None
    CONFIG_LOCATION: Optional[str] = None
    ITEMS_LOCATION: Optional[str] = None
    INDEX_TABLE_NAME: str = "index"
    CONFIG_TABLE_NAME: str = "config"
    ITEMS_TABLE_NAME: str = "items"
    INDEX_CONNECTION_STRING: Optional[str] = None
    CONFIG_CONNECTION_STRING: Optional[str] = None
    ITEMS_CONNECTION_STRING: Optional[str] = None
    CPU_THREADS: int = 0
    GPU_OPERATIONS: Optional[str] = (
        None  # GPU operations setting (none, upsert, train, query, all, or comma-separated)
    )

    # GPU settings set automatically from GPU_OPERATIONS
    GPU_UPSERT: bool = False
    GPU_TRAIN: bool = False
    GPU_QUERY: bool = False

    # Concurrency settings
    WORKERS: int = 0  # 0 means auto-calculate based on CPU count

    # Replace the Config class with model_config
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Set fallbacks for locations and connection strings
    @model_validator(mode="after")
    def set_fallbacks(self):
        # Check if connection string is provided without db type - this is an error
        if self.CYBORGDB_CONNECTION_STRING and not self.CYBORGDB_DB_TYPE:
            raise ValueError(
                "CYBORGDB_CONNECTION_STRING is provided but CYBORGDB_DB_TYPE is not set. "
                "Please set CYBORGDB_DB_TYPE to 'redis' or 'postgres', "
                "or unset CYBORGDB_CONNECTION_STRING to use the default standalone database."
            )

        # Check if db type is provided without connection string - this is an error
        if self.CYBORGDB_DB_TYPE and not self.CYBORGDB_CONNECTION_STRING:
            raise ValueError(
                "CYBORGDB_DB_TYPE is provided but CYBORGDB_CONNECTION_STRING is not set. "
                "Please provide CYBORGDB_CONNECTION_STRING for your database, "
                "or unset CYBORGDB_DB_TYPE to use the default standalone database."
            )

        # If neither db type nor connection string are set, use valkeylite as fallback
        if not self.CYBORGDB_DB_TYPE and not self.CYBORGDB_CONNECTION_STRING:
            from cyborgdb_service.core.valkeylite_manager import (
                get_valkeylite_connection_string,
            )

            # Initialize valkeylite and get its connection string
            valkeylite_conn_string = get_valkeylite_connection_string()
            self.CYBORGDB_CONNECTION_STRING = valkeylite_conn_string

            # Valkeylite uses Redis protocol, so set locations to "redis"
            self.INDEX_LOCATION = "redis"
            self.CONFIG_LOCATION = "redis"
            self.ITEMS_LOCATION = "redis"
        else:
            # For redis and postgres, use fallback logic for locations
            self.INDEX_LOCATION = self.INDEX_LOCATION or self.CYBORGDB_DB_TYPE
            self.CONFIG_LOCATION = self.CONFIG_LOCATION or self.CYBORGDB_DB_TYPE
            self.ITEMS_LOCATION = self.ITEMS_LOCATION or self.CYBORGDB_DB_TYPE

        # Set individual connection strings with fallback to main connection string
        self.INDEX_CONNECTION_STRING = (
            self.INDEX_CONNECTION_STRING or self.CYBORGDB_CONNECTION_STRING
        )
        self.CONFIG_CONNECTION_STRING = (
            self.CONFIG_CONNECTION_STRING or self.CYBORGDB_CONNECTION_STRING
        )
        self.ITEMS_CONNECTION_STRING = (
            self.ITEMS_CONNECTION_STRING or self.CYBORGDB_CONNECTION_STRING
        )

        self.GPU_UPSERT, self.GPU_TRAIN, self.GPU_QUERY = parse_gpu_accelerate(
            self.GPU_OPERATIONS
        )

        return self


def parse_gpu_accelerate(gpu_accelerate: Optional[str]) -> tuple[bool, bool, bool]:
    """Parse the GPU_ACCELERATE environment variable to determine GPU settings."""
    if not gpu_accelerate:
        return False, False, False

    operations = [op.strip() for op in gpu_accelerate.lower().split(",")]

    if "none" in operations:
        return False, False, False
    elif "all" in operations:
        return True, True, True
    else:
        return ("upsert" in operations, "train" in operations, "query" in operations)


def ensure_api_key():
    """Ensure we have an API key, generating one if necessary."""
    # Check environment variable
    if key := os.getenv("SERVICE_API_KEY"):
        return key

    # Check anything else

    # Generate a new API key
    key = secrets.token_urlsafe(32)
    os.environ["SERVICE_API_KEY"] = key

    print("\n   API Key Generated")
    print(f"   Key: {key}")
    print("   Saved to environment variable: SERVICE_API_KEY")
    print("   To disable auth: REQUIRE_API_KEY=false\n")


settings = Settings()
