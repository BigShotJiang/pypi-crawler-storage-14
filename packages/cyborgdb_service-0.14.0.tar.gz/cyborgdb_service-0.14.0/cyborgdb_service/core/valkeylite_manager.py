# valkeylite_manager.py

import atexit
import logging
from pathlib import Path
from typing import Optional
from valkeylite import ValkeyServer

logger = logging.getLogger(__name__)

_server: Optional[ValkeyServer] = None


def get_valkeylite_connection_string(db_path: Optional[Path] = None) -> str:
    """Get or create valkeylite connection, starting server if needed."""
    global _server

    if _server is not None and _server.is_running():
        conn_info = _server.connection_kwargs
        return f"host:{conn_info['host']},port:{conn_info['port']},db:0"

    if db_path is None:
        db_path = Path.home() / ".cyborgdb" / "valkeylite"

    db_path.mkdir(parents=True, exist_ok=True)

    logger.info(f"Starting valkeylite server with data at {db_path}")

    _server = ValkeyServer(
        host="127.0.0.1",
        data_dir=db_path,
        persist=True,
        config={
            "appendonly": "yes",
            "maxmemory-policy": "noeviction",
        },
    )
    _server.start()
    atexit.register(_shutdown_valkeylite)

    conn_info = _server.connection_kwargs
    return f"host:{conn_info['host']},port:{conn_info['port']},db:0"


def _shutdown_valkeylite():
    """Graceful shutdown handler."""
    global _server
    if _server is not None:
        logger.info("Shutting down valkeylite server...")
        try:
            _server.stop(timeout=5.0)
        except Exception as e:
            logger.warning(f"Error during valkeylite shutdown: {e}")
            _server.terminate()
        _server = None


def get_valkeylite_instance() -> ValkeyServer:
    """Get the running server instance."""
    if _server is None or not _server.is_running():
        raise RuntimeError(
            "Valkeylite not initialized—call get_valkeylite_connection_string first"
        )
    return _server
