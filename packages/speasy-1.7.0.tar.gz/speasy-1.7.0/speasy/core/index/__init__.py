from .speasy_index import SpeasyIndex as _SpeasyIndex

index = _SpeasyIndex()


