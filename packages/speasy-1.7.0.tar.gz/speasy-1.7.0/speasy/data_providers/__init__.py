from .amda import AmdaWebservice
from .cda import CdaWebservice
from .csa import CsaWebservice
from .generic_archive import GenericArchive
from .ssc import SscWebservice
