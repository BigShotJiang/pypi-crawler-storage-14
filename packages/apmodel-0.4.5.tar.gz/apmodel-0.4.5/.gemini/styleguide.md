- This Project is compliant with PEP8.

- `[dependency-groups]` is not a pdm specific feature. `[project.optional-dependencies]` is used to specify so-called extra dependencies, but I don't see the point in publishing development dependencies on PyPI, so I'll leave it as it is.