# example.py
from public import populate_all

def foo():
    pass

class Foo:
    pass

fooint: int = 7
_foobool: bool = False

populate_all()
