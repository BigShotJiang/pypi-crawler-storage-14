import polars as pl
from gocharts.GoChartClass import Chart
from gocharts.utils import percent_value, calculate_distance, get_geom_data, get_theme_option
from gocharts.labeling import get_ticks_position
from gocharts.Aesthetics import Aesthetics
from gocharts.Facet import Facet
from gocharts.Facet import FacetUtils
from gocharts.Matrix import Matrix
from gocharts.GridUtils import GridUtils

class Generator:
    """
    Generator class for creating ECharts options from GoChart.
    This class is responsible for generating the options needed for rendering the chart.
    It processes the GoChart object and extracts the necessary information to create the chart options.
    """
    def __init__(self, gochart: Chart, width: int = 800, height: int = 600):
        self._verify_gochart(gochart)
        self.gochart = gochart
        self.width = width
        self.height = height

    def _verify_gochart(self, gochart):
        # This method currently does nothing meaningful
        isinstance(gochart, dict)

    def _get_types(self, map_item):
        types = set([g['map_types'][map_item] for g in self.gochart.geom_list])
        # possible echarts types are "value", "category", "time"
        polars_types = self.gochart.valid_polar_types
        check_subset = {k: types.issubset(v) for k, v in polars_types.items()}
        map_item_type = [k for k, v in check_subset.items() if v]
        if map_item_type == []:
            raise ValueError('Mixed types provided in mapping for ' + map_item + ': ' + ','.join(types))
        return map_item_type[0]

    def _get_unique_values(self, map_item, value_type='unique'):
        value_series = []
        for dict_i in self.gochart.geom_list:
            column_name = dict_i['map'][map_item]
            df =  get_geom_data(dict_i, self.gochart.core_data)
            value_series.append(df.select(column_name).to_series())
        if value_type == 'unique':
            return sorted(pl.concat(value_series).unique().to_list())
        elif value_type == 'range':
            concat_series = pl.concat(value_series)
            return [concat_series.min(), concat_series.max()]
        else:
            raise ValueError("value_type must be 'unique' or 'range'")

    def _get_axis_label(self, axis):
        """
        Get axis label for facet columns or rows.
        Returns a dictionary with axis label properties.
        """
        if axis not in ['x', 'y']:
            raise ValueError('Axis needs to be x or y')
        labels = []
        for dict_i in self.gochart.geom_list:
            labels.append( dict_i['map'][axis])
        return labels[0]

    def _get_axis_add_data_value(self, axis, axis_params, theme):
        if axis_params['limits'] is not None:
            dmin = axis_params['limits'][0]
            if len(axis_params['limits']) == 1:
                dmax = self._get_unique_values(axis, value_type='range')[1]
                range_ticks = get_ticks_position(dmin=dmin, dmax=dmax, number=axis_params['n_breaks'])
            elif len(axis_params['limits']) == 2:
                dmax = axis_params['limits'][1]
                range_ticks = get_ticks_position(dmin=dmin, dmax=dmax, number=axis_params['n_breaks'])
        else:
            range = self._get_unique_values(axis, value_type='range')
            range_ticks = get_ticks_position(dmin=range[0], 
                                             dmax=range[1], 
                                             number=5,
                                             extend_percent=axis_params['expand'][0],
                                             extend_value=axis_params['expand'][1])
        add_data = {
            'min': range_ticks['min'],
            'max': range_ticks['max'],
            'axisTick': {
                **get_theme_option(theme['ticks'][axis], 'lineStyle'),
                'customValues': range_ticks['ticks'],
                'alignWithLabel': True
            },
            'axisLabel': {
                **get_theme_option(theme['label'][axis]),
                'customValues': range_ticks['ticks']
            }
        }
        return add_data
    
    def _get_axis(self, axis, grid=None, matrix=None):
        """
        Get axis for facet columns or rows. Returns a list of dictionaries with axis properties.
        """
        if axis not in ['x', 'y']:
            raise ValueError('Axis needs to be x or y')
        axis_params = self.gochart.axis[axis]
        type = self._get_types(axis)
        # add axis name if provided
        if axis_params['name'] is not None:
            axis_name = axis_params['name']
        else:
            axis_name = self._get_axis_label(axis)
        
        theme = self.gochart.theme.theme['axis']
        axis_theme_options = {
            'axisLabel': get_theme_option(theme['label'][axis]),
            'axisTick': get_theme_option(theme['ticks'][axis], 'lineStyle'),
            'axisLine': get_theme_option(theme['line'][axis], 'lineStyle')
        }

        axis_options = {
            'type': type,
            **axis_theme_options
        }
        if get_theme_option(theme['title'][axis])['show']:
            axis_options['name'] = axis_name
            axis_options['nameLocation'] = 'middle'

        if type == 'value':
            add_data = self._get_axis_add_data_value(axis, axis_params, theme)
            axis_options.update(add_data)
        else:
            add_data = {'data': self._get_unique_values(axis)}
            axis_options.update(add_data)
        if grid is None and matrix is None:
            return axis_options
        if grid is not None:
            if self.gochart.facet['scales'] != 'fixed':
                raise NotImplementedError('Only fixed scales are implemented for now')
            else:
                axis = [{'gridIndex': i['id'], **axis_options} for i in grid]  
            return axis
        if matrix is not None:
            axis = [{'gridIndex': i['id'], **axis_options} for i in matrix]
            return axis


    @staticmethod
    def _get_geom_grid(grid_dict: dict[pl.DataFrame, dict],
                       df: pl.DataFrame,
                       dict_map: dict,
                       groupings: list[str]) -> dict:
        """
        Get grid DataFrame for geom series.
        Returns a Polars DataFrame with grid properties.
        """
        grid_axis = ['xAxisIndex', 'yAxisIndex']
        geom_facet_map = {k: v for k, v in grid_dict['facet_map'].items() if v in df.columns}
        geom_grid_df = grid_dict['grid_df'].select(grid_axis + list(geom_facet_map.keys()))
        if len(geom_facet_map) > 0:
            dict_map.update(geom_facet_map)
        # Create new columns based on standard_names mapping, allowing duplicates
        df = df.select([pl.col(v).alias(k) for k, v in dict_map.items()])
        df = df.join(geom_grid_df, how='left', on=list(geom_facet_map.keys()))
        to_group = [k for k in dict_map.keys() if k in groupings] + grid_axis
        return df, to_group

    @staticmethod
    def _get_geom_matrix(matrix_dict: dict[pl.DataFrame, dict],
                       df: pl.DataFrame,
                       dict_map: dict,
                       groupings: list[str]) -> dict:
        """
        Get grid DataFrame for geom series.
        Returns a Polars DataFrame with grid properties.
        """
        grid_axis = ['xAxisIndex', 'yAxisIndex']
        geom_facet_map = {k: [x for x in v if x in df.columns] for k, v in matrix_dict['facet_map'].items()}
        geom_facet_map = {k: v for k, v in geom_facet_map.items() if len(v) > 0}
        geom_facet_map0 = { k: {str(i):v for i, v in enumerate(vals)} for k, vals in geom_facet_map.items()}
        geom_grid_df = matrix_dict['grid_df'].select(grid_axis + list(geom_facet_map.keys()))
        to_join = []
        for i in list(geom_facet_map.keys()):
            geom_grid_df = geom_grid_df.unnest(i)
            geom_grid_df = geom_grid_df.rename({v: f'{i}{k}' for k, v in geom_facet_map0[i].items()})
            dict_map.update({f'{i}{k}':v for k, v in geom_facet_map0[i].items()})
            to_join.extend([f'{i}{k}' for k, v in geom_facet_map0[i].items()])
        # Create new columns based on standard_names mapping, allowing duplicates
        df = df.select([pl.col(v).alias(k) for k, v in dict_map.items()])
        df = df.join(geom_grid_df, how='left', on=to_join)
        to_group = [k for k in dict_map.keys() if k in groupings] + grid_axis
        return df, to_group


    def _get_aesthetics(self, map_item: str, aesthetics: Aesthetics = None):
        unique_values = self._get_unique_values(map_item, value_type='unique')
        if aesthetics is None:
            aesthetics = Aesthetics()
        unique_aes = getattr(aesthetics, map_item)
        aes = (unique_aes * ((len(unique_values) // len(unique_aes)) + 1))[:len(unique_values)]
        return pl.DataFrame({map_item: unique_values, f'{map_item}_aes': aes})

    def _get_series(self, grid: dict = None, matrix: dict = None):
        all_series = []
        aesthetics = Aesthetics()
        for dict_i in self.gochart.geom_list:
            geom_type = dict_i['type']
            series_map = self.gochart.valid_types_mapping[geom_type]
            df = get_geom_data(dict_i, self.gochart.core_data)
            dict_map = dict_i['map']
            # if grid is not None
            if grid is not None:
                df, to_group = self._get_geom_grid(grid, df, dict_map, self.gochart.grouping_mappings)
            elif matrix is not None:
                df, to_group = self._get_geom_matrix(matrix, df, dict_map, self.gochart.grouping_mappings)
            else:
                df = df.select([pl.col(v).alias(k) for k, v in dict_map.items()])
                to_group = [k for k in dict_map.keys() if k in self.gochart.grouping_mappings]

            if 'tooltip' in df.columns:
                df = (df
                    .with_columns(pl.concat_list(series_map).alias('value'))
                    .with_columns(pl.col('tooltip').cast(pl.Utf8))
                    .with_columns(pl.struct('value', 'tooltip').alias('data'))
                )
            else:
                df = df.with_columns(pl.concat_list(series_map).alias('data'))

            if len(to_group) != 0:
                series = (df
                    .group_by(to_group, maintain_order=True)
                    .agg(pl.col('data'))
                )
            else:
                series = (df.with_columns(pl.lit('all').alias('to_group'))
                    .group_by('to_group', maintain_order=True)
                    .agg(pl.col('data'))
                )

            series = series.with_columns(pl.lit(geom_type).alias('type'))
            for k, v in dict_i['params'].items():
                series = series.with_columns(pl.lit(v).alias(k))



            for aes in [i for i in series.columns if i in aesthetics.mapped]:
                if aes in series.columns:
                    df_color = self._get_aesthetics(aes, aesthetics)
                    series = (series.join(df_color, on=aes, how='left')
                              .drop(f'{aes}')
                              .rename({f'{aes}_aes': aesthetics.remap[aes]}))
                    
            all_series.extend(series.to_dicts())
        return all_series
    
    def _get_title(self):
        """
        Get title and subtitle for the chart.
        Returns a dictionary with title and subtitle.
        """
        title = {}
        if self.gochart.title is not None:
            title['text'] = self.gochart.title
            if self.gochart.subtitle is not None:
                title['subtext'] = self.gochart.subtitle
        return title

    def _get_options(self):
        options = {}
        options['title'] = [self._get_title()]
        if self.gochart.facet is not None:
            # grid = self._get_grid()s
            facet = Facet(gochart=self.gochart, width=self.width, height=self.height)
            grid = facet._get_grid()
            options['grid'] = FacetUtils._get_grid_options(grid)
            options['xAxis'] = self._get_axis('x', grid)
            options['yAxis'] = self._get_axis('y', grid)
            grid_series = FacetUtils._get_grid_for_series(grid, facet=self.gochart.facet)
            options['series'] = self._get_series(grid = grid_series)
            # add facet titles
            options['graphic'] = facet._get_facet_titles(grid)
        elif self.gochart.matrix is not None:
            go_matrix = Matrix(gochart=self.gochart, width=self.width, height=self.height)
            matrix, matrix_options = go_matrix._get_grid()
            options['matrix'] = matrix_options
            options['grid'] = GridUtils._get_matrix_grid_options(matrix)
            options['xAxis'] = self._get_axis('x', matrix=matrix)
            options['yAxis'] = self._get_axis('y', matrix=matrix)
            matrix_series = FacetUtils._get_grid_for_series(matrix, facet=self.gochart.matrix)
            options['series'] = self._get_series(matrix = matrix_series)

        else:
            options['xAxis'] = self._get_axis('x')
            options['yAxis'] = self._get_axis('y')
            options['series'] = self._get_series()
        options['tooltip'] = {}
        options['legend'] = {}
        return options