import polars as pl
from gocharts.GoChartClass import Chart
from gocharts.utils import percent_value, calculate_distance, get_geom_data, get_theme_option
from gocharts.GridUtils import GridUtils

class FacetUtils:
    @staticmethod
    def _get_grid_options(grid, percent=True) -> list[dict]:
        """
        Get grid options for facet columns or rows.
        Returns a list of dictionaries with grid properties.
        """
        opts = ['left', 'bottom', 'right', 'top', 'width', 'height']
        if percent:
            return [{k: str(v) + '%' for k, v in g.items() if k in opts} for g in grid]
        else:
            return [{k: v for k, v in g.items() if k in opts} for g in grid]
    
    @staticmethod
    def _get_facet_map(facet):
        """
        Get facet map for facet columns or rows.
        Returns a list of dictionaries with facet properties.
        """
        if facet is None:
            return None
        if facet['col'] is not None and facet['row'] is not None:
            return {'facet_col': facet['col'], 'facet_row': facet['row']}
        elif facet['col'] is not None:
            return {'facet_col': facet['col']}
        elif facet['row'] is not None:
            return {'facet_row': facet['row']}

    @staticmethod
    def _get_grid_for_series(grid: list[dict] = None, facet: dict = None) -> dict:
        """
        Get grid DataFrame for facet columns or rows.
        Returns a Polars DataFrame with grid properties.
        """
        grid_df = pl.DataFrame({k: [d[k] for d in grid] for k in grid[0].keys()})
        grid_df = grid_df.with_columns(
            pl.col('id').alias('xAxisIndex'),
            pl.col('id').alias('yAxisIndex')
        )
        return {'grid_df': grid_df, 'facet_map': FacetUtils._get_facet_map(facet)}

class Facet:
    """
    Facet class for handling chart faceting functionality.

    This class is intended to be used with a Chart object to provide
    faceting capabilities for visualizations.
    """
    def __init__(self, gochart: Chart, width: int, height: int):
        self.gochart = gochart
        self.width = width
        self.height = height

    def _get_grid_values(self, param: dict):
        """
        Get unique values for facet columns or rows.
        If there are two or more of the cols or rows it creates a permutations 
        of the values and combines them into a list of lists.
        """
        facet = self.gochart.facet
        if param in facet.keys() and facet[param] is not None:
            values = set()
            for geom in self.gochart.geom_list:
                df = get_geom_data(geom, self.gochart.core_data)
                if facet[param] not in df.columns:
                    continue
                else:
                    values_add = df[facet[param]].unique().to_list()
                    values.update(values_add)
            if len(values) > 0:
                return values
            else:
                return None
        return None


    def _get_grid(self) -> list[dict]:
        margins = self.gochart.theme.theme['grid']['margin']['margin']
        TITLE_MARGIN_ADJUSTMENT = 11  # Extra top margin to accommodate chart title
        if self.gochart.title is not None:
            margins['top'] += TITLE_MARGIN_ADJUSTMENT
        spacing = self.gochart.theme.theme['grid']['facet']['spacing']
        cols = self._get_grid_values('col')
        rows = self._get_grid_values('row')

        if cols is None and rows is None:
            raise ValueError('No columns or rows provided for facet in the data')

        if cols is not None and rows is not None:
            width = calculate_distance(margins['left'], margins['right'], spacing['cols'], len(cols))
            height = calculate_distance(margins['top'], margins['bottom'], spacing['rows'], len(rows))
            grids = [{'facet_col': c, 'facet_row': r} for c in cols for r in rows]
            position = []
            for c in range(len(cols)):
                for r in range(len(rows)):
                    position.append({
                        'x_axis_id': c,
                        'y_axis_id': r,
                        'left': margins['left'] + c * (width + spacing['cols']),
                        'top': margins['top'] + r * (height + spacing['rows']),
                        'width': width,
                        'height': height
                    })
            merged = [{**g, **p} for g, p in zip(grids, position)]
            merged = [{'id': i, **v} for i, v in enumerate(merged)]

        elif cols is not None:
            width = calculate_distance(margins['left'], margins['right'], spacing['cols'], len(cols))
            grids = [{'facet_col': c} for c in cols]
            position = [{
                'x_axis_id': i,
                'left': margins['left'] + i * (width + spacing['cols']),
                'width': width
            } for i in range(len(cols))]
            merged = [{**g, **p} for g, p in zip(grids, position)]
            merged = [{'id': i, **v} for i, v in enumerate(merged)]

        elif rows is not None:
            height = calculate_distance(margins['top'], margins['bottom'], spacing['rows'], len(rows))
            grids = [{'facet_row': r} for r in rows]
            position = [{
                'y_axis_id': i,
                'top': margins['top'] + i * (height + spacing['rows']),
                'height': height
            } for i in range(len(rows))]
            merged = [{**g, **p} for g, p in zip(grids, position)]
            merged = [{'id': i, **v} for i, v in enumerate(merged)]
        return merged

    @staticmethod
    def _facet_text_style(style_type):
        """Return style dictionary for facet text based on type."""
        common_style = {
            'fontSize': 16,
            'fontWeight': 'bold',
            'padding': 5,
            'color': '#909090',
        }
        border_style = {
            'borderColor': '#909090',
            'borderWidth': 0,
            'borderRadius': 3
        }
        if style_type == 'title':
            return {'textStyle': {**common_style}, **border_style}
        elif style_type == 'axis':
            return {'nameTextStyle': {**common_style, **border_style}}

    @staticmethod
    def _facet_text_style():
        """Return style dictionary for facet text."""
        return {
            'fontSize': 14,
            'fontWeight': 'bold',
            'fill': '#909090',
            'padding': 2
            }
    
    @staticmethod
    def _facet_box_style():
        """Return style dictionary for facet box."""
        return {
            'fill': '#f0f0f0',
            'stroke': '#909090',
            'lineWidth': 1,
        }

    def _get_facet_titles(self, grid: list[dict], percent=True) -> list[str]:
        """
        Get facet titles for facet columns.
        Returns a list of strings with facet titles and locations corresponding to the grid.
        """
        facet_height = 20
        facet_width = 20
        theme = self.gochart.theme.theme['facet']
        def get_top(g):
            return g['top'] if 'top' in g else 15
        def get_left(g):
            return g['left']+g['width'] if 'left' in g else 90
        if 'facet_col' in grid[0]:
            cols = [
                {
                    'type': 'group',
                    'left': percent_value(max(g['left'] for g in grid if g['facet_col'] == facet_col), percent),
                    'bottom': percent_value(100-min(get_top(g) for g in grid if g['facet_col'] == facet_col), percent),
                    'children': [
                        {
                            'type': 'rect',
                            'left': 'center',
                            'top': 'middle',
                            'shape': {'x': 0,
                                      'y': 0,
                                      'width': max(g['width'] for g in grid if g['facet_col'] == facet_col) * self.width/100,
                                      'height': facet_height,
                                      **get_theme_option(theme['box']['col'],select_keys=['r'])},
                            'style': get_theme_option(theme['box']['col'],remove_keys=['r'])
                        },
                        {
                            'type': 'text',
                            'left': 'center',
                            'top': 'middle',
                            'style': {'text': facet_col, **get_theme_option(theme['label']['col'])}
                        }]
                }
                for facet_col in {g['facet_col'] for g in grid}
            ]
            print(cols)
        else:
            cols = []

        if 'facet_row' in grid[0]:
            rows = [
                {
                    'type': 'group',
                    'left': percent_value(max((get_left(g)) for g in grid if g['facet_row'] == facet_row),percent),
                    'top': percent_value(max(g['top'] for g in grid if g['facet_row'] == facet_row),percent),
                    'children': [
                        {
                            'type': 'rect',
                            'left': 'center',
                            'top': 'middle',
                            'shape': {'x': 0,
                                      'y': 0,
                                      'width': facet_width,
                                      'height': max(g['height'] for g in grid if g['facet_row'] == facet_row) * self.height/100,
                                      **get_theme_option(theme['box']['row'],select_keys=['r'])},
                            'style': get_theme_option(theme['box']['row'],remove_keys=['r'])
                        },
                        {
                            'type': 'text',
                            'rotation':  -1.57079633,
                            'left': 'center',
                            'top': 'middle',
                            'style': {'text': facet_row, **get_theme_option(theme['label']['row'])}
                        }]
                }
                for facet_row in {g['facet_row'] for g in grid}
            ]

        else:
            rows = []
        blocks = cols + rows
        return blocks
