import polars as pl
import copy


class Grid:
    def __init__(self):
        self.margin = self.Margin()
        self.spacing = self.Spacing()
    class Margin:
        def __init__(self, top=7, right=7, bottom=7, left=7):
            self.top = top
            self.right = right
            self.bottom = bottom
            self.left = left
    class Spacing:
        def __init__(self, cols=7, rows=7):
            self.cols = cols
            self.rows = rows

def set_nested_value(d, keys, final_key, value):
    """
    Set a value in a nested dictionary given a list of keys.
    d: the dictionary
    keys: list of keys, e.g. ['axis', 'label', 'x']
    final_key: the key to set the value for, e.g. 'color'
    value: the value to set
    """
    for items in keys:
        current = d
        for key in items:
            current = current[key]
        current[final_key] = value
    return d


def is_valid_color(color: str) -> bool:
    if isinstance(color, str):
        if color.startswith("#") and len(color) in (4, 7):
            hex_digits = color[1:]
            return all(c in "0123456789abcdefABCDEF" for c in hex_digits)
    return False

def is_valid_font(font: str) -> bool:
    """
    Check if the font string is valid.
    For simplicity, we assume any non-empty string is a valid font.
    """
    return isinstance(font, str) and len(font) > 0

def is_valid_size(size: int) -> bool:
    """
    Check if the size is a valid integer greater than zero.
    """
    return isinstance(size, int) and size > 0

DEFINED_PARAMETERS = {'show', 'color', 'fill', 'stroke', 'font', 'size', 'lineWidth', 'r',
                      'cols', 'rows', 'top', 'right', 'bottom', 'left', 'EChartsOptions'}

def set_parameters_error():
    """
    Raise an error for invalid parameters.
    This function is a placeholder for future error handling logic.
    """
    raise ValueError("It's not possible to set parameters for this level of the theme.")
    

def set_parameters(theme: dict, path: dict, given: dict):
    """
    Set parameters in the theme dictionary based on the provided path.
    theme: the theme dictionary
    path: a dictionary mapping parameter names to their locations in the theme
    """
    if given.keys() - DEFINED_PARAMETERS:
        raise ValueError(f"Undefined parameters provided: {', '.join(given.keys() - DEFINED_PARAMETERS)}. "
                         f"Defined parameters are: {', '.join(DEFINED_PARAMETERS)}")
    if given.keys() - path.keys():
        raise ValueError(f"Invalid parameters provided: {', '.join(given.keys() - path.keys())}. "
                         f"Allowed parameters are: {', '.join(path.keys())}")
    for i in ['color','fill','stroke']:
        if i in given.keys() and i in path.keys():
            color_value = given.get(i)
            if not is_valid_color(color_value):
                raise ValueError(f"Invalid {i} string: {color_value}")
            theme = set_nested_value(theme, path[i], i, color_value)
    for i in ['r', 'lineWidth', 'cols', 'rows', 'top', 'right', 'bottom', 'left']:
        if i in given.keys() and i in path.keys():
            r_value = given.get(i)
            if not isinstance(r_value, (int, float)):
                raise ValueError(f"Invalid {i} value: {r_value}. It must be a number.")
            theme = set_nested_value(theme, path[i], i, r_value)
    if 'font' in given.keys() and 'font' in path.keys():
        font_value = given.get('font')
        if not is_valid_font(font_value):
            raise ValueError(f"Invalid font string: {font_value}")
        theme = set_nested_value(theme, path['font'], 'font', font_value)
    if 'size' in given.keys() and 'size' in path.keys():
        size_value = given.get('size')
        if not is_valid_size(size_value):
            raise ValueError(f"Invalid size: {size_value}")
        theme = set_nested_value(theme, path['size'], 'size', size_value)
    if 'show' in given.keys() and 'show' in path.keys():
        show_value = given.get('show')
        if not isinstance(show_value, bool):
            raise ValueError(f"Invalid show value: {show_value}. It must be a boolean.")
        theme = set_nested_value(theme, path['show'], 'show', show_value)
    if 'EChartsOptions' in given.keys() and 'EChartsOptions' in path.keys():
        echarts_value = given.get('EChartsOptions')
        if not isinstance(echarts_value, dict):
            raise ValueError(f"Invalid EChartsOptions: {echarts_value}. It must be a dictionary.")
        for key, value in echarts_value.items():
            theme = set_nested_value(theme, path['EChartsOptions'], key, value)
    return ThemeClass(theme)


class Margin:
    def __init__(self, top=7, right=7, bottom=7, left=7):
        self.top = top
        self.right = right
        self.bottom = bottom
        self.left = left
        
    def to_dict(self):
        dictionary = {k: v for k, v in self.__dict__.items() if not k.startswith('_') and not callable(v)}
        return dictionary
class Spacing:
    def __init__(self, cols=7, rows=7):
        self.cols = cols
        self.rows = rows

    def to_dict(self):
        dictionary = {k: v for k, v in self.__dict__.items() if not k.startswith('_') and not callable(v)}
        return dictionary
    
# Label component for theme, representing text labels (axis, facet, etc.)
class Label:
    def __init__(self,
                 show=True,
                 color=None,
                 fontStyle=None,
                 fontWeight=None,
                 fontSize=None,
                 EChartsOptions=None):
        self.show = show
        self.color = color
        self.fontStyle = fontStyle
        self.fontWeight = fontWeight
        self.fontSize = fontSize
        self.EChartsOptions = EChartsOptions
    
    def to_dict(self):
        # Convert all public attributes to a dictionary
        dictionary = {k: v for k, v in self.__dict__.items() if not k.startswith('_') and not callable(v)}
        return dictionary

# Line component for theme, representing lines (axis, ticks, etc.)
class Line:
    def __init__(self, show=True, color=None, width=None, EChartsOptions=None):
        self.color = color
        self.width = width
        self.show = show
        self.EChartsOptions = EChartsOptions
    
    def to_dict(self):
        dictionary = {k: v for k, v in self.__dict__.items() if not k.startswith('_') and not callable(v)}
        return dictionary

# Rectangle component for theme, representing boxes (facet, etc.)
class Rectangle:
    def __init__(self, show=True, fill='#ffffff', stroke='#000000', lineWidth=None, r=None, EChartsOptions=None):
        self.show = show
        self.fill = fill
        self.stroke = stroke
        self.lineWidth = lineWidth
        self.r = r
        self.EChartsOptions = EChartsOptions
    
    def to_dict(self):
        dictionary = {k: v for k, v in self.__dict__.items() if not k.startswith('_') and not callable(v)}
        return dictionary

class ThemeStructure:
    def __init__(self):
        self.structure = {
            'axis': {
                'title': {
                    'attributes': ['color', 'font', 'size', 'show', 'EChartsOptions'],
                    'x': 'Label',
                    'y': 'Label'
                },
                'label': {
                    'attributes': ['color', 'font', 'size', 'show', 'EChartsOptions'],
                    'x': 'Label',
                    'y': 'Label'
                },
                'ticks': {
                    'attributes': ['color', 'width', 'show', 'EChartsOptions'],
                    'x': 'Line',
                    'y': 'Line'
                },
                'line': {
                    'attributes': ['color', 'width', 'show', 'EChartsOptions'],
                    'x': 'Line',
                    'y': 'Line'
                }
            },
            'facet': {
                'label': {
                    'attributes': ['fontSize', 'fontWeight', 'fill', 'padding', 'EChartsOptions'],
                    'col': 'Label',
                    'row': 'Label'
                },
                'box': {
                    'attributes': ['fill', 'stroke', 'lineWidth', 'r', 'EChartsOptions'],
                    'col': 'Rectangle',
                    'row': 'Rectangle'
                }
            },
            'grid': {
                'margin': {
                    'attributes': ['top', 'right', 'bottom', 'left'],
                    'margin': 'Margin'
                },
                'facet': {
                    'attributes': ['cols', 'rows'],
                    'spacing': 'Spacing'
                }
            }
        }

def generate_theme_default() -> dict:
    """
    Generate a ThemeDefault-style nested dictionary from a ThemeStructure-style structure.
    Uses class names as strings to instantiate the correct component and call .to_dict().
    """
    # Map string names to actual classes
    component_map = {
        'Label': Label,
        'Line': Line,
        'Rectangle': Rectangle,
        'Margin': Margin,
        'Spacing': Spacing,
    }

    def build_node(node):
        if isinstance(node, dict):
            result = {}
            for k, v in node.items():
                if k == 'attributes':
                    continue  # skip attributes key
                result[k] = build_node(v)
            return result
        elif isinstance(node, str) and node in component_map:
            # Instantiate and convert to dict
            return component_map[node]().to_dict()
        else:
            return node

    return build_node(ThemeStructure().structure)

class ThemeDefault:
    def __init__(self):
        self.theme = generate_theme_default()

class ThemeComponent:
    def __init__(self, theme, path):
        self.theme = theme
        self.path = path

    def set(self, **kwargs):
        if self.path is None:
            return set_parameters_error()
        else:
            return set_parameters(self.theme, self.path, kwargs)

def get_path(d, parent_keys=None):
    if parent_keys is None:
        parent_keys = []
    items = []
    for k, v in d.items():
        new_keys = parent_keys + [k]
        if isinstance(v, dict):
            items.extend(get_path(v, new_keys))
        else:
            items.append(new_keys)
    return items


class ParentThemeComponent(ThemeComponent):
    def __init__(self, theme,
                 paths: list[list] = None,
                 attributes: list = None,
                 nodes: dict = {},
                 parents: list = None):
        parents = parents or []
        self.theme = theme
        self.path = paths
        self.theme = theme
        self.path = paths
        if paths is not None and attributes is not None:
            attr_path = {attr: paths for attr in attributes}
            super().__init__(theme, attr_path)
        if len(nodes) > 0:
            for key, item in nodes.items():
                parents_full = parents + [key]
                if isinstance(item, dict):
                    attributes = item.get('attributes', attributes)
                    nodes = {k: v for k, v in item.items() if k not in ['paths', 'attributes']}
                    paths = [parents_full + [x for x in sublist if x not in ('paths', 'attributes')] for sublist in get_path(nodes)]
                    setattr(self, key, ParentThemeComponent(theme=theme,
                                                            paths=paths,
                                                            attributes=attributes,
                                                            nodes=nodes,
                                                            parents=parents_full))
                else:
                    setattr(self, key, ParentThemeComponent(theme=theme, paths=[parents_full], attributes=attributes, parents=parents_full))


class ThemeClass:
    def __init__(self, theme=None):
        if theme is None:
            self.theme = ThemeDefault().theme
        else:
            self.theme = copy.deepcopy(theme)
        # self.grid = Grid()
        for param, value in ThemeStructure().structure.items():
            setattr(self,
                    param,
                    ParentThemeComponent(theme=self.theme,
                                         nodes=value,
                                         parents=[param]))

    def to_dict(self):
        return copy.deepcopy(self.theme)



# class Theme:
#     def __init__(
#         self,
#         background_color: str = "#ffffff",
#         grid_color: str = "#e0e0e0",
#         axis_color: str = "#333333",
#         axis_label_color: str = "#333333",
#         title_color: str = "#222222",
#         font: str = "Arial",
#         font_size: int = 12,
#         legend_background: str = "#f9f9f9",
#         legend_border: str = "#cccccc",
#         palette: list = None
#     ):
#         self.background_color = background_color
#         self.grid_color = grid_color
#         self.axis_color = axis_color
#         self.axis_label_color = axis_label_color
#         self.title_color = title_color
#         self.font = font
#         self.font_size = font_size
#         self.legend_background = legend_background
#         self.legend_border = legend_border
#         self.palette = palette or [
#             "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
#             "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
#             "#bcbd22", "#17becf"
#         ]
#         self.grid = Grid()
#         self.axis = Axis()
#         # self.facet = Facet()

