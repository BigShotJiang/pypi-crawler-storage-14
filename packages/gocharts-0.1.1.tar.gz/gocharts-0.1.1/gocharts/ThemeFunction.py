# This file is auto-generated. Do not edit manually.
from gocharts.ThemeClass import ThemeClass
class Theme:
   """
   Configures the theme properties for the chart.

   Methods:

      Theme_axis_title: color, font, size, show, EChartsOptions
      Theme_axis_title_x: color, font, size, show, EChartsOptions
      Theme_axis_title_y: color, font, size, show, EChartsOptions
      Theme_axis_label: color, font, size, show, EChartsOptions
      Theme_axis_label_x: color, font, size, show, EChartsOptions
      Theme_axis_label_y: color, font, size, show, EChartsOptions
      Theme_axis_ticks: color, width, show, EChartsOptions
      Theme_axis_ticks_x: color, width, show, EChartsOptions
      Theme_axis_ticks_y: color, width, show, EChartsOptions
      Theme_axis_line: color, width, show, EChartsOptions
      Theme_axis_line_x: color, width, show, EChartsOptions
      Theme_axis_line_y: color, width, show, EChartsOptions
      Theme_facet_label: fontSize, fontWeight, fill, padding, EChartsOptions
      Theme_facet_label_col: fontSize, fontWeight, fill, padding, EChartsOptions
      Theme_facet_label_row: fontSize, fontWeight, fill, padding, EChartsOptions
      Theme_facet_box: fill, stroke, lineWidth, r, EChartsOptions
      Theme_facet_box_col: fill, stroke, lineWidth, r, EChartsOptions
      Theme_facet_box_row: fill, stroke, lineWidth, r, EChartsOptions
      Theme_grid_margin: top, right, bottom, left
      Theme_grid_margin_margin: top, right, bottom, left
      Theme_grid_facet: cols, rows
      Theme_grid_facet_spacing: cols, rows
   """
   def __init__(self):
      self.theme = ThemeClass()

   def axis_title(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         font:
         size:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.title.set(**kwargs)
      return self
   def axis_title_x(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         font:
         size:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.title.x.set(**kwargs)
      return self
   def axis_title_y(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         font:
         size:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.title.y.set(**kwargs)
      return self
   def axis_label(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         font:
         size:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.label.set(**kwargs)
      return self
   def axis_label_x(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         font:
         size:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.label.x.set(**kwargs)
      return self
   def axis_label_y(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         font:
         size:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.label.y.set(**kwargs)
      return self
   def axis_ticks(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         width:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.ticks.set(**kwargs)
      return self
   def axis_ticks_x(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         width:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.ticks.x.set(**kwargs)
      return self
   def axis_ticks_y(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         width:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.ticks.y.set(**kwargs)
      return self
   def axis_line(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         width:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.line.set(**kwargs)
      return self
   def axis_line_x(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         width:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.line.x.set(**kwargs)
      return self
   def axis_line_y(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         color:
         width:
         show:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.axis.line.y.set(**kwargs)
      return self
   def facet_label(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         fontSize:
         fontWeight:
         fill:
         padding:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.facet.label.set(**kwargs)
      return self
   def facet_label_col(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         fontSize:
         fontWeight:
         fill:
         padding:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.facet.label.col.set(**kwargs)
      return self
   def facet_label_row(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         fontSize:
         fontWeight:
         fill:
         padding:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.facet.label.row.set(**kwargs)
      return self
   def facet_box(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         fill:
         stroke:
         lineWidth:
         r:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.facet.box.set(**kwargs)
      return self
   def facet_box_col(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         fill:
         stroke:
         lineWidth:
         r:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.facet.box.col.set(**kwargs)
      return self
   def facet_box_row(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         fill:
         stroke:
         lineWidth:
         r:
         EChartsOptions:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.facet.box.row.set(**kwargs)
      return self
   def grid_margin(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         top:
         right:
         bottom:
         left:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.grid.margin.set(**kwargs)
      return self
   def grid_margin_margin(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         top:
         right:
         bottom:
         left:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.grid.margin.margin.set(**kwargs)
      return self
   def grid_facet(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         cols:
         rows:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.grid.facet.set(**kwargs)
      return self
   def grid_facet_spacing(self, **kwargs):
      """
      Configures the theme properties for the chart.
      Args:
         cols:
         rows:
      Returns:
         self: Returns the instance with updated axis label settings.
      """

      self.theme = self.theme.grid.facet.spacing.set(**kwargs)
      return self

   def to_dict(self):
      return self.theme.to_dict()