class Aesthetics:
    def __init__(self):
        self.color = [
            '#1f77b4', '#ff7f0e', '#2ca02c',
            '#d62728', '#9467bd', '#8c564b',
            '#e377c2', '#7f7f7f', '#bcbd22',
            '#17becf']
        self.fill = self.color
        self.shape = ['circle', 'square', 'triangle', 'diamond', 'cross', 'x']
        self.mapped = ['color', 'fill', 'shape']
        self.remap = {
            'shape': 'symbol',
            'color': 'color',
            'fill': 'fill',
        }