def percent_value(value: float, percent: bool) -> str | float:
    return f"{value}%" if percent else value

def calculate_distance(margin_1, margin_2, spacing, length):
    distance = (100 - margin_1 - margin_2 - (length - 1) * spacing) / length
    if distance < 0:
        raise ValueError('Facet columns/rows are too many to fit in the chart width')
    return distance

def get_geom_data(geom, core_data):
# Verify that geom['data'] is a string before returning
    if isinstance(geom['data'], str):
        if geom['data'] == 'core_data':
            if core_data is None:
                raise ValueError("core_data is not provided.")
            return core_data
        else:
            raise ValueError(f"Invalid data source: {geom['data']}. Expected 'core_data' or a DataFrame.")
    else:
        return geom['data']
    
def get_theme_option(item: dict, style_name: str = None,
                      select_keys: list[str] = None, 
                      remove_keys: list[str] = None) -> dict:
    if style_name is None:
        if select_keys is not None:
            theme_options = {k: v for k, v in item.items() if k in select_keys and v is not None}
        elif remove_keys is not None:
            theme_options = {k: v for k, v in item.items() if k not in remove_keys and v is not None}
        else:
            # If no style_name or select_keys/remove_keys are provided, return all non-None items
            theme_options = {k: v for k, v in item.items() if v is not None}
    else:
        theme_options = {
            'show': item.get('show', True),
            style_name: {k: v 
                         for k, v in item.items() 
                         if k != 'show' and v is not None
                         }
    }
    return theme_options

