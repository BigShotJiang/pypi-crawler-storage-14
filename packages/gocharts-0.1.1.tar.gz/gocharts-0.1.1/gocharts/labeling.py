import math
import numpy as np

def get_ticks_position(dmin, dmax,
                       number=5,
                       extend_percent=None,
                       extend_value=None,
                       limits=None,
                       label=None):
    if number <= 0:
        raise ValueError("Number of ticks must be positive")
    if dmin >= dmax: 
        raise ValueError("Minimum value must be less than maximum value")
    if extend_percent is not None and (extend_percent > 0 and extend_percent < 1):
        dmin = dmin - (dmax - dmin) * extend_percent
        dmax = dmax + (dmax - dmin) * extend_percent
    if extend_value is not None:
        dmin -= extend_value
        dmax += extend_value
    if limits is not None and len(limits) == 2:
        if limits[0] >= limits[1]:
            raise ValueError("Limits must be a tuple with min < max")
        dmin = limits[0]
        dmax = limits[1]

    # Calculate the tick positions
    tick_positions = get_pretty_numbers(dmin, dmax, n_breaks=number)
    return {'min': dmin, 'max': dmax, 'ticks': tick_positions}

def round_ticks(ticks, step):
    if step <= 0:
        return ticks.tolist()
    exp = math.floor(math.log10(step))
    exp = math.floor(math.log10(step))
    decimal_places = max(0, -exp)
    return [round(float(t), decimal_places) for t in ticks]
def get_scientific(x):
    if x == 0:
        return (0, 0)
    exponent = math.floor(math.log10(abs(x)))
    value = x / (10 ** exponent)
    return value, exponent

def get_pretty_numbers(dmin, dmax, n_breaks=5, pretty_numbers=[1, 5, 2, 2.5, 4, 3, 10]):
    pretty_numbers0 = pretty_numbers + [0]
    diff = dmax - dmin
    diff_c, diff_p = get_scientific(diff / n_breaks)
    min_max_p = max(get_scientific(dmin)[1], get_scientific(dmax)[1])

    # Find best pretty number
    pretty_number_use = min(pretty_numbers, key=lambda pn: abs(diff_c - pn))
    step = pretty_number_use * (10 ** diff_p)
    # Start tick
    dmin_scaled = abs(dmin / (10 ** min_max_p))
    pretty_number_start = np.sign(dmin) * min(pretty_numbers0, key=lambda pn: abs(dmin_scaled - pn)) * (10 ** min_max_p)
    if pretty_number_start > dmax:
        pretty_number_start -= pretty_number_use

    breaks_start = np.arange(pretty_number_start, dmax + step, step)
    breaks_start = round_ticks(breaks_start, step)
    # End tick
    dmax_scaled = abs(dmax / (10 ** min_max_p))
    pretty_number_end = np.sign(dmax) * min(pretty_numbers0, key=lambda pn: abs(dmax_scaled - pn)) * (10 ** min_max_p)
    if pretty_number_end < dmin:
        pretty_number_end += pretty_number_use

    breaks_end = -np.flip(np.arange(-pretty_number_end, -dmin + step, step))
    breaks_end = round_ticks(breaks_end, step)
    # Coverage
    def coverage(breaks):
        return min(breaks) - dmin + dmax - max(breaks) if len(breaks) > 0 else float('inf')

    if coverage(breaks_start) < coverage(breaks_end):
        return breaks_start
    else:
        return breaks_end


# Example usage:
# print(get_pretty_numbers(-100, 1320, n_breaks=6))
# Example usage:
# print(get_pretty_numbers(-100, 1320, n_breaks=6))
# print(get_pretty_numbers(0, 0.003, n_breaks=6))
# print(get_pretty_numbers(100, 130, n_breaks=6))