import numpy as np
import pandas as pd
import polars as pl
import json

# display related
import time # for unique id generation

from gocharts.ThemeFunction import Theme
from gocharts.ThemeClass import ThemeClass
from gocharts.Display import Display
from gocharts.ChartExporter import ChartExporter
from gocharts.Generator import Generator
from gocharts.GoChartClass import Chart
# main class for GoChart
__version__ = '0.1.0'
__author__ = 'Edvinas Drevinskas'
__license__ = 'GPL-3.0-or-later'
__all__ = ['GoChart','Theme']

class GoChart:
    """
    GoChart is the main class for creating and configuring charts using the gocharts library.

    This class provides a high-level API for mapping data columns to chart attributes, adding geometric layers,
    faceting, theming, displaying, and exporting charts. It supports data input as pandas DataFrame, numpy ndarray,
    or polars DataFrame, and allows flexible mapping and customization of chart elements.

    Attributes:
        chart (Chart): The underlying Chart object that stores chart configuration and data.

    Methods:
        __init__(data=None, map: dict=None):
            Initializes the GoChart object with optional data and mapping.
        map(**kwargs):
            Maps data columns to chart attributes.
        title(title: str, subtitle: str = None):
            Sets the main title and optional subtitle for the chart.
        geom(type: str, **kwargs):
            Adds a geometric layer to the chart.
        facet(col: str = None, row: str = None, scales: str = 'fixed', space: float = 0.1):
            Configures faceting for the chart.
        theme(**kwargs):
            Configures the chart theme (not implemented).
        display(width='600px', height='400px'):
            Displays the chart in a notebook environment.
        display_test():
            Displays a test chart (for development).
        save(type: str = 'html', file_name, width='600px', height='400px'):
            Saves the chart in the specified format.
    """
    def __init__(self, data = None, map: dict = None):
        """
        Initializes the object with optional data and mapping.
        Args:
            data (optional): The input data to be used for the chart. Can be any format supported by _verify_data and _data_converter.
            map (dict, optional): A dictionary specifying the mapping of data fields to chart elements.
        Raises:
            ValueError: If the provided data does not pass verification.
        """

        if data is not None:
            self._verify_data(data)
            data = self._data_converter(data)
        self.chart = Chart(data, map)
        self = self.axis('x')
        self = self.axis('y')
    
    def _verify_data(self,data):
        if not isinstance(data, (pd.DataFrame, np.ndarray, pl.DataFrame)):
            raise TypeError("data must be a pandas, polars DataFrame or numpy ndarray")

    def _data_converter(self,df):
        if isinstance(df, pd.DataFrame):
            df = pl.from_pandas(df)
        if isinstance(df, np.ndarray):
            df = pl.from_numpy(df)
        return df
    
    def _convert_type(self,type: str):
        if type == 'point':
            type = 'scatter'
        elif type == 'tile':
            type = 'heatmap'
        self.chart._verify_type(type)
        return type

    def _convert_string_list(self, value: str | list[str]) -> list[str]:
        if value is not None:
            if isinstance(value, str):
                value = [value]
        return value
    
    def _verify_string(self, values: str):
        if not isinstance(values, str):
            raise TypeError(f"Expected a string, but got {type(values).__name__}")
        if len(values) == 0:
            raise ValueError("String cannot be empty")
        return values

    def _verify_string_list(self, values: list[str]):
        if not isinstance(values, list):
            raise TypeError(f"Expected a list, but got {type(values).__name__}")
        for v in values:
            self._verify_string(v)
        return values
    
    def map(self,**kwargs):
        """
        Maps data columns to chart attributes.
        This method allows you to specify how your data columns should be mapped to the chart's visual attributes
        (such as x, y, color, etc.) by passing keyword arguments. It verifies the provided mapping and updates
        the chart's core mapping accordingly.
        Args:
            **kwargs: Arbitrary keyword arguments where the key is the chart attribute (e.g., 'x', 'y', 'color')
                      and the value is the corresponding data column name.
        Returns:
            self: Returns the current instance to allow method chaining.
        Raises:
            ValueError: If the provided mapping is invalid or does not match the data.
        """

        # it might override map given in the parameter of the class
        self.chart._verify_mapping(mapping=kwargs)
        if self.chart.core_data is not None:
            self.chart._verify_data_mapping(self.chart.core_data,kwargs)
        self.chart.core_map = kwargs
        return self
    
    def title(self, title: str, subtitle: str = None):
        """
        Sets the main title and optional subtitle for the chart.
        Args:
            title (str): The main title of the chart.
            subtitle (str, optional): The subtitle of the chart. Defaults to None.
        Returns:
            self: Returns the instance to allow method chaining.
        """

        if not isinstance(title, str):
            raise TypeError("Title must be a string")
        if subtitle is not None and not isinstance(subtitle, str):
            raise TypeError("Subtitle must be a string")
        self.chart.title = title
        self.chart.subtitle = subtitle
        return self

    def geom(self,type: str,**kwargs):
        """
        Adds a geometric layer to the chart with the specified type and mapping.
        Parameters:
            type (str): The type of geometric layer to add (e.g., 'bar', 'line', etc.).
            **kwargs: Additional keyword arguments:
                - map (dict, optional): A mapping of data columns to aesthetic attributes. 
                  If not provided, uses the chart's core map intialised by map.
                - data (DataFrame, optional): The data to use for this geometric layer. 
                  If not provided, uses the chart's core data intialised by creating GoChart.
        Returns:
            self: Returns the chart object to allow method chaining.
        Raises:
            ValueError: If the provided data is invalid or if the type mapping is incorrect.
        Notes:
            - The method updates the chart's geom_list with the new geometric layer.
            - Data is verified and converted as needed before adding the layer.
        """
        params = {}
        type = self._convert_type(type)

        if 'map' in kwargs.keys():
            map = kwargs['map']
        else:
            map = self.chart.core_map

        if 'data' in kwargs.keys():
            df = kwargs['data']
            self._verify_data(df)
            df = self._data_converter(df)
            map_types = self.chart._create_map_types(df,map)
            data = df
        else:
            df = self.chart.core_data
            map_types = self.chart._create_map_types(df,map)
            data = 'core_data'

        self.chart._verify_type_mapping(type, map)


        if 'symbol' in kwargs.keys():
            symbol = kwargs['symbol']
            if not isinstance(symbol, str):
                raise TypeError("Symbol must be a string")
            if symbol not in ['circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow', 'none', 'emptyCircle']:
                raise ValueError('Symbol must be one of "circle", "rect", "roundRect", "triangle", "diamond", "pin", "arrow", "none", "emptyCircle"')
            params['symbol'] = symbol

        if 'symbolSize' in kwargs.keys():
            symbolSize = kwargs['symbolSize']
            if not isinstance(symbolSize, (int, float)):
                raise TypeError("Symbol size must be a number")
            params['symbolSize'] = symbolSize

        self.chart.geom_list = self.chart.geom_list + [{'type':type, 'map':map, 'data':data, 'map_types':map_types, 'params':params}]
        return self
    


    def axis(self,
             axis: str = None, # axis can be 'x', 'y'
             type: str = None, # type can be 'category', 'value', 'time', 'log'
             name: str = None,
             n_breaks: int = 5,
             breaks: list = None,
             minor_breaks: list = None,
             breaks_labels: list = None,
             limits: list = None,
             expand: list = [0.05, 0],
             inverse: bool = False
               ):
        """
        Configure the axis for the chart.
        Parameters:
            axis (str, optional): The axis to configure ('x' or 'y'). Defaults to None.
            type (str, optional): The type of the axis ('category', 'value', 'time', 'log'). Defaults to None.
            name (str, optional): The name of the axis. Defaults to None.
            breaks (list, optional): The positions of the major ticks. Defaults to None.
            minor_breaks (list, optional): The positions of the minor ticks. Defaults to None.
            breaks_labels (list, optional): Labels for the major ticks. Defaults to None.
            limits (list, optional): Limits for the axis range. Defaults to None.
            expand (list, optional): Expansion factor for the axis range. Defaults to None.
            inverse (bool, optional): Whether to invert the axis. Defaults to False.
        Returns:
            self: Returns the chart object with updated axis configuration for method chaining.
        Raises:
            ValueError: If the axis type is not recognized or if the axis is not specified.
        """
        if axis is None:
            raise ValueError('Axis must be specified as "x" or "y"')
        if axis not in ['x', 'y']:
            raise ValueError('Axis must be either "x" or "y"')
        if type is not None:
            if type not in ['category', 'value', 'time', 'log']:
                raise ValueError('Axis type must be either "category", "value", "time" or "log"')
        if breaks is not None and not isinstance(breaks, list):
            raise TypeError('Breaks must be a list')
        if minor_breaks is not None and not isinstance(minor_breaks, list):
            raise TypeError('Minor breaks must be a list')
        if breaks_labels is not None and not isinstance(breaks_labels, list):       
            raise TypeError('Breaks labels must be a list')
        if limits is not None and not isinstance(limits, list):
            raise TypeError('Limits must be a list')
        if expand is not None and not isinstance(expand, list):
            raise TypeError('Expand must be a list')
        
        self.chart.axis[axis] = {
            'type': type,
            'name': name,
            'n_breaks': n_breaks,
            'breaks': breaks,
            'minor_breaks': minor_breaks,
            'breaks_labels': breaks_labels,
            'limits': limits,
            'expand': expand,
            'inverse': inverse
        }
        return self
 
    def matrix(self,
             col: list[str] = None,
             row: list[str] = None
               ):
        """
        Configure the matrix for the chart.
        Parameters:
            col (list[str], optional): List of columns to display matrix lines for. Defaults to None.
            row (list[str], optional): List of rows to display matrix lines for. Defaults to None.
        """
        matrix = {}
        if col is not None:
            col = self._convert_string_list(col)
            self._verify_string_list(col)
            matrix['col'] = col
        if row is not None:
            row = self._convert_string_list(row)
            self._verify_string_list(row)
            matrix['row'] = row
        self.chart.matrix = matrix
        return self

    def facet(self,
              col: str = None,
              row: str = None, 
              scales: str = 'fixed', space: float = 0.1):
        """
        Configure faceting for the chart by splitting data into subplots based on column and/or row variables.
        Parameters:
            col (str, optional): The name of the column variable to facet by. Defaults to None.
            row (str, optional): The name of the row variable to facet by. Defaults to None.
            scales (str, optional): Determines how axis scales are shared across facets. 
                Must be one of 'fixed', 'free', 'free_x', or 'free_y'. Defaults to 'fixed'.
            space (float, optional): The relative spacing between facets, between 0 and 1. Defaults to 0.1.
        Returns:
            self: Returns the chart object with updated faceting configuration for method chaining.
        """
        
        facet = {}
        if col is None and row is None:
            raise ValueError('At least one of col or row must be provided')
        
        if col is not None:
            self._verify_string(col)
        if row is not None:
            self._verify_string(row)
            
        facet['col'] = col
        facet['row'] = row

        if scales is not None:  
            if scales not in ['free', 'fixed', 'free_x', 'free_y']:
                raise ValueError('Scales must be either "free", "fixed", "free_x" or "free_y"')
            facet['scales'] = scales
        if space is not None:
            if not isinstance(space, (int, float)):
                raise TypeError('Space must be a number')
            if space < 0 or space > 1:
                raise ValueError('Space must be between 0 and 1')
            facet['space'] = space
        self.chart.facet = facet
        return self

    def theme(self, theme: Theme = None):
        """
        Configure the theme for the chart.
        Example usage:
            gochart = (goc.GoChart(df)
                .map(x='Category',y='Value', color='Subgroup')
                .geom('bar')
                .facet(col = 'Subgroup', row = 'Category')
                .theme(goc.Theme()
                    .axis.title.set(color = '#0000ff')
                    .axis.ticks.set(color = '#ff0000')
                    .facet.text.set(font = 'Arial', size = 12)
                    .facet.text.col.set(color = '#00ff00')
                    .facet.text.row.set(color = '#ff0000')
                )
            )
        """
        self.chart.theme = theme.theme
        return self
    
    def display(self, width='600px', height='400px'):
        """
        Displays the chart in a notebook environment with the specified width and height.
        Args:
            width (str, optional): The width of the chart display area. Defaults to '600px'.
            height (str, optional): The height of the chart display area. Defaults to '400px'.
        Returns:
            None
        """
        width_numeric = int(width.replace('px', '').replace('%', ''))
        height_numeric = int(height.replace('px', '').replace('%', ''))
        id = 'chart_'+str(round(time.time()*100000))
        Display.display_nootbook(json.dumps(
            Generator(self.chart,
                      width=width_numeric,
                      height=height_numeric)._get_options()),
                                 id,
                                 width,
                                 height)

    def display_test(self):
        Display.display_nootbook_test()

    def print(self, width='600px', height='400px'):
        """
        Returns the chart data as a text string.
        """

        width_numeric = int(width.replace('px', '').replace('%', ''))
        height_numeric = int(height.replace('px', '').replace('%', ''))
        options = json.dumps(Generator(self.chart,
                                       width=width_numeric,
                                       height=height_numeric
                                       )._get_options())
        return ChartExporter.save_text(options)

    def save(self, file_name, type: str = 'html', width='600px', height='400px'):
        """
        Saves the chart in the specified format.
        Args:
            type (str, optional): The format to save the chart in. 
                Must be either 'html' or 'text'. Defaults to 'html'.
            file_name (str): The name of the file to save the chart to (used for 'html' type).
            width (str, optional): The width of the chart (applies to 'html' type). Defaults to '600px'.
            height (str, optional): The height of the chart (applies to 'html' type). Defaults to '400px'.
        Returns:
            str: The chart options as a text string if type is 'text'.
        Raises:
            ValueError: If the type is not 'text' or 'html'.
        """

        width_numeric = int(width.replace('px', '').replace('%', ''))
        height_numeric = int(height.replace('px', '').replace('%', ''))
        id = 'chart_'+str(round(time.time()*100000))
        options = json.dumps(Generator(self.chart,
                                       width=width_numeric,
                                       height=height_numeric
                                       )._get_options())
        if type == 'text':
            return ChartExporter.save_text(options)
        elif type == 'html':
            ChartExporter.save_html(options, file_name, height, width, id)
        else:
            raise ValueError('Type must be either "text" or "html"')

