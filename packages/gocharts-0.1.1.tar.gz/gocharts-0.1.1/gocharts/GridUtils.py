import polars as pl
from gocharts.GoChartClass import Chart
from gocharts.utils import percent_value, calculate_distance, get_geom_data, get_theme_option

class GridUtils:
    @staticmethod
    def _get_facet_grid_options(grid, percent=True) -> list[dict]:
        """
        Get grid options for facet columns or rows.
        Returns a list of dictionaries with grid properties.
        """
        opts = ['left', 'bottom', 'right', 'top', 'width', 'height']
        if percent:
            return [{k: str(v) + '%' for k, v in g.items() if k in opts} for g in grid]
        else:
            return [{k: v for k, v in g.items() if k in opts} for g in grid]
    
    @staticmethod
    def _get_matrix_grid_options(matrix) -> list[dict]:
        """
        Get matrix options for facet columns or rows.
        Returns a list of dictionaries with matrix properties.
        """
        
        return [{'id': g['id'],
                'coordinateSystem': 'matrix',
                'coord': [g['x_axis_id'], g['y_axis_id']] } for g in matrix ]
    
    @staticmethod
    def _get_facet_map(facet):
        """
        Get facet map for facet columns or rows.
        Returns a list of dictionaries with facet properties.
        """
        if facet is None:
            return None
        if facet['col'] is not None and facet['row'] is not None:
            return {'facet_col': facet['col'], 'facet_row': facet['row']}
        elif facet['col'] is not None:
            return {'facet_col': facet['col']}
        elif facet['row'] is not None:
            return {'facet_row': facet['row']}

    @staticmethod
    def _get_grid_for_series(grid: list[dict] = None, facet: dict = None) -> dict:
        """
        Get grid DataFrame for facet columns or rows.
        Returns a Polars DataFrame with grid properties.
        """
        grid_df = pl.DataFrame({k: [d[k] for d in grid] for k in grid[0].keys()})
        grid_df = grid_df.with_columns(
            pl.col('id').alias('xAxisIndex'),
            pl.col('id').alias('yAxisIndex')
        )
        return {'grid_df': grid_df, 'facet_map': GridUtils._get_facet_map(facet)}
    
    @staticmethod
    def _get_grid_values(gochart: Chart, param: dict):
        """
        Get unique values for facet columns or rows.
        If there are two or more of the cols or rows it creates a permutations 
        of the values and combines them into a list of lists.
        """
        facet = gochart.facet
        if param in facet.keys() and facet[param] is not None:
            values = set()
            for geom in gochart.geom_list:
                df = get_geom_data(geom, gochart.core_data)
                if facet[param] not in df.columns:
                    continue
                else:
                    values_add = df[facet[param]].unique().to_list()
                    values.update(values_add)
            if len(values) > 0:
                return values
            else:
                return None
        return None