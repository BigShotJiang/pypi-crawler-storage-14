import inspect
from pathlib import Path
from ThemeClass import ThemeStructure

def generate_nested_docstring(lines: list, component: str, config: dict, parents: list):
    tab = '   '
    parents = parents + [component]
    if 'attributes' in config:
        f_name = f"{'_'.join(parents)}"
        f_attributes = f"{', '.join(config['attributes'])}"
        lines.append(f"{tab*2}{f_name}: {f_attributes}")
        for key, value in {k: v for k, v in config.items() if k != 'attributes'}.items():
            f_name = f"{'_'.join(parents+[key])}"
            lines.append(f"{tab*2}{f_name}: {f_attributes}")
    for key, value in config.items():
        if isinstance(value, dict):
            lines = generate_nested_docstring(lines, key, value, parents)
    return lines


def generate_nested_function(lines: list, component: str, config: dict, parents: list):
    tab = '   '
    if component == 'Theme':
        lines.append('class Theme:')
        lines.append(f"{tab}\"\"\"")
        lines.append(f"{tab}Configures the theme properties for the chart.\n")
        lines.append(f"{tab}Methods:\n")
        lines = generate_nested_docstring(lines, component, config, [])
        lines.append(f"{tab}\"\"\"")
        lines.append(f'{tab}def __init__(self):')
        lines.append(f'{tab * 2}self.theme = ThemeClass()\n')
    else:
        parents = parents + [component]
    if 'attributes' in config:
        nl = '\n'
        docstring = (
            f"{tab * 2}\"\"\"\n" +
            f"{tab * 2}Configures the theme properties for the chart.\n" +
            f"{tab * 2}Args:\n" +
            f"{nl.join([f'{tab * 3}{attr}:' for attr in config['attributes']])}\n" +
            f"{tab * 2}Returns:\n" +
            f"{tab * 3}self: Returns the instance with updated axis label settings.\n" +
            f"{tab * 2}\"\"\"\n")
        f_name = f"{tab}def {'_'.join(parents)}"
        # attributes = ', '.join(config.get('attributes', []))
        f_attributes = f"(self, **kwargs):"
        f_call = f"{tab*2}self.theme = self.theme.{'.'.join(parents)}.set(**kwargs)"
        f_return = f"{tab*2}return self"
        lines.append(f_name+f_attributes)
        lines.append(f"{docstring}")
        lines.append(f_call)
        lines.append(f_return)
        for key, value in {k: v for k, v in config.items() if k != 'attributes'}.items():
            f_name = f"{tab}def {'_'.join(parents+[key])}"
            f_call = f"{tab*2}self.theme = self.theme.{'.'.join(parents)}.{key}.set(**kwargs)"
            lines.append(f_name+f_attributes)
            lines.append(f"{docstring}")
            lines.append(f_call)
            lines.append(f_return)

    for key, value in config.items():
        if isinstance(value, dict):
            lines = generate_nested_function(lines, key, value, parents)
    return lines


def generate_stub_py():
    tab = '   '
    structure = ThemeStructure().structure
    lines = ['# This file is auto-generated. Do not edit manually.']
    lines.append('from gocharts.ThemeClass import ThemeClass')
    lines = generate_nested_function(lines, 'Theme', structure, [])
    lines.append(f'\n{tab}def to_dict(self):')
    lines.append(f"{tab*2}return self.theme.to_dict()")
    Path("gocharts/ThemeFunction.py").write_text("\n".join(lines))


generate_stub_py()