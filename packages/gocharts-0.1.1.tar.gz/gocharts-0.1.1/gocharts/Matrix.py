import polars as pl
from gocharts.GoChartClass import Chart
from gocharts.utils import percent_value, calculate_distance, get_geom_data, get_theme_option

class Matrix:
    """
    Matrix class for handling chart grid functionality.

    This class is intended to be used with a Chart object to provide
    grid capabilities which are based on Echarts matrix implementation.
    """

    def __init__(self, gochart: Chart, width: int, height: int):
        self.gochart = gochart
        self.width = width
        self.height = height

    def _get_grid_values(self, param: dict):
        """
        Get unique values for facet columns or rows.
        If there are two or more of the cols or rows it creates a permutations 
        of the values and combines them into a list of lists.
        """
        grid_params = self.gochart.matrix
        if param in grid_params.keys() and grid_params[param] is not None:
            values = pl.DataFrame()
            for geom in self.gochart.geom_list:
                df = get_geom_data(geom, self.gochart.core_data)
                if not any(x in df.columns for x in grid_params[param]):
                    continue
                else:
                    cols_use = [c for c in grid_params[param] if c in df.columns]
                    values_add = df.select(cols_use).unique()
                    values = pl.concat([values, values_add])
            if len(values) > 0:
                values_col = [c for c in grid_params[param] if c in values.columns]
                sorted_df = values.select(values_col).sort(by=values_col)          # sorts by col1, then col2, ...
                sorted_df = sorted_df.with_row_index("grid_gocharts_id")
                return sorted_df
            else:
                return None
        return None

    @staticmethod
    def df_to_nested_dict(df: pl.DataFrame, id_col: str = "grid_gocharts_id") -> dict:
        """
        Convert a sorted Polars DataFrame with hierarchical columns into a nested dictionary.
        
        Args:
            df: Polars DataFrame with id column and hierarchical columns
            id_col: Name of the ID column to exclude from hierarchy
        
        Returns:
            Dictionary with nested 'data' structure
        """
        # Get hierarchy columns (exclude id column)
        hierarchy_cols = [c for c in df.columns if c != id_col]
        
        if not hierarchy_cols:
            return {"data": []}
        
        def build_level(df_subset: pl.DataFrame, col_idx: int = 0) -> list:
            """Recursively build nested structure."""
            if col_idx >= len(hierarchy_cols):
                return []
            
            current_col = hierarchy_cols[col_idx]
            is_last_col = col_idx == len(hierarchy_cols) - 1
            
            # Group by current column
            unique_values = df_subset.select(current_col).unique(maintain_order=True)[current_col].to_list()
            result = []
            
            for value in unique_values:
                filtered = df_subset.filter(pl.col(current_col) == value)
                
                if is_last_col:
                    # Leaf level - just append the value
                    result.append(value)
                else:
                    # Branch level - recurse for children
                    children = build_level(filtered, col_idx + 1)
                    result.append({
                        "value": value,
                        "children": children
                    })
            
            return result
        
        return {"data": build_level(df)}
    
    
    # Usage in your Matrix class:
    def _get_matrix(self,cols: pl.DataFrame, rows: pl.DataFrame) -> dict:
        """Build matrix structure from cols/rows DataFrames."""
        matrix = {}
        
        if cols is not None:
            matrix['x'] = self.df_to_nested_dict(cols)
        
        if rows is not None:
            matrix['y'] = self.df_to_nested_dict(rows)
        
        return matrix
    

    def _get_grid(self) -> list[dict]:
        margins = self.gochart.theme.theme['grid']['margin']['margin']

        TITLE_MARGIN_ADJUSTMENT = 11  # Extra top margin to accommodate chart title
        if self.gochart.title is not None:
            margins['top'] += TITLE_MARGIN_ADJUSTMENT
        cols = self._get_grid_values('col')
        rows = self._get_grid_values('row')

        matrix = self._get_matrix(cols, rows)
        def _to_list(df: pl.DataFrame, prefix: str, suffix: str) -> pl.DataFrame :
            df = (df.select([
                    pl.col('grid_gocharts_id').alias(f'{prefix}_axis_id'),
                    pl.struct(pl.exclude('grid_gocharts_id')).alias(f'facet_{suffix}')]))
            return df
        if cols is None and rows is None:
            raise ValueError('No columns or rows provided for matrix in the data')
        if cols is not None and rows is not None:
            df_cols = _to_list(cols,'x','col')
            df_rows = _to_list(rows,'y','row')
            merged = (
                df_cols.join(df_rows, how='cross')
                .with_row_index('id')
                .to_dicts()
            )
        elif cols is not None:
            df_cols = _to_list(cols,'x','col')
            merged = (
                df_cols
                .with_row_index('id')
                .to_dicts()
            )
        elif rows is not None:
            df_rows = _to_list(rows,'y','row')
            merged = (
                df_rows
                .with_row_index('id')
                .to_dicts()
            )
        return merged, matrix