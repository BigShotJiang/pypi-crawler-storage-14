Models
=================
   
Pytorch
------------------------

.. automodule:: tiledb.ml.models.pytorch
   :inherited-members:
   :undoc-members:


Sklearn
------------------------

.. automodule:: tiledb.ml.models.sklearn
   :inherited-members:
   :undoc-members:


Tensorflow Keras
----------------------------------

.. automodule:: tiledb.ml.models.tensorflow_keras
   :inherited-members:
   :undoc-members:
