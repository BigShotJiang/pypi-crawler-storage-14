"""FastMCP re-export from the official mcp library."""

from mcp.server.fastmcp import FastMCP

__all__ = ["FastMCP"]
