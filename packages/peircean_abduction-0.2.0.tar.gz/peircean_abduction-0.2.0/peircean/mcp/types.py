"""MCP types re-exported from the official mcp library."""

from mcp.types import ToolAnnotations

__all__ = ["ToolAnnotations"]
