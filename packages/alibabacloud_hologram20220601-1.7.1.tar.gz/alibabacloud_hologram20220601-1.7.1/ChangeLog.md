2025-11-05 Version: 1.7.0
- Support API GrantDatabasePermission.
- Support API GrantSchemaPermission.
- Support API GrantTablePermission.
- Support API ListDatabases.
- Support API RevokeDatabasePermission.
- Support API RevokeSchemaPermission.
- Support API RevokeTablePermission.


2025-10-14 Version: 1.6.1
- Update API CreateHoloWarehouse: add request parameters body.clusterCount.
- Update API GetWarehouseDetail: add response parameters Body.WarehouseDetail.AutoElasticCpu.
- Update API GetWarehouseDetail: add response parameters Body.WarehouseDetail.WarehouseList.$.AutoScaleType.
- Update API GetWarehouseDetail: add response parameters Body.WarehouseDetail.WarehouseList.$.ClusterCount.
- Update API GetWarehouseDetail: add response parameters Body.WarehouseDetail.WarehouseList.$.ClusterCpu.
- Update API GetWarehouseDetail: add response parameters Body.WarehouseDetail.WarehouseList.$.ElasticType.
- Update API GetWarehouseDetail: add response parameters Body.WarehouseDetail.WarehouseList.$.InitClusterCount.
- Update API GetWarehouseDetail: add response parameters Body.WarehouseDetail.WarehouseList.$.MaxClusterCount.
- Update API ScaleHoloWarehouse: add request parameters body.clusterCount.


2025-10-13 Version: 1.6.0
- Support API DisableSSL.
- Support API EnableSSL.
- Support API GetCertificateAttribute.
- Support API GetRootCertificate.
- Support API RenewSSLCertificate.


2025-03-18 Version: 1.5.2
- Update API CreateInstance: update param body.


2024-12-26 Version: 1.5.1
- Update API GetInstance: update response param.
- Update API ListInstances: update response param.


2024-11-18 Version: 1.5.0
- Support API ListBackupData.


2024-08-20 Version: 1.4.0
- Support API CreateHoloWarehouse.
- Support API DeleteHoloWarehouse.
- Support API RebalanceHoloWarehouse.
- Support API RenameHoloWarehouse.
- Support API RestartHoloWarehouse.
- Support API ResumeHoloWarehouse.
- Support API ScaleHoloWarehouse.
- Support API SuspendHoloWarehouse.


2024-08-19 Version: 1.3.3
- Generated python 2022-06-01 for Hologram.

2024-08-16 Version: 1.3.2
- Update API GetWarehouseDetail: update response param.


2024-08-16 Version: 1.3.2
- Update API GetWarehouseDetail: update response param.


2024-04-10 Version: 1.3.1
- Update API CreateInstance: update param body.
- Update API ScaleInstance: update param body.


2024-03-14 Version: 1.3.0
- Support API ChangeResourceGroup.
- Support API DisableHiveAccess.
- Support API EnableHiveAccess.
- Support API GetWarehouseDetail.
- Support API ListWarehouses.
- Update API GetInstance: update response param.


2024-02-21 Version: 1.2.0
- Support API ChangeResourceGroup.
- Support API DisableHiveAccess.
- Support API EnableHiveAccess.
- Support API GetWarehouseDetail.
- Support API ListWarehouses.


2024-02-21 Version: 1.1.0
- Support API ChangeResourceGroup.
- Support API DisableHiveAccess.
- Support API EnableHiveAccess.
- Support API GetWarehouseDetail.
- Support API ListWarehouses.


2024-01-23 Version: 1.0.7
- Generated python 2022-06-01 for Hologram.

2023-10-18 Version: 1.0.6
- Generated python 2022-06-01 for Hologram.

2023-10-17 Version: 1.0.5
- Generated python 2022-06-01 for Hologram.

2023-07-13 Version: 1.0.4
open hologram api 

2023-05-17 Version: 1.0.3
open hologram api 

2023-04-26 Version: 1.0.2
open hologram api 

2023-04-19 Version: 1.0.1
open hologram api 

2023-04-13 Version: 1.0.0
open hologram api 

