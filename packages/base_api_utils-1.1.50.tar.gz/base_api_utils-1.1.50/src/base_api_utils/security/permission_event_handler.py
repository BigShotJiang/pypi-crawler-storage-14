import logging

from ..domain import EventMessage, DomainEvent
from ..handlers import BaseEventHandler

from .user_permissions_service import UserPermissionsService


class PermissionEventHandler(BaseEventHandler):
    HANDLED_EVENTS = [
        DomainEvent.AUTH_ACCESS_RIGHT_REMOVED.value,
        DomainEvent.AUTH_USER_REMOVED_FROM_GROUP.value,
        DomainEvent.AUTH_USER_REMOVED_FROM_SPONSOR_AND_SUMMIT.value,
        DomainEvent.AUTH_USER_REMOVED_FROM_SUMMIT.value
    ]

    def can_handle(self, event_type: str) -> bool:
        return event_type in self.HANDLED_EVENTS

    def handle(self, event: EventMessage) -> bool:
        try:
            logging.getLogger('api').debug(
                f"PermissionEventHandler::handle - Processing permission event: {event.event_type} - {event.payload}")

            return self._handle_permission_changed(event)
        except Exception as e:
            logging.getLogger('api').error(f"Error processing permission event: {e}")
            return False

    def _handle_permission_changed(self, event: EventMessage) -> bool:
        permission_data = event.payload
        sponsor_id = permission_data.get('sponsor_id')
        user_id = permission_data.get('user_external_id')
        summit_id = permission_data.get('summit_id')
        if not summit_id:
            summit_id = permission_data.get('show_id')

        UserPermissionsService.remove_cached_permission(user_id, summit_id, sponsor_id)
        return True