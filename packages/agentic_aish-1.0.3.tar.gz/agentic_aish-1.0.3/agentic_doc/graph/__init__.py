"""Graph module for symbol graph visualization."""
