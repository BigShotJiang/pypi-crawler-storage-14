"""
Agentic Doc - AI-Powered Documentation Generator

A professional CLI tool for generating comprehensive documentation
for large codebases using AI (OpenAI GPT or Google Gemini).
"""

__version__ = "1.0.0"
__author__ = "Ish Kapoor"
