

analytes = {
    "1-MNA":137.0709,
    "Methionine":150.0583,
    "Adenosine":256.24023,
    "Kynurenine":209.09262,
    "Arginine":175.1195,
    "N1-methyl-2and4-pyridone-5-carboxamide":153.06640,
    "SAM":399.1451,
    "Glutathione":330.0736,
    "5-Methylthioadenosine":298.09739,
    "Spermine":203.2236,
    "Spermidine":146.1657,
    "Putrescine":89.1079,
    "SAH": 385.1294,
    "Homocysteine": 136.0432,
    "Nicotinamide": 123.0552,
    "Asparagine": 133.0613,
}
