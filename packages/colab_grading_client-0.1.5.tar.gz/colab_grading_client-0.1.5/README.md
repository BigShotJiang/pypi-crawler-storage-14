# colab_grading_client
colab notebook functions to invoke AI teaching and grading assistant
