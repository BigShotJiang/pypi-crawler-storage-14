// Deprecated: functionality moved to `src/ops/{batch,project}.rs` to avoid duplication.
