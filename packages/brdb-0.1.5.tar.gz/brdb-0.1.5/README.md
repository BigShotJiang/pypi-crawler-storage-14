# Test library


# My Library

[![GitHub stars](https://img.shields.io/github/stars/braveua/brdb?style=social)](https://github.com/braveua/brdb)

**My Library** – небольшая утилита для работы с данными.

## 📦 Установка

```bash
pip install my_library
```