from draive.parameters.model import DataModel

__all__ = ("DataModel",)
