"""Core domain availability checking functionality."""
import dns.resolver
import whois


def check_dns_records(domain):
    """Check if domain has DNS records (A, NS, MX, AAAA)."""
    record_types = ['A', 'AAAA', 'NS', 'MX']
    found_records = []
    
    for record_type in record_types:
        try:
            answers = dns.resolver.resolve(domain, record_type)
            if answers:
                found_records.append(record_type)
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, 
                dns.resolver.NoNameservers, dns.exception.Timeout):
            continue
        except Exception:
            continue
    
    return found_records


def check_whois_registration(domain):
    """Check WHOIS to see if domain is registered."""
    try:
        w = whois.whois(domain)
        if w.domain_name:
            return True
        if w.status:
            return True
        if w.creation_date:
            return True
        return False
    except Exception:
        return None


def is_domain_registered(domain):
    """
    Combine DNS and WHOIS checks to determine if domain is registered.
    Returns: (is_registered: bool, reason: str)
    """
    dns_records = check_dns_records(domain)
    
    if 'A' in dns_records or 'NS' in dns_records or 'AAAA' in dns_records:
        return True, f"DNS records found: {', '.join(dns_records)}"
    
    whois_result = check_whois_registration(domain)
    
    if whois_result is True:
        return True, "Registered (WHOIS confirmed)"
    elif whois_result is False:
        return False, "Available (no DNS, no WHOIS)"
    else:
        return False, "Likely available (no DNS records)"


def normalize_name(name):
    """Convert brand name to domain-suitable format."""
    name = name.lower()
    return "".join(ch for ch in name if ch.isalnum())


def check_domains(names, tlds, verbose=True):
    """Check availability of domain combinations."""
    normalized_names = [normalize_name(n) for n in names]
    unique_names = []
    seen = set()
    for name in normalized_names:
        if name and name not in seen:
            seen.add(name)
            unique_names.append(name)
    
    available = []
    taken = []
    
    total = len(unique_names) * len(tlds)
    current = 0
    
    for name in unique_names:
        for tld in tlds:
            current += 1
            domain = f"{name}.{tld}"
            
            if verbose:
                print(f"[{current}/{total}] Checking {domain}...", end=' ')
            
            try:
                is_registered, reason = is_domain_registered(domain)
                
                if is_registered:
                    taken.append((domain, reason))
                    if verbose:
                        print(f"✗ TAKEN")
                else:
                    available.append((domain, reason))
                    if verbose:
                        print(f"✓ AVAILABLE")
                    
            except Exception as e:
                taken.append((domain, f"Error: {str(e)}"))
                if verbose:
                    print(f"⚠ ERROR: {str(e)}")
    
    return available, taken
