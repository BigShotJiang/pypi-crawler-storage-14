"""Command-line interface for domain checker."""
import argparse
import sys
from . import checker


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Check domain availability for multiple name and TLD combinations.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Check single name with default TLDs
  domain-checker -n myapp
  
  # Check multiple names
  domain-checker -n myapp yourapp theirapp
  
  # Check with custom TLDs
  domain-checker -n myapp -t com net org
  
  # Check from file
  domain-checker -f names.txt -t com ai io
        """
    )
    
    # Input options
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument(
        '-n', '--names',
        nargs='+',
        help='Domain names to check (space-separated)'
    )
    input_group.add_argument(
        '-f', '--file',
        type=str,
        help='File containing domain names (one per line)'
    )
    
    # TLD options
    parser.add_argument(
        '-t', '--tlds',
        nargs='+',
        default=['com', 'ai', 'io', 'co', 'app', 'dev'],
        help='TLD extensions to check (default: com ai io co app dev)'
    )
    
    # Output options
    parser.add_argument(
        '-o', '--output',
        type=str,
        help='Output file for results (optional)'
    )
    
    parser.add_argument(
        '--available-only',
        action='store_true',
        help='Show only available domains'
    )
    
    parser.add_argument(
        '--taken-only',
        action='store_true',
        help='Show only taken domains'
    )
    
    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help='Suppress progress messages'
    )
    
    args = parser.parse_args()
    
    # Get names from file or arguments
    if args.file:
        try:
            with open(args.file, 'r') as f:
                names = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(f"Error: File '{args.file}' not found.", file=sys.stderr)
            sys.exit(1)
    else:
        names = args.names
    
    # Normalize TLDs (remove dots if present)
    tlds = [tld.lstrip('.') for tld in args.tlds]
    
    # Show configuration
    if not args.quiet:
        print("Domain Availability Checker")
        print("=" * 70)
        print(f"Names to check: {len(names)}")
        print(f"TLDs: {', '.join(tlds)}")
        print(f"Total combinations: {len(names) * len(tlds)}")
        print("=" * 70)
        print()
    
    # Check domains
    available, taken = checker.check_domains(names, tlds, verbose=not args.quiet)
    
    # Prepare output
    output_lines = []
    
    if not args.taken_only:
        output_lines.append("\n" + "=" * 70)
        output_lines.append(f"AVAILABLE DOMAINS ({len(available)} total):")
        output_lines.append("=" * 70)
        for domain, reason in available:
            output_lines.append(f"  ✓ {domain:30} {reason}")
    
    if not args.available_only:
        output_lines.append("\n" + "=" * 70)
        output_lines.append(f"TAKEN/REGISTERED DOMAINS ({len(taken)} total):")
        output_lines.append("=" * 70)
        for domain, reason in taken:
            output_lines.append(f"  ✗ {domain:30} {reason}")
    
    # Print to console
    for line in output_lines:
        print(line)
    
    # Save to file if requested
    if args.output:
        with open(args.output, 'w') as f:
            f.write('\n'.join(output_lines))
        print(f"\nResults saved to: {args.output}")


if __name__ == '__main__':
    main()
