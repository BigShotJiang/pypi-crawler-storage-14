"""Domain availability checker package."""
from .checker import (
    check_dns_records,
    check_whois_registration,
    is_domain_registered,
    check_domains,
    normalize_name
)

__version__ = '0.1.0'
__all__ = [
    'check_dns_records',
    'check_whois_registration', 
    'is_domain_registered',
    'check_domains',
    'normalize_name'
]
