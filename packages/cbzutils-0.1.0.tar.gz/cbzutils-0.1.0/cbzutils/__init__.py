import tqdm

from . import sort_keys, source

from . import writer
from pathlib import Path
from typing import Any, Callable

def merge_cbz(output: Path, files: list[Path], sort_key: Callable[[str], Any] = sort_keys.key_default):
    """
    Merges as bunch of input cbz files into an output cbz file.

    the sort_key is a function that is passed as the key argument
    to the list.sort method.
    """
    files = [Path(x) for x in files]  # Just to make sure

    cbzwriter = writer.CbzWriter(Path(output))
    files.sort(key=lambda x: sort_key(x.name))

    sources = [source.CbzSource(x) for x in files]
    for x in tqdm.tqdm(sources, "Merging files"):
        cbzwriter.append_source(x)
    
    cbzwriter.close()