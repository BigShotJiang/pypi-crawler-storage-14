"""
Provides functions for generating ordering strings with optional jittering.

<https://github.com/httpie/fractional-indexing-python>.

<https://observablehq.com/@dgreensp/implementing-fractional-indexing>

"""
from math import floor
from typing import Optional, List, Dict, Callable
from dataclasses import dataclass
import decimal
import random


__version__ = '0.2.0'
__licence__ = 'CC0 1.0 Universal'

BASE_62_DIGITS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'


class FIError(Exception):
    pass


@dataclass
class IndexedCharacterSet:
    """A character set with pre-computed lookups for efficient key operations."""
    chars: str
    by_char: Dict[str, int]
    by_code: Dict[int, str]
    padding_dict: Dict[int, int]
    length: int
    first: str
    last: str
    first_positive: str
    most_positive: str
    first_negative: str
    most_negative: str
    jitter_range: int


def _create_char_set_dicts(chars: str) -> tuple:
    """Create lookup dictionaries from a character string."""
    by_char: Dict[str, int] = {}
    by_code: Dict[int, str] = {}
    length = len(chars)

    for i, char in enumerate(chars):
        by_code[i] = char
        by_char[char] = i

    return by_char, by_code, length


def _create_padding_dict(jitter_range: int, char_set_length: int) -> Dict[int, int]:
    """Pre-calculate padding amounts needed for various distances."""
    padding_dict: Dict[int, int] = {}
    for i in range(100):
        padding_dict[i] = char_set_length ** i
        if padding_dict[i] > jitter_range:
            break
    return padding_dict


def _distance_between(a: str, b: str, char_set: IndexedCharacterSet) -> int:
    """Calculate the index distance between two characters."""
    index_a = char_set.by_char[a]
    index_b = char_set.by_char[b]
    return abs(index_a - index_b)


def index_character_set(
    chars: str,
    first_positive: Optional[str] = None,
    most_positive: Optional[str] = None,
    most_negative: Optional[str] = None,
    jitter_range: Optional[int] = None,
) -> IndexedCharacterSet:
    """
    Create an IndexedCharacterSet from a string of characters.

    Args:
        chars: A sorted string of unique characters (minimum 7 characters)
        first_positive: The character that marks the start of positive integers (default: middle)
        most_positive: The maximum positive head character (default: last char)
        most_negative: The minimum negative head character (default: first char)
        jitter_range: The range for jittering (default: chars_length^3 / 5)

    Returns:
        An IndexedCharacterSet instance
    """
    if len(chars) < 7:
        raise FIError("charSet must be at least 7 characters long")

    if ''.join(sorted(chars)) != chars:
        raise FIError("charSet must be sorted")

    by_char, by_code, length = _create_char_set_dicts(chars)

    first_positive_idx = by_char[first_positive] if first_positive else length // 2
    most_positive_idx = by_char[most_positive] if most_positive else length - 1
    most_negative_idx = by_char[most_negative] if most_negative else 0

    if most_positive_idx - first_positive_idx < 3:
        raise FIError("mostPositive must be at least 3 characters away from firstPositive")
    if first_positive_idx - most_negative_idx < 3:
        raise FIError("mostNegative must be at least 3 characters away from firstPositive")

    first_negative_idx = first_positive_idx - 1

    if jitter_range is None:
        jitter_range = floor(length ** 3 / 5)

    padding_dict = _create_padding_dict(jitter_range, length)

    return IndexedCharacterSet(
        chars=chars,
        by_char=by_char,
        by_code=by_code,
        padding_dict=padding_dict,
        length=length,
        first=by_code[0],
        last=by_code[length - 1],
        first_positive=by_code[first_positive_idx],
        most_positive=by_code[most_positive_idx],
        first_negative=by_code[first_negative_idx],
        most_negative=by_code[most_negative_idx],
        jitter_range=jitter_range,
    )


_base62_char_set: Optional[IndexedCharacterSet] = None


def base62_char_set() -> IndexedCharacterSet:
    """
    Get the default base62 character set (cached).

    Uses: 0-9, A-Z, a-z with:
    - firstPositive: 'a'
    - mostPositive: 'z'
    - mostNegative: 'A'
    """
    global _base62_char_set
    if _base62_char_set is None:
        _base62_char_set = index_character_set(
            chars=BASE_62_DIGITS,
            first_positive='a',
            most_positive='z',
            most_negative='A',
        )
    return _base62_char_set


def _make_same_length(a: str, b: str, pad_side: str, pad_char: str) -> tuple:
    """Pad two strings to the same length."""
    max_len = max(len(a), len(b))
    if pad_side == "start":
        return a.rjust(max_len, pad_char), b.rjust(max_len, pad_char)
    else:
        return a.ljust(max_len, pad_char), b.ljust(max_len, pad_char)


def add_char_set_keys(a: str, b: str, char_set: IndexedCharacterSet) -> str:
    """Add two keys as base-N numbers."""
    base = char_set.length
    padded_a, padded_b = _make_same_length(a, b, "start", char_set.first)

    result: List[str] = []
    carry = 0

    for i in range(len(padded_a) - 1, -1, -1):
        digit_a = char_set.by_char[padded_a[i]]
        digit_b = char_set.by_char[padded_b[i]]
        total = digit_a + digit_b + carry
        carry = total // base
        remainder = total % base
        result.insert(0, char_set.by_code[remainder])

    if carry > 0:
        result.insert(0, char_set.by_code[carry])

    return ''.join(result)


def subtract_char_set_keys(
    a: str,
    b: str,
    char_set: IndexedCharacterSet,
    strip_leading_zeros: bool = True
) -> str:
    """Subtract b from a as base-N numbers (a - b)."""
    base = char_set.length
    padded_a, padded_b = _make_same_length(a, b, "start", char_set.first)

    result: List[str] = []
    borrow = 0

    for i in range(len(padded_a) - 1, -1, -1):
        digit_a = char_set.by_char[padded_a[i]]
        digit_b = char_set.by_char[padded_b[i]] + borrow

        if digit_a < digit_b:
            borrow = 1
            digit_a += base
        else:
            borrow = 0

        difference = digit_a - digit_b
        result.insert(0, char_set.by_code[difference])

    if borrow > 0:
        raise FIError("Subtraction result is negative. Ensure a >= b.")

    while strip_leading_zeros and len(result) > 1 and result[0] == char_set.first:
        result.pop(0)

    return ''.join(result)


def encode_to_char_set(num: int, char_set: IndexedCharacterSet) -> str:
    """Encode an integer to a key string using the character set."""
    if num == 0:
        return char_set.by_code[0]

    result = ""
    base = char_set.length
    while num > 0:
        result = char_set.by_code[num % base] + result
        num //= base

    return result


def decode_char_set_to_number(key: str, char_set: IndexedCharacterSet) -> int:
    """Decode a key string to an integer."""
    result = 0
    length = len(key)
    base = char_set.length

    for i, char in enumerate(key):
        result += char_set.by_char[char] * (base ** (length - i - 1))

    return result


def lexical_distance(a: str, b: str, char_set: IndexedCharacterSet) -> int:
    """Calculate the lexical distance between two keys."""
    padded_a, padded_b = _make_same_length(a, b, "end", char_set.first)
    lower, upper = sorted([padded_a, padded_b])
    distance = subtract_char_set_keys(upper, lower, char_set)
    return decode_char_set_to_number(distance, char_set)


def _increment_key(key: str, char_set: IndexedCharacterSet) -> str:
    """Increment a key by 1."""
    return add_char_set_keys(key, char_set.by_code[1], char_set)


def _decrement_key(key: str, char_set: IndexedCharacterSet) -> str:
    """Decrement a key by 1 (preserves leading zeros)."""
    return subtract_char_set_keys(key, char_set.by_code[1], char_set, strip_leading_zeros=False)


def _integer_length_from_second_level(
    key: str,
    direction: str,
    char_set: IndexedCharacterSet
) -> int:
    """Calculate integer length from second level onwards."""
    if not key:
        return 0

    first_char = key[0]
    if first_char > char_set.most_positive or first_char < char_set.most_negative:
        raise FIError(f"invalid firstChar on key: {first_char}")

    if first_char == char_set.most_positive and direction == "positive":
        total_room = _distance_between(first_char, char_set.most_negative, char_set) + 1
        return total_room + _integer_length_from_second_level(key[1:], direction, char_set)

    if first_char == char_set.most_negative and direction == "negative":
        total_room = _distance_between(first_char, char_set.most_positive, char_set) + 1
        return total_room + _integer_length_from_second_level(key[1:], direction, char_set)

    if direction == "positive":
        return _distance_between(first_char, char_set.most_negative, char_set) + 2
    else:
        return _distance_between(first_char, char_set.most_positive, char_set) + 2


def integer_length(head: str, char_set: IndexedCharacterSet) -> int:
    """Calculate the total length of an integer part given its head."""
    first_char = head[0]
    if first_char > char_set.most_positive or first_char < char_set.most_negative:
        raise FIError(f"invalid firstChar on key: {first_char}")

    if first_char == char_set.most_positive:
        first_level = _distance_between(first_char, char_set.first_positive, char_set) + 1
        return first_level + _integer_length_from_second_level(head[1:], "positive", char_set)

    if first_char == char_set.most_negative:
        first_level = _distance_between(first_char, char_set.first_negative, char_set) + 1
        return first_level + _integer_length_from_second_level(head[1:], "negative", char_set)

    is_positive = first_char >= char_set.first_positive
    if is_positive:
        return _distance_between(first_char, char_set.first_positive, char_set) + 2
    else:
        return _distance_between(first_char, char_set.first_negative, char_set) + 2


def integer_head(integer: str, char_set: IndexedCharacterSet) -> str:
    """Extract the head portion of an integer."""
    i = 0
    if integer[0] == char_set.most_positive:
        while i < len(integer) and integer[i] == char_set.most_positive:
            i += 1
    elif integer[0] == char_set.most_negative:
        while i < len(integer) and integer[i] == char_set.most_negative:
            i += 1
    return integer[:i + 1]


def split_integer(integer: str, char_set: IndexedCharacterSet) -> tuple:
    """Split an integer into head and digits."""
    head = integer_head(integer, char_set)
    tail = integer[len(head):]
    return head, tail


def valid_integer(integer: str, char_set: IndexedCharacterSet) -> bool:
    """Check if an integer has the correct length for its head."""
    head = integer_head(integer, char_set)
    length = integer_length(head, char_set)
    return length == len(integer)


def get_integer_part_cs(order_key: str, char_set: IndexedCharacterSet) -> str:
    """Get the integer part of an order key using a character set."""
    head = integer_head(order_key, char_set)
    int_length = integer_length(head, char_set)
    if int_length > len(order_key):
        raise FIError(f"invalid order key length: {order_key}")
    return order_key[:int_length]


def _validate_integer_cs(integer: str, char_set: IndexedCharacterSet):
    """Validate that an integer has the correct length."""
    if not valid_integer(integer, char_set):
        raise FIError(f"invalid integer length: {integer}")


def _start_on_new_head(head: str, limit: str, char_set: IndexedCharacterSet) -> str:
    """Create a new integer starting on a new head."""
    new_length = integer_length(head, char_set)
    fill_char = char_set.by_code[char_set.length - 1] if limit == "upper" else char_set.by_code[0]
    return head + fill_char * (new_length - len(head))


def _increment_integer_head(head: str, char_set: IndexedCharacterSet) -> str:
    """Increment the integer head."""
    in_positive_range = head >= char_set.first_positive
    next_head = _increment_key(head, char_set)
    head_is_limit_max = head[-1] == char_set.most_positive
    next_head_is_limit_max = next_head[-1] == char_set.most_positive

    if in_positive_range and next_head_is_limit_max:
        return next_head + char_set.most_negative
    if not in_positive_range and head_is_limit_max:
        return head[:-1]
    return next_head


def _decrement_integer_head(head: str, char_set: IndexedCharacterSet) -> str:
    """Decrement the integer head."""
    in_positive_range = head >= char_set.first_positive
    head_is_limit_min = head[-1] == char_set.most_negative

    if in_positive_range and head_is_limit_min:
        next_level = head[:-1]
        return _decrement_key(next_level, char_set)

    if not in_positive_range and head_is_limit_min:
        return head + char_set.most_positive

    return _decrement_key(head, char_set)


def increment_integer_cs(integer: str, char_set: IndexedCharacterSet) -> str:
    """Increment an integer using a character set."""
    _validate_integer_cs(integer, char_set)
    head, digs = split_integer(integer, char_set)

    any_non_maxed = any(d != char_set.by_code[char_set.length - 1] for d in digs)

    if any_non_maxed:
        new_digits = _increment_key(digs, char_set)
        return head + new_digits

    next_head = _increment_integer_head(head, char_set)
    return _start_on_new_head(next_head, "lower", char_set)


def decrement_integer_cs(integer: str, char_set: IndexedCharacterSet) -> str:
    """Decrement an integer using a character set."""
    _validate_integer_cs(integer, char_set)
    head, digs = split_integer(integer, char_set)

    any_non_limit = any(d != char_set.by_code[0] for d in digs)

    if any_non_limit:
        new_digits = _decrement_key(digs, char_set)
        return head + new_digits

    next_head = _decrement_integer_head(head, char_set)
    return _start_on_new_head(next_head, "upper", char_set)


def start_key(char_set: IndexedCharacterSet) -> str:
    """Get the starting key for a character set (e.g., 'a0' for base62)."""
    return char_set.first_positive + char_set.by_code[0]


def validate_order_key_cs(order_key: str, char_set: IndexedCharacterSet):
    """Validate an order key using a character set."""
    get_integer_part_cs(order_key, char_set)


def _padding_needed_for_distance(distance: int, char_set: IndexedCharacterSet) -> int:
    """Calculate padding needed to accommodate jitter within a given distance."""
    gap = char_set.jitter_range - distance
    for padding, threshold in sorted(char_set.padding_dict.items()):
        if threshold > gap:
            return padding
    return 0


def padding_needed_for_jitter(
    order_key: str,
    b: Optional[str],
    char_set: IndexedCharacterSet
) -> int:
    """Calculate padding needed to safely apply jitter to a key."""
    integer = get_integer_part_cs(order_key, char_set)
    next_integer = increment_integer_cs(integer, char_set)

    needed = 0

    if b is not None:
        distance_to_b = lexical_distance(order_key, b, char_set)
        if distance_to_b < char_set.jitter_range + 1:
            needed = max(needed, _padding_needed_for_distance(distance_to_b, char_set))

    distance_to_next_integer = lexical_distance(order_key, next_integer, char_set)
    if distance_to_next_integer < char_set.jitter_range + 1:
        needed = max(needed, _padding_needed_for_distance(distance_to_next_integer, char_set))

    return needed


def jitter_string(order_key: str, char_set: IndexedCharacterSet) -> str:
    """Apply random jitter to an order key."""
    shift = encode_to_char_set(
        floor(random.random() * char_set.jitter_range),
        char_set
    )
    return add_char_set_keys(order_key, shift, char_set)


def pad_and_jitter_string(
    order_key: str,
    num_chars: int,
    char_set: IndexedCharacterSet
) -> str:
    """Pad a key and then apply jitter."""
    padded_key = order_key.ljust(len(order_key) + num_chars, char_set.first)
    return jitter_string(padded_key, char_set)


def _mid_point(lower: str, upper: str, char_set: IndexedCharacterSet) -> str:
    """Calculate the midpoint between two keys using numerical distance."""
    padded_lower, padded_upper = _make_same_length(lower, upper, "end", char_set.first)
    distance = lexical_distance(padded_lower, padded_upper, char_set)

    if distance == 1:
        padded_lower = padded_lower.ljust(len(padded_lower) + 1, char_set.first)
        distance = char_set.length

    mid = encode_to_char_set(floor(distance / 2), char_set)
    return add_char_set_keys(padded_lower, mid, char_set)


def generate_key_between_cs(
    lower: Optional[str],
    upper: Optional[str],
    char_set: IndexedCharacterSet
) -> str:
    """Generate a key between two other keys using a character set."""
    if lower is not None:
        validate_order_key_cs(lower, char_set)
    if upper is not None:
        validate_order_key_cs(upper, char_set)

    if lower is None and upper is None:
        return start_key(char_set)

    if lower is None:
        integer = get_integer_part_cs(upper, char_set)
        return decrement_integer_cs(integer, char_set)

    if upper is None:
        integer = get_integer_part_cs(lower, char_set)
        return increment_integer_cs(integer, char_set)

    if lower >= upper:
        raise FIError(f"{lower} >= {upper}")

    return _mid_point(lower, upper, char_set)


def generate_jittered_key_between(
    lower: Optional[str],
    upper: Optional[str],
    char_set: Optional[IndexedCharacterSet] = None
) -> str:
    """
    Generate a key between two other keys with jitter.

    Jittering adds a random component to the key to avoid collisions
    when multiple clients generate keys simultaneously.

    Args:
        lower: The lower bound (or None for start of list)
        upper: The upper bound (or None for end of list)
        char_set: The character set to use (default: base62)

    Returns:
        A jittered key that sorts between lower and upper
    """
    if char_set is None:
        char_set = base62_char_set()

    key = generate_key_between_cs(lower, upper, char_set)
    padding_needed = padding_needed_for_jitter(key, upper, char_set)

    if padding_needed:
        return pad_and_jitter_string(key, padding_needed, char_set)
    return jitter_string(key, char_set)


def _spread_generator_results(
    lower: Optional[str],
    upper: Optional[str],
    n: int,
    char_set: IndexedCharacterSet,
    generate_key: Callable,
    generate_n_keys: Callable
) -> List[str]:
    """Spread n keys between lower and upper using a tree-splitting approach."""
    if n == 0:
        return []
    if n == 1:
        return [generate_key(lower, upper, char_set)]

    if upper is None:
        new_upper = generate_key(lower, upper, char_set)
        result = [new_upper]
        for _ in range(n - 1):
            new_upper = generate_key(new_upper, upper, char_set)
            result.append(new_upper)
        return result

    if lower is None:
        new_lower = generate_key(lower, upper, char_set)
        result = [new_lower]
        for _ in range(n - 1):
            new_lower = generate_key(lower, new_lower, char_set)
            result.append(new_lower)
        result.reverse()
        return result

    mid = floor(n / 2)
    mid_key = generate_key(lower, upper, char_set)
    return [
        *generate_n_keys(lower, mid_key, mid, char_set),
        mid_key,
        *generate_n_keys(mid_key, upper, n - mid - 1, char_set),
    ]


def generate_n_keys_between_cs(
    lower: Optional[str],
    upper: Optional[str],
    n: int,
    char_set: IndexedCharacterSet
) -> List[str]:
    """Generate n keys between two other keys using a character set."""
    return _spread_generator_results(
        lower, upper, n, char_set,
        generate_key_between_cs,
        generate_n_keys_between_cs
    )


def generate_n_jittered_keys_between(
    lower: Optional[str],
    upper: Optional[str],
    n: int,
    char_set: Optional[IndexedCharacterSet] = None
) -> List[str]:
    """
    Generate n jittered keys between two other keys.

    Args:
        lower: The lower bound (or None for start of list)
        upper: The upper bound (or None for end of list)
        n: Number of keys to generate
        char_set: The character set to use (default: base62)

    Returns:
        A list of n jittered keys in sorted order
    """
    if char_set is None:
        char_set = base62_char_set()

    return _spread_generator_results(
        lower, upper, n, char_set,
        generate_jittered_key_between,
        generate_n_jittered_keys_between
    )


@dataclass
class GeneratorOptions:
    """Options for the IndexGenerator class."""
    char_set: Optional[IndexedCharacterSet] = None
    use_jitter: bool = True
    group_id_length: int = 0


class IndexGenerator:
    """
    A helper class for managing ordered lists with fractional indexing.

    This class provides convenient methods for generating keys at various
    positions in a list, with optional support for grouping.

    Example:
        >>> gen = IndexGenerator([])
        >>> key1 = gen.key_end()
        >>> gen.update_list([key1])
        >>> key2 = gen.key_end()
    """

    def __init__(self, list_: List[str], options: Optional[GeneratorOptions] = None):
        if options is None:
            options = GeneratorOptions()

        self._char_set = options.char_set or base62_char_set()
        self._use_jitter = options.use_jitter
        self._list = sorted(list_)
        self._use_groups = options.group_id_length > 0
        self._group_id_length = options.group_id_length

    def update_list(self, list_: List[str]) -> None:
        """Update the internal list (will be sorted)."""
        self._list = sorted(list_)

    def key_start(self, group_id: Optional[str] = None) -> str:
        """Generate a key at the start of the list (or group)."""
        self._validate_group_id(group_id)
        return self.n_keys_start(1, group_id)[0]

    def key_end(self, group_id: Optional[str] = None) -> str:
        """Generate a key at the end of the list (or group)."""
        self._validate_group_id(group_id)
        return self.n_keys_end(1, group_id)[0]

    def key_after(self, order_key: str) -> str:
        """Generate a key after the given key."""
        return self.n_keys_after(order_key, 1)[0]

    def key_before(self, order_key: str) -> str:
        """Generate a key before the given key."""
        return self.n_keys_before(order_key, 1)[0]

    def n_keys_start(self, n: int, group_id: Optional[str] = None) -> List[str]:
        """Generate n keys at the start of the list (or group)."""
        self._validate_group_id(group_id)
        return self._generate_n_keys_between(
            None,
            self._first_of_group(group_id),
            n,
            group_id
        )

    def n_keys_end(self, n: int, group_id: Optional[str] = None) -> List[str]:
        """Generate n keys at the end of the list (or group)."""
        self._validate_group_id(group_id)
        return self._generate_n_keys_between(
            self._last_of_group(group_id),
            None,
            n,
            group_id
        )

    def n_keys_after(self, order_key: str, n: int) -> List[str]:
        """Generate n keys after the given key."""
        key_after = self._get_key_after(order_key)
        return self._generate_n_keys_between(
            order_key,
            key_after,
            n,
            self._group_id(order_key)
        )

    def n_keys_before(self, order_key: str, n: int) -> List[str]:
        """Generate n keys before the given key."""
        key_before = self._get_key_before(order_key)
        return self._generate_n_keys_between(
            key_before,
            order_key,
            n,
            self._group_id(order_key)
        )

    def _generate_n_keys_between(
        self,
        lower_key: Optional[str],
        upper_key: Optional[str],
        n: int,
        group_id: Optional[str]
    ) -> List[str]:
        lower = self._group_less_key(lower_key)
        upper = self._group_less_key(upper_key)

        if self._use_jitter:
            keys = generate_n_jittered_keys_between(lower, upper, n, self._char_set)
        else:
            keys = generate_n_keys_between_cs(lower, upper, n, self._char_set)

        if group_id:
            keys = [group_id + key for key in keys]

        return keys

    def _get_key_before(self, order_key: str) -> Optional[str]:
        try:
            index = self._list.index(order_key)
        except ValueError:
            raise FIError("orderKey is not in the list")

        if index == 0:
            return None

        before = self._list[index - 1]
        return before if self._is_same_group(order_key, before) else None

    def _get_key_after(self, order_key: str) -> Optional[str]:
        try:
            index = self._list.index(order_key)
        except ValueError:
            raise FIError("orderKey is not in the list")

        if index >= len(self._list) - 1:
            return None

        after = self._list[index + 1]
        return after if self._is_same_group(order_key, after) else None

    def _first_of_group(self, group_id: Optional[str]) -> Optional[str]:
        if not self._use_groups:
            return self._list[0] if self._list else None

        for key in self._list:
            if self._is_part_of_group(key, group_id):
                return key
        return None

    def _last_of_group(self, group_id: Optional[str]) -> Optional[str]:
        if not self._use_groups:
            return self._list[-1] if self._list else None

        group_items = [k for k in self._list if self._is_part_of_group(k, group_id)]
        return group_items[-1] if group_items else None

    def _validate_group_id(self, group_id: Optional[str]) -> None:
        if not self._use_groups:
            if group_id:
                import warnings
                warnings.warn("groupId should not be used when not using groups")
            return

        if not group_id:
            raise FIError("groupId is required when using groups")
        if len(group_id) != self._group_id_length:
            raise FIError("groupId must be the length supplied in options")

    def _group_id(self, order_key: str) -> Optional[str]:
        if not self._use_groups:
            return None
        return self._split_group_and_key(order_key)[0]

    def _group_less_key(self, order_key: Optional[str]) -> Optional[str]:
        if not self._use_groups:
            return order_key
        return self._split_group_and_key(order_key)[1]

    def _split_group_and_key(self, order_key: Optional[str]) -> tuple:
        if not self._use_groups or not order_key:
            return (None, order_key)

        group_id = order_key[:self._group_id_length]
        key = order_key[self._group_id_length:]
        return (group_id, key)

    def _is_same_group(self, a: str, b: str) -> bool:
        if not self._use_groups:
            return True
        return self._split_group_and_key(a)[0] == self._split_group_and_key(b)[0]

    def _is_part_of_group(self, order_key: str, group_id: Optional[str]) -> bool:
        if not self._use_groups:
            return True
        return self._split_group_and_key(order_key)[0] == group_id


def midpoint(a: str, b: Optional[str], digits: str) -> str:
    """
    `a` may be empty string, `b` is null or non-empty string.
    `a < b` lexicographically if `b` is non-null.
    no trailing zeros allowed.
    digits is a string such as '0123456789' for base 10.  Digits must be in
    ascending character code order!

    """
    zero = digits[0]
    if b is not None and a >= b:
        raise FIError(f'{a} >= {b}')
    if (a and a[-1]) == zero or (b is not None and b[-1] == zero):
        raise FIError('trailing zero')
    if b:
        # remove longest common prefix.  pad `a` with 0s as we
        # go.  note that we don't need to pad `b`, because it can't
        # end before `a` while traversing the common prefix.
        n = 0
        for x, y in zip(a.ljust(len(b), zero), b):
            if x == y:
                n += 1
                continue
            break

        if n > 0:
            return b[:n] + midpoint(a[n:], b[n:], digits)

    # first digits (or lack of digit) are different
    try:
        digit_a = digits.index(a[0]) if a else 0
    except IndexError:
        digit_a = -1
    try:
        digit_b = digits.index(b[0]) if b is not None else len(digits)
    except IndexError:
        digit_b = -1

    if digit_b - digit_a > 1:
        min_digit = round_half_up(0.5 * (digit_a + digit_b))
        return digits[min_digit]
    else:
        if b is not None and len(b) > 1:
            return b[:1]
        else:
            # `b` is null or has length 1 (a single digit).
            # the first digit of `a` is the previous digit to `b`,
            # or 9 if `b` is null.
            # given, for example, midpoint('49', '5'), return
            # '4' + midpoint('9', null), which will become
            # '4' + '9' + midpoint('', null), which is '495'
            return digits[digit_a] + midpoint(a[1:], None, digits)


def validate_integer(i: str):
    if len(i) != get_integer_length(i[0]):
        raise FIError(f'invalid integer part of order key: {i}')


def get_integer_length(head):
    if 'a' <= head <= 'z':
        return ord(head) - ord('a') + 2
    elif 'A' <= head <= 'Z':
        return ord('Z') - ord(head[0]) + 2
    raise FIError('invalid order key head: ' + head)


def get_integer_part(key: str) -> str:
    integer_part_length = get_integer_length(key[0])
    if integer_part_length > len(key):
        raise FIError(f'invalid order key: {key}')
    return key[:integer_part_length]


def validate_order_key(key: str, digits=BASE_62_DIGITS):
    zero = digits[0]
    smallest = 'A' + (zero * 26)
    if key == smallest:
        raise FIError(f'invalid order key: {key}')

    # get_integer_part() will throw if the first character is bad,
    # or the key is too short.  we'd call it to check these things
    # even if we didn't need the result
    i = get_integer_part(key)
    f = key[len(i):]
    if f and f[-1] == zero:
        raise FIError(f'invalid order key: {key}')


def increment_integer(x: str, digits: str) -> Optional[str]:
    zero = digits[0]
    validate_integer(x)
    head, *digs = x
    carry = True
    for i in reversed(range(len(digs))):
        d = digits.index(digs[i]) + 1
        if d == len(digits):
            digs[i] = zero
        else:
            digs[i] = digits[d]
            carry = False
            break
    if carry:
        if head == 'Z':
            return 'a' + zero
        elif head == 'z':
            return None
        h = chr(ord(head[0]) + 1)
        if h > 'a':
            digs.append(zero)
        else:
            digs.pop()
        return h + ''.join(digs)
    else:
        return head + ''.join(digs)


def decrement_integer(x, digits):
    validate_integer(x)
    head, *digs = x
    borrow = True
    for i in reversed(range(len(digs))):

        try:
            index = digits.index(digs[i])
        except IndexError:
            index = -1
        d = index - 1

        if d == -1:
            digs[i] = digits[-1]
        else:
            digs[i] = digits[d]
            borrow = False
            break
    if borrow:
        if head == 'a':
            return 'Z' + digits[-1]
        if head == 'A':
            return None
        h = chr(ord(head[0]) - 1)
        if h < 'Z':
            digs.append(digits[-1])
        else:
            digs.pop()
        return h + ''.join(digs)
    else:
        return head + ''.join(digs)


def generate_key_between(a: Optional[str], b: Optional[str], digits=BASE_62_DIGITS) -> str:
    """
    `a` is an order key or null (START).
    `b` is an order key or null (END).
    `a < b` lexicographically if both are non-null.
    digits is a string such as '0123456789' for base 10.  Digits must be in
    ascending character code order!

    """
    zero = digits[0]
    if a is not None:
        validate_order_key(a, digits=digits)
    if b is not None:
        validate_order_key(b, digits=digits)
    if a is not None and b is not None and a >= b:
        raise FIError(f'{a} >= {b}')

    if a is None:
        if b is None:
            return 'a' + zero
        ib = get_integer_part(b)
        fb = b[len(ib):]
        if ib == 'A' + (zero * 26):
            return ib + midpoint('', fb, digits)
        if ib < b:
            return ib
        res = decrement_integer(ib, digits)
        if res is None:
            raise FIError('cannot decrement any more')
        return res

    if b is None:
        ia = get_integer_part(a)
        fa = a[len(ia):]
        i = increment_integer(ia, digits)
        return ia + midpoint(fa, None, digits) if i is None else i

    ia = get_integer_part(a)
    fa = a[len(ia):]
    ib = get_integer_part(b)
    fb = b[len(ib):]
    if ia == ib:
        return ia + midpoint(fa, fb, digits)
    i = increment_integer(ia, digits)
    if i is None:
        raise FIError('cannot increment any more')

    if i < b:
        return i

    return ia + midpoint(fa, None, digits)


def generate_n_keys_between(a: Optional[str], b: Optional[str], n: int, digits=BASE_62_DIGITS) -> List[str]:
    """
    same preconditions as generate_keys_between().
    n >= 0.
    Returns an array of n distinct keys in sorted order.
    If a and b are both null, returns [a0, a1, ...]
    If one or the other is null, returns consecutive "integer"
    keys.  Otherwise, returns relatively short keys between

    """
    if n == 0:
        return []
    if n == 1:
        return [generate_key_between(a, b, digits)]
    if b is None:
        c = generate_key_between(a, b, digits)
        result = [c]
        for i in range(n - 1):
            c = generate_key_between(c, b, digits)
            result.append(c)
        return result

    if a is None:
        c = generate_key_between(a, b, digits)
        result = [c]
        for i in range(n - 1):
            c = generate_key_between(a, c, digits)
            result.append(c)
        return list(reversed(result))

    mid = floor(n / 2)
    c = generate_key_between(a, b, digits)
    return [
        *generate_n_keys_between(a, c, mid, digits),
        c,
        *generate_n_keys_between(c, b, n - mid - 1, digits)
    ]


def round_half_up(n: float) -> int:
    """
    >>> round_half_up(0.4)
    0
    >>> round_half_up(0.8)
    1
    >>> round_half_up(0.5)
    1
    >>> round_half_up(1.5)
    2
    >>> round_half_up(2.5)
    3
    """
    return int(
        decimal.Decimal(str(n)).quantize(
            decimal.Decimal('1'),
            rounding=decimal.ROUND_HALF_UP
        )
    )
