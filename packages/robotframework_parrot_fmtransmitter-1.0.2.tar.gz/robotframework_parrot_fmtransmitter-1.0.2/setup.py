from setuptools import setup
from setuptools import find_namespace_packages
from setuptools import find_packages
from os import path

with open(path.join(path.dirname(__file__), "README.md"), 'rt') as fh:
    long_description = fh.read()

setup(
    name='robotframework-parrot-fmtransmitter',
    version='1.0.2',
    license="Apache License 2.0",
    url="https://github.com/zilogic-systems/parrot",
    author='Zilogic Systems',
    author_email='code@zilogic.com',
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_namespace_packages(),
    package_dir={'parrot': '.'},
    py_modules=['parrot.FMTransmitter'],
    install_requires=["robotframework"],
)
