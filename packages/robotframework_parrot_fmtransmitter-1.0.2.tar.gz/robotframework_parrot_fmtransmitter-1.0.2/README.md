# FM Transmitter Library

This library provides Robot Framework keywords to control an FM transmitter remotely via XML-RPC. It consists of:

- A Robot Framework library (`FMTransmitter.py`) for test automation.
- An XML-RPC server (`FMTransmitterServer.py`) to be run on a Raspberry Pi that interfaces with the transmitter hardware via I2C.


## Installation

To install the FM Transmitter Robot Framework library from PyPI:

```
pip install robotframework-parrot-fmtransmitter
```

To install from git repo use the following command:

```
$ pip install .
```

### Server Dependencies (for Raspberry Pi)

Install `smbus` (Python I2C library):

```
$ sudo pip install smbus
```

Install I2C tools (for debugging and testing hardware):

```
$ sudo apt install i2c-tools
```

Enable I2C interface on the Raspberry Pi using:

```
$ sudo raspi-config
```

Copy the project files to the Raspberry Pi:

```
$ scp -f rpi-fm-setup/ <pi_username>@<raspberry_pi_ip>:/home/<pi_username>/
```

SSH into the Raspberry Pi:

```
$ ssh <pi_username>@<raspberry_pi_ip>
```

Run the install.sh script to set up the server and enable it to start at boot:

```
$ sudo bash install.sh
```

## Example

Example of using the library in Robot Framework is available `example.robot`.


