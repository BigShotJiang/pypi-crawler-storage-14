import asyncio
import aiofiles
import aiohttp
import json
import logging
import time
from pathlib import Path
from typing import Optional, Set, Dict, Any, List, Tuple
import aiotieba as tb
from aiotieba.logging import get_logger as LOG

# 导入内部工具
from .utils import update_thread_index, load_checkpoint, save_checkpoint, MIN_FILE_SIZE
from .utils import list_crawled_threads # 方便 CLI 导入

# --- 配置区 (常量) ---
IMAGE_WORKERS = 8
REQUEST_RETRIES = 5
RETRY_BASE_DELAY = 1.0
REVISIT_LAST_PAGES = 3

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="<%(asctime)s> [%(levelname)s] [%(name)s] %(message)s",
)

class TiebaCrawler:
    """
    贴吧帖子爬虫类。
    封装了初始化、异步爬取和图片下载逻辑。
    """
    
    def __init__(self, bduss: str, max_consecutive_failures: int = 3):
        """
        初始化爬虫。
        :param bduss: 贴吧 BDUSS 登录凭证。
        """
        if not bduss:
            raise ValueError("BDUSS 不能为空。请设置 TIEBA_BDUSS 环境变量。")
            
        self.client = tb.Client(bduss=bduss, fname="tieba-toolkit")
        self.max_consecutive_failures = max_consecutive_failures
        self.consecutive_failures = 0

    # ==============================================================================
    # 辅助函数 (从 craw3.4.8.py 迁移)
    # ==============================================================================
    
    def _extract_images(self, contents) -> list:
        """从 contents 中提取图片列表"""
        if not contents:
            return []
        return getattr(contents, "imgs", [])

    def _build_img_url(self, img) -> Optional[str]:
        """生成图片 URL：优先使用原图 origin_src"""
        origin_src = getattr(img, "origin_src", None)
        if origin_src:
            return origin_src
        
        big_src = getattr(img, "big_src", None)
        if big_src:
            return big_src

        src = getattr(img, "src", None)
        if src:
            return src
            
        return None

    # [此处省略 _http_get_with_retries 和 _download_image_worker 的完整代码，其逻辑与 craw3.4.8.py 中的完全一致，只是成为了类方法]

    async def _http_get_with_retries(self, session: aiohttp.ClientSession, url: str,
                                     retries: int = REQUEST_RETRIES) -> Optional[bytes]:
        """带指数退避的 HTTP GET 请求"""
        delay = RETRY_BASE_DELAY
        for attempt in range(1, retries + 1):
            try:
                async with session.get(url, timeout=30) as resp:
                    if resp.status == 200:
                        return await resp.read()
                    elif resp.status in (429, 503):
                        LOG().warning(
                            f"HTTP {resp.status} (Rate limit/Service unavailable) for {url} attempt {attempt}/{retries}, backoff {delay:.1f}s"
                        )
                    else:
                        LOG().error(f"HTTP {resp.status} for {url}")
                        return None
            except Exception as e:
                LOG().warning(f"GET {url} failed attempt {attempt}/{retries}: {e.__class__.__name__} - {e}")

            await asyncio.sleep(delay)
            delay *= 2

        LOG().error(f"Exhausted retries for {url}")
        return None

    async def _download_image_worker(self, queue: "asyncio.Queue[tuple[str, Path]]",
                                     session: aiohttp.ClientSession):
        """图片下载工作线程"""
        while True:
            item = await queue.get()
            if item is None:
                queue.task_done()
                break

            url, save_path = item
            try:
                if save_path.exists() and save_path.stat().st_size > MIN_FILE_SIZE:
                    continue
                
                data = await self._http_get_with_retries(session, url)
                if data:
                    save_path.parent.mkdir(parents=True, exist_ok=True)
                    async with aiofiles.open(save_path, "wb") as f:
                        await f.write(data)
                else:
                    LOG().error(f"Failed to download image: {url}")
            except Exception as e:
                LOG().exception(f"Image worker error: {e}")
            finally:
                queue.task_done()

    # ==============================================================================
    # JSON 持久化
    # ==============================================================================
    
    def _get_local_img_name(self, idx: int, p=None, c=None, is_main_post: bool = False) -> str:
        """生成图片本地文件名"""
        if is_main_post and p:
            pid = getattr(p, "pid", "unknown_pid")
            return f"楼层_1_{pid}_图片{idx}.jpg"
        
        if c: # 楼中楼评论
            parent_pid = getattr(c, 'orig_pid', 'unknown_p')
            c_pid = getattr(c, 'pid', 'unknown_c')
            return f"楼中楼_{parent_pid}_{c_pid}_图片{idx}.jpg"
        
        if p: # 楼层回复 (非主贴)
            floor_num = getattr(p, "floor", 0)
            pid = getattr(p, "pid", 0)
            return f"楼层_{floor_num}_{pid}_图片{idx}.jpg"
            
        return f"unknown_img_{idx}.jpg"

    async def _serialize_item(self, item, json_type: str = 'llm'):
        """序列化单个帖子或评论"""
        text = getattr(item, "text", "")
        if not text and hasattr(item, "contents"):
            text = getattr(item.contents, "text", "")
            
        user = getattr(item, "user", None)
        
        data = {
            "pid": getattr(item, "pid", None),
            "tid": getattr(item, "tid", None),
            "user_name": getattr(user, "user_name", None) if user else None,
            "user_id": getattr(user, "user_id", None) if user else None,
            "text": text,
            "time": getattr(item, "create_time", 0),
            "image_links": [],
            "img_urls_original": [],
        }
        
        is_comment = hasattr(item, 'orig_pid')
        data['is_comment'] = is_comment
        data['parent_pid'] = getattr(item, 'orig_pid', None) if is_comment else None
        
        floor_num = getattr(item, 'floor', 0)
        data['floor'] = floor_num
        is_main_post = (floor_num == 1 and not is_comment)
        
        contents = getattr(item, "contents", None)
        imgs_raw = self._extract_images(contents)
        
        for i, img in enumerate(imgs_raw, 1):
            url = self._build_img_url(img)
            if url:
                data["img_urls_original"].append(url)
                
                # HTML 格式或 LLM 格式使用对应的图片链接
                local_name = self._get_local_img_name(i, p=item, is_main_post=is_main_post)
                if json_type == 'html':
                    data["image_links"].append(f"images/{local_name}")
                elif json_type == 'llm':
                    data["image_links"].append(url)
            
        return data

    async def _write_posts_json(self, tid: int, page_num: int, posts_list: List):
        """将帖子数据写入 page_xxxx.json 文件 (用于 HTML 查看器)"""
        TID_DIR = Path(f"threads/{tid}")
        JSON_DIR = TID_DIR / "posts"
        JSON_DIR.mkdir(parents=True, exist_ok=True)
        
        payload = []
        for p in posts_list:
            try:
                post_data = await self._serialize_item(p, json_type='html')
                post_data.pop("img_urls_original", None)
                
                if post_data.get('pid') and (post_data.get('text') or post_data.get('image_links')):
                    payload.append(post_data)
            except Exception as e:
                LOG().warning(f"Post serialize (html) failed pid={getattr(p, 'pid', 'unknown')}: {e}")

        if not payload:
            LOG().warning(f"Page {page_num} contains no valid posts. SKIPPING file creation (page_{page_num:04d}.json).")
            return

        async with aiofiles.open(JSON_DIR / f"page_{page_num:04d}.json", "w", encoding="utf-8") as f:
            await f.write(json.dumps(payload, ensure_ascii=False, indent=2))

    async def _append_to_jsonl(self, tid: int, items_list: List):
        """追加到 tid_dump.jsonl (用于 LLM, 仅保留原始图片 URL)"""
        JSONL_FILE = Path(f"threads/{tid}/{tid}_dump.jsonl")
        JSONL_FILE.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(JSONL_FILE, "a", encoding="utf-8") as f:
            for item in items_list:
                try:
                    item_data = await self._serialize_item(item, json_type='llm')
                    item_data.pop("image_links", None) 
                    await f.write(json.dumps(item_data, ensure_ascii=False) + '\n')
                except Exception as e:
                    LOG().warning(f"JSONL serialize failed pid={getattr(item, 'pid', 'unknown')}: {e}")

    # ==============================================================================
    # 核心爬取逻辑 (crawl_thread)
    # ==============================================================================

    async def _fetch_and_process_page(self, tid: int, page: int, img_queue: asyncio.Queue, is_revisit: bool = False) -> Tuple[Optional[int], bool]:
        """爬取并处理一页帖子。"""
        client = self.client
        TID_DIR = Path(f"threads/{tid}")
        OUTPUT_TXT = TID_DIR / f"{tid}_log.txt"
        IMAGE_DIR = TID_DIR / "images"
        
        # ... (API 调用和重试逻辑与 craw3.4.8.py 保持一致)
        posts = None
        success = False
        
        for attempt in range(3):
            try:
                posts = await client.get_posts(tid, pn=page, with_comments=True)
                if posts.err is not None:
                    if isinstance(posts.err, tuple) and posts.err[0] == 429:
                        await asyncio.sleep(10.0 * (2 ** attempt))
                        continue 
                    else:
                        success = False
                        break
                else:
                    success = True
                    break
            except Exception as e:
                if getattr(e, 'status', 0) == 429:
                    await asyncio.sleep(10.0 * (2 ** attempt))
                    continue
                await asyncio.sleep(RETRY_BASE_DELAY * (2 ** attempt)) 
                
        if not success or posts is None:
            if not is_revisit:
                self.consecutive_failures += 1
            return (None, True)

        self.consecutive_failures = 0
        has_more = posts.has_more
        
        # 1. 持久化 JSON (HTML 查看器格式)
        await self._write_posts_json(tid, page, posts.objs)
        
        # 2. 图片排队和 JSONL 更新
        checkpoint = load_checkpoint(tid)
        seen_pids = checkpoint.get('seen_pids', set())

        items_to_jsonl = []
        
        # 将新内容写入日志和 JSONL，并将图片加入队列
        async with aiofiles.open(OUTPUT_TXT, "a", encoding="utf-8") as tx:
            for p in posts.objs:
                pid = p.pid
                is_new_post = pid not in seen_pids
                
                if is_new_post:
                    seen_pids.add(pid)
                    items_to_jsonl.append(p)
                
                # 楼层图片排队下载
                imgs = self._extract_images(p.contents)
                for i, img in enumerate(imgs, 1):
                    url = self._build_img_url(img)
                    if url:
                        local_name = self._get_local_img_name(i, p=p, is_main_post=(p.floor == 1 and page == 1))
                        await img_queue.put((url, IMAGE_DIR / local_name))
                        
                # 楼中楼图片排队下载
                for c in p.comments:
                    if c.pid not in seen_pids:
                        seen_pids.add(c.pid)
                        items_to_jsonl.append(c)
                        
                    imgs = self._extract_images(c.contents)
                    for i, img in enumerate(imgs, 1):
                        url = self._build_img_url(img)
                        if url:
                            local_name = self._get_local_img_name(i, c=c)
                            await img_queue.put((url, IMAGE_DIR / local_name))

        # 3. 更新 JSONL 
        await self._append_to_jsonl(tid, items_to_jsonl)
        
        # 4. 更新检查点 (包含所有 seen_pids)
        save_checkpoint(tid, page, seen_pids)
        
        return len(posts.objs), has_more

    async def crawl_thread(self, tid: int):
        """开始或恢复爬取指定帖子。这是用户调用的主要方法。"""
        if not self.client.bduss:
            LOG().error("BDUSS 未设置或无效，无法开始爬取。")
            return

        LOG().info(f"--- 帖子爬取任务开始: TID {tid} ---")
        
        try:
            info = await self.client.get_thread_info(tid)
            thread_title = info.title
        except Exception as e:
            LOG().error(f"无法获取帖子 {tid} 的信息: {e}")
            thread_title = f"TID_{tid}"

        update_thread_index(tid, thread_title)
        LOG().info(f"帖子标题: {thread_title}")
        
        checkpoint = load_checkpoint(tid)
        start_page = checkpoint["last_page"] + 1
        
        # 准备图片下载队列和工作线程
        img_queue = asyncio.Queue()
        async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(limit=IMAGE_WORKERS * 2)) as session:
            
            workers = [
                asyncio.create_task(self._download_image_worker(img_queue, session))
                for _ in range(IMAGE_WORKERS)
            ]

            # 断点续爬：重爬最后 N 页
            revisit_pages = list(range(max(1, start_page - REVISIT_LAST_PAGES), start_page))
            if revisit_pages:
                LOG().info(f"恢复爬取：正在重爬最后 {len(revisit_pages)} 页。")
                for page in revisit_pages:
                    await self._fetch_and_process_page(tid, page, img_queue, is_revisit=True)
            
            # 主循环
            page = start_page
            LOG().info(f"开始/恢复爬取，起始页码: {page}")

            while True:
                posts_count, has_more = await self._fetch_and_process_page(tid, page, img_queue)
                
                if posts_count is None:
                    if self.consecutive_failures >= self.max_consecutive_failures:
                        LOG().error(f"连续 {self.consecutive_failures} 页爬取失败，达到上限。爬虫终止。")
                        break
                    await asyncio.sleep(RETRY_BASE_DELAY * 4) 
                    continue 
                
                page += 1
                await asyncio.sleep(RETRY_BASE_DELAY) 
                
                if not has_more:
                    LOG().info("已到达帖子尾页，爬取结束。")
                    break

            # 结束图片下载任务
            LOG().info("所有页面数据已获取，等待图片下载完成...")
            for _ in range(IMAGE_WORKERS):
                img_queue.put_nowait(None)
            await img_queue.join()
            await asyncio.gather(*workers)
            
        LOG().info(f"--- 帖子爬取任务完成: TID {tid} ---")