**Italiano**

Questo modulo consente di generare i file XML della fattura elettronica
versione 1.2

<http://www.fatturapa.gov.it/export/fatturazione/it/normativa/f-2.htm>

da inviare al Sistema di Interscambio (SdI).

<http://www.fatturapa.gov.it/export/fatturazione/it/sdi.htm>

**English**

This module allows you to generate the Electronic Invoice XML files
version 1.2

<http://www.fatturapa.gov.it/export/fatturazione/en/normativa/f-2.htm>

to be sent to the Exchange System (ES).

<http://www.fatturapa.gov.it/export/fatturazione/en/sdi.htm>
