**Italiano**

> - Compilare la fattura con i dati necessari per l'esportazione: per
>   esempio, nella scheda "Fattura elettronica"
> - Selezionare 1 o N fatture ed eseguire la procedura guidata "Esporta
>   fattura elettronica"
> - Per le fatture estere, è possibile inviarle a soli fini fiscali
>   inserendo il codice identificativo XXXXXXX (7 volte X) ed avendo
>   cura di indicare il paese del partner. Le fatture vanno comunque
>   spedite al cliente, ma si evita la predisposizione dell'esterometro.

**English**

> - Fill invoice data you need to export: For instance, in 'Electronic
>   Invoice' tab
> - Select 1 or N invoices and run 'Export Electronic Invoice' wizard
> - For foreign invoices, it is possible to send them only for tax
>   purposes with code XXXXXXX (7 times X) and assuring to set the
>   country of the partner. Invoices must be sent anyway to the
>   customer, but in this way it is not needed to prepare esterometro.
