**Italiano**

Consultare il file README di l10n_it_fatturapa.

É possibile esportare le fatture cliente con le righe articolo con un
CodiceTipo diverso dallo standard 'ODOO' creando un parametro
'fatturapa.codicetipo.odoo' (in Configurazione \> Funzioni tecniche \>
Parametri \> Parametri di sistema) con il codice voluto (tipicamente su
richiesta del cliente). Non è possibile impostare un diverso CodiceTipo
per cliente, al momento.

**English**

See l10n_it_fatturapa README file.

It is possible to export invoices with rows with a different CodiceTipo
from the default 'ODOO' by creating a parameter
'fatturapa.codicetipo.odoo' (in Settings \> Technical \> Parameters \>
System Parameters) with the desired code (tipically on customer's
request). It is not possible to set a different CodiceTipo by customer,
until now.
