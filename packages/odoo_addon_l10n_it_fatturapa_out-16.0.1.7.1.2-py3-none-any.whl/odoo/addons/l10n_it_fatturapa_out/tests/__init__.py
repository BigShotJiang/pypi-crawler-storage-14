# Copyright 2014 Davide Corio

from . import fatturapa_common
from . import test_fatturapa_xml_validation
from . import test_fatturapa_out_noteline
