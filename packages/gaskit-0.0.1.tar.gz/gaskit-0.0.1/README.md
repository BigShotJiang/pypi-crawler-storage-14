# 欢迎使用 gaskit
gaskit是一个气体动力学工具箱，涉及气体动力学中简单的计算，可用于本科大作业如激波膨胀波法求翼型升力系数、阻力系数。

## 功能特点

- **等熵流动**
- **PM膨胀波**
- **平面激波**
- **超声速圆锥扰流**
- **平面异侧波系相交**
- **圆锥激波求解**

## 各模块使用示例

安装

```python
pip install gaskit
```
导入
```python
import gaskit
```
###等熵流动参数求解
```python
result = gaskit.isentropic_flow(Ma2=2.0, Ma1=1.0, gamma=1.4)
print(f"压强比: {result.p2_p1:.4f}")
print(f"温度比: {result.T2_T1:.4f}")
print(f"密度比: {result.rho2_rho1:.4f}")
# 转换为字典格式
result_dict = result.to_dict()
print(result_dict)
```
###P-M膨胀波求解
```python
# Prandtl-Meyer 膨胀波
expansion_result = gaskit.expansion_wave(Ma1=2.0, theta_deg=10.0, gamma=1.4)
print(f"波后马赫数: {expansion_result.Ma2:.4f}")
print(f"压强比: {expansion_result.p2_p1:.4f}")
# 计算 Prandtl-Meyer 角
nu = gaskit.PM_angle(Ma=2.0, gamma=1.4)
print(f"Prandtl-Meyer 角: {np.rad2deg(nu):.2f}°")
```
###平面激波求解
```python
normal_shock = gaskit.normal_shock(Ma1=2.0, gamma=1.4)
print(f"正激波后马赫数: {normal_shock.Ma2:.4f}")
print(f"总压损失: {(1-normal_shock.pt2_pt1)*100:.2f}%")

# 斜激波
weak_shock = gaskit.weak_shock_by_deflection_angle(Ma1=2.0, theta_deg=10.0, gamma=1.4)
print(f"弱激波角: {weak_shock.beta_deg:.2f}°")
print(f"波后马赫数: {weak_shock.Ma2:.4f}")
#还有更多求解斜激波函数,如已知激波角
weak_shock_by_beta=gaskit.shock_by_shock_angle(Ma1=2, beta_deg=40, gamma=1.4)
print(f"气流偏转角:{weak_shock_by_beta.theta_deg:.2f}°")
print(f"波后马赫数: {weak_shock_by_beta.Ma2:.4f}")
#求强解
strong_shock=gaskit.strong_shock_by_deflection_angle(Ma1=3, theta_deg=10, gamma=1.4)
print(f"激波角:{strong_shock.beta_deg}")
print(f"波后马赫数数{strong_shock.Ma2}")
```
###激波相交
```python
# 计算两道异侧激波相交
intersection_result = gaskit.shock_intersect_different_side(
    Ma1=3.0, 
    theta2_deg=10.0,  # 向上偏转
    theta3_deg=15.0,  # 向下偏转
    gamma=1.4
)
# 获取各区域参数
summary = intersection_result.get_region_summary()
for region, params in summary.items():
    print(f"{region}: Ma={params['Ma']:.3f}, p/p1={params['p_p1']:.3f}")
print("------------------------------")
```
###异侧膨胀波与激波相交
```python
Ma1 = 2.0
theta2_deg = 10.0  # 激波楔角
theta3_deg = 15.0  # 总膨胀角
gamma = 1.4
n=10

result, detailed_results = gaskit.shock_expan_intersect_different_side(
    Ma1=Ma1,
    theta2_deg=theta2_deg,
    theta3_deg=theta3_deg,
    n=n,
    gamma=gamma
)
#检查
shock5=result.region5
expan4=result.region4
shock2=result.region2
expan3=result.region3
print(shock5.to_dict())
print(expan4.to_dict())
#验证压力和流向条件
print('--')
print(gaskit.shock_expan_wave_intersect_different_side.validate_intersection_solution(result))
print(shock2.p2_p1*expan4.p2_p1-shock5.p2_p1*expan3.p2_p1,'\n',
      shock2.theta_deg+expan4.theta_deg-(shock5.theta_deg+expan3.theta_deg))
```
###圆锥激波

```python
# 圆锥激波求解
cone_result = gaskit.solve_conical_shock(
    Ma0=2.0,
    cone_half_angle_deg=20.0,
    gamma=1.4,
    #theta_deg=20,#求20°等值线上的参数,不指定则求解壁面的参数
    shock_type='weak'  # 弱激波解
)

print(f"圆锥激波角: {cone_result.beta_deg:.2f}°")
print(f"锥面马赫数: {cone_result.Ma:.4f}")
print(f"锥面压强比: {cone_result.P_P0:.4f}")

# 计算最大半锥角
max_angle, beta_max, theta_max = gaskit.max_cone_half_angle(Ma=2.0, gamma=1.4)
print(f"最大半锥角: {max_angle:.2f}°")
#更多关于圆锥激波求解的函数参见源码
```
由于作者水平有限，库仅提供源码，目前还没撰写参考文档。有问题可联系2805665001@qq.com
若你想参与本工具箱的优化、改进、扩展，可添加qq2805665001

**祝您使用愉快！**