# -*- coding: utf-8 -*-
"""
Created on Tue Nov 25 22:30:09 2025
面向过程的圆锥激波求解
@author: 28056
"""
import numpy as np
from dataclasses import dataclass
from scipy.optimize import fsolve,minimize_scalar,bisect
from scipy.integrate import solve_ivp
from gaskit.shock_wave import(
    shock_max_deflection_angle,
    shock_by_shock_angle,
    shock_min_Ma,
    Ma0_from_down_stream
    )
from gaskit.isentropic_flow import (
    isentropic_flow)
#------------------结果类----------
@dataclass
class ConicalShockResult:
    '''圆锥激波结果类,用于圆锥激波输出给定角度的数据'''
    Ma0:float
    ConeHalfAngle_deg:float
    theta_deg:float#指定角度
    beta_deg:float
    Ma:float
    P_P0:float
    Pt_Pt0:float
    T_T0:float
    rho_rho0:float
    v_v0:float
    gamma:float =1.4
    def __post_init__(self):
        """初始化后计算弧度制值、计算激波角"""
        self.ConeHalfAngle_rad=np.deg2rad(self.ConeHalfAngle_deg)
        self.beta_rad=np.deg2rad(self.beta_deg)
        self.theta_rad=np.deg2rad(self.theta_deg)
    def to_dict(self):
        return {
            'Ma0':self.Ma0,
            'ConeHalfAngle_deg':self.ConeHalfAngle_deg,
            'ConeHalfAngle_rad':self.ConeHalfAngle_rad,
            'beta_deg':self.beta_deg,
            'beta_rad':self.beta_rad,
            'theta_deg':self.theta_deg,
            'theta_rad':self.theta_rad,
            'Ma':self.Ma,
            'P_P0':self.P_P0,
            'Pt_Pt0':self.Pt_Pt0,
            'T_T0':self.T_T0,
            'rho_rho0':self.rho_rho0,
            'v_v0':self.v_v0,
            'gamma':self.gamma
        }

#----------求解函数--------------
def Taylor_Maccoll_equation(x,y,gamma):
        theta=x#theta是弧度制
        u=y[0]
        v=y[1]
        part=( u+v/np.tan(theta) ) / (v**2-1)
        dy1=(v+(gamma-1)/2*u*v*part)
        dy2=-u+( 1+(gamma-1)/2*v**2 )*part
        dy=np.array([dy1,dy2])
        
        if abs(v**2-1)<1e-3:
            #return np.array([v,-u])
            p=0
            dy=np.array([v+(gamma-1)/2*u*v*p,-u+p*(1+(gamma-1)/2*v**2)])
        
        return dy
   
'''
def shock_wave_condition_(Ma,beta_deg,gamma):
    shock_res=shock_by_shock_angle(Ma, beta_deg, gamma)
    rho_rho_beta=1/shock_res.rho2_rho1
    T1_T2=1/shock_res.T2_T1
    beta_rad=np.deg2rad(beta_deg)
    v_beta=-rho_rho_beta*np.sin(beta_rad)*Ma*T1_T2**0.5
    u_beta=Ma*np.cos(beta_rad)*T1_T2**0.5
    #Ma_beta=shock_res.Ma2
    print("直接计算波后马赫数得到Ma{}".format(
        shock_res.Ma2))
    print("uv计算马赫数{}".format(
        pow(u_beta**2+v_beta**2,0.5)))
    return u_beta,v_beta
    '''
    #激波前后参数关系，因为由激波角计算气流偏转角，因此强弱激波的函数关系一致 
def shock_wave_condition(Ma,beta_deg,gamma):
    """激波后马赫数分量计算"""
    shock_res = shock_by_shock_angle(Ma, beta_deg, gamma)
    
    # 激波后总马赫数
    M2 = shock_res.Ma2  # 这是激波后的马赫数
    
    # 气流偏转角
    delta = shock_res.theta_deg
    
    beta_rad = np.deg2rad(beta_deg)
    delta_rad = np.deg2rad(delta)
    
    # 关键：在圆锥坐标系中的马赫数分量
    # 激波角beta是相对于来流方向
    # 激波后气流方向是 (beta - delta)
    # 在圆锥坐标系中：
    # - 径向：沿着锥面射线方向  
    # - 周向：垂直于径向
    
    # 激波后速度方向相对于径向的角度 = (beta - delta)
    M_r = M2 * np.cos(beta_rad - delta_rad)      # 径向马赫数分量
    M_theta = -M2 * np.sin(beta_rad - delta_rad) # 周向马赫数分量（负号因为指向轴心）

    
    return M_r, M_theta,delta

def cone_half_angle_by_beta(Ma,beta_deg,gamma=1.4):#函数序号1
    #给定激波角、来流马赫数，求壁面半锥角

    #初始条件
    u_beta,v_beta,_=shock_wave_condition(Ma,beta_deg,gamma)
    def stop_func(x,y,gamma):
        #这里的积分终止条件是v=0，以确定壁面theta
        #print(y[1])
        return y[1]
    stop_func.terminal = True
    stop_func.direction = 0 
    y0=np.array([u_beta,v_beta])
    y0=y0.reshape((2))
    beta_rad=np.deg2rad(beta_deg)
    beta_rad=float(beta_rad)
    x_span=[beta_rad,0]
    sol = solve_ivp(Taylor_Maccoll_equation, 
                    x_span, 
                    y0, 
                    args=(gamma,),
                    events=stop_func, 
                    rtol=1e-4,
                    atol=1e-4)
    
    return np.rad2deg(sol.t[-1])

def max_cone_half_angle_0(Ma,gamma=1.4):
    """最大半锥角"""
    #给定来流马赫数，求最大的半锥角
    #计算最大的平面波后偏转角
    theta_max_deg,beta_max_deg=shock_max_deflection_angle(Ma, gamma)
    #并非最大激波角，是最大偏转角下的激波角
    #还返回激波当地的气流偏转角
    return cone_half_angle_by_beta(Ma, beta_max_deg,gamma),beta_max_deg,theta_max_deg
def max_cone_half_angle(Ma, gamma=1.4):
    """最大半锥角 - 使用minimize_scalar优化求解
    
    参数:
    ----------
    Ma : float
        来流马赫数
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple : (最大半锥角, 对应激波角, 激波后气流偏转角)
    """
    
    # 定义目标函数：负的半锥角（因为我们要最大化半锥角）
    def objective(beta_deg):
        """目标函数：返回负的半锥角值"""
        try:
            cone_angle = cone_half_angle_by_beta(Ma, beta_deg, gamma)
            # 返回负值，因为minimize_scalar是求最小值
            return -cone_angle
        except (ValueError, TypeError):
            # 如果计算失败，返回一个很大的正值
            return 1e6
    
    # 定义搜索范围
    # 激波角范围：从马赫角到90度
    Ma=float(Ma)
    mach_angle_deg = np.rad2deg(np.arcsin(1/Ma)) if Ma > 1 else 1.0
    bounds = (mach_angle_deg , 90)  # 避免边界值
    
    
    # 使用minimize_scalar求解
    result = minimize_scalar(
        objective,
        bounds=bounds,
        method='bounded',
        options={'xatol': 1e-4, 'maxiter': 100}
    )
    
    if result.success:
        optimal_beta_deg = result.x
        max_cone_angle = -result.fun  # 取负值得到实际的最大半锥角
        
        # 计算对应的激波后气流偏转角
        shock_res = shock_by_shock_angle(Ma, optimal_beta_deg, gamma)
        theta_wave_deg = shock_res.theta_deg
        
        return max_cone_angle, optimal_beta_deg, theta_wave_deg
    else:
        print('优化求解失败')
        return None,None,None
def weak_beta_of_cone(Ma,cone_half_deg,gamma):
    #给顶半锥角，反向求解激波角
    #首先确定是否附体
    #可以按照最大半锥角
    max_cone_half_angle_Ma,beta_max_deg,_=max_cone_half_angle(Ma,gamma)
    #也可以按照最小马赫数
    
    #二分法求激波角
    if cone_half_deg<=max_cone_half_angle_Ma:
        def func(x,Ma,cone_half_deg_target,gamma):
            beta_deg=x#注意是角度
            cone_half_angle_deg=cone_half_angle_by_beta(Ma,beta_deg,gamma)
            equa=cone_half_angle_deg-cone_half_deg_target
            return equa
        a,b=[np.rad2deg(np.arcsin(1/Ma)),beta_max_deg]
        beta_deg=bisect(func, a, b,
                        args=(Ma,cone_half_deg,gamma,)
                        )
        '''
        #fsolve求解，容易跳跃到beta_deg很小甚至为负，并不稳定
        #定义求解方程
        def func(x,Ma,cone_half_deg_target,gamma):
            beta_deg=x#注意是角度
            beta_rad=np.rad2deg(beta_deg)
            # 使用斜激波关系式计算波后马赫数
            part1 = Ma**2 + 2 / (gamma - 1)
            part2 = 2 * gamma / (gamma - 1) * Ma**2 * np.sin(beta_rad)**2 - 1
            part3 = Ma**2 * np.cos(beta_rad)**2
            part4 = (gamma - 1) / 2 * Ma**2 * np.sin(beta_rad)**2 + 1
            Ma2 = part1 / part2 + part3 / part4
            if Ma2<0:
                return 1e6
            else:
                cone_half_angle_deg=cone_half_angle_by_beta(Ma,beta_deg,gamma)  
                return abs(cone_half_angle_deg-cone_half_deg_target)
        
        #使用fsolve求解时的求解初始值   

        cone_half_rad=np.deg2rad(cone_half_deg)
        beta_rad0=cone_half_rad*\
        (gamma+1)/(gamma+3)*\
            ( 1+np.sqrt( 1+ 2*(gamma+3)/pow( (gamma+1)*Ma*cone_half_rad ,2) ) )
        beta_deg0=np.rad2deg(beta_rad0)
        #如果接近脱体，求解会变得很慢，这里进行提前预估
        if  max_cone_half_angle_Ma-cone_half_deg<1:
            beta_deg0=beta_max_deg
        
        #使用fsolve可能出现beta为负
        res=fsolve(func,
                   beta_deg0,
                   args=(Ma,cone_half_deg,gamma,),
                   xtol=1e-4)#求解过程对初值极其敏感，并非求不对
        beta_deg=res[0]
        '''
        
        '''
        #使用minimize_scalar求解
        #设置边界
        bounds=[np.rad2deg(np.arcsin(1/Ma)),beta_max_deg]
        result=minimize_scalar(func, 
                        args=(Ma,cone_half_deg,gamma),
                        bounds=bounds,
                        options={'xatol': 1e-4, 'maxiter': 500}
                        )
        beta_deg=result.x
        '''
        return beta_deg
    else:
        print('半锥角过大，激波脱体')
        return None
def weak_beta_of_cone_2(Ma,cone_half_deg,gamma):
    #通过计算壁面v来建立方程
    def func(x,Ma,cone_half_deg,gamma):
        beta_deg=x#注意是角度
        u_cone,v_cone=uv_from_shock(Ma,
                            beta_deg,
                            cone_half_deg,
                            #theta_deg,
                            cone_half_deg,
                            gamma)
        print("beta_deg={},u={},v={}".format(beta_deg,
                                   u_cone,
                                   v_cone
            ))
        return v_cone
    #求解初始值
    cone_half_rad=np.deg2rad(cone_half_deg)
    beta_rad0=cone_half_rad*\
    (gamma+1)/(gamma+3)*\
        ( 1+np.sqrt( 1+ 2*(gamma+3)/pow( (gamma+1)*Ma*cone_half_rad ,2) ) )
    beta_deg0=np.rad2deg(beta_rad0)
    #使用激波角作为初值可能出现圆锥激波附体，但恰好锥角作为平面楔角的激波脱体
    #如果初始解导致v=-1，迭代会自动停止
    
    res=fsolve(func,
               beta_deg0,
               args=(Ma,cone_half_deg,gamma,),
               xtol=1e-4)
    return res[0]
'''
def uv_from_cone(theta_deg,cone_half_angle_deg,u,v,gamma,stop_func=None):
    #给定壁面uv,求指定角度处的uv
    y0=np.array([u,v])#壁面处v=0
    y0=y0.reshape((1,2))
    x_span=[cone_half_angle_deg,theta_deg]
    x_span=np.array(x_span)
    sol = solve_ivp(Taylor_Maccoll_equation, 
                    x_span, 
                    y0, 
                    args=(gamma,),
                    dense_output=True,
                    stop_func=stop_func,
                    rtol=1e-4)
    uv=sol.y
    u_theta=uv[-1][0]
    v_theta=uv[-1][1]
    return u_theta,v_theta
'''
def stop_func_from_cone(x,y,Ma,gamma):
    #判断来流和波后参数恰好满足激波关系
    theta_deg=np.rad2deg(x)
    u_beta,v_beta,_=shock_wave_condition(Ma,theta_deg,gamma)
    #以当前角度为激波角计算波后参数
    u=y[0]
    v=y[1]
    delta=pow(u**2+v**2,0.5)-pow(u_beta**2+v_beta**2,0.5)
    return delta
def intergrate_from_cone(u,Ma,cone_half_deg,gamma):
    """从壁面积分的函数,终止条件为当地的参数和来流参数恰好满足激波关系

    参数:
    ----------
    u:float
        壁面径向马赫数
    Ma : float
        来流马赫数
    cone_half_deg:float
        半锥角
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple : (激波角, 波后径向马赫数u,波后周向马赫数v)
    """
    #编写从壁面积分的函数,终止条件为当地的参数和来流参数恰好满足激波关系
    #theta_deg_max=weak_shock_angle(Ma,cone_half_deg,gamma)
    theta_deg_max=90
    #由于终止条件用到了来流马赫数作为参数，定义的微分方程也要加参数
    #只需要在原方程上加参数Ma即可，虽然用不到
    def func_intergrate(x,y,Ma,gamma):
        dy=Taylor_Maccoll_equation(x,y,gamma)
        return dy
    u=np.array(u)#防止u不是数组的情况
    y0=np.append(u, 0)
    x_span=[cone_half_deg,theta_deg_max]
    x_span=np.deg2rad(x_span)
    def stop_func(x,y,Ma,gamma):
        return stop_func_from_cone(x,y,Ma,gamma)
    stop_func.terminal = True
    stop_func.direction = 0 
    sol = solve_ivp(func_intergrate, 
                    x_span, 
                    y0, 
                    args=(Ma,gamma,),
                    dense_output=True,
                    events=stop_func,
                    rtol=1e-4)
    #自变量最后的值，若不是90°对应位置，则积分成功停止
    #如果返回自变量数值求解u时函数不连续，容易发散
    uv_beta=sol.y[:][-1]
    u=uv_beta[0]
    v=uv_beta[1]
    beta_rad=sol.t[-1]
    return beta_rad,u,v
#从壁面积分到满足激波条件的方式
def beta_from_cone(Ma,cone_half_deg,gamma):
    #从壁面积分的方式求解激波角
    """从壁面积分的方式求解激波角

    参数:
    ----------
    Ma : float
        来流马赫数
    cone_half_deg:float
        半锥角
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple : (波后马赫数, 对应激波角, 激波后气流偏转角)
    """
    def func_u(u,Ma,cone_half_deg,gamma):
        theta_rad_last,y_last=intergrate_from_cone(u,Ma,cone_half_deg,gamma)
        delta=stop_func_from_cone(theta_rad_last,y_last,Ma,gamma)
        print("u0={}积分最终角度 {},delta {}".format(u,
                                               np.rad2deg(theta_rad_last),
                                               delta)
              )
        return delta
    u0=Ma
    res=fsolve(func_u,
               u0,
               args=(Ma,cone_half_deg,gamma),
               )
    u=res[0]#得到u之后再进行一次求解
    beta_rad,u,v=intergrate_from_cone(u,Ma,cone_half_deg,gamma)
    Ma_beta=pow(u**2+v**2,0.5)
    beta_deg=np.rad2deg(beta_rad)
    theta_rad=beta_rad-np.arctan(abs(v/u))
    theta_deg=np.rad2deg(theta_rad)
    return Ma_beta,beta_deg,theta_deg

                
    

def uv_from_shock(Ma,beta_deg,cone_half_angle_deg,theta_deg,gamma):
    #已知马赫数、激波角、半锥角、求指定位置theta_deg的分量马赫数()
    #微分方程
    if theta_deg>=cone_half_angle_deg and theta_deg<=beta_deg:
        #判断角度是否在合理范围
        #初始条件
        u_beta,v_beta,_=shock_wave_condition(Ma,beta_deg,gamma)
        y0=np.array([u_beta,v_beta])
        y0=y0.reshape((2))
        #积分区间
        #在被fsolve调用时，beta_deg是一个数组
        beta_rad=np.deg2rad(beta_deg)
        if type(beta_rad)==np.ndarray:
            beta_rad=beta_rad[0]
        theta_rad=np.array(np.deg2rad(theta_deg))
        x_span=np.array([beta_rad,theta_rad])
        sol = solve_ivp(Taylor_Maccoll_equation, 
                        x_span, 
                        y0, 
                        args=(gamma,),
                        dense_output=True,
                        rtol=1e-4)
        y=sol.y
        u_theta=y[0][-1]
        v_theta=y[1][-1]
        return u_theta,v_theta
    else:
        print('角度不在合理范围')
        return None,None
def strong_beta_of_cone(Ma,cone_half_deg,gamma):
    #强激波情况
    #给定半锥角，反向求解激波角
    #定义求解方程
    def func(x,Ma,cone_half_deg,gamma):
        beta_deg=x#注意是角度
        u_cone,v_cone=uv_from_shock(Ma,
                            beta_deg,
                            cone_half_deg,
                            #theta_deg,
                            cone_half_deg,
                            gamma)
        '''
        print("beta_deg={},u={},v={}".format(beta_deg,
                                   u_cone,
                                   v_cone
                                   ))
        '''
        return v_cone
    #求解初始值
    '''
    beta_deg0=strong_shock_angle(Ma,cone_half_deg,gamma)
    if beta_deg0==None:
        beta_deg0=90
        '''
    max_cone_half_angle_Ma,beta_max_deg,_=max_cone_half_angle(Ma,gamma)
    #beta_deg0=(beta_max_deg+90)/2
    beta_deg0=90
    res=fsolve(func,beta_deg0,
               args=(Ma,cone_half_deg,gamma,),
               xtol=1e-4)
    return res[0]

#给定半锥角，求最小马赫数
def min_Ma_cone_0(cone_half_deg,gamma=1.4):
    
    #在临界条件下，激波当地的气流偏转角小于半锥角,激波角、来流最小马赫数、对应气流偏转角一一对应
    #满足临界条件后，进行积分，要满足边界条件v=0
    def func(theta_deg_cri,cone_half_deg,gamma):
        Ma_cri,beta_deg_cri=shock_min_Ma(theta_deg_cri,gamma)
        #对微分方程积分,最终得到壁面的速度v=0
        u,v=uv_from_shock(Ma_cri,beta_deg_cri,cone_half_deg,cone_half_deg,gamma)
        return v
    theta_deg_cri0=0
    res=fsolve(func, theta_deg_cri0,args=(cone_half_deg,gamma,))
    theta_deg_cri=res[0]
    Ma_cri,beta_deg_cri=shock_min_Ma(theta_deg_cri,gamma)
    
    return Ma_cri,beta_deg_cri,theta_deg_cri
#用理论的精确解所得最小马赫数偏大，还是采用优化算法
def Ma0_from_cone(u,cone_half_deg,beta_deg,gamma=1.4):
    """指定激波角、半锥角及其径向马赫数，积分后求其波前马赫数
    输入:
        u:float
            锥面径向马赫数
        cone_half_deg:float
            半锥角
        beta_deg:float
            激波角
    输出：
        Ma0:float
            波前马赫数    
    """
    theta_span=np.deg2rad([cone_half_deg,beta_deg])
    
    sol=solve_ivp(Taylor_Maccoll_equation,
              theta_span,
              [u,0],
              args=(gamma,),
              )
    uv_beta=sol.y[:,-1]
    u=uv_beta[0]
    v=uv_beta[1]
    Ma_down=pow(u**2+v**2,0.5)
    Ma0=Ma0_from_down_stream(Ma_down,beta_deg,gamma)
    return Ma0
def min_Ma_cone(cone_half_deg, gamma=1.4):
    """最大半锥角 - 使用minimize_scalar优化求解
    
    参数:
    ----------
    Ma : 半锥角
    
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple : (最小马赫数, 对应激波角, 激波后气流偏转角)
    """
    #
    def func(Ma,cone_half_deg,gamma):
        Ma=float(Ma)
        max_cone_half_deg,_,_=max_cone_half_angle(Ma, gamma)
        return cone_half_deg-max_cone_half_deg
    x0,_,_=min_Ma_cone_0(cone_half_deg,gamma)
    res=fsolve(func, 
           x0,
           args=(cone_half_deg,gamma)
           )
    Ma=res[0]
    max_cone_half_deg,beta_deg,theta_deg=max_cone_half_angle(Ma, gamma)
    return Ma,beta_deg,theta_deg
    
def solve_conical_shock(Ma0, cone_half_angle_deg, gamma=1.4, shock_type='weak', theta_deg=None):
    """
    完整的圆锥激波求解函数
    
    参数:
    ----------
    Ma0 : float
        来流马赫数
    cone_half_angle_deg : float
        半锥角（度）
    gamma : float, optional
        比热比，默认为1.4
    shock_type : str, optional
        激波类型，'weak' 或 'strong'，默认为'weak'
    theta_deg : float, optional
        指定角度位置（度），如果为None则计算壁面处结果
    
    返回:
    -------
    ConicalShockResult
        包含所有圆锥激波参数的结果类
    """
    
    # 如果没有指定角度，默认为壁面角度
    if theta_deg is None:
        theta_deg = cone_half_angle_deg
    
    # 检查激波是否附体
    max_cone_angle, beta_max_deg ,_= max_cone_half_angle(Ma0, gamma)
    #----------------------------------------------暂时取消---------------
    if cone_half_angle_deg > max_cone_angle:
       raise ValueError(f"半锥角{cone_half_angle_deg}°过大，超过最大半锥角{max_cone_angle:.2f}°，激波脱体")
    
    # 根据激波类型求解激波角
    if shock_type == 'weak':
        beta_deg = weak_beta_of_cone(Ma0, cone_half_angle_deg, gamma)
    elif shock_type == 'strong':
        beta_deg = strong_beta_of_cone(Ma0, cone_half_angle_deg, gamma)
    else:
        raise ValueError("shock_type必须是'weak'或'strong'")
    
    if beta_deg is None:
        raise ValueError("无法求解激波角，请检查输入参数")
    
    # 计算指定角度处的流动参数
    u_theta, v_theta = uv_from_shock(Ma0, beta_deg, cone_half_angle_deg, theta_deg, gamma)
    
    if u_theta is None or v_theta is None:
        raise ValueError(f"在角度{theta_deg}°处无法计算流动参数")
    
    # 计算当地马赫数,这里是指定角度的值
    Ma_theta = np.sqrt(u_theta**2 + v_theta**2)#正确
    # 计算激波前后的参数比
    shock_result = shock_by_shock_angle(Ma0, beta_deg, gamma)
    Ma_beta=shock_result.Ma2#波后马赫数
    #激波到指定角度为等熵流动,现在已知两者的马赫数
    #先计算激波前后参数比
    # 计算相对于来流的总参数比
    
    # 激波前后总压比
    Pt_Pt0= shock_result.pt2_pt1#等熵流动不改变总压
    
    # 激波前后静压比
    P_P0_beta = shock_result.p2_p1
    
    # 激波前后温度比  
    T_T0_beta = shock_result.T2_T1
    
    # 激波前后密度比
    rho_rho0_beta = shock_result.rho2_rho1
    
    #再计算等熵流动
    isen_beta2theta=isentropic_flow(Ma_theta, Ma_beta, gamma)
    P_P0=isen_beta2theta.p2_p1*P_P0_beta
    T_T0=isen_beta2theta.T2_T1*T_T0_beta
    rho_rho0=isen_beta2theta.rho2_rho1*rho_rho0_beta
    v_v0=Ma_theta/Ma0*(T_T0**0.5)
    # 创建结果对象
    result = ConicalShockResult(
        Ma0=Ma0,
        ConeHalfAngle_deg=cone_half_angle_deg,
        theta_deg=theta_deg,
        beta_deg=beta_deg,
        Ma=Ma_theta,
        P_P0=P_P0,
        Pt_Pt0=Pt_Pt0,
        T_T0=T_T0,
        rho_rho0=rho_rho0,
        v_v0=v_v0,
        gamma=gamma
    )
    
    return result

