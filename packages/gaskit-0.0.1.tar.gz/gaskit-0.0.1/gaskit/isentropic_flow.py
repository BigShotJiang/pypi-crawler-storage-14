# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 21:34:50 2025
#等熵关系求解，模块先后编写序号1
@author: 28056
"""

from dataclasses import dataclass
'''
-----------------数据类定义---------------
'''
@dataclass
class IsentropicFlowResult:
    """等熵流动结果类"""
    Ma1: float  # 波前马赫数
    Ma2: float  # 波后马赫数
    p2_p1: float  # 波后/波前压强比
    T2_T1: float  # 波后/波前温度比
    rho2_rho1: float  # 波后/波前密度比
    pt2_pt1: float = None  # 波后/波前总压比
    v2_v1: float = None  # 波后/波前速度比
    gamma: float = 1.4  # 比热比
    
    def to_dict(self):
        """转换为字典"""
        result = {
            'Ma1': self.Ma1,
            'Ma2': self.Ma2,
            'p2_p1': self.p2_p1,
            'T2_T1': self.T2_T1,
            'rho2_rho1': self.rho2_rho1,
            'gamma': self.gamma
        }
        if self.pt2_pt1 is not None:
            result['pt2_pt1'] = self.pt2_pt1
        if self.v2_v1 is not None:
            result['v2_v1'] = self.v2_v1
        return result

'''
----------------等熵关系式部分-------------
'''
def isentropic_p_ratio(Ma2, Ma1, gamma=1.4):
    """等熵流压比 p2/p1"""
    part1 = 2 + (gamma - 1) * Ma1**2
    part2 = 2 + (gamma - 1) * Ma2**2
    part3 = gamma / (gamma - 1)
    return (part1 / part2) ** part3

def isentropic_T_ratio(Ma2, Ma1, gamma=1.4):
    """等熵流温度比 T2/T1"""
    part1 = 2 + (gamma - 1) * Ma1**2
    part2 = 2 + (gamma - 1) * Ma2**2
    return part1 / part2

def isentropic_rho_ratio(Ma2, Ma1, gamma=1.4):
    """等熵流密度比 rho2/rho1"""
    part1 = 2 + (gamma - 1) * Ma1**2
    part2 = 2 + (gamma - 1) * Ma2**2
    return (part1 / part2) ** (1 / (gamma - 1))

def isentropic_flow(Ma2, Ma1, gamma=1.4):
    p2_p1 = isentropic_p_ratio(Ma2, Ma1, gamma)
    T2_T1 = isentropic_T_ratio(Ma2, Ma1, gamma)
    rho2_rho1 = isentropic_rho_ratio(Ma2, Ma1, gamma)
    v2_v1 = Ma2 / Ma1 * T2_T1**0.5
    pt2_pt1 = 1
    return IsentropicFlowResult(Ma2,
                                Ma1,
                                p2_p1,
                                T2_T1,
                                rho2_rho1,
                                pt2_pt1,
                                v2_v1,
                                gamma
                                )

