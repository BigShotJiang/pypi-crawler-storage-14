# -*- coding: utf-8 -*-
"""
Created on Fri Nov  7 08:17:51 2025
激波-膨胀波相交求解模块
@author: 28056
"""
import numpy as np
from scipy.optimize import fsolve
from gaskit.shock_wave import(
    weak_shock_by_deflection_angle,
    shock_by_shock_angle,
    ShockWaveResult
    )
from gaskit.expansion_wave import (
    expansion_wave,
    ExpansionWaveResult)
from gaskit.shock_intersect_different_side import(
    WaveIntersectionResult)

def shock_little_expan_intersect_different_side(Ma1, theta2_deg, delta_expan_deg, gamma=1.4):
    """
    小角度膨胀波与激波异侧相交的局部求解
    
    用于求解一个小的膨胀波段与激波相交的情况，这是大角度膨胀波分解的基础单元
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta2_deg : float
        激波对应的楔角（度）
    delta_expan_deg : float
        小膨胀波段的偏转角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    WaveIntersectionResult
        包含四个区域流动参数的结果对象
        
    区域说明:
    ----------
    区域1: 来流区域
    区域2: 激波后区域  
    区域3: 膨胀波后区域
    区域4: 二次膨胀后区域（区域2经过膨胀）
    区域5: 二次激波后区域（区域3经过激波）
    """
    
    shock2 = weak_shock_by_deflection_angle(Ma1, theta2_deg, gamma)
    expanwave3 = expansion_wave(Ma1, delta_expan_deg, gamma)
    
    theta2_deg = shock2.theta_deg
    theta3_deg = expanwave3.theta_deg
    p2_p1 = shock2.p2_p1
    p3_p1 = expanwave3.p2_p1
    
    def equation(x, args):
        """流向和压强匹配"""
        
        Ma2, theta2_deg, p2_p1, Ma3, theta3_deg, p3_p1 = args
        theta4_deg, beta5_deg = x[0:2] 
        
        if theta4_deg<0 or beta5_deg<0:
            return [1e6,1e6]
        else:   
            # 计算二次膨胀波 -
            expanwave4 = expansion_wave(Ma2, theta4_deg, gamma)
            
            # 计算二次激波
            shock5 = shock_by_shock_angle(Ma3, beta5_deg, gamma)
            
            # 压力连续条件
            p4_p5 = (expanwave4.p2_p1 * p2_p1) / (shock5.p2_p1 * p3_p1)
            
            # 流动方向连续条件
            flow_angle_4 = -theta2_deg - expanwave4.theta_deg
            flow_angle_5 = -theta3_deg - shock5.theta_deg
            
            return [p4_p5 - 1, flow_angle_4 - flow_angle_5]
    
    
    x0 = np.array([0,shock2.beta_deg])
    
    args = [shock2.Ma2, theta2_deg, p2_p1, expanwave3.Ma2, theta3_deg, p3_p1]
    
    solution = fsolve(equation, x0, args=args, xtol=1e-6)
    theta4_deg, beta5_deg = solution

    
    # 计算最终结果
    expanwave4 = expansion_wave(shock2.Ma2, theta4_deg, gamma)
    shock5 = shock_by_shock_angle(expanwave3.Ma2, beta5_deg, gamma)
    
    # 创建相对于来流的全局参数
    shock4_global = ExpansionWaveResult(
        theta4_deg,
        shock2.Ma2,
        expanwave4.Ma2,
        expanwave4.p2_p1,
        expanwave4.T2_T1,
        expanwave4.rho2_rho1,
        expanwave4.v2_v1,
        gamma
    )
    
    shock5_global = ShockWaveResult(
        shock5.theta_deg,
        shock5.beta_deg,
        Ma1,  # 来流马赫数
        shock5.Ma2,
        shock5.p2_p1,
        shock5.T2_T1,
        shock5.rho2_rho1,
        shock5.pt2_pt1,
        shock5.v2_v1,
        gamma
    )
    
    return WaveIntersectionResult(shock2, expanwave3, shock4_global, shock5_global)


def shock_expan_intersect_different_side(Ma1, theta2_deg, theta3_deg, n, gamma=1.4):
    """
    大角度膨胀波与激波异侧相交的完整求解
    
    将大角度膨胀波分解为n个小角度膨胀波，逐步求解每个小波与激波的相互作用
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta2_deg : float
        激波对应的楔角（度）
    theta3_deg : float
        总膨胀波偏转角（度）
    n : int
        膨胀波分解的段数
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple
        (WaveIntersectionResult, list)
        - 简化的整体结果
        - 详细的逐步计算结果列表
        
    物理过程:
    ----------
    1. 来流Ma1遇到楔角theta2产生激波（1→2）
    2. 来流Ma1遇到膨胀角theta3产生膨胀波（1→3）  
    3. 激波和膨胀波相交后：
       - 区域2的气流继续膨胀（2→4）
       - 区域3的气流遇到二次激波（3→5）
    4. 区域4和区域5必须满足压力和流动方向连续条件
    """
    
    # 保存当前马赫数和角度用于迭代
    Ma1_i = Ma1
    theta2_deg_i = theta2_deg  # 每次迭代都要重置
    
    # 计算总的激波和膨胀波（用于最终结果）
    shock2_total = weak_shock_by_deflection_angle(Ma1, theta2_deg, gamma)  # 1-2区之间为激波
    expanwave3_total = expansion_wave(Ma1, theta3_deg, gamma)              # 1-3区之间为膨胀波
    
    # 将总膨胀波分解为n个小段
    delta_expan_deg = theta3_deg / n
    
    # 存储每一步的详细结果
    res_n = []
    
    # 逐步求解每个小膨胀波段
    for i in range(1, n + 1):
        res_i = shock_little_expan_intersect_different_side(
            Ma1_i, 
            theta2_deg_i,
            delta_expan_deg,
            gamma
        )
        
        # 更新下一轮的初始条件
        expanwave3 = res_i.region3  # 当前小膨胀波后的区域
        shock5 = res_i.region5      # 当前二次激波后的区域
        
        Ma1_i = expanwave3.Ma2      # 更新来流马赫数为当前膨胀波后马赫数
        theta2_deg_i = shock5.theta_deg  # 更新楔角为当前二次激波偏转角
        
        res_n.append(res_i)
    
    # 计算区域4的累计参数（所有小膨胀波的累积效果）
    theta4_rad_total = 0        # 总偏转角（弧度）
    p4_p2_total = 1.0           # 总压强比
    T4_T2_total = 1.0           # 总温度比  
    rho4_rho2_total = 1.0       # 总密度比
    v4_v2_total = 1.0           # 总速度比
    
    # 累加所有小膨胀波的影响
    for j in range(len(res_n)):
        res_j = res_n[j]
        theta4_rad_total += res_j.region4.theta_rad
        p4_p2_total *= res_j.region4.p2_p1
        T4_T2_total *= res_j.region4.T2_T1
        rho4_rho2_total *= res_j.region4.rho2_rho1
        v4_v2_total *= res_j.region4.v2_v1
    
    # 创建区域4的总体膨胀波结果
    # 使用最后一个结果的马赫数作为区域4的最终马赫数
    final_Ma4 = res_n[-1].region4.Ma2 if res_n else shock2_total.Ma2
    
    expanwave4_total = ExpansionWaveResult(
        np.rad2deg(theta4_rad_total),      # 总偏转角（度）
        shock2_total.Ma2,                  # 起始马赫数（区域2马赫数）
        final_Ma4,                         # 最终马赫数（区域4马赫数）
        p4_p2_total,                       # 总压强比
        T4_T2_total,                       # 总温度比
        rho4_rho2_total,                   # 总密度比
        v4_v2_total,                       # 总速度比
        gamma
    )
    
    # 区域5使用最后一个二次激波的结果
    shock5_final = res_n[-1].region5 if res_n else None
    
    return WaveIntersectionResult(shock2_total, expanwave3_total, expanwave4_total, shock5_final), res_n


def validate_intersection_solution(intersection_result):
    """
    验证激波-膨胀波相交解的合理性
    
    参数:
    ----------
    intersection_result : WaveIntersectionResult
        相交计算结果
        
    返回:
    -------
    dict
        验证结果字典
    """
    result = intersection_result
    
    # 检查压力连续性
    p4 = result.region2.p2_p1 * result.region4.p2_p1  # p4/p1
    p5 = result.region3.p2_p1 * result.region5.p2_p1  # p5/p1
    pressure_error = abs(p4 - p5) / p4 * 100  # 百分比误差
    
    # 检查流动方向连续性
    flow_angle_4 = -(result.region2.theta_rad + result.region4.theta_rad)
    flow_angle_5 = -(result.region3.theta_rad + result.region5.theta_rad)
    angle_error_deg = np.rad2deg(abs(flow_angle_4 - flow_angle_5))
    
    validation = {
        'pressure_continuity': {
            'p4/p1': p4,
            'p5/p1': p5,
            'error_percent': pressure_error,
            'is_acceptable': pressure_error < 1.0  # 1%误差容限
        },
        'flow_angle_continuity': {
            'angle_4_deg': np.rad2deg(flow_angle_4),
            'angle_5_deg': np.rad2deg(flow_angle_5),
            'error_deg': angle_error_deg,
            'is_acceptable': angle_error_deg < 0.1  # 0.1度误差容限
        },
        'overall_valid': pressure_error < 1.0 and angle_error_deg < 0.1
    }
    
    return validation
