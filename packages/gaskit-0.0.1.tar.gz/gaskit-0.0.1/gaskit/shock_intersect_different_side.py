# -*- coding: utf-8 -*-
"""
Created on Fri Nov  7 08:10:49 2025
异侧激波相交函数
@author: 28056
"""
import numpy as np
from dataclasses import dataclass
from scipy.optimize import fsolve
from gaskit.shock_wave import(
    weak_shock_by_deflection_angle,
    shock_by_shock_angle,
    ShockWaveResult
    )


@dataclass
class WaveIntersectionResult:
    """波系相交结果类，用于存储异侧激波相交的所有区域参数"""
    region2: object  # 第一道波后的区域（激波2后）
    region3: object  # 第二道波后的区域（激波3后）  
    region4: object  # 相交后第一道波后的区域（激波4后）
    region5: object  # 相交后第二道波后的区域（激波5后）
    
    def to_dict(self):
        """转换为嵌套字典格式，便于输出和存储"""
        result = {}
        
        for region_name in ['region2', 'region3', 'region4', 'region5']:
            region_obj = getattr(self, region_name)  # 获取属性
            if hasattr(region_obj, 'to_dict'):       # 判断是否含有to_dict方法
                result[region_name] = region_obj.to_dict()
            else:
                result[region_name] = region_obj
                
        return result
    
    def get_region_summary(self):
        """获取各区域的简要参数摘要"""
        summary = {}
        for region_name in ['region2', 'region3', 'region4', 'region5']:
            region_obj = getattr(self, region_name)
            if hasattr(region_obj, 'Ma2') and hasattr(region_obj, 'p2_p1'):
                summary[region_name] = {
                    'Ma': region_obj.Ma2,
                    'p_p1': region_obj.p2_p1,
                    'theta_deg': getattr(region_obj, 'theta_deg', 'N/A')
                }
        return summary


def shock_intersect_different_side(Ma1, theta2_deg, theta3_deg, gamma=1.4):
    """
    异侧激波相交求解：计算两道来自不同方向的激波相交后的流场
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta2_deg : float
        第一道激波对应的楔角（度），正值表示向上偏转
    theta3_deg : float  
        第二道激波对应的楔角（度），正值表示向下偏转
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    WaveIntersectionResult
        包含四个区域流动参数的结果对象
        
    区域说明:
    ----------
    区域1: 来流区域 (Ma1, p1, T1)
    区域2: 第一道激波后区域 (激波2: 1→2)
    区域3: 第二道激波后区域 (激波3: 1→3)  
    区域4: 相交后第一道激波后的区域 (激波4: 2→4)
    区域5: 相交后第二道激波后的区域 (激波5: 3→5)
    
    物理条件:
    ----------
    1. 压力连续: p4 = p5
    2. 流动方向连续: 区域4和区域5的流动方向相同
    
    注意:
    ----------
    假设两道激波都是弱激波解
    """
    
    # 计算初始的两道激波
    shock2 = weak_shock_by_deflection_angle(Ma1, theta2_deg, gamma)  # 激波2: 1→2
    shock3 = weak_shock_by_deflection_angle(Ma1, theta3_deg, gamma)  # 激波3: 1→3
    
    if shock2 is None or shock3 is None:
        raise ValueError("无法形成附体激波，请检查楔角是否过大")
    
    def equation(x, args):
        """
        求解激波相交的方程组
        
        方程组包含两个方程：
        1. 压力连续方程：p4 = p5
        2. 流动方向连续方程：流动方向4 = 流动方向5
        
        参数:
        ----------
        x : list
            待求解变量 [beta4_deg, beta5_deg]
            - beta4_deg: 激波4的激波角（度）
            - beta5_deg: 激波5的激波角（度）
        args : list
            参数列表 [Ma2, theta2_deg, p2_p1, Ma3, theta3_deg, p3_p1]
            
        返回:
        -------
        list
            方程残差 [压力残差, 流动方向残差]
        """
        Ma2, theta2_deg, p2_p1, Ma3, theta3_deg, p3_p1 = args
        beta4_deg, beta5_deg = x
        
        # 计算二次激波4 (区域2 → 区域4)
        shock4 = shock_by_shock_angle(Ma2, beta4_deg, gamma)
        
        # 计算二次激波5 (区域3 → 区域5)
        shock5 = shock_by_shock_angle(Ma3, beta5_deg, gamma)
        
        # 方程1: 压力连续条件 p4 = p5
        # p4 = p1 * (p2/p1) * (p4/p2) = p1 * p2_p1 * shock4.p2_p1
        # p5 = p1 * (p3/p1) * (p5/p3) = p1 * p3_p1 * shock5.p2_p1
        p4_p5 = (shock4.p2_p1 * p2_p1) / (shock5.p2_p1 * p3_p1)
        
        # 方程2: 流动方向连续条件
        # 区域4流动方向 = -第一道激波偏转角 + 第二道激波偏转角
        flow_angle_4 = -np.deg2rad(theta2_deg) + shock4.theta_rad
        # 区域5流动方向 = 第二道激波偏转角 - 第三道激波偏转角  
        flow_angle_5 = np.deg2rad(theta3_deg) - shock5.theta_rad
        
        return [p4_p5 - 1, flow_angle_4 - flow_angle_5]
    
    # 初始猜测值（角度制）
    x0 = [45.0, 45.0]  # [beta4_deg, beta5_deg]
    
    # 准备求解参数
    args = [
        shock2.Ma2,        # 区域2马赫数
        theta2_deg,        # 第一道激波楔角
        shock2.p2_p1,      # 激波2的压强比
        shock3.Ma2,        # 区域3马赫数  
        theta3_deg,        # 第二道激波楔角
        shock3.p2_p1       # 激波3的压强比
    ]
    
    # 求解方程组
    beta4_deg, beta5_deg = fsolve(equation, x0, args)
    
    # 用求解得到的参数计算最终的激波
    shock4 = shock_by_shock_angle(shock2.Ma2, beta4_deg, gamma)  # 激波4: 2→4
    shock5 = shock_by_shock_angle(shock3.Ma2, beta5_deg, gamma)  # 激波5: 3→5
    
    # 创建相对于来流的全局参数结果（便于比较）
    shock4_global = ShockWaveResult(
        shock4.theta_deg,      # 偏转角
        shock4.beta_deg,       # 激波角  
        Ma1,                   # 来流马赫数
        shock4.Ma2,            # 波后马赫数
        shock4.p2_p1,          # 压强比（相对于区域2）
        shock4.T2_T1,          # 温度比（相对于区域2）
        shock4.rho2_rho1,      # 密度比（相对于区域2）
        shock4.pt2_pt1,        # 总压比（相对于区域2）
        shock4.v2_v1,          # 速度比（相对于区域2）
        gamma
    )
    
    shock5_global = ShockWaveResult(
        shock5.theta_deg,      # 偏转角
        shock5.beta_deg,       # 激波角
        Ma1,                   # 来流马赫数  
        shock5.Ma2,            # 波后马赫数
        shock5.p2_p1,          # 压强比（相对于区域3）
        shock5.T2_T1,          # 温度比（相对于区域3）
        shock5.rho2_rho1,      # 密度比（相对于区域3）
        shock5.pt2_pt1,        # 总压比（相对于区域3）
        shock5.v2_v1,          # 速度比（相对于区域3）
        gamma
    )
    
    return WaveIntersectionResult(shock2, shock3, shock4_global, shock5_global)


def validate_shock_intersection(result, tolerance_p=0.01, tolerance_angle=0.1):
    """
    验证激波相交解的合理性
    
    参数:
    ----------
    result : WaveIntersectionResult
        激波相交计算结果
    tolerance_p : float, optional
        压力连续性容差（百分比），默认为1%
    tolerance_angle : float, optional  
        角度连续性容差（度），默认为0.1度
        
    返回:
    -------
    dict
        验证结果字典
    """
    # 计算区域4和区域5的绝对压强（相对于来流）
    p4_p1 = result.region2.p2_p1 * result.region4.p2_p1
    p5_p1 = result.region3.p2_p1 * result.region5.p2_p1
    
    # 压力连续性误差
    pressure_error = abs(p4_p1 - p5_p1) / p4_p1 * 100
    
    # 流动方向连续性
    flow_angle_4 = -np.deg2rad(result.region2.theta_deg) + result.region4.theta_rad
    flow_angle_5 = np.deg2rad(result.region3.theta_deg) - result.region5.theta_rad
    angle_error_deg = np.rad2deg(abs(flow_angle_4 - flow_angle_5))
    
    validation = {
        'pressure_continuity': {
            'p4/p1': p4_p1,
            'p5/p1': p5_p1,
            'error_percent': pressure_error,
            'is_acceptable': pressure_error <= tolerance_p
        },
        'flow_angle_continuity': {
            'angle_4_deg': np.rad2deg(flow_angle_4),
            'angle_5_deg': np.rad2deg(flow_angle_5),
            'error_deg': angle_error_deg,
            'is_acceptable': angle_error_deg <= tolerance_angle
        },
        'overall_valid': (pressure_error <= tolerance_p and 
                         angle_error_deg <= tolerance_angle)
    }
    
    return validation


def shock_intersection_analysis(Ma1, theta2_deg, theta3_deg, gamma=1.4):
    """
    激波相交综合分析：计算并验证激波相交结果
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta2_deg : float
        第一道激波楔角（度）
    theta3_deg : float
        第二道激波楔角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple
        (WaveIntersectionResult, dict, dict)
        - 相交计算结果
        - 验证结果
        - 区域摘要
    """
    # 计算激波相交
    result = shock_intersect_different_side(Ma1, theta2_deg, theta3_deg, gamma)
    
    # 验证解的合理性
    validation = validate_shock_intersection(result)
    
    # 获取区域摘要
    summary = result.get_region_summary()
    
    return result, validation, summary

