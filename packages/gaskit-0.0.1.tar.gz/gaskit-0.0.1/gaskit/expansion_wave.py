# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 21:49:31 2025
膨胀波求解部分 模块先后编写序号2
@author: 28056
"""
import numpy as np
from scipy.optimize import fsolve
from dataclasses import dataclass
from gaskit.isentropic_flow import (
    isentropic_p_ratio,
    isentropic_T_ratio,
    isentropic_rho_ratio)


'''
-----------------数据类定义---------------
'''
@dataclass
class ExpansionWaveResult:
    """膨胀波结果类，用于存储Prandtl-Meyer膨胀波计算的所有参数"""
    theta_deg: float  # 偏转角（角度）
    Ma1: float  # 波前马赫数
    Ma2: float  # 波后马赫数
    p2_p1: float  # 波后/波前压强比
    T2_T1: float  # 波后/波前温度比
    rho2_rho1: float  # 波后/波前密度比
    v2_v1: float  # 波后/波前速度比
    gamma: float = 1.4  # 比热比
    
    def __post_init__(self):
        """初始化后计算弧度制值和其他衍生参数"""
        self.theta_rad = np.deg2rad(self.theta_deg)  # 偏转角（弧度）
        # 计算Prandtl-Meyer角
        self.nu1_deg = np.rad2deg(PM_angle(self.Ma1, self.gamma))
        self.nu2_deg = np.rad2deg(PM_angle(self.Ma2, self.gamma))
        self.nu1_rad = PM_angle(self.Ma1, self.gamma)
        self.nu2_rad = PM_angle(self.Ma2, self.gamma)
    
    def to_dict(self):
        """将结果转换为字典格式，便于输出和存储"""
        return {
            'theta_deg': self.theta_deg,
            'theta_rad': self.theta_rad,
            'Ma1': self.Ma1,
            'Ma2': self.Ma2,
            'p2_p1': self.p2_p1,
            'T2_T1': self.T2_T1,
            'rho2_rho1': self.rho2_rho1,
            'v2_v1': self.v2_v1,
            'gamma': self.gamma,
            'nu1_deg': self.nu1_deg,
            'nu2_deg': self.nu2_deg,
            'nu1_rad': self.nu1_rad,
            'nu2_rad': self.nu2_rad
        }


'''
----------------膨胀波基础求解部分------------
'''
def PM_angle(Ma, gamma=1.4):
    """
    Prandtl-Meyer函数：计算从声速（Ma=1）膨胀到给定马赫数时的偏转角
    
    参数:
    ----------
    Ma : float
        马赫数，必须 >= 1
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        Prandtl-Meyer角（弧度）
        
    注意:
    -------
    当 Ma < 1 时，Prandtl-Meyer函数无定义，会返回NaN
    """
    if Ma < 1:
        return np.nan
    
    # Prandtl-Meyer函数公式：
    # ν(M) = √((γ+1)/(γ-1)) * arctan(√((γ-1)/(γ+1)*(M²-1))) - arctan(√(M²-1))
    nu = (np.sqrt((gamma + 1) / (gamma - 1)) * 
          np.arctan(np.sqrt((gamma - 1) / (gamma + 1) * (Ma**2 - 1))) - 
          np.arctan(np.sqrt(Ma**2 - 1)))
    return nu

def PM_max_angle(gamma=1.4):
    """
    计算最大Prandtl-Meyer角（当马赫数趋于无穷大时的极限值）
    
    参数:
    ----------
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        最大Prandtl-Meyer角（弧度）
    """
    return (np.pi / 2) * (np.sqrt((gamma + 1) / (gamma - 1)) - 1)

def PM_Ma2(Ma1, theta_deg, gamma=1.4):
    """
    Prandtl-Meyer膨胀波求解：已知波前马赫数和偏转角，求波后马赫数
    
    参数:
    ----------
    Ma1 : float
        波前马赫数，必须 >= 1
    theta_deg : float
        壁面偏转角（度），正值表示膨胀
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        波后马赫数
        
    异常:
    -------
    ValueError: 当马赫数小于1或偏转角超过最大可能值时抛出
    """
    if Ma1 < 1:
        raise ValueError("波前马赫数必须 >= 1")
    
    theta_rad = np.deg2rad(theta_deg)
    
    # 计算波前的Prandtl-Meyer角
    nu1 = PM_angle(Ma1, gamma)
    
    # 计算波后的Prandtl-Meyer角
    nu2 = nu1 + theta_rad
    
    # 检查是否超过最大膨胀角
    nu_max = PM_max_angle(gamma)
    if nu2 > nu_max:
        raise ValueError(f"偏转角{theta_deg}°过大，超过最大膨胀角{np.rad2deg(nu_max):.2f}°")
    
    def f(Ma2, params):
        """
        目标函数：用于求解使PM角等于nu2的马赫数
        
        参数:
        ----------
        Ma2 : float
            待求解的马赫数
        params : tuple
            (gamma, nu2) 参数元组
            
        返回:
        -------
        float
            PM_angle(Ma2) - nu2
        """
        gamma_param, nu2_param = params
        return PM_angle(Ma2, gamma_param) - nu2_param
    
    # 使用数值方法求解马赫数，初始猜测值为略大于Ma1的值
    Ma2_guess = Ma1 * 1.1
    Ma2_solution = fsolve(f, Ma2_guess, args=[gamma, nu2])
    
    return Ma2_solution[0]

def expansion_wave(Ma1, theta_deg, gamma=1.4):
    """
    膨胀波完整求解：计算Prandtl-Meyer膨胀波的所有参数
    
    参数:
    ----------
    Ma1 : float
        波前马赫数，必须 >= 1
    theta_deg : float
        壁面偏转角（度），正值表示膨胀
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ExpansionWaveResult
        包含所有膨胀波参数的结果对象
        
    示例:
    -------
    >>> result = expansion_wave(2.0, 10.0)
    >>> print(f"波后马赫数: {result.Ma2:.3f}")
    >>> print(f"压强比: {result.p2_p1:.3f}")
    """
    # 求解波后马赫数
    Ma2 = PM_Ma2(Ma1, theta_deg, gamma)
    
    # 计算等熵流动参数比
    p_ratio = isentropic_p_ratio(Ma2, Ma1, gamma)    # 压强比 p2/p1
    T_ratio = isentropic_T_ratio(Ma2, Ma1, gamma)    # 温度比 T2/T1
    rho_ratio = isentropic_rho_ratio(Ma2, Ma1, gamma)  # 密度比 ρ2/ρ1
    
    # 速度比：v2/v1 = (Ma2 * a2) / (Ma1 * a1) = (Ma2/Ma1) * sqrt(T2/T1)
    v_ratio = Ma2 / Ma1 * np.sqrt(T_ratio)
    
    return ExpansionWaveResult(theta_deg, Ma1, Ma2, p_ratio, T_ratio, 
                             rho_ratio, v_ratio, gamma)

def expansion_wave_by_Ma2(Ma1, Ma2, gamma=1.4):
    """
    通过给定的波后马赫数计算膨胀波参数
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    Ma2 : float
        波后马赫数
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ExpansionWaveResult
        包含所有膨胀波参数的结果对象
    """
    if Ma1 >= Ma2:
        raise ValueError("膨胀波要求 Ma2 > Ma1")
    
    # 计算偏转角
    nu1 = PM_angle(Ma1, gamma)
    nu2 = PM_angle(Ma2, gamma)
    theta_rad = nu2 - nu1
    theta_deg = np.rad2deg(theta_rad)
    
    # 计算其他参数
    p_ratio = isentropic_p_ratio(Ma2, Ma1, gamma)
    T_ratio = isentropic_T_ratio(Ma2, Ma1, gamma)
    rho_ratio = isentropic_rho_ratio(Ma2, Ma1, gamma)
    v_ratio = Ma2 / Ma1 * np.sqrt(T_ratio)
    
    return ExpansionWaveResult(theta_deg, Ma1, Ma2, p_ratio, T_ratio, 
                             rho_ratio, v_ratio, gamma)

def expansion_fan_properties(Ma1, theta_deg, num_points=10, gamma=1.4):
    """
    计算膨胀扇内的详细参数分布
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    theta_deg : float
        总偏转角（度）
    num_points : int, optional
        计算点的数量，默认为10
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    list of ExpansionWaveResult
        膨胀扇内多个位置的结果列表
    """
    results = []
    theta_range = np.linspace(0, theta_deg, num_points)
    
    for theta in theta_range:
        if theta == 0:
            # 起始点就是波前状态
            result = ExpansionWaveResult(0, Ma1, Ma1, 1.0, 1.0, 1.0, 1.0, gamma)
        else:
            result = expansion_wave(Ma1, theta, gamma)
        results.append(result)
    
    return results

