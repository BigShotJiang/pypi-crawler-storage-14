# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 21:54:38 2025
平面激波求解
@author: 28056
"""
import numpy as np
import sympy as sp
from dataclasses import dataclass
from scipy.optimize import fsolve
from gaskit.isentropic_flow import (
    isentropic_p_ratio,
    isentropic_T_ratio
    )


@dataclass
class ShockWaveResult:
    """激波结果类，用于存储平面激波计算的所有参数"""
    theta_deg: float  # 气流偏转角（角度）
    beta_deg: float  # 激波角（角度）
    Ma1: float  # 波前马赫数
    Ma2: float  # 波后马赫数
    p2_p1: float  # 波后/波前压强比
    T2_T1: float  # 波后/波前温度比
    rho2_rho1: float  # 波后/波前密度比
    pt2_pt1: float  # 波后/波前总压比
    v2_v1: float  # 波后/波前速度比
    gamma: float = 1.4  # 比热比
    
    def __post_init__(self):
        """初始化后计算弧度制值"""
        self.theta_rad = np.deg2rad(self.theta_deg)  # 气流偏转角（弧度）
        self.beta_rad = np.deg2rad(self.beta_deg)    # 激波角（弧度）
    
    def to_dict(self):
        """将结果转换为字典格式，便于输出和存储"""
        return {
            'theta_deg': self.theta_deg,
            'theta_rad': self.theta_rad,
            'beta_deg': self.beta_deg,
            'beta_rad': self.beta_rad,
            'Ma1': self.Ma1,
            'Ma2': self.Ma2,
            'p2_p1': self.p2_p1,
            'T2_T1': self.T2_T1,
            'rho2_rho1': self.rho2_rho1,
            'pt2_pt1': self.pt2_pt1,
            'v2_v1': self.v2_v1,
            'gamma': self.gamma
        }

'''
-----------------激波基础求解部分-------------
'''

def shock_deflection_angle(Ma, beta_deg, gamma=1.4):
    """
    已知马赫数、激波角，求气流偏转角（角度度）
    
    参数:
    ----------
    Ma : float
        来流马赫数
    beta_deg : float
        激波角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        气流偏转角（角度度）
    """
    beta_rad = np.deg2rad(beta_deg)
    # 使用斜激波关系式计算气流偏转角的正切值
    tan_theta = (2 / np.tan(beta_rad) * (Ma**2 * np.sin(beta_rad)**2 - 1) / 
                (Ma**2 * (gamma + np.cos(2 * beta_rad)) + 2))
    theta_rad=np.arctan(tan_theta)
    theta_deg=np.rad2deg(theta_rad)
    return theta_deg

def shock_max_deflection_angle(Ma, gamma=1.4):
    """
    计算最大附体激波的偏转角及其对应的最大激波角（返回角度值）
    
    参数:
    ----------
    Ma : float
        来流马赫数
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple
        (最大偏转角_deg, 对应的激波角_deg)
    """
    part1 = gamma * Ma**2
    part2 = (gamma + 1) / 4 * Ma**2 - 1
    part3 = (1 + gamma) * (1 + (gamma - 1) / 2 * Ma**2 + (gamma + 1) / 16 * Ma**4)
    # 计算最大偏转角对应的sin²(β)
    sin2_beta_m = (part2 + part3**0.5) / part1
    beta_m_rad = np.arcsin(sin2_beta_m**0.5)
    # 计算对应的最大偏转角
    theta_max_deg = shock_deflection_angle(Ma, np.rad2deg(beta_m_rad), gamma)
    theta_max_rad=np.deg2rad(theta_max_deg)
    return np.rad2deg(theta_max_rad), np.rad2deg(beta_m_rad)

def shock_min_Ma(theta_deg, gamma=1.4):
    """
    计算给定偏转角下的最小马赫数
    
    参数:
    ----------
    theta_deg : float
        气流偏转角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    tuple
        (最小马赫数, 对应的激波角_deg)
    """
    theta_rad = np.deg2rad(theta_deg)
    
    def dMa2_dbeta(beta_rad, theta_rad, gamma):
        """马赫数平方对激波角的导数方程"""
        return 2*np.sin(2*beta_rad) + np.sin(4*beta_rad-2*theta_rad) - gamma*np.sin(2*theta_rad)
    
    # 求解使导数方程为零的激波角
    beta_rad = fsolve(dMa2_dbeta, np.deg2rad(65), args=(theta_rad, gamma))
    beta_rad = beta_rad[0]
    
    # 计算最小马赫数
    part1 = 4 * np.cos(beta_rad - theta_rad)
    part2 = (np.cos(3*beta_rad - theta_rad) - np.cos(beta_rad - theta_rad) 
             - gamma * np.cos(beta_rad + theta_rad) + gamma * np.cos(beta_rad - theta_rad))
    Ma2 = -part1 / part2
    
    if Ma2 < 0:
        print('气流偏转角过大')
        return None, None
    else:
        return pow(Ma2, 0.5), np.rad2deg(beta_rad)  # 同时返回临界条件下的激波角

def shock_Ma2(Ma1, beta_deg, gamma=1.4):
    """
    计算激波后马赫数
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    beta_deg : float
        激波角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        波后马赫数
    """
    beta_rad = np.deg2rad(beta_deg)
    # 使用斜激波关系式计算波后马赫数
    part1 = Ma1**2 + 2 / (gamma - 1)
    part2 = 2 * gamma / (gamma - 1) * Ma1**2 * np.sin(beta_rad)**2 - 1
    part3 = Ma1**2 * np.cos(beta_rad)**2
    part4 = (gamma - 1) / 2 * Ma1**2 * np.sin(beta_rad)**2 + 1
    Ma2 = part1 / part2 + part3 / part4
    #可能为负
    return Ma2**0.5

def shock_T_ratio(Ma1, beta_deg, gamma=1.4):
    """
    计算激波前后温度比
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    beta_deg : float
        激波角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        温度比 T2/T1
    """
    beta_rad = np.deg2rad(beta_deg)
    a = Ma1 * np.sin(beta_rad)  # 法向马赫数
    b = a**2
    # 使用Rankine-Hugoniot关系式计算温度比
    part1 = 2 * gamma * b - (gamma - 1)
    part2 = (gamma - 1) * b + 2
    part3 = (gamma + 1)**2 * b
    return part1 * part2 / part3

def shock_rho_ratio(Ma1, beta_deg, gamma=1.4):
    """
    计算激波前后密度比
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    beta_deg : float
        激波角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        密度比 ρ2/ρ1
    """
    beta_rad = np.deg2rad(beta_deg)
    # 使用斜激波关系式计算密度比
    part1 = (gamma + 1) * Ma1**2 * np.sin(beta_rad)**2
    part2 = 2 + (gamma - 1) * Ma1**2 * np.sin(beta_rad)**2
    return part1 / part2

def shock_p_ratio(Ma1, beta_deg, gamma=1.4):
    """
    计算激波前后压强比
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    beta_deg : float
        激波角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float
        压强比 p2/p1
    """
    beta_rad = np.deg2rad(beta_deg)
    # 使用斜激波关系式计算压强比
    return 1 + 2 * gamma / (gamma + 1) * (Ma1**2 * np.sin(beta_rad)**2 - 1)

def shock_angles(Ma1, theta_deg, gamma=1.4):
    """
    已知斜劈角度theta、来流马赫数Ma1求斜激波的激波角（返回角度值）
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta_deg : float
        斜劈角度（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    list
        可能的激波角列表（度），如果脱体激波则返回空列表
    """
    theta_rad = np.deg2rad(theta_deg)
    theta_max_deg, beta_m_deg = shock_max_deflection_angle(Ma1, gamma)
    theta_max_rad = np.deg2rad(theta_max_deg)
    
    # 检查是否产生脱体激波
    if theta_rad > theta_max_rad:
        print(f'当前气流偏转角{theta_deg:.2f}°, 最大气流偏转角{theta_max_deg:.2f}°')
        print('产生脱体激波')
        return []
    
    # 使用符号计算求解激波角的三次方程
    x = sp.symbols('x')
    part1 = 1 + (gamma - 1) * 0.5 * Ma1**2
    part2 = 1 + (gamma + 1) * 0.5 * Ma1**2
    A = (1 - Ma1**2) / part1
    B = part2 / part1 * np.tan(theta_rad)
    C = 1 / part1
    
    # 构建激波角的三次方程
    f = np.tan(theta_rad) * sp.Pow(x, 3) + A * sp.Pow(x, 2) + B * x + C
    res = sp.solveset(f, x, domain=sp.S.Reals)
    res = [float(sol) for sol in res]
    return [np.rad2deg(np.arctan(angle)) for angle in res]

def weak_shock_angle(Ma1, theta_deg, gamma=1.4):
    """
    弱激波的激波角（返回角度值）
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta_deg : float
        斜劈角度（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float or None
        弱激波角（度），如果无解返回None
    """
    angles_deg = shock_angles(Ma1, theta_deg, gamma)
    if len(angles_deg) == 0:
        return None
    
    _, beta_m_deg = shock_max_deflection_angle(Ma1, gamma)
    # 选择小于最大偏转角对应激波角的解作为弱激波解
    for angle_deg in angles_deg:
        if 0 < angle_deg < beta_m_deg:
            return angle_deg
    return None

def strong_shock_angle(Ma1, theta_deg, gamma=1.4):
    """
    强激波的激波角（返回角度值）
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta_deg : float
        斜劈角度（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    float or None
        强激波角（度），如果无解返回None
    """
    angles_deg = shock_angles(Ma1, theta_deg, gamma)
    if not angles_deg:
        return None
    
    _, beta_m_deg = shock_max_deflection_angle(Ma1, gamma)
    # 选择大于最大偏转角对应激波角的解作为强激波解
    for angle_deg in angles_deg:
        if angle_deg > beta_m_deg:
            return angle_deg
    return None

def shock_by_shock_angle(Ma1, beta_deg, gamma=1.4):
    """
    已知激波角，求所有激波参数
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    beta_deg : float
        激波角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ShockWaveResult
        包含所有激波参数的结果对象
    """
    # 计算气流偏转角
    beta_min_rad=np.arcsin(1/Ma1)
    beta_min_deg=np.rad2deg(beta_min_rad)
    if beta_deg<beta_min_deg or beta_deg>90:
        raise ValueError(f"激波角超出范围{beta_min_deg}°<beta<90°")
    theta_deg = shock_deflection_angle(Ma1, beta_deg, gamma)
    # 计算各物理量比值
    Ma2 = shock_Ma2(Ma1, beta_deg, gamma)
    T_ratio = shock_T_ratio(Ma1, beta_deg, gamma)
    p_ratio = shock_p_ratio(Ma1, beta_deg, gamma)
    rho_ratio = shock_rho_ratio(Ma1, beta_deg, gamma)
    
    # 计算总压比和速度比
    pt1_p1 = isentropic_p_ratio(0, Ma1, gamma)  # 波前总压/静压
    pt2_p2 = isentropic_p_ratio(0, Ma2, gamma)  # 波后总压/静压
    pt_ratio = pt2_p2 / pt1_p1 * p_ratio  # 波后总压/波前总压
    v_ratio = Ma2 / Ma1 * np.sqrt(T_ratio)  # 速度比
    
    return ShockWaveResult(theta_deg, beta_deg, Ma1, Ma2, p_ratio, T_ratio, 
                         rho_ratio, pt_ratio, v_ratio, gamma)

def weak_shock_by_deflection_angle(Ma1, theta_deg, gamma=1.4):
    """
    已知气流偏转角，求弱激波所有参数
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta_deg : float
        气流偏转角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ShockWaveResult or None
        弱激波结果对象，如果无解返回None
    """
    beta_deg = weak_shock_angle(Ma1, theta_deg, gamma)
    if beta_deg is None:
        return None
    return shock_by_shock_angle(Ma1, beta_deg, gamma)

def strong_shock_by_deflection_angle(Ma1, theta_deg, gamma=1.4):
    """
    已知气流偏转角，求强激波所有参数
    
    参数:
    ----------
    Ma1 : float
        来流马赫数
    theta_deg : float
        气流偏转角（度）
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ShockWaveResult or None
        强激波结果对象，如果无解返回None
    """
    beta_deg = strong_shock_angle(Ma1, theta_deg, gamma)
    if beta_deg is None:
        return None
    return shock_by_shock_angle(Ma1, beta_deg, gamma)

def shock_by_p_ratio(Ma1, p_ratio, gamma=1.4):
    """
    已知压强比，求激波参数
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    p_ratio : float
        压强比 p2/p1
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ShockWaveResult
        激波结果对象
    """
    # 从压强比反推激波角
    a = 2 * gamma / (gamma + 1)
    part1 = (p_ratio - 1) / a + 1
    sin2_beta = part1 / Ma1**2
    beta_rad = np.arcsin(sin2_beta**0.5)
    beta_deg = np.rad2deg(beta_rad)
    return shock_by_shock_angle(Ma1, beta_deg, gamma)
def Ma0_from_down_stream(Ma_down,beta_deg,gamma=1.4):
    '''已知波后的马赫数和激波角，求波前马赫数
    输入:
        Ma_down:float
            波后马赫数
        beta_deg:float
            激波角
    输出:
        Ma0:float
            波前马赫数
    '''
    def Ma0_func(Ma0,Ma_down,beta_deg,gamma):
        Ma_down=shock_Ma2(Ma0, beta_deg, gamma)
        return Ma_down-Ma0
    res=fsolve(Ma0_func, Ma_down,args=(Ma_down,beta_deg,gamma))
    return res[0]
#---------------正激波求解部分---------------
def normal_shock(Ma1, gamma=1.4):
    """
    正激波求解
    
    参数:
    ----------
    Ma1 : float
        波前马赫数
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ShockWaveResult
        正激波结果对象
    """
    # 正激波关系式
    Ma2_2 = (1 + (gamma - 1) / 2 * Ma1**2) / (gamma * Ma1**2 - (gamma - 1) / 2)
    Ma2 = Ma2_2**0.5
    p_ratio = 1 + (2 * gamma) / (gamma + 1) * (Ma1**2 - 1)
    rho_ratio = Ma1**2 / (1 + (gamma - 1) / (gamma + 1) * (Ma1**2 - 1))
    T_ratio = isentropic_T_ratio(Ma2, Ma1, gamma)
    
    # 总压比和速度比
    pt1_p1 = isentropic_p_ratio(0, Ma1, gamma)
    pt2_p2 = isentropic_p_ratio(0, Ma2, gamma)
    pt_ratio = pt2_p2 / pt1_p1 * p_ratio
    v_ratio = Ma2 / Ma1 * np.sqrt(T_ratio)
    
    # 正激波的特殊参数
    theta_deg = 0  # 正激波无偏转
    beta_deg = 90  # 正激波角为90度
    
    return ShockWaveResult(theta_deg, beta_deg, Ma1, Ma2, p_ratio, T_ratio, 
                         rho_ratio, pt_ratio, v_ratio, gamma)

def normal_shock_by_p_ratio(p_ratio, gamma=1.4):
    """
    已知压强比求正激波参数
    
    参数:
    ----------
    p_ratio : float
        压强比 p2/p1
    gamma : float, optional
        比热比，默认为1.4
        
    返回:
    -------
    ShockWaveResult
        正激波结果对象
    """
    # 从压强比反推马赫数
    a = 2 * gamma / (gamma + 1)
    Ma1_2 = (p_ratio - 1) / a + 1
    return normal_shock(Ma1_2**0.5, gamma)
