"""
gaskit - 气体动力学计算工具包

一个用于计算气体动力学中各种流动现象的Python工具包，包括等熵流动、膨胀波、激波、波系相交等计算功能。

模块列表:
- isentropic_flow: 等熵流动计算
- expansion_wave: 膨胀波计算  
- shock_wave: 激波计算
- shock_intersect_different_side: 异侧激波相交计算
- shock_expan_wave_intersect_different_side: 激波-膨胀波相交计算
- cone_shock: 圆锥激波计算
"""

from gaskit.isentropic_flow import (
    isentropic_p_ratio,
    isentropic_T_ratio,
    isentropic_rho_ratio,
    isentropic_flow,
    IsentropicFlowResult
)

from gaskit.expansion_wave import (
    PM_angle,
    PM_max_angle,
    PM_Ma2,
    expansion_wave,
    expansion_wave_by_Ma2,
    expansion_fan_properties,
    ExpansionWaveResult
)

from gaskit.shock_wave import (
    shock_deflection_angle,
    shock_max_deflection_angle,
    shock_min_Ma,
    shock_Ma2,
    shock_T_ratio,
    shock_rho_ratio,
    shock_p_ratio,
    shock_angles,
    weak_shock_angle,
    strong_shock_angle,
    shock_by_shock_angle,
    weak_shock_by_deflection_angle,
    strong_shock_by_deflection_angle,
    shock_by_p_ratio,
    Ma0_from_down_stream,
    normal_shock,
    normal_shock_by_p_ratio,
    ShockWaveResult
)

from gaskit.shock_intersect_different_side import (
    shock_intersect_different_side,
    validate_shock_intersection,
    shock_intersection_analysis,
    WaveIntersectionResult
)

from gaskit.shock_expan_wave_intersect_different_side import (
    shock_little_expan_intersect_different_side,
    shock_expan_intersect_different_side,
    validate_intersection_solution
)

from gaskit.cone_shock import (
    Taylor_Maccoll_equation,
    shock_wave_condition,
    cone_half_angle_by_beta,
    max_cone_half_angle_0,
    max_cone_half_angle,
    weak_beta_of_cone,
    weak_beta_of_cone_2,
    intergrate_from_cone,
    beta_from_cone,
    uv_from_shock,
    strong_beta_of_cone,
    min_Ma_cone_0,
    Ma0_from_cone,
    min_Ma_cone,
    solve_conical_shock,
    ConicalShockResult
)

# 定义包的版本
__version__ = "1.0.0"
__author__ = "28056"

# 定义__all__以便明确导出的符号
__all__ = [
    # isentropic_flow 模块
    "isentropic_p_ratio",
    "isentropic_T_ratio", 
    "isentropic_rho_ratio",
    "isentropic_flow",
    "IsentropicFlowResult",
    
    # expansion_wave 模块
    "PM_angle",
    "PM_max_angle",
    "PM_Ma2",
    "expansion_wave",
    "expansion_wave_by_Ma2",
    "expansion_fan_properties",
    "ExpansionWaveResult",
    
    # shock_wave 模块
    "shock_deflection_angle",
    "shock_max_deflection_angle",
    "shock_min_Ma",
    "shock_Ma2",
    "shock_T_ratio",
    "shock_rho_ratio",
    "shock_p_ratio",
    "shock_angles",
    "weak_shock_angle",
    "strong_shock_angle",
    "shock_by_shock_angle",
    "weak_shock_by_deflection_angle",
    "strong_shock_by_deflection_angle",
    "shock_by_p_ratio",
    "Ma0_from_down_stream",
    "normal_shock",
    "normal_shock_by_p_ratio",
    "ShockWaveResult",
    
    # shock_intersect_different_side 模块
    "shock_intersect_different_side",
    "validate_shock_intersection",
    "shock_intersection_analysis",
    "WaveIntersectionResult",
    
    # shock_expan_wave_intersect_different_side 模块
    "shock_little_expan_intersect_different_side",
    "shock_expan_intersect_different_side",
    "validate_intersection_solution",
    
    # cone_shock 模块
    "Taylor_Maccoll_equation",
    "shock_wave_condition",
    "cone_half_angle_by_beta",
    "max_cone_half_angle_0",
    "max_cone_half_angle",
    "weak_beta_of_cone",
    "weak_beta_of_cone_2",
    "intergrate_from_cone",
    "beta_from_cone",
    "uv_from_shock",
    "strong_beta_of_cone",
    "min_Ma_cone_0",
    "Ma0_from_cone",
    "min_Ma_cone",
    "solve_conical_shock",
    "ConicalShockResult"
]