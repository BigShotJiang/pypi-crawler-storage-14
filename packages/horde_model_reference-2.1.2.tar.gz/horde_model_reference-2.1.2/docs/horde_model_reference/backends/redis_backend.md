# redis_backend
::: horde_model_reference.backends.redis_backend
