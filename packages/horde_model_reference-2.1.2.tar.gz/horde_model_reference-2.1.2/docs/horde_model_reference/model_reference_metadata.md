# model_reference_metadata
::: horde_model_reference.model_reference_metadata
