"""Tests for the FastAPI service layer."""
