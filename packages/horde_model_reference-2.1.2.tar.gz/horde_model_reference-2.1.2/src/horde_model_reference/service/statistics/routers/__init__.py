"""The FastAPI routers for statistics and audit specific endpoints."""
