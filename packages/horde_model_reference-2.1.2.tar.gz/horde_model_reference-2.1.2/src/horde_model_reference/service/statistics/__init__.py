"""The statistics and audit specific endpoints."""
