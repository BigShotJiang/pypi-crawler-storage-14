# Windows

::: fluxgate.windows.CountWindow

::: fluxgate.windows.TimeWindow
