# Permits

::: fluxgate.permits.Random

::: fluxgate.permits.RampUp
