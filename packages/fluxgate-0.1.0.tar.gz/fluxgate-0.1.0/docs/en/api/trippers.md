# Trippers

::: fluxgate.trippers.Closed

::: fluxgate.trippers.HalfOpened

::: fluxgate.trippers.MinRequests

::: fluxgate.trippers.FailureRate

::: fluxgate.trippers.AvgLatency

::: fluxgate.trippers.SlowRate
