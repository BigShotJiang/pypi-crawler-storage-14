# Interfaces

::: fluxgate.interfaces.IWindow

::: fluxgate.interfaces.ITracker

::: fluxgate.interfaces.ITripper

::: fluxgate.interfaces.IRetry

::: fluxgate.interfaces.IPermit

::: fluxgate.interfaces.IListener

::: fluxgate.interfaces.IAsyncListener
