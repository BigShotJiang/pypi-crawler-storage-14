# Core

::: fluxgate.CircuitBreaker

::: fluxgate.AsyncCircuitBreaker

::: fluxgate.StateEnum

::: fluxgate.CallNotPermittedError
