.. _lsst.resources-internal-api:

Internal API reference
======================

.. automodapi:: lsst.resources.utils
   :no-main-docstr:

.. automodapi:: lsst.resources._resourceHandles._baseResourceHandle
   :no-main-docstr:

.. automodapi:: lsst.resources._resourceHandles._fileResourceHandle
   :no-main-docstr:
