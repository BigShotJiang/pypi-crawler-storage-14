"""Video Info MCP - Get detailed video file information."""

__version__ = "0.1.0"