# Video Info MCP

获取视频文件详细信息的 MCP Server。

## 功能

- 获取视频文件的完整元数据
- 支持分辨率、码率、编码格式、容器信息
- 支持音频流、视频流、字幕流信息
- 返回格式化的 JSON 数据

## 安装

```bash
uvx video-info-mcp
```

或通过 pip 安装：

```bash
pip install video-info-mcp
```

## 使用

```bash
video-info-mcp
```

## 工具

### get_video_info

获取视频文件的详细信息。

**参数：**
- `video_path`: 输入视频文件路径

**返回信息包括：**
- 文件信息：文件名、大小、时长、格式、码率
- 视频流：编码、分辨率、帧率、像素格式等
- 音频流：编码、采样率、声道、码率等
- 字幕流：编码、语言、标题等
- 摘要信息：主要视频/音频参数汇总

## 依赖

- Python >=3.12
- FFmpeg/FFprobe（需系统安装）

## License

MIT License