# MCP Database Manager

An MCP server that enables LLM agents to perform CRUD operations across multiple databases.

## Features

- Multi-Database Support
- Permission Management (Read-only by default)
- SQLAlchemy Integration

## Configuration

The configuration file is located at:
- `~/.mcp-database-manager/config.yaml` (on all platforms)

Example `config.yaml`:

```yaml
connections:
  - name: "main_db"
    url: "sqlite:///./main.db"
    readonly: true
```

## Cursor Configuration

To use this MCP server in Cursor, add the following to your MCP settings (Settings > Features > MCP):

### Option 1: Local Development (Recommended)

Use this if you have the source code locally.

```json
{
  "mcpServers": {
    "database-manager": {
      "command": "uv",
      "args": [
        "run",
        "--extra",
        "postgres",
        "mcp-database-manager"
      ],
      "cwd": "d:/code/mcp-database-manager"
    }
  }
}
```

### Option 2: Using `uvx` (If published)

```json
{
  "mcpServers": {
    "database-manager": {
      "command": "uvx",
      "args": [
        "--with",
        "mcp-database-manager[postgres]",
        "mcp-database-manager"
      ]
    }
  }
}
```

## Troubleshooting

If you see "Module not found" errors, ensure you are using `uv run` which handles the virtual environment automatically.
