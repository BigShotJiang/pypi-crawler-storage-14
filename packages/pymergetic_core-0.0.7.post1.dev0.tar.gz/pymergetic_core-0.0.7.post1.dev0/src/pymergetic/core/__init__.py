"""PymergeticOS Core package."""

from .__project__ import __version__, __package_name__

