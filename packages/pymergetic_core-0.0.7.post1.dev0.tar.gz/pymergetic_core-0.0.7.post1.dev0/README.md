# Pymergetic Core

Core package for PymergeticOS with optional feature groups organized by topic.

## Installation

### Base Package

```bash
pip install pymergetic-core
```

### With Optional Dependencies

```bash
# Install with console features (CLI tools)
pip install pymergetic-core[console]

# Install with config features (configuration management)
pip install pymergetic-core[config]

# Install with multiple extras
pip install pymergetic-core[console,config]
```

## Optional Dependencies (Extras)

- **console**: Virtual console and CLI package dependencies
  - `fire>=0.5.0` - Python Fire for CLI interfaces
  - `rich>=13.0.0` - Rich text and beautiful formatting for terminal

- **config**: Configuration management dependencies
  - `pydantic>=2.0.0` - Data validation using Python type annotations
  - `pydantic-settings>=2.0.0` - Settings management using Pydantic
  - `pyyaml>=6.0` - YAML parser and emitter

## Development

### Building and Publishing

```bash
# Build package
make build

# Publish to PyPI
make publish

# Full release (tag, build, publish)
make release
```

See `Makefile` for all available targets.

