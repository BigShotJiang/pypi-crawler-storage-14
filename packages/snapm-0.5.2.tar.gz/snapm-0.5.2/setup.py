"""
Python packaging file for setup tools.
"""
import setuptools

setuptools.setup()

# vim: set et ts=4 sw=4 :
