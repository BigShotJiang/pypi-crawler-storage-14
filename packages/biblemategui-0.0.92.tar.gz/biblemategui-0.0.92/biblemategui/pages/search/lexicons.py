from biblemategui import BIBLEMATEGUI_DATA, config
from nicegui import ui, app
from agentmake.utils.rag import get_embeddings, cosine_similarity_matrix
import numpy as np
import re, apsw, os, json, traceback
from biblemategui.data.cr_books import cr_books

def search_bible_lexicons(gui=None, q='', **_):

    client_lexicons = list(config.lexicons.keys())
    if app.storage.client["custom"]:
        client_lexicons += list(config.lexicons_custom.keys())
    client_lexicons = sorted(list(set(client_lexicons)))

    def get_lexicon_path(lexicon_name):
        nonlocal client_lexicons
        if not lexicon_name in client_lexicons:
            return client_lexicons["Morphology"]
        if lexicon_name in config.lexicons_custom:
            return config.lexicons_custom[lexicon_name]
        elif lexicon_name in config.lexicons:
            return config.lexicons[lexicon_name]

    scope_select = None

    def cr(event):
        nonlocal gui
        b, c, v, *_ = event.args
        b = cr_books.get(b, b)
        gui.change_area_1_bible_chapter(None, b, c, v)

    def bcv(event):
        nonlocal gui
        b, c, v, *_ = event.args
        gui.change_area_1_bible_chapter(None, b, c, v)
    
    def website(event):
        url, *_ = event.args
        print(url)
        ui.navigate.to(url, new_tab=True)

    ui.on('bcv', bcv)
    ui.on('cr', cr)
    ui.on('website', website)

    # all entries
    def get_all_entries(lexicon):
        all_entries = []
        db = get_lexicon_path(lexicon)
        with apsw.Connection(db) as connn:
            cursor = connn.cursor()
            sql_query = f"SELECT Topic FROM Lexicon"
            cursor.execute(sql_query)
            all_entries = [i[0] for i in cursor.fetchall()]
        return list(set([i for i in all_entries if i]))
    lexicon_module = app.storage.user.get('favorite_lexicon', 'Morphology')
    all_entries = get_all_entries(lexicon_module)

    # ----------------------------------------------------------
    # Core: Fetch and Display
    # ----------------------------------------------------------

    def handle_enter(e):
        nonlocal content_container, gui, input_field, lexicon_module

        topic = input_field.value.strip()

        db = get_all_entries(lexicon_module)
        with apsw.Connection(db) as connn:
            cursor = connn.cursor()
            sql_query = f"SELECT content FROM Lexicon WHERE Topic=? limit 1"
            cursor.execute(sql_query, (topic,))
            fetch = cursor.fetchone()
            content = fetch[0] if fetch else ""

        # Clear existing rows first
        content_container.clear()

        with content_container:
            # html style
            ui.add_head_html(f"""
            <style>
                /* Main container for the content - LTR flow */
                .content-text {{
                    direction: ltr;
                    font-family: sans-serif;
                    padding: 0px;
                    margin: 0px;
                }}
                /* Verse ref */
                ref {{
                    color: {'#f2c522' if app.storage.user['dark_mode'] else 'navy'};
                    font-weight: bold;
                    cursor: pointer;
                }}
                /* CSS to target all h1 elements */
                h1 {{
                    font-size: 2.2rem;
                    color: {app.storage.user['primary_color']};
                }}
                /* CSS to target all h2 elements */
                h2 {{
                    font-size: 1.8rem;
                    color: {app.storage.user['secondary_color']};
                }}
            </style>
            """)
            # convert links, e.g. <ref onclick="bcv(3,19,26)">
            content = re.sub(r'''(onclick|ondblclick)="(cr|bcv|website)\((.*?)\)"''', r'''\1="emitEvent('\2', [\3]); return false;"''', content)
            content = re.sub(r"""(onclick|ondblclick)='(cr|bcv|website)\((.*?)\)'""", r"""\1='emitEvent("\2", [\3]); return false;'""", content)
            # remove map
            content = content.replace('<div id="map" style="width:100%;height:500px"></div>', "")
            content = re.sub(r'<script.*?>.*?</script>', '', content, flags=re.DOTALL)
            # convert colors for dark mode, e.g. <font color="brown">
            if app.storage.user['dark_mode']:
                content = content.replace('color="brown">', 'color="pink">')
                content = content.replace('color="navy">', 'color="lightskyblue">')
                content = content.replace('<table bgcolor="#BFBFBF"', '<table bgcolor="#424242"')
                content = content.replace('<td bgcolor="#FFFFFF">', '<td bgcolor="#212121">')
                content = content.replace('<tr bgcolor="#FFFFFF">', '<tr bgcolor="#212121">')
                content = content.replace('<tr bgcolor="#DFDFDF">', '<tr bgcolor="#303030">')
            # display
            ui.html(f'<div class="bible-text">{content}</div>', sanitize=False)

        # Clear input so user can start typing to filter immediately
        input_field.value = ""

    # ==============================================================================
    # 3. UI LAYOUT
    # ==============================================================================
    with ui.row().classes('w-full max-w-3xl mx-auto m-0 py-0 px-4 items-center'):
        input_field = ui.input(
            value=q,
            autocomplete=all_entries,
            placeholder=f'Enter keywords to search {config.encyclopedias[lexicon_module]}...'
        ).classes('flex-grow text-lg') \
        .props('outlined dense clearable autofocus')

        input_field.on('keydown.enter', handle_enter)

        scope_select = ui.select(
            options=client_lexicons,
            label='Search',
            value=app.storage.user.get('favorite_lexicon', 'Morphology'),
            with_input=True
        ).classes('w-22')

        def handle_scope_change(e):
            nonlocal lexicon_module
            lexicon_module = e.value
            app.storage.user['favorite_lexicon'] = lexicon_module
            input_field.autocomplete = get_all_entries(lexicon_module)
            input_field.props(f'placeholder="Enter keywords to search {lexicon_module}..."')
        scope_select.on_value_change(handle_scope_change)

    # --- Main Content Area ---
    with ui.column().classes('w-full items-center'):
        # Define the container HERE within the layout structure
        content_container = ui.column().classes('w-full transition-all !gap-1')

    if q:
        handle_enter(None)