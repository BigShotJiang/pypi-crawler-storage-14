# TNFR Visualization — Canonical Module Hub (Single Source of Truth)

English-only hub for visualization helpers and plots.

## Scope
- Matplotlib/Plotly helpers; safe headless modes for CI
