# TNFR Tools — Canonical Module Hub (Single Source of Truth)

English-only hub for developer and user tools.

## Scope
- Small utilities, scripts integrations, and CLI helpers

## Policy
- Keep thin and defer theory to canonical docs (`AGENTS.md`).
