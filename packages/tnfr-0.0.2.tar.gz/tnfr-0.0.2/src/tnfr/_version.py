"""Version information for TNFR package."""

__version__ = "0.0.2"