# TNFR Structural — Canonical Module Hub (Single Source of Truth)

English-only hub for structural constructs/utilities.

- Canonical physics/invariants: `AGENTS.md`

## Scope
- Structural representations supporting EPI/ΔNFR operations
