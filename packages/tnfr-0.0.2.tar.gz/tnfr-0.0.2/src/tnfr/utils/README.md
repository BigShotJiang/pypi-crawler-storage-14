# TNFR Utils — Canonical Module Hub (Single Source of Truth)

English-only hub for general-purpose utilities used across modules.

## Scope
- Small helpers; shared idioms; no theory duplication
