### Auth workflow
* AUTH connection state
* Example
* README blurb

### Persistence
* Session data reset policies

