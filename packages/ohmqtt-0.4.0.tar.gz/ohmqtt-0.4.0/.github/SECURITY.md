# Security Policy

## Reporting a Vulnerability

Use the [security reporting](https://github.com/ohmqtt/ohmqtt_python/security) feature of GitHub to report security issues.
