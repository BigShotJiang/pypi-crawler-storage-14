# Code of Conduct for ΩQTT

This software was created and is maintained by humans for all humans.

The software and related forums will not be a venue for abuse, discrimination or harassment.

If someone asks you politely to desist a behavior, please do so politely.

Contact <matt@endpointdev.com> if there's a problem.
