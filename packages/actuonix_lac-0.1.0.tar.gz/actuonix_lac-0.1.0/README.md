# actuonix_lac

Python controller for Actuonix Linear Actuator Control Board Modified from
[AccelerationConsortium/actuonix_lac](https://github.com/AccelerationConsortium/actuonix_lac).
The main update was to publish the library to PyPI.

## Tested on

Actuonix L16-P Linear Actuators with 5-wire connectors.

    https://www.actuonix.com/l16-p

Actuonix Linear Actuator Control (LAC) Board.

    https://www.actuonix.com/lac

Connect the actuator to the LAC and the LAC to your computer using a mini-USB cable.
    
## Installation

### Install drivers

Make sure the LAC driver is installed:

        https://www.actuonix.com/assets/images/Actuonix%20LAC%20Configuration%20Utility-24-Setup.zip

Confrim the USB VendorID and ProductID are correct:

   Windows "Device Manager" -> "Custom USB Devices" -> "WinUSB Devices"

   -> "Hardware Ids" -> "USB\VID_04D8&PID_FC5F"

       VID = 0x04d8  # Vendor ID
       PID = 0xfc5f  # Product ID

### Install library from PyPI

uv:

    uv add actuonix_lac

pip:

    pip install actuonix_lac
