# Additional class to be used in imports

class MyCustomClass:
    pass
