import prismarine_client as pc


class TeamModel(pc.ItemModel):
    pass
