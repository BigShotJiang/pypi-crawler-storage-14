class CloudIgniteError(Exception):
    """Base exception"""

class InvalidCredentials(CloudIgniteError):
    pass

class TokenExpired(CloudIgniteError):
    pass

class APIError(CloudIgniteError):
    def __init__(self, status_code, message):
        super().__init__(f"{status_code}: {message}")
        self.status_code = status_code
        self.message = message

class PermissionDenied(APIError):
    pass
