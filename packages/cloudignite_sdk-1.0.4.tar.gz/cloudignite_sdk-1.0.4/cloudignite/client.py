import json
import requests
from typing import Optional, Dict, Any, List
from .exceptions import APIError, InvalidCredentials, TokenExpired, PermissionDenied
from .models import User, AuthTokens
from .token_manager import TokenManager


def _check_response(resp):
    if resp.status_code in (200, 201):
        try:
            return resp.json()
        except:
            return resp.text

    if resp.status_code == 401:
        raise InvalidCredentials(resp.text)

    if resp.status_code == 403:
        raise PermissionDenied(resp.status_code, resp.text)

    raise APIError(resp.status_code, resp.text)


class CloudIgnite:
    """
    Python SDK for CloudIgnite Auth System.
    """
    def __init__(self, base_url: str, project_id: Optional[str] = None):
        self.base_url = base_url.rstrip("/")
        self.project_id = project_id
        self.tokens = TokenManager()
        self.api_key = None
        self.session = requests.Session()

    def _url(self, path: str):
        return f"{self.base_url}/{path.lstrip('/')}"

    def _headers(self):
        h = {}
        if self.api_key:
            h["X-API-Key"] = self.api_key
        if self.tokens.access_token:
            h["Authorization"] = f"Bearer {self.tokens.access_token}"
        return h

    def _request(self, method: str, path: str, body=None, params=None):
        url = self._url(path)
        resp = self.session.request(
            method,
            url,
            json=body,
            params=params,
            headers=self._headers(),
            timeout=30
        )

        # if token expired, auto-refresh once
        if resp.status_code == 401 and self.tokens.refresh_token:
            try:
                self.refresh(self.project_id)
                resp = self.session.request(
                    method,
                    url,
                    json=body,
                    params=params,
                    headers=self._headers(),
                    timeout=30
                )
            except:
                pass

        return _check_response(resp)

    # --------------------
    # AUTH
    # --------------------
    def signup(self, project_id, email, password, metadata=None):
        body = {"email": email, "password": password, "metadata": metadata or {}}
        data = self._request("POST", f"projects/{project_id}/auth/signup", body)
        user = User(**data["user"])
        tokens = AuthTokens(data["access_token"], data["refresh_token"])
        self.tokens.set_tokens(tokens.access_token, tokens.refresh_token)
        self.project_id = project_id
        return user, tokens

    def login(self, project_id, email, password):
        data = self._request("POST", f"projects/{project_id}/auth/login", {"email": email, "password": password})
        user = User(**data["user"])
        tokens = AuthTokens(data["access_token"], data["refresh_token"])
        self.tokens.set_tokens(tokens.access_token, tokens.refresh_token)
        self.project_id = project_id
        return user, tokens

    def refresh(self, project_id):
        data = self._request("POST", f"projects/{project_id}/auth/refresh", {"refresh_token": self.tokens.refresh_token})
        tokens = AuthTokens(data["access_token"], data["refresh_token"])
        self.tokens.set_tokens(tokens.access_token, tokens.refresh_token)
        return tokens

    def logout(self, project_id):
        self._request("POST", f"projects/{project_id}/auth/logout", {"refresh_token": self.tokens.refresh_token})
        self.tokens.clear()
        return True

    def logout_all(self, project_id):
        self._request("POST", f"projects/{project_id}/auth/logout-all")
        self.tokens.clear()
        return True

    # --------------------
    # PASSWORD
    # --------------------
    def forgot_password(self, project_id, email):
        return self._request("POST", f"projects/{project_id}/auth/forgot-password", {"email": email})

    def reset_password(self, project_id, email, otp, new_password):
        body = {"email": email, "otp": otp, "new_password": new_password}
        return self._request("POST", f"projects/{project_id}/auth/reset-password", body)

    # --------------------
    # EMAIL VERIFICATION
    # --------------------
    def resend_verification(self, project_id, email):
        return self._request("POST", f"projects/{project_id}/auth/resend-verification-email", {"email": email})

    def verify_email(self, project_id, token):
        return self._request("POST", f"projects/{project_id}/auth/verify-email", {"token": token})

    # --------------------
    # PROFILE
    # --------------------
    def me(self, project_id=None):
        project_id = project_id or self.project_id
        return self._request("GET", f"projects/{project_id}/auth/me")

    def update_me(self, project_id=None, metadata=None):
        project_id = project_id or self.project_id
        return self._request("PATCH", f"projects/{project_id}/auth/me", {"metadata": metadata or {}})

    def change_password(self, project_id, old_password, new_password):
        body = {"old_password": old_password, "new_password": new_password}
        return self._request("POST", f"projects/{project_id}/auth/change-password", body)

    def delete_account(self, project_id=None):
        project_id = project_id or self.project_id
        return self._request("DELETE", f"projects/{project_id}/auth/delete")

    # --------------------
    # SESSIONS
    # --------------------
    def list_sessions(self, project_id):
        return self._request("GET", f"projects/{project_id}/auth/sessions")

    def revoke_session(self, project_id, session_id):
        return self._request("DELETE", f"projects/{project_id}/auth/sessions/{session_id}")

    # --------------------
    # API KEYS
    # --------------------
    def create_api_key(self, project_id, permissions=None, environment="prod"):
        body = {"permissions": permissions or {"read": True}, "environment": environment}
        return self._request("POST", f"projects/{project_id}/auth/api-keys/create", body)

    def list_api_keys(self, project_id):
        return self._request("GET", f"projects/{project_id}/auth/api-keys")

    def delete_api_key(self, project_id, key_id):
        return self._request("DELETE", f"projects/{project_id}/auth/api-keys/{key_id}")

    # --------------------
    # ADMIN
    # --------------------
    def list_users(self, project_id, status=None, email=None):
        params = {}
        if status: params["status"] = status
        if email: params["email"] = email
        return self._request("GET", f"projects/{project_id}/auth/users", params=params)

    def block_user(self, project_id, email, reason=None):
        return self._request("POST", f"projects/{project_id}/auth/block-user", {"email": email, "reason": reason or ""})

    def unblock_user(self, project_id, email):
        return self._request("POST", f"projects/{project_id}/auth/unblock-user", {"email": email})

    def ban_user(self, project_id, email, reason=None):
        return self._request("POST", f"projects/{project_id}/auth/ban-user", {"email": email, "reason": reason or ""})

    def unban_user(self, project_id, email):
        return self._request("POST", f"projects/{project_id}/auth/unban-user", {"email": email})

    # --------------------
    # API KEY HEADER
    # --------------------
    def set_api_key(self, key):
        self.api_key = key

    def clear_all(self):
        self.tokens.clear()
        self.api_key = None
