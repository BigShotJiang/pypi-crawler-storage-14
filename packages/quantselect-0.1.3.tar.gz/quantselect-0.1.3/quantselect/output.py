import os
from typing import Any, Dict, Optional, Union

import numpy as np
import pandas as pd
import torch

from quantselect.config import QuantSelectConfig
from quantselect.constants import ColumnConfig
from quantselect.dataloader import DataLoader
from quantselect.loader import Loader
from quantselect.ms1_features import FeatureConfig
from quantselect.preprocessing import Preprocessing, PreprocessingPipeline
from quantselect.shared_state import shared_state
from quantselect.utils import get_logger, set_global_determinism
from quantselect.var_model import Model
from quantselect.visualizer import Visualizer

logger = get_logger()


def run_model(
    output_path: str,
    config: Union[Dict[str, Any], QuantSelectConfig] = None,
    level: str = "pg",
    standardize: bool = True,
    plot_loss: bool = True,
    cutoff: float = 0.9,
    min_num_fragments: int = 12,
    no_const: int = 3000,
    save_quality_scores: bool = False,
    save_normalized_data: bool = False,
    seed: Optional[int] = 42,
    top_n: Optional[int] = None,
) -> pd.DataFrame:
    """
    Run the SelectLFQ model pipeline for protein quantification.

    Parameters
    ----------
    output_path : str
        Path to the directory containing feature files
    config : Union[Dict[str, Any], QuantSelectConfig], optional
        Configuration for model parameters. Can be either:
        - A dictionary with keys: "criterion_params", "model_params", "optimizer_params", "fit_params"
        - A QuantSelectConfig object
        - None to use default parameters
    level : str, default="pg"
        Level to predict: "pg" for protein groups or "mod_seq_charge_hash" for precursors
    standardize : bool, default=True
        Whether to standardize the input features
    plot_loss : bool, default=True
        Whether to plot training and validation loss curves
    cutoff : float, default=0.9
        Quality score cutoff used to remove low quality datapoints
    threshold : int, default=12
        Minimum number of datapoints per sample required for aggregation
    no_const : int, default=3000
        Number of proteins/precursors to use for sample-wise normalization
    save_normalized_data : str, optional
        Path to save the normalized data. If None, data won't be saved.
    save_quality_scores : bool, default=True
        Whether to save the quality scores for each protein/precursor.

    Returns
    -------
    pd.DataFrame
        Normalized prediction data with samples for columns
        and pg or precursor as rows.
    """
    # Set deterministic behavior
    if seed is not None:
        set_global_determinism(seed=seed)

    # Load and process features
    features = Loader().load_features(output_path)

    if top_n:
        features = filter_top_intensities_by_total_values(features, top_n=top_n, level=level)

    # Initialize preprocessing pipeline
    pipeline = PreprocessingPipeline(standardize=standardize)

    # Process data at specified level
    feature_layer, intensity_layer = pipeline.process(data=features, level=level)

    # Create dataloader object
    dataloader = DataLoader(feature_layer=feature_layer, intensity_layer=intensity_layer)

    # Handle configuration - support both new QuantSelectConfig and legacy dict format
    if config is None:
        # Use default configuration
        quantselect_config = QuantSelectConfig()
    elif isinstance(config, QuantSelectConfig):
        # Use provided QuantSelectConfig
        quantselect_config = config
    elif isinstance(config, dict):
        # Convert legacy dict format to QuantSelectConfig
        quantselect_config = QuantSelectConfig.from_dict(config)
    else:
        raise ValueError(f"config must be None, QuantSelectConfig, or dict, got {type(config)}")

    # Initialize model with configuration
    model, optimizer, criterion = Model.initialize_for_training(
        dataloader=dataloader,
        criterion_params=quantselect_config.CONFIG["criterion_params"],
        model_params=quantselect_config.CONFIG["model_params"],
        optimizer_params=quantselect_config.CONFIG["optmizer_params"],
    )

    # Train model with fit parameters from config
    fit_params = quantselect_config.CONFIG["fit_params"]
    model.fit(
        criterion=criterion,
        optimizer=optimizer,
        dataloader=dataloader,
        fit_params=fit_params,
    )

    if plot_loss:
        # Plot training progress
        Visualizer.plot_loss(model.train_loss, model.val_loss)

    # Generate predictions
    normalized_data = model.predict(
        dataloader=dataloader,
        cutoff=cutoff,
        min_num_fragments=min_num_fragments,
        no_const=no_const,
    )

    if save_normalized_data:
        _save_normalized_data(normalized_data, _get_identifiers(features), output_path)

    if save_quality_scores:
        _save_quality_scores(model, _get_identifiers(features), output_path)

    return normalized_data, model


def _save_normalized_data(normalized_data: pd.DataFrame, identifiers: pd.DataFrame, path: str) -> None:
    if shared_state.level == "pg":
        filename = "pg.matrix.normalized.tsv"
    else:
        filename = "precursor.matrix.normalized.tsv"
        identifiers = identifiers.drop_duplicates(subset=["mod_seq_charge_hash"])

    filepath = os.path.join(path, filename)

    if shared_state.level == "mod_seq_charge_hash":
        normalized_data = normalized_data.reset_index(names="mod_seq_charge_hash")
        normalized_data = normalized_data.merge(
            identifiers[["mod_seq_charge_hash", "pg"]].drop_duplicates(subset=["mod_seq_charge_hash"]),
            on="mod_seq_charge_hash",
            how="left",
        )
        normalized_data["mod_seq_charge_hash;pg"] = (
            normalized_data["mod_seq_charge_hash"].astype("string") + ";" + normalized_data["pg"].astype("string")
        )
        normalized_data = normalized_data.drop(columns=["mod_seq_charge_hash", "pg"])
        normalized_data = normalized_data.set_index("mod_seq_charge_hash;pg")
    normalized_data.to_csv(filepath, sep="\t")
    logger.info("Saved %s (%d rows)", filename, len(normalized_data))


def _match_pg_and_mod_seq_charge_hash(normalized_data: pd.DataFrame, identifiers: pd.DataFrame) -> pd.DataFrame:
    normalized_data = normalized_data.reset_index(names="mod_seq_charge_hash")
    normalized_data = normalized_data.merge(
        identifiers[["mod_seq_charge_hash", "pg"]].drop_duplicates(subset=["mod_seq_charge_hash"]),
        on="mod_seq_charge_hash",
        how="left",
    )
    normalized_data["mod_seq_charge_hash;pg"] = (
        normalized_data["mod_seq_charge_hash"].astype("string") + ";" + normalized_data["pg"].astype("string")
    )
    normalized_data = normalized_data.drop(columns=["mod_seq_charge_hash", "pg"])
    normalized_data = normalized_data.set_index("mod_seq_charge_hash;pg")
    return normalized_data


def _save_quality_scores(model: Model, identifiers: pd.DataFrame, save_path: str) -> None:
    """
    Save the quality scores for each protein/precursor.
    """

    quality_scores = pd.DataFrame(np.vstack(model.quality_score))
    if shared_state.sorted_columns is not None:
        quality_scores.columns = shared_state.sorted_columns
    else:
        print("No sorted columns found. DataFrame will be saved without column names.")
    quality_scores = pd.concat([identifiers, quality_scores], axis=1)

    filename = "quality.score.matrix.tsv"
    if shared_state.level == "pg":
        filename = "pg.quality.score.matrix.tsv"
    else:
        filename = "precursor.quality.score.matrix.tsv"
        identifiers = identifiers.drop_duplicates(subset=["mod_seq_charge_hash"])

    filepath = os.path.join(save_path, filename)
    quality_scores.to_csv(filepath, sep="\t")
    logger.info("Saved %s (%d rows)", filename, len(quality_scores))


def _get_identifiers(features: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """
    Get the fragment level identifiers.
    """
    return pd.concat(
        [
            g
            for _, g in features["ms2"]["ms2_intensity"][
                ["precursor_idx", "ion", "pg", "mod_seq_hash", "mod_seq_charge_hash"]
            ].groupby(shared_state.level)
        ]
    ).reset_index(drop=True)


def filter_top_intensities_by_max(features, top_n=50, level="pg"):
    """
    Alternative version: ranks by maximum intensity instead of mean.

    Use this if you want to keep the rows with the highest peak intensities
    rather than highest average intensity across samples.
    """

    filtered_features = {}

    for ms_level, dataframes_dict in features.items():
        print(f"\nProcessing {ms_level}...")
        if ms_level == "ms1":
            intensity_key = "ms1_pg.intensity"
        else:
            intensity_key = "ms2_intensity"

        if intensity_key not in dataframes_dict:
            print(f"  Warning: '{intensity_key}' not found in {ms_level}, skipping")
            filtered_features[ms_level] = dataframes_dict.copy()
            continue

        intensity_df = dataframes_dict[intensity_key]

        if level not in intensity_df.columns:
            print(f"  Warning: '{level}' column not found, skipping")
            filtered_features[ms_level] = dataframes_dict.copy()
            continue

        indices_to_keep = []

        identifiers_to_remove = set(ColumnConfig.IDENTIFIERS) - set(level)
        intensity_df = intensity_df.drop(identifiers_to_remove, errors="ignore")

        for _, group in intensity_df.groupby(level):
            intensity_cols = group.select_dtypes(include=[np.number]).columns

            if len(intensity_cols) == 0:
                continue

            # Rank by MAXIMUM intensity (instead of mean)
            group_max_intensities = group[intensity_cols].mean(axis=1)
            top_indices = group_max_intensities.nlargest(min(top_n, len(group))).index
            indices_to_keep.extend(top_indices)

        print(f" Keeping {len(indices_to_keep)} rows from original {len(intensity_df)}")
        print(indices_to_keep)

        filtered_features[ms_level] = {}
        for feature_name, df in dataframes_dict.items():
            filtered_df = df.loc[indices_to_keep].copy()
            filtered_features[ms_level][feature_name] = filtered_df
            print(f"  - {feature_name}: {len(df)} → {len(filtered_df)} rows")

    return filtered_features


import numpy as np
import pandas as pd


def filter_top_intensities_by_total_values(features, top_n=50, level="pg"):
    """
    Filter by keeping rows that contain the top (N * num_samples) intensity values.

    This approach is different from mean/max ranking:
    - Instead of ranking rows by their mean/max intensity
    - We find the top (N * num_samples) individual intensity values
    - And keep any row that contains at least one of these top values

    Example:
    --------
    If top_n=50 and you have 18 samples:
    - We find the top 900 intensity values per protein group
    - Keep all rows that contain any of these top 900 values

    This is useful because:
    - Accounts for the number of replicates/samples
    - A row with one very high intensity in one sample can be kept
    - More sensitive to peak intensities across all samples

    Parameters:
    -----------
    features : dict
        Nested dictionary: {ms_level: {feature_name: DataFrame}}
    top_n : int, default=50
        Multiplier for number of top values to keep
        Total values kept = top_n * number_of_samples
    level : str, default='pg'
        Column name for grouping (e.g., 'pg', 'peptide')

    Returns:
    --------
    dict : Filtered features
    """

    filtered_features = {}

    for ms_level, dataframes_dict in features.items():
        print(f"\nProcessing {ms_level}...")

        # Determine intensity key based on MS level
        if ms_level == "ms1":
            intensity_key = "ms1_pg.intensity"
        else:
            intensity_key = "ms2_intensity"

        if intensity_key not in dataframes_dict:
            print(f"  Warning: '{intensity_key}' not found in {ms_level}, skipping")
            filtered_features[ms_level] = dataframes_dict.copy()
            continue

        intensity_df = dataframes_dict[intensity_key].copy()

        if level not in intensity_df.columns:
            print(f"  Warning: '{level}' column not found, skipping")
            filtered_features[ms_level] = dataframes_dict.copy()
            continue

        # Add position tracking for correct filtering
        intensity_df["__position__"] = range(len(intensity_df))

        positions_to_keep = []

        for pg, group in intensity_df.groupby(level):
            # Get numeric columns (intensity values)
            intensity_cols = group.select_dtypes(include=[np.number]).columns
            intensity_cols = [col for col in intensity_cols if col != "__position__"]

            if len(intensity_cols) == 0:
                continue

            # Calculate how many values to keep
            num_samples = len(intensity_cols)
            num_values_to_keep = top_n * num_samples

            # Flatten all intensity values with their row positions
            all_values = []
            for idx, row in group.iterrows():
                position = row["__position__"]
                for col in intensity_cols:
                    value = row[col]
                    if pd.notna(value):  # Skip NaN values
                        all_values.append((value, position))

            # Sort by intensity value (descending) and take top N*samples
            all_values.sort(key=lambda x: x[0], reverse=True)
            top_values = all_values[:num_values_to_keep]

            # Get unique positions that contain these top values
            top_positions = list(set([pos for _, pos in top_values]))
            positions_to_keep.extend(top_positions)

        print(f"  Keeping {len(positions_to_keep)} rows from original {len(dataframes_dict[intensity_key])}")

        # Apply filtering to all DataFrames using positional indexing
        filtered_features[ms_level] = {}
        for feature_name, df in dataframes_dict.items():
            filtered_df = df.iloc[positions_to_keep].copy()
            filtered_features[ms_level][feature_name] = filtered_df
            print(f"  - {feature_name}: {len(df)} → {len(filtered_df)} rows")

    return filtered_features


def run_quantselect(seed: int, psm_df: pd.DataFrame, feature_dfs_dict: dict[str, pd.DataFrame], lfq_config: dict):
    torch.manual_seed(seed)
    np.random.seed(seed)

    quantselect_config = QuantSelectConfig().CONFIG

    precursor_df = Loader()._pivot_table_by_feature(
        FeatureConfig.DEFAULT_FEATURES, psm_df[psm_df["precursor.decoy"] == 0]
    )
    keys = list(feature_dfs_dict.keys())
    for k in keys:
        if "ms2" not in k:
            feature_dfs_dict[f"ms2_{k}"] = feature_dfs_dict.pop(k)
    features = {
        "ms1": precursor_df,
        "ms2": feature_dfs_dict,
    }

    pipeline = PreprocessingPipeline(standardize=True)

    feature_layer, intensity_layer = pipeline.process(data=features, level=lfq_config.quant_level)

    dataloader = DataLoader(feature_layer=feature_layer, intensity_layer=intensity_layer)

    model, optimizer, criterion = Model.initialize_for_training(
        dataloader=dataloader,
        criterion_params=quantselect_config["criterion_params"],
        model_params=quantselect_config["model_params"],
        optimizer_params=quantselect_config["optmizer_params"],
    )

    fit_params = quantselect_config["fit_params"]
    model.fit(
        criterion=criterion,
        optimizer=optimizer,
        dataloader=dataloader,
        fit_params=fit_params,
    )

    normalized_data = model.predict(
        dataloader=dataloader,
        cutoff=0.5,
        min_num_fragments=12,
        no_const=len(intensity_layer) // 2,
    )

    # Improved pipeline for combining predictions and robust normalization

    # Identify quality columns and compute average quality per row
    exclude_cols = {"precursor_idx", "ion", "pg", "mod_seq_hash", "mod_seq_charge_hash"}
    quality_df = feature_dfs_dict["ms2_correlation"].copy()
    run_columns = [c for c in quality_df.columns if c not in exclude_cols]

    # Compute mean quality and per-group rank for filtering
    quality_df["total"] = quality_df[run_columns].mean(axis=1)
    quality_df["rank"] = quality_df.groupby(lfq_config.quant_level)["total"].rank(ascending=False, method="first")

    # Mask: keep top-N per group or if quality above threshold
    top_n = 12
    quality_cutoff = 0.9
    mask = (quality_df["rank"] <= top_n) | (quality_df["total"] > quality_cutoff)

    # Robust intensity aggregation pipeline
    ms2_intensity_df = feature_dfs_dict["ms2_intensity"].loc[mask].set_index(lfq_config.quant_level)
    ms2_intensity_df = ms2_intensity_df[run_columns]
    ms2_intensity_df = ms2_intensity_df.replace(0, np.nan)
    ms2_intensity_log2 = np.log2(ms2_intensity_df)

    preprocessing = Preprocessing()
    extr_data = preprocessing.extract_data_from_level(ms2_intensity_log2, lfq_config.quant_level)
    aligned_data = preprocessing.init_align(extr_data)

    # Aggregate using nanmedian for robustness, normalize by sample
    agg_aligned_array = np.concatenate(
        [np.nanmedian(aligned, axis=0, keepdims=True) for aligned in aligned_data],
        axis=0,
    )
    agg_aligned_array = preprocessing.normalize_by_sample(agg_aligned_array, max(1, len(extr_data) // 2))

    agg_aligned_df = pd.DataFrame(agg_aligned_array, columns=ms2_intensity_log2.columns)
    agg_aligned_df = agg_aligned_df.sort_index(axis=1)

    # Combine with model prediction via shift and mean
    shifter = normalized_data.mean(axis=1).to_numpy().reshape(-1, 1)
    median_centered = agg_aligned_df.subtract(agg_aligned_df.mean(axis=1), axis=0)
    shifted_data = median_centered.add(shifter)

    # Take mean of shifted and initial (model-based) normalized data
    normalized_combined = (shifted_data.sort_index(axis=1).values + normalized_data.values) / 2
    normalized_data = pd.DataFrame(normalized_combined, index=normalized_data.index, columns=normalized_data.columns)

    return (2**normalized_data).reset_index(names=lfq_config.quant_level)
