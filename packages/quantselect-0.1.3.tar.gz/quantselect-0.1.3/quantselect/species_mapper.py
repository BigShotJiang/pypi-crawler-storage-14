import pandas as pd


def parse_fasta_ids(fasta_path):
    """
    Parse a FASTA file and extract all protein IDs.
    Handles various FASTA header formats including UniProt IDs.
    """
    protein_ids = set()

    with open(fasta_path, "r") as f:
        for line in f:
            if line.startswith(">"):
                # Extract ID from header
                # Common formats:
                # >sp|P12345|PROT_HUMAN
                # >P12345
                # >tr|A0A024R1R8|...
                header = line.strip()[1:]  # Remove '>'

                # Split by '|' if present (UniProt format)
                if "|" in header:
                    parts = header.split("|")
                    # Usually the ID is in the second position for sp|ID|NAME format
                    if len(parts) >= 2:
                        protein_ids.add(parts[1])
                    # Also add the first part in case it's the ID
                    protein_ids.add(parts[0])
                else:
                    # If no '|', take the first whitespace-separated token
                    protein_ids.add(header.split()[0])

    return protein_ids


def create_species_mapping(ecoli_fasta, human_fasta, yeast_fasta):
    """
    Create a mapping dictionary from protein IDs to species.
    """
    print("Parsing E. coli FASTA...")
    ecoli_ids = parse_fasta_ids(ecoli_fasta)
    print(f"Found {len(ecoli_ids)} E. coli protein IDs")

    print("Parsing Human FASTA...")
    human_ids = parse_fasta_ids(human_fasta)
    print(f"Found {len(human_ids)} Human protein IDs")

    print("Parsing Yeast FASTA...")
    yeast_ids = parse_fasta_ids(yeast_fasta)
    print(f"Found {len(yeast_ids)} Yeast protein IDs")

    # Create mapping dictionary
    species_mapping = {}

    for protein_id in ecoli_ids:
        species_mapping[protein_id] = "ECOLI"

    for protein_id in human_ids:
        species_mapping[protein_id] = "HUMAN"

    for protein_id in yeast_ids:
        species_mapping[protein_id] = "YEAST"

    return species_mapping


def map_dataframe_to_species(df, species_mapping):
    """
    Map DataFrame index (protein IDs) to species.
    Handles cases where index contains multiple IDs separated by semicolons.
    """
    species_list = []

    for id in df.index.str.split(";").str[0]:
        # Handle multiple IDs separated by semicolons

        # Try to find species for each ID
        found_species = set()
        if id in species_mapping:
            found_species.add(species_mapping[id])

        # Assign species
        if len(found_species) == 1:
            species_list.append(list(found_species)[0])
        elif len(found_species) > 1:
            # If multiple species found, join them
            species_list.append(";".join(sorted(found_species)))
        else:
            # If no match found, mark as unknown
            species_list.append("Unknown")

    return species_list
