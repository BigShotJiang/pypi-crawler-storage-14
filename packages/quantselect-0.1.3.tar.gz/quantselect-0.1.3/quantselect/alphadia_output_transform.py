from typing import Any, Dict, Optional, Union

import pandas as pd

from quantselect.config import QuantSelectConfig
from quantselect.constants import ColumnConfig
from quantselect.dataloader import DataLoader
from quantselect.loader import Loader
from quantselect.ms1_features import FeatureConfig
from quantselect.output import _get_identifiers, _save_normalized_data, _save_quality_scores
from quantselect.preprocessing import PreprocessingPipeline
from quantselect.shared_state import shared_state
from quantselect.utils import set_global_determinism
from quantselect.var_model import Model


def rename_feature_dict(feature_dict: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
    """
    Rename the features in the feature dictionary by adding 'ms2_' in front of each key, in place.
    """
    keys = list(feature_dict.keys())
    for k in keys:
        feature_dict[f"ms2_{k}"] = feature_dict.pop(k)
    return feature_dict


def create_features_for_quantselect_input(ms1_features: pd.DataFrame, ms2_features: list[pd.DataFrame]):
    """
    Create the features for the quantselect input.

    Parameters
    ----------
    ms1_features: pd.DataFrame
    ms2_features: list[pd.DataFrame]
    Returns
    -------
    features: dict[str, pd.DataFrame]
    """

    precursor_features = Loader()._pivot_table_by_feature(FeatureConfig.DEFAULT_FEATURES, ms1_features)
    ms2_features = rename_feature_dict(ms2_features)
    shared_state.ms2_identifiers = ms2_features["ms2_intensity"][ColumnConfig.IDENTIFIERS]
    features = {
        "ms1": precursor_features,
        "ms2": ms2_features,
    }
    return features


def run_quantselect(
    ms1_features: pd.DataFrame,
    ms2_features: list[pd.DataFrame],
    config: Union[Dict[str, Any], QuantSelectConfig] = None,
    level: str = "pg",
    standardize: bool = True,
    cutoff: float = 0.9,
    min_num_fragments: int = 12,
    no_const: int = 3000,
    seed: Optional[int] = 42,
) -> pd.DataFrame:
    """
    Run the SelectLFQ model pipeline for protein quantification.

    Parameters
    ----------
    ms1_features: pd.DataFrame
    ms2_features: list[pd.DataFrame]
    config : Union[Dict[str, Any], QuantSelectConfig], optional
        Configuration for model parameters. Can be either:
        - A dictionary with keys: "criterion_params", "model_params", "optimizer_params", "fit_params"
        - A QuantSelectConfig object
        - None to use default parameters
    level : str, default="pg"
        Level to predict: "pg" for protein groups or "mod_seq_charge_hash" for precursors
    standardize : bool, default=True
        Whether to standardize the input features
    cutoff : float, default=0.9
        Quality score cutoff used to remove low quality datapoints
    threshold : int, default=12
        Minimum number of datapoints per sample required for aggregation
    no_const : int, default=3000
        Number of proteins/precursors to use for sample-wise normalization
    save_normalized_data : str, optional
        Path to save the normalized data. If None, data won't be saved.
    save_quality_scores : bool, default=False
        Whether to save the quality scores for each protein/precursor.
    output_path : str, optional
        Path to save the normalized data and quality scores. If None, data won't be saved.

    Returns
    -------
    pd.DataFrame
        Normalized prediction data with samples for columns
        and pg or precursor as rows.
    """

    if seed is not None:
        set_global_determinism(seed=seed)

    features = create_features_for_quantselect_input(ms1_features, ms2_features)

    # Initialize preprocessing pipeline
    pipeline = PreprocessingPipeline(standardize=standardize)

    # Process data at specified level
    feature_layer, intensity_layer = pipeline.process(data=features, level=level)

    # Create dataloader object
    dataloader = DataLoader(feature_layer=feature_layer, intensity_layer=intensity_layer)

    # Handle configuration - support both new QuantSelectConfig and legacy dict format
    if config is None:
        # Use default configuration
        quantselect_config = QuantSelectConfig()
    elif isinstance(config, QuantSelectConfig):
        # Use provided QuantSelectConfig
        quantselect_config = config
    elif isinstance(config, dict):
        # Convert legacy dict format to QuantSelectConfig
        quantselect_config = QuantSelectConfig.from_dict(config)
    else:
        raise ValueError(f"config must be None, QuantSelectConfig, or dict, got {type(config)}")

    # Initialize model with configuration
    model, optimizer, criterion = Model.initialize_for_training(
        dataloader=dataloader,
        criterion_params=quantselect_config.CONFIG["criterion_params"],
        model_params=quantselect_config.CONFIG["model_params"],
        optimizer_params=quantselect_config.CONFIG["optmizer_params"],
    )

    # Train model with fit parameters from config
    fit_params = quantselect_config.CONFIG["fit_params"]
    model.fit(
        criterion=criterion,
        optimizer=optimizer,
        dataloader=dataloader,
        fit_params=fit_params,
    )

    # Generate predictions
    normalized_data = model.predict(
        dataloader=dataloader,
        cutoff=cutoff,
        min_num_fragments=min_num_fragments,
        no_const=no_const,
    )

    return 2 ** normalized_data.reset_index(names=level), model
