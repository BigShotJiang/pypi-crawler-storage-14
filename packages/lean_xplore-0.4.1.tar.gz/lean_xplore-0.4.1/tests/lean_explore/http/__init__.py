# tests/lean_explore/http/__init__.py

"""Tests for the HTTP server module."""

