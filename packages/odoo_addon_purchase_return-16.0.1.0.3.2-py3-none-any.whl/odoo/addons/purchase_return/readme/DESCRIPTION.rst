This module allows to create Purchase Return Orders. Typically vendors expect
to receive Purchase Return Orders as the starting event for claims associated
with products or services delivered.

The process work pretty much the same as with Purchase Orders, but the flow
is inverted. Upon indication of quantities delivered (representing the
services that have been accepted to be refunded for, or products returned) you
can create the subsequent refund bills.
