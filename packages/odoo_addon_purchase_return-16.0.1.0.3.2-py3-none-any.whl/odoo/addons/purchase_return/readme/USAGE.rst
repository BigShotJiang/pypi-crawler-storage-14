To use this module, you need to:

* Attribute a type when editing purchase requests
