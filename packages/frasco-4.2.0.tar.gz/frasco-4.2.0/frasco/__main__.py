from flask.cli import main
main()
