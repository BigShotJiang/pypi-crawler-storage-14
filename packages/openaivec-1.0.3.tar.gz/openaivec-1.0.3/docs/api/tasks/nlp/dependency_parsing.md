# Dependency Parsing Task

::: openaivec.task.nlp.dependency_parsing
