# Pandas Extension

::: openaivec.pandas_ext