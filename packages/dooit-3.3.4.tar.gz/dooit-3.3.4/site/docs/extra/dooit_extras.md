# Dooit Extras

Dooit extras is another extension project which contains all different kinds of utilities to make it easy for you to rice your dooit setup!

[See Docs](https://dooit-org.github.io/dooit-extras/)

## Why a different package?

Unlike dooit, I think utilities will continously be changed and added which will have a more often release cycle. \
I would like to help all the users with their config if possible so it'll be better to have a separate repo for all those sorts of stuff

I'll also be making other unique plugins and hopefully others will too!

If you have any requests/ideas, feel free to open an issue.

Thanks <3
