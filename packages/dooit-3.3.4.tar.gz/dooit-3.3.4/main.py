from dooit.__main__ import main

main()
