class ApiComponent:
    """
    Base class for API Components
    """
