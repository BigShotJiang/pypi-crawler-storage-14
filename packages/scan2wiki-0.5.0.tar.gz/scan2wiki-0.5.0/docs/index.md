# scan2wiki API Documentation

::: scan
    options:
      show_submodules: true
