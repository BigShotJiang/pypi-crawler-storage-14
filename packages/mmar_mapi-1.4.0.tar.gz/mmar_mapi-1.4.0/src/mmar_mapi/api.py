# will be removed in the future
from mmar_mapi.services import *  # noqa: F403
