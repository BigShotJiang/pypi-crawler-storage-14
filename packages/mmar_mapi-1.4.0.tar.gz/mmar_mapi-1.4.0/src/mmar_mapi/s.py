"""alias for quick access"""
from mmar_mapi.services import *  # noqa: F403
