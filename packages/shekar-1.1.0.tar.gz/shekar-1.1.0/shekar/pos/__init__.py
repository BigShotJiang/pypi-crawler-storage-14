from .base import POSTagger
from .albert_pos import AlbertPOS

__all__ = ["POSTagger", "AlbertPOS"]
