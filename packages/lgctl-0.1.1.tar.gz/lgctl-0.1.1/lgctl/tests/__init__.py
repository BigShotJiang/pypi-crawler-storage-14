"""Tests for lgctl package."""
