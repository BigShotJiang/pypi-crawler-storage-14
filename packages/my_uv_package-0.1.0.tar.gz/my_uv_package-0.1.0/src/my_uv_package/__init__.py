__version__ = '0.0.1'
def main() -> None:
    print("Hello from my-uv-package!")
