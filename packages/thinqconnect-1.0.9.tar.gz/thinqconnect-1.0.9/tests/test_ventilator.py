from __future__ import annotations

from tests.device_test_base import DeviceTestBase
from thinqconnect.const import DeviceType
from thinqconnect.devices.ventilator import VentilatorDevice


class TestVentilator(DeviceTestBase):
    @classmethod
    def get_device_class(cls) -> type[VentilatorDevice]:
        return VentilatorDevice

    @classmethod
    def get_device_type(cls) -> str:
        return DeviceType.VENTILATOR

    async def check_control(self, device: VentilatorDevice):
        await device.set_ventilator_operation_mode("POWER_ON")
        await device.set_wind_strength("AUTO")
        await device.set_wind_strength("HIGH")
        await device.set_wind_strength("POWER")
        await device.set_wind_strength("LOW")
        await device.set_current_job_mode("VENT_AUTO")
        await device.set_current_job_mode("VENT_NATURE")
        await device.set_current_job_mode("VENT_HEAT_EXCHANGE")
        await device.set_absolute_time_to_stop(13, 30)
        await device.set_absolute_time_to_start(10, 20)
        await device.set_sleep_timer_relative_time_to_stop(3)
        await device.set_ventilator_operation_mode("POWER_OFF")
