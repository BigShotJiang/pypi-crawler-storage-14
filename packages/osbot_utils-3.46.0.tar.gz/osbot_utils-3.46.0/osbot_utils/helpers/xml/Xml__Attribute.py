from osbot_utils.type_safe.Type_Safe import Type_Safe


class Xml__Attribute(Type_Safe):
    name     : str
    value    : str
    namespace: str