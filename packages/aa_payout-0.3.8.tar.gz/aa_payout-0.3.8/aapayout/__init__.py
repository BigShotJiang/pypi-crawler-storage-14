"""Initialize the app"""

__version__ = "0.3.8"
__title__ = "AA Payout"
