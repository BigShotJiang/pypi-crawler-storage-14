"""Output formatting utilities"""

import json
import csv
from typing import List, Dict
from pathlib import Path


class OutputFormatter:
    """Format and export scan results"""

    @staticmethod
    def format_table(results: List[Dict], headers: List[str] = None) -> str:
        """
        Format results as an ASCII table

        Args:
            results: List of result dictionaries
            headers: Optional list of headers to display

        Returns:
            Formatted table string
        """
        if not results:
            return "No results to display"

        # Auto-detect headers if not provided
        if headers is None:
            headers = list(results[0].keys())

        # Calculate column widths
        col_widths = {}
        for header in headers:
            col_widths[header] = len(str(header))

        for result in results:
            for header in headers:
                value = result.get(header, '')
                col_widths[header] = max(col_widths[header], len(str(value)))

        # Build table
        separator = '+' + '+'.join('-' * (col_widths[h] + 2) for h in headers) + '+'
        header_row = '|' + '|'.join(f" {h:<{col_widths[h]}} " for h in headers) + '|'

        table = [separator, header_row, separator]

        for result in results:
            row = '|' + '|'.join(
                f" {str(result.get(h, '')):<{col_widths[h]}} " for h in headers
            ) + '|'
            table.append(row)

        table.append(separator)

        return '\n'.join(table)

    @staticmethod
    def format_json(results: List[Dict], pretty: bool = True) -> str:
        """
        Format results as JSON

        Args:
            results: List of result dictionaries
            pretty: Pretty print with indentation

        Returns:
            JSON string
        """
        if pretty:
            return json.dumps(results, indent=2, default=str)
        return json.dumps(results, default=str)

    @staticmethod
    def export_json(results: List[Dict], filepath: str):
        """
        Export results to JSON file

        Args:
            results: List of result dictionaries
            filepath: Output file path
        """
        with open(filepath, 'w') as f:
            json.dump(results, f, indent=2, default=str)

    @staticmethod
    def export_csv(results: List[Dict], filepath: str):
        """
        Export results to CSV file

        Args:
            results: List of result dictionaries
            filepath: Output file path
        """
        if not results:
            return

        headers = list(results[0].keys())

        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(results)

    @staticmethod
    def format_summary(results: List[Dict], scan_type: str = "scan") -> str:
        """
        Format a summary of scan results

        Args:
            results: List of result dictionaries
            scan_type: Type of scan performed

        Returns:
            Formatted summary string
        """
        summary = [
            f"\n{'=' * 60}",
            f"  RTSP Scanner - {scan_type.upper()} RESULTS",
            f"{'=' * 60}",
            f"Total results: {len(results)}",
        ]

        if results:
            # Group by status or other relevant field
            if 'status' in results[0]:
                open_count = sum(1 for r in results if r.get('status') == 'open')
                summary.append(f"Open ports: {open_count}")

            if 'reachable' in results[0]:
                reachable = sum(1 for r in results if r.get('reachable'))
                summary.append(f"Reachable: {reachable}")

            if 'status_code' in results[0]:
                code_200 = sum(1 for r in results if r.get('status_code') == 200)
                code_401 = sum(1 for r in results if r.get('status_code') == 401)
                summary.append(f"Accessible (200): {code_200}")
                summary.append(f"Auth required (401): {code_401}")

        summary.append('=' * 60 + '\n')

        return '\n'.join(summary)
