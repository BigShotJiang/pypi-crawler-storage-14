Sometimes we want to avoid that salesmen are able to modify prices that are fixed and
negociated with the customer in advance.
