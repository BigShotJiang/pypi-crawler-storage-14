#!/usr/bin/env python
# coding: utf-8
#
# Licensed under MIT
#

import setuptools

if __name__ == "__main__":
    setuptools.setup()