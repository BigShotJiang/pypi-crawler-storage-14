from .sqli_main import main as Plugin

__all__ = ["Plugin"]