from .xss import main as Plugin

__all__ = ["Plugin"]