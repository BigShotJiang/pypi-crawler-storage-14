"""Result dataclasses for trajectory evaluation."""

__all__ = ["ATEResult", "RPEResult", "AlignmentResult"]
