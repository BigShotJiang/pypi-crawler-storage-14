"""Main entry point for trajectopy - delegates to CLI."""

from trajectopy.cli.main import main

if __name__ == "__main__":
    main()
