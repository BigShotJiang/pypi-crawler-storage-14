# -*- coding: utf-8 -*-
"""
蜂巢云控 Python SDK

支持三种连接方式：
1. ADB直连（USB/WiFi）- 推荐
2. 中继服务器（需要APP开启无障碍）
3. HTTP直连APP

Example:
    >>> # ADB USB直连
    >>> from fengchao import ADBDevice
    >>> device = ADBDevice()
    >>> device.click(500, 800)
    
    >>> # ADB WiFi连接
    >>> device = ADBDevice.connect_wifi("192.168.1.100")
    >>> device.swipe_up()
    
    >>> # 中继服务器模式
    >>> from fengchao import Client
    >>> client = Client(api_key="sk-xxx", relay_server="http://server:9999")
    >>> device = client.get_device("DEVICE_001")
"""

__version__ = "1.0.0"
__author__ = "蜂巢云控"

from .client import Client
from .device import Device
from .element import Element
from .adb import ADBDevice
from .exceptions import (
    QunKongError,
    AuthError,
    ConnectionError,
    DeviceNotFoundError,
    TimeoutError,
    ElementNotFoundError
)

__all__ = [
    "Client",
    "Device",
    "ADBDevice",
    "Element",
    "QunKongError",
    "AuthError",
    "ConnectionError",
    "DeviceNotFoundError",
    "TimeoutError",
    "ElementNotFoundError"
]
