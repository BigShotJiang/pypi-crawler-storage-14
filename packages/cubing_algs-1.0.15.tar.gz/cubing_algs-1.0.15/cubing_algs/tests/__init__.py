"""Tests for cubing_algs."""
