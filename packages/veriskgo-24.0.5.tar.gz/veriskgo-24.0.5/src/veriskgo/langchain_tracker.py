"""
LangChain-specific LLM tracing for VeriskGO.
This file provides:
    - @track_langchain decorator (async + sync)
    - automatic Bedrock token extraction for LangChain pipelines
    - works even when LCEL returns plain strings
    - no modifications required in GenAI app code
"""

import time
import functools
import traceback
import inspect
import contextvars
from typing import cast, Dict, Any

from .trace_manager import TraceManager, serialize_value, calculate_cost


# =================================================================
# Context variable to store LangChain → Bedrock usage (per request)
# =================================================================

_last_lc_usage = contextvars.ContextVar("last_lc_usage", default=None)


# =================================================================
# Monkey-patch ChatBedrock to intercept raw Bedrock API responses
# =================================================================

def _patch_chatbedrock():
    """
    Safely monkey-patch ChatBedrock._prepare_request so we can intercept
    the Bedrock raw `usage` metadata and store it in contextvars.

    This allows @track_langchain() to capture full token usage
    even when a chain ends with StrOutputParser() and returns only a string.
    """
    try:
        from langchain_aws import ChatBedrock
    except Exception:
        return  # LangChain AWS not installed → skip patch

    # _prepare_request exists at runtime but is not typed → avoid Pylance error
    original_prepare = getattr(ChatBedrock, "_prepare_request", None)
    if not callable(original_prepare):
        return  # safety guard for future LangChain changes

    def patched_prepare(self, *args, **kwargs):
        # original_prepare(self, ...) returns a dict-like request object
        req = original_prepare(self, *args, **kwargs)

        # Cast req to dict for Pylance (runtime object is always dict)
        req = cast(Dict[str, Any], req)

        # Safe access with .get()
        original_body = req.get("body")  # type: ignore[index]
        if not callable(original_body):
            return req  # nothing to patch

        def new_body():
            # The response is also a dict at runtime
            response = original_body()

            response = cast(Dict[str, Any], response)  # cast for Pylance
            usage = response.get("usage")  # type: ignore[call-arg]

            if usage:
                _last_lc_usage.set(usage)

            return response

        req["body"] = new_body  # type: ignore[index]
        return req

    # Apply safe monkey patch
    setattr(ChatBedrock, "_prepare_request", patched_prepare)


# run the patch during import
_patch_chatbedrock()


# =================================================================
# Extract final LangChain output + token usage + cost
# =================================================================

def _extract_langchain_output(result: Any, model_id: str, latency: int):
    """
    Computes:
      - text output
      - token usage (input/output/total)
      - cost
    from either:
      - string result
      - tuple (summary, keywords)
      - any LangChain return value
    """

    usage_raw = _last_lc_usage.get()

    # Default zero-usage if nothing captured
    usage = {
        "input_tokens": usage_raw.get("inputTokens", 0) if usage_raw else 0,
        "output_tokens": usage_raw.get("outputTokens", 0) if usage_raw else 0,
    }
    usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]

    cost = calculate_cost(usage)

    # Extract result text
    if isinstance(result, tuple):
        text = result[0]   # (summary, keywords) → summary
    elif isinstance(result, str):
        text = result
    else:
        text = serialize_value(result)

    return {
        "status": "success",
        "model": model_id,
        "latency_ms": latency,
        "output": {"text": text},
        "usage": usage,
        "usage_details": usage,
        "cost": cost,
        "cost_details": cost,
    }


# =================================================================
# @track_langchain decorator (async + sync)
# =================================================================

def track_langchain(name: str = "langchain_call", *, model_id: str = "", tags=None):
    """
    Decorator for ANY LangChain-based LLM call:
      - LCEL pipeline (.invoke / .ainvoke)
      - ChatBedrock
      - Chains ending with StrOutputParser() → plain string

    Automatically records:
      - tokens (input/output/total)
      - cost
      - latency
      - text output

    Zero changes needed in GenAI app code.
    """

    def decorator(func):
        is_async = inspect.iscoroutinefunction(func)

        # -----------------------------
        # ASYNC wrapper
        # -----------------------------
        async def async_wrapper(*args, **kwargs):

            if not TraceManager.has_active_trace():
                return await func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={
                    "args": serialize_value(args),
                    "kwargs": serialize_value(kwargs)
                },
                tags=tags,
            )

            start = time.time()

            try:
                result = await func(*args, **kwargs)
            except Exception as e:
                TraceManager.end_span(
                    span_id,
                    {
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                    }
                )
                raise

            latency = int((time.time() - start) * 1000)
            span_output = _extract_langchain_output(result, model_id, latency)

            TraceManager.end_span(span_id, span_output)
            return result

        # -----------------------------
        # SYNC wrapper
        # -----------------------------
        def sync_wrapper(*args, **kwargs):

            if not TraceManager.has_active_trace():
                return func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={
                    "args": serialize_value(args),
                    "kwargs": serialize_value(kwargs)
                },
                tags=tags,
            )

            start = time.time()

            try:
                result = func(*args, **kwargs)
            except Exception as e:
                TraceManager.end_span(
                    span_id,
                    {
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                    }
                )
                raise

            latency = int((time.time() - start) * 1000)
            span_output = _extract_langchain_output(result, model_id, latency)

            TraceManager.end_span(span_id, span_output)
            return result

        return functools.wraps(func)(async_wrapper if is_async else sync_wrapper)

    return decorator
