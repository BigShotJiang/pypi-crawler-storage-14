from pydantic_core import PydanticUndefined

Undefined = PydanticUndefined
