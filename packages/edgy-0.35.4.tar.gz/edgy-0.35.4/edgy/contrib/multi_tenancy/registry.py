from edgy.core.connection.registry import Registry as TenantRegistry

__all__ = ["TenantRegistry"]
