"""
Sarmat.
"""
VERSION = "4.6.0"

__version__ = VERSION
