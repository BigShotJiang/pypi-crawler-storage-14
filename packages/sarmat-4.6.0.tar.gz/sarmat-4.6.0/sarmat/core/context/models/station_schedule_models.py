"""
Sarmat.
Ядро пакета.
Описание бизнес логики.
Модели.
Объекты для работы со станционным расписанием.
"""
from dataclasses import dataclass
from datetime import date, time
from uuid import UUID

from .sarmat_models import BaseModel
from .traffic_management_models import JourneyType


@dataclass
class BaseRoutePublication(BaseModel):
    """Маршрут (базовый класс)."""

    journey: UUID           # идентификатор публикации рейса
    sequence_number: int    # номер в последовательности
    point_name: str         # наименование пункта
    point_id: int           # идентификатор пункта


@dataclass
class RoutePublication(BaseRoutePublication):
    """Маршрут."""

    station_name: str | None = None             # наименование станции
    station_id: int | None = None               # идентификатор станции
    arrive_time: time | None = None             # время прибытия в пункт
    stop_time: int | None = None                # время стоянки
    departure_time: time | None = None          # время отправления из пункта
    ticket_amount: list[float] | None = None    # стоимость проезда с текущего пункта до конца
    baggage_amount: list[float] | None = None   # стоимость провоза багажа с текущего пункта до конца


@dataclass
class CalendarPublication(BaseModel):
    """График выезда в рейс."""

    journey: UUID           # идентификатор рейса
    carrier: int            # перевозчик
    departure_date: date    # дата выезда


@dataclass
class BaseJourneyPublication(BaseModel):
    """Публикация рейса (основные атрибуты)."""

    uid: UUID                               # идентификатора записи
    owner: int                              # владелец записи
    journey_type: JourneyType               # тип рейса
    name: str                               # наименование рейса
    number: int                             # номер
    is_chartered: bool                      # заказной рейс
    need_control: bool                      # паспортный контроль
    departure_time: time                    # время отправления из начальной точки
    route: list[RoutePublication]           # маршрут
    calendar: list[CalendarPublication]     # график выезда в рейс


@dataclass
class JourneyPublication(BaseJourneyPublication):
    """Публикация рейса."""

    literal: str | None = None              # литера
    vehicle_model: str | None = None        # модель ТС
    baggage_capacity: int | None = None     # вместимость багажного отделения
    seats: int | None = None                # места для сидения
    stand_places: int | None = None         # места для проезда стоя
    seats_map: dict | None = None           # схема расположения мест
