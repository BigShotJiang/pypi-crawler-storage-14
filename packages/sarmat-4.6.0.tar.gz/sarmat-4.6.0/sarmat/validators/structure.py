"""
Sarmat.
Валидаторы.
Структура для описания ошибок проверки.
"""
from dataclasses import dataclass


@dataclass
class ValidationIssue:
    """Описание проблемы."""

    field: str
    description: str
