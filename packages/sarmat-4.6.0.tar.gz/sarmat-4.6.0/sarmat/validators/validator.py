"""
Sarmat.
Валидаторы.
Класс валидации объектов.
"""
from typing import Callable, TypeVar
from sarmat.core.context.models import BaseModel
from sarmat.core.constants.exception_constants import SarmatNotFilledAttribute

from .structure import ValidationIssue
from ..core.constants import ErrorClass

SarmatModel = TypeVar("SarmatModel", bound=BaseModel)


class Validator:
    """Класс для организации проверки Sarmat объектов."""

    def __init__(self, validate_call: Callable):
        self._call = validate_call
        self._issues: list[ValidationIssue] = []

    @property
    def issues(self) -> list[ValidationIssue]:
        """Ошибки валидации модели."""
        return self._issues

    def is_valid(self, model: SarmatModel, raise_error: bool = False) -> bool:
        """Проверка модели."""
        self._issues = self._call(model)
        is_valid = not self._issues

        if not is_valid and raise_error:
            raise SarmatNotFilledAttribute(
                err_class=ErrorClass.DATA,
                title="Ошибка валидации рейса",
                description=f"Замечаний к модели: {len(self._issues)}",
            )

        return is_valid
