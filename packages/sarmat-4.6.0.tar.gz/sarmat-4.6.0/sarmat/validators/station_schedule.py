"""
Sarmat.
Валидаторы.
Проверка моделей перед публикацией рейса.
"""
from sarmat.core.context.models import (
    CalendarPublication,
    JourneyPublication,
    RoutePublication,
)

from .structure import ValidationIssue


def validate_calendar_publication(calendar: CalendarPublication) -> list[ValidationIssue]:
    """Проверка графика выезда."""
    issues = []

    if not calendar.journey:
        issues.append(ValidationIssue("journey", "Не указан идентификатор рейса"))

    if not calendar.carrier:
        issues.append(ValidationIssue("carrier", "Не указан перевозчик"))

    if not calendar.departure_date:
        issues.append(ValidationIssue("departure_date", "Не указана дата отправления"))

    return issues


def validate_route_item_publication(route_item: RoutePublication) -> list[ValidationIssue]:
    """Проверка элемента из состава маршрута."""
    issues = []

    if not route_item.journey:
        issues.append(ValidationIssue("journey", "Не указан идентификатор рейса"))

    if route_item.sequence_number is None or route_item.sequence_number < 0:
        issues.append(ValidationIssue("sequence_number", "Последовательность не указана или имеет неверное значение"))

    if not route_item.point_id:
        issues.append(ValidationIssue("point_id", "Не указан идентификатор пункта"))

    if not route_item.point_name:
        issues.append(ValidationIssue("point_name", "Не указано наименование пункта"))

    if route_item.station_id and not route_item.station_name:
        issues.append(ValidationIssue("station_name", "Не указано наименование станции"))

    if route_item.station_name and not route_item.station_id:
        issues.append(ValidationIssue("station_id", "Не указан идентификатор станции"))

    if route_item.sequence_number:
        if not route_item.arrive_time:
            issues.append(ValidationIssue("arrive_time", "Не указано время прибытия в пункт"))

    return issues


def validate_journey_publication(journey: JourneyPublication) -> list[ValidationIssue]:
    """Проверка рейса перед публикацией."""
    issues = []

    if not journey.uid:
        issues.append(ValidationIssue("uid", "Нет идентификатора рейса"))

    if not journey.owner:
        issues.append(ValidationIssue("owner", "Не указан автор публикации"))

    if not journey.journey_type:
        issues.append(ValidationIssue("journey_type", "Не указан тип рейса"))

    if not journey.name:
        issues.append(ValidationIssue("name", "Не указано наименование рейса"))

    if not journey.number:
        issues.append(ValidationIssue("number", "Не указан номер рейса"))

    if journey.is_chartered is None:
        issues.append(ValidationIssue("is_chartered", "Не указан признак заказного рейса"))

    if journey.need_control is None:
        issues.append(ValidationIssue("need_control", "Не указан признак паспортного контроля"))

    if not journey.departure_time:
        issues.append(ValidationIssue("departure_time", "Не указано время отправления"))

    if not journey.route:
        issues.append(ValidationIssue("route", "Нет состава маршрута"))

    for route_item in journey.route:
        issues.extend(validate_route_item_publication(route_item))
        if route_item.journey != journey.uid:
            issues.append(ValidationIssue("route_item", "Идентификатор точки маршрута не соответствует рейсу"))

    if not journey.calendar:
        issues.append(ValidationIssue("calendar", "Не указан график выезда"))

    for day in journey.calendar:
        issues.extend(validate_calendar_publication(day))
        if day.journey != journey.uid:
            issues.append(ValidationIssue("journey", "Идентификатор графика не соответствует рейсу"))

    if not journey.vehicle_model:
        issues.append(ValidationIssue("vehicle_model", "Не указана модель ТС"))

    if journey.seats and not journey.seats_map:
        issues.append(ValidationIssue("seats_map", "Не указана схема расположения мест"))

    if journey.seats_map and not journey.seats:
        issues.append(ValidationIssue("seats", "Не указано количество мест для сидения"))

    return issues
