# Librería matemática

##Funcionalidades básicas

###1. Método es_par(valor entero)
Devuelve True si el valor indicado es par y False al contrario

###2. Método es_impar(valor entero)
Devuelve True si el valor indicado es impar y False al contrario

###La forma de instalarlo es con:
pip install funciones

###Ejemplos de importación en proyecto cliente:
from funciones.funciones_maths import es_impar, es_par

###Ejemplo de uso en proyecto cliente:
print(es_impar(3)) 

True

print(es_par(2))

True
