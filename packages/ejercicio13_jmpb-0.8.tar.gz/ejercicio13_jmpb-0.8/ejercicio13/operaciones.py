from typing import Union

Number = Union[int, float]

def suma(a: Number, b: Number) -> Number:
    """Devuelve a + b"""
    return a + b

def resta(a: Number, b: Number) -> Number:
    """Devuelve a - b"""
    return a - b

def multiplicacion(a: Number, b: Number) -> Number:
    """Devuelve a * b"""
    return a * b

def division(a: Number, b: Number) -> float:
    """Devuelve a / b (lanza ZeroDivisionError si b == 0)"""
    return a / b