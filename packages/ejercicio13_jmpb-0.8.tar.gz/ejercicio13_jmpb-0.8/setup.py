from setuptools import setup, find_packages

setup(
    # Se especifica el nombre de la librería
    name="ejercicio13-jmpb",
    # Se especifica el nombre del paquete (Python)
    packages=find_packages(exclude=["tests", "*.tests", "*.tests.*", "tests.*"]),
    # Se especifica la versión
    version="0.8",
    # Se especifica la licencia escogida
    license="MIT",
    # Breve descripción de la librería
    description="Libreria de mates con operaciones básicas",
    # Nombre del autor
    author="José Manuel Pérez Barros",
    # Email del autor
    author_email="xxx@gmail.com",
    # Enlace al repositorio de git de la librería
    url="https://github.com/RobertoCoronaEscamilla/libreria_rc",
    # Enlace de descarga de la librería
    download_url="https://github.com/RobertoCoronaEscamilla/libreria_rc/archive/refs/heads/main.zip",
    # Palabras claves de la librería
    keywords=["mates", "operaciones", "suma", "resta"],
    # Librerías externas que requieren la librería (solo runtime)
    install_requires=[],
    # Dependencias opcionales para desarrollo
    extras_require={
        "dev": ["pytest>=6.0"],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.14",
    ],
    python_requires=">=3.6",
)
