# AppServicesDynamicExecutionSchemasDynamicExecutionStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | 

## Example

```python
from revengai.models.app_services_dynamic_execution_schemas_dynamic_execution_status import AppServicesDynamicExecutionSchemasDynamicExecutionStatus

# TODO update the JSON string below
json = "{}"
# create an instance of AppServicesDynamicExecutionSchemasDynamicExecutionStatus from a JSON string
app_services_dynamic_execution_schemas_dynamic_execution_status_instance = AppServicesDynamicExecutionSchemasDynamicExecutionStatus.from_json(json)
# print the JSON string representation of the object
print(AppServicesDynamicExecutionSchemasDynamicExecutionStatus.to_json())

# convert the object into a dict
app_services_dynamic_execution_schemas_dynamic_execution_status_dict = app_services_dynamic_execution_schemas_dynamic_execution_status_instance.to_dict()
# create an instance of AppServicesDynamicExecutionSchemasDynamicExecutionStatus from a dict
app_services_dynamic_execution_schemas_dynamic_execution_status_from_dict = AppServicesDynamicExecutionSchemasDynamicExecutionStatus.from_dict(app_services_dynamic_execution_schemas_dynamic_execution_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


