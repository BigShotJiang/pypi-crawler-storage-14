# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["UsageEventIngestResponse"]


class UsageEventIngestResponse(BaseModel):
    ingested_count: int
