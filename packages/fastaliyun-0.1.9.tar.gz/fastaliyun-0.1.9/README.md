# fastaliyun

#### 介绍
快捷使用阿里云模块

#### 软件架构
软件架构说明


#### 安装教程

1.  pip安装
```shell script
pip install fastaliyun
```
2.  pip安装（使用淘宝镜像加速）
```shell script
pip install fastaliyun -i https://mirrors.aliyun.com/pypi/simple
```

#### 使用说明

1.  demo
```python
import fastaliyun
res = fastaliyun.datahub.project_list()
```
