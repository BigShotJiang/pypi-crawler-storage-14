"""Integration tests for image generation capability."""
