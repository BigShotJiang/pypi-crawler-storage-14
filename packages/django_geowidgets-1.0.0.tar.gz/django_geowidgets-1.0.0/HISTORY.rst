=======
History
=======

1.0.0 (2025-11-28)
==================

- Compatible with Python 3.10 through Python 3.13.
- Uses type hinting.
- Build and version management modernized with pyproject.toml and
  setuptools_scm.

0.1.2 (2024-04-22)
==================

- Updated requirements so that it is compatible with Django 4 and 5.

0.1.1 (2021-04-08)
==================

- Updated requirements so that it is compatible with Django 3.

0.1.0 (2019-08-13)
==================

- Initial release.
