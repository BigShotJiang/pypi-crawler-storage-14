This module does the following:

- Extends \_prepare_subcontract_mo_vals() and adds the purchase order
  line reference to the subcontracted manufacturing orders.
- Adds an action button in the purchase order form view to open related
  subcontracted manufacturing orders.
