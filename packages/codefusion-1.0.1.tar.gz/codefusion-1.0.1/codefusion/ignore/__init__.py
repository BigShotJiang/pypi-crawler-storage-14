from .manager import IgnoreManager
