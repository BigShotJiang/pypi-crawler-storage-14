# Static version file
__version__ = "1.0.1"
version = "1.0.1"
__version_tuple__ = (1, 0, 1)
version_tuple = (1, 0, 1)
