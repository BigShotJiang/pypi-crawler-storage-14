# AWS S3

::: rustac.store.S3Store
::: rustac.store.S3Config
    options:
        show_if_no_docstring: true
::: rustac.store.S3Credential
::: rustac.store.S3CredentialProvider
