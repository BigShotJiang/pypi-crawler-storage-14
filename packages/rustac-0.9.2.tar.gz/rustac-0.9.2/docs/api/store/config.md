# Configuration

::: rustac.store.ClientConfig
::: rustac.store.BackoffConfig
::: rustac.store.RetryConfig
