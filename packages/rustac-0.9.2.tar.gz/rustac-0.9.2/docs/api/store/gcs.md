# Google Cloud Storage

::: rustac.store.GCSStore
::: rustac.store.GCSConfig
    options:
        show_if_no_docstring: true
::: rustac.store.GCSCredential
::: rustac.store.GCSCredentialProvider
