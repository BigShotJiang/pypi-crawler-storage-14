# ObjectStore

::: rustac.store.from_url
::: rustac.store.ObjectStore
