---
description: Write STAC to the filesystem or to blob storage
---

# Write

::: rustac.write
