---
description: Read STAC from the local filesystem or blob storage
---

# Read

::: rustac.read
