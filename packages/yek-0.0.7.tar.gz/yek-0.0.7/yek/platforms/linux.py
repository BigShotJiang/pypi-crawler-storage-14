"""Linux keyboard state alias."""

from yek.platforms.common import PynputKeyboardState as LinuxKeyboardState

__all__ = ["LinuxKeyboardState"]
