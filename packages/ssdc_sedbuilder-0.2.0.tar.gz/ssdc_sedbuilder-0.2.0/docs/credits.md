# Acknowledgment

This client package was realized by [Giuseppe Dilillo](https://gdilillo.com/).

It would not exist without the work of Fabrizio Fabri on the REST API.

Which would not exist itself without the work on the [SED Builder](https://tools.ssdc.asi.it/SED/) service by Capalbi, Cutini, Gasparrini, Giommi, Maselli, Primavera, Stratta and maybe others[^1].

I hope you enjoy it!

[^1]: Please if you worked on SED Builder and you are missing from this list, let me know!