
PyTRiP98 Documentation
======================

Contents:

.. toctree::
   :maxdepth: 2

   getting_started.rst
   install.rst
   user_guide.rst
   interaction_with_trip.rst
   examples.rst
   authors.rst
   Source Code <apidoc/pytrip>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

