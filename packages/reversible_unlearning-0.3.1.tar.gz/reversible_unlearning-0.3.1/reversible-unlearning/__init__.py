﻿# reversible_unlearning/__init__.py (v0.3.0)
"""
AUREON: Production-grade reversible machine unlearning framework
Package: reversible_unlearning
Version: 0.3.0
"""

__version__ = "0.3.0"
__author__ = "AUREON Labs"

# Import all V3 components
from .core import (
    Reversible,
    ForgetVerification,
    BalancedUnlearner,           # NEW V3
    SelectiveGradientUnlearner,  # NEW V3
    MembershipInferenceTest,     # NEW V3
    verify_unlearning_quality,   # NEW V3
    reversible_pipeline
)

# Export for direct import
__all__ = [
    "Reversible",
    "ForgetVerification",
    "BalancedUnlearner",
    "SelectiveGradientUnlearner",
    "MembershipInferenceTest",
    "verify_unlearning_quality",
    "reversible_pipeline"
]
