import asyncio
import inspect
from typing import Optional, Callable, Any, Literal, Union

from .core.moment import StageInfo, Moment
from .core.adventure import Adventure, get_pool, register_adventure, remove_adventure
from .core.elf import Elf

MaybeStrOrCallable = Union[str, Callable[..., str]]


def _validate_maybe_callable(
        value: Optional[MaybeStrOrCallable],
        fn: Callable[..., Any],
        label: str,
) -> None:
    if value is None:
        return
    if isinstance(value, str):
        return
    if not callable(value):
        raise TypeError(
            f"Expected string or callable for '{label}'; "
            f"got {type(value).__name__} instead. "
            f"Perhaps you meant to call it? e.g. "
            f"@oops_moment({label}={value}())"
        )

    fn_sig = inspect.signature(fn)
    value_sig = inspect.signature(value)

    missing = []
    for name, param in value_sig.parameters.items():
        if param.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
        ):
            continue
        if name not in fn_sig.parameters:
            missing.append(name)

    if missing:
        raise TypeError(
            f"Callable for '{label}' has parameters {missing} which "
            f"are not in the signature of function '{fn.__name__}'. "
            f"Expected parameters to be a subset of {list(fn_sig.parameters.keys())}."
        )


def _resolve_maybe_callable(
        value: Optional[MaybeStrOrCallable],
        default: str,
        bound_args: inspect.BoundArguments,
        label: str,
        fn_name: str,
) -> str:
    if value is None:
        return default
    if isinstance(value, str):
        return value

    call_kwargs = {}
    value_sig = inspect.signature(value)
    for name, param in value_sig.parameters.items():
        if param.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
        ):
            continue
        if name in bound_args.arguments:
            call_kwargs[name] = bound_args.arguments[name]

    try:
        result = value(**call_kwargs)
    except Exception as exc:
        raise TypeError(
            f"Error while calling '{label}' callable for function '{fn_name}': {exc}"
        ) from exc

    if not isinstance(result, str):
        raise TypeError(
            f"Callable for '{label}' on function '{fn_name}' must return str; "
            f"got {type(result).__name__} instead."
        )

    return result


def oops_moment_auto(
        *,
        chapter: str,
        stage: Optional[MaybeStrOrCallable] = None,
        name: Optional[MaybeStrOrCallable] = None,
        elf: Optional[Elf] = None,
        mode: Literal["auto", "async", "sync"] = "auto",
):
    def deco(fn: Callable[..., Any]):
        fn_sig = inspect.signature(fn)

        _validate_maybe_callable(stage, fn, "stage")
        _validate_maybe_callable(name, fn, "name")

        async def _async_call(*args, **kwargs):
            bound = fn_sig.bind_partial(*args, **kwargs)

            pool = get_pool()
            created = False
            if pool:
                adv = pool[0]
            else:
                adv = Adventure(name="auto")
                register_adventure(adv)
                created = True
                await adv.start()

            resolved_stage = _resolve_maybe_callable(
                stage,
                fn.__name__,
                bound,
                label="stage",
                fn_name=fn.__name__,
            )
            resolved_name = _resolve_maybe_callable(
                name,
                fn.__name__,
                bound,
                label="name",
                fn_name=fn.__name__,
            )

            st = StageInfo(
                chapter=chapter,
                stage=resolved_stage,
                name=resolved_name,
            )

            m = Moment(
                adv=adv,
                stage=st,
                elf=elf or Elf(),
                fn=lambda: fn(*args, **kwargs),
            )
            try:
                return await adv.enter_moment(m)
            finally:
                if created:
                    try:
                        await adv.end()
                    finally:
                        remove_adventure(adv)

        def wrapper(*args, **kwargs):
            if inspect.isasyncgenfunction(fn):
                async def wrapped_asyncgen(*args, **kwargs):
                    async for item in fn(*args, **kwargs):
                        yield item
                return wrapped_asyncgen(*args, **kwargs)

            if mode == "async":
                return _async_call(*args, **kwargs)

            if mode == "sync":
                try:
                    asyncio.get_running_loop()
                    raise RuntimeError(
                        "mode='sync' cannot run inside an active event loop; "
                        "use mode='async' and await."
                    )
                except RuntimeError:
                    pass
                return asyncio.run(_async_call(*args, **kwargs))

            try:
                asyncio.get_running_loop()
                return _async_call(*args, **kwargs)
            except RuntimeError:
                return asyncio.run(_async_call(*args, **kwargs))

        return wrapper

    return deco


oops_moment = oops_moment_auto
