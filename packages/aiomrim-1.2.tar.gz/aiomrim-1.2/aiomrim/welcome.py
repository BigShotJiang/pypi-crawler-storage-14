# entry point for aiomrim command 
def hello():
    print("Welcome to aiomrim! This is the async SDK for MRIM-Server (Renaissance). Version: v1.1\nOur GitHub repo: https://github.com/fayzetwin1/aiomrim\nContact with me: contact@fayzetwin.xyz\nRenaissance (MRIM-Server) repo: https://github.com/mrimsu/mrim-server\n\nMade with love by fayzetwin! <3")