from .welcome import hello 

if __name__ == "__main__":
    hello()