# aiomrim

<img src="logo_aiomrim.png" alt="Logo of Aiomrim" width="200"/>

SDK для MRIM-сервера (Renaissance). Позволяет работать с Rest.API Renaissance, и прочими вещами.

[Документация](https://github.com/fayzetwin1/aiomrim/blob/main/docs/docs.md)

[PyPI](https://pypi.org/project/aiomrim/1.0/)

Связаться со мной: contact@fayzetwin.xyz 

[Репозиторий Renaissance](https://github.com/mrimsu/mrim-server)