"""Orchestration modules for La Perf benchmark suite."""

from src.orchestration.runner import run_all_benchmarks

__all__ = ["run_all_benchmarks"]
