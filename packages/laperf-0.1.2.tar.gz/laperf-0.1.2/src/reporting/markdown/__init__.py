"""Markdown generation utilities."""

from .sections import ResultsSectionGenerator

__all__ = ["ResultsSectionGenerator"]
