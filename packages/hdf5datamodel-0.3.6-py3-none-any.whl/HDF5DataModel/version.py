__version__ = "0.3.6"  # please sync with pyproject.toml !!!
