export const DisableTooltipMessages = {
  add_or_remove: "Unavailable for added or removed resources.",
} as const;
