EX3=r"""
import os
    import matplotlib.pyplot as plt
    from numpy import expand_dims
    from tensorflow.keras.preprocessing.image import load_img, img_to_array, ImageDataGenerator

    # Disable unnecessary warnings & logs
    os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

    print("\n=== EXERCISE 3 — IMAGE AUGMENTATION VISUALIZATION ===\n")

    # Load the base image
    img = load_img(r'D:\Studies\Sem-7\Deep Learning Concepts and Architectures\Exercise\Bird.jpg')
    data = img_to_array(img)
    samples = expand_dims(data, 0)

    # Function to show augmentations
    def show_augmented(datagen, title):
        it = datagen.flow(samples, batch_size=1)
        plt.figure(figsize=(6, 6))
        for i in range(9):
            plt.subplot(330 + 1 + i)
            batch = next(it)
            image = batch[0].astype('uint8')
            plt.imshow(image)
            plt.axis('off')
        plt.suptitle(title)
        plt.tight_layout()
        plt.show()

    # Run all augmentations
    show_augmented(ImageDataGenerator(horizontal_flip=True), "Horizontal Flip")
    show_augmented(ImageDataGenerator(width_shift_range=[-200, 200]), "Width Shift")
    show_augmented(ImageDataGenerator(brightness_range=[0.2, 1.0]), "Brightness Adjustment")
    show_augmented(ImageDataGenerator(rotation_range=90), "Rotation")
    show_augmented(ImageDataGenerator(zoom_range=[0.5, 1.0]), "Zoom")
    show_augmented(ImageDataGenerator(height_shift_range=0.5), "Height Shift")

    print("\n✅ Exercise 3 augmentations displayed successfully!")

"""
def get3():
    
    print(EX3)

