# enddl

This package contains seven deep-learning exercise scripts wrapped as Python functions:

- get1()
- get2()
- get3()
- get4()
- get5()
- get6()
- get7()

After installation:

```python
import enddl
enddl.get1()
