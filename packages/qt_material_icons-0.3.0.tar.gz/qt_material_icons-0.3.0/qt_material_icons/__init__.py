from ._icon import MaterialIcon, SVGIcon

__version__ = '0.0.0'
