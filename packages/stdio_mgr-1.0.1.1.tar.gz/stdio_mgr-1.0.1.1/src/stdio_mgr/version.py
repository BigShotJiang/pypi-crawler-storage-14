r"""``stdio_mgr`` *version definition module*.

``stdio_mgr`` provides a context manager for convenient
mocking and/or wrapping of ``stdin``/``stdout``/``stderr``
interactions.

**Author**
    Brian Skinn (bskinn@alum.mit.edu)

**File Created**
    28 Nov 2025

**Copyright**
    \(c) Brian Skinn 2018-2025

**Source Repository**
    http://www.github.com/bskinn/stdio-mgr

**Documentation**
    See README.md at the GitHub repository

**License**
    Code: `MIT License`_

    Docs & Docstrings: |CC BY 4.0|_

    See |license_txt|_ for full license terms.

**Members**

"""

__version__ = "1.0.1.1"
