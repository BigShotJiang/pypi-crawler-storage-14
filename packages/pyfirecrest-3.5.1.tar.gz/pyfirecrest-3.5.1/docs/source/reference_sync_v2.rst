FirecREST objects
==============================

Here is the API for the client:

The ``Firecrest`` class
****************************
.. autoclass:: firecrest.v2.Firecrest
    :members:
    :undoc-members:
    :show-inheritance:

The ``ExternalUpload`` class
****************************
.. autoclass:: firecrest.v2.ExternalUpload
    :members:
    :undoc-members:
    :show-inheritance:

The ``ExternalDownload`` class
******************************
.. autoclass:: firecrest.v2.ExternalDownload
    :members:
    :undoc-members:
    :show-inheritance:
