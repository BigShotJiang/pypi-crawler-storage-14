Authorization
=============

The ``ClientCredentialsAuth`` class
***********************************
.. autoclass:: firecrest.ClientCredentialsAuth
    :members:
    :undoc-members:
    :show-inheritance:
