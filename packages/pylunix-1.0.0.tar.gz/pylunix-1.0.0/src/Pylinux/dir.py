# In src/Pylunix/modules/dir.py

import os

def mkdir(dir_path_name):
    """
    Creates a single directory. Handles common OS and Python errors.
    Returns True on success, or False if a non-fatal error occurs.
    """
    try:
        os.mkdir(dir_path_name)
    except FileExistsError:
        # If the directory already exists, consider it a success and proceed
        print(f"Directory already exists: {dir_path_name}")
    except FileNotFoundError:
        # If a required parent directory doesn't exist
        print(f"Error: Parent directory for '{dir_path_name}' does not exist.")
        return False
    except (TypeError, ValueError):
        # Catches cases where dir_path_name isn't a string or is invalid
        print("There was a type or value error with the path name.")
        return False
    except OSError as e:
        # Catches generic OS errors (e.g., permission denied, invalid path characters)
        print(f"An operating system error occurred: {e}")
        return False
    
    # Only returns True if the operation succeeded or the directory already existed
    return True

def mkdirs(dir_path_name):
    """Creates a directory and any necessary parent directories."""
    try:
        # exist_ok=True prevents FileExistsError if the path already exists
        os.makedirs(dir_path_name, exist_ok=True)
        return True
    except (TypeError, ValueError) as e:
        print(f"Path error: {e}")
        return False
    except OSError as e:
        # Catches permission denied, invalid names, etc.
        print(f"OS error during directory creation: {e}")
        return False