import dir

def mkdir(Directory_path_name):
    dir.mkdir(Directory_path_name)
def mkdirs(Directory_path_name):
    dir.mkdirs(Directory_path_name)

#C:/Users/parui/AppData/Local/Microsoft/WindowsApps/python3.13.exe 