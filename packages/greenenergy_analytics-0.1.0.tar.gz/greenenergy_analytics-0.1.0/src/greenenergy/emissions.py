EMISSION_FACTORS = {
    "electricity": 0.475,        # kg CO2 per kWh
    "gas": 2.03,                 # kg CO2 per m3
    "steam": 0.55,               # example unit
    "air-conditioning": 0.65,    # example unit
}

def calculate_co2(utility_type: str, value: float, factors: dict | None = None) -> float:
    table = factors or EMISSION_FACTORS
    factor = table.get(utility_type, 0.0)
    return value * factor
