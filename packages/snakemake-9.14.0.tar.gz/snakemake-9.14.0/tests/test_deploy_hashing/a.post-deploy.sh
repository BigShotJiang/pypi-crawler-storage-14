#!/bin/bash

echo "test" > $CONDA_PREFIX/a.txt