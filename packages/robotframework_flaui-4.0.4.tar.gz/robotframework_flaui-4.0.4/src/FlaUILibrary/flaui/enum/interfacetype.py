from enum import Enum


class InterfaceType(Enum):
    """
    Enum declaration for supported ui component handling
    """
    INVALID = 0
    TEXTBOX = 1
    CHECKBOX = 2
    COMBOBOX = 3
    WINDOW = 4
    LISTVIEW = 5
    RADIOBUTTON = 6
    LISTBOX = 7
    TAB = 8
    TREE = 9
    TOGGLEBUTTON = 10
    BUTTON = 11
