"""Module containing data classes."""
