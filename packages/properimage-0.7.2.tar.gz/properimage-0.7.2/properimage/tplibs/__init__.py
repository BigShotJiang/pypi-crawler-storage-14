#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Copyright 2020 Toros astro team
#
# This file is part of ProperImage (https://github.com/toros-astro/ProperImage)
# License: BSD-3-Clause
# Full Text: https://github.com/toros-astro/ProperImage/blob/master/LICENSE.txt
#

"""This package contains external libraries shipped with properimage."""
