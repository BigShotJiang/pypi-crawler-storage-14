"""Benchmarks for teehistorian_py."""
