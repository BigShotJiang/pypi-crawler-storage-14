__pypi_version__ = "2025.11.28";__local_version__ = "2025.11.28+19f47cd"
