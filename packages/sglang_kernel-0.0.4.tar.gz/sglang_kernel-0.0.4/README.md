# sglang-kernel

The new pypi entry for sglang kernel.

see https://github.com/sgl-project/sglang/blob/main/sgl-kernel/README.md

