"""Factory patterns for AIoIA projects."""

from aioia_core.factories.base_manager_factory import BaseManagerFactory

__all__ = ["BaseManagerFactory"]
