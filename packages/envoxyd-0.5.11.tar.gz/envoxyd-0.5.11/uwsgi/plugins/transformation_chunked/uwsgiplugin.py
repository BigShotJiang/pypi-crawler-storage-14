NAME='transformation_chunked'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['chunked']
