from .utils import load_data

project_data = load_data()

website_data = {
    "homepage" : {
        "title" : "Welcome to SoftiqTech Home Page",
        "homepage_description" : [
            "Home page section includes the following sub-sections:",
            "1. Hero Section\n"
            "2. Get To Know SoftiqTech\n"
            "3. What SoftiqTech Offers\n"
            "4. Completed Projects\n"
            "5. Why Choose SoftiqTech\n"
            "6. Client Testimonials\n"
            "7. Footer\n\n"
        ],

        "hero_section" : {
            "description" : [
                "The Hero Section is designed to grab the visitor's attention immediately upon landing on the homepage. It typically features a compelling headline that communicates the core message of SoftiqTech, along with a sub-headline that provides additional context or value proposition. The background image is carefully selected to reflect the brand's identity and create a visually appealing experience for users. The Hero Section includes the following data:",
                "1. Innovative Tech for a Smarter Future: SoftiqTech empowers businesses with cutting-edge IT solutions, from software and AI to design and digital growth strategies. We turn your vision into reality.",
                "2. Powering Growth Through Smart Technology: From web to AI-driven automation, SoftiqTech delivers secure, scalable, and result-focused solutions that accelerate your business journey.",
                "3. Your Partner in Digital Transformation: SoftiqTech combines design, development, AI, and strategy to provide end-to-end solutions that shape your success story.",
                "4. Transforming Ideas into Digital Reality: At SoftiqTech, we craft tailored solutions, apps, AI, and designs that help businesses grow, connect, and lead with innovation"
            ]
        },

        "Get_To_Know_SoftiqTech" : {
            "title" : "SoftiqTech – Where Technology Meets Creativity",
            "description" : [
                "At SoftiqTech, we don’t just develop software, we create intelligent digital solutions that help businesses grow, connect, and thrive in today’s fast-paced world. Our expertise covers UI/UX design, web & app development, AI-powered agents & chatbots, digital marketing, and data analysis. Whether you’re a startup ready to make an impact or an enterprise aiming to scale globally, we deliver technology that adapts to your unique goals. What sets us apart is our end-to-end approach and a collaborative team of designers, developers, AI specialists, and marketing experts dedicated to building secure, scalable, and results-driven solutions."
            ]
        },

        "What_SoftiqTech_Offers" : {
            "title" : "Real-Time IT Solutions & Services",
            "services_list" : [
                "1. Website Development\n",
                "2. App Development\n",
                "3. UI/UX Designing\n",
                "4. AI Agents & Bots Development\n",
                "5. Digital Marketing\n",
                "6. Graphic Designing\n\n",
            ]
        },

        "Why_Choose_SoftiqTech" : {
            "title" : "The Difference We Deliver",
            "description" : [
                "We go beyond delivering IT services and build lasting partnerships that empower your business to grow, adapt, and lead. Our focus is not just on solving challenges, but on creating simple, scalable, and innovative solutions that bring real impact",
                "1. IT & AI Services\n",
                "2. Dedicated Team\n",
                "3. Affordable Solutions\n",
                "4. 24/7 Client Support\n\n",
            ]
        },

        "Client_Testimonials" : {
            "title" : "Check What They’re Talking About Us",
            "testimonials_list" : {
                "client_1" : {
                    "name" : "Rehman Khan",
                    "organization" : "Dubai Police",
                    "testimonial" : "SoftiqTech provided exceptional website design services for the Dubai Police. Their ability to create a user-friendly and secure platform was impressive. They delivered a seamless experience for both our team and visitors.",
                    "rating" : 5
                },
                "client_2" : {
                    "name" : "Sheikh Abid",
                    "organization" : "Pizza Perfect",
                    "testimonial" : "We are thrilled with the logo created by SoftiqTech for Pizza Perfect. It captures the essence of our brand perfectly and stands out in the competitive pizza industry. The team’s creativity and responsiveness were top-notch.",
                    "rating" : 4
                },
                "client_3" : {
                    "name" : "Majid Khan",
                    "organization" : "Liaquat University Hospital",
                    "testimonial" : "What impressed us most about SoftiqTech is their innovative approach. They don’t just solve problems, also, they anticipate challenges and provide creative solutions that keep our business ahead of the curve.",
                    "rating" : 5
                },
                "client_4" : {
                    "name" : "Umair Khan",
                    "organization" : "Bin Mehmoood Group",
                    "testimonial" : "SoftiqTech delivered an outstanding website for Bin Mehmoood Group. The site is not only visually stunning but also highly functional, which is exactly what we were looking for. Their attention to detail and prompt service exceeded our expectations.",
                    "rating" : 5
                },
                "client_5" : {
                    "name" : "Abdul Rafay",
                    "organization" : "Toyota Point",
                    "testimonial" : "Working with Softiq Tech was an absolute pleasure. They provided exceptional UI/UX design services for our platform. The user interface is sleek, intuitive, and the overall user experience has drastically improved. We highly recommend their expertise!",
                    "rating" : 4
                }
            }
        },

        "Footer" : {
            "description" : "© 2024 SoftiqTech. All rights reserved.",
            "contact_info" : {
                "email" : "infosoftiqtech@gmail.com",
                "phone" : "+92-308-3940742",
                "address" : "Karachi, Pakistan",
            }
        },
    },

    "aboutpage" : {
        "title" : "Welcome to SoftiqTech's About Page",
        "aboutpage_description" : [
            "The About Page provides an in-depth look at SoftiqTech's company overview, mission, vision, values, and team members. It is designed to build trust and credibility with visitors by showcasing the company's expertise and commitment to excellence. The About Page includes the following sections:",
            "1. Company Overview\n",
            "2. Our Mission\n"
            "3. Our Vision\n"
            "4. Our Values\n"
            "5. Meet the Team\n\n"
        ],

        "company_overview" : {
            "title" : "About SoftiqTech",
            "Subtitle" : "Driving Innovation, Powering Global Growth",
            "description" : [
                "At SoftiqTech, we believe technology should do more than just work. Moreover, it should inspire, transform, and accelerate success. Our team of expert designers, developers, and innovators bring years of proven experience to deliver cutting-edge digital solutions that help businesses compete and thrive on a global stage.\n"
                "We specialize in creating scalable apps, AI-powered systems, engaging digital experiences, and data-driven strategies that turn visions into measurable results. With every project, we focus on innovation, quality, and impact, ensuring our clients always stay ahead in the digital race",
                "1. Innovation at the Core\n",
                "2. Global Excellence\n",
                "3. Impact-Driven Approach\n",
                "4. Partnership That Lasts\n\n",
            ]
        },

        "our_mission" : {
            "title" : "Our Mission",
            "description" : [
                "To transform ideas into intelligent digital solutions that inspire innovation, accelerate growth, and create lasting impact for businesses worldwide while building trusted partnerships that thrive in a constantly evolving digital era."
            ]
        },

        "our_vision" : {
            "title" : "Our Vision",
            "description" : [
                "To become a globally recognized innovation hub that empowers businesses with transformative solutions, nurtures long-term success, and shapes the future of technology through creativity, collaboration, and excellence."
            ]
        },

        "our_values" : {
            "title" : "Our Values",
            "description" : [
                "At SoftiqTech, we drive innovation and deliver excellence with integrity. Through collaboration and a strong customer focus, we create solutions that inspire growth and ensure accountability in every project",
            ]
        },

        "meet_the_team" : {
            "title" : "Meet Our Passionate Minds",
            "description" : [
                "Our team at SoftiqTech combines innovation, expertise, and dedication to craft solutions that drive real impact. Every member brings unique skills, creativity, and a results-driven mindset, ensuring that we deliver projects that exceed expectations and inspire growth."
            ],
            "team_members" : {
                "member_1" : {
                    "name" : "Maimoona Masood",
                    "position" : "Founder & CIO",
                    # "bio" : "Ali is a visionary leader with over a decade of experience in the tech industry. He founded SoftiqTech with a mission to drive innovation and deliver cutting-edge digital solutions that empower businesses worldwide."
                },
                "member_2" : {
                    "name" : "Syed Huzaifa",
                    "position" : "Founder & CEO",
                    # "bio" : "Sara is a tech enthusiast and expert in software development and AI technologies. As CTO, she leads the technical team at SoftiqTech, ensuring the delivery of high-quality, scalable solutions."
                },
                "member_3" : {
                    "name" : "Tanzeel Fatima",
                    "position" : "Founder & CMO",
                    # "bio" : "Omar is a creative force behind SoftiqTech's innovative designs. With a keen eye for aesthetics and user experience, he leads the design team to create engaging digital experiences."
                },
                "member_4" : {
                    "name" : "Syed Daniyal",
                    "position" : "Founder & CTO",
                    # "bio" : "Ayesha is a strategic thinker with expertise in digital marketing and brand development. She drives SoftiqTech's marketing efforts to build strong client relationships and expand the company's reach."
                },
                "member_5" : {
                    "name" : "Salika Syed",
                    "position" : "Founder & CFO",
                    # "bio" : "Ayesha is a strategic thinker with expertise in digital marketing and brand development. She drives SoftiqTech's marketing efforts to build strong client relationships and expand the company's reach."
                },
                "member_6" : {
                    "name" : "Saqib Sheikh",
                    "position" : "Founder & COO",
                    # "bio" : "Ahsan is a strategic thinker with expertise in digital marketing and brand development. She drives SoftiqTech's marketing efforts to build strong client relationships and expand the company's reach."
                },
            }
        }



    },

    "servicespage" : {
        "title" : "Driving Growth With Innovative Services",
        "sub_title" : "Boosting Business Success Through Smarter Technology Solutions",
        "description" : "At SoftiqTech, our services are designed to deliver real business value. From streamlined processes to intelligent automation, we ensure every solution enhances productivity, reduces costs, and drives measurable results. Partnering with us means gaining a technology ally focused on your success",
        "services" : {
            "Web_Developement" : {
                "title" : "Web Development",
                "about_this_service" : [
                    "We develop responsive, high-performance websites that combine functionality, security, and design. Tailored for every business, our web solutions enhance user experiences, improve conversions, and provide scalable digital platforms for long-term growth",
                    "1. Build frontend and backend web applications using modern technologies.\n",
                    "2. Develop e-commerce platforms and content management systems efficiently.\n",
                    "3. Create custom portals and applications tailored to business needs.\n",
                    "4. Integrate APIs and manage databases for seamless functionality.\n",
                    "5. Implement website optimization techniques to boost speed and performance.\n",
                    "5. Ensure robust website security and maintain regular monitoring protocols.\n",

                ]
            },

            "App_Developement" : {
                "title" : "App Development",
                "about_this_service" : [
                    "We design and develop mobile applications that are fast, reliable, and engaging. From concept to deployment, our apps ensure smooth performance, user satisfaction, and seamless functionality across Android and iOS platforms.",
                    "1. Develop native and cross-platform mobile applications for all devices.\n",
                    "2. Design app UI/UX that ensures engaging user experiences.\n",
                    "3. Test and optimize performance for smooth bug-free functionality.\n",
                    "4. Integrate push notifications and real-time analytics tools.\n",
                    "5. Deploy applications on App Store and Google Play efficiently.\n",
                    "6. Provide regular updates new features and ongoing maintenance.\n",
                ]
            },

            "UI/UX_Designing" : {
                "title" : "UI/UX Designing",
                "about_this_service" : [
                    "We craft intuitive, visually stunning interfaces that elevate user experiences, drive engagement, and strengthen brand identity. Our designs focus on usability, accessibility, and seamless interaction across all devices for maximum impact.",
                    "1. Conduct user research create personas and map customer journeys effectively.\n",
                    "2. Design interactive wireframes and prototypes for rapid feedback and improvement.\n",
                    "3. Develop responsive layouts compatible with all screen sizes and devices.\n",
                    "4. Maintain consistent visual branding and design patterns across platforms.\n",
                    "5. Perform usability testing and iterative enhancements for superior experience.\n",
                    "6. Optimize user experience to increase engagement and conversion rates.\n",
                ]
            },

            "AI_Agents_&_Chatbots" : {
                "title" : "AI Agents & Chatbots",
                "about_this_service" : [
                    "We implement AI-powered agents and chatbots to automate tasks, improve customer interactions, and provide personalized experiences. Our solutions reduce manual effort, increase efficiency, and enhance business communication.",
                    "1. Create AI-powered chatbots for seamless customer support experiences.\n",
                    "2. Automate repetitive business workflows using intelligent AI tools.\n",
                    "3. Personalize conversations for enhanced engagement and customer satisfaction.\n",
                    "4. Integrate chatbots with CRM and third-party business systems.\n",
                    "5. Monitor performance using analytics and optimize for better results.\n",
                    "6. Develop custom AI workflows tailored to unique business requirements.\n",
                ]
            },

            "Digital_Marketing" : {
                "title" : "Digital Marketing",
                "about_this_service" : [
                    "We craft result-driven digital marketing strategies that increase brand visibility, engagement, and conversions. Our campaigns leverage SEO, social media, content, and paid advertising to maximize online presence and generate measurable results.",
                    "1. Optimize websites for search engines using proven SEO strategies.\n",
                    "2. Manage social media accounts to boost engagement effectively.\n",
                    "3. Create and implement strategic content marketing plans.\n",
                    "4. Run paid advertising campaigns for maximum ROI and visibility.\n",
                    "5. Automate email marketing campaigns for personalized customer engagement.\n",
                    "6. Track performance metrics and continuously optimize marketing strategies.\n",
                ]
            },

            "Graphics_Designing" : {
                "title" : "Graphics Designing",
                "about_this_service" : [
                    "We create visually compelling designs that communicate your brand’s story effectively. Our solutions enhance engagement, build brand recognition, and deliver impactful visuals across digital and print platforms for consistent brand identity.",
                    "1. Design logos brand identities and corporate visuals that leave lasting impressions.\n",
                    "2. Create marketing materials brochures and promotional graphics for digital and print.\n",
                    "3. Develop social media visuals and campaigns to boost engagement and reach.\n",
                    "4. Craft UI/UX design elements for websites and applications.\n",
                    "5. Produce illustrations infographics and motion graphics to support storytelling.\n",
                    "6. Ensure cohesive branding across all visual touchpoints for maximum impact.\n",
                ]
            }
        }
    },

    "projectspage" : {
        "title" : "Crafting Success",
        "description" : "Our projects reflect our commitment to innovation, quality, and results. Each solution we deliver is crafted with precision and creativity, helping businesses achieve real growth and lasting impact.",
        "projects" : {
                "completed_projects": project_data["completed_projects"],
                "ongoing_projects": project_data["ongoing_projects"],
                "upcoming_projects": project_data["upcoming_projects"]
            }
    },

    "contactpage": {
        "title": "Welcome to SoftiqTech's Contact Page",
        "description": [
            "Contact page section includes the following sub-sections:",
            "1. Contact Details\n",
            "2. Contact Form Guide\n"
        ],

        "contact_details": {
            "title": "Connect With Experts Who Bring Innovation",
            "description": "Have a project, question, or vision? Reach out to SoftiqTech, and our dedicated team will guide you with tailored IT, AI, and software solutions to achieve measurable business growth.",

            "contact_list": {
                "phone": "+92-308-3940742",
                "email": "infosoftiqtech@gmail.com",
                "address": "Karachi, Pakistan"
            },
        },

        "contact_form_guide": {
            "title": "Contact Form Guide",
            "description": "This contact form guide helps you enter accurate information by explaining each field, its purpose, and the correct format. Follow all steps carefully to ensure your message reaches our team without errors.",

            "steps": [
                {
                    "field": "Full Name",
                    "what_to_write": (
                        "Write your complete name such as 'John Doe' or 'Albert'. "
                        "Only alphabets and spaces are allowed."
                    ),
                    "validation": "Required — letters and spaces only.",
                    "error": "Please enter your full name correctly."
                },
                {
                    "field": "Email",
                    "what_to_write": (
                        "Enter your active email address where you can receive replies. "
                        "Example: name@example.com"
                    ),
                    "validation": "Required — must be a valid email format.",
                    "error": "Please enter a valid email address."
                },
                {
                    "field": "Phone Number",
                    "what_to_write": (
                        "Enter your phone number. Preferably in the Pakistani format such as +923001234567. "
                    ),
                    "validation": "Optional — digits (and +) only.",
                    "error": "Please enter a valid phone number."
                },
                {
                    "field": "Area of Interest",
                    "what_to_write": (
                        "Write which service you are interested in. Example: 'AI Agent Development', 'Website Design', or 'Digital Marketing'."
                    ),
                    "validation": "Required — text input only.",
                    "error": "Please specify your area of interest."
                },
                {
                    "field": "Message / Availability",
                    "what_to_write": (
                        "Write a clear message about your project, requirements, or preferred time for a call/meeting."
                    ),
                    "validation": "Required — minimum 10 characters.",
                    "error": "Please enter a valid message."
                },
                {
                    "field": "Submit Button",
                    "what_happens_after_click": [
                        "1. Once you click Submit, your form details are emailed to SoftiqTech.",
                        "2. Our team reviews your message.",
                        "3. You will receive a reply within 24–48 hours.",
                        "4. For urgent matters, you can call us directly at +92-308-3940742."
                    ],
                    "success_message": "Your message has been sent successfully! Our team will contact you soon.",
                    "failure_message": "Something went wrong. Please try again later."
                }
            ],
        },
    },

    "accountpage": {
        "title": "Welcome to SoftiqTech's Account Page",
        "description": [
            "Account page section includes the following sub-sections:",
            "1. Login\n",
            "2. Sign Up\n"
        ],

        "login": {
            "title": "Login to Your Account",
            "description": "Welcome back! Please enter your credentials to access    your account.",
            "login_flow": {
                "form_fields": [
                    "Username — Enter your registered username.",
                    "Password — Enter your account password.",
                    "Remember Me — Check this box if you want the system to keep you logged in.",
                    "Forgot Password? — Click this link to reset your password.",
                    "Sign In — Click this button after entering valid credentials."
                ],
               
                "flow_steps": [
                    "1. User visits the Login page.",
                    "2. Enters Username.",
                    "3. Enters Password.",
                    "4. (Optional) Checks 'Remember Me'.",
                    "5. Clicks 'Sign In'.",
                    "6. If login is successful → user gets access to all pages.",
                    "7. If incorrect credentials → show 'Invalid username or password.'",
                    "8. If 'Forgot Password?' clicked → redirect to password reset page."
                ],
                "security_notes": [
                    "Never request or process real passwords.",
                    "Warn the user not to share passwords in chat.",
                    "Explain how to troubleshoot invalid credentials.",
                    "Explain that 'Remember Me' should be used on trusted devices only."
                ],
                "interactive_behavior": [
                    "If the user asks 'How do I log in?', first show the intro message.",
                    "Ask the user if they want step-by-step guidance.",
                    "Guide them through Username → Password → Remember Me → Sign In.",
                    "If login fails, guide them to reset the password safely."
                ]
            }
        },

        "sign_up": {
            "title": "Create a New Account",
            "description": "Join SoftiqTech today! Fill out the form below to create your account and get access of contact page for further Queries.",
            "step_by_step_guide": {
                "introduction": (
                    "Create an account — step-by-step guidance\n\n"
                    "To access all features of the SoftiqTech website, you first need to create your account on the Account page. "
                    "During signup, you’ll provide your basic details like name, username, email, and password. "
                    "Once you complete the signup process, you’ll be redirected to the Login page where you can log in to your new account. "
                    "After Sign Up in successfully, all main pages — Home, About, Services, and Projects — will be accessible, "
                    "while the Contact page remains hidden until full login is completed. "
                    "This ensures a secure and personalized user experience, allowing you to explore our services and projects seamlessly after authentication."
                ),
                "quick_flow_summary": [
                    "Pages: Home, About, Services, Project, Contact, Account.\n",
                    "Contact page is hidden until user signs up and logs in.\n",
                    "Flow: Sign Up -> redirected to Login -> Login -> Contact page becomes available."
                ],
                "fields": [
                    "- First Name | 'First Name' | 'Please enter your first name.'",
                    "- Last Name  | 'Last Name'  | 'Please enter your last name.'",
                    "- Username   | 'Choose a username' | letters/numbers/underscore, unique | 'Username must be 3–30 chars; try another if taken.'",
                    "- Email      | 'Enter your email' | required, valid email format | 'Please enter a valid email.'",
                    "- Password   | 'Create a password' | required, min 8 chars, 1 upper, 1 lower, 1 number, 1 symbol recommended | 'Password too weak.'",
                    "- Confirm Password | 'Confirm your password' | required, must match Password | 'Passwords do not match.'",
                    "- Anti-bot check | 'Answer the puzzle' (What is 3 + 4?) | required; numeric answer must equal 7 | 'Incorrect answer.'"
                ],
                "buttons_navigation": [
                    "Primary CTA: 'Sign Up' (disabled until form valid)",
                    "On success: show 'Account created successfully. Please log in.' then redirect to Login page.",
                    "Link: 'Already have an account? Login' -> Login page."
                ],
                "ux_error_handling": [
                    "Inline validation messages below each field; focus field on error.",
                    "If server says 'username/email taken', show that msg inline.",
                    "Server error -> 'Something went wrong. Please try again later.'"
                ],
                "security_note": "We store your info securely. Your data is privately stored in our database.",
                "interactive_guidance": [
                    "- Present the above guidance when user asks 'How do I sign up?' or similar.",
                    "- Then ask: 'Do you want a step-by-step walkthrough and I'll guide you field-by-field?' If user says yes:",
                    "  1. Ask for First Name -> validate locally (letters-only). If invalid, reprompt.",
                    "  2. Ask for Last Name -> validate.",
                    "  3. Ask for Username -> check basic format locally; DO NOT check uniqueness server-side (advise user how to check on UI).",
                    "  4. Ask for Email -> validate format locally.",
                    "  5. Ask for Password -> DO NOT ask for full real password in chat. Instead:",
                    "     - Offer password rules and ask user to create it on the site.",
                    "     - If user insists on entering a test value here, refuse to accept real passwords and explain security risk.",
                    "  6. Ask to confirm password on the website (agent may validate format matches if user voluntarily provides a masked or placeholder value; strongly discourage sharing).",
                    "  7. Ask anti-bot question and verify answer == 7.",
                    "  8. When all fields locally valid, instruct the user: 'Now click Sign Up. You will be redirected to Login.'",
                    "- If user asks agent to actually submit the form or create account on their behalf -> politely refuse and provide exact manual steps and tips."
                ]
            }
        }
    }
}