# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

# pyfrontkit/css_register.py 

from pathlib import Path
from typing import Any 

class CSSRegistry:
    """
    Simplified CSS selector registry for PyFrontKit.
    Manages unique registration of tags, IDs, classes, and parent > child cascade selectors.
    The registration occurs **only in memory** for efficiency (Pure Memory).
    """

    _tags = set()
    _ids = set()
    _classes = set()
    _cascades = set() 

    @classmethod
    def _get_child_tag(cls, child: Any) -> str | None:
        """Helper to get the tag, whether it's a Block or a ContentItem."""
        # If it's a Block or a ContentItem
        if hasattr(child, "tag"):
            return getattr(child, "tag")
        # If it's a plain string or int, it's ignored here.
        return None

    @classmethod
    def _register_cascades_by_tag(cls, block):
        """
        Generates and registers tag-based cascades up to 2 levels deep:
        - tag > tag/content_tag (1st level)
        - tag > tag > tag/content_tag (2nd level)
        """
        parent_tag = block.tag
        
        # ---------------------------------------------
        # 1. Analyze Children (1st Level)
        # ---------------------------------------------
        
        # Children of type Block
        for child in block.children:
            child_tag = cls._get_child_tag(child)
            if not child_tag:
                continue
            
            # 1.1 Cascade of 1 Level: tag > tag
            selector_1 = f"{parent_tag} > {child_tag}"
            cls._cascades.add(selector_1)
            
            # ---------------------------------------------
            # 2. Analyze Grandchildren (2nd Level)
            # ---------------------------------------------
            # Checks if the child is a Block capable of having further children/content
            if hasattr(child, "tag") and hasattr(child, "children"): 
                
                # Grandchildren of type Block
                for grandchild in child.children:
                    grandchild_tag = cls._get_child_tag(grandchild)
                    if grandchild_tag:
                        # Cascade of 2 Levels: tag > tag > tag (Block > Block > Block)
                        selector_2 = f"{parent_tag} > {child_tag} > {grandchild_tag}"
                        cls._cascades.add(selector_2)
                
                # Grandchildren of type ContentItem (text/image inside the child block)
                for ctn_item in getattr(child, "content_items", []):
                    grandchild_tag = cls._get_child_tag(ctn_item)
                    if grandchild_tag:
                        # Cascade of 2 Levels: tag > tag > content_tag (Block > Block > Content)
                        selector_2 = f"{parent_tag} > {child_tag} > {grandchild_tag}"
                        cls._cascades.add(selector_2)


        # ---------------------------------------------
        # 3. Analyze Block Content (1st Level)
        # ---------------------------------------------
        # Children of type ContentItem (Text/Image)
        for ctn_item in getattr(block, "content_items", []):
            ctn_tag = cls._get_child_tag(ctn_item)
            if ctn_tag:
                # 3.1 Cascade of 1 Level: tag > content_tag
                selector_1 = f"{parent_tag} > {ctn_tag}"
                cls._cascades.add(selector_1)


    @classmethod
    def register_block(cls, block):
        """
        Registers selectors of the block and its children ONLY IN MEMORY.
        Reads the Block structure and fills the sets.
        """
        
        block_id = getattr(block, "attrs", {}).get("id")
        children = list(getattr(block, "children", []))

        # --- TAG REGISTRATION
        if block.tag and block.tag not in cls._tags:
            cls._tags.add(block.tag)

        # --- ID REGISTRATION
        if block_id and block_id not in cls._ids:
            cls._ids.add(block_id)
        
        # --- CLASS REGISTRATION
        classes = block.attrs.get("class")
        if classes:
            for cls_name in str(classes).split():
                if cls_name not in cls._classes:
                    cls._classes.add(cls_name)

        # ----------------------------------------------------
        # --- EXISTING CASCADE: ID > TAG (Direct Child)
        # ----------------------------------------------------
        if block_id:
            for child in children:
                child_tag = getattr(child, "tag", None)
                if child_tag:
                    selector = f"#{block_id} > {child_tag}"

                    if selector not in cls._cascades:
                        cls._cascades.add(selector)
                        
        # ----------------------------------------------------
        # --- NEW CASCADES: TAG > TAG AND TAG > TAG > TAG
        # ----------------------------------------------------
        cls._register_cascades_by_tag(block)


        # --- RECURSION THROUGH CHILD BLOCKS
        for child in children:
            if hasattr(child, "tag") and getattr(child, "tag"):
                cls.register_block(child)

        # --- CONTENT-ITEM TAG REGISTRATION (Maintained to register the simple TAG)
        for ctn_item in getattr(block, "content_items", []):
            content_tag = cls._get_child_tag(ctn_item)
            if content_tag and content_tag not in cls._tags:
                cls._tags.add(content_tag)


    @classmethod
    def generate_css(cls):
        """
        Returns all generated selectors in memory as a CSS text string.
        """
        lines = ["/* Selectors generated by PyFrontKit */\n"]

        # TAGS
        for tag in sorted(cls._tags):
            lines.append(f"{tag} {{\n \t/* styles here */\n}}\n")

        # IDS
        for id_name in sorted(cls._ids):
            lines.append(f"#{id_name} {{\n \t/* styles here */\n}}\n")

        # CLASSES
        for cls_name in sorted(cls._classes):
            lines.append(f".{cls_name} {{\n \t/* styles here */\n}}\n")

        # CASCADES parent > child and grandparent > parent > child
        for selector in sorted(cls._cascades):
            lines.append(f"{selector} {{\n \t/* styles here */\n}}\n")

        return "\n".join(lines)