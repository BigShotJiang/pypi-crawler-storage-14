# ----------------------------------------------------------------------
# Package Configuration
# ----------------------------------------------------------------------
__version__ = "1.0.36"
__author__ = "Eduardo Antonio Ferrera Rodriguez"
__license__ = "GPLv3"

# ----------------------------------------------------------------------
# Expose CSS submodule
# ----------------------------------------------------------------------
from . import css  # permite: from pyfrontkit import css

# ----------------------------------------------------------------------
# Optionally expose key CSS classes and palettes for direct import
# ----------------------------------------------------------------------
from .css.create_color import CreateColor
from .css.create_color.palettes_homologous import palette_homologous, homologous_color_rule
from .css.create_color.palettes_triadic import palette_triadic, triadic_color_rule
from .css.create_color.palettes_tetradic import palette_tetradic, tetradic_color_rule

# ----------------------------------------------------------------------
# Core modules
# ----------------------------------------------------------------------
from .html_doc import HtmlDoc
from .css_register import CSSRegistry
from .block import Block

# ----------------------------------------------------------------------
# Tags
# ----------------------------------------------------------------------
from .tags import (
    Div, Section, Article, Header, Footer, Nav, Main, Aside, Button, Form, Ul, Li, A,
    div, section, article, header, footer, nav, main, aside,
    button, form, ul, li, a
)

# ----------------------------------------------------------------------
# Void elements
# ----------------------------------------------------------------------
from .void_element import (
    VoidElement, Img, Input, Hr, Meta, Link, Source, Embed, Param, Track, Wbr, Area, Base, Col,
    img, input, hr, meta, link, source, embed, param, track, wbr, area, base, col
)

# ----------------------------------------------------------------------
# Special containers
# ----------------------------------------------------------------------
from .special import Video, Audio, Picture, ObjectElement
from .special import video, audio, picture, object

# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------
__all__ = [
    # CSS module
    "css",
    "CreateColor",
    "palette_homologous", "homologous_color_rule",
    "palette_triadic", "triadic_color_rule",
    "palette_tetradic", "tetradic_color_rule",

    # Core
    "HtmlDoc",
    "CSSRegistry",
    "Block",

    # Tags
    "Div", "Section", "Article", "Header", "Footer", "Nav", "Main", "Aside",
    "Button", "Form", "Ul", "Li", "A",
    "div", "section", "article", "header", "footer", "nav", "main", "aside",
    "button", "form", "ul", "li", "a",

    # Void
    "VoidElement", "Img", "Input", "Hr", "Meta", "Link", "Source", "Embed",
    "Param", "Track", "Wbr", "Area", "Base", "Col",
    "img", "input", "hr", "meta", "link", "source", "embed", "param",
    "track", "wbr", "area", "base", "col",

    # Special
    "Video", "Audio", "Picture", "ObjectElement",
    "video", "audio", "picture", "object",
]
