"""List command - alias for status."""

from .status import status

# Alias for status command
list_cmd = status
