import abc
import datetime
import functools
import hashlib
import io
import itertools
import logging
from collections.abc import Iterable
from typing import Any
from typing import Optional
from typing import Union

import altair as alt
import geojson
import matplotlib
import matplotlib.pyplot as pl
import numpy as np
import pandas as pd
import sqlalchemy
from flask import Blueprint
from flask import flash
from flask import redirect
from flask import render_template
from flask import request
from flask import Response
from flask import url_for
from flask.typing import ResponseReturnValue

from ...core.config import Config
from ...core.config import ConfigAccessor
from ...core.coordinates import Bounds
from ...core.datamodel import Activity
from ...core.datamodel import DB
from ...core.datamodel import ExplorerTileBookmark
from ...core.datamodel import TileVisit
from ...core.raster_map import ImageTransform
from ...core.raster_map import OSM_TILE_SIZE
from ...core.raster_map import TileGetter
from ...core.tiles import compute_tile
from ...core.tiles import get_tile_upper_left_lat_lon
from ...explorer.grid_file import get_border_tiles
from ...explorer.grid_file import make_grid_file_geojson
from ...explorer.grid_file import make_grid_file_gpx
from ...explorer.grid_file import make_grid_points
from ...explorer.tile_visits import compute_tile_evolution
from ...explorer.tile_visits import get_tile_count
from ...explorer.tile_visits import get_tile_history_df
from ...explorer.tile_visits import get_tile_medians
from ...explorer.tile_visits import TileEvolutionState
from ...explorer.tile_visits import TileVisitAccessor
from ..authenticator import Authenticator
from ..authenticator import needs_authentication

alt.data_transformers.enable("vegafusion")

logger = logging.getLogger(__name__)


def blend_color(
    base: np.ndarray, addition: Union[np.ndarray, float], opacity: float
) -> np.ndarray:
    return (1 - opacity) * base + opacity * addition


@functools.cache
def hex_color_to_float(color: str) -> np.ndarray:
    values = [int("".join(x), base=16) / 255 for x in itertools.batched(color[1:], 2)]
    assert (
        min(values) >= 0.0 and max(values) <= 1.0
    ), f"All {values=} must be within 0.0 and 1.0."
    return np.array([[values]])


class ColorStrategy(abc.ABC):
    @abc.abstractmethod
    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        pass


class MaxClusterColorStrategy(ColorStrategy):
    def __init__(
        self, evolution_state: TileEvolutionState, tile_visits, config: Config
    ):
        self.evolution_state = evolution_state
        self.tile_visits = tile_visits
        self.max_cluster_members = set(
            max(
                evolution_state.clusters.values(),
                key=len,
            )
        )
        self._config = config

    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        if tile_xy in self.max_cluster_members:
            return hex_color_to_float(self._config.color_strategy_max_cluster_color)
        elif tile_xy in self.evolution_state.memberships:
            return hex_color_to_float(
                self._config.color_strategy_max_cluster_other_color
            )
        elif tile_xy in self.tile_visits:
            return hex_color_to_float(self._config.color_strategy_visited_color)
        else:
            return None


class ColorfulClusterColorStrategy(ColorStrategy):
    def __init__(
        self, evolution_state: TileEvolutionState, tile_visits, config: Config
    ):
        self.evolution_state = evolution_state
        self.tile_visits = tile_visits
        self.max_cluster_members = max(
            evolution_state.clusters.values(),
            key=len,
        )
        self._cmap = matplotlib.colormaps["hsv"]
        self._config = config

    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        if tile_xy in self.evolution_state.memberships:
            cluster_id = self.evolution_state.memberships[tile_xy]
            m = hashlib.sha256()
            m.update(str(cluster_id).encode())
            d = int(m.hexdigest(), base=16) / (256.0**m.digest_size)
            return np.array(
                [[self._cmap(d)[:3] + (self._config.color_strategy_cmap_opacity,)]]
            )
        elif tile_xy in self.tile_visits:
            return hex_color_to_float(self._config.color_strategy_visited_color)
        else:
            return None


class VisitTimeColorStrategy(ColorStrategy):
    def __init__(self, tile_visits, config: Config, use_first=True):
        self.tile_visits = tile_visits
        self.use_first = use_first
        self._config = config

    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        if tile_xy in self.tile_visits:
            today = datetime.date.today()
            cmap = matplotlib.colormaps["plasma"]
            tile_info = self.tile_visits[tile_xy]
            relevant_time = (
                tile_info["first_time"] if self.use_first else tile_info["last_time"]
            )
            if pd.isna(relevant_time):
                color = hex_color_to_float(self._config.color_strategy_visited_color)
            else:
                last_age_days = (today - relevant_time.date()).days
                color = cmap(max(1 - last_age_days / (2 * 365), 0.0))
                color = np.array(
                    [[color[:3] + (self._config.color_strategy_cmap_opacity,)]]
                )
            return color
        else:
            return None


class NumVisitsColorStrategy(ColorStrategy):
    def __init__(self, tile_visits, config: Config):
        self.tile_visits = tile_visits
        self._config = config

    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        if tile_xy in self.tile_visits:
            cmap = matplotlib.colormaps["viridis"]
            tile_info = self.tile_visits[tile_xy]
            color = cmap(min(tile_info["visit_count"] / 50, 1.0))
            return np.array([[color[:3] + (self._config.color_strategy_cmap_opacity,)]])
        else:
            return None


class MissingColorStrategy(ColorStrategy):
    def __init__(self, tile_visits, config: Config):
        self.tile_visits = tile_visits
        self._config = config

    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        if tile_xy in self.tile_visits:
            return None
        else:
            return hex_color_to_float(self._config.color_strategy_visited_color)


class VisitedColorStrategy(ColorStrategy):
    def __init__(self, tile_visits, config: Config):
        self.tile_visits = tile_visits
        self._config = config

    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        if tile_xy in self.tile_visits:
            return hex_color_to_float(self._config.color_strategy_visited_color)
        else:
            return None


class SquarePlannerColorStrategy(ColorStrategy):
    def __init__(
        self,
        tile_visits,
        config: Config,
        square_x: int,
        square_y: int,
        square_size: int,
    ):
        self.tile_visits = tile_visits
        self._config = config
        self.square_x = square_x
        self.square_y = square_y
        self.square_size = square_size

    def _color(self, tile_xy: tuple[int, int]) -> Optional[np.ndarray]:
        x, y = tile_xy
        if (
            self.square_x <= x < self.square_x + self.square_size
            and self.square_y <= y < self.square_y + self.square_size
        ):
            if tile_xy in self.tile_visits:
                return hex_color_to_float("#00aa004d")
            else:
                return hex_color_to_float("#aa00004d")
        elif tile_xy in self.tile_visits:
            return hex_color_to_float(self._config.color_strategy_visited_color)
        else:
            return None


def make_explorer_blueprint(
    authenticator: Authenticator,
    tile_visit_accessor: TileVisitAccessor,
    config_accessor: ConfigAccessor,
    tile_getter: TileGetter,
    image_transforms: dict[str, ImageTransform],
    config: Config,
) -> Blueprint:
    blueprint = Blueprint("explorer", __name__, template_folder="templates")

    @blueprint.route("/enable-zoom-level/<int:zoom>")
    @needs_authentication(authenticator)
    def enable_zoom_level(zoom: int) -> ResponseReturnValue:
        if 0 <= zoom <= 19:
            config_accessor().explorer_zoom_levels.append(zoom)
            config_accessor().explorer_zoom_levels.sort()
            config_accessor.save()
            compute_tile_evolution(tile_visit_accessor.tile_state, config_accessor())
            flash(f"Enabled {zoom=} for explorer tiles.", category="success")
        else:
            flash(f"{zoom=} is not valid, must be between 0 and 19.", category="danger")
        return redirect(url_for(".map", zoom=zoom))

    @blueprint.route(
        "/<int:zoom>/<float(signed=True):north>/<float(signed=True):east>/<float(signed=True):south>/<float(signed=True):west>/missing.<suffix>"
    )
    def download_missing(
        zoom: int, north: float, east: float, south: float, west: float, suffix: str
    ) -> ResponseReturnValue:
        x1, y1 = compute_tile(north, west, zoom)
        x2, y2 = compute_tile(south, east, zoom)
        tile_bounds = Bounds(x1, y1, x2 + 2, y2 + 2)

        tiles = get_tile_history_df(zoom)
        points = get_border_tiles(tiles, zoom, tile_bounds)
        if suffix == "geojson":
            result = make_grid_file_geojson(points)
        elif suffix == "gpx":
            result = make_grid_file_gpx(points)
        else:
            raise ValueError(f"Unsupported suffix: {suffix}")

        mimetypes = {"geojson": "application/json", "gpx": "application/xml"}
        return Response(
            result,
            mimetype=mimetypes[suffix],
            headers={"Content-disposition": "attachment"},
        )

    @blueprint.route(
        "/<int:zoom>/<float(signed=True):north>/<float(signed=True):east>/<float(signed=True):south>/<float(signed=True):west>/explored.<suffix>"
    )
    def download_explored(
        zoom: int, north: float, east: float, south: float, west: float, suffix: str
    ) -> ResponseReturnValue:
        x1, y1 = compute_tile(north, west, zoom)
        x2, y2 = compute_tile(south, east, zoom)
        tile_bounds = Bounds(x1, y1, x2 + 2, y2 + 2)

        tile_visits = tile_visit_accessor.tile_state["tile_visits"]
        tiles = tile_visits[zoom]
        points = make_grid_points(
            (tile for tile in tiles.keys() if tile_bounds.contains(*tile)), zoom
        )
        if suffix == "geojson":
            result = make_grid_file_geojson(points)
        elif suffix == "gpx":
            result = make_grid_file_gpx(points)
        else:
            raise ValueError(f"Unsupported suffix: {suffix}")

        mimetypes = {"geojson": "application/json", "gpx": "application/xml"}
        return Response(
            result,
            mimetype=mimetypes[suffix],
            headers={"Content-disposition": "attachment"},
        )

    @blueprint.route("/<int:zoom>/server-side")
    def server_side(zoom: int) -> ResponseReturnValue:
        if zoom not in config_accessor().explorer_zoom_levels:
            return {"zoom_level_not_generated": zoom}

        tile_evolution_state = tile_visit_accessor.tile_state["evolution_state"][zoom]

        # Get data from database
        medians = get_tile_medians(zoom)
        median_lat, median_lon = get_tile_upper_left_lat_lon(
            medians[0], medians[1], zoom
        )
        num_tiles = get_tile_count(zoom)
        tile_history = get_tile_history_df(zoom)

        bookmarks: list[dict[str, Any]] = []
        for bookmark in DB.session.scalars(
            sqlalchemy.select(ExplorerTileBookmark).where(
                ExplorerTileBookmark.zoom == zoom
            )
        ).all():
            tile = (bookmark.tile_x, bookmark.tile_y)
            representative = tile_evolution_state.memberships.get(tile, None)
            if not representative:
                continue
            cluster = tile_evolution_state.clusters.get(representative, None)
            if not cluster:
                continue
            bookmarks.append(
                {
                    "id": bookmark.id,
                    "name": bookmark.name,
                    "bbox": geojson_bounding_box_for_tile_collection(cluster, zoom),
                    "size": len(cluster),
                }
            )

        context = {
            "center": {
                "latitude": median_lat,
                "longitude": median_lon,
                "bbox": (
                    bounding_box_for_biggest_cluster(
                        tile_evolution_state.clusters.values(), zoom
                    )
                    if len(tile_evolution_state.memberships) > 0
                    else {}
                ),
            },
            "plot_tile_evolution": plot_tile_evolution(tile_history),
            "plot_cluster_evolution": plot_cluster_evolution(
                tile_evolution_state.cluster_evolution
            ),
            "plot_square_evolution": plot_square_evolution(
                tile_evolution_state.square_evolution
            ),
            "zoom": zoom,
            "num_tiles": num_tiles,
            "num_cluster_tiles": len(tile_evolution_state.memberships),
            "square_x": tile_evolution_state.square_x,
            "square_y": tile_evolution_state.square_y,
            "square_size": tile_evolution_state.max_square_size,
            "max_cluster_size": max(
                map(len, tile_evolution_state.clusters.values()), default=0
            ),
            "bookmarks": bookmarks,
        }
        return render_template("explorer/server-side.html.j2", **context)

    @blueprint.route("/<int:zoom>/tile/<int:z>/<int:x>/<int:y>.png")
    def tile(zoom: int, z: int, x: int, y: int) -> ResponseReturnValue:
        tile_visits = tile_visit_accessor.tile_state["tile_visits"][zoom]
        evolution_state = tile_visit_accessor.tile_state["evolution_state"][zoom]

        # map_tile = np.array(tile_getter.get_tile(z, x, y)) / 255
        # grayscale = image_transforms["grayscale"].transform_image(map_tile)
        grayscale = np.zeros((OSM_TILE_SIZE, OSM_TILE_SIZE, 4), dtype=np.float32)
        square_line_width = 3
        square_color = np.array([[[228, 26, 28, 255]]]) / 256

        color_strategy_name = request.args.get("color_strategy", "colorful_cluster")
        if color_strategy_name == "default":
            color_strategy_name = config_accessor().cluster_color_strategy
        match color_strategy_name:
            case "max_cluster":
                color_strategy = MaxClusterColorStrategy(
                    evolution_state, tile_visits, config
                )
            case "colorful_cluster":
                color_strategy = ColorfulClusterColorStrategy(
                    evolution_state, tile_visits, config
                )
            case "first":
                color_strategy = VisitTimeColorStrategy(
                    tile_visits, config, use_first=True
                )
            case "last":
                color_strategy = VisitTimeColorStrategy(
                    tile_visits, config, use_first=False
                )
            case "visits":
                color_strategy = NumVisitsColorStrategy(tile_visits, config)
            case "missing":
                color_strategy = MissingColorStrategy(tile_visits, config)
            case "visited":
                color_strategy = VisitedColorStrategy(tile_visits, config)
            case "square_planner":
                color_strategy = SquarePlannerColorStrategy(
                    tile_visits,
                    config,
                    int(request.args["x"]),
                    int(request.args["y"]),
                    int(request.args["size"]),
                )
            case _:
                raise ValueError("Unsupported color strategy.")

        if z >= zoom:
            factor = 2 ** (z - zoom)
            tile_x = x // factor
            tile_y = y // factor
            tile_xy = (tile_x, tile_y)
            color = color_strategy._color(tile_xy)
            if color is None:
                result = grayscale
            else:
                result = np.broadcast_to(color, grayscale.shape).copy()

            if x % factor == 0:
                result[:, 0, :] = 0.5
            if y % factor == 0:
                result[0, :, :] = 0.5

            if (
                evolution_state.square_x is not None
                and evolution_state.square_y is not None
            ):
                if (
                    x % factor == 0
                    and tile_x == evolution_state.square_x
                    and evolution_state.square_y
                    <= tile_y
                    < evolution_state.square_y + evolution_state.max_square_size
                ):
                    result[:, 0:square_line_width] = square_color
                if (
                    y % factor == 0
                    and tile_y == evolution_state.square_y
                    and evolution_state.square_x
                    <= tile_x
                    < evolution_state.square_x + evolution_state.max_square_size
                ):
                    result[0:square_line_width, :] = square_color
                if (
                    (x + 1) % factor == 0
                    and (x + 1) // factor
                    == evolution_state.square_x + evolution_state.max_square_size
                    and evolution_state.square_y
                    <= tile_y
                    < evolution_state.square_y + evolution_state.max_square_size
                ):
                    result[:, -square_line_width:] = square_color
                if (
                    (y + 1) % factor == 0
                    and (y + 1) // factor
                    == evolution_state.square_y + evolution_state.max_square_size
                    and evolution_state.square_x
                    <= tile_x
                    < evolution_state.square_x + evolution_state.max_square_size
                ):
                    result[-square_line_width:, :] = square_color
        else:
            result = grayscale
            factor = 2 ** (zoom - z)
            width = 256 // factor
            for xo in range(factor):
                for yo in range(factor):
                    tile_x = x * factor + xo
                    tile_y = y * factor + yo
                    tile_xy = (tile_x, tile_y)
                    color = color_strategy._color(tile_xy)
                    if color is not None:
                        result[
                            yo * width : (yo + 1) * width, xo * width : (xo + 1) * width
                        ] = color

                    if (
                        evolution_state.square_x is not None
                        and evolution_state.square_y is not None
                    ):
                        if (
                            tile_x == evolution_state.square_x
                            and evolution_state.square_y
                            <= tile_y
                            < evolution_state.square_y + evolution_state.max_square_size
                        ):
                            result[
                                yo * width : (yo + 1) * width,
                                xo * width : xo * width + square_line_width,
                            ] = square_color
                        if (
                            tile_y == evolution_state.square_y
                            and evolution_state.square_x
                            <= tile_x
                            < evolution_state.square_x + evolution_state.max_square_size
                        ):
                            result[
                                yo * width : yo * width + square_line_width,
                                xo * width : (xo + 1) * width,
                            ] = square_color

                        if (
                            tile_x + 1
                            == evolution_state.square_x
                            + evolution_state.max_square_size
                            and evolution_state.square_y
                            <= tile_y
                            < evolution_state.square_y + evolution_state.max_square_size
                        ):
                            result[
                                yo * width : (yo + 1) * width,
                                (xo + 1) * width - square_line_width : (xo + 1) * width,
                            ] = square_color

                        if (
                            tile_y + 1
                            == evolution_state.square_y
                            + evolution_state.max_square_size
                            and evolution_state.square_x
                            <= tile_x
                            < evolution_state.square_x + evolution_state.max_square_size
                        ):
                            result[
                                (yo + 1) * width - square_line_width : (yo + 1) * width,
                                xo * width : (xo + 1) * width,
                            ] = square_color
                    if width >= 64:
                        result[yo * width, :, :] = 0.5
                        result[:, xo * width, :] = 0.5
        f = io.BytesIO()
        pl.imsave(f, result, format="png")
        return Response(bytes(f.getbuffer()), mimetype="image/png")

    @blueprint.route(
        "/<int:zoom>/info/<float(signed=True):latitude>/<float(signed=True):longitude>"
    )
    def info(zoom: int, latitude: float, longitude: float) -> str:
        evolution_state = tile_visit_accessor.tile_state["evolution_state"][zoom]
        tile_xy = compute_tile(latitude, longitude, zoom)
        context: dict[str, Any] = {
            "tile_x": tile_xy[0],
            "tile_y": tile_xy[1],
            "zoom": zoom,
            "square_size": evolution_state.max_square_size,
        }

        # Query tile info from database
        tile_visit = (
            DB.session.query(TileVisit)
            .filter(
                TileVisit.zoom == zoom,
                TileVisit.tile_x == tile_xy[0],
                TileVisit.tile_y == tile_xy[1],
            )
            .first()
        )

        if tile_visit is not None:
            context.update(
                {
                    "num_visits": tile_visit.visit_count,
                    "first_activity_id": tile_visit.first_activity_id,
                    "first_activity_name": tile_visit.first_activity.name,
                    "first_time": (
                        tile_visit.first_time.isoformat()
                        if tile_visit.first_time
                        else None
                    ),
                    "last_activity_id": tile_visit.last_activity_id,
                    "last_activity_name": tile_visit.last_activity.name,
                    "last_time": (
                        tile_visit.last_time.isoformat()
                        if tile_visit.last_time
                        else None
                    ),
                    "is_cluster": tile_xy in evolution_state.memberships,
                    "this_cluster_size": len(
                        evolution_state.clusters.get(
                            evolution_state.memberships.get(tile_xy, None), []
                        )
                    ),
                    "new_bookmark_url": url_for(
                        "settings.cluster_bookmark_new",
                        zoom=zoom,
                        tile_x=tile_xy[0],
                        tile_y=tile_xy[1],
                    ),
                    "activities_through_tile_url": url_for(
                        ".activities_through_tile",
                        zoom=zoom,
                        tile_x=tile_xy[0],
                        tile_y=tile_xy[1],
                        radius=0,
                    ),
                }
            )
        return render_template("explorer/tooltip.html.j2", **context)

    @blueprint.route("/<int:zoom>/activities/<int:tile_x>/<int:tile_y>/<int:radius>")
    def activities_through_tile(
        zoom: int, tile_x: int, tile_y: int, radius: int
    ) -> ResponseReturnValue:
        """List all activities that pass through a tile or its vicinity.

        Args:
            zoom: The tile zoom level.
            tile_x: The tile X coordinate.
            tile_y: The tile Y coordinate.
            radius: The radius of neighboring tiles to include (0 = just this tile).
        """
        activities_per_tile = tile_visit_accessor.tile_state["activities_per_tile"][
            zoom
        ]

        # Collect all activity IDs from the tile and its neighbors within the radius
        activity_ids: set[int] = set()
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                tile = (tile_x + dx, tile_y + dy)
                if tile in activities_per_tile:
                    activity_ids.update(activities_per_tile[tile])

        # Fetch activities from database
        activities = []
        if activity_ids:
            activities = (
                DB.session.query(Activity)
                .filter(Activity.id.in_(activity_ids))
                .order_by(Activity.start.desc())
                .all()
            )

        context = {
            "zoom": zoom,
            "tile_x": tile_x,
            "tile_y": tile_y,
            "radius": radius,
            "activities": activities,
            "num_activities": len(activities),
        }
        return render_template("explorer/activities_through_tile.html.j2", **context)

    return blueprint


def bounding_box_for_biggest_cluster(
    clusters: Iterable[list[tuple[int, int]]], zoom: int
) -> str:
    biggest_cluster = max(clusters, key=lambda members: len(members))
    return geojson_bounding_box_for_tile_collection(biggest_cluster, zoom)


def geojson_bounding_box_for_tile_collection(
    tiles: list[tuple[int, int]], zoom: int
) -> str:
    min_x = min(x for x, y in tiles)
    max_x = max(x for x, y in tiles)
    min_y = min(y for x, y in tiles)
    max_y = max(y for x, y in tiles)
    lat_max, lon_min = get_tile_upper_left_lat_lon(min_x, min_y, zoom)
    lat_min, lon_max = get_tile_upper_left_lat_lon(max_x, max_y, zoom)
    return geojson.dumps(
        geojson.Feature(
            geometry=geojson.Polygon(
                [
                    [
                        (lon_min, lat_max),
                        (lon_max, lat_max),
                        (lon_max, lat_min),
                        (lon_min, lat_min),
                        (lon_min, lat_max),
                    ]
                ]
            ),
        )
    )


def plot_tile_evolution(tiles: pd.DataFrame) -> str:
    if len(tiles) == 0:
        return ""
    tiles["count"] = np.arange(1, len(tiles) + 1)
    return (
        alt.Chart(tiles, title="Tiles")
        .mark_line(interpolate="step-after")
        .encode(alt.X("time", title="Time"), alt.Y("count", title="Number of tiles"))
        .interactive(bind_y=False)
        .to_json(format="vega")
    )


def plot_cluster_evolution(cluster_evolution: pd.DataFrame) -> str:
    if len(cluster_evolution) == 0:
        return ""
    return (
        alt.Chart(cluster_evolution, title="Cluster")
        .mark_line(interpolate="step-after")
        .encode(
            alt.X("time", title="Time"),
            alt.Y("max_cluster_size", title="Maximum cluster size"),
        )
        .interactive(bind_y=False)
        .to_json(format="vega")
    )


def plot_square_evolution(square_evolution: pd.DataFrame) -> str:
    if len(square_evolution) == 0:
        return ""
    return (
        alt.Chart(square_evolution, title="Square")
        .mark_line(interpolate="step-after")
        .encode(
            alt.X("time", title="Time"),
            alt.Y("max_square_size", title="Maximum square size"),
        )
        .interactive(bind_y=False)
        .to_json(format="vega")
    )
