"""Configuration management for AOC CLI."""

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


CONFIG_PATH = Path.home() / ".aocconfig"


@dataclass
class Config:
    email: str
    display_name: str
    session_token: str
    template: str


def get_config() -> Optional[Config]:
    """Load config from ~/.aocconfig."""
    try:
        content = CONFIG_PATH.read_text()
        data = json.loads(content)
        return Config(
            email=data["email"],
            display_name=data["display_name"],
            session_token=data["session_token"],
            template=data["template"],
        )
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        return None


def save_config(config: Config) -> None:
    """Save config to ~/.aocconfig."""
    data = {
        "email": config.email,
        "display_name": config.display_name,
        "session_token": config.session_token,
        "template": config.template,
    }
    CONFIG_PATH.write_text(json.dumps(data, indent=2))


def config_exists() -> bool:
    """Check if config file exists."""
    return CONFIG_PATH.exists()
