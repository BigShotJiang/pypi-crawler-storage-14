"""Run solution with real input without submitting."""

import re
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import click


@dataclass
class PuzzleInfo:
    year: int
    day: int
    dir: Path


@dataclass
class SolutionResult:
    output: str
    duration_ms: int


def detect_puzzle() -> Optional[PuzzleInfo]:
    """Detect puzzle from current directory."""
    cwd = Path.cwd()
    parts = cwd.parts

    try:
        aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
    except ValueError:
        return None

    after_aoc = parts[aoc_index + 1:]
    if len(after_aoc) != 2:
        return None

    try:
        year = int(after_aoc[0])
        day = int(after_aoc[1])
    except ValueError:
        return None

    return PuzzleInfo(year=year, day=day, dir=cwd)


def parse_puzzle_arg(puzzle: str) -> Optional[tuple]:
    """Parse puzzle argument like '2024/1'."""
    match = re.match(r"^(\d{4})/(\d{1,2})$", puzzle)
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def format_duration(ms: int) -> str:
    """Format duration in human-readable form."""
    if ms < 1000:
        return f"{ms}ms"
    elif ms < 60000:
        return f"{ms / 1000:.2f}s"
    else:
        mins = ms // 60000
        secs = (ms % 60000) / 1000
        return f"{mins}m {secs:.1f}s"


def run_solution(dir: Path) -> SolutionResult:
    """Run the solution file in the given directory."""
    # Find solution file
    solution_files = list(dir.glob("solution.*"))
    if not solution_files:
        raise click.ClickException("No solution file found")

    solution_file = solution_files[0]
    ext = solution_file.suffix

    if ext == ".py":
        cmd = ["python3", str(solution_file)]
    elif ext == ".js":
        cmd = ["node", str(solution_file)]
    elif ext == ".ts":
        cmd = ["npx", "tsx", str(solution_file)]
    else:
        raise click.ClickException(f"Unknown file extension: {ext}")

    start_time = time.time()

    result = subprocess.run(
        cmd,
        cwd=dir,
        capture_output=True,
        text=True,
    )

    duration_ms = int((time.time() - start_time) * 1000)

    # Print stdout
    if result.stdout:
        sys.stdout.write(result.stdout)

    # Print stderr
    if result.stderr:
        sys.stderr.write(result.stderr)

    if result.returncode != 0:
        raise click.ClickException(f"Solution exited with code {result.returncode}")

    return SolutionResult(
        output=result.stdout.strip() if result.stdout else "",
        duration_ms=duration_ms,
    )


@click.command()
@click.option("-p", "--puzzle", help="Puzzle to run (e.g., 2024/1)")
def run(puzzle: Optional[str]):
    """Run solution with real input (without submitting)."""
    # Determine puzzle
    if puzzle:
        parsed = parse_puzzle_arg(puzzle)
        if not parsed:
            raise click.ClickException("Invalid puzzle format. Use: -p <year>/<day>")
        year, day = parsed

        # Find directory
        cwd = Path.cwd()
        parts = cwd.parts
        try:
            aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
        except ValueError:
            raise click.ClickException("Not in an aoc directory")

        dir = Path(*parts[:aoc_index + 1]) / str(year) / str(day)
    else:
        detected = detect_puzzle()
        if not detected:
            raise click.ClickException(
                "Could not detect puzzle. Run from aoc/<year>/<day>/ or use -p <year>/<day>"
            )
        year = detected.year
        day = detected.day
        dir = detected.dir

    # Check that in.txt exists
    input_path = dir / "in.txt"
    if not input_path.exists():
        raise click.ClickException(
            f"No in.txt found in {dir}\n"
            "Run `aoc get <year>/<day>` to fetch the input first."
        )

    click.echo(f"Running solution for {year} day {day}...\n")

    try:
        result = run_solution(dir)
        lines = [l for l in result.output.split("\n") if l.strip()]
        last_line = lines[-1] if lines else ""

        click.echo(f"\nAnswer: {last_line}")
        click.echo(f"Execution time: {format_duration(result.duration_ms)}")
    except click.ClickException:
        raise
    except Exception as e:
        raise click.ClickException(str(e))
