"""Run solution against test cases from test.txt."""

import re
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import click


@dataclass
class PuzzleInfo:
    year: int
    day: int
    dir: Path


@dataclass
class TestCase:
    input: str
    expected_output: Optional[str]


@dataclass
class SolutionResult:
    output: str
    duration_ms: int


def detect_puzzle() -> Optional[PuzzleInfo]:
    """Detect puzzle from current directory."""
    cwd = Path.cwd()
    parts = cwd.parts

    try:
        aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
    except ValueError:
        return None

    after_aoc = parts[aoc_index + 1:]
    if len(after_aoc) != 2:
        return None

    try:
        year = int(after_aoc[0])
        day = int(after_aoc[1])
    except ValueError:
        return None

    return PuzzleInfo(year=year, day=day, dir=cwd)


def parse_puzzle_arg(puzzle: str) -> Optional[tuple]:
    """Parse puzzle argument like '2024/1'."""
    match = re.match(r"^(\d{4})/(\d{1,2})$", puzzle)
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def format_duration(ms: int) -> str:
    """Format duration in human-readable form."""
    if ms < 1000:
        return f"{ms}ms"
    elif ms < 60000:
        return f"{ms / 1000:.2f}s"
    else:
        mins = ms // 60000
        secs = (ms % 60000) / 1000
        return f"{mins}m {secs:.1f}s"


def parse_test_file(content: str) -> List[TestCase]:
    """Parse test.txt content into test cases."""
    test_cases = []
    sections = re.split(r"^=== TEST \d+ ===$", content, flags=re.MULTILINE)

    for section in sections:
        section = section.strip()
        if not section:
            continue

        lines = section.split("\n")
        expected_output = None
        input_start_index = -1

        for i, line in enumerate(lines):
            if line.startswith("EXPECTED:"):
                value = line.replace("EXPECTED:", "").strip()
                expected_output = None if value == "(unknown)" else value
            elif line.startswith("INPUT:"):
                input_start_index = i + 1
                break

        if input_start_index >= 0:
            input_text = "\n".join(lines[input_start_index:]).strip()
            if input_text:
                test_cases.append(TestCase(input=input_text, expected_output=expected_output))

    return test_cases


def run_solution_with_input(dir: Path, input_text: str) -> SolutionResult:
    """Run the solution with custom input."""
    # Find solution file
    solution_files = list(dir.glob("solution.*"))
    if not solution_files:
        raise click.ClickException("No solution file found")

    solution_file = solution_files[0]
    ext = solution_file.suffix

    # Create temporary input file (using _test_input.txt to avoid conflicts with test.txt)
    test_input_path = dir / "_test_input.txt"
    test_input_path.write_text(input_text)

    # Read the solution file and modify it to use test input
    original_code = solution_file.read_text()
    test_code = re.sub(r'["\']in\.txt["\']', '"_test_input.txt"', original_code)

    # Write modified solution to temp file
    test_solution_path = dir / f"test_solution{ext}"
    test_solution_path.write_text(test_code)

    try:
        if ext == ".py":
            cmd = ["python3", str(test_solution_path)]
        elif ext == ".js":
            cmd = ["node", str(test_solution_path)]
        elif ext == ".ts":
            cmd = ["npx", "tsx", str(test_solution_path)]
        elif ext == ".hs":
            cmd = ["runhaskell", str(test_solution_path)]
        elif ext in (".cpp", ".cc", ".cxx"):
            # Compile and run C++
            executable = dir / "test_solution_bin"
            compile_result = subprocess.run(
                ["g++", "-O2", "-o", str(executable), str(test_solution_path)],
                cwd=dir,
                capture_output=True,
                text=True,
            )
            if compile_result.returncode != 0:
                if compile_result.stderr:
                    sys.stderr.write(compile_result.stderr)
                raise click.ClickException(f"C++ compilation failed")
            cmd = [str(executable)]
        else:
            raise click.ClickException(f"Unknown file extension: {ext}")

        start_time = time.time()

        result = subprocess.run(
            cmd,
            cwd=dir,
            capture_output=True,
            text=True,
        )

        duration_ms = int((time.time() - start_time) * 1000)

        # Print stdout
        if result.stdout:
            sys.stdout.write(result.stdout)

        # Print stderr
        if result.stderr:
            sys.stderr.write(result.stderr)

        if result.returncode != 0:
            raise click.ClickException(f"Solution exited with code {result.returncode}")

        return SolutionResult(
            output=result.stdout.strip() if result.stdout else "",
            duration_ms=duration_ms,
        )
    finally:
        # Clean up temp files
        try:
            test_input_path.unlink()
            test_solution_path.unlink()
            # Clean up C++ executable if it exists
            executable = dir / "test_solution_bin"
            if executable.exists():
                executable.unlink()
        except Exception:
            pass


@click.command()
@click.option("-p", "--puzzle", help="Puzzle to test (e.g., 2024/1)")
def test(puzzle: Optional[str]):
    """Run solution against test cases from test.txt."""
    # Determine puzzle
    if puzzle:
        parsed = parse_puzzle_arg(puzzle)
        if not parsed:
            raise click.ClickException("Invalid puzzle format. Use: -p <year>/<day>")
        year, day = parsed

        # Find directory
        cwd = Path.cwd()
        parts = cwd.parts
        try:
            aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
        except ValueError:
            raise click.ClickException("Not in an aoc directory")

        dir = Path(*parts[:aoc_index + 1]) / str(year) / str(day)
    else:
        detected = detect_puzzle()
        if not detected:
            raise click.ClickException(
                "Could not detect puzzle. Run from aoc/<year>/<day>/ or use -p <year>/<day>"
            )
        year = detected.year
        day = detected.day
        dir = detected.dir

    # Read test cases from test.txt
    test_path = dir / "test.txt"
    if not test_path.exists():
        raise click.ClickException(
            f"No test.txt found in {dir}\n"
            "Run `aoc get <year>/<day>` to fetch test cases, or create test.txt manually.\n\n"
            "Format:\n"
            "=== TEST 1 ===\n"
            "EXPECTED: 123\n"
            "INPUT:\n"
            "<your test input here>"
        )

    test_content = test_path.read_text()
    test_cases = parse_test_file(test_content)

    if not test_cases:
        raise click.ClickException("No test cases found in test.txt")

    click.echo(f"Running {len(test_cases)} test case(s) for {year} day {day}\n")

    all_passed = True

    for i, test_case in enumerate(test_cases):
        click.echo(f"--- Test Case {i + 1} ---")
        click.echo("Input:")

        # Show first few lines of input
        input_lines = test_case.input.split("\n")
        if len(input_lines) <= 10:
            click.echo(test_case.input)
        else:
            click.echo("\n".join(input_lines[:5]))
            click.echo(f"... ({len(input_lines) - 5} more lines)")
        click.echo("")

        if test_case.expected_output:
            click.echo(f"Expected: {test_case.expected_output} (auto-parsed, verify this is correct)")

        click.echo("\nRunning solution...\n")

        try:
            result = run_solution_with_input(dir, test_case.input)
            lines = [l for l in result.output.split("\n") if l.strip()]
            actual_output = lines[-1] if lines else ""

            click.echo(f"\nGot: {actual_output}")
            click.echo(f"Time: {format_duration(result.duration_ms)}")

            if test_case.expected_output:
                if actual_output == test_case.expected_output:
                    click.echo("✅ PASSED")
                else:
                    click.echo("❌ FAILED")
                    all_passed = False
            else:
                click.echo("⚠️  No expected output to compare (verify manually)")
        except click.ClickException:
            raise
        except Exception as e:
            click.echo(f"Error: {e}", err=True)
            all_passed = False

        click.echo("")

    if all_passed and any(tc.expected_output for tc in test_cases):
        click.echo("All tests passed!")
