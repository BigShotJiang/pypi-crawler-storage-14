"""Initialize AOC configuration."""

import sys
from pathlib import Path

import click

from ..config import config_exists, save_config, Config
from ..api import create_user, APIError


PYTHON_TEMPLATE = '''def solve(input_text):
    pass

if __name__ == "__main__":
    with open("in.txt") as f:
        print(solve(f.read()))
'''


@click.command()
def init():
    """Initialize AOC configuration."""
    if config_exists():
        click.echo("Config already exists at ~/.aocconfig. This will override it.\n")

    click.echo("Welcome to AOC Leaderboard CLI!\n")

    email = click.prompt("Email")
    display_name = click.prompt("Display name")
    session_token = click.prompt("AoC session token (from browser cookies)")
    template = click.prompt("Language (press Enter for python)", default="python")

    # Warn if non-python language
    if template != "python":
        click.echo(f"\nWarning: Only python template is provided by default.", err=True)
        click.echo(f"You must create aoc/templates/{template}.{template} yourself for templates to work.", err=True)

    # Register with server
    try:
        create_user(email, display_name)
        click.echo("\nRegistered with leaderboard server.")
    except APIError as e:
        click.echo(f"\nWarning: Could not register with server: {e}", err=True)
        click.echo("You can still use the CLI, but results won't be tracked.", err=True)

    save_config(Config(
        email=email,
        display_name=display_name,
        session_token=session_token,
        template=template,
    ))

    # Create aoc/ directory with templates
    aoc_dir = Path.cwd() / "aoc"
    aoc_dir.mkdir(parents=True, exist_ok=True)

    # Create templates/ directory with python.py template
    templates_dir = aoc_dir / "templates"
    templates_dir.mkdir(parents=True, exist_ok=True)
    python_template_path = templates_dir / "python.py"
    if not python_template_path.exists():
        python_template_path.write_text(PYTHON_TEMPLATE)
        click.echo(f"Created aoc/templates/python.py")

    click.echo(f"\nConfig saved to ~/.aocconfig")
    click.echo(f"Created aoc/ directory. Run `aoc get <year>/<day>` to start a puzzle.")
