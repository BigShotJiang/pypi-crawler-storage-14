"""Get puzzle input and create solution template."""

import re
import sys
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import click
import requests
from bs4 import BeautifulSoup

from ..config import get_config
from ..api import start_submission, APIError




@dataclass
class DirInfo:
    target_dir: Path
    year: int
    day: int


@dataclass
class TestCase:
    input: str
    expected_output: Optional[str]


def detect_directory(requested_year: int, requested_day: int) -> DirInfo:
    """Detect the target directory based on current location."""
    cwd = Path.cwd()
    parts = cwd.parts

    # Find 'aoc' in path
    try:
        aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
    except ValueError:
        raise click.ClickException("Not in an aoc directory. Run `aoc init` first.")

    after_aoc = parts[aoc_index + 1:]

    # cwd is aoc/
    if len(after_aoc) == 0:
        return DirInfo(
            target_dir=cwd / str(requested_year) / str(requested_day),
            year=requested_year,
            day=requested_day,
        )

    # cwd is aoc/<year>/
    if len(after_aoc) == 1:
        cwd_year = int(after_aoc[0])
        if cwd_year != requested_year:
            raise click.ClickException(
                f"You're in aoc/{cwd_year}/ but requested year {requested_year}. "
                "cd to the correct year directory."
            )
        return DirInfo(
            target_dir=cwd / str(requested_day),
            year=requested_year,
            day=requested_day,
        )

    # cwd is aoc/<year>/<day>/
    if len(after_aoc) == 2:
        cwd_year = int(after_aoc[0])
        cwd_day = int(after_aoc[1])
        if cwd_year != requested_year or cwd_day != requested_day:
            raise click.ClickException(
                f"You're in aoc/{cwd_year}/{cwd_day}/ but requested {requested_year}/{requested_day}."
            )
        return DirInfo(
            target_dir=cwd,
            year=requested_year,
            day=requested_day,
        )

    raise click.ClickException("Unexpected directory structure.")


def fetch_input(year: int, day: int, session_token: str) -> str:
    """Fetch puzzle input from Advent of Code."""
    url = f"https://adventofcode.com/{year}/day/{day}/input"
    response = requests.get(url, cookies={"session": session_token})

    if not response.ok:
        raise click.ClickException(f"Failed to fetch input: {response.status_code} {response.reason}")

    return response.text


def fetch_problem_page(year: int, day: int, session_token: str) -> str:
    """Fetch problem page HTML from Advent of Code."""
    url = f"https://adventofcode.com/{year}/day/{day}"
    response = requests.get(url, cookies={"session": session_token})

    if not response.ok:
        raise click.ClickException(f"Failed to fetch problem: {response.status_code} {response.reason}")

    return response.text


def extract_test_cases(html: str) -> List[TestCase]:
    """Extract test cases from problem HTML."""
    soup = BeautifulSoup(html, "html.parser")
    test_cases = []

    # Find all <pre><code> blocks which typically contain examples
    code_blocks = []
    for pre in soup.find_all("pre"):
        code = pre.find("code")
        if code:
            text = code.get_text().strip()
            if text:
                code_blocks.append(text)
        else:
            text = pre.get_text().strip()
            if text:
                code_blocks.append(text)

    # Look for patterns like "the answer would be X" or "the result is X"
    article_text = ""
    for article in soup.find_all("article"):
        article_text += article.get_text()

    # Common answer patterns in AoC problems
    answer_patterns = [
        r"(?:the )?(?:answer|result|total|sum|output|value) (?:would be|is|equals?|=)\s*[`*]*(\d+)[`*]*",
        r"(?:produces?|returns?|gives?|yields?)\s*[`*]*(\d+)[`*]*",
        r"[`*]*(\d+)[`*]*\s*(?:is the answer|is correct)",
    ]

    potential_answers = []

    # Find emphasized code blocks which often contain answers
    for code_em in soup.select("code em, em code"):
        text = code_em.get_text().strip()
        if text and text.isdigit():
            potential_answers.append(text)

    for pattern in answer_patterns:
        for match in re.finditer(pattern, article_text, re.IGNORECASE):
            potential_answers.append(match.group(1))

    # If we found code blocks, use the first one as test input
    # The last emphasized number is likely the expected output
    if code_blocks:
        test_cases.append(TestCase(
            input=code_blocks[0],
            expected_output=potential_answers[-1] if potential_answers else None,
        ))

    return test_cases


def format_test_file(test_cases: List[TestCase]) -> str:
    """Format test cases for writing to file."""
    lines = []

    for i, tc in enumerate(test_cases):
        if i > 0:
            lines.append("")
        lines.append(f"=== TEST {i + 1} ===")
        if tc.expected_output:
            lines.append(f"EXPECTED: {tc.expected_output}")
        else:
            lines.append("EXPECTED: (unknown)")
        lines.append("INPUT:")
        lines.append(tc.input)

    return "\n".join(lines) + "\n"


def update_test_expected_answer(test_path: Path, new_expected: Optional[str]) -> bool:
    """Update the expected answer in an existing test.txt file.

    Returns True if the file was updated, False otherwise.
    """
    if not test_path.exists():
        return False

    content = test_path.read_text()

    # Replace the EXPECTED line with the new value
    if new_expected:
        new_content = re.sub(
            r"^EXPECTED:.*$",
            f"EXPECTED: {new_expected}",
            content,
            count=1,
            flags=re.MULTILINE
        )
    else:
        new_content = re.sub(
            r"^EXPECTED:.*$",
            "EXPECTED: (unknown)",
            content,
            count=1,
            flags=re.MULTILINE
        )

    if new_content != content:
        test_path.write_text(new_content)
        return True

    return False


@click.command()
@click.argument("puzzle")
def get(puzzle: str):
    """Get puzzle input (e.g., aoc get 2024/1)."""
    config = get_config()
    if not config:
        raise click.ClickException("Not configured. Run `aoc init` first.")

    # Parse year/day
    match = re.match(r"^(\d{4})/(\d{1,2})$", puzzle)
    if not match:
        raise click.ClickException("Invalid puzzle format. Use: aoc get <year>/<day> (e.g., aoc get 2024/1)")

    year = int(match.group(1))
    day = int(match.group(2))

    if day < 1 or day > 25:
        raise click.ClickException("Day must be between 1 and 25")

    # Detect target directory
    dir_info = detect_directory(year, day)
    target_dir = dir_info.target_dir

    # Create directory
    target_dir.mkdir(parents=True, exist_ok=True)

    input_path = target_dir / "in.txt"

    # Fetch and write input
    if input_path.exists():
        click.echo("in.txt already exists, skipping")
    else:
        click.echo(f"Fetching input for {year} day {day}...")
        try:
            input_text = fetch_input(year, day, config.session_token)
            input_path.write_text(input_text)
            click.echo(f"Wrote {input_path}")
        except Exception as e:
            raise click.ClickException(f"Failed to fetch input: {e}")

    # Find and copy template
    # Find the aoc root directory
    cwd = Path.cwd()
    parts = cwd.parts
    aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
    aoc_root = Path(*parts[:aoc_index + 1])
    templates_dir = aoc_root / "templates"

    # Look for template file (e.g., python.py, javascript.js)
    template_files = list(templates_dir.glob(f"{config.template}.*")) if templates_dir.exists() else []

    if template_files:
        template_file = template_files[0]
        ext = template_file.suffix
        solution_path = target_dir / f"solution{ext}"

        if solution_path.exists():
            click.echo(f"solution{ext} already exists, skipping")
        else:
            template_content = template_file.read_text()
            solution_path.write_text(template_content)
            click.echo(f"Wrote {solution_path}")
    else:
        click.echo(f"Warning: No template found for '{config.template}' in aoc/templates/", err=True)
        click.echo(f"You need to create solution.* yourself for test/submit commands to work.", err=True)
        click.echo(f"Tip: Your solution should print the final answer as the last line to stdout.", err=True)

    # Fetch and write test cases
    test_path = target_dir / "test.txt"
    if test_path.exists():
        click.echo("test.txt already exists, skipping")
    else:
        click.echo(f"Fetching test cases for {year} day {day}...")
        try:
            html = fetch_problem_page(year, day, config.session_token)
            test_cases = extract_test_cases(html)
            if test_cases:
                # Only use the first test case - parsing multiple is unreliable
                if len(test_cases) > 1:
                    click.echo(f"Warning: Found {len(test_cases)} potential test cases, using only the first one.", err=True)
                    click.echo("Note: This tool supports only 1 test case. Edit test.txt manually if needed.", err=True)
                    test_cases = test_cases[:1]
                test_content = format_test_file(test_cases)
                test_path.write_text(test_content)
                click.echo(f"Wrote {test_path}")
                click.echo("Note: Expected answer was auto-parsed and may be incorrect. Please verify.")
            else:
                click.echo("No test cases found in problem description")
        except Exception as e:
            click.echo(f"Warning: Could not fetch test cases: {e}", err=True)

    # Register start time with server
    try:
        start_submission(config.email, year, day, 1)
        click.echo("Registered start time with server")
    except APIError as e:
        if "already started" in str(e):
            click.echo("Start time already registered")
        else:
            click.echo(f"Warning: Could not register with server: {e}", err=True)

    # Open browser
    problem_url = f"https://adventofcode.com/{year}/day/{day}"
    click.echo(f"Opening {problem_url}")
    webbrowser.open(problem_url)
