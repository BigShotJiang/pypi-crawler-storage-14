"""Submit answer to Advent of Code."""

import re
import subprocess
import sys
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import click
import requests

from ..config import get_config
from ..api import check_submission, end_submission, APIError
from .get import fetch_problem_page, extract_test_cases, update_test_expected_answer


@dataclass
class PuzzleInfo:
    year: int
    day: int
    dir: Path


@dataclass
class SolutionResult:
    output: str
    duration_ms: int


@dataclass
class SubmitResult:
    correct: bool
    message: str


def detect_puzzle() -> Optional[PuzzleInfo]:
    """Detect puzzle from current directory."""
    cwd = Path.cwd()
    parts = cwd.parts

    try:
        aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
    except ValueError:
        return None

    after_aoc = parts[aoc_index + 1:]
    if len(after_aoc) != 2:
        return None

    try:
        year = int(after_aoc[0])
        day = int(after_aoc[1])
    except ValueError:
        return None

    return PuzzleInfo(year=year, day=day, dir=cwd)


def parse_puzzle_arg(puzzle: str) -> Optional[tuple]:
    """Parse puzzle argument like '2024/1'."""
    match = re.match(r"^(\d{4})/(\d{1,2})$", puzzle)
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def format_duration(ms: int) -> str:
    """Format duration in human-readable form."""
    if ms < 1000:
        return f"{ms}ms"
    elif ms < 60000:
        return f"{ms / 1000:.2f}s"
    else:
        mins = ms // 60000
        secs = (ms % 60000) / 1000
        return f"{mins}m {secs:.1f}s"


def run_solution(dir: Path) -> SolutionResult:
    """Run the solution file in the given directory."""
    # Find solution file
    solution_files = list(dir.glob("solution.*"))
    if not solution_files:
        raise click.ClickException("No solution file found")

    solution_file = solution_files[0]
    ext = solution_file.suffix

    if ext == ".py":
        cmd = ["python3", str(solution_file)]
    elif ext == ".js":
        cmd = ["node", str(solution_file)]
    elif ext == ".ts":
        cmd = ["npx", "tsx", str(solution_file)]
    elif ext == ".hs":
        cmd = ["runhaskell", str(solution_file)]
    elif ext in (".cpp", ".cc", ".cxx"):
        # Compile and run C++
        executable = dir / "solution_bin"
        compile_result = subprocess.run(
            ["g++", "-O2", "-o", str(executable), str(solution_file)],
            cwd=dir,
            capture_output=True,
            text=True,
        )
        if compile_result.returncode != 0:
            if compile_result.stderr:
                sys.stderr.write(compile_result.stderr)
            raise click.ClickException(f"C++ compilation failed")
        cmd = [str(executable)]
    else:
        raise click.ClickException(f"Unknown file extension: {ext}")

    start_time = time.time()

    result = subprocess.run(
        cmd,
        cwd=dir,
        capture_output=True,
        text=True,
    )

    duration_ms = int((time.time() - start_time) * 1000)

    # Print stdout
    if result.stdout:
        sys.stdout.write(result.stdout)

    # Print stderr
    if result.stderr:
        sys.stderr.write(result.stderr)

    if result.returncode != 0:
        raise click.ClickException(f"Solution exited with code {result.returncode}")

    return SolutionResult(
        output=result.stdout.strip() if result.stdout else "",
        duration_ms=duration_ms,
    )


def submit_to_aoc(year: int, day: int, part: int, answer: str, session_token: str) -> SubmitResult:
    """Submit answer to Advent of Code."""
    url = f"https://adventofcode.com/{year}/day/{day}/answer"
    response = requests.post(
        url,
        data={"level": part, "answer": answer},
        cookies={"session": session_token},
    )

    if not response.ok:
        raise click.ClickException(f"AoC submission failed: {response.status_code}")

    html = response.text

    # Parse response
    if "That's the right answer" in html:
        return SubmitResult(correct=True, message="That's the right answer!")

    if "That's not the right answer" in html:
        # Extract hint if present
        hint_match = re.search(
            r"That's not the right answer[^<]*(?:<[^>]+>[^<]*)*your answer is too (low|high)",
            html,
            re.IGNORECASE,
        )
        hint = f" Your answer is too {hint_match.group(1)}." if hint_match else ""
        return SubmitResult(correct=False, message=f"That's not the right answer.{hint}")

    if "You gave an answer too recently" in html:
        wait_match = re.search(r"You have (?:(\d+)m )?(\d+)s left to wait", html)
        if wait_match:
            wait = f"Wait {wait_match.group(1) + 'm ' if wait_match.group(1) else ''}{wait_match.group(2)}s."
        else:
            wait = ""
        return SubmitResult(correct=False, message=f"Rate limited. {wait}")

    if "You don't seem to be solving the right level" in html:
        return SubmitResult(correct=False, message="Wrong level - you may have already solved this part.")

    return SubmitResult(correct=False, message="Unknown response from AoC")


@click.command()
@click.option("-a", "--answer", help="Answer to submit")
@click.option("-p", "--puzzle", help="Puzzle to submit for (e.g., 2024/1)")
def submit(answer: Optional[str], puzzle: Optional[str]):
    """Submit answer."""
    config = get_config()
    if not config:
        raise click.ClickException("Not configured. Run `aoc init` first.")

    # Determine puzzle
    if puzzle:
        parsed = parse_puzzle_arg(puzzle)
        if not parsed:
            raise click.ClickException("Invalid puzzle format. Use: -p <year>/<day>")
        year, day = parsed

        # Find directory
        cwd = Path.cwd()
        parts = cwd.parts
        try:
            aoc_index = len(parts) - 1 - parts[::-1].index("aoc")
        except ValueError:
            raise click.ClickException("Not in an aoc directory")

        dir = Path(*parts[:aoc_index + 1]) / str(year) / str(day)
    else:
        detected = detect_puzzle()
        if not detected:
            raise click.ClickException(
                "Could not detect puzzle. Run from aoc/<year>/<day>/ or use -p <year>/<day>"
            )
        year = detected.year
        day = detected.day
        dir = detected.dir

    # Check server state
    try:
        status = check_submission(config.email, year, day)
    except APIError as e:
        raise click.ClickException(f"Server error: {e}")

    # Determine which part to submit
    if not status.exists or not status.part1_finished:
        part = 1
    elif not status.part2_finished:
        part = 2
    else:
        raise click.ClickException("Both parts already submitted for this puzzle")

    # Get answer
    if answer:
        final_answer = answer
    else:
        click.echo("Running solution...\n")
        try:
            result = run_solution(dir)
            lines = [l for l in result.output.split("\n") if l.strip()]
            last_line = lines[-1] if lines else ""

            # Parse as integer
            try:
                parsed_answer = int(last_line)
            except ValueError:
                raise click.ClickException(f"\nCould not parse answer from output: \"{last_line}\"")

            final_answer = str(parsed_answer)
            click.echo(f"\nParsed answer as: {final_answer}")
            click.echo("(This is the last line of output - please verify this is correct)")
            click.echo(f"Execution time: {format_duration(result.duration_ms)}")
        except click.ClickException:
            raise
        except Exception as e:
            raise click.ClickException(str(e))

    # Submit to AoC
    click.echo(f"Submitting {final_answer} for {year} day {day} part {part}...")
    result = submit_to_aoc(year, day, part, final_answer, config.session_token)

    if not result.correct:
        raise click.ClickException(f"❌ {result.message}")

    click.echo(f"✅ {result.message}")

    # Read solution code
    code = ""
    try:
        solution_files = list(dir.glob("solution.*"))
        if solution_files:
            code = solution_files[0].read_text()
    except Exception:
        pass

    # Report to server
    try:
        end_submission(config.email, year, day, part, code)
        click.echo("Reported to leaderboard server")
    except APIError as e:
        click.echo(f"Warning: Could not report to server: {e}", err=True)

    # If part 1, update test.txt with part 2 expected answer and open part 2
    if part == 1:
        # Update test.txt with part 2 expected answer
        test_path = dir / "test.txt"
        try:
            click.echo("Updating test.txt with part 2 expected answer...")
            html = fetch_problem_page(year, day, config.session_token)
            test_cases = extract_test_cases(html)
            if test_cases and test_cases[0].expected_output:
                if update_test_expected_answer(test_path, test_cases[0].expected_output):
                    click.echo(f"Updated expected answer to: {test_cases[0].expected_output}")
                    click.echo("Note: This was auto-parsed and may be incorrect. Please verify.")
                else:
                    click.echo("Could not update test.txt (file unchanged)")
            else:
                click.echo("Could not find part 2 expected answer in problem page")
        except Exception as e:
            click.echo(f"Warning: Could not update test.txt: {e}", err=True)

        url = f"https://adventofcode.com/{year}/day/{day}#part2"
        click.echo("Opening part 2...")
        webbrowser.open(url)
    else:
        # Part 2 complete - open the day page to show success
        url = f"https://adventofcode.com/{year}/day/{day}"
        click.echo("Opening puzzle page to celebrate your success!")
        webbrowser.open(url)
