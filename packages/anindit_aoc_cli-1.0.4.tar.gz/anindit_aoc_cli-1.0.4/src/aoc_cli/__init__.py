"""Advent of Code CLI with leaderboard integration."""

__version__ = "1.0.0"
