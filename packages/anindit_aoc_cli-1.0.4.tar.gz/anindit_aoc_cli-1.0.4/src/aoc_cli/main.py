"""Main CLI entry point."""

import click

from .commands.init import init
from .commands.get import get
from .commands.run import run
from .commands.test import test
from .commands.submit import submit


@click.group()
@click.version_option(version="1.0.0")
def cli():
    """Advent of Code CLI with leaderboard integration."""
    pass


cli.add_command(init)
cli.add_command(get)
cli.add_command(run)
cli.add_command(test)
cli.add_command(submit)


if __name__ == "__main__":
    cli()
