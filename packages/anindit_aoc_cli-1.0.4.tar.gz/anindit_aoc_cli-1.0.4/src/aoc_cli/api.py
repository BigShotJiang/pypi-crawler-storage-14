"""API client for the leaderboard server."""

import requests
from dataclasses import dataclass
from typing import Optional


SERVER_URL = "https://aocserver-production.up.railway.app"


@dataclass
class User:
    email: str
    display_name: str


@dataclass
class SubmissionStatus:
    exists: bool
    part1_started: Optional[bool] = None
    part1_finished: Optional[bool] = None
    part2_started: Optional[bool] = None
    part2_finished: Optional[bool] = None


class APIError(Exception):
    """Error from the API server."""
    pass


def _request(method: str, path: str, json_data: dict = None) -> dict:
    """Make a request to the API server."""
    url = f"{SERVER_URL}/api{path}"
    headers = {"Content-Type": "application/json"}

    try:
        response = requests.request(method, url, json=json_data, headers=headers)

        if not response.ok:
            try:
                error = response.json().get("error", response.reason)
            except Exception:
                error = response.reason
            raise APIError(error)

        return response.json()
    except requests.RequestException as e:
        raise APIError(str(e))


def create_user(email: str, display_name: str) -> User:
    """Register a new user with the server."""
    data = _request("POST", "/users", {"email": email, "display_name": display_name})
    return User(email=data["email"], display_name=data["display_name"])


def start_submission(email: str, year: int, day: int, part: int) -> None:
    """Record the start time for a submission."""
    _request("POST", "/submissions/start", {
        "email": email,
        "year": year,
        "day": day,
        "part": part,
    })


def end_submission(email: str, year: int, day: int, part: int, code: str) -> None:
    """Record the end time and code for a submission."""
    _request("POST", "/submissions/end", {
        "email": email,
        "year": year,
        "day": day,
        "part": part,
        "code": code,
    })


def check_submission(email: str, year: int, day: int) -> SubmissionStatus:
    """Check the status of submissions for a puzzle."""
    from urllib.parse import quote
    data = _request("GET", f"/submissions/check?email={quote(email)}&year={year}&day={day}")
    return SubmissionStatus(
        exists=data.get("exists", False),
        part1_started=data.get("part1_started"),
        part1_finished=data.get("part1_finished"),
        part2_started=data.get("part2_started"),
        part2_finished=data.get("part2_finished"),
    )
