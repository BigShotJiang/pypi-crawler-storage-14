# AOC CLI

Advent of Code CLI with leaderboard integration.

## Installation

```bash
cd packages/cli-py
pip install -e .
```

## Usage

### Initialize configuration

```bash
aoc init
```

You'll be prompted for:
- Email, display name, AoC session token
- Language (press Enter for Python, the only built-in template)

This creates:
- `~/.aocconfig` - Your configuration
- `aoc/templates/python.py` - Customizable solution template
- `aoc/<year>/` - Directory for your solutions

**Note:** Only Python is supported out of the box. For other languages, create your own template at `aoc/templates/<language>.<ext>`.

### Get puzzle input

```bash
aoc get 2024/1
```

This will:
- Download your puzzle input to `in.txt`
- Copy your template to `solution.*`
- Extract a test case to `test.txt` (auto-parsed—verify manually)
- Register start time with the server
- Open the puzzle in your browser

**Note:** Only one test case is extracted. The expected answer is auto-parsed and may be incorrect.

### Run solution with real input

```bash
aoc run
# or
aoc run -p 2024/1
```

### Run solution against test cases

```bash
aoc test
# or
aoc test -p 2024/1
```

The expected output shown is auto-parsed from the problem page—always verify it's correct.

### Submit answer

```bash
aoc submit
# or
aoc submit -a 12345
# or
aoc submit -p 2024/1 -a 12345
```

The answer is parsed from the last line of your solution's stdout. The CLI will show you what it parsed—verify it's correct before submission.

## Solution Requirements

Your solution must:
1. Read input from `in.txt`
2. Print the final answer as the **last line** to stdout
