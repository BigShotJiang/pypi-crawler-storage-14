"""actinia-cloudevent-plugin core part of package.

This part provides the core part of the actinia-cloudevent-plugin.
"""
