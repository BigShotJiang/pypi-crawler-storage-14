"""actinia-cloudevent-plugin resources part of package.

This part provides the Resources part of the actinia-cloudevent-plugin.
"""
