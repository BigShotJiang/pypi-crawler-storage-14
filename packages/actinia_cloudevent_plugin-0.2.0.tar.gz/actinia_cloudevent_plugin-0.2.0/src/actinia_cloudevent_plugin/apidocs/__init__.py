"""actinia-cloudevent-plugin API DOCs part of package.

This part provides the API DOCs part of the actinia-cloudevent-plugin.
"""
