"""actinia-cloudevent-plugin model part of package.

This part provides the model part of the actinia-cloudevent-plugin.
"""
