"""actinia-cloudevent-plugin API part of package.

This part provides the API part of the actinia-cloudevent-plugin.
"""
