import json
import time
import platform
import requests
from pathlib import Path
import subprocess
import re

headers = {"User-Agent": "XiaomiPCSuite"}


def extract_pass_token(response):

    if 'passToken' in response.cookies.get_dict():
        print('\ntoken was found in response')
        return response.cookies.get_dict()
    
    if response.history:
        for i in range(len(response.history)):
            if 'passToken' in response.history[i].cookies.get_dict():
                print(f'\ntoken was found in history: {i}')
                return response.history[i].cookies.get_dict()
    
    return {"error": "Failed to get pass token !!"}

def verification(notificationUrl, cookies, data):
    response = requests.get(notificationUrl, headers=headers, cookies=cookies)
    cookies.update(response.cookies.get_dict())

    resultJson = json.loads(
        re.search(r"resultJson=\$\.parseJSON\('(.+?)'\s*\.replace", response.text).group(1)
    )

    options = resultJson['options']

    if 8 in options and 4 in options:
        while True:
            print("\nChoose verification method:")
            print("1 = phone verification (CAPTCHA required)")
            print("2 = email verification")
            choice = input("Enter 1 or 2: ").strip()
            if choice == "1":
                method = "Phone"
                break
            elif choice == "2":
                method = "Email"
                break
            else:
                print("\nInvalid choice!\n")

    elif 4 in options:
        method = "Phone"
    elif 8 in options:
        method = "Email"
    else:
        return {"error": resultJson}

    base = "https://account.xiaomi.com"
    urlsv = base + "/identity/auth/"
    urlsend = urlsv + "send" + method + "Ticket"
    urlverify = urlsv + "verify" + method

    data_icode = {}

    while True:
        r2 = requests.post(urlsend, data=data_icode, cookies=cookies, headers=headers)
        r2_text = json.loads(r2.text[11:])

        if r2_text["code"] == 87001:
            print(r2_text["reason"])
            captchaUrl = r2_text["captchaUrl"]
            path = Path.home() / f"{int(time.time())}_captcha.jpg"

            rc = requests.get(f"{base}{captchaUrl}", cookies=cookies, headers=headers)
            cookies.update(rc.cookies.get_dict())

            with open(path, "wb") as f:
                f.write(rc.content)

            input('\nPress Enter to open the CAPTCHA image')

            if platform.system() == 'Windows':
                subprocess.run(['start', str(path)], shell=True)
            elif platform.system() == 'Darwin':
                subprocess.run(['open', str(path)])
            else:
                subprocess.run(['xdg-open', str(path)])

            print(f"\nCaptcha displayed from {path}")

            icode = input("\nEnter captcha code: ").strip()
            data_icode.update({'icode': icode})

            path.unlink()

        elif r2_text["code"] == 0:
            print(f"\nVerification code sent to your {method}")
            break

        else:
            if r2_text["code"] == 70022:
                return {"error": r2_text["tips"]}
            else:
                return {"error": r2_text}

    while True:
        ticket = input("Enter code: ").strip()
        r3 = requests.post(
            urlverify,
            data={'ticket': ticket, 'trust': 'true'},
            headers=headers,
            cookies=cookies
        )
        r3_text = json.loads(r3.text[11:])

        if r3_text["code"] == 70014:
            print(r3_text["tips"])
            continue
        elif r3_text["code"] == 0:
            break
        else:
            return {"error": r3_text}


    print('\nr3 r3_text:', r3_text)
    print('\nr3 history:', r3.history)

    if 'passToken' in r3.cookies.get_dict():
        print('\ntoken was found in r3.cookies')
        return r3.cookies.get_dict()

    if 'location' in r3_text:
        location = r3_text["location"]
        r4= requests.get(location, headers=headers, cookies=cookies)
        cookies = extract_pass_token(r4)
        if "error" in cookies:
            return cookies
            
    if 'passToken' not in cookies:
        print("\nresponse: ", response.text)
        return {"error": "Failed to get pass token !"}

    # response = requests.post("https://account.xiaomi.com/pass/serviceLoginAuth2", data=data, headers=headers, cookies=cookies)
    # cookies = response.cookies.get_dict()

