from .downloader import UnisonRepo

def fetch_dataset(id):
    """
    Descarga un dataset por ID y devuelve el nombre del archivo guardado.
    """
    client = UnisonRepo()
    return client.download_file(id)
