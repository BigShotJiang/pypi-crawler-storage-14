import requests
import re

class UnisonRepo:
    BASE_URL = "https://aevi.lat"

    def download_file(self, dataset_id):
        """
        Descarga un archivo desde la API usando solo el ID.
        Usa el nombre original del archivo que está en file_path.
        """
        url = f"{self.BASE_URL}/api/datasets/{dataset_id}/download"
        response = requests.get(url, stream=True)

        if response.status_code != 200:
            raise Exception(f"Error descargando archivo: {response.text}")

        # Obtener nombre del archivo desde el header Content-Disposition
        content_disposition = response.headers.get("Content-Disposition")
        output_filename = None
        if content_disposition:
            match = re.findall('filename="?(.+)"?', content_disposition)
            if match:
                output_filename = match[0]

        if output_filename is None:
            # fallback si no hay header
            output_filename = f"dataset_{dataset_id}"

        # Guardar archivo
        with open(output_filename, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        return output_filename
