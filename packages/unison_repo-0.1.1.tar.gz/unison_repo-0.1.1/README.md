# unison_repo

Librería simple para descargar datasets desde la API de AEVI usando únicamente el ID.

## Instalación

```bash
pip install unison_repo
