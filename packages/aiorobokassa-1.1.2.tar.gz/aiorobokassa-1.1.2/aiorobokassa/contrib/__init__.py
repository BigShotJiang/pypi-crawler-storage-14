"""Contrib extensions for aiorobokassa."""

__all__: list[str] = []
