"""DuckDB-powered pipeline_backend operations for checkpoints and branching."""

from __future__ import annotations

import json
import re
from typing import Any, Dict


def _payload_dict(data):
    """Sichert, dass wir ein dict als payload haben und gibt es zurück."""
    payload = getattr(data, "payload", None)
    if payload is None:
        payload = {}
        data.payload = payload
    if not isinstance(payload, dict):
        raise TypeError(f"Expected data.payload to be dict, got {type(payload)}")
    return payload


def _sanitize_identifier(value: Any) -> str:
    """Sanitize strings for use as DuckDB identifiers."""
    text = "" if value is None else str(value)
    sanitized = re.sub(r"[^A-Za-z0-9_]", "_", text)
    return sanitized or "table"


def duckdb_checkpoint_op(data: Any) -> None:
    """
    Speichert schwere Daten (z.B. values) in DuckDB und legt einen Pipeline-Checkpoint an.
    """
    payload = _payload_dict(data)
    run_id = payload.get("run_id")
    if not run_id:
        raise ValueError("duckdb_checkpoint_op requires payload['run_id']")

    step = payload.get("step", "C")
    duckdb_path = payload.get("duckdb_path", "work.duckdb")
    values = payload.get("values", [])
    sample_id = payload.get("sample_id", 0)

    try:
        values_list = list(values) if values is not None else []
    except Exception as exc:
        raise TypeError("payload['values'] must be iterable") from exc

    import duckdb
    import pandas as pd

    data_table = f"data_{_sanitize_identifier(run_id)}_{_sanitize_identifier(step)}"
    df = pd.DataFrame(
        {
            "idx": range(len(values_list)),
            "value": values_list,
            "sample_id": sample_id,
        }
    )

    con = duckdb.connect(duckdb_path)
    try:
        con.register("df", df)
        con.execute(f"CREATE TABLE IF NOT EXISTS {data_table} AS SELECT * FROM df LIMIT 0;")
        con.execute(f"INSERT INTO {data_table} SELECT * FROM df;")
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS pipeline_state (
                run_id       TEXT,
                step         TEXT,
                duckdb_path  TEXT,
                data_table   TEXT,
                payload_json TEXT
            );
            """
        )

        payload_copy: Dict[str, Any] = dict(payload)
        payload_copy.pop("values", None)
        con.execute(
            "INSERT INTO pipeline_state VALUES (?, ?, ?, ?, ?);",
            [run_id, step, duckdb_path, data_table, json.dumps(payload_copy)],
        )
    finally:
        con.close()

    payload["duckdb_path"] = duckdb_path
    payload["data_table"] = data_table
    payload.pop("values", None)
    data.payload = payload


def duckdb_resume_from_checkpoint_op(data: Any) -> None:
    """
    Restore a payload from a DuckDB checkpoint in pipeline_state.

    This version *merges* the stored checkpoint payload with the current
    payload so that branch-specific settings (e.g. SQL, out_table) from
    the caller are preserved.
    """
    payload = _payload_dict(data)

    run_id = payload.get("run_id")
    if not run_id:
        raise ValueError("duckdb_resume_from_checkpoint_op requires payload['run_id'].")

    step = payload.get("resume_from_step", "C")
    duckdb_path_cfg = payload.get("duckdb_path", "work.duckdb")

    import duckdb

    con = duckdb.connect(duckdb_path_cfg)

    row = con.execute(
        """
        SELECT duckdb_path, data_table, payload_json
        FROM pipeline_state
        WHERE run_id = ? AND step = ?
        LIMIT 1
        """,
        [run_id, step],
    ).fetchone()

    if row is None:
        raise RuntimeError(
            f"No checkpoint found in pipeline_state for run_id={run_id!r}, step={step!r}."
        )

    duckdb_path_db, data_table_db, payload_json = row

    restored_payload = {}
    if payload_json:
        try:
            restored_payload = json.loads(payload_json)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to decode checkpoint payload_json for run_id={run_id!r}, step={step!r}: {exc}"
            )

    merged = dict(restored_payload)

    for key, value in payload.items():
        if key in ("run_id", "resume_from_step"):
            continue
        merged[key] = value

    merged["duckdb_path"] = duckdb_path_db or duckdb_path_cfg
    merged["data_table"] = data_table_db
    merged["run_id"] = run_id
    merged["step"] = step

    merged.pop("resume_from_step", None)

    data.payload = merged


def duckdb_sql_op(data: Any) -> None:
    """
    Führt eine SQL-Transformation auf Basis der aktuellen DuckDB-Tabelle aus.
    """
    payload = _payload_dict(data)
    duckdb_path = payload.get("duckdb_path")
    data_table = payload.get("data_table")
    sql_template = payload.get("sql")
    out_table = payload.get("out_table")

    if not duckdb_path:
        raise ValueError("duckdb_sql_op requires payload['duckdb_path']")
    if not data_table:
        raise ValueError("duckdb_sql_op requires payload['data_table']")
    if not sql_template:
        raise ValueError("duckdb_sql_op requires payload['sql']")
    if not out_table:
        raise ValueError("duckdb_sql_op requires payload['out_table']")

    sql = str(sql_template).format(in_table=data_table, out_table=out_table)

    import duckdb

    con = duckdb.connect(duckdb_path)
    try:
        con.execute(sql)
    finally:
        con.close()

    payload["data_table"] = out_table
    data.payload = payload


def register_duckdb_ops() -> bool:
    """
    Registriert die DuckDB-Ops bei pipeline_backend, falls verfügbar.
    Gibt True zurück, wenn Registrierung erfolgreich war, sonst False.
    """
    try:
        import pipeline_backend as pb
    except ImportError:
        return False

    existing = {entry.get("name") for entry in pb.describe_ops()}

    ops = {
        "duckdb_checkpoint": duckdb_checkpoint_op,
        "duckdb_resume_from_checkpoint": duckdb_resume_from_checkpoint_op,
        "duckdb_sql": duckdb_sql_op,
    }

    for name, fn in ops.items():
        if name in existing:
            continue
        pb.register_py_op(name, fn)

    return True


try:
    register_duckdb_ops()
except Exception:
    # Silent fail, damit das Modul keinen Import-Error verursacht,
    # wenn pipeline_backend oder duckdb nicht installiert sind.
    pass
