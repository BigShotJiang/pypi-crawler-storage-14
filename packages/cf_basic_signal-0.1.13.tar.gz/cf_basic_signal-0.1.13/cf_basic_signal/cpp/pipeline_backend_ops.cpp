#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <vector>

#include "libdataproc_core.hpp"
#include "pipeline_backend_compat.hpp"

namespace py = pybind11;

// C API type exposed by pipeline_backend via PyCapsule.
using register_op_c_api_t = void (*)(const char *, pipeline::OpFn);

static std::vector<double> to_double_list(const py::handle &obj) {
    if (!obj || obj.is_none()) {
        return {};
    }
    try {
        return obj.cast<std::vector<double>>();
    } catch (const py::cast_error &) {
        // If it's a scalar, wrap it.
        try {
            return {obj.cast<double>()};
        } catch (const py::cast_error &) {
            return {};
        }
    }
}

static std::vector<double> values_from_payload(py::dict payload, std::initializer_list<const char *> keys) {
    for (auto key : keys) {
        if (payload.contains(key)) {
            return to_double_list(payload[key]);
        }
    }
    return {};
}

static int window_size_from_payload(py::dict payload) {
    try {
        if (payload.contains("windowSize")) {
            return std::max(0, py::cast<int>(payload["windowSize"]));
        }
        if (payload.contains("window_size")) {
            return std::max(0, py::cast<int>(payload["window_size"]));
        }
    } catch (const py::cast_error &) {
    }
    return 0;
}

static std::string fifo_id_from_payload(py::dict payload) {
    if (payload.contains("fifoId")) {
        return py::cast<std::string>(payload["fifoId"]);
    }
    return "default";
}

static std::string average_mode_from_payload(py::dict payload) {
    if (payload.contains("averageMethod")) {
        return py::cast<std::string>(payload["averageMethod"]);
    }
    if (payload.contains("mode")) {
        return py::cast<std::string>(payload["mode"]);
    }
    return "arithmetic";
}

// ---------------------------------------------------------------------------
// C++ pipeline operations
// ---------------------------------------------------------------------------

static void fifo_window_buffer_op(pipeline::Data &data) {
    py::dict payload = data.payload;
    const auto values = values_from_payload(payload, {"sampleChunk", "values", "data"});
    const auto window_size = window_size_from_payload(payload);
    const auto fifo_id = fifo_id_from_payload(payload);

    const auto window = cf_basic_signal::fifo_window_buffer(values, static_cast<std::size_t>(window_size), fifo_id);
    payload["window"] = window;
}

static void average_op(pipeline::Data &data) {
    py::dict payload = data.payload;
    auto values = values_from_payload(payload, {"window", "values"});
    if (values.empty() && payload.contains("data")) {
        values = to_double_list(payload["data"]);
    }
    const auto mode = average_mode_from_payload(payload);

    const auto res = cf_basic_signal::average(values, mode, nullptr);
    py::dict stats;
    stats["mean"] = res.mean;
    stats["se"] = res.standard_error;
    stats["standardError"] = res.standard_error;

    payload["stats"] = stats;
    payload["mean"] = res.mean;
    payload["se"] = res.standard_error;
    payload["standardError"] = res.standard_error;
}

static std::string handle_uri_from_payload(py::dict payload) {
    if (payload.contains("handleUri")) {
        return py::cast<std::string>(payload["handleUri"]);
    }
    if (payload.contains("handle")) {
        return py::cast<std::string>(payload["handle"]);
    }
    if (payload.contains("csvPath")) {
        return std::string("csv://") + py::cast<std::string>(payload["csvPath"]);
    }
    return {};
}

static py::dict row_from_payload(py::dict payload) {
    if (payload.contains("data")) {
        try {
            return py::cast<py::dict>(payload["data"]);
        } catch (const py::cast_error &) {
            // fall through
        }
    }
    if (payload.contains("stats")) {
        try {
            return py::cast<py::dict>(payload["stats"]);
        } catch (const py::cast_error &) {
            // fall through
        }
    }

    py::dict row;
    if (payload.contains("data")) {
        row["value"] = payload["data"];
    } else if (payload.contains("mean")) {
        row["mean"] = payload["mean"];
        if (payload.contains("se")) {
            row["se"] = payload["se"];
        }
    }
    return row;
}

static void csv_sink_op(pipeline::Data &data) {
    py::dict payload = data.payload;
    const auto handle_uri = handle_uri_from_payload(payload);
    if (handle_uri.rfind("csv://", 0) != 0) {
        payload["status"] = py::str("handled via ") + py::str(handle_uri);
        return;
    }

    const std::filesystem::path target(handle_uri.substr(6));  // strip csv://
    const auto row = row_from_payload(payload);
    if (row.empty()) {
        payload["status"] = py::str("handled via ") + py::str(handle_uri);
        return;
    }

    std::error_code ec;
    std::filesystem::create_directories(target.parent_path(), ec);

    const bool need_header = !std::filesystem::exists(target) || std::filesystem::file_size(target) == 0;

    std::ofstream out(target, std::ios::out | std::ios::app);
    if (!out.is_open()) {
        throw std::runtime_error("csv_sink_op: failed to open file: " + target.string());
    }

    std::vector<std::string> keys;
    keys.reserve(row.size());
    for (auto item : row) {
        keys.push_back(py::cast<std::string>(item.first));
    }

    if (need_header) {
        for (std::size_t i = 0; i < keys.size(); ++i) {
            if (i) out << ",";
            out << keys[i];
        }
        out << "\n";
    }

    for (std::size_t i = 0; i < keys.size(); ++i) {
        if (i) out << ",";
        // Cast via py::str to handle non-string values gracefully.
        out << py::str(row[keys[i].c_str()]).cast<std::string>();
    }
    out << "\n";
    out.close();

    payload["status"] = py::str("handled via ") + py::str(handle_uri);
}

// ---------------------------------------------------------------------------
// Registration with pipeline_backend via PyCapsule
// ---------------------------------------------------------------------------

static void register_with_backend() {
    py::object backend = py::module_::import("pipeline_backend");
    py::object capsule = backend.attr("_register_op_capsule");

    auto reg_fn = reinterpret_cast<register_op_c_api_t>(
        PyCapsule_GetPointer(capsule.ptr(), "pipeline_backend.register_op_v1"));
    if (!reg_fn) {
        throw std::runtime_error("Failed to obtain register_op_c_api from pipeline_backend capsule");
    }

    reg_fn("fifo_window_buffer", &fifo_window_buffer_op);
    reg_fn("average", &average_op);
    reg_fn("csv_sink", &csv_sink_op);
}

PYBIND11_MODULE(_pipeline_backend_ops, m) {
    m.doc() = "C++ pipeline_backend ops for cf_basic_signal (register_cpp_op via capsule)";

    // Register C++ ops with the backend on import.
    register_with_backend();
}
