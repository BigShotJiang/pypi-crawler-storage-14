#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <stdexcept>
#include <string>
#include <vector>
#include <regex>

#include "pipeline_backend_compat.hpp"

// DuckDB C++ API
#include <duckdb.hpp>

namespace py = pybind11;
using namespace duckdb;

// C API type exposed by pipeline_backend via PyCapsule.
using register_op_c_api_t = void (*)(const char *, pipeline::OpFn);

// ---------------------------------------------------------------------
// kleine Helfer
// ---------------------------------------------------------------------

static std::string sanitize_identifier(const std::string &value) {
    static const std::regex re("[^A-Za-z0-9_]");
    std::string out = std::regex_replace(value, re, "_");
    if (out.empty()) {
        out = "table";
    }
    return out;
}

static std::string get_str_or(py::dict payload, const char *key, const std::string &fallback) {
    if (payload.contains(key)) {
        return py::cast<std::string>(payload[key]);
    }
    return fallback;
}

static std::vector<double> to_double_list(const py::handle &obj) {
    if (!obj || obj.is_none()) {
        return {};
    }
    try {
        return py::cast<std::vector<double>>(obj);
    } catch (const std::exception &e) {
        throw std::runtime_error(std::string("duckdb_checkpoint_cpp: payload['values'] must be a sequence of floats: ") + e.what());
    }
}

// ---------------------------------------------------------------------
// C++ DuckDB Ops
// ---------------------------------------------------------------------

// C++-Variante von duckdb_checkpoint_op(data)
static void duckdb_checkpoint_cpp(pipeline::Data &data) {
    py::dict payload = data.payload;

    if (!payload.contains("run_id")) {
        throw std::runtime_error("duckdb_checkpoint_cpp requires payload['run_id']");
    }
    std::string run_id = py::cast<std::string>(payload["run_id"]);

    std::string step = get_str_or(payload, "step", "C");
    std::string duckdb_path = get_str_or(payload, "duckdb_path", "work.duckdb");

    std::vector<double> values = to_double_list(payload.contains("values") ? payload["values"] : py::none());
    int64_t sample_id = 0;
    if (payload.contains("sample_id")) {
        sample_id = py::cast<int64_t>(payload["sample_id"]);
    }

    std::string data_table = "data_" + sanitize_identifier(run_id) + "_" + sanitize_identifier(step);

    // DuckDB DB + Connection
    DuckDB db(duckdb_path);
    Connection con(db);

    // Tabelle für Werte
    con.Query("CREATE TABLE IF NOT EXISTS " + data_table +
              " (idx BIGINT, value DOUBLE, sample_id BIGINT);");

    // Effizienter Bulk-Insert via Appender
    {
        Appender appender(con, data_table);
        for (idx_t i = 0; i < values.size(); ++i) {
            appender.BeginRow();
            appender.Append<int64_t>(static_cast<int64_t>(i));
            appender.Append<double>(values[i]);
            appender.Append<int64_t>(sample_id);
            appender.EndRow();
        }
        appender.Close();
    }

    // pipeline_state Tabelle wie im Python-Plugin
    con.Query(
        "CREATE TABLE IF NOT EXISTS pipeline_state ("
        "  run_id       TEXT,"
        "  step         TEXT,"
        "  duckdb_path  TEXT,"
        "  data_table   TEXT,"
        "  payload_json TEXT"
        ");"
    );

    // Payload-Kopie ohne 'values' als JSON (Python kümmert sich weiterhin um das JSON selbst)
    py::dict payload_copy = py::dict(payload);
    if (payload_copy.contains("values")) {
        payload_copy.attr("pop")("values", py::none());
    }

    py::object json_mod = py::module_::import("json");
    py::object dumps = json_mod.attr("dumps");
    py::object payload_json_obj = dumps(payload_copy);
    std::string payload_json = py::cast<std::string>(payload_json_obj);

    // Eintrag in pipeline_state hinzufügen
    {
        auto stmt = con.Prepare(
            "INSERT INTO pipeline_state (run_id, step, duckdb_path, data_table, payload_json) "
            "VALUES (?, ?, ?, ?, ?);"
        );
        stmt->Execute(run_id, step, duckdb_path, data_table, payload_json);
    }

    // Payload im Data-Objekt aktualisieren
    payload["duckdb_path"] = py::cast(duckdb_path);
    payload["data_table"] = py::cast(data_table);
    if (payload.contains("values")) {
        payload.attr("pop")("values", py::none());
    }
    data.payload = payload;
}

// C++-Variante von duckdb_sql_op(data)
static void duckdb_sql_cpp(pipeline::Data &data) {
    py::dict payload = data.payload;

    if (!payload.contains("duckdb_path")) {
        throw std::runtime_error("duckdb_sql_cpp requires payload['duckdb_path']");
    }
    if (!payload.contains("data_table")) {
        throw std::runtime_error("duckdb_sql_cpp requires payload['data_table']");
    }
    if (!payload.contains("sql")) {
        throw std::runtime_error("duckdb_sql_cpp requires payload['sql']");
    }
    if (!payload.contains("out_table")) {
        throw std::runtime_error("duckdb_sql_cpp requires payload['out_table']");
    }

    std::string duckdb_path = py::cast<std::string>(payload["duckdb_path"]);
    std::string in_table    = py::cast<std::string>(payload["data_table"]);
    std::string sql_tmpl    = py::cast<std::string>(payload["sql"]);
    std::string out_table   = py::cast<std::string>(payload["out_table"]);

    // Primitive Placeholder-Ersetzung: {in_table}, {out_table}
    std::string sql = sql_tmpl;
    auto replace_all = [](std::string &s, const std::string &from, const std::string &to) {
        if (from.empty()) return;
        size_t pos = 0;
        while ((pos = s.find(from, pos)) != std::string::npos) {
            s.replace(pos, from.length(), to);
            pos += to.length();
        }
    };
    replace_all(sql, "{in_table}", in_table);
    replace_all(sql, "{out_table}", out_table);

    DuckDB db(duckdb_path);
    Connection con(db);
    auto res = con.Query(sql);
    if (res->HasError()) {
        throw std::runtime_error("duckdb_sql_cpp failed: " + res->GetError());
    }

    // Output-Tabelle als neuen data_table setzen
    payload["data_table"] = py::cast(out_table);
    data.payload = payload;
}

// ---------------------------------------------------------------------
// Registrierung bei pipeline_backend
// ---------------------------------------------------------------------

static void register_with_backend() {
    py::gil_scoped_acquire gil;
    py::object backend = py::module_::import("pipeline_backend");
    py::object capsule = backend.attr("_register_op_capsule");

    auto reg_fn = reinterpret_cast<register_op_c_api_t>(
        PyCapsule_GetPointer(capsule.ptr(), "pipeline_backend.register_op_v1"));
    if (!reg_fn) {
        throw std::runtime_error("Failed to obtain register_op_c_api from pipeline_backend capsule");
    }

    reg_fn("duckdb_checkpoint_cpp", &duckdb_checkpoint_cpp);
    reg_fn("duckdb_sql_cpp", &duckdb_sql_cpp);
}

PYBIND11_MODULE(_duckdb_backend_ops, m) {
    m.doc() = "C++ DuckDB ops for cf_basic_signal (register_cpp_op via capsule)";
    register_with_backend();
}
