# py-naija-utils

A lightweight utility toolkit for Nigerian-specific tasks:
- Format phone numbers
- Validate NIN
- Format currency (₦)
- Date helpers

## Usage

```python
from py_naija_utils import format_phone, format_currency

print(format_phone("0803 123 4567"))
print(format_currency(15000))