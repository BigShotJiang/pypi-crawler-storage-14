def format_naira(amount: float) -> str:
    """Format a numeric amount as a Naira currency string.

    Examples:
        1000 -> '₦1,000.00'
        -3500.5 -> '-₦3,500.50'

    Args:
        amount: A number (int or float) representing the amount.

    Returns:
        A string with the Naira symbol, thousands separators and two decimals.

    Raises:
        ValueError: If `amount` is not coercible to a number.
    """
    try:
        value = float(amount)
    except (TypeError, ValueError):
        raise ValueError("amount must be a number") from None

    sign = "-" if value < 0 else ""
    formatted = f"{abs(value):,.2f}"
    # Place the sign before the currency symbol for negative values
    return f"{sign}₦{formatted}"
