import re
def format_phone(phone_number: str) -> str:
    '''Format phone number in XXXX-XXX-XXXX format.'''
    if len(phone_number) == 11 and phone_number.isdigit():
        formatted = re.sub(r'(\d{4})(\d{3})(\d{4})', r'\1-\2-\3', phone_number)
    else:
        raise ValueError('Phone number must be number and 11 digits')
    return formatted