from datetime import date


def get_naija_date() -> str:
    """Return today's date in DD/MM/YYYY format.

    Returns:
        A string with the current date in the format DD/MM/YYYY.
    """
    today = date.today()
    return today.strftime("%d/%m/%Y")