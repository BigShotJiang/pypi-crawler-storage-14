def validate_nin(nin: str) -> bool:
    '''Validate Nigerian National Identification Number (NIN).'''
    return len(nin) == 11 and nin.isdigit()