"""Test fixtures and test doubles for pytest-test-categories testing."""

from __future__ import annotations
