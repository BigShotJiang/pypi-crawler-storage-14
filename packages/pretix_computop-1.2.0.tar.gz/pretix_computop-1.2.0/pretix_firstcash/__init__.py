from pretix_computop import __version__  # noqa
