from pretix_computop.urls import get_event_patterns

event_patterns = get_event_patterns("firstcash")
