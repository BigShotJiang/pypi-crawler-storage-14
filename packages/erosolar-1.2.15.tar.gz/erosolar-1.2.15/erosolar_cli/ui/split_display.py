"""
Split-screen display with persistent input container.

This module provides a terminal UI with:
- Scrollable output area at the top
- Fixed input prompt pinned at the bottom
- Output cannot be interrupted by user typing
"""

from __future__ import annotations

import asyncio
import sys
import os
from dataclasses import dataclass
from typing import Callable, Optional, List, Any
from threading import Lock

from prompt_toolkit import Application
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.document import Document
from prompt_toolkit.filters import Condition
from prompt_toolkit.formatted_text import HTML, FormattedText, merge_formatted_text
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import (
    ConditionalContainer,
    Container,
    Dimension,
    Float,
    FloatContainer,
    FormattedTextControl,
    HSplit,
    Layout,
    ScrollablePane,
    VSplit,
    Window,
    WindowAlign,
)
from prompt_toolkit.layout.controls import BufferControl
from prompt_toolkit.layout.margins import ScrollbarMargin
from prompt_toolkit.styles import Style
from prompt_toolkit.widgets import Frame, TextArea

from rich.console import Console
from rich.text import Text


@dataclass
class OutputLine:
    """A line of output with optional styling."""
    text: str
    style: str = ""
    is_spinner: bool = False


class SplitScreenDisplay:
    """
    Split-screen terminal display with persistent input at bottom.

    Layout:
    ┌─────────────────────────────────┐
    │  Output Area (scrollable)       │
    │  - Assistant messages           │
    │  - Tool calls and results       │
    │  - System messages              │
    │                                 │
    ├─────────────────────────────────┤
    │  Status Bar (optional)          │
    ├─────────────────────────────────┤
    │ > Input prompt (fixed)          │
    └─────────────────────────────────┘
    """

    def __init__(self):
        """Initialize split-screen display."""
        self._output_lines: List[OutputLine] = []
        self._output_lock = Lock()
        self._status_text = ""
        self._is_processing = False
        self._spinner_frame = 0
        self._spinner_chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        self._app: Optional[Application] = None
        self._input_buffer: Optional[Buffer] = None
        self._on_input_callback: Optional[Callable[[str], None]] = None
        self._running = False
        self._input_ready = asyncio.Event()
        self._last_input = ""

        # Style configuration
        self._style = Style.from_dict({
            "output-area": "bg:#1a1a2e",
            "status-bar": "bg:#16213e fg:#e94560",
            "input-area": "bg:#0f0f23",
            "prompt": "#00ff00 bold",
            "spinner": "#00ffff",
            "success": "#00ff00",
            "error": "#ff0000",
            "warning": "#ffff00",
            "info": "#00ffff",
            "tool-call": "#ff00ff",
            "tool-result": "#00ff00",
        })

        # Terminal dimensions
        self._width = self._get_terminal_width()
        self._height = self._get_terminal_height()

    def _get_terminal_width(self) -> int:
        """Get terminal width."""
        try:
            return os.get_terminal_size().columns
        except OSError:
            return 80

    def _get_terminal_height(self) -> int:
        """Get terminal height."""
        try:
            return os.get_terminal_size().lines
        except OSError:
            return 24

    def _create_output_control(self) -> FormattedTextControl:
        """Create the output area control."""
        def get_output_text() -> FormattedText:
            with self._output_lock:
                fragments = []
                for line in self._output_lines:
                    if line.is_spinner:
                        # Render spinner with current frame
                        spinner_char = self._spinner_chars[self._spinner_frame % len(self._spinner_chars)]
                        fragments.append(("class:spinner", f"{spinner_char} "))
                        fragments.append(("", line.text))
                    elif line.style:
                        fragments.append((f"class:{line.style}", line.text))
                    else:
                        fragments.append(("", line.text))
                    fragments.append(("", "\n"))
                return FormattedText(fragments)

        return FormattedTextControl(get_output_text)

    def _create_status_control(self) -> FormattedTextControl:
        """Create the status bar control."""
        def get_status_text() -> FormattedText:
            if self._is_processing:
                spinner = self._spinner_chars[self._spinner_frame % len(self._spinner_chars)]
                return FormattedText([
                    ("class:spinner", f" {spinner} "),
                    ("class:status-bar", self._status_text or "Processing..."),
                ])
            elif self._status_text:
                return FormattedText([("class:status-bar", f" {self._status_text}")])
            return FormattedText([("class:status-bar", "")])

        return FormattedTextControl(get_status_text)

    def _create_layout(self) -> Layout:
        """Create the split-screen layout."""
        # Output area - scrollable
        output_control = self._create_output_control()
        output_window = Window(
            content=output_control,
            wrap_lines=True,
            right_margins=[ScrollbarMargin(display_arrows=True)],
        )

        # Scrollable pane for output
        output_pane = ScrollablePane(output_window)

        # Status bar - fixed height
        status_control = self._create_status_control()
        status_window = Window(
            content=status_control,
            height=1,
            style="class:status-bar",
        )

        # Input buffer
        self._input_buffer = Buffer(
            multiline=False,
            accept_handler=self._handle_input_accept,
        )

        # Input area - fixed at bottom
        input_window = Window(
            content=BufferControl(buffer=self._input_buffer),
            height=1,
            style="class:input-area",
        )

        # Prompt indicator
        prompt_window = Window(
            content=FormattedTextControl(lambda: [("class:prompt", "> ")]),
            width=2,
            style="class:input-area",
        )

        # Input row with prompt
        input_row = VSplit([prompt_window, input_window])

        # Status bar visibility condition
        @Condition
        def show_status():
            return bool(self._status_text) or self._is_processing

        # Main layout
        root = HSplit([
            # Output area takes remaining space
            output_pane,
            # Separator
            Window(height=1, char="─", style="class:status-bar"),
            # Status bar (conditional)
            ConditionalContainer(
                content=status_window,
                filter=show_status,
            ),
            # Input area at bottom
            input_row,
        ])

        return Layout(root, focused_element=input_window)

    def _handle_input_accept(self, buffer: Buffer) -> bool:
        """Handle when user presses Enter."""
        self._last_input = buffer.text
        buffer.reset()
        self._input_ready.set()
        return True  # Keep buffer

    def _create_keybindings(self) -> KeyBindings:
        """Create key bindings."""
        kb = KeyBindings()

        @kb.add("c-c")
        def handle_ctrl_c(event):
            """Handle Ctrl+C."""
            self._last_input = ""
            self._input_ready.set()

        @kb.add("c-d")
        def handle_ctrl_d(event):
            """Handle Ctrl+D (EOF)."""
            self._running = False
            self._input_ready.set()
            event.app.exit()

        return kb

    async def _spinner_task(self):
        """Update spinner animation."""
        while self._running:
            if self._is_processing and self._app:
                self._spinner_frame = (self._spinner_frame + 1) % len(self._spinner_chars)
                self._app.invalidate()
            await asyncio.sleep(0.1)

    def append_output(self, text: str, style: str = "", is_spinner: bool = False) -> None:
        """
        Append text to output area.

        Args:
            text: Text to append
            style: CSS-like style class
            is_spinner: Whether this is a spinner line (will be animated)
        """
        with self._output_lock:
            # Remove previous spinner lines if adding new content
            if not is_spinner:
                self._output_lines = [l for l in self._output_lines if not l.is_spinner]

            for line in text.split("\n"):
                self._output_lines.append(OutputLine(text=line, style=style, is_spinner=is_spinner))

        if self._app:
            self._app.invalidate()

    def clear_spinners(self) -> None:
        """Remove all spinner lines from output."""
        with self._output_lock:
            self._output_lines = [l for l in self._output_lines if not l.is_spinner]
        if self._app:
            self._app.invalidate()

    def set_status(self, text: str) -> None:
        """Set status bar text."""
        self._status_text = text
        if self._app:
            self._app.invalidate()

    def set_processing(self, is_processing: bool, message: str = "") -> None:
        """Set processing state with optional message."""
        self._is_processing = is_processing
        if message:
            self._status_text = message
        elif not is_processing:
            self._status_text = ""
        if self._app:
            self._app.invalidate()

    def clear_output(self) -> None:
        """Clear all output."""
        with self._output_lock:
            self._output_lines.clear()
        if self._app:
            self._app.invalidate()

    async def get_input(self) -> str:
        """
        Wait for user input.

        Returns:
            User input string, or empty string if cancelled
        """
        self._input_ready.clear()
        await self._input_ready.wait()
        return self._last_input

    async def run(self, on_input: Callable[[str], Any]) -> None:
        """
        Run the split-screen display.

        Args:
            on_input: Async callback for handling user input
        """
        self._running = True
        self._on_input_callback = on_input

        # Create application
        self._app = Application(
            layout=self._create_layout(),
            key_bindings=self._create_keybindings(),
            style=self._style,
            full_screen=True,
            mouse_support=True,
        )

        # Start spinner task
        spinner_task = asyncio.create_task(self._spinner_task())

        try:
            # Run the application
            await self._app.run_async()
        finally:
            self._running = False
            spinner_task.cancel()
            try:
                await spinner_task
            except asyncio.CancelledError:
                pass

    def exit(self) -> None:
        """Exit the display."""
        self._running = False
        if self._app:
            self._app.exit()


class SplitDisplayAdapter:
    """
    Adapter that provides the same interface as Display class
    but outputs to a SplitScreenDisplay.
    """

    def __init__(self, split_display: SplitScreenDisplay):
        """Initialize adapter."""
        self._display = split_display
        self._icons = {
            "action": "⏺",
            "sub_action": "⎿",
            "info": "ℹ",
            "warning": "⚠",
            "error": "✗",
            "success": "✓",
            "progress": "✽",
            "thinking": "…",
            "sparkle": "✦",
            "folder": "📂",
            "chip": "⚙",
            "version": "◎",
        }

    def show_welcome(
        self,
        profile_label: str,
        profile_name: str,
        model: str,
        provider: str,
        working_dir: str,
        version: Optional[str] = None,
    ) -> None:
        """Display welcome banner."""
        self._display.append_output(f"{self._icons['sparkle']} Profile: {profile_label} ({profile_name})")
        self._display.append_output(f"{self._icons['chip']} Model: {model} via {provider}")
        self._display.append_output(f"{self._icons['folder']} Workspace: {working_dir}")
        if version:
            self._display.append_output(f"{self._icons['version']} Version: {version}")
        self._display.append_output("─" * 60)
        self._display.append_output("")

    def show_thinking(self, message: str = "Thinking...") -> None:
        """Show thinking indicator."""
        self._display.set_processing(True, message)
        self._display.append_output(message, style="spinner", is_spinner=True)

    def update_thinking(self, message: str) -> None:
        """Update thinking message."""
        self._display.set_processing(True, message)

    def stop_thinking(self) -> None:
        """Stop thinking indicator."""
        self._display.set_processing(False)
        self._display.clear_spinners()

    def show_assistant_message(self, content: str, metadata: Any = None) -> None:
        """Show assistant message."""
        self._display.append_output(content)
        self._display.append_output("")

    def show_info(self, message: str) -> None:
        """Show info message."""
        self._display.append_output(message, style="info")

    def show_warning(self, message: str) -> None:
        """Show warning message."""
        self._display.append_output(f"{self._icons['warning']} {message}", style="warning")

    def show_error(self, message: str) -> None:
        """Show error message."""
        self._display.append_output(f"{self._icons['error']} {message}", style="error")

    def show_tool_call(self, tool_name: str, args: dict, truncate: bool = True) -> None:
        """Show tool call."""
        arg_parts = []
        for key, value in list(args.items())[:3]:
            value_str = str(value)
            if truncate and len(value_str) > 50:
                value_str = value_str[:47] + "..."
            arg_parts.append(f"{key}={value_str!r}")
        args_text = ", ".join(arg_parts)
        if len(args) > 3:
            args_text += ", ..."

        self._display.append_output(f"{self._icons['action']} {tool_name}({args_text})", style="tool-call")

    def show_tool_result(self, tool_name: str, result: str, success: bool = True) -> None:
        """Show tool result."""
        style = "success" if success else "error"
        icon = self._icons["success"] if success else self._icons["error"]

        lines = result.split("\n")[:10]  # Limit to 10 lines
        if len(result.split("\n")) > 10:
            lines.append(f"... (+{len(result.split(chr(10))) - 10} more lines)")

        for i, line in enumerate(lines):
            prefix = f"  {icon} " if i == 0 else "    "
            self._display.append_output(f"{prefix}{line}", style=style)

    def new_line(self) -> None:
        """Print blank line."""
        self._display.append_output("")

    def clear(self) -> None:
        """Clear output."""
        self._display.clear_output()


# Create singleton for easy import
_split_display: Optional[SplitScreenDisplay] = None
_split_adapter: Optional[SplitDisplayAdapter] = None


def get_split_display() -> SplitScreenDisplay:
    """Get or create the split display singleton."""
    global _split_display
    if _split_display is None:
        _split_display = SplitScreenDisplay()
    return _split_display


def get_split_adapter() -> SplitDisplayAdapter:
    """Get or create the split adapter singleton."""
    global _split_adapter, _split_display
    if _split_adapter is None:
        _split_adapter = SplitDisplayAdapter(get_split_display())
    return _split_adapter
