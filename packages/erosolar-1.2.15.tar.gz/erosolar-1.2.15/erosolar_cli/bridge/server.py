"""
Bridge Server for Cross-Language Tool Execution

Handles IPC communication from TypeScript runtime and executes
Python tools on demand.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

import json
import sys
import time
import os
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, asdict

from ..core.unified_tool_runtime import (
    UnifiedToolRuntime,
    UnifiedToolRuntimeConfig,
    UnifiedToolDefinition,
    ToolExecutionContext,
    ToolExecutionResult,
    register_core_tools,
    CORE_TOOL_HANDLERS,
)
from ..core.unified_provider import get_tools


# ============================================================================
# Message Types
# ============================================================================

@dataclass
class BridgeMessage:
    """Bridge message format."""
    id: str
    type: str
    payload: Any
    timestamp: float


@dataclass
class ToolExecutionRequest:
    """Tool execution request."""
    tool_id: str
    args: Dict[str, Any]
    context: Dict[str, Any]


@dataclass
class RemoteToolDefinition:
    """Remote tool definition for TypeScript."""
    id: str
    name: str
    description: str
    category: str
    cacheable: bool
    requires_auth: bool
    parameters: Dict[str, Any]
    runtime: str = "python"


# ============================================================================
# Bridge Server
# ============================================================================

class BridgeServer:
    """Server that handles tool execution requests from TypeScript."""

    def __init__(self, working_dir: str):
        self.working_dir = working_dir
        self.runtime = UnifiedToolRuntime(
            UnifiedToolRuntimeConfig(
                working_dir=working_dir,
                enable_caching=True,
            )
        )
        self._register_tools()

    def _register_tools(self) -> None:
        """Register all available tools."""
        register_core_tools(self.runtime)

        # Register additional plugin tools
        try:
            from ..plugins import registry, load_builtin_plugins
            load_builtin_plugins()
            # Note: Plugin tools would be registered here
        except ImportError:
            pass

    def handle_message(self, message: BridgeMessage) -> BridgeMessage:
        """Handle an incoming message."""
        try:
            if message.type == "execute_tool":
                return self._handle_execute_tool(message)
            elif message.type == "list_tools":
                return self._handle_list_tools(message)
            elif message.type == "heartbeat":
                return self._handle_heartbeat(message)
            else:
                return self._error_response(message.id, f"Unknown message type: {message.type}")
        except Exception as e:
            return self._error_response(message.id, str(e))

    def _handle_execute_tool(self, message: BridgeMessage) -> BridgeMessage:
        """Handle tool execution request."""
        payload = message.payload
        request = ToolExecutionRequest(
            tool_id=payload.get("toolId", ""),
            args=payload.get("args", {}),
            context=payload.get("context", {}),
        )

        result = self.runtime.execute(request.tool_id, request.args)

        return BridgeMessage(
            id=message.id,
            type="tool_result",
            payload={
                "success": result.success,
                "toolId": result.tool_id,
                "toolName": result.tool_name,
                "result": result.result,
                "error": result.error,
                "cached": result.cached,
                "durationMs": result.duration_ms,
            },
            timestamp=time.time(),
        )

    def _handle_list_tools(self, message: BridgeMessage) -> BridgeMessage:
        """Handle list tools request."""
        tools = []
        for tool in self.runtime.list_tools():
            tools.append({
                "id": tool.id,
                "name": tool.name,
                "description": tool.description,
                "category": tool.category,
                "cacheable": tool.cacheable,
                "requiresAuth": tool.requires_auth,
                "parameters": tool.parameters,
                "runtime": "python",
            })

        return BridgeMessage(
            id=message.id,
            type="list_tools",
            payload=tools,
            timestamp=time.time(),
        )

    def _handle_heartbeat(self, message: BridgeMessage) -> BridgeMessage:
        """Handle heartbeat request."""
        return BridgeMessage(
            id=message.id,
            type="heartbeat",
            payload={"status": "ok", "timestamp": time.time()},
            timestamp=time.time(),
        )

    def _error_response(self, message_id: str, error: str) -> BridgeMessage:
        """Create an error response."""
        return BridgeMessage(
            id=message_id,
            type="error",
            payload=error,
            timestamp=time.time(),
        )

    def run(self) -> None:
        """Run the server, reading from stdin and writing to stdout."""
        # Send initial heartbeat to signal ready
        ready_message = BridgeMessage(
            id="init",
            type="heartbeat",
            payload={"status": "ready"},
            timestamp=time.time(),
        )
        self._send_message(ready_message)

        # Process messages
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                data = json.loads(line)
                message = BridgeMessage(
                    id=data.get("id", ""),
                    type=data.get("type", ""),
                    payload=data.get("payload"),
                    timestamp=data.get("timestamp", time.time()),
                )

                response = self.handle_message(message)
                self._send_message(response)
            except json.JSONDecodeError as e:
                error_response = self._error_response("parse_error", f"Invalid JSON: {e}")
                self._send_message(error_response)
            except Exception as e:
                error_response = self._error_response("error", str(e))
                self._send_message(error_response)

    def _send_message(self, message: BridgeMessage) -> None:
        """Send a message to stdout."""
        data = {
            "id": message.id,
            "type": message.type,
            "payload": message.payload,
            "timestamp": message.timestamp,
        }
        print(json.dumps(data), flush=True)


# ============================================================================
# Entry Point
# ============================================================================

def start_bridge_server(working_dir: Optional[str] = None) -> None:
    """Start the bridge server."""
    if working_dir is None:
        working_dir = os.getcwd()

    server = BridgeServer(working_dir)
    server.run()


def main() -> None:
    """Main entry point for the bridge server."""
    import argparse

    parser = argparse.ArgumentParser(description="Tool Bridge Server")
    parser.add_argument(
        "--working-dir",
        "-w",
        default=os.getcwd(),
        help="Working directory for tool execution",
    )
    args = parser.parse_args()

    start_bridge_server(args.working_dir)


if __name__ == "__main__":
    main()
