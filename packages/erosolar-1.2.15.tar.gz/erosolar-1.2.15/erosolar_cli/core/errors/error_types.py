"""
Structured error types for better error handling and reporting.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class StructuredError:
    """Base class for structured errors."""

    code: str
    message: str
    details: Optional[dict[str, str]] = None
    suggestion: Optional[str] = None

    def to_display_string(self) -> str:
        """Format error for display to user."""
        lines = [f"Error [{self.code}]: {self.message}"]

        if self.details:
            lines.append("\nDetails:")
            for key, value in self.details.items():
                lines.append(f"  {key}: {value}")

        if self.suggestion:
            lines.append(f"\nSuggestion: {self.suggestion}")

        return "\n".join(lines)


class DangerousOperationError(Exception):
    """Raised when a dangerous operation is attempted."""

    def __init__(self, operation: str, reason: str, safe_alternative: Optional[str] = None):
        self.operation = operation
        self.reason = reason
        self.safe_alternative = safe_alternative

        message = f"Dangerous operation blocked: {reason}\nCommand: {operation}"
        if safe_alternative:
            message += f"\nSafe alternative: {safe_alternative}"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="DANGEROUS_OPERATION",
            message=self.reason,
            details={"command": self.operation},
            suggestion=self.safe_alternative,
        )


class BlockedOperationError(Exception):
    """Raised when an operation is blocked by policy."""

    def __init__(self, operation: str, policy: str, allowed_alternatives: Optional[list[str]] = None):
        self.operation = operation
        self.policy = policy
        self.allowed_alternatives = allowed_alternatives

        message = f"Operation blocked by policy: {policy}\nCommand: {operation}"
        if allowed_alternatives:
            message += f"\nAllowed alternatives: {', '.join(allowed_alternatives)}"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="BLOCKED_OPERATION",
            message=self.policy,
            details={"command": self.operation},
            suggestion=self.allowed_alternatives[0] if self.allowed_alternatives else None,
        )


class ContextOverflowError(Exception):
    """Raised when context size exceeds limits."""

    def __init__(self, actual: int, limit: int, unit: str, is_recoverable: bool = False):
        self.actual = actual
        self.limit = limit
        self.unit = unit
        self.is_recoverable = is_recoverable

        message = f"Context overflow: {actual} {unit} exceeds limit of {limit} {unit}"
        if is_recoverable:
            message += " (recoverable with truncation)"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="CONTEXT_OVERFLOW",
            message=f"Context size exceeds {self.limit} {self.unit}",
            details={"actual": str(self.actual), "limit": str(self.limit), "unit": self.unit},
            suggestion="Reduce context size or enable auto-truncation" if self.is_recoverable else None,
        )


class ResourceLimitError(Exception):
    """Raised when a resource limit is exceeded."""

    def __init__(self, resource: str, actual: int, limit: int, is_recoverable: bool = False):
        self.resource = resource
        self.actual = actual
        self.limit = limit
        self.is_recoverable = is_recoverable

        message = f"Resource limit exceeded: {resource}\nLimit: {limit}, Actual: {actual}"
        if is_recoverable:
            message += " (recoverable)"

        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="RESOURCE_LIMIT",
            message=f"{self.resource} limit exceeded",
            details={"limit": str(self.limit), "actual": str(self.actual)},
            suggestion=f"Reduce {self.resource} usage to below {self.limit}",
        )


class ValidationError(Exception):
    """Raised when validation fails."""

    def __init__(self, field: str, value: any, requirement: str, example: str):
        self.field = field
        self.value = value
        self.requirement = requirement
        self.example = example

        message = f"Validation failed for {field}: {requirement}\nReceived: {value}\nExample: {example}"
        super().__init__(message)

    def to_structured(self) -> StructuredError:
        """Convert to structured error."""
        return StructuredError(
            code="VALIDATION_ERROR",
            message=f"{self.field}: {self.requirement}",
            details={"received": str(self.value)},
            suggestion=f"Use format: {self.example}",
        )


def to_structured_error(error: Exception) -> StructuredError:
    """
    Convert exception to structured error.

    Args:
        error: Exception to convert

    Returns:
        StructuredError instance
    """
    if hasattr(error, "to_structured"):
        return error.to_structured()

    # Generic error
    return StructuredError(
        code="GENERIC_ERROR",
        message=str(error),
    )
