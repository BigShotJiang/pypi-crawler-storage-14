"""
Code Intelligence Suite for Python

Automated code analysis, refactoring, documentation, and test generation.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import ast
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# ============================================================================
# Types
# ============================================================================


@dataclass
class Issue:
    """A code issue found during analysis."""
    file: str
    line: int
    severity: str  # critical, high, medium, low, info
    category: str
    message: str
    suggestion: Optional[str] = None


@dataclass
class Metric:
    """A code metric."""
    name: str
    value: float
    max_value: float = 100.0
    unit: str = "%"


@dataclass
class AnalysisReport:
    """Complete code analysis report."""
    files_analyzed: int
    lines_of_code: int
    issues: List[Issue]
    metrics: Dict[str, Metric]
    good_patterns: Dict[str, int]


@dataclass
class RefactoringAction:
    """A refactoring action to apply."""
    file: str
    line: int
    action: str
    old_code: str
    new_code: str
    risk: str  # safe, low, medium, high


@dataclass
class DocumentationEntry:
    """A documentation entry."""
    name: str
    kind: str  # function, class, method
    signature: str
    description: str
    params: List[Dict[str, str]]
    returns: Optional[str] = None
    file: Optional[str] = None
    line: Optional[int] = None


@dataclass
class TestCase:
    """A generated test case."""
    name: str
    function_under_test: str
    test_type: str  # unit, edge, error
    code: str


# ============================================================================
# Pattern Definitions
# ============================================================================

SECURITY_PATTERNS = [
    (r"\beval\s*\(", "critical", "Use of eval() is dangerous", "Refactor to avoid eval - use safer alternatives"),
    (r"\bexec\s*\(", "critical", "Use of exec() is dangerous", "Refactor to avoid exec"),
    (r"password\s*=\s*[\"'][^\"']+[\"']", "critical", "Hardcoded password detected", "Use environment variables"),
    (r"api[_-]?key\s*=\s*[\"'][^\"']+[\"']", "critical", "Hardcoded API key detected", "Use secrets manager"),
    (r"subprocess\.(?:call|run|Popen)\s*\(.*shell\s*=\s*True", "high", "Shell injection risk", "Avoid shell=True"),
    (r"\.format\s*\(.*\+", "medium", "Potential format string injection", "Use f-strings or parameterized queries"),
    (r"pickle\.loads?", "high", "Unsafe deserialization", "Use safer alternatives like JSON"),
    (r"yaml\.load\s*\([^)]*\)(?!\s*,\s*Loader\s*=)", "high", "Unsafe YAML loading", "Use yaml.safe_load()"),
]

PERFORMANCE_PATTERNS = [
    (r"for\s+\w+\s+in\s+range\s*\(\s*len\s*\(", "low", "Consider enumerate() instead of range(len())", "Use enumerate()"),
    (r"\.readlines\s*\(\)", "low", "readlines() loads entire file into memory", "Iterate over file object"),
    (r"\+\s*=\s*[\"']", "low", "String concatenation in loop may be slow", "Use list.join() or StringIO"),
    (r"time\.sleep\s*\([^)]*\)", "info", "Blocking sleep detected", "Consider async alternatives"),
    (r"global\s+\w+", "medium", "Global variable usage", "Consider passing as parameter"),
]

MAINTAINABILITY_PATTERNS = [
    (r"except\s*:", "medium", "Bare except clause catches all exceptions", "Specify exception types"),
    (r"#\s*TODO|#\s*FIXME|#\s*HACK", "low", "Technical debt marker", "Address marked issues"),
    (r"pass\s*$", "info", "Empty block with pass", "Implement or add comment"),
    (r"print\s*\(", "low", "Print statement in production code", "Use logging module"),
]


# ============================================================================
# Code Intelligence Engine
# ============================================================================

class CodeIntelligenceEngine:
    """Engine for analyzing Python codebases."""

    IGNORED_DIRS: Set[str] = {
        ".git", "node_modules", "dist", ".next", "build", "coverage",
        "__pycache__", ".pytest_cache", ".venv", "venv", ".mypy_cache",
        ".tox", "eggs", "*.egg-info",
    }

    def __init__(self, working_dir: str = "."):
        self.working_dir = Path(working_dir).resolve()
        self.issues: List[Issue] = []
        self.metrics: Dict[str, Metric] = {}
        self.good_patterns: Dict[str, int] = {}

    def analyze(
        self,
        patterns: Optional[List[str]] = None,
        exclude: Optional[List[str]] = None,
    ) -> AnalysisReport:
        """Analyze the codebase."""
        patterns = patterns or ["**/*.py"]
        exclude = exclude or []

        files = self._collect_files(patterns, exclude)
        total_lines = 0

        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8")
                lines = content.split("\n")
                total_lines += len(lines)
                self._analyze_file(file_path, content, lines)
            except Exception:
                pass

        self._calculate_metrics(len(files), total_lines)

        return AnalysisReport(
            files_analyzed=len(files),
            lines_of_code=total_lines,
            issues=self.issues,
            metrics=self.metrics,
            good_patterns=self.good_patterns,
        )

    def _collect_files(
        self,
        patterns: List[str],
        exclude: List[str],
    ) -> List[Path]:
        """Collect files matching patterns."""
        files: List[Path] = []

        for pattern in patterns:
            for path in self.working_dir.rglob(pattern.replace("**/", "")):
                if path.is_file():
                    skip = False
                    for part in path.parts:
                        if part in self.IGNORED_DIRS or part.endswith(".egg-info"):
                            skip = True
                            break
                    if not skip:
                        # Check exclude patterns
                        rel_path = str(path.relative_to(self.working_dir))
                        for exc in exclude:
                            if exc in rel_path:
                                skip = True
                                break
                    if not skip:
                        files.append(path)

        return files

    def _analyze_file(self, file_path: Path, content: str, lines: List[str]) -> None:
        """Analyze a single file."""
        rel_path = str(file_path.relative_to(self.working_dir))

        # Pattern-based analysis
        all_patterns = SECURITY_PATTERNS + PERFORMANCE_PATTERNS + MAINTAINABILITY_PATTERNS
        for pattern, severity, message, suggestion in all_patterns:
            for i, line in enumerate(lines, 1):
                if re.search(pattern, line):
                    self.issues.append(Issue(
                        file=rel_path,
                        line=i,
                        severity=severity,
                        category=self._get_category(pattern),
                        message=message,
                        suggestion=suggestion,
                    ))

        # Good patterns
        type_hints = len(re.findall(r":\s*(?:int|str|float|bool|List|Dict|Optional|Any)", content))
        if type_hints:
            self.good_patterns["type_annotations"] = self.good_patterns.get("type_annotations", 0) + type_hints

        try_blocks = len(re.findall(r"\btry\s*:", content))
        if try_blocks:
            self.good_patterns["error_handling"] = self.good_patterns.get("error_handling", 0) + try_blocks

        docstrings = len(re.findall(r'"""[\s\S]*?"""', content))
        if docstrings:
            self.good_patterns["documentation"] = self.good_patterns.get("documentation", 0) + docstrings

        tests = len(re.findall(r"def\s+test_\w+|class\s+Test\w+", content))
        if tests:
            self.good_patterns["unit_tests"] = self.good_patterns.get("unit_tests", 0) + tests

    def _get_category(self, pattern: str) -> str:
        """Get category for a pattern."""
        for p, _, _, _ in SECURITY_PATTERNS:
            if p == pattern:
                return "security"
        for p, _, _, _ in PERFORMANCE_PATTERNS:
            if p == pattern:
                return "performance"
        return "maintainability"

    def _calculate_metrics(self, file_count: int, line_count: int) -> None:
        """Calculate overall metrics."""
        # Severity weights
        weights = {"critical": 10, "high": 5, "medium": 2, "low": 1, "info": 0}

        security_issues = [i for i in self.issues if i.category == "security"]
        security_score = max(0, 100 - sum(weights.get(i.severity, 0) for i in security_issues))

        perf_issues = [i for i in self.issues if i.category == "performance"]
        perf_score = max(0, 100 - sum(weights.get(i.severity, 0) for i in perf_issues))

        maint_issues = [i for i in self.issues if i.category == "maintainability"]
        maint_score = max(0, 100 - sum(weights.get(i.severity, 0) for i in maint_issues))

        doc_count = self.good_patterns.get("documentation", 0)
        doc_score = min(100, (doc_count / max(1, file_count)) * 50)

        test_count = self.good_patterns.get("unit_tests", 0)
        test_score = min(100, (test_count / max(1, file_count)) * 100)

        self.metrics = {
            "security": Metric("Security", security_score),
            "performance": Metric("Performance", perf_score),
            "maintainability": Metric("Maintainability", maint_score),
            "documentation": Metric("Documentation", doc_score),
            "testability": Metric("Testability", test_score),
        }


# ============================================================================
# Refactoring Engine
# ============================================================================

class RefactoringEngine:
    """Engine for suggesting and applying refactorings."""

    def __init__(self, working_dir: str = "."):
        self.working_dir = Path(working_dir).resolve()

    def suggest(
        self,
        file_path: str,
        refactoring_types: Optional[List[str]] = None,
    ) -> List[RefactoringAction]:
        """Suggest refactorings for a file."""
        path = self.working_dir / file_path
        if not path.exists():
            return []

        content = path.read_text(encoding="utf-8")
        lines = content.split("\n")
        actions: List[RefactoringAction] = []

        # Range(len()) to enumerate()
        for i, line in enumerate(lines, 1):
            match = re.search(r"for\s+(\w+)\s+in\s+range\s*\(\s*len\s*\(\s*(\w+)\s*\)\s*\)\s*:", line)
            if match:
                idx_var, list_var = match.groups()
                old_code = match.group(0)
                new_code = f"for {idx_var}, item in enumerate({list_var}):"
                actions.append(RefactoringAction(
                    file=file_path,
                    line=i,
                    action="Use enumerate() instead of range(len())",
                    old_code=old_code,
                    new_code=new_code,
                    risk="safe",
                ))

        # String formatting
        for i, line in enumerate(lines, 1):
            match = re.search(r'(["\']).*?%s.*?\1\s*%\s*\(', line)
            if match:
                actions.append(RefactoringAction(
                    file=file_path,
                    line=i,
                    action="Use f-strings instead of % formatting",
                    old_code=line.strip(),
                    new_code="# Convert to f-string",
                    risk="low",
                ))

        return actions

    def apply(
        self,
        actions: List[RefactoringAction],
        dry_run: bool = True,
    ) -> Dict[str, Any]:
        """Apply refactoring actions."""
        if dry_run:
            return {
                "status": "dry_run",
                "actions_count": len(actions),
                "actions": [a.__dict__ for a in actions],
            }

        applied = 0
        for action in actions:
            if action.risk == "safe":
                path = self.working_dir / action.file
                content = path.read_text(encoding="utf-8")
                new_content = content.replace(action.old_code, action.new_code, 1)
                path.write_text(new_content, encoding="utf-8")
                applied += 1

        return {
            "status": "applied",
            "applied_count": applied,
            "total_count": len(actions),
        }


# ============================================================================
# Documentation Generator
# ============================================================================

class DocumentationGenerator:
    """Generator for API documentation."""

    def __init__(self, working_dir: str = "."):
        self.working_dir = Path(working_dir).resolve()

    def generate(
        self,
        patterns: Optional[List[str]] = None,
        format_type: str = "markdown",
    ) -> str:
        """Generate documentation for the codebase."""
        patterns = patterns or ["**/*.py"]
        entries: List[DocumentationEntry] = []

        for pattern in patterns:
            for path in self.working_dir.rglob(pattern.replace("**/", "")):
                if path.is_file() and "__pycache__" not in str(path):
                    try:
                        content = path.read_text(encoding="utf-8")
                        rel_path = str(path.relative_to(self.working_dir))
                        entries.extend(self._parse_file(content, rel_path))
                    except Exception:
                        pass

        if format_type == "markdown":
            return self._format_markdown(entries)
        return self._format_json(entries)

    def _parse_file(self, content: str, file_path: str) -> List[DocumentationEntry]:
        """Parse a Python file for documentation."""
        entries: List[DocumentationEntry] = []

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return entries

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                entry = self._parse_function(node, file_path)
                if entry:
                    entries.append(entry)
            elif isinstance(node, ast.ClassDef):
                entry = self._parse_class(node, file_path)
                if entry:
                    entries.append(entry)

        return entries

    def _parse_function(self, node: ast.FunctionDef, file_path: str) -> Optional[DocumentationEntry]:
        """Parse a function definition."""
        params: List[Dict[str, str]] = []
        for arg in node.args.args:
            param = {"name": arg.arg}
            if arg.annotation:
                param["type"] = ast.unparse(arg.annotation)
            params.append(param)

        # Get docstring
        docstring = ast.get_docstring(node) or ""

        # Build signature
        sig_parts = [f"{p['name']}: {p.get('type', 'Any')}" for p in params]
        returns = ""
        if node.returns:
            returns = ast.unparse(node.returns)

        signature = f"def {node.name}({', '.join(sig_parts)})"
        if returns:
            signature += f" -> {returns}"

        return DocumentationEntry(
            name=node.name,
            kind="function",
            signature=signature,
            description=docstring.split("\n")[0] if docstring else "",
            params=params,
            returns=returns or None,
            file=file_path,
            line=node.lineno,
        )

    def _parse_class(self, node: ast.ClassDef, file_path: str) -> Optional[DocumentationEntry]:
        """Parse a class definition."""
        docstring = ast.get_docstring(node) or ""
        bases = [ast.unparse(b) for b in node.bases]

        signature = f"class {node.name}"
        if bases:
            signature += f"({', '.join(bases)})"

        return DocumentationEntry(
            name=node.name,
            kind="class",
            signature=signature,
            description=docstring.split("\n")[0] if docstring else "",
            params=[],
            file=file_path,
            line=node.lineno,
        )

    def _format_markdown(self, entries: List[DocumentationEntry]) -> str:
        """Format entries as markdown."""
        lines = ["# API Documentation", "", f"Generated documentation for {len(entries)} items.", ""]

        # Group by file
        by_file: Dict[str, List[DocumentationEntry]] = {}
        for entry in entries:
            key = entry.file or "unknown"
            if key not in by_file:
                by_file[key] = []
            by_file[key].append(entry)

        for file_path, file_entries in sorted(by_file.items()):
            lines.append(f"## {file_path}")
            lines.append("")

            for entry in file_entries:
                lines.append(f"### {entry.kind}: `{entry.name}`")
                lines.append("")
                lines.append(f"```python")
                lines.append(entry.signature)
                lines.append("```")
                lines.append("")
                if entry.description:
                    lines.append(entry.description)
                    lines.append("")
                if entry.params:
                    lines.append("**Parameters:**")
                    for p in entry.params:
                        ptype = p.get("type", "Any")
                        lines.append(f"- `{p['name']}` ({ptype})")
                    lines.append("")
                if entry.returns:
                    lines.append(f"**Returns:** `{entry.returns}`")
                    lines.append("")

        return "\n".join(lines)

    def _format_json(self, entries: List[DocumentationEntry]) -> str:
        """Format entries as JSON."""
        import json
        return json.dumps([e.__dict__ for e in entries], indent=2)


# ============================================================================
# Test Generator
# ============================================================================

class TestGenerator:
    """Generator for test suites."""

    def __init__(self, working_dir: str = "."):
        self.working_dir = Path(working_dir).resolve()

    def generate(
        self,
        file_path: str,
        framework: str = "pytest",
    ) -> str:
        """Generate tests for a file."""
        path = self.working_dir / file_path
        if not path.exists():
            return f"# Error: File not found: {file_path}"

        content = path.read_text(encoding="utf-8")
        test_cases = self._generate_tests(content, file_path, framework)

        return self._format_tests(test_cases, file_path, framework)

    def _generate_tests(
        self,
        content: str,
        file_path: str,
        framework: str,
    ) -> List[TestCase]:
        """Generate test cases for content."""
        cases: List[TestCase] = []

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return cases

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                if node.name.startswith("_"):
                    continue

                # Basic test
                cases.append(TestCase(
                    name=f"test_{node.name}_basic",
                    function_under_test=node.name,
                    test_type="unit",
                    code=self._generate_basic_test(node, framework),
                ))

                # Edge case test
                cases.append(TestCase(
                    name=f"test_{node.name}_edge_cases",
                    function_under_test=node.name,
                    test_type="edge",
                    code=self._generate_edge_test(node, framework),
                ))

        return cases

    def _generate_basic_test(self, node: ast.FunctionDef, framework: str) -> str:
        """Generate a basic test for a function."""
        params = [arg.arg for arg in node.args.args if arg.arg != "self"]
        args_str = ", ".join(["test_value"] * len(params)) if params else ""

        if framework == "pytest":
            return f"""def test_{node.name}_basic():
    \"\"\"Test basic functionality of {node.name}.\"\"\"
    # Arrange
    # TODO: Set up test data

    # Act
    result = {node.name}({args_str})

    # Assert
    assert result is not None"""

        # unittest
        return f"""def test_{node.name}_basic(self):
    \"\"\"Test basic functionality of {node.name}.\"\"\"
    # Arrange
    # TODO: Set up test data

    # Act
    result = {node.name}({args_str})

    # Assert
    self.assertIsNotNone(result)"""

    def _generate_edge_test(self, node: ast.FunctionDef, framework: str) -> str:
        """Generate edge case tests."""
        if framework == "pytest":
            return f"""def test_{node.name}_edge_cases():
    \"\"\"Test edge cases for {node.name}.\"\"\"
    # Test with None
    # Test with empty input
    # Test with invalid input
    pass  # TODO: Implement edge case tests"""

        return f"""def test_{node.name}_edge_cases(self):
    \"\"\"Test edge cases for {node.name}.\"\"\"
    # Test with None
    # Test with empty input
    # Test with invalid input
    pass  # TODO: Implement edge case tests"""

    def _format_tests(
        self,
        cases: List[TestCase],
        file_path: str,
        framework: str,
    ) -> str:
        """Format test cases into a test file."""
        module_name = Path(file_path).stem

        lines = [
            f'"""Tests for {file_path}"""',
            "",
        ]

        if framework == "pytest":
            lines.extend([
                "import pytest",
                f"from {module_name} import *",
                "",
                "",
            ])
        else:
            lines.extend([
                "import unittest",
                f"from {module_name} import *",
                "",
                "",
                f"class Test{module_name.title().replace('_', '')}(unittest.TestCase):",
                "    \"\"\"Test cases for {module_name}.\"\"\"",
                "",
            ])

        for case in cases:
            if framework == "unittest":
                # Indent for class
                indented = "\n".join("    " + line for line in case.code.split("\n"))
                lines.append(indented)
            else:
                lines.append(case.code)
            lines.append("")

        if framework == "unittest":
            lines.extend([
                "",
                'if __name__ == "__main__":',
                "    unittest.main()",
            ])

        return "\n".join(lines)


# ============================================================================
# Unified Suite
# ============================================================================

class CodeIntelligenceSuite:
    """Unified interface for all code intelligence features."""

    def __init__(self, working_dir: str = "."):
        self.working_dir = working_dir
        self.analyzer = CodeIntelligenceEngine(working_dir)
        self.refactorer = RefactoringEngine(working_dir)
        self.documenter = DocumentationGenerator(working_dir)
        self.tester = TestGenerator(working_dir)

    def analyze(
        self,
        patterns: Optional[List[str]] = None,
        exclude: Optional[List[str]] = None,
    ) -> AnalysisReport:
        """Analyze the codebase."""
        return self.analyzer.analyze(patterns, exclude)

    def suggest_refactorings(
        self,
        file_path: str,
        types: Optional[List[str]] = None,
    ) -> List[RefactoringAction]:
        """Suggest refactorings for a file."""
        return self.refactorer.suggest(file_path, types)

    def generate_docs(
        self,
        patterns: Optional[List[str]] = None,
        format_type: str = "markdown",
    ) -> str:
        """Generate documentation."""
        return self.documenter.generate(patterns, format_type)

    def generate_tests(
        self,
        file_path: str,
        framework: str = "pytest",
    ) -> str:
        """Generate tests for a file."""
        return self.tester.generate(file_path, framework)

    def full_analysis(
        self,
        patterns: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Run full analysis and return comprehensive report."""
        report = self.analyze(patterns)
        docs = self.generate_docs(patterns)

        return {
            "analysis": {
                "files_analyzed": report.files_analyzed,
                "lines_of_code": report.lines_of_code,
                "issues_by_severity": {
                    "critical": len([i for i in report.issues if i.severity == "critical"]),
                    "high": len([i for i in report.issues if i.severity == "high"]),
                    "medium": len([i for i in report.issues if i.severity == "medium"]),
                    "low": len([i for i in report.issues if i.severity == "low"]),
                    "info": len([i for i in report.issues if i.severity == "info"]),
                },
                "metrics": {k: v.value for k, v in report.metrics.items()},
                "good_patterns": report.good_patterns,
            },
            "documentation_size": len(docs),
            "top_issues": [
                {
                    "file": i.file,
                    "line": i.line,
                    "severity": i.severity,
                    "message": i.message,
                }
                for i in sorted(report.issues, key=lambda x: {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}.get(x.severity, 5))[:10]
            ],
        }


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Types
    "Issue",
    "Metric",
    "AnalysisReport",
    "RefactoringAction",
    "DocumentationEntry",
    "TestCase",

    # Engines
    "CodeIntelligenceEngine",
    "RefactoringEngine",
    "DocumentationGenerator",
    "TestGenerator",

    # Suite
    "CodeIntelligenceSuite",
]
