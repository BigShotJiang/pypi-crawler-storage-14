"""
Bash execution tools with safety validation and sandboxing.

Features:
- Command safety validation
- Sandboxed environment
- Background process support
- Timeout handling
"""

from __future__ import annotations

import asyncio
import os
import subprocess
from pathlib import Path
from typing import Any, Optional

from ..core.errors.error_types import to_structured_error
from ..core.errors.safety_validator import SmartFixer, validate_bash_command
from ..core.tool_runtime import ToolDefinition
from ..core.types import (
    JSONSchemaArray,
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
)


# Cache for sandbox paths
_sandbox_cache: dict[str, dict[str, str]] = {}


def create_bash_tools(working_dir: str) -> list[ToolDefinition]:
    """
    Create bash execution tools.

    Args:
        working_dir: Working directory for command execution

    Returns:
        List of bash tool definitions
    """
    working_path = Path(working_dir).resolve()

    async def execute_bash_handler(args: dict[str, Any]) -> str:
        try:
            command = args.get("command", "")
            if not command or not isinstance(command, str):
                return "Error: command must be a non-empty string."

            timeout = args.get("timeout", 30000)  # Default 30 seconds
            if isinstance(timeout, (int, float)):
                timeout_seconds = timeout / 1000.0
            else:
                timeout_seconds = 30.0

            run_in_background = args.get("run_in_background", False)

            # Enhanced safety validation with structured errors
            validation = validate_bash_command(command)

            if not validation.valid:
                if validation.error:
                    structured_error = to_structured_error(validation.error)
                    error_msg = structured_error.to_display_string()

                    # Add auto-fix suggestion if available
                    if validation.auto_fix and validation.auto_fix.available:
                        fixed, changes = SmartFixer.fix_dangerous_command(command)
                        if changes:
                            error_msg += "\n\nAuto-fix available:"
                            for change in changes:
                                error_msg += f"\n  - {change}"
                            error_msg += f"\n\nFixed command: {fixed}"

                    return error_msg

                return "Error: Command validation failed"

            # Log warnings if any
            if validation.warnings:
                for warning in validation.warnings:
                    print(f"[Bash Safety] {warning}")

            # Handle background execution
            if run_in_background:
                return "Error: Background execution not yet implemented. Use run_in_background: false"

            # Handle foreground execution
            env = await _build_sandbox_env(str(working_path))

            try:
                result = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(working_path),
                    env=env,
                )

                try:
                    stdout_bytes, stderr_bytes = await asyncio.wait_for(
                        result.communicate(),
                        timeout=timeout_seconds,
                    )

                    stdout = stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else ""
                    stderr = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""

                    output_parts = []
                    if stdout:
                        output_parts.append(f"stdout:\n{stdout}")
                    if stderr:
                        output_parts.append(f"stderr:\n{stderr}")

                    if output_parts:
                        return "\n".join(output_parts)
                    return "Command executed successfully (no output)"

                except asyncio.TimeoutError:
                    # Kill the process
                    result.kill()
                    await result.wait()
                    return f"Error: Command timed out after {timeout}ms"

            except Exception as error:
                return f"Error executing command: {error}"

        except Exception as error:
            return f"Error: {error}"

    return [
        ToolDefinition(
            name="execute_bash",
            description="Execute a bash command in the working directory. Use run_in_background: true to run commands in the background (not yet implemented).",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "command": JSONSchemaString(type="string",
                        description="The bash command to execute",
                        min_length=1,
                    ),
                    "timeout": JSONSchemaNumber(type="number",
                        description="Timeout in milliseconds (default: 30000)",
                    ),
                    "run_in_background": JSONSchemaBoolean(type="boolean",
                        description="Set to true to run this command in the background (not yet implemented)",
                    ),
                },
                required=["command"],
                additional_properties=False,
            ),
            handler=execute_bash_handler,
        )
    ]


async def _build_sandbox_env(working_dir: str, preserve_home: bool = False) -> dict[str, str]:
    """
    Build sandboxed environment for bash execution.

    Args:
        working_dir: Working directory
        preserve_home: Whether to preserve HOME directory

    Returns:
        Environment dictionary
    """
    # Check environment preference
    env_preference = os.environ.get("EROSOLAR_PRESERVE_HOME")
    if env_preference == "1":
        preserve_home = True
    elif env_preference == "0":
        preserve_home = False

    # Get or create sandbox paths
    paths = await _ensure_sandbox_paths(working_dir)

    # Build environment
    env = os.environ.copy()
    env["EROSOLAR_SANDBOX_ROOT"] = paths["root"]
    env["EROSOLAR_SANDBOX_HOME"] = paths["home"]
    env["EROSOLAR_SANDBOX_TMP"] = paths["tmp"]

    if not preserve_home:
        env["HOME"] = paths["home"]

    env["XDG_CACHE_HOME"] = paths["cache"]
    env["XDG_CONFIG_HOME"] = paths["config"]
    env["XDG_DATA_HOME"] = paths["data"]
    env["TMPDIR"] = paths["tmp"]
    env["TMP"] = paths["tmp"]
    env["TEMP"] = paths["tmp"]

    # Ensure cloud CLIs are in PATH
    current_path = env.get("PATH", "")
    cloud_cli_paths = [
        "/Users/bo/google-cloud-sdk/bin",  # gcloud
        "/usr/local/bin",                   # aws, brew packages
        "/opt/homebrew/bin",                # homebrew (ARM Mac)
        "/usr/bin",                         # system binaries
        "/bin",                             # core binaries
    ]

    # Add cloud CLI paths if not already in PATH
    for cli_path in cloud_cli_paths:
        if cli_path not in current_path and Path(cli_path).exists():
            current_path = f"{cli_path}:{current_path}"

    env["PATH"] = current_path

    return env


async def _ensure_sandbox_paths(working_dir: str) -> dict[str, str]:
    """
    Ensure sandbox directories exist.

    Args:
        working_dir: Working directory

    Returns:
        Dictionary of sandbox paths
    """
    # Check cache
    if working_dir in _sandbox_cache:
        return _sandbox_cache[working_dir]

    # Create sandbox paths
    root_path = Path(working_dir) / ".erosolar" / "shell-sandbox"
    paths = {
        "root": str(root_path),
        "home": str(root_path / "home"),
        "cache": str(root_path / "cache"),
        "config": str(root_path / "config"),
        "data": str(root_path / "data"),
        "tmp": str(root_path / "tmp"),
    }

    # Create directories
    for path in paths.values():
        Path(path).mkdir(parents=True, exist_ok=True)

    # Cache and return
    _sandbox_cache[working_dir] = paths
    return paths
