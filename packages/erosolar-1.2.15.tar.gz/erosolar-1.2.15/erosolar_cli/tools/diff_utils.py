"""
Diff utilities for showing file changes.
Supports git-based diff or naive line-by-line comparison.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Literal, Optional


@dataclass
class DiffSegment:
    """A segment of a diff showing an added or removed line."""

    type: Literal["added", "removed"]
    line_number: int
    content: str


def build_diff_segments(previous: str, next: str) -> list[DiffSegment]:
    """
    Build diff segments between two strings.

    Args:
        previous: Original content
        next: New content

    Returns:
        List of diff segments
    """
    before = normalize_newlines(previous)
    after = normalize_newlines(next)

    if before == after:
        return []

    # Try git diff first (better quality)
    git_segments = try_build_with_git(before, after)
    if git_segments is not None:
        return git_segments

    # Fall back to naive diff
    return build_naive_diff(before, after)


def format_diff_lines(diff: list[DiffSegment]) -> list[str]:
    """
    Format diff segments as human-readable lines.

    Args:
        diff: List of diff segments

    Returns:
        List of formatted diff lines
    """
    if not diff:
        return []

    # Calculate padding width for line numbers
    width = max(1, max(max(1, entry.line_number) for entry in diff))
    width_str = len(str(width))

    formatted = []
    for entry in diff:
        prefix = "+" if entry.type == "added" else "-"
        line_number = max(1, entry.line_number)
        body = entry.content if entry.content else "[empty line]"
        padded_number = str(line_number).rjust(width_str)
        formatted.append(f"{prefix} L{padded_number} | {body}")

    return formatted


def try_build_with_git(before: str, after: str) -> Optional[list[DiffSegment]]:
    """
    Try to build diff using git.

    Args:
        before: Original content
        after: New content

    Returns:
        List of diff segments or None if git is not available
    """
    temp_dir = None
    try:
        # Create temp directory
        temp_dir = tempfile.mkdtemp(prefix="erosolar-diff-")
        original_path = os.path.join(temp_dir, "before.txt")
        updated_path = os.path.join(temp_dir, "after.txt")

        # Write files
        with open(original_path, "w", encoding="utf-8") as f:
            f.write(before)
        with open(updated_path, "w", encoding="utf-8") as f:
            f.write(after)

        # Run git diff
        result = subprocess.run(
            [
                "git",
                "--no-pager",
                "diff",
                "--no-index",
                "--unified=0",
                "--color=never",
                "--",
                original_path,
                updated_path,
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )

        # Git returns 1 for differences, which is normal
        if result.returncode > 1:
            return None

        return parse_unified_diff(result.stdout)

    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    finally:
        # Clean up temp directory
        if temp_dir and os.path.exists(temp_dir):
            try:
                import shutil

                shutil.rmtree(temp_dir)
            except Exception:
                pass


def parse_unified_diff(output: str) -> list[DiffSegment]:
    """
    Parse unified diff output.

    Args:
        output: Git diff output

    Returns:
        List of diff segments
    """
    if not output.strip():
        return []

    lines = output.split("\n")
    segments: list[DiffSegment] = []
    old_line = 0
    new_line = 0

    for raw_line in lines:
        line = raw_line.rstrip("\r")
        if not line:
            continue

        # Parse hunk header
        if line.startswith("@@"):
            import re

            match = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line)
            if match:
                old_line = int(match.group(1))
                new_line = int(match.group(2))
            continue

        # Skip metadata lines
        if (
            line.startswith("+++")
            or line.startswith("---")
            or line.startswith("diff ")
            or line.startswith("index ")
            or line.startswith("Binary ")
            or line.startswith("\\")
        ):
            continue

        # Added line
        if line.startswith("+"):
            segments.append(DiffSegment(type="added", line_number=new_line, content=line[1:]))
            new_line += 1
            continue

        # Removed line
        if line.startswith("-"):
            segments.append(DiffSegment(type="removed", line_number=old_line, content=line[1:]))
            old_line += 1
            continue

        # Context line
        if line.startswith(" "):
            old_line += 1
            new_line += 1
            continue

    return segments


def build_naive_diff(before: str, after: str) -> list[DiffSegment]:
    """
    Build naive line-by-line diff.

    Args:
        before: Original content
        after: New content

    Returns:
        List of diff segments
    """
    a_lines = split_lines(before)
    b_lines = split_lines(after)
    max_lines = max(len(a_lines), len(b_lines))
    segments: list[DiffSegment] = []

    for index in range(max_lines):
        left = a_lines[index] if index < len(a_lines) else None
        right = b_lines[index] if index < len(b_lines) else None

        if left == right:
            continue

        if left is not None:
            segments.append(DiffSegment(type="removed", line_number=index + 1, content=left))

        if right is not None:
            segments.append(DiffSegment(type="added", line_number=index + 1, content=right))

    return segments


def normalize_newlines(value: str) -> str:
    """Normalize newlines to LF."""
    return value.replace("\r\n", "\n")


def split_lines(value: str) -> list[str]:
    """Split string into lines."""
    if not value:
        return []
    normalized = normalize_newlines(value)
    return normalized.split("\n")
