This module masks the recurring functionality built into Odoo's
maintenance module to avoid confusion with recurring settings
specific to the maintenance plan.
