#!/usr/bin/env python3
"""
DevGenius MCP Server - stdio 实现

标准的 MCP Server 实现，使用 stdio 协议与 AI IDE 通信。
这是最通用的方式，兼容所有支持 MCP 的 AI IDE（Cursor、Windsurf、Claude Desktop 等）。

使用方法:
1. 配置环境变量 DEVGENIUS_MCP_TOKEN
2. 在 AI IDE 的 MCP 配置中添加:
   {
     "mcpServers": {
       "devgenius": {
         "command": "python",
         "args": ["/path/to/mcp_stdio_server.py"],
         "env": {
           "DEVGENIUS_MCP_TOKEN": "mcp_your_token",
           "DEVGENIUS_API_URL": "http://localhost:8000/api/v1/mcp"
         }
       }
     }
   }
"""

import sys
import json
import os
import asyncio
import logging
from typing import Any, Dict, List, Optional
from urllib.parse import quote

# 强制设置 UTF-8 编码
import io

# 重新配置 stdin/stdout 为 UTF-8，使用 'replace' 错误处理避免 surrogate 错误
sys.stdin = io.TextIOWrapper(
    sys.stdin.buffer,
    encoding='utf-8',
    errors='replace',  # 替换无法解码的字符
    newline=None
)
sys.stdout = io.TextIOWrapper(
    sys.stdout.buffer,
    encoding='utf-8',
    errors='replace',  # 替换无法编码的字符
    newline=None,
    line_buffering=False,  # 禁用行缓冲
    write_through=True  # 立即写入
)
sys.stderr = io.TextIOWrapper(
    sys.stderr.buffer,
    encoding='utf-8',
    errors='replace',
    newline=None,
    line_buffering=False,
    write_through=True
)

# 配置日志（输出到文件）
logging.basicConfig(
    filename='devgenius_mcp_server.log',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

try:
    import httpx
except ImportError:
    logger.error("httpx 未安装，请运行: pip install httpx")
    sys.exit(1)


class DevGeniusMCPStdioServer:
    """
    DevGenius MCP Server (stdio 协议)
    
    通过标准输入输出与 AI IDE 通信，调用 DevGenius HTTP API 执行实际操作。
    """
    
    def __init__(self, token: str, api_url: str):
        """
        初始化 MCP Server
        
        Args:
            token: MCP Token
            api_url: DevGenius API 基础 URL
        """
        self.token = token
        self.api_url = api_url.rstrip('/')
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        logger.info(f"✅ DevGenius MCP Server 初始化完成，API: {api_url}")
    
    def get_tools_list(self) -> List[Dict[str, Any]]:
        """Get list of available tools"""
        return [
            {
                "name": "get_project_context",
                "description": "Get project context including basic info and current tasks",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "include_tasks": {
                            "type": "boolean",
                            "description": "Whether to include task list",
                            "default": True
                        }
                    }
                }
            },
            {
                "name": "get_my_tasks",
                "description": "Get my task list, automatically filtered by member role",
                "inputSchema": {"type": "object", "properties": {}}
            },
            {
                "name": "claim_task",
                "description": "Claim a task and acquire lock (default 120 minutes)",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Task ID"},
                        "lock_duration_minutes": {"type": "integer", "description": "Lock duration in minutes", "default": 120}
                    },
                    "required": ["task_id"]
                }
            },
            {
                "name": "update_task_status",
                "description": "Update task status with optimistic locking",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Task ID"},
                        "status": {"type": "string", "description": "New status", "enum": ["pending", "in_progress", "completed", "cancelled"]},
                        "version": {"type": "integer", "description": "Version number for optimistic locking"}
                    },
                    "required": ["task_id", "status", "version"]
                }
            },
            {
                "name": "split_task_into_subtasks",
                "description": "Split a main task into multiple subtasks",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Main task ID"},
                        "subtasks": {
                            "type": "array",
                            "description": "List of subtasks to create",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "title": {"type": "string", "description": "Subtask title"},
                                    "description": {"type": "string", "description": "Subtask description"}
                                },
                                "required": ["title"]
                            }
                        }
                    },
                    "required": ["task_id", "subtasks"]
                }
            },
            {
                "name": "get_task_subtasks",
                "description": "Get all subtasks for a given task",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "integer", "description": "Main task ID"}
                    },
                    "required": ["task_id"]
                }
            },
            {
                "name": "update_subtask_status",
                "description": "Update subtask status",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "subtask_id": {"type": "integer", "description": "Subtask ID"},
                        "status": {"type": "string", "description": "New status", "enum": ["pending", "in_progress", "completed", "cancelled"]},
                        "notes": {"type": "string", "description": "Optional notes"}
                    },
                    "required": ["subtask_id", "status"]
                }
            },
            {
                "name": "list_documents",
                "description": "Get project document list (metadata only)",
                "inputSchema": {"type": "object", "properties": {}}
            },
            {
                "name": "get_document_by_title",
                "description": "Query document by title (with full content)",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Document title"},
                        "version": {"type": "integer", "description": "Version number (optional, defaults to latest)"}
                    },
                    "required": ["title"]
                }
            },
            {
                "name": "search_documents",
                "description": "Full-text search across all documents",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search keywords"},
                        "category": {"type": "string", "description": "Category filter (optional)"},
                        "limit": {"type": "integer", "description": "Maximum results to return", "default": 10}
                    },
                    "required": ["query"]
                }
            }
        ]
    
    async def call_tool(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """调用工具"""
        logger.info(f"🔧 调用工具: {name}, 参数: {arguments}")
        
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                # 根据工具名称调用对应的 API
                if name == "get_project_context":
                    response = await client.get(
                        f"{self.api_url}/context",
                        headers=self.headers,
                        params={"include_tasks": arguments.get("include_tasks", True)}
                    )
                
                elif name == "get_my_tasks":
                    response = await client.get(f"{self.api_url}/tasks", headers=self.headers)
                
                elif name == "claim_task":
                    response = await client.post(f"{self.api_url}/tasks/claim", headers=self.headers, json=arguments)
                
                elif name == "update_task_status":
                    response = await client.post(f"{self.api_url}/tasks/update-status", headers=self.headers, json=arguments)
                
                elif name == "split_task_into_subtasks":
                    # 确保中文标题正确编码
                    # httpx 会自动处理 JSON 编码，但我们需要确保使用 UTF-8
                    response = await client.post(
                        f"{self.api_url}/tasks/split",
                        headers=self.headers,
                        json=arguments,
                        timeout=30.0
                    )
                
                elif name == "get_task_subtasks":
                    task_id = arguments["task_id"]
                    response = await client.get(f"{self.api_url}/tasks/{task_id}/subtasks", headers=self.headers)
                
                elif name == "update_subtask_status":
                    response = await client.post(f"{self.api_url}/subtasks/update-status", headers=self.headers, json=arguments)
                
                elif name == "list_documents":
                    response = await client.get(f"{self.api_url}/documents", headers=self.headers)
                
                elif name == "get_document_by_title":
                    title = arguments["title"]
                    # URL 编码标题，支持中文（只编码标题，不编码查询参数）
                    encoded_title = quote(title, safe='')
                    # 查询参数单独处理
                    params = {}
                    if "version" in arguments:
                        params["version"] = arguments["version"]
                    response = await client.get(
                        f"{self.api_url}/documents/by-title/{encoded_title}",
                        headers=self.headers,
                        params=params
                    )
                
                elif name == "search_documents":
                    response = await client.get(f"{self.api_url}/documents/search", headers=self.headers, params=arguments)
                
                else:
                    return {"error": f"未知工具: {name}"}
                
                response.raise_for_status()
                result = response.json()
                logger.info(f"✅ 工具调用成功: {name}")
                return result
                
        except httpx.HTTPError as e:
            logger.error(f"❌ HTTP 错误: {e}")
            return {"error": f"HTTP 错误: {str(e)}"}
        except Exception as e:
            logger.error(f"❌ 调用失败: {e}", exc_info=True)
            return {"error": f"调用失败: {str(e)}"}
    
    async def handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """处理 MCP 请求"""
        method = request.get("method")
        params = request.get("params", {})
        request_id = request.get("id")
        
        logger.debug(f"📨 收到请求: method={method}, id={request_id}")
        
        try:
            if method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "devgenius", "version": "1.0.0"}
                }
            
            elif method == "tools/list":
                result = {"tools": self.get_tools_list()}
            
            elif method == "tools/call":
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                tool_result = await self.call_tool(tool_name, arguments)
                result = {"content": [{"type": "text", "text": json.dumps(tool_result, ensure_ascii=False, indent=2)}]}
            
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {"code": -32601, "message": f"Method not found: {method}"}
                }
            
            return {"jsonrpc": "2.0", "id": request_id, "result": result}
            
        except Exception as e:
            logger.error(f"❌ 处理请求失败: {e}", exc_info=True)
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32603, "message": str(e)}
            }
    
    async def run(self):
        """运行 MCP Server（stdio 模式）"""
        logger.info("🚀 DevGenius MCP Server 启动，等待请求...")
        
        try:
            for line in sys.stdin:
                line = line.strip()
                if not line:
                    continue
                
                try:
                    request = json.loads(line)
                    response = await self.handle_request(request)
                    
                    # 确保中文正确编码输出，避免 surrogate 错误
                    # 使用 ensure_ascii=False 保留中文，但先转为字节再解码确保安全
                    response_str = json.dumps(response, ensure_ascii=False)
                    
                    # 写入并立即刷新
                    sys.stdout.write(response_str + '\n')
                    sys.stdout.flush()
                    
                except json.JSONDecodeError as e:
                    logger.error(f"❌ JSON 解析错误: {e}")
                    error_response = {
                        "jsonrpc": "2.0",
                        "id": None,
                        "error": {"code": -32700, "message": "Parse error"}
                    }
                    print(json.dumps(error_response, ensure_ascii=False), flush=True)
                    
        except KeyboardInterrupt:
            logger.info("🛑 收到中断信号，退出...")
        except Exception as e:
            logger.error(f"❌ 运行时错误: {e}", exc_info=True)


async def async_main():
    """异步主函数"""
    try:
        logger.info("=" * 60)
        logger.info("DevGenius MCP Server 正在启动...")
        logger.info(f"Python 版本: {sys.version}")
        logger.info(f"平台: {sys.platform}")
        logger.info("=" * 60)
        
        # 从环境变量获取配置
        token = os.getenv("DEVGENIUS_MCP_TOKEN")
        api_url = os.getenv("DEVGENIUS_API_URL", "http://localhost:8000/api/v1/mcp")
        
        logger.info(f"API URL: {api_url}")
        logger.info(f"Token: {token[:20]}..." if token else "Token: 未设置")
        
        if not token:
            logger.error("❌ 未设置 DEVGENIUS_MCP_TOKEN 环境变量")
            sys.stderr.write("错误: 请设置 DEVGENIUS_MCP_TOKEN 环境变量\n")
            sys.stderr.flush()
            sys.exit(1)
        
        server = DevGeniusMCPStdioServer(token=token, api_url=api_url)
        await server.run()
        
    except Exception as e:
        logger.error(f"❌ 启动失败: {e}", exc_info=True)
        sys.stderr.write(f"启动失败: {str(e)}\n")
        sys.stderr.flush()
        sys.exit(1)


def main():
    """同步入口点（供 uvx/pip 调用）"""
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
