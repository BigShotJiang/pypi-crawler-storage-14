# 发布 DevGenius MCP Client 到 PyPI

## 📦 发布步骤

### 1. 清理旧的构建文件

```bash
cd mcp-client
Remove-Item -Recurse -Force dist, build, *.egg-info -ErrorAction SilentlyContinue
```

### 2. 构建包

```bash
python -m build
```

这会在 `dist/` 目录生成：
- `devgenius_mcp_client-1.0.1-py3-none-any.whl`
- `devgenius_mcp_client-1.0.1.tar.gz`

### 3. 上传到 PyPI

```bash
python -m twine upload dist/*
```

输入你的 PyPI API Token。

### 4. 验证

```bash
# 测试安装
uvx --from devgenius-mcp-client devgenius-mcp --help

# 或
pip install devgenius-mcp-client
devgenius-mcp --help
```

---

## ✅ 版本更新清单

发布新版本前检查：

- [ ] 更新 `pyproject.toml` 中的版本号
- [ ] 测试本地脚本运行正常
- [ ] 清理旧的 dist 目录
- [ ] 构建新包
- [ ] 上传到 PyPI
- [ ] 测试 uvx 安装
- [ ] 更新文档中的版本号

---

## 🔧 当前版本

**v1.0.1**
- 修复 async main 函数问题
- 正确的入口点配置
- 完整的日志支持

**v1.0.0**
- 初始发布
- 支持所有 10 个 MCP 工具
- 中文编码支持

---

## 📝 PyPI 链接

https://pypi.org/project/devgenius-mcp-client/
