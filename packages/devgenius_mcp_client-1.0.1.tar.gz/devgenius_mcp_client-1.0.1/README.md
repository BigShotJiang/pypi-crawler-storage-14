# DevGenius MCP Client

DevGenius MCP Client for AI IDEs (Cursor, Windsurf, Trae, etc.)

## 🚀 Quick Start with uvx

**无需安装，一条命令运行！**

```bash
uvx devgenius-mcp-client
```

## 📦 Installation Methods

### Method 1: uvx (Recommended) ⭐

**优点**:
- ✅ 无需预安装依赖
- ✅ 自动创建隔离环境
- ✅ 一条命令运行

```bash
# 直接运行（uvx 会自动安装依赖）
uvx devgenius-mcp-client
```

### Method 2: pip

```bash
pip install devgenius-mcp-client
devgenius-mcp
```

### Method 3: pipx

```bash
pipx install devgenius-mcp-client
devgenius-mcp
```

## 🔧 AI IDE Configuration

### Trae IDE

```json
{
  "mcpServers": {
    "devgenius": {
      "command": "uvx",
      "args": ["devgenius-mcp-client"],
      "env": {
        "DEVGENIUS_MCP_TOKEN": "mcp_你的Token",
        "DEVGENIUS_API_URL": "http://localhost:8000/api/v1/mcp"
      }
    }
  }
}
```

### Cursor IDE

```json
{
  "mcp": {
    "servers": {
      "devgenius": {
        "command": "uvx",
        "args": ["devgenius-mcp-client"],
        "env": {
          "DEVGENIUS_MCP_TOKEN": "mcp_你的Token",
          "DEVGENIUS_API_URL": "http://localhost:8000/api/v1/mcp"
        }
      }
    }
  }
}
```

### Windsurf IDE

Same as Cursor.

## 🌐 Environment Variables

- `DEVGENIUS_MCP_TOKEN` - Your MCP Token (required)
- `DEVGENIUS_API_URL` - API URL (default: `http://localhost:8000/api/v1/mcp`)

## 📚 Available Tools

1. `get_project_context` - Get project context
2. `get_my_tasks` - Get my task list
3. `claim_task` - Claim a task
4. `update_task_status` - Update task status
5. `split_task_into_subtasks` - Split task into subtasks
6. `get_task_subtasks` - Get subtasks
7. `update_subtask_status` - Update subtask status
8. `list_documents` - List documents
9. `get_document_by_title` - Get document by title
10. `search_documents` - Search documents

## 🔍 Troubleshooting

### uvx not found

Install uv first:

```bash
# Windows (PowerShell)
irm https://astral.sh/uv/install.ps1 | iex

# macOS/Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### Token not set

Make sure `DEVGENIUS_MCP_TOKEN` is set in the AI IDE configuration.

## 📝 License

MIT
