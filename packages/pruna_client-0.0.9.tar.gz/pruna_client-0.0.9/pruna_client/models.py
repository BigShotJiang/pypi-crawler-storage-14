"""Data models for Pruna API responses."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class PredictionStatus(str, Enum):
    """Current status of the prediction."""

    STARTING = "starting"
    PROCESSING = "processing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELED = "canceled"


@dataclass
class Response:
    """Unified response class for Pruna API predictions."""

    id: str
    model: str
    inputs: dict[str, Any]
    status: PredictionStatus = PredictionStatus.SUCCEEDED
    response: dict[str, Any] = field(default_factory=dict)
