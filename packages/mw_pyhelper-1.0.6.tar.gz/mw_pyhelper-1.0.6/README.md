# mw_pyhelper

A set of python helper classes / utilities from MicWan

### Command to build and check
``` bash
#Build
python -m build

#Check the packages
twine check dist/*
```