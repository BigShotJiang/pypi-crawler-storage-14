DEFAULT_USER_AGENT_CHROME = r'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'

CFG_KEY_BROWSER_BINARY = 'mw_pyhelper.webbot.browserBinary'
CFG_KEY_BROWSER_TYPE = 'mw_pyhelper.webbot.browserType'
CFG_KEY_HEADLESS_MODE = 'mw_pyhelper.webbot.headlessMode'
CFG_KEY_EXPLICIT_WAIT_TIMEOUT = 'mw_pyhelper.webbot.explicitWaitTimeout'