#All Rights Reserved
#Copyrights Suchana SpaceExpo, 2025
#CubeAPI Authors | Anu Electronics



# SPDX-License-Identifier: Proprietary

# All Rights Reserved Ã‚Â© Suchana SpaceExpo, 2025
# CubeAPI Authors | Anu Electronics
#
# This software, including the CubeAPI, is the exclusive proprietary property
# of Suchana SpaceExpo and Anu Electronics. It is not open source and may
# not be copied, distributed, modified, or used without the express written
# permission of Suchana SpaceExpo and Anu Electronics.
#
# Unauthorized use, duplication, or distribution is strictly prohibited and
# may result in civil and criminal penalties.
#
# Suchana SpaceExpo and Anu Electronics reserve all rights, titles, and
# interests in the software and documentation.


# All Rights Reserved Â© Suchana SpaceExpo, 2025
# CubeAPI Authors | Anu Electronics
# SPDX-License-Identifier: Proprietary



import datetime, threading
import pkgutil
import tempfile
import os
from pathlib import Path

# Google Firebase
import firebase_admin
from firebase_admin import credentials, db, auth, storage

# Ultralytics YOLO Object Recognition
import signal, sys, os, platform, uuid, requests, json
from collections import defaultdict, deque
import subprocess as sp, hashlib
from ultralytics import YOLO
import cv2, time

# OpenCV Face Detection
import matplotlib.pyplot as plt
import numpy as np

# Import necessary Google modules
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.auth.transport.requests import Request

# Libraries to send mail
import mimetypes, base64
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders



def load_pkg_file(filename):
    """
    Return absolute path for packaged or bundled resources.
    Works in:
    ✔ PyInstaller EXE
    ✔ pip installed package
    ✔ normal script run
    """
    # PyInstaller temp folder
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, filename)

    # PIP package or script path
    data = pkgutil.get_data("suchana_grp7_cam", filename)
    if data is not None:
        temp = tempfile.NamedTemporaryFile(delete=False)
        temp.write(data)
        temp.close()
        return temp.name

    # Fallback for debug mode
    return os.path.join(os.path.dirname(__file__), filename)

# ======================= GOOGLE CONFIG =======================
print(Path.home())
CLIENT_SECRETS_FILE = load_pkg_file("credential.json")
FIREBASE_ADMIN_KEY = load_pkg_file("grp7-suchana-b6c41-firebase-adminsdk-fbsvc-af0323250b.json")
HAAR_PATH = load_pkg_file("haarcascade_frontalface_default.xml")
LOGO_PATH = load_pkg_file("logo.ico")
TOKEN_PATH = Path.home()/"token.json"
print(TOKEN_PATH)

SCOPES = ['https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/gmail.send']
FOLDER_ID = '11TcV72_1Id1GHBf-pGyJ1boSz5dj1Qiq'

# ======================= Logging =======================
timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
log_entry = f"Script executed at: {timestamp}\n"
with open("log.txt", "a") as log_file:
    log_file.write(log_entry)
print("Log entry added.")


# --- GOOGLE AUTH SETUP ---
SCOPES = ['https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/gmail.send']
FOLDER_ID = '11TcV72_1Id1GHBf-pGyJ1boSz5dj1Qiq'
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS_FILE, SCOPES)

# --- FIREBASE SETUP ---
with open(FIREBASE_ADMIN_KEY) as f:
    firebase_config = json.load(f)

# ======================= OpenCV Face Detection =======================
cascade_path = HAAR_PATH
face_classifier = cv2.CascadeClassifier(cascade_path)
os.makedirs("images", exist_ok=True)
last_capture = 0


mode_to_colormap = {
    0: None,
    1: cv2.COLORMAP_JET,
    2: cv2.COLORMAP_OCEAN,
    3: cv2.COLORMAP_TURBO,
    4: cv2.COLORMAP_MAGMA,
    5: cv2.COLORMAP_HOT,
    6: cv2.COLORMAP_RAINBOW
}


def send_email(service, to, subject, msg, enclosure):
    mail = MIMEMultipart()
    mail['to'] = to
    mail['subject'] = subject
    
    msg = MIMEText(msg, 'html')
    mail.attach(msg)
    if enclosure and os.path.exists(enclosure):
        try:
            ctype, encoding = mimetypes.guess_type(enclosure)
            if ctype is None or encoding is not None:
                ctype = 'application/octet-stream'
            maintype, subtype = ctype.split('/', 1)
            part = MIMEBase(maintype, subtype)
            with open(enclosure, 'rb') as fp:
                part.set_payload(fp.read())

            encoders.encode_base64(part)

            # Add content-disposition header with the filename
            filename = os.path.basename(enclosure)
            part.add_header('Content-Disposition',
                            f'attachment; filename="{filename}"')
            
            # Attach the file part to the message
            mail.attach(part)
        except Exception as e:
            print(f"Could not attach file {enclosure}. Sending email without attachment. Error: {e}")
    
    # Encode the entire message into a raw, URL-safe base64 string
    raw_message = base64.urlsafe_b64encode(mail.as_bytes()).decode()
    
    try:
        sent_message = service.users().messages().send(
            userId='me',
            body={'raw': raw_message}
        ).execute()
        print(f"Message ID: {sent_message['id']} sent successfully.")
        return sent_message
    except Exception as e:
        print(f"An error occurred: {e}")


def authenticate_google_drive():
    creds = None
    # The file token.json stores the user's access and refresh tokens.
    if TOKEN_PATH.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_PATH), SCOPES)

    
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open(TOKEN_PATH, 'w') as token:
            token.write(creds.to_json())
    return creds

def upload_file_to_drive(file_path):
    """Uploads a file to Google Drive."""
    try:
        creds = authenticate_google_drive()
        drv_service = build('drive', 'v3', credentials=creds)
        sheets_service = build('sheets', 'v4', credentials=creds)
        gmail_service = build('gmail', 'v1', credentials=creds)

        file_metadata = {'name': os.path.basename(file_path), 'mimeType':'image/jpg','parents':[FOLDER_ID]}
        media = MediaFileUpload(file_path, mimetype="image/jpg", resumable=True)
        file = drv_service.files().create(body=file_metadata, media_body=media, fields='id').execute()
        print(f"File '{os.path.basename(file_path)}' with ID: {file.get('id')} has been uploaded successfully.")
        
        receiver_email = 'hemanthabhiram.official@gmail.com' # Replace with recipient email
        subject = 'File Uploaded to Google Drive'
        message_body = f"<b>Notification from Drone</b><br/><br/>&emsp;Dear admin, I've captured a new image and uploded into drive.<br/><br/>The file <strong>'{os.path.basename(file_path)}'</strong> has been uploaded to Google Drive with ID: <strong>{file.get('id')}</strong><br/><br/><br/>With Regards,<br/>Yours Drone."
        send_email(gmail_service, receiver_email, subject, message_body, file_path)
        
    except Exception as e:
        print(f"An error occurred: {e}")

# ===== GOOGLE SHEET LOG UPLOAD ===== #

LOG_SHEET_NAME = "CubeAPI Logs"

def init_google_sheets():
    creds = authenticate_google_drive()
    service = build("sheets", "v4", credentials=creds)

    # Check if sheet already exists, else create new
    spreadsheet_id = None

    with open("sheet_id.txt", "a+") as f:
        f.seek(0)
        spreadsheet_id = f.read().strip()

    if spreadsheet_id:
        return spreadsheet_id, service

    # Create a new spreadsheet
    sheet_metadata = {
        "properties": {"title": LOG_SHEET_NAME},
        "sheets": [{
            "properties": {
                "title": "Logs",
                "gridProperties": {"rowCount": 1000, "columnCount": 10}
            }
        }]
    }

    sheet = service.spreadsheets().create(body=sheet_metadata,
                                          fields="spreadsheetId").execute()
    spreadsheet_id = sheet.get("spreadsheetId")

    # Save ID locally so we reuse same sheet next time
    with open("sheet_id.txt", "w") as f:
        f.write(spreadsheet_id)

    return spreadsheet_id, service


def log_event_to_sheet(event, file_path=None, extra_info=""):
    try:
        spreadsheet_id, service = init_google_sheets()
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Log row format
        values = [[
            timestamp,
            event,
            os.path.basename(file_path) if file_path else "-",
            extra_info
        ]]

        body = {"values": values}
        service.spreadsheets().values().append(
            spreadsheetId=spreadsheet_id,
            range="Logs!A1",
            valueInputOption="USER_ENTERED",
            insertDataOption="INSERT_ROWS",
            body=body
        ).execute()

        print(f"Logged to Google Sheets: {event}")

    except Exception as e:
        print("Sheet Logging Failed:", e)


# Create credentials object using dictionary
cred = credentials.Certificate(firebase_config)
firebase_admin.initialize_app(cred, {
    "databaseURL": "https://grp7-suchana-b6c41-default-rtdb.asia-southeast1.firebasedatabase.app"
})

def check_access():
    try:
        status_ref = db.reference('/config/enabled_status')
        status = status_ref.get()

        if status is None:
            print("⚠ No license status found in DB!")
            return False

        if int(status) == 1:
            print("✔ Access Granted — License Active")
            return True
        else:
            print("❌ Insufficient Balance — License Disabled")
            return False

    except Exception as e:
        print("License Check Failed:", e)
        return False


ref = db.reference('/config/mode')
mode_value = ref.get()

# Convert to OpenCV colormap
colormap = mode_to_colormap.get(mode_value, None)

# Listener handler
def listener(event):
    mode_value = event.data
    print("Mode updated:", mode_value)

    global colormap
    colormap = mode_to_colormap.get(mode_value, None)

db.reference('/config/mode').listen(listener) #auto-update


target = db.reference('/config/track').get()

# Listener handler
def listener(event):
    trgt = event.data
    print("Target updated:", trgt)

    global target
    target = trgt

db.reference('/config/track').listen(listener) #auto-update



ref_size = db.reference('/config/track_size')
target_size = ref_size.get() or 12  # fallback if None

def size_listener(event):
    global target_size
    if event.data is not None:
        target_size = int(event.data)
        print("Target size updated:", target_size)

ref_size.listen(size_listener)


scroll_x = 0
scroll_speed = 3  # adjust speed
watermark_text = "SUCHANA SPACEEXPO © 2025  "



client_id = str(uuid.uuid4())
MACHINE_ID = hashlib.sha256(f"{uuid.getnode()}-{platform.processor()}-{platform.node()}-{platform.system()}".encode()).hexdigest()
STREAM_KEY = "fpf5-g5hw-hzc1-72fr-fmt9"
YOUTUBE_URL = f"rtmps://b.rtmp.youtube.com/live2/{STREAM_KEY}?backup=1" #Backup URL
SUCHANA_LICENSE = "SE-7H9F-3KQ2-PY91-LS0Z"
GA4_API_SECRET = "-M62YnUBS2qR5jeHlKVpbg"
GA4_MEASUREMENT_ID = "G-ZL7KJ64CED"
STREAM_ID = "13063315487"
url = f"https://www.google-analytics.com/mp/collect?measurement_id={GA4_MEASUREMENT_ID}&api_secret={GA4_API_SECRET}"


ffmpeg_cmd = [
r"ffmpeg.exe","-re","-f","rawvideo","-pix_fmt","bgr24","-s","1920x1080",
"-r","20","-i","-","-f","lavfi","-i","anullsrc=channel_layout=mono:sample_rate=44100","-c:v","libx264",
"-pix_fmt", "yuv420p","-preset", "veryfast","-b:v", "6000k","-maxrate", "7000k","-bufsize", "12000k","-g","60",
"-tune", "film","-x264opts", "aq-mode=2:ref=4:me=hex","-profile:v", "high",
"-c:a", "aac","-b:a", "160k","-ar", "44100","-f", "flv", YOUTUBE_URL
]


def ga_send_event(event_name, params=None):
    if params is None:
        params = {}

    payload = {
        "client_id": client_id,
        "events": [{
            "name": event_name,
            "params": {
                **params,
                "device_os": platform.system(),
                "python_ver": platform.python_version(),
                "app": "CubeAPI"
            }
        }]
    }

    try:
        requests.post(url, json=payload, timeout=2)
    except:
        pass

prev_hash = "CUBEAPI_INIT"
frame_index = 0

track_history = defaultdict(lambda: deque(maxlen=30))

def main():
    global last_capture
    last_capture = time.time()

    # Load YOLO model
    model = YOLO("yolov8n.pt", verbose=False)
    cv2.setNumThreads(1)
    device = "cpu"
    model.to(device)
    model.fuse()
    ga_send_event("model_load")

    process = sp.Popen(ffmpeg_cmd, stdin=sp.PIPE)
    # stdout=sp.PIPE, stderr=sp.PIPE,
    priev = time.time()

    # Setup USB Camera (cv2)
    cap = cv2.VideoCapture(0)  # /dev/video0
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

    key = cv2.waitKey(1)

    if key == 32:  # SPACE key
        cv2.imwrite(path, frame)
        print("Saved photo.jpg")
    
    def handle_exit(sig, frame):
        cap.release()
        try:
            if process.stdin:process.stdin.close()
        except:pass
        try:process.terminate()
        except:process.kill()
        try:process.wait(timeout=5)
        except:process.kill()
        cv2.destroyAllWindows()
        cv2.waitKey(1)
        sys.exit(0)
    
    signal.signal(signal.SIGINT, handle_exit)

    prev_time = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Camera not detected!")
            continue

        # YOLO Inference
        small = cv2.resize(frame, (640, 360))
        results = model(small, device=device, imgsz=320)
        annot_small = results[0].plot()  # Draw YOLO boxes
        annotated = cv2.resize(annot_small, (1920, 1080))  # Upscale for streaming

        if target==1:
            boxes = results[0].boxes

            for box in boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                cls = int(box.cls[0])
                conf = float(box.conf[0])

                # Track ID (if available)
                obj_id = int(box.id[0]) if box.id is not None else None

                # Calculate center of the box (modded for 1080p)
                cx = int((x1 + x2) / 2 * 1920 / 640)
                cy = int((y1 + y2) / 2 * 1080 / 360)

                if obj_id is not None:
                    track_history[obj_id].append((cx, cy))

                    # Draw Track Line
                    pts = track_history[obj_id]
                    for j in range(1, len(pts)):
                        cv2.line(annotated, pts[j - 1], pts[j], (0, 255, 255), 2)

                    # Draw ID label
                    cv2.putText(annotated, f"ID {obj_id}",
                        (cx - 10, cy - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                        (0, 255, 0), 2)

                # Target Lock Symbol 🎯 dynamic size
                cv2.circle(annotated, (cx, cy), target_size, (0, 0, 255), 2)
                cv2.line(annotated, (cx - target_size*2, cy), (cx + target_size*2, cy), (0, 0, 255), 1)
                cv2.line(annotated, (cx, cy - target_size*2), (cx, cy + target_size*2), (0, 0, 255), 1)


        # Thermal / IR color mapping
        gray = cv2.cvtColor(annotated, cv2.COLOR_BGR2GRAY)
        thermal = cv2.applyColorMap(gray, cv2.COLORMAP_OCEAN)

        if colormap is not None:
            annotated = cv2.applyColorMap(gray,colormap)

        
        
        # FPS Display
        curr_time = time.time()
        fps = 1 / (curr_time - prev_time) if prev_time else 0
        prev_time = curr_time

        if curr_time - last_capture >= 5:
            last_capture = curr_time

            capture_name = f"images/capture_{int(curr_time)}.jpg"
            cv2.imwrite(capture_name, annotated)

            print("📸 Saved:", capture_name)
            
            threading.Thread(
                target=upload_file_to_drive,
                args=(capture_name,),
                daemon=True
            ).start()

        #watermark = cv2.imread("suchana.png", cv2.IMREAD_UNCHANGED)
        
        
        # global prev_hash, frame_index
        # frame_bytes = annotated.tobytes()
        # full_hash = hashlib.sha256(prev_hash.encode('utf-8') + frame_bytes).hexdigest()
        # short_tag = full_hash[:10]
        
        cv2.putText(annotated,f"FPS: {fps:.1f}", (20, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1,
                    (0, 255, 0), 2)
        



        process.stdin.write(annotated.tobytes())

        cv2.imshow("YOLO - USB Camera", annotated)

        if cv2.waitKey(1) & 0xFF in [27, ord('q')]:
            handle_exit(None, None)

if check_access():
    main()
else:
    time.sleep(5)
    sys.exit(0)