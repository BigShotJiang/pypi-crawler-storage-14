"""
The application codebase is related to research and previous version of tensorcircuit,
the code inside is subject to change, be caution to use.
Most of the useful code is and will be refactored and copied to other parts of tensorcircuit.
"""
