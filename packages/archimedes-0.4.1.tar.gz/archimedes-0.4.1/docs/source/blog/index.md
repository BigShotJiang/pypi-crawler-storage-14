
# Archimedes Blog

::::{grid} 1 1 2 2
:gutter: 3

:::{grid-item-card} Introducing Archimedes
:link: 2025/introduction
:link-type: doc

6 Oct 2025 · Announcements

A Python toolkit for hardware engineering
:::

:::{grid-item-card} Spatial Mechanics
:link: 2025/spatial
:link-type: doc

20 Oct 2025 · Announcements

Inside the new `spatial` module
:::

::::
