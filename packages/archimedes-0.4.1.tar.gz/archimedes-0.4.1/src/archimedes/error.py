__all__ = [
    "ShapeDtypeError",
]


class ShapeDtypeError(ValueError):
    pass
