EARTH_MU = 3.986e14  # [m^3/s^2]
EARTH_RADIUS = 6371e3  # [m]
