class QtfException(Exception):
    pass
