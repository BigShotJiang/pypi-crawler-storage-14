from quanti_fret.apps.cli.controller import CliController  # noqa: F401


__ALL__ = ['CliController']
