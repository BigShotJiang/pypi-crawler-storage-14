from qtpy.QtWidgets import QLabel

from quanti_fret.algo import (
    BackgroundEngine, BackgroundEnginePercentile, BackgroundEngineFixed
)


class BackgroundEngineLabel(QLabel):
    """ Label whose purpose is to display a Background engine.

    It will display: "Background: {mode} ({Extra})" or "Background: -" is no
    background.
    """
    def __init__(
        self, *args, preText: str = 'Background: ', postText: str = '',
        **kwargs
    ):
        """ Constructor

        Args:
            pre_text (str): Text to display before the background
            post_text (str): Text to display after the background
        """
        super().__init__(*args, **kwargs)
        self._preText = preText
        self._postText = postText

    def setBackgroundEngine(self, engine: BackgroundEngine | None) -> None:
        """ Display the given background engine

        Args:
            engine (BackgroundEngine | None): Engine to display. If None,
                display (-) instead
        """
        text = self._preText
        if engine is None:
            text += ' - '
        else:
            text += f' {engine.mode}'
            if isinstance(engine, BackgroundEnginePercentile):
                text += f' ({engine._percentile})'
            elif isinstance(engine, BackgroundEngineFixed):
                text += f' {engine.background}'
        text += self._postText
        self.setText(text)
