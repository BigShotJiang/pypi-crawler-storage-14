from qtpy.QtCore import Qt
from qtpy.QtWidgets import QLabel


class PathLabel(QLabel):
    """ Label whose purpose is to display a Path.

    When `setText` is called, it:
        - It will crop (on the left) the text passed to the given width
        - Add the string "Path: " in front of it
        - Add as a hovering tooltip the whole path
    """
    def __init__(self, *args, max_len: int = 250, **kwargs):
        """ Constructor

        Args:
            max_len (int, optional): max len of the path. Defaults to 250.
        """
        super().__init__(*args, **kwargs)
        self._max_width = max_len

    def setText(self, a0: str | None) -> None:
        self.setToolTip(a0)
        font = self.fontMetrics()
        cropped = font.elidedText(a0, Qt.TextElideMode.ElideLeft,
                                  self._max_width)
        super().setText(f"Path: {cropped}")
