# server.py
from fastmcp import FastMCP, Client, Context

import os
import json
import asyncio
import pkgutil

from typing import List, Dict, Optional, Union

mcp = FastMCP("RealTimeX.AI Document Manifest Tools")

def get_file_hash(file_path):
    import sys
    import hashlib

    # BUF_SIZE is totally arbitrary, change for your app!
    BUF_SIZE = 65536  # lets read stuff in 64kb chunks!

    sha1 = hashlib.sha1()

    with open(file_path, 'rb') as f:
        while True:
            data = f.read(BUF_SIZE)
            if not data:
                break
            sha1.update(data)
    return str(sha1.hexdigest())

@mcp.tool
async def analyze_document_manifest(file_path:str) -> Dict:
    """Analyze manifest document."""
    import requests

    base_url = "http://testcrm.rtworkspace.com:8002"

    file_name = os.path.basename(file_path)

    url = f"{base_url}/analyze"

    files = {
        "file": (file_name, open(file_path, "rb"), "application/pdf")
    }

    response = requests.post(url, files=files)

    analysis = response.json()

    print("analysis",analysis)

    batch_id = get_file_hash(file_path)

    # result = {
    #     "status": "success",
    #     "overall_analysis_status": analysis["overall_status"],
    #     "insights": analysis["insights"],
    #     "recommended_actions": analysis["recommended_actions"],
    #     "ui-components":[
    #         {
    #             "dataType": 'mcpUi',
    #             "data": {
    #                 "content": [
    #                     {
    #                         "type": "resource",
    #                         "resource": {
    #                             "uri": f'ui://doc-manifest/{batch_id}',
    #                             "mimeType": 'text/uri-list',
    #                             "text": f'{base_url}/?batchId={batch_id}',
    #                         }
    #                     }
    #                 ]   
    #             }    
    #         }
    #     ]
    # }

    master_records = []
    for master_record_key in analysis["master_record"]:
        master_record = analysis["master_record"][master_record_key]
        master_record["field"] = master_record_key
        master_records.append(master_record)
    analysis["master_record"] = master_records

    main_widget = None
    widget_data = pkgutil.get_data('realtimex_manifest_tools', f'widgets/main.json')
    if widget_data:
        widget_data = widget_data.decode('utf-8')
        main_widget = json.loads(widget_data)
    main_widget["data"]["content"]["data"] = analysis

    # batch_id = 
    
    # with open("widget.json", 'r') as file:
    #     result = json.load(file)

    result = {
        "status": "success",
        "overall_analysis_status": analysis["overall_status"],
        "insights": analysis["insights"],
        "recommended_actions": analysis["recommended_actions"],
        "ui-components":[
            main_widget,
            {
                "dataType": "html",
                "data": {
                    "content": f'<a href="{base_url}/?batchId={batch_id}" class="border rounded-3xl hover:bg-gray-800 light:hover:bg-gray-50 transition-colors cursor-pointer group border-gray-700 light:border-gray-200 text-white dark:text-white" style="display:inline-block;padding:8px 16px;text-decoration:none;float:right;">See details</a>',
                    "language": None
                }    
            }
        ]
    }

    

    return result


# async def test():
#     async with Client(mcp) as client:
#         tools = await client.list_tools()
#         print("tools",tools)
#         result = await client.call_tool("analyze_document_manifest", {"file_path": "/Users/phuongnguyen/.realtimex.ai/storage/working-data/docmanifest/BATCH_2017_PTL_YAN_001.pdf"})
#         print(result.content[0].text)

# def main():
#     import asyncio
#     asyncio.run(test())



# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(test())

def main():
    mcp.run()