``nipoppy init``
================

.. note::
   This command calls the :py:class:`nipoppy.workflows.dataset_init.InitWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:init
   :prog: nipoppy init
