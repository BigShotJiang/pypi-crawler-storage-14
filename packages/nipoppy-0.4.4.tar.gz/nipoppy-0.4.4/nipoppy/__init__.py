"""Nipoppy."""

from nipoppy._data_retriever import NipoppyDataRetriever
