import re
from datetime import datetime
from pathlib import Path
from typing import Iterable

from docx.document import Document
from docx.text.paragraph import Paragraph
from docxcompose.composer import Composer

from report_maker.config import ComposerPartTypeTemplate as DocumentTemplateProcessorConfig
from report_maker.core.converter_base import ConverterBase
from report_maker.utils import docx_extras

variable_prefix = re.compile(re.escape('${'))
variable_suffix = re.compile(re.escape('}'))
variable_pattern = re.compile(r'\$\{(?P<name>\w[\w.]*)}')

class DocumentTemplateProcessor(ConverterBase):
    config: DocumentTemplateProcessorConfig
    template_file: Path
    
    def validate_config(self):
        if (self.config.template.is_absolute()):
            self.template_file = self.config.template
        else:
            self.template_file = self.template_loader.template_documents / self.config.template
        
        assert self.template_file.is_file(), f"Template file {self.template_file} does not exist"
        self.config.attributes.setdefault('year', datetime.now().year)
    
    def declare_extensions(self):
        pass
    def declare_tasks(self):
        pass
    def declare_styles(self):
        pass
    def define_styles(self):
        pass
    
    def replace_in_paragraphs(self, paragraphs: Iterable[Paragraph]):
        for par in paragraphs:
            if (not variable_pattern.search(par.text)):
                self.logger.debug(f"Paragraph {par.text!r} does not match the pattern, skipping...")
                continue
            else:
                self.logger.debug(f"Paragraph {par.text!r} matches the pattern, replacing...")
            
            i = 0
            while i < len(par.runs):
                run = par.runs[i]
                if ('${' not in run.text):
                    i += 1
                    continue
                
                while (not variable_pattern.search(run.text)):
                    if (i+1 >= len(par.runs)):
                        break
                    else:
                        next_run = par.runs[i+1]
                        if (next_run.style == run.style):
                            self.logger.debug(f"{run.text!r} << {next_run.text!r}")
                            run.text += next_run.text
                            docx_extras.delete_run(next_run)
                        else:
                            print("Styles differ, can't merge")
                
                run.text = variable_pattern.sub(lambda m: str(self.config.attributes.get(m.group('name'))), run.text)
                i += 1
    
    def replace_in_document(self, template: Document):
        for table in template.tables:
            for row in table.rows:
                for cell in row.cells:
                    self.replace_in_paragraphs(cell.paragraphs)
        
        self.replace_in_paragraphs(template.paragraphs)
    
    def run(self):
        template = docx_extras.document_open(self.template_file)
        self.replace_in_document(template)
        composer = Composer(self.doc)
        composer.append(template)


__all__ = \
[
    'DocumentTemplateProcessor',
    'DocumentTemplateProcessorConfig',
]
