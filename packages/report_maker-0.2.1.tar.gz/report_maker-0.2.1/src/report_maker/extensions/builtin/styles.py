import contextlib
from dataclasses import dataclass
from enum import Enum, auto
from typing import *

from dataclass_exceptions.errors import InvalidArgumentTypeError
from docx.section import Section
from docx.settings import Settings as PageSettings
from docx.shared import RGBColor
from docx.styles.style import BaseStyle, CharacterStyle, ParagraphStyle
from docx.text.paragraph import Paragraph
from pyhocon import ConfigTree
from report_maker.core.concepts import *
from report_maker.core.converter_base import ConverterBase
from report_maker.core.meta import AppendixMeta
from report_maker.utils import convertions


type RecursiveConfig[T] = ConfigTree

@dataclass(kw_only=True)
class StylesRecursiveConfig:
    section: RecursiveConfig[Section]
    page: RecursiveConfig[PageSettings]
    styles: Dict[StyleName, RecursiveConfig[BaseStyle]]

class ChapterKind(Enum):
    MainBodyUnit = auto()
    AuxiliaryUnit = auto()
    AppendixUnit = auto()


class SharedStyles(ConverterBase):
    # region Style names
    # region Regular styles
    DEFAULT_PARAGRAPH_FONT_STYLE_NAME:  StyleName = StyleName('Default Paragraph Font')
    NORMAL_STYLE_NAME:                  StyleName = StyleName('Normal')
    BODY_STYLE_NAME:                    StyleName = StyleName('Body Text')
    # endregion
    # region Header styles
    STRUCTURAL_UNIT_STYLE_NAME:         StyleName = StyleName('Heading 1 - Structural Element')
    H2_NO_NUMBERING_STYLE_NAME:         StyleName = StyleName('Heading 2 - No numbering')
    # endregion
    # region Monospace styles
    CODE_BLOCK_STYLE_NAME:              StyleName = StyleName('Code block')
    PREFORMATTED_STYLE_NAME:            StyleName = StyleName('Preformatted')
    # endregion
    # region List styles
    UNORDERED_LIST_STYLE_NAME:          StyleName = StyleName('Bullet List')
    ORDERED_LIST_STYLE_NAME:            StyleName = StyleName('Numbered List')
    # endregion
    # endregion
    # region Style objects
    # region Regular styles
    default_paragraph_font_style:   CharacterStyle = None # This is character style!!
    normal_style:                   ParagraphStyle = None
    body_style:                     ParagraphStyle = None
    # endregion
    # region Header styles
    structural_unit_style:          ParagraphStyle = None
    h2_no_numbering_style:          ParagraphStyle = None
    # endregion
    # region Monospace styles
    code_block_style:               ParagraphStyle = None
    preformatted_style:             CharacterStyle = None
    # endregion
    # region List styles
    unordered_list_style:           ParagraphStyle = None
    ordered_list_style:             ParagraphStyle = None
    # endregion
    # endregion
    
    main_section: Section
    styles_config: StylesRecursiveConfig
    
    def validate_config(self):
        config_obj: ConfigTree = self.template_loader.load_main_config()
        self.styles_config = StylesRecursiveConfig \
        (
            section = config_obj.get_config('section', ConfigTree()),
            page    = config_obj.get_config('page',    ConfigTree()),
            styles  = config_obj.get_config('styles',  ConfigTree()),
        )
    
    def declare_extensions(self):
        pass
    def declare_tasks(self):
        pass
    
    def declare_styles(self):
        # region Regular styles
        self.default_paragraph_font_style   = self.declare_style(self.DEFAULT_PARAGRAPH_FONT_STYLE_NAME, CharacterStyle)
        self.normal_style                   = self.declare_style(self.NORMAL_STYLE_NAME, ParagraphStyle)
        self.body_style                     = self.declare_style(self.BODY_STYLE_NAME, ParagraphStyle)
        # endregion
        # region Header styles
        self.structural_unit_style          = self.declare_style(self.STRUCTURAL_UNIT_STYLE_NAME, ParagraphStyle)
        self.h2_no_numbering_style          = self.declare_style(self.H2_NO_NUMBERING_STYLE_NAME, ParagraphStyle)
        # endregion
        # region Monospace styles
        self.code_block_style               = self.declare_style(self.CODE_BLOCK_STYLE_NAME, ParagraphStyle)
        self.preformatted_style             = self.declare_style(self.PREFORMATTED_STYLE_NAME, CharacterStyle)
        # endregion
        # region List styles
        self.unordered_list_style           = self.declare_style(self.UNORDERED_LIST_STYLE_NAME, ParagraphStyle)
        self.ordered_list_style             = self.declare_style(self.ORDERED_LIST_STYLE_NAME, ParagraphStyle)
        # endregion
        
        for style_name, style_obj in self.styles_config.styles.items():
            if (style_name not in self.doc.styles):
                self.doc.styles.add_style(style_name, style_obj.get_int('type'))
        
        self.main_section = self.doc.sections[0]
    
    def define_recursive_settings(self):
        self.recursively_apply(self.styles_config.section, self.main_section)
        self.recursively_apply(self.styles_config.page, self.doc.settings)
        for style_name, style in self.styles_config.styles.items():
            self.recursively_apply(style, self.doc.styles[style_name])
    
    def recursively_apply[T](self, config: Dict[str, T], element: T):
        for key, value in config.items():
            match value:
                case dict(d):
                    self.recursively_apply(d, getattr(element, key))
                    return
                case str(s) if (key.endswith('_style') and hasattr(element, key)):
                    value = self.resolve_style(StyleName(s))
                case str(s) if (key == 'rgb' and hasattr(element, key)):
                    value = RGBColor.from_string(s)
                case int() if (key == 'type'):
                    continue
                case str(s):
                    try:
                        value = convertions.parse_length_units(s)
                    except ValueError:
                        pass
            
            if (not hasattr(element, key)):
                raise KeyError(f"Element {element} has no attribute {key!r}")
            setattr(element, key, value)
    
    def clear_goddamn_builtin_defaults_for_style(self, style: StyleName | BaseStyle):
        from docx.oxml.text.font import CT_RPr
        from docx.oxml.text.parfmt import CT_PPr
        
        style: BaseStyle = self.resolve_style(style)
        
        # print(style.name, style.element.xml)
        if (isinstance(style, CharacterStyle)):
            font_xml: CT_RPr = style.element.rPr
            font_xml.remove(font_xml.rFonts)
        
        if (isinstance(style, ParagraphStyle)):
            paragraph_xml: CT_PPr = style.element.pPr
            paragraph_xml._remove_sectPr()
            paragraph_xml.remove_all('w:pBdr', 'w:spacing', 'w:keepNext')
        
        # print(style.name, style.element.xml)
    
    def define_styles(self):
        # for st in [ "Title", *(f"Heading {i}" for i in range(1, 10)) ]:
        #     self.clear_goddamn_builtin_defaults_for_style(st)
        # 
        # print(self.doc.element.xml)
        
        self.define_recursive_settings()
    
    def add_appendix(self, text: str, *, numbering: bool | None = None, sep='. ') -> Paragraph:
        prefix = "Приложение"
        if (numbering is None):
            numbering = self.meta.appendix_meta.is_numbered
        if (numbering):
            prefix += f" {next(self.meta.counters.appendix_counter)}"
        return self.doc.add_paragraph(prefix + sep + text, style=self.structural_unit_style)
    
    def add_appendix_header(self, text: str, level: int = 1, **kwargs) -> Paragraph:
        if (level == 1):
            return self.add_appendix(text, **kwargs)
        else:
            return self.add_auxiliary_header(text, level, **kwargs)
    
    def add_auxiliary_header(self, text: str, level: int = 1, **kwargs) -> Paragraph:
        style: ParagraphStyle
        match (level):
            case 1:
                style = self.structural_unit_style
            case 2:
                style = self.h2_no_numbering_style
            case _:
                style = self.doc.styles[f'Heading {level}']
        
        return self.doc.add_paragraph(text, style=style)
    
    def add_main_header(self, text: str, level: int = 1, **kwargs) -> Paragraph:
        style: ParagraphStyle = self.doc.styles[f'Heading {level}']
        return self.doc.add_paragraph(text, style=style)
    
    def add_auto_header(self, text: str, level: int = 1, chapter_kind: ChapterKind | None = None, **kwargs) -> Paragraph:
        """
        Adds a header of the specified type.
        
        Args:
            text: Header's title text
            level: Header level, starting from 1
            chapter_kind: Chapter type, a member of `ChapterType` enum,
                or `None` for auto behaviour.
            kwargs: Additional keyword arguments propagated to the implementation method,
                mainly for the appendices.
        
        Returns:
            Returns the added paragraph object.
        """
        
        impl: Callable
        match (chapter_kind):
            case ChapterKind.MainBodyUnit:
                impl = self.add_main_header
            case ChapterKind.AuxiliaryUnit:
                impl = self.add_auxiliary_header
            case ChapterKind.AppendixUnit:
                impl = self.add_appendix_header
            case None:
                impl = self.add_appendix_header if (self.meta.appendix_meta.is_appendix) else self.add_auxiliary_header
            case _:
                raise InvalidArgumentTypeError('chapter_type', (ChapterKind,), chapter_kind)
        
        return impl(text, level, **kwargs)
    
    @contextlib.contextmanager
    def apply_appendix_meta(self, new_appendix_meta: AppendixMeta):
        old_meta = self.meta.appendix_meta
        self.meta.appendix_meta = new_appendix_meta
        try:
            yield
        finally:
            self.meta.appendix_meta = old_meta
    
    def resolve_style_property[S: BaseStyle, T](self, style: StyleName | S, property_getter: Callable[[S], T | None]) -> T:
        """
        Recursively searches for the style property across style's MRO.
        
        Args:
            style: A style name or style object.
            property_getter: A getter function that takes a style object as an argument and returns the property value.
        
        Returns:
            Returns the property value or None if not found.
        """
        
        style: BaseStyle = self.resolve_style(style)
        value = None
        while (value is None and style is not None):
            try:
                value = property_getter(style)
            except AttributeError:
                pass
            
            if (isinstance(style, CharacterStyle)):
                style = style.base_style
            else:
                break
        
        return value


__all__ = \
[
    'SharedStyles',
    'ChapterKind',
]
