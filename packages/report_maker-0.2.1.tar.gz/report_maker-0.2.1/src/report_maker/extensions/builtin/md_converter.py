from __future__ import annotations

import importlib
import re
from dataclasses import dataclass, field, replace
from enum import Flag, auto
from pathlib import Path
from typing import *
from xml.etree.ElementTree import Element, fromstring as parse_xml

from dataclass_exceptions.errors import BaseExceptionABC, dataclass_exception
from docx.document import Document
from docx.shared import Length
from docx.styles.style import ParagraphStyle
from docx.text.hyperlink import Hyperlink
from docx.text.paragraph import Paragraph
from docx.text.run import Run
from markdown import Markdown

from report_maker.config import ComposerPartTypeMarkdown as MarkdownConverterConfig, DiscoveringFile
from report_maker.core.concepts import StyleName
from report_maker.core.converter_base import ConverterBase
from report_maker.core.interfaces.file_discovery import FileDiscovering
from report_maker.extensions import markdown_extensions as mdx
from report_maker.utils.docx_extras import add_hyperlink
from .hyperlinks_processor import HyperlinksProcessor
from .styles import ChapterKind, SharedStyles


# import haggis.files.docx as hg

HTMLTagName = NewType('HTMLTagName', str)

W3_NAMESPACES = \
{
    'w3':   'http://www.w3.org/1999/xhtml',
    'w3m':  'http://www.w3.org/1998/Math/MathML',
}
LIST_TAGS = (HTMLTagName('ul'), HTMLTagName('ol'))

@dataclass_exception
class UnsupportedSpecialTag(BaseExceptionABC):
    tag: HTMLTagName
    comment: str = None
    
    @property
    def message(self):
        msg = f"Unsupported special tag: {self.tag}"
        if (self.comment):
            msg += f" ({self.comment})"
        return msg

class StyleCaster:
    paragraph_styles: Dict[HTMLTagName, StyleName]
    paragraph_styles_for_structural_units: Dict[HTMLTagName, StyleName]
    paragraph_special_styles: List[HTMLTagName]
    inline_styles: Dict[HTMLTagName, StyleName]
    inline_styles_special: List[HTMLTagName]
    
    DEFAULT_PARAGRAPH_STYLES_FOR_STRUCTURAL_UNITS: ClassVar[Dict[HTMLTagName, StyleName]] = \
    {
        HTMLTagName('h1'): StyleName(SharedStyles.STRUCTURAL_UNIT_STYLE_NAME),
        HTMLTagName('h2'): StyleName(SharedStyles.H2_NO_NUMBERING_STYLE_NAME),
        # HTMLTagName('h3'): StyleName('Heading 3'),
    }
    
    DEFAULT_PARAGRAPH_STYLES_CASTER: ClassVar[Dict[HTMLTagName, StyleName]] = \
    {
        HTMLTagName('h1'):  StyleName('Heading 1 - Chapter'),
        HTMLTagName('h2'):  StyleName('Heading 2'),
        HTMLTagName('h3'):  StyleName('Heading 3'),
        HTMLTagName('h4'):  StyleName('Heading 4'),
        HTMLTagName('h5'):  StyleName('Heading 5'),
        HTMLTagName('h6'):  StyleName('Heading 6'),
        HTMLTagName('h7'):  StyleName('Heading 7'),
        HTMLTagName('h8'):  StyleName('Heading 8'),
        HTMLTagName('h9'):  StyleName('Heading 9'),
        HTMLTagName('p'):   SharedStyles.BODY_STYLE_NAME,
        HTMLTagName('pre'): SharedStyles.CODE_BLOCK_STYLE_NAME,
        HTMLTagName('ul'):  SharedStyles.UNORDERED_LIST_STYLE_NAME,
        HTMLTagName('ol'):  SharedStyles.ORDERED_LIST_STYLE_NAME,
        HTMLTagName('li'):  None,
    }
    
    DEFAULT_PARAGRAPH_SPECIAL_STYLES: List[HTMLTagName] = \
    [
        HTMLTagName('p'),
        HTMLTagName('ul'),
        HTMLTagName('ol'),
        HTMLTagName('li'),
        HTMLTagName('div'),
        HTMLTagName('pre'),
    ]
    
    DEFAULT_INLINE_STYLE_CASTER: ClassVar[Dict[HTMLTagName, StyleName]] = \
    {
        HTMLTagName('code'):    SharedStyles.PREFORMATTED_STYLE_NAME,
        HTMLTagName('em'):      StyleName('Emphasis'),
        HTMLTagName('strong'):  StyleName('Strong'),
        HTMLTagName('s'):       StyleName('Strikethrough'),
    }
    
    DEFAULT_INLINE_SPECIAL_STYLES: List[HTMLTagName] = \
    [
        HTMLTagName('a'),
        HTMLTagName('br'),
        HTMLTagName('span'),
        HTMLTagName('math'),
        HTMLTagName('img'),
    ]
    
    def __init__(self, paragraph_styles: Dict[HTMLTagName, StyleName] = None, inline_style_caster: Dict[HTMLTagName, StyleName] = None):
        self.paragraph_styles = paragraph_styles or self.DEFAULT_PARAGRAPH_STYLES_CASTER
        self.paragraph_styles_for_structural_units = self.DEFAULT_PARAGRAPH_STYLES_FOR_STRUCTURAL_UNITS
        self.paragraph_special_styles = self.DEFAULT_PARAGRAPH_SPECIAL_STYLES
        self.inline_styles = inline_style_caster or self.DEFAULT_INLINE_STYLE_CASTER
        self.inline_styles_special = self.DEFAULT_INLINE_SPECIAL_STYLES

_ROOT: Final[HTMLTagName] = HTMLTagName('ROOT')

@dataclass_exception
class EmptyStackException(BaseExceptionABC, ValueError):
    context: Context
    
    @property
    def message(self):
        return f"Empty stack for tag: {self.context.tag} (context: {self.context})"

@dataclass(frozen=True, slots=True)
class MarkdownFileTask:
    path: Path
    kind: ChapterKind

@dataclass(frozen=True, kw_only=True)
class Context:
    tag: HTMLTagName
    ns: str | None = None
    
    task: MarkdownFileTask = field(repr=False)
    list_level: int
    stack: Tuple[HTMLTagName, ...]
    element_stack: Tuple[Element, ...] = field(repr=False)
    
    parent: Document | Paragraph | Hyperlink = field(repr=False)
    
    @classmethod
    def parse_ns(cls, tag: HTMLTagName) -> Tuple[str | None, HTMLTagName]:
        if (tag and isinstance(tag, str) and tag.startswith('{') and '}' in tag):
            return cast(Tuple[str, HTMLTagName], tuple(tag[1:].split('}', 1)))
        else:
            return None, tag
    
    def __post_init__(self):
        if (self.ns is None):
            ns, tag = self.parse_ns(self.tag)
            if (ns is not None):
                object.__setattr__(self, 'ns', ns)
                object.__setattr__(self, 'tag', tag)
    
    @property
    def parent_as_document(self) -> Document:
        assert isinstance(self.parent, Document)
        return self.parent
    @property
    def parent_as_paragraph(self) -> Paragraph:
        assert isinstance(self.parent, Paragraph)
        return self.parent
    @property
    def parent_as_hyperlink(self) -> Hyperlink:
        assert isinstance(self.parent, Hyperlink)
        return self.parent
    @property
    def parent_as_run_container(self) -> Paragraph | Hyperlink:
        assert hasattr(self.parent, 'add_run')
        return cast('Paragraph | Hyperlink', self.parent)
    
    @property
    def parent_tag(self) -> HTMLTagName:
        return self.stack[-2] if (len(self.stack) > 1) else _ROOT
    @property
    def parent_element(self) -> Element:
        if (len(self.element_stack) > 1):
            return self.element_stack[-2]
        else:
            raise EmptyStackException(self)
    
    def push(self, element: Element, *, enter_list: bool | None = None, **kwargs) -> 'Context':
        tag = HTMLTagName(element.tag)
        if (enter_list is None):
            enter_list = tag in LIST_TAGS
        return replace(self, tag=tag, list_level=self.list_level + int(enter_list), stack=(*self.stack, tag), element_stack=(*self.element_stack, element), **kwargs)
    
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

class MarkdownConverterFlags(Flag):
    katex = auto()
    pygments = auto()

type HtmlElementProcessor = Callable[[Element, Context], Run | Paragraph | Hyperlink | None]

class MarkdownConverter(ConverterBase, FileDiscovering[MarkdownConverterConfig, MarkdownFileTask]):
    config: MarkdownConverterConfig
    stylesheet: SharedStyles
    hyperlinks_processor: HyperlinksProcessor
    style_caster: StyleCaster
    files: List[MarkdownFileTask]
    md: Markdown
    processors: List[Tuple[Container[HTMLTagName], HtmlElementProcessor]]
    flags: MarkdownConverterFlags = MarkdownConverterFlags(0)
    
    # region Stage: Configuration validation
    def init_tag_processors(self):
        self.processors = \
        [
            (self.style_caster.paragraph_special_styles,    self.process_paragraph_special),
            (self.style_caster.paragraph_styles,            self.process_top_level_element),
            (self.style_caster.inline_styles,               self.process_inner_element),
            (self.style_caster.inline_styles_special,       self.process_inline_special),
        ]
    
    def set_flag(self, flag: MarkdownConverterFlags, *module_names: str):
        try:
            for module_name in module_names:
                importlib.import_module(module_name)
        except ImportError:
            pass
        else:
            self.flags |= flag
    
    def init_flags(self):
        self.set_flag(MarkdownConverterFlags.katex, 'markdown_katex', 'math2docx')
        self.set_flag(MarkdownConverterFlags.pygments, 'pygments')
    
    def validate_config(self):
        self.style_caster = StyleCaster()
        self.init_tag_processors()
        self.init_flags()
    # endregion
    # region Stage: Extensions Declaration
    def optional_extension(self, ext_name: str, flag: MarkdownConverterFlags = None) -> str | None:
        if (flag is None):
            flag = MarkdownConverterFlags[ext_name]
        
        if (flag in self.flags):
            return ext_name
        else:
            return None
    
    def init_md_processor(self):
        extensions: List[str | None] = \
        [
            'fenced_code',
            self.optional_extension('codehilite', MarkdownConverterFlags.pygments),
            self.optional_extension('markdown_katex', MarkdownConverterFlags.katex),
            f'{mdx.__name__}.markdown_pretty_lists',
            f'{mdx.__name__}.markdown_strikethrough',
            f'{mdx.__name__}.markdown_symbols_replacement',
        ]
        ext_cfg: Dict[str, Dict[str, Any]] = \
        {
            'markdown_katex': { 'insert_fonts_css': False },
        }
        self.md = Markdown(extensions=[ ext for ext in extensions if (ext is not None) ], extension_configs=ext_cfg)
        self.md.stripTopLevelTags = False
        
        return self.md
    
    def declare_extensions(self):
        self.stylesheet = self.declare_extension(SharedStyles)
        self.hyperlinks_processor = self.declare_extension(HyperlinksProcessor)
        self.init_md_processor()
    # endregion
    # region Stage: Tasks Declaration
    def make_task(self, file: Path, df: DiscoveringFile | None = None) -> MarkdownFileTask:
        if (self.meta.appendix_meta.is_appendix):
            kind = ChapterKind.AppendixUnit
        elif (df.is_main_body if (df is not None) else file.name.startswith('chapter-')):
            kind = ChapterKind.MainBodyUnit
        else:
            kind = ChapterKind.AuxiliaryUnit
        
        return MarkdownFileTask(file, kind)
    def declare_tasks(self):
        self.files = self.discover_files(self.config)
    # endregion
    # region Stage: Styles (empty)
    def declare_styles(self):
        self.declare_style(StyleName('Figure'), ParagraphStyle)
        self.declare_style(StyleName('Figure Caption'), ParagraphStyle)
    def define_styles(self):
        pass
    # endregion
    # region Stage: Processing
    def md_processor_root(self, root_element: Element, *, context: Context):
        assert isinstance(root_element, Element)
        assert root_element.tag == 'div'
        assert root_element.text.strip() == ''
        context = replace(context, element_stack=(root_element, ))
        for el in root_element:
            self.process_element(el, None, context)
    
    def process_element(self, element: Element, parent: Document | Paragraph | Hyperlink | None, context: Context):
        with context.push(element, parent=parent or context.parent) as ctx:
            self.logger.debug(f"Processing element: {ctx}")
            for tags, processor in self.processors:
                if (ctx.tag in tags):
                    return processor(element, ctx)
            else:
                self.logger.warning(f"Unknown tag: {ctx.tag}{f'[{ctx.ns}]' if (ctx.ns) else ''}")
                return None
    
    def elem_text(self, element: Element, context: Context, *, ignore_whitespaces: bool = None) -> str:
        text = (element.text or '')
        if (ignore_whitespaces or (ignore_whitespaces is None and HTMLTagName('pre') not in context.stack)):
            text = re.sub(r'\s+', ' ', text)
        
        return text.strip('\n')
    
    @overload
    def _add_paragraph_impl(self, element: Element, text: str | None, style: StyleName | None, context: Context, *, process_children: bool = True, skip: Literal[True]) -> None:
        ...
    @overload
    def _add_paragraph_impl(self, element: Element, text: str | None, style: StyleName | None, context: Context, *, process_children: bool = True, skip: Literal[False] = False) -> Paragraph:
        ...
    def _add_paragraph_impl(self, element: Element, text: str | None, style: StyleName | None, context: Context, *, process_children: bool = True, skip: bool = False) -> Paragraph | None:
        p: Paragraph | None = None
        if (not skip):
            p = self.doc.add_paragraph(text or '', style)
        if (process_children):
            for el in element:
                self.process_element(el, p, context)
        assert not (element.tail and element.tail.strip('\n')), "Cannot have tail for top-level elements"
        return p
    
    def _add_run_impl(self, element: Element, text: str | None, style: StyleName | None, context: Context, *, process_children: bool = True, keep_linebreaks: bool = False) -> Run | None:
        run: Run | None = None
        if (text is not None):
            run = context.parent_as_run_container.add_run(text, style)
        
        if (process_children):
            for el in element:
                self.process_element(el, None, context)
        if (tail_text := element.tail):
            if (not keep_linebreaks):
                tail_text = tail_text.replace('\n', ' ')
            context.parent_as_run_container.add_run(tail_text)
        
        return run
    
    @overload
    def _add_image_impl(self, element: Element, context: Context, *, width: int | Length | None = None, height: int | Length | None = None, **kwargs) -> Run: ...
    def _add_image_impl(self, element: Element, context: Context, **kwargs):
        if (not (src := element.attrib.get('src'))):
            raise AssertionError(f"Missing required `src` attribute for image in {context}")
        
        img_path = Path(src)
        if (not img_path.is_absolute()):
            img_path = context.task.path.parent / img_path
        #  ToDo: elif is_url
        
        for attr in ('width', 'height'):
            if ((val := element.attrib.get(attr, None)) is not None and val != 'auto'):
                kwargs[attr] = val
        
        run = self._add_run_impl(element, '', None, context)
        run.add_picture(str(img_path), **kwargs)
        return run
    
    def process_top_level_element(self, element: Element, context: Context) -> Paragraph:
        self.logger.debug(f"Processing top-level element: {context.tag}")
        text = self.elem_text(element, context)
        
        st: StyleName = self.style_caster.paragraph_styles[context.tag]
        if (context.task.kind != ChapterKind.MainBodyUnit):
            st = self.style_caster.paragraph_styles_for_structural_units.get(context.tag, st)
        assert len(context.stack) == 1, f"Top-level tag `<{context.tag}>` must be top-level"
        return self._add_paragraph_impl(element, text or None, st, context)
    
    def process_paragraph_special(self, element: Element, context: Context) -> Paragraph | None:
        self.logger.debug(f"Processing special paragraph: {context.tag}")
        text = self.elem_text(element, context)
        
        match str(context.tag):
            case 'p':
                # special case for the top-level paragraph math code blocks
                if (self.flags & MarkdownConverterFlags.katex):
                    if (context.stack == ('p', 'p')):
                        if ((katex := element.find('.//span[@class="katex"]', namespaces=W3_NAMESPACES)) is not None):
                            p = self.doc.add_paragraph(style=self.stylesheet.body_style)
                            return cast('Paragraph', self.process_element(katex, p, context))
                
                # else: fallback to default top-level processing
                return self.process_top_level_element(element, context)
            
            case 'li':
                assert context.parent_tag in LIST_TAGS, f"`<{context.tag}>` tags require direct parent of `<ul>` or `<ol>`"
                assert text.strip() or len(element) > 0, f"`<{context.tag}>` tags cannot have both empty text and no children"
                
                st = self.style_caster.paragraph_styles[context.stack[-2]]
                assert st is not None, f"Cannot determine list style for `<{context.tag}>` tag"
                assert context.list_level > 0, f"`<{context.tag}>` require list level > 0"
                if (context.list_level > 1):
                    st += f' {context.list_level}'
                
                p = self._add_paragraph_impl(element, text, st, context, skip=False)
                return p
            
            case tag if tag in LIST_TAGS:
                assert not text.strip(), f"Top-level `<{context.tag}>` tags cannot have text"
                assert context.parent_tag in ('li', _ROOT), f"`<{context.tag}>` tags require direct parent of `<li>`, or be the top-level"
                self._add_paragraph_impl(element, None, None, context, skip=True)
                return None
            
            case 'div':
                # raise NotImplementedError("`div` tags are not supported")
                assert not text.strip(), f"Top-level `<{context.tag}>` tags cannot have text"
                self._add_paragraph_impl(element, None, None, context, skip=True)
                return None
            
            case 'pre':
                text = self.elem_text(element, context)
                st: StyleName = self.style_caster.paragraph_styles[context.tag]
                return self._add_paragraph_impl(element, text or None, st, context)
            
            case _:
                raise UnsupportedSpecialTag(context.tag)
    
    def process_inner_element(self, element: Element, context: Context) -> Run:
        self.logger.debug(f"Processing inner element: {context.tag}")
        text = self.elem_text(element, context)
        style = self.style_caster.inline_styles[context.tag]
        return cast('Run', self._add_run_impl(element, text or None, style, context))
    
    def process_inline_special(self, element: Element, context: Context) -> Run | None:
        self.logger.debug(f"Processing special inline element: {context.tag}")
        run: Run | None = None
        match str(context.tag):
            case 'a':
                if (href := element.attrib.get('href', '')):
                    # ToDo: dynamically deduce externality
                    text = self.elem_text(element, context) or None
                    new_parent = add_hyperlink(context.parent_as_paragraph, href, text, is_external=True)
                    context = replace(context, parent=new_parent)
                    run = self._add_run_impl(element, None, None, context)
                else:
                    raise AssertionError("Link without href")
            
            case 'br':
                context.parent_as_run_container.add_run('\n')
            
            case 'span' if (element.attrib.get('class', None) == 'katex'):
                if (MarkdownConverterFlags.katex not in self.flags):
                    raise UnsupportedSpecialTag(context.tag, comment="LaTeX/KaTeX support is not enabled, missing required modules")
                math = element.find('.//w3m:math', namespaces=W3_NAMESPACES)
                assert math is not None, "Unable to find `w3m:math` element for KaTeX `<span>` element."
                self.process_element(math, None, context)
                return self._add_run_impl(element, None, None, context, process_children=False)
            
            case 'span' if (MarkdownConverterFlags.pygments in self.flags):
                # ToDo: Implement formatting here
                run = self._add_run_impl(element, element.text, None, context, keep_linebreaks=True)
            
            case 'math' if (context.ns == W3_NAMESPACES['w3m']):
                if (MarkdownConverterFlags.katex not in self.flags):
                    raise UnsupportedSpecialTag(context.tag, comment="LaTeX/KaTeX support is not enabled, missing required modules")
                
                import math2docx
                
                annotation = element.find('./w3m:semantics/w3m:annotation', namespaces=W3_NAMESPACES)
                annotation_text = self.elem_text(annotation, context, ignore_whitespaces=False)
                math2docx.add_math(context.parent, annotation_text)
                return self._add_run_impl(element, None, None, context, process_children=False)
            
            case 'img' if (len(context.parent_element) == 1 and not self.elem_text(context.parent_element, context) and not element.tail): # Standalone image
                assert context.parent_tag == 'p', f"Standalone image must be inside a paragraph"
                assert len(element) == 0, f"Standalone image cannot have children"
                
                context.parent_as_paragraph.style = self.resolve_style(StyleName("Figure"))
                
                li = self.stylesheet.resolve_style_property(context.parent_as_paragraph.style, lambda st: st.paragraph_format.left_indent) or 0
                ri = self.stylesheet.resolve_style_property(context.parent_as_paragraph.style, lambda st: st.paragraph_format.right_indent) or 0
                lm = self.doc.sections[0].left_margin or 0
                rm = self.doc.sections[0].right_margin or 0
                pw  = self.doc.sections[0].page_width
                if (pw):
                    img_width = pw - (lm + li + ri + rm)
                    img_width *= .75
                    img_width = int(img_width)
                else:
                    img_width = None
                
                run = self._add_image_impl(element, context, width=img_width)
                if ((title := element.attrib.get('title', None)) is not None):
                    # ToDo: Remove Russian hardcoded text token from here
                    text = f"Рисунок {next(self.meta.counters.images_counter)} – {title}"
                    self._add_paragraph_impl(element, text, self.resolve_style(StyleName("Figure Caption")), context, process_children=False)
            
            case 'img': # inline image
                run = self._add_image_impl(element, context, height=self.stylesheet.resolve_style_property(context.parent_as_paragraph.style, lambda st: st.font.size))
            
            case _:
                raise UnsupportedSpecialTag(context.tag)
        
        return run
    
    def process_task(self, task: MarkdownFileTask):
        with self.step(f"Processing file: {task.path}"):
            # Intentionally disabled
            # noinspection PyTypeChecker
            ctx = Context(task=task, stack=tuple(), list_level=0, parent=self.doc, tag=..., element_stack=...)
            
            # Markdown converter results in empty string when the source file is empty.
            if html := self.md.convert(task.path.read_text()):
                self.md_processor_root(parse_xml(html), context=ctx)
    
    def run(self):
        for task in self.files:
            self.process_task(task)
    # endregion


__all__ = \
[
    'MarkdownConverter',
    'MarkdownConverterConfig',
    'MarkdownConverterFlags',
]
