import license as license_lib
from docx.shared import Pt
from docx.styles.style import ParagraphStyle
from license.licenses import License

from report_maker.config import ComposerPartTypeLicense as LicenseConfig
from report_maker.core.concepts import StyleName
from report_maker.core.converter_base import ConverterBase
from .styles import SharedStyles


class LicenseConverter(ConverterBase):
    stylesheet: SharedStyles
    config: LicenseConfig
    license_name: str
    license_obj: License | None
    license_text_style: ParagraphStyle
    
    def validate_config(self):
        pass
    def declare_extensions(self):
        self.stylesheet = self.declare_extension(SharedStyles)
    def declare_tasks(self):
        if (self.config.license_id is not None):
            self.license_obj = license_lib.find(self.config.license_id)
        else:
            self.license_obj = None
        
        self.license_name = self.config.license_name or self.license_obj.name
    def declare_styles(self):
        self.license_text_style = self.declare_style(StyleName('License Text'), ParagraphStyle)
    def define_styles(self):
        self.license_text_style.base_style = self.stylesheet.code_block_style
        if (self.config.font_size_override is not None):
            self.license_text_style.font.size = Pt(self.config.font_size_override)
    
    def run(self):
        self.stylesheet.add_auto_header(f"Лицензия {self.license_name}", sep='\n')
        
        reminder_text = f"Исходный код настоящего проекта распространяется под лицензией {self.license_name}." \
                        " Полный текст лицензии приведён ниже."
        self.doc.add_paragraph(reminder_text, self.stylesheet.body_style)
        self.doc.add_paragraph(style=self.stylesheet.body_style)
        
        if (self.config.license_file is not None):
            license_text = self.config.license_file.read_text()
        else:
            license_text = self.license_obj.render(**self.config.options)
        
        self.doc.add_paragraph(license_text, style=self.license_text_style)


__all__ = \
[
    'LicenseConverter',
    'LicenseConfig',
]
