"""
Report maker tool.
Used to convert Markdown documents into a single .docx report with proper formatting.
Automatically inserts source code as a document appendix.
"""

from collections import namedtuple

__title__ = 'report-maker'
__author__ = 'Peter Zaitcev'
__license__ = 'BSD 2-clause license'
__copyright__ = 'Copyright 2025 Peter Zaitcev'
__version__ = '0.2.1'

VersionInfo = namedtuple('VersionInfo', 'major minor micro releaselevel serial')
version_info = VersionInfo(*__version__.split('.'), releaselevel='alpha', serial=0)

__all__ = \
[
    'version_info',
    '__title__',
    '__author__',
    '__license__',
    '__copyright__',
    '__version__',
]
