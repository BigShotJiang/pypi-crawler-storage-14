import contextlib
from abc import ABC, abstractmethod
from dataclasses import dataclass
from logging import Logger, getLogger
from typing import *

from dataclass_exceptions import BaseExceptionABC, dataclass_exception
from docx.document import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.styles.style import BaseStyle, CharacterStyle, ParagraphStyle, _NumberingStyle, _TableStyle

from .concepts import *
from .interfaces.template_lodader import TemplateLoader
from .meta import Meta


@dataclass
class GlobalConfig:
    template: str
    extension_configs: Dict[Type['ConverterInterface'], Any]

class ConverterInterface(ABC):
    doc: Final[Document]
    global_config: GlobalConfig
    meta: Meta
    
    def __init__(self, doc: Document, global_config: GlobalConfig, meta: Meta):
        self.doc = doc
        self.global_config = global_config
        self.meta = meta
    
    @abstractmethod
    def validate_config(self):
        """
        Verifies the configuration integrity.
        MUST be defined even if it does nothing.
        """
    
    @abstractmethod
    def declare_extensions(self):
        """
        Declares extensions that MUST exist for this to work.
        MUST be defined even if it does nothing.
        """
    
    @abstractmethod
    def declare_tasks(self):
        """
        Locate the files to be processed.
        MUST be defined even if it does nothing.
        """
    
    @abstractmethod
    def declare_styles(self):
        """
        Declares styles that MUST exist within this document.
        MUST be defined even if it does nothing.
        """
    
    @abstractmethod
    def define_styles(self):
        """
        Implements the styles that are declared in `declare_styles`.
        MUST be defined even if it does nothing.
        """
    
    def run(self):
        """ Optional. Defines the main processing logic. """
        pass


_STYLE_CLASSES_TABLE: Dict[Type[BaseStyle], WD_STYLE_TYPE] = \
{
    ParagraphStyle: WD_STYLE_TYPE.PARAGRAPH,
    CharacterStyle: WD_STYLE_TYPE.CHARACTER,
    _TableStyle: WD_STYLE_TYPE.TABLE,
    _NumberingStyle: WD_STYLE_TYPE.LIST,
}

@dataclass_exception
class Skip(BaseExceptionABC):
    """
    Skips the current build step.
    Won't skip build stages.
    """
    
    reason: str = None
    
    @property
    def message(self):
        text = "SKIPPED"
        if (self.reason is not None):
            text += f" (reason: {self.reason})"
        
        return text


class ConverterBase(ConverterInterface, ABC):
    logger: Logger
    template_loader: TemplateLoader
    config: ...
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        if (type(self) in self.global_config.extension_configs):
            self.config = self.global_config.extension_configs[type(self)]
        
        self.logger = getLogger(f'{self.__class__.__module__}.{self.__class__.__qualname__}')
        self.template_loader = TemplateLoader(self.global_config.template)
    
    @contextlib.contextmanager
    def step(self, name: str):
        self.logger.info(f"Step: {name}")
        try:
            yield
        except Skip as skip:
            self.logger.info(f"Step: {name}: {skip.message} ...")
        except Exception as e:
            self.logger.exception(f"Step: {name}: FAILED: {e}")
            raise e
        else:
            self.logger.info(f"Step: {name}: Done")
    
    def declare_extension[T: ConverterInterface](self, ext_cls: Type[T]) -> T:
        """ Makes an extension class instance if one did not exist already. """
        
        if (ext_cls not in self.meta.extensions):
            self.meta.extensions[ext_cls] = ext_cls(self.doc, self.global_config, self.meta)
        
        return self.meta.extensions[ext_cls]
    
    @overload
    def resolve_style[T: BaseStyle](self, style: StyleName | T, *, ok_none: Literal[False] = False) -> T:
        ...
    @overload
    def resolve_style[T: BaseStyle](self, style: StyleName | T, *, ok_none: Literal[True]) -> T:
        ...
    @overload
    def resolve_style[T: BaseStyle](self, style: StyleName | T| None, *, ok_none: Literal[True]) -> T | None:
        ...
    def resolve_style[T: BaseStyle | None](self, style: StyleName | T, *, ok_none: bool = False) -> T:
        """ Casts a style name or object to a style object. """
        
        match (style):
            case None if (ok_none):
                return None
            case None if (not ok_none):
                raise ValueError("Style name cannot be None unless 'ok_none' is True")
            case str(s):
                return self.doc.styles[s]
            case BaseStyle():
                return style
            case _:
                raise TypeError(f"Invalid 'style' argument type. Must be StyleName, BaseStyle, or None, got {type(style)}")
    
    def declare_style[T: BaseStyle](self, style_name: StyleName, style_type: Type[T], base: StyleName | BaseStyle | None = None, *, pubic: bool = True) -> T:
        """
        Declares a style to be used later.
        Creates style if it does not exist.
        If the style does exist, checks that it is of the correct type.
        
        DOES NOT define any of its properties besides parent style and inheritance settings.
        Note that base these properties will be overridden
        if called multiple times with different arguments. 
        
        Args:
            style_name: Required. The name of the style.
            style_type: Required. The type of the style.
                Must be a `BaseStyle` subclass, not a `WD_STYLE_TYPE` enum value.
            base:   Optional. The name of the parent style, if any.
            pubic:  Optional, default: `True`. Whether the style is public or not.
                Non-public styles are hidden from the user interface.
        
        Returns:
            Returns the declared style object.
        """
        
        assert style_type in _STYLE_CLASSES_TABLE, f"Invalid style type: {style_type}"
        style_type_value = _STYLE_CLASSES_TABLE[style_type]
        
        style: T
        if (style_name not in self.doc.styles):
            style: ParagraphStyle = self.doc.styles.add_style(style_name, style_type_value)
        else:
            style = self.doc.styles[style_name]
            assert style.type == style_type_value, f"Style type mismatch. Expected: {style_type_value}, got {style.type}"
        
        # ToDo: Register all declared styles to check for args consistency.
        if ((base := self.resolve_style(base, ok_none=True)) is not None):
            style.base_style = base
        style.quick_style = pubic
        style.hidden = not pubic
        style.locked = False
        
        return style


__all__ = \
[
    'ConverterInterface',
    'ConverterBase',
    'Skip',
    'GlobalConfig',
]
