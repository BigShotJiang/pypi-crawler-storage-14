# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""
Contains helper class that creates ParallelRunStep for running AutoML many models train/inference runs.

"""
