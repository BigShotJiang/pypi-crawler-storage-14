from adam.commands.command import Command
from adam.commands.export.utils_export import ExportDatabases, ExportSpec, display_export_session
from adam.repl_state import ReplState, RequiredState
from adam.sql.sql_completer import SqlCompleter
from adam.utils import log2
from adam.utils_athena import Athena

class ExportUseX(Command):
    COMMAND = 'use'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ExportUseX, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ExportUseX.COMMAND

    def required(self):
        return ReplState.X

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if not args:
            if state.in_repl:
                log2('Specify database to use.')
            else:
                log2('* database is missing.')

                Command.display_help()

            return 'command-missing'

        state.export_session = args[0]
        Athena.clear_cache()

        display_export_session(state.export_session)

        return state

    def completion(self, state: ReplState):
        if state.device != ReplState.X:
            return {}

        # dict = super().completion(state, {n: None for n in Athena.database_names()})
        dict = super().completion(state, {n: None for n in ExportDatabases.database_names()})

        if state.export_session:
            dict = dict | {'select': SqlCompleter(
                lambda: ExportDatabases.table_names(state.export_session),
                dml='select',
                columns=lambda table: Athena.column_names(database=state.export_session, function='export'),
                variant='athena'
            )}

        return dict

    def help(self, _: ReplState):
        return f'{ExportUseX.COMMAND} <export db name>\t use Export Database'

# No action body, only for a help entry and auto-completion
class ExportSelectX(Command):
    COMMAND = 'select'

    def command(self):
        return ExportSelectX.COMMAND

    def required(self):
        return RequiredState.EXPORT_DB

    def help(self, _: ReplState):
        return f'<sql-select-statements>\t run queries on export database'