# CLI Reference

## Quick help

```bash
# Show top-level help
cx --help

# Show help for a subcommand
cx <subcommand> --help
```
