"""Run the mosaic layout example."""

from janela import Janela
from janela.effects import mosaic


if __name__ == "__main__":
    ja = Janela()
    mosaic(ja)
