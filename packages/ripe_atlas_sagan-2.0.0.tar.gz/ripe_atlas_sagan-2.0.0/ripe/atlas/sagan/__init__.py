# Copyright (c) 2016 RIPE NCC
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import absolute_import

from .base import Result, ResultError, ResultParseError
from .dns import DnsResult
from .http import HttpResult
from .ping import PingResult
from .ssl import SslResult
from .traceroute import TracerouteResult
from .ntp import NtpResult

from .version import __version__

__all__ = (
    "Result",
    "PingResult",
    "TracerouteResult",
    "DnsResult",
    "SslResult",
    "HttpResult",
    "NtpResult",
)
