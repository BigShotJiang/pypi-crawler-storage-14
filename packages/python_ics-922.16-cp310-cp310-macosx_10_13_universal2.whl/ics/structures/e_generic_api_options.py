# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class e_generic_api_options(enum.IntEnum):
    """A ctypes-compatible IntEnum superclass."""
    @classmethod
    def from_param(cls, obj):
        return int(obj)

    eGENERIC_API  = 0
    eADI_WIL_API  = 1


_eGenericAPIOptions = e_generic_api_options
eGenericAPIOptions = e_generic_api_options

