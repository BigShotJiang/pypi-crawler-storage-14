# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class s_wil_network_data_capture_settings(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('enabled', ctypes.c_uint8),
    ]


sWIL_NETWORK_DATA_CAPTURE_SETTINGS = s_wil_network_data_capture_settings

