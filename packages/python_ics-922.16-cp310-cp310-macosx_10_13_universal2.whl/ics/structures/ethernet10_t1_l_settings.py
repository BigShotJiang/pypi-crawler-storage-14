# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class ethernet10_t1_l_settings(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('tx_mode', ctypes.c_uint8),
        ('rsvd', ctypes.c_uint8 * 7),
    ]


ETHERNET10T1L_SETTINGS_t = ethernet10_t1_l_settings
ETHERNET10T1L_SETTINGS = ethernet10_t1_l_settings

