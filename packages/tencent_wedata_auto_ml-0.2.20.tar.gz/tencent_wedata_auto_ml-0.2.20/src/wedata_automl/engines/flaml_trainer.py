"""
FLAMLTrainer - FLAML 训练器

封装 FLAML 训练逻辑，支持 Databricks 风格的参数
"""
import traceback
from typing import Any, Dict, List, Optional, Union
import logging
import time
import os
import uuid
import tempfile
from datetime import datetime
import pandas as pd
import numpy as np
import mlflow
from sklearn.pipeline import Pipeline as SkPipe

# Robust import for FLAML
try:
    from flaml import AutoML
    import flaml as flaml_pkg
except ImportError:
    try:
        from flaml.automl.automl import AutoML
        import flaml as flaml_pkg
    except ImportError as e:
        raise ImportError(
            "Cannot import AutoML from flaml. "
            "Please install flaml with AutoML support: pip install 'flaml[automl]==2.3.6'"
        ) from e

from wedata_automl.summary import AutoMLSummary
from wedata_automl.utils.sk_pipeline import build_numeric_preprocessor
from wedata_automl.utils.spark_utils import compute_split_and_weights
from wedata_automl.utils.print_utils import safe_print, print_separator, print_header
from wedata_automl.engines.trial_hook import TrialHook

logger = logging.getLogger(__name__)


# ============================================================================
# Log 文件管理辅助函数
# ============================================================================

def generate_log_file_path(
    base_dir: Optional[str] = None,
    run_id: Optional[str] = None,
    use_timestamp: bool = True,
    use_uuid: bool = True
) -> str:
    """
    生成唯一的 FLAML log 文件路径

    解决的问题：
    1. 避免重复 fit() 时 log 被覆盖
    2. 支持多进程/多节点环境
    3. 便于日志管理和清理

    Args:
        base_dir: 基础目录，默认使用系统临时目录
        run_id: MLflow run ID，用于关联 log 文件
        use_timestamp: 是否在文件名中包含时间戳
        use_uuid: 是否在文件名中包含 UUID

    Returns:
        log 文件的完整路径

    Example:
        >>> path = generate_log_file_path()
        >>> # /tmp/wedata_automl/flaml_20251125_143022_abc123_run456.log
    """
    # 确定基础目录
    if base_dir is None:
        # 使用系统临时目录 + wedata_automl 子目录
        base_dir = os.path.join(tempfile.gettempdir(), "wedata_automl", "flaml_logs")

    # 确保目录存在
    os.makedirs(base_dir, exist_ok=True)

    # 构建文件名
    parts = ["flaml"]

    if use_timestamp:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        parts.append(timestamp)

    if use_uuid:
        short_uuid = str(uuid.uuid4())[:8]
        parts.append(short_uuid)

    if run_id:
        parts.append(f"run{run_id[:8]}")

    filename = "_".join(parts) + ".log"

    return os.path.join(base_dir, filename)


def cleanup_old_log_files(
    base_dir: Optional[str] = None,
    max_age_hours: int = 24,
    max_files: int = 100,
    dry_run: bool = False
) -> int:
    """
    清理旧的 FLAML log 文件

    解决的问题：
    1. 防止 log 文件累积过多
    2. 自动清理过期的 log 文件

    Args:
        base_dir: 基础目录，默认使用系统临时目录
        max_age_hours: 最大保留时间（小时），超过此时间的文件将被删除
        max_files: 最大保留文件数，超过此数量的旧文件将被删除
        dry_run: 是否只模拟运行（不实际删除）

    Returns:
        删除的文件数量

    Example:
        >>> # 删除 24 小时前的 log 文件
        >>> count = cleanup_old_log_files(max_age_hours=24)
        >>> print(f"Deleted {count} old log files")
    """
    if base_dir is None:
        base_dir = os.path.join(tempfile.gettempdir(), "wedata_automl", "flaml_logs")

    if not os.path.exists(base_dir):
        return 0

    import glob

    # 获取所有 log 文件
    log_files = glob.glob(os.path.join(base_dir, "flaml_*.log"))

    if not log_files:
        return 0

    # 按修改时间排序（最新的在前）
    log_files.sort(key=lambda x: os.path.getmtime(x), reverse=True)

    deleted_count = 0
    current_time = time.time()
    max_age_seconds = max_age_hours * 3600

    for i, log_file in enumerate(log_files):
        should_delete = False
        reason = ""

        # 检查是否超过最大文件数
        if i >= max_files:
            should_delete = True
            reason = f"exceeds max_files ({max_files})"

        # 检查是否超过最大保留时间
        file_age = current_time - os.path.getmtime(log_file)
        if file_age > max_age_seconds:
            should_delete = True
            reason = f"older than {max_age_hours} hours"

        if should_delete:
            if dry_run:
                safe_print(f"[DRY RUN] Would delete: {log_file} ({reason})")
            else:
                try:
                    os.remove(log_file)
                    deleted_count += 1
                    safe_print(f"Deleted old log file: {log_file} ({reason})")
                except Exception as e:
                    safe_print(f"Failed to delete {log_file}: {e}")

    return deleted_count


# ============================================================================
# MLflow Artifact 日志记录辅助函数
# ============================================================================

def log_feature_list(features: List[str]):
    """记录特征列表到 MLflow"""
    import json
    mlflow.log_dict({"features": features}, "feature_list.json")


def log_best_config_overall(config: Dict[str, Any]):
    """记录最佳配置到 MLflow"""
    import json
    mlflow.log_dict(config, "best_config_overall.json")


def log_best_config_per_estimator(config: Dict[str, Any]):
    """记录每个估计器的最佳配置到 MLflow"""
    import json
    mlflow.log_dict(config, "best_config_per_estimator.json")


def log_engine_meta(meta: Dict[str, Any]):
    """记录引擎元数据到 MLflow"""
    import json
    mlflow.log_dict(meta, "engine_meta.json")


class TrialLogger:
    """
    FLAML Trial 日志记录器

    用于记录每个 trial 的详细信息到 MLflow
    """

    def __init__(self, parent_run_id: str, features: List[str], task: str, metric: str):
        """
        初始化 Trial Logger

        Args:
            parent_run_id: 父 run 的 ID
            features: 特征列表
            task: 任务类型
            metric: 评估指标
        """
        self.parent_run_id = parent_run_id
        self.features = features
        self.task = task
        self.metric = metric
        self.trial_count = 0
        self.trial_runs = []  # 存储所有 trial 的信息

    def log_trial(self, config: Dict[str, Any], estimator: str, val_loss: float, train_time: float):
        """
        记录单个 trial 到 MLflow

        Args:
            config: 超参数配置
            estimator: 估计器名称
            val_loss: 验证集损失
            train_time: 训练时间
        """
        self.trial_count += 1

        try:
            # 创建嵌套 run
            with mlflow.start_run(run_name=f"trial_{self.trial_count}_{estimator}", nested=True) as trial_run:
                trial_run_id = trial_run.info.run_id

                # 记录参数
                mlflow.log_param("estimator", estimator)
                mlflow.log_param("trial_number", self.trial_count)
                mlflow.log_param("parent_run_id", self.parent_run_id)

                # 记录超参数
                for key, value in config.items():
                    try:
                        mlflow.log_param(f"hp_{key}", value)
                    except Exception as e:
                        # 某些值可能无法序列化
                        safe_print(f"⚠️  DEBUG: Failed to log param hp_{key}={value}: {e}")
                        mlflow.log_param(f"hp_{key}", str(value))

                # 记录指标 - 直接使用 FLAML 的原始值，不做转换
                mlflow.log_metric("val_loss", val_loss)
                mlflow.log_metric("train_time", train_time)

                # 记录特征列表
                log_feature_list(self.features)

                # 存储 trial 信息
                trial_info = {
                    "run_id": trial_run_id,
                    "trial_number": self.trial_count,
                    "estimator": estimator,
                    "val_loss": val_loss,
                    "train_time": train_time,
                    "config": config,
                }
                self.trial_runs.append(trial_info)

                safe_print(f"  Trial {self.trial_count:3d} | {estimator:15s} | val_loss={val_loss:.6f} | time={train_time:.2f}s")
        except Exception as e:
            safe_print(f"❌ DEBUG: Exception in log_trial for trial {self.trial_count}: {e}")
            import traceback
            safe_print(f"   Traceback: {traceback.format_exc()}")
            # 重新抛出异常，让外层捕获
            raise

    def get_best_trial(self) -> Dict[str, Any]:
        """
        获取最佳 trial

        Returns:
            最佳 trial 的信息字典
        """
        if not self.trial_runs:
            return None

        # 按 val_loss 排序（越小越好）
        best_trial = min(self.trial_runs, key=lambda x: x["val_loss"])
        return best_trial


class FLAMLTrainer:
    """
    FLAML 训练器
    
    封装 FLAML 训练逻辑，支持 Databricks 风格的参数
    """
    
    def __init__(
        self,
        task: str,
        target_col: str,
        timeout_minutes: int = 5,
        max_trials: Optional[int] = None,
        metric: str = "auto",
        exclude_cols: Optional[List[str]] = None,
        exclude_frameworks: Optional[List[str]] = None,
        estimator_list: Optional[List[str]] = None,
        sample_weight_col: Optional[str] = None,
        pos_label: Optional[Union[str, int]] = None,
        data_split_col: Optional[str] = None,
        experiment_name: Optional[str] = None,
        experiment_id: Optional[str] = None,
        run_name: Optional[str] = None,
        register_model: bool = True,
        model_name: Optional[str] = None,
        max_concurrent_trials: int = 1,
        use_spark: bool = False,
        custom_hp: Optional[Dict[str, Any]] = None,
        project_id: Optional[str] = None,
        log_file_dir: Optional[str] = None,
        auto_cleanup_logs: bool = True,
        log_max_age_hours: int = 24,
        log_max_files: int = 100,
        **kwargs
    ):
        """
        初始化 FLAML 训练器

        Args:
            task: 任务类型 ("classification" 或 "regression")
            target_col: 目标列名
            timeout_minutes: 超时时间（分钟）
            max_trials: 最大试验次数
            metric: 评估指标，用于选择最佳模型
                分类任务可选:
                    - 'log_loss': 对数损失（默认，推荐用于多分类）
                    - 'accuracy': 准确率（适合类别平衡的数据）
                    - 'roc_auc': ROC AUC（二分类）
                    - 'f1': F1 分数（二分类或 macro/micro F1）
                    - 'macro_f1': Macro-averaged F1（多分类，类别不平衡）
                    - 'micro_f1': Micro-averaged F1（多分类）
                    - 'roc_auc_ovr': One-vs-Rest ROC AUC（多分类）
                    - 'roc_auc_ovo': One-vs-One ROC AUC（多分类）
                    - 'precision': 精确率
                    - 'recall': 召回率
                    - 'ap': Average Precision
                回归任务可选:
                    - 'r2': R² 分数
                    - 'mse': 均方误差
                    - 'rmse': 均方根误差
                    - 'mae': 平均绝对误差
                    - 'mape': 平均绝对百分比误差
                注意: FLAML 内部会将指标转换为 val_loss（损失值，越小越好）
                      - 对于"越小越好"的指标（如 log_loss, mse）: val_loss = metric_value
                      - 对于"越大越好"的指标（如 accuracy, f1）: val_loss = 1 - metric_value
            exclude_cols: 排除的列
            exclude_frameworks: 排除的框架（已弃用，请使用 estimator_list）
            estimator_list: 估计器列表，默认 None（使用所有可用估计器）
                可选值: ["lgbm", "xgboost", "rf", "extra_tree", "lrl1"]
                例如: ["lgbm", "xgboost"] 只使用 LightGBM 和 XGBoost
                注意: lrl1 仅适用于分类任务
            sample_weight_col: 样本权重列
            pos_label: 正类标签（二分类）
            data_split_col: 数据划分列
            experiment_name: MLflow 实验名称
            experiment_id: MLflow 实验 ID
            run_name: MLflow run 名称
            register_model: 是否注册模型
            model_name: 模型名称
            max_concurrent_trials: 并发 trials 数量，默认 1（顺序执行）
                - 设置 > 1 时，FLAML 会并行执行多个 trials
                - 本地模式：使用多线程并行
                - Spark 模式：使用 Spark 分布式并行（需要设置 use_spark=True）
                - 注意：并发会增加内存和 CPU 使用
            use_spark: 是否使用 Spark 作为并行后端，默认 False
                - True: 使用 Spark 分布式执行 trials（需要 Spark 集群）
                - False: 使用本地多线程并行
                - 注意：Spark 模式不支持 GPU 训练
            custom_hp: 自定义超参数搜索空间，格式为 {estimator_name: {param_name: search_space}}
                例如: {"lgbm": {"n_estimators": {"domain": range(100, 1000), "init_value": 100}}}
            project_id: 项目 ID，用于多租户隔离（设置为实验标签 'wedata.project'）
                - 优先使用传入的 project_id 参数
                - 如果未传入，则从环境变量 WEDATA_PROJECT_ID 读取
                - 如果都未配置，则抛出 ValueError 异常
            log_file_dir: FLAML log 文件存储目录，默认 None（使用系统临时目录）
                - 建议在 DLC Spark 环境下设置为共享存储路径（如 HDFS、COS）
                - 例如: "/tmp/wedata_automl/logs" 或 "hdfs:///user/wedata/logs"
            auto_cleanup_logs: 是否自动清理旧的 log 文件，默认 True
                - True: 每次训练前自动清理过期的 log 文件
                - False: 不清理，需要手动管理
            log_max_age_hours: log 文件最大保留时间（小时），默认 24
                - 超过此时间的 log 文件将被自动清理
            log_max_files: log 文件最大保留数量，默认 100
                - 超过此数量的旧 log 文件将被自动清理
            **kwargs: 其他参数

        Raises:
            ValueError: 如果 project_id 未配置（既未传入参数，也未设置环境变量）
        """
        self.task = task
        self.target_col = target_col
        self.timeout_minutes = timeout_minutes
        self.max_trials = max_trials
        self.metric = metric if metric != "auto" else self._get_default_metric(task)
        self.exclude_cols = exclude_cols or []
        self.exclude_frameworks = exclude_frameworks or []
        self.estimator_list = estimator_list
        self.sample_weight_col = sample_weight_col
        self.pos_label = pos_label
        self.data_split_col = data_split_col
        self.experiment_name = experiment_name or "wedata_automl"
        self.experiment_id = experiment_id
        self.run_name = run_name or f"flaml_automl_{task}"
        self.register_model = register_model
        self.model_name = model_name
        self.max_concurrent_trials = max_concurrent_trials
        self.use_spark = use_spark
        self.custom_hp = custom_hp

        # Log 文件管理配置
        self.log_file_dir = log_file_dir
        self.auto_cleanup_logs = auto_cleanup_logs
        self.log_max_age_hours = log_max_age_hours
        self.log_max_files = log_max_files

        # 处理 project_id：优先使用用户传入的值，否则从环境变量读取
        self.project_id = project_id or os.environ.get("WEDATA_PROJECT_ID")

        # 验证 project_id 是否存在
        if not self.project_id:
            raise ValueError(
                "❌ 未配置 Project ID！\n"
                "请通过以下任一方式配置 Project ID：\n"
                "1. 传递 project_id 参数：classify(..., project_id='your_project_id')\n"
                "2. 设置环境变量：export WEDATA_PROJECT_ID='your_project_id'\n"
                "\n"
                "Project ID 用于多租户隔离，确保实验可以通过后端 API 正确查询。"
            )

        self.kwargs = kwargs

        # 内部状态
        self.automl = None
        self.pipeline = None
        self.features = None
        self.preprocessor = None
    
    def _get_default_metric(self, task: str) -> str:
        """获取默认指标"""
        if task == "classification":
            return "log_loss"
        elif task == "regression":
            return "deviance"
        elif task == "":
            return
        else:
            return "accuracy"
    
    def _get_estimator_list(self) -> List[str]:
        """获取估计器列表"""
        # 如果用户指定了 estimator_list，直接使用
        if self.estimator_list:
            return self.estimator_list

        # 否则使用默认列表（排除 exclude_frameworks）
        all_estimators = ["lgbm", "xgboost", "rf", "extra_tree"]
        if self.task == "classification":
            all_estimators.append("lrl1")

        # 排除指定的框架（向后兼容）
        estimators = [e for e in all_estimators if e not in self.exclude_frameworks]
        return estimators

    def _evaluate_model(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_val: pd.DataFrame,
        y_val: np.ndarray,
        X_test: pd.DataFrame,
        y_test: np.ndarray
    ) -> Dict[str, float]:
        """
        评估模型

        Returns:
            评估指标字典
        """
        metrics = {}

        if self.task == "classification":
            from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

            for name, X, y_true in [
                ("train", X_train, y_train),
                ("val", X_val, y_val),
                ("test", X_test, y_test),
            ]:
                pred = self.pipeline.predict(X)

                acc = float(accuracy_score(y_true, pred))
                f1 = float(f1_score(y_true, pred, average='weighted', zero_division=0))
                precision = float(precision_score(y_true, pred, average='weighted', zero_division=0))
                recall = float(recall_score(y_true, pred, average='weighted', zero_division=0))

                metrics[f"{name}_accuracy"] = acc
                metrics[f"{name}_f1"] = f1
                metrics[f"{name}_precision"] = precision
                metrics[f"{name}_recall"] = recall

                mlflow.log_metric(f"{name}_accuracy", acc)
                mlflow.log_metric(f"{name}_f1", f1)
                mlflow.log_metric(f"{name}_precision", precision)
                mlflow.log_metric(f"{name}_recall", recall)

                safe_print(f"{name.capitalize():5s} Set - Accuracy: {acc:.4f} | F1: {f1:.4f} | Precision: {precision:.4f} | Recall: {recall:.4f}")

        elif self.task == "regression":
            from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

            for name, X, y_true in [
                ("train", X_train, y_train),
                ("val", X_val, y_val),
                ("test", X_test, y_test),
            ]:
                pred = self.pipeline.predict(X)

                r2 = float(r2_score(y_true, pred))
                mse = float(mean_squared_error(y_true, pred))
                mae = float(mean_absolute_error(y_true, pred))
                rmse = float(np.sqrt(mse))

                metrics[f"{name}_r2"] = r2
                metrics[f"{name}_mse"] = mse
                metrics[f"{name}_mae"] = mae
                metrics[f"{name}_rmse"] = rmse

                mlflow.log_metric(f"{name}_r2", r2)
                mlflow.log_metric(f"{name}_mse", mse)
                mlflow.log_metric(f"{name}_mae", mae)
                mlflow.log_metric(f"{name}_rmse", rmse)

                safe_print(f"{name.capitalize():5s} Set - R²: {r2:.4f} | MSE: {mse:.4f} | MAE: {mae:.4f} | RMSE: {rmse:.4f}")

        return metrics
    
    def _prepare_data(
        self,
        pdf: pd.DataFrame
    ) -> tuple:
        """
        准备数据
        
        Returns:
            (X_train, y_train, X_val, y_val, X_test, y_test, features)
        """
        # 确定特征列
        disable_cols = set(self.exclude_cols) | {self.target_col}
        if self.sample_weight_col:
            disable_cols.add(self.sample_weight_col)
        if self.data_split_col:
            disable_cols.add(self.data_split_col)
        
        self.features = [c for c in pdf.columns if c not in disable_cols]

        safe_print(f"Target column: '{self.target_col}'")
        safe_print(f"Feature columns: {len(self.features)} columns")
        if len(self.features) <= 20:
            safe_print(f"  Features: {', '.join(self.features)}")
        else:
            safe_print(f"  First 10 features: {', '.join(self.features[:10])}")
            safe_print(f"  ... and {len(self.features) - 10} more")
        
        # 数据划分
        safe_print("", show_timestamp=False, show_level=False)
        if self.data_split_col and self.data_split_col in pdf.columns:
            # 使用用户提供的划分列
            pdf["_automl_split_col"] = pdf[self.data_split_col]
            safe_print(f"✅ Using user-provided split column: '{self.data_split_col}'")
        else:
            # 自动划分
            safe_print(f"Auto-generating train/val/test split (60%/20%/20%)")
            if self.task == "classification":
                safe_print(f"  Using stratified split for classification")
            split_col, sample_weights = compute_split_and_weights(
                y=pdf[self.target_col].values,
                task=self.task,
                train_ratio=0.6,
                val_ratio=0.2,
                test_ratio=0.2,
                stratify=True if self.task == "classification" else False,
                random_state=42,
            )
            pdf["_automl_split_col"] = split_col.values
            pdf["_automl_sample_weight"] = sample_weights.values
            safe_print("✅ Split generated successfully")
        
        # 分割数据
        train_df = pdf[pdf["_automl_split_col"] == 0]
        val_df = pdf[pdf["_automl_split_col"] == 1]
        test_df = pdf[pdf["_automl_split_col"] == 2]
        
        X_train = train_df[self.features]
        y_train = train_df[self.target_col].values
        
        X_val = val_df[self.features]
        y_val = val_df[self.target_col].values
        
        X_test = test_df[self.features]
        y_test = test_df[self.target_col].values

        safe_print("", show_timestamp=False, show_level=False)
        safe_print(f"Data split summary:")
        safe_print(f"  Train: {len(train_df):,} samples ({len(train_df)/len(pdf)*100:.1f}%)")
        safe_print(f"  Val:   {len(val_df):,} samples ({len(val_df)/len(pdf)*100:.1f}%)")
        safe_print(f"  Test:  {len(test_df):,} samples ({len(test_df)/len(pdf)*100:.1f}%)")
        safe_print(f"  Total: {len(pdf):,} samples")

        # 显示目标变量分布（分类任务）
        if self.task == "classification":
            safe_print("", show_timestamp=False, show_level=False)
            safe_print(f"Target distribution in training set:")
            train_dist = pd.Series(y_train).value_counts().sort_index()
            for label, count in train_dist.items():
                safe_print(f"  Class {label}: {count:,} samples ({count/len(y_train)*100:.1f}%)")

        return X_train, y_train, X_val, y_val, X_test, y_test
    
    def train(
        self,
        dataset: Union[pd.DataFrame, Any],
        spark=None
    ) -> AutoMLSummary:
        """
        训练模型
        
        Args:
            dataset: 数据集（Pandas DataFrame 或 Spark DataFrame）
            spark: Spark session（如果 dataset 是表名）
            
        Returns:
            AutoMLSummary 对象
        """
        # 转换为 Pandas DataFrame
        if isinstance(dataset, str):
            # 表名
            if spark is None:
                raise ValueError("Spark session is required when dataset is a table name")
            pdf = spark.read.table(dataset).toPandas()
        elif hasattr(dataset, "toPandas"):
            # Spark DataFrame
            pdf = dataset.toPandas()
        else:
            # Pandas DataFrame
            pdf = dataset
        
        print_separator()
        safe_print("📊 Data Loading", show_timestamp=False, show_level=False)
        print_separator()
        safe_print(f"Dataset shape: {pdf.shape} (rows × columns)")
        safe_print(f"Memory usage: {pdf.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

        # 准备数据
        safe_print("", show_timestamp=False, show_level=False)
        print_separator()
        safe_print("🔧 Data Preparation", show_timestamp=False, show_level=False)
        print_separator()
        X_train, y_train, X_val, y_val, X_test, y_test = self._prepare_data(pdf)
        
        # 构建预处理器
        safe_print("", show_timestamp=False, show_level=False)
        print_separator()
        safe_print(f"⚙️  Feature Preprocessing")
        print_separator()
        self.preprocessor = build_numeric_preprocessor(self.features)
        X_train_num = self.preprocessor.fit_transform(X_train)
        X_val_num = self.preprocessor.transform(X_val)
        X_test_num = self.preprocessor.transform(X_test)

        safe_print(f"Preprocessor fitted successfully")
        safe_print(f"  - Train set: {X_train_num.shape}")
        safe_print(f"  - Val set:   {X_val_num.shape}")
        safe_print(f"  - Test set:  {X_test_num.shape}")
        
        # 获取或创建 MLflow 实验
        safe_print("", show_timestamp=False, show_level=False)
        print_separator()
        safe_print(f"📝 MLflow Experiment Setup")
        print_separator()

        # 检查 MLflow tracking URI
        tracking_uri = mlflow.get_tracking_uri()
        safe_print(f"MLflow Tracking URI: {tracking_uri}")

        # 如果使用本地文件系统且指定了 project_id，给出警告
        if tracking_uri.startswith('file://') and self.project_id:
            warning_msg = (
                f"⚠️  WARNING: Using local file system MLflow tracking ('{tracking_uri}')\n"
                f"   Local MLflow does not support project ID validation.\n"
                f"   For production use, please set MLflow tracking URI to a remote server:\n"
                f"   Example: mlflow.set_tracking_uri('http://your-mlflow-server:5000')"
            )
            safe_print(warning_msg)
            logger.warning(warning_msg)

        # 使用 set_experiment 统一处理实验创建和设置
        # 这种方式更简单可靠，避免复杂的条件判断和装饰器冲突
        if self.experiment_id:
            # 如果指定了 experiment_id，先获取实验名称
            experiment = mlflow.get_experiment(self.experiment_id)
            experiment_name = experiment.name
            experiment_id = self.experiment_id
            safe_print(f"Using experiment by ID: {self.experiment_id}")
            safe_print(f"Experiment name: '{experiment_name}'")
        else:
            # 使用 experiment_name
            experiment_name = self.experiment_name

        # 直接使用 set_experiment，自动创建或使用现有实验
        try:
            mlflow.set_experiment(experiment_name)
        except Exception as e:
            error_msg = (
                f"❌ Failed to set experiment '{experiment_name}'. Error: {traceback.format_exc()}\n\n"
                f"This may be due to:\n"
                f"  1. MLflow backend permission issues\n"
                f"  2. Project ID '{self.project_id}' not found or invalid\n"
                f"  3. MLflow tracking server connection issues\n"
                f"  4. Backend API restrictions (e.g., project validation)\n\n"
                f"Configuration:\n"
                f"  - MLflow tracking URI: {mlflow.get_tracking_uri()}\n"
                f"  - Project ID: {self.project_id}\n"
                f"  - Experiment name: {experiment_name}\n\n"
                f"Please verify:\n"
                f"  - The project ID '{self.project_id}' exists in the backend\n"
                f"  - You have permission to create experiments in this project\n"
                f"  - The MLflow tracking server is accessible"
            )
            logger.error(error_msg)
            raise ValueError(error_msg) from e

        # 获取实验信息用于日志输出
        experiment = mlflow.get_experiment_by_name(experiment_name)

        # 检查实验是否成功创建/获取
        if experiment is None:
            error_msg = (
                f"❌ Failed to create or get experiment '{experiment_name}'. "
                f"This may be due to:\n"
                f"  1. MLflow backend permission issues\n"
                f"  2. Project ID '{self.project_id}' validation failed\n"
                f"  3. MLflow tracking server connection issues\n"
                f"  4. Backend API restrictions\n\n"
                f"Please check:\n"
                f"  - MLflow tracking URI: {mlflow.get_tracking_uri()}\n"
                f"  - Project ID: {self.project_id}\n"
                f"  - Backend server logs for more details"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        experiment_id = experiment.experiment_id

        # 判断是新创建还是使用现有实验
        if experiment.creation_time == experiment.last_update_time:
            safe_print(f"✅ Created new experiment: '{experiment_name}' (ID: {experiment_id})")
        else:
            safe_print(f"✅ Using existing experiment: '{experiment_name}' (ID: {experiment_id})")

        # 设置项目 ID 标签（用于多租户隔离）
        if self.project_id:
            try:
                mlflow.set_experiment_tag("wedata.project", self.project_id)
                safe_print(f"✅ Set project ID tag: 'wedata.project' = '{self.project_id}'")
            except Exception as e:
                safe_print(f"⚠️  Failed to set project ID tag: {e}")
                logger.warning(f"Failed to set project ID tag: {e}")

        # 开始 MLflow run
        with mlflow.start_run(run_name=self.run_name) as parent_run:
            parent_run_id = parent_run.info.run_id
            safe_print(f"Run name: '{self.run_name}'")
            safe_print(f"Run ID: {parent_run_id}")
            
            # 记录参数
            mlflow.log_params({
                "task": self.task,
                "target_col": self.target_col,
                "timeout_minutes": self.timeout_minutes,
                "metric": self.metric,
                "n_rows": len(pdf),
                "n_features": len(self.features),
            })
            
            log_feature_list(self.features)
            log_engine_meta({"engine": "flaml", "version": getattr(flaml_pkg, "__version__", "unknown")})
            
            # FLAML 设置
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"🤖 AutoML Training Configuration")
            print_separator()
            self.automl = AutoML()
            estimator_list = self._get_estimator_list()

            # 自动清理旧的 log 文件（如果启用）
            if self.auto_cleanup_logs:
                safe_print("", show_timestamp=False, show_level=False)
                safe_print("🧹 Cleaning up old log files...")
                try:
                    deleted_count = cleanup_old_log_files(
                        base_dir=self.log_file_dir,
                        max_age_hours=self.log_max_age_hours,
                        max_files=self.log_max_files,
                        dry_run=False
                    )
                    if deleted_count > 0:
                        safe_print(f"✅ Deleted {deleted_count} old log files")
                    else:
                        safe_print("✅ No old log files to clean up")
                except Exception as e:
                    safe_print(f"⚠️  Failed to cleanup old log files: {e}")

            # 生成唯一的 log 文件路径（避免重复 fit() 时被覆盖）
            log_file_path = generate_log_file_path(
                base_dir=self.log_file_dir,
                run_id=parent_run_id,
                use_timestamp=True,
                use_uuid=True
            )
            safe_print(f"📝 FLAML log file: {log_file_path}")

            settings = {
                "task": self.task,
                "metric": self.metric,
                "time_budget": int(self.timeout_minutes * 60),  # 转换为秒
                "eval_method": "holdout",
                "ensemble": False,
                "verbose": 0,  # 设置为 0 以减少日志输出
                "estimator_list": estimator_list,
                "seed": 42,
                "log_file_name": log_file_path,  # 输出日志文件以记录所有 trials
                "mlflow_logging": False,  # 禁用 FLAML 的自动 MLflow 记录，我们手动控制
                "early_stop": False,  # 禁用早停，确保运行完所有 trials
                "log_type": "all",  # 记录所有 trials，不只是更好的
                "n_concurrent_trials": self.max_concurrent_trials,  # 并发 trials 数量
                "use_spark": self.use_spark,  # 是否使用 Spark 并行后端
            }

            if self.max_trials:
                settings["max_iter"] = self.max_trials

            # 如果使用 Spark，添加 force_cancel 选项
            if self.use_spark:
                settings["force_cancel"] = True  # 超时强制取消 Spark jobs

            # 添加自定义超参数搜索空间
            if self.custom_hp:
                settings["custom_hp"] = self.custom_hp
                safe_print(f"Custom hyperparameter search space provided for: {', '.join(self.custom_hp.keys())}")

            safe_print(f"Task: {self.task}")
            safe_print(f"Metric: {self.metric}")
            safe_print(f"Time budget: {self.timeout_minutes} minutes ({int(self.timeout_minutes * 60)} seconds)")
            safe_print(f"Max trials: {self.max_trials if self.max_trials else 'unlimited'}")
            safe_print(f"Concurrent trials: {self.max_concurrent_trials}")
            safe_print(f"Parallel backend: {'Spark' if self.use_spark else 'Local (multi-thread)'}")
            safe_print(f"Estimators: {', '.join(estimator_list)}")
            safe_print(f"Evaluation method: holdout")
            if self.custom_hp:
                safe_print(f"Custom search space: Yes ({len(self.custom_hp)} estimator(s))")
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("🚀 Starting AutoML Training...", show_timestamp=False, show_level=False)
            print_separator()
            
            # 抑制 FLAML 和 MLflow 子 run 的 debug 日志
            import logging as py_logging
            flaml_logger = py_logging.getLogger("flaml.automl.logger")
            flaml_automl_logger = py_logging.getLogger("flaml.automl")
            mlflow_logger = py_logging.getLogger("mlflow.tracking._tracking_service.client")
            mlflow_utils_logger = py_logging.getLogger("mlflow.utils")

            original_flaml_level = flaml_logger.level
            original_flaml_automl_level = flaml_automl_logger.level
            original_mlflow_level = mlflow_logger.level
            original_mlflow_utils_level = mlflow_utils_logger.level

            # 设置为 WARNING 级别，只显示警告和错误
            flaml_logger.setLevel(py_logging.WARNING)
            flaml_automl_logger.setLevel(py_logging.WARNING)
            mlflow_logger.setLevel(py_logging.WARNING)
            mlflow_utils_logger.setLevel(py_logging.WARNING)

            safe_print("Training in progress... (FLAML debug logs suppressed)")

            # 创建 TrialHook（但不安装，等训练完成后再提取 trials）
            safe_print("", show_timestamp=False, show_level=False)
            safe_print("🔧 Preparing TrialHook to log all trials...")
            trial_hook = TrialHook(
                parent_run_id=parent_run_id,
                features=self.features,
                task=self.task,
                metric=self.metric,
                enable_logging=True
            )

            start_time = time.time()

            try:
                # 训练
                self.automl.fit(
                    X_train=X_train_num,
                    y_train=y_train,
                    X_val=X_val_num,
                    y_val=y_val,
                    **settings,
                )
            finally:
                # 恢复日志级别
                flaml_logger.setLevel(original_flaml_level)
                flaml_automl_logger.setLevel(original_flaml_automl_level)
                mlflow_logger.setLevel(original_mlflow_level)
                mlflow_utils_logger.setLevel(original_mlflow_utils_level)

            # 训练完成后，从 AutoML 实例中提取所有 trials 并创建 MLflow 子 runs
            trial_hook.log_trials_from_automl(self.automl, log_file_path=log_file_path)

            # 上传 log 文件到 MLflow（作为 artifact）
            safe_print("", show_timestamp=False, show_level=False)
            safe_print("📤 Uploading FLAML log file to MLflow...")
            try:
                if os.path.exists(log_file_path):
                    mlflow.log_artifact(log_file_path, artifact_path="flaml_logs")
                    safe_print(f"✅ Log file uploaded: {os.path.basename(log_file_path)}")

                    # 清理本地 log 文件（已上传到 MLflow）
                    if self.auto_cleanup_logs:
                        try:
                            os.remove(log_file_path)
                            safe_print(f"✅ Local log file cleaned up: {log_file_path}")
                        except Exception as e:
                            safe_print(f"⚠️  Failed to cleanup local log file: {e}")
                else:
                    safe_print(f"⚠️  Log file not found: {log_file_path}")
            except Exception as e:
                safe_print(f"⚠️  Failed to upload log file: {e}")
                # 即使上传失败，也尝试清理本地文件
                if self.auto_cleanup_logs:
                    try:
                        if os.path.exists(log_file_path):
                            os.remove(log_file_path)
                    except Exception:
                        pass

            elapsed_time = time.time() - start_time
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print("✅ AutoML Training Completed", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"Total training time: {elapsed_time:.1f}s ({elapsed_time/60:.2f} minutes)")

            # 打印 TrialHook 统计摘要
            trial_hook.print_summary()

            # 获取 TrialHook 的统计信息
            hook_summary = trial_hook.get_summary()
            total_trials_run = hook_summary['total_trials']
            best_trial_run_id = hook_summary['best_trial_run_id']
            best_trial_run_name = hook_summary['best_trial_run_name']

            # 记录最佳配置到父 run
            best_est = self.automl.best_estimator
            best_cfg = self.automl.best_config
            log_best_config_overall(best_cfg)
            if getattr(self.automl, "best_config_per_estimator", None):
                log_best_config_per_estimator(self.automl.best_config_per_estimator)

            mlflow.log_param("best_estimator", best_est)
            mlflow.log_param("best_trial_run_id", best_trial_run_id)
            mlflow.log_param("total_trials", total_trials_run)

            # 设置 tags 到父 run
            mlflow.set_tags({
                "wedata.total_trials_run": str(total_trials_run),  # 实际运行次数
                "wedata.best_run_id": best_trial_run_id,           # best_run_id
                "wedata.best_run_name": best_trial_run_name,       # best_run_name
            })
            safe_print(f"✅ Tags set: total_trials_run={total_trials_run}, best_run_id={best_trial_run_id}, best_run_name={best_trial_run_name}")

            safe_print("", show_timestamp=False, show_level=False)
            safe_print(f"Best estimator: {best_est}")
            safe_print(f"Best config: {best_cfg}")
            
            # 构建服务管道
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"🔨 Building Serving Pipeline")
            print_separator()
            clf = self.automl.model
            self.pipeline = SkPipe([("preprocess", self.preprocessor), ("clf", clf)])
            self.pipeline.fit(X_train, y_train)
            safe_print("Pipeline built: [Preprocessor] -> [Classifier/Regressor]")

            # 评估
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"📊 Model Evaluation")
            print_separator()
            metrics = self._evaluate_model(
                X_train, y_train, X_val, y_val, X_test, y_test
            )
            
            # 注册模型
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"💾 Model Registration")
            print_separator()
            model_uri = f"runs:/{parent_run_id}/model"
            model_version = None

            if self.register_model and self.model_name:
                mlflow.sklearn.log_model(self.pipeline, "model")
                safe_print(f"Model logged to MLflow")
                result = mlflow.register_model(model_uri, self.model_name)
                model_version = result.version
                safe_print(f"✅ Model registered: '{self.model_name}' version {model_version}")
            else:
                mlflow.sklearn.log_model(self.pipeline, "model")
                safe_print(f"Model logged to MLflow (not registered)")
            
            # 准备任务特定参数（用于 Notebook 生成）
            task_kwargs = {}
            if self.task == "forecast":
                task_kwargs = {
                    "time_col": self.kwargs.get("time_col"),
                    "horizon": self.kwargs.get("horizon"),
                    "frequency": self.kwargs.get("frequency"),
                    "identity_col": self.kwargs.get("identity_col"),
                }

            # 创建 AutoMLSummary
            summary = AutoMLSummary(
                experiment_id=experiment.experiment_id,
                run_id=parent_run_id,
                best_trial_run_id=best_trial_run_id,  # 使用最佳 trial 的 run_id
                model_uri=model_uri,
                model_version=model_version,
                metrics=metrics,
                best_estimator=best_est,
                best_params=best_cfg,
                task=self.task,
                mlflow_tracking_uri=mlflow.get_tracking_uri(),
                features=self.features,
                target_col=self.target_col,
                metric=self.metric,
                task_kwargs=task_kwargs,
            )

            # 最终总结
            safe_print("", show_timestamp=False, show_level=False)
            print_separator()
            safe_print(f"🎉 Training Pipeline Completed Successfully!")
            print_separator()
            safe_print(f"Experiment: {experiment_name} (ID: {experiment.experiment_id})")
            safe_print(f"Run ID: {parent_run_id}")
            safe_print(f"Best Model: {best_est}")
            if self.register_model and self.model_name:
                safe_print(f"Registered Model: {self.model_name} v{model_version}")
            safe_print(f"Model URI: {model_uri}")

            # 显示最佳性能指标
            if self.task == "classification":
                test_acc = metrics.get("test_accuracy", 0)
                test_f1 = metrics.get("test_f1", 0)
                safe_print(f"Test Accuracy: {test_acc:.4f}")
                safe_print(f"Test F1 Score: {test_f1:.4f}")
            elif self.task == "regression":
                test_r2 = metrics.get("test_r2", 0)
                test_rmse = metrics.get("test_rmse", 0)
                safe_print(f"Test R²: {test_r2:.4f}")
                safe_print(f"Test RMSE: {test_rmse:.4f}")

            print_separator()

            return summary

