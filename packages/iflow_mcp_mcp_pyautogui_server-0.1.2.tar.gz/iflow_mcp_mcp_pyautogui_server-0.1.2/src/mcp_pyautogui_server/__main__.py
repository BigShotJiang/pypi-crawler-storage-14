from mcp_pyautogui_server import main

main()