import pyperclip

def copy_to_clipboard(password):
    """Copy password to system clipboard"""
    try:
        pyperclip.copy(password)
        return True
    except Exception:
        return False

def clear_clipboard():
    """Clear clipboard after delay (security)"""
    pyperclip.copy("")
