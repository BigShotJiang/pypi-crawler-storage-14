# Trd Utils

Basic common utils for Python.

## How to run tests

Use this command first:

```bash
pip install -e .
```

Then run the tests in vscode.
