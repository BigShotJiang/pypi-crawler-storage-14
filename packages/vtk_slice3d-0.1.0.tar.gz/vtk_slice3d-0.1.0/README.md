# slice3d

3D slice visualization with VTK.

## Installation

```bash
pip install vtk-slice3d
