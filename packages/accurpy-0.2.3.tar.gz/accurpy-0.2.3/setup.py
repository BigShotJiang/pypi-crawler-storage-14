from setuptools import setup, Extension
import sys, platform
import numpy as np

compile_args = []
link_args = []
libraries = []

if platform.system() == "Windows":
    compile_args += ["/O2", "/fp:precise"]
else:
    compile_args += [
        "-O3",
        "-std=c11",
        "-fno-trapping-math",
        "-fexcess-precision=standard",
        "-ffp-contract=off",
    ]
    libraries.append("m")

ext = Extension(
    name="accurpy._fm",
    sources=["src/accurpy/_fm.c"],
    include_dirs=[np.get_include()],
    extra_compile_args=compile_args,
    extra_link_args=link_args,
    libraries=libraries,
)

setup(
    ext_modules=[ext],
    zip_safe=False,
)
