# AccurPy

Ultra-accurate and fast FM function evaluator with <4.5e-16 relative error (~2x machine epsilon).

## Installation

```bash
pip install accurpy
```

## Usage

```python
from accurpy import syncF, fm_scaled

# Compute FM(x) * exp(x) - the numerically stable form
result = syncF(1.0)

# Compute FM(x) = exp(-x) * integral of t^(-1/2) * exp(-t) / (1 + t/x) dt
result_scaled = fm_scaled(1.0)

# Works with numpy arrays
import numpy as np
x = np.linspace(0.001, 100, 1000)
y = syncF(x)
```

## Performance

The C extension uses `METH_O` calling convention with `PyFloat_AS_DOUBLE` for minimal overhead:

| x range | syncF(x) time | Notes |
|---------|---------------|-------|
| Small (1e-8) | ~38 ns | Cube-root expansion |
| Wide (1.0) | ~45 ns | Rational approximation |
| Large (1e10) | ~32 ns | Asymptotic expansion |

Comparable to `math.sin` (~38 ns) - only ~20 ns above the minimum possible CPython C-extension overhead (~16 ns for extract+create).

Array throughput: ~10 ns/element.

## Accuracy

- Relative error < 4.5e-16 across entire domain (x > 0)
- Three-region algorithm:
  - Small x (< 1e-7): Cube-root expansion
  - Wide domain (1e-7 to 1e6): 63-segment rational approximation
  - Large x (> 1e6): Asymptotic expansion

## License

MIT
