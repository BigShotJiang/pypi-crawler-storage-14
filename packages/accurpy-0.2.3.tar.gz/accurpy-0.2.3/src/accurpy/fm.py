from ._fm import fm, fm_scaled

# Alias for backward compatibility
syncF = fm

__all__ = ["fm", "fm_scaled", "syncF"]
