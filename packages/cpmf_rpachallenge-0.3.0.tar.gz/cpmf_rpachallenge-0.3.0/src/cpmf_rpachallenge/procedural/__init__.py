"""Procedural paradigm - imperative workflows and high-level orchestration.

This module provides the procedural programming approach:
- Imperative, step-by-step workflows
- High-level client interface
- Backend delegation pattern
"""

from .client import RPAChallengeClient

__all__ = ["RPAChallengeClient"]
