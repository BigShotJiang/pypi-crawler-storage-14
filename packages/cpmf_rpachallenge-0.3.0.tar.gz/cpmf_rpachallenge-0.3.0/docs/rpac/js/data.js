const CHALLENGE_DATA = [
  {
    first_name: "John",
    last_name: "Smith",
    company_name: "IT Solutions",
    role: "Analyst",
    address: "98 North Road",
    email: "jsmith@itsolutions.co.uk",
    phone: "40716543298"
  },
  {
    first_name: "Jane",
    last_name: "Dorsey",
    company_name: "MediCare",
    role: "Medical Engineer",
    address: "11 Crown Street",
    email: "jdorsey@medcare.com",
    phone: "40791345621"
  },
  {
    first_name: "Albert",
    last_name: "Kipling",
    company_name: "Waterfront",
    role: "Accountant",
    address: "22 Guild Street",
    email: "kipling@waterfront.com",
    phone: "40735416854"
  },
  {
    first_name: "Michael",
    last_name: "Robertson",
    company_name: "MediCare",
    role: "IT Specialist",
    address: "83 Jan Road",
    email: "mrobertson@medcare.com",
    phone: "40733652145"
  },
  {
    first_name: "Doug",
    last_name: "Derrick",
    company_name: "Timepath Inc.",
    role: "Analyst",
    address: "99 Shire Oak Road",
    email: "dderrick@timepath.co.uk",
    phone: "40794485865"
  },
  {
    first_name: "Jessie",
    last_name: "Marlowe",
    company_name: "Aperture Inc.",
    role: "Scientist",
    address: "27 Cheshire Street",
    email: "jmarlowe@aperture.us",
    phone: "40733845219"
  },
  {
    first_name: "Stan",
    last_name: "Hamm",
    company_name: "Sugarwell",
    role: "Advisor",
    address: "10 Dam Road",
    email: "shamm@sugarwell.org",
    phone: "40712462257"
  },
  {
    first_name: "Michelle",
    last_name: "Norton",
    company_name: "Gadget UK",
    role: "Designer",
    address: "14 Bilton View",
    email: "mnorton@gadget.co.uk",
    phone: "40700854721"
  },
  {
    first_name: "Stacy",
    last_name: "Shelby",
    company_name: "TechDev",
    role: "HR Manager",
    address: "19 Peterborough Avenue",
    email: "sshelby@techdev.com",
    phone: "40735416766"
  },
  {
    first_name: "Lara",
    last_name: "Palmer",
    company_name: "Recreate Rus",
    role: "Programmer",
    address: "87 Horsefair Green",
    email: "lpalmer@recreate.ru",
    phone: "40730141970"
  }
];
