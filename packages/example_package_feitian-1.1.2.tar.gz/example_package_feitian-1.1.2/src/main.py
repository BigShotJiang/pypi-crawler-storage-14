
from example_package_fetian import *

print(my_add(1,2))
hello()