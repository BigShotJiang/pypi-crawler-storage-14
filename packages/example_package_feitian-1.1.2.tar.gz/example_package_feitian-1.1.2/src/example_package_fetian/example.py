

def my_add(x, y):
    return x+y

def hello():
    print("hello world!")