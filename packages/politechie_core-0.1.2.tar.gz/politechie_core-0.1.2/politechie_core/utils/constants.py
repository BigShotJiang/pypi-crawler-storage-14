VALID_GENDER_OPTIONS = {"M", "F", "O"}

EMAIL_PATTERN = r"^[^@]+@[^@]+\.[^@]+$"

DOB_FORMAT = "%Y-%m-%d"