epydoc -v --no-frames --no-private -o html spharm.spharm
