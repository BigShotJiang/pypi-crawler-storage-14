from edgefirst.validator.datasets.instance.core import Instance, InstanceCollection
from edgefirst.validator.datasets.instance.detection import DetectionInstance
from edgefirst.validator.datasets.instance.segmentation import SegmentationInstance
from edgefirst.validator.datasets.instance.multitask import MultitaskInstance
