# Audio Slice MCP

截取音频片段的 MCP 服务，提供 `slice_audio` 工具。返回值为英文文本。

## 安装
```bash
pip install audio-slice-mcp
```

## 运行
```bash
audio-slice-mcp
```

## 工具
- `slice_audio(input_audio_path: str, output_audio_path: str, start_time: str, end_time: str, copy_codec: bool = True) -> str`
  - 支持时间格式：秒数（如 `90`）、`MM:SS`、`HH:MM:SS`
  - `copy_codec=true` 时不重新编码，速度更快

## 示例
截取 00:00:10 到 00:00:30：