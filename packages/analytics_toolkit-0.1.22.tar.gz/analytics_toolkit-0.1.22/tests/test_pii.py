"""
Test suite for PII detection and tagging module.
"""

from analytics_toolkit.pii import (
    detect_and_tag_pii,
    _split_by_speaker,
    _literal_to_digits,
    _detect_letter_reference,
    _find_pii,
    _tag_text_with_positions,
)


# Basic PII Detection Tests
def test_detect_and_tag_pii_basic():
    # Test basic PII detection with DNI
    text = "Mi DNI es doce treinta y cuatro cincuenta y seis setenta y ocho A"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert len(positions) > 0
    assert positions[0]["pii_type"] == "DNI"


def test_detect_and_tag_pii_multiple_types():
    # Test detection of multiple PII types
    text = "Mi DNI es doce treinta y cuatro cincuenta y seis setenta y ocho A y mi NIE es X uno dos tres cuatro cinco seis siete B"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert "[NIE_A]" in processed_text
    assert len(positions) >= 2


def test_detect_and_tag_pii_with_speakers():
    # Test PII detection in text with multiple speakers
    text = "speaker0: Mi DNI es doce treinta y cuatro cincuenta y seis setenta y ocho A | speaker1: Y mi NIE es X uno dos tres cuatro cinco seis siete B"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert "[NIE_A]" in processed_text
    assert len(positions) >= 2


# Number Format Tests
def test_detect_and_tag_pii_with_written_numbers():
    # Test PII detection with written numbers
    text = (
        "Mi DNI es ciento veintitrés mil cuatrocientos cincuenta y seis, veinticinco A"
    )
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert len(positions) > 0


def test_detect_and_tag_pii_with_mixed_number_formats():
    # Test PII detection with mixed number formats
    text = "Mi DNI es 12 treinta y cuatro 56 setenta y ocho A"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert len(positions) > 0


# Letter Reference Tests
def test_detect_and_tag_pii_with_letter_references():
    # Test PII detection with letter references
    text = "P de Pamplona 12345678A"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert "P de Pamplona" not in processed_text


def test_detect_and_tag_pii_with_multiple_letter_references():
    # Test PII detection with multiple letter references
    text = "P de Pamplona 12345678A y C de Cádiz 87654321B"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert "[DNI_A]" in processed_text
    assert "P de Pamplona" not in processed_text
    assert "C de Cádiz" not in processed_text


# Policy and Expediente Tests
def test_detect_and_tag_pii_poliza():
    # Test detection of policy numbers
    text = "La póliza es uno dos tres cuatro cinco seis siete ocho nueve cero uno dos"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[POLIZA_A]" in processed_text
    assert len(positions) > 0
    assert positions[0]["pii_type"] == "POLIZA"


def test_detect_and_tag_pii_expediente():
    # Test detection of expediente numbers
    text = "El expediente es uno dos tres cuatro cinco seis siete ocho nueve cero uno dos tres"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[EXPEDIENTE_A]" in processed_text
    assert len(positions) > 0
    assert positions[0]["pii_type"] == "EXPEDIENTE"


# Phone Number Tests
def test_detect_and_tag_pii_phone():
    # Test detection of phone numbers
    text = "Mi teléfono es seis seis seis uno dos tres cuatro cinco seis siete ocho"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[PHONE_A]" in processed_text
    assert len(positions) > 0
    assert positions[0]["pii_type"] == "PHONE"


# Edge Cases and Error Handling
def test_detect_and_tag_pii_empty_text():
    # Test empty text handling
    text = ""
    processed_text, positions = detect_and_tag_pii(text, True)
    assert processed_text == ""
    assert len(positions) == 0


def test_detect_and_tag_pii_invalid_text():
    # Test invalid text handling
    text = None
    processed_text, positions = detect_and_tag_pii(text, True)
    assert processed_text == ""
    assert len(positions) == 0


def test_detect_and_tag_pii_special_characters():
    # Test text with special characters
    text = "Mi DNI es 12-34-56-78-A"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text
    assert len(positions) > 0


# Overlapping PII Tests
def test_detect_and_tag_pii_overlapping():
    # Test overlapping PII detection
    text = "DNI 12345678A y NIE X1234567B"
    processed_text, positions = detect_and_tag_pii(text, True)
    assert "[DNI_A]" in processed_text or "[NIE_A]" in processed_text
    assert len(positions) > 0


# Speaker Splitting Tests
def test_split_by_speaker_basic():
    # Test basic speaker splitting
    text = "speaker0: Hola mundo | speaker1: ¿Qué tal?"
    result = _split_by_speaker(text)
    assert "speaker0" in result
    assert "speaker1" in result
    assert result["speaker0"][0]["text"] == "Hola mundo"
    assert result["speaker1"][0]["text"] == "¿Qué tal?"


def test_split_by_speaker_no_speakers():
    # Test text without speaker markers
    text = "Hola mundo"
    result = _split_by_speaker(text)
    assert "speaker0" in result
    assert result["speaker0"][0]["text"] == "Hola mundo"


def test_split_by_speaker_multiple_segments():
    # Test multiple segments from same speaker
    text = "speaker0: Hola | speaker0: mundo"
    result = _split_by_speaker(text)
    assert "speaker0" in result
    assert len(result["speaker0"]) == 2
    assert result["speaker0"][0]["text"] == "Hola"
    assert result["speaker0"][1]["text"] == "mundo"


# Number Conversion Tests
def test_literal_to_digits_basic():
    # Test basic number conversion
    text = "doce treinta y cuatro"
    result, number_dict, _ = _literal_to_digits(text, "es")
    assert "12" in result
    assert "34" in result
    assert len(number_dict) > 0


def test_literal_to_digits_multiple_occurrences():
    # Test handling of multiple number occurrences
    text = "doce y doce"
    result, number_dict, _ = _literal_to_digits(text, "es")
    assert "12" in result
    assert "12_1" in result
    assert len(number_dict["12"]) == 2


def test_literal_to_digits_large_numbers():
    # Test conversion of large numbers
    text = "ciento veintitrés mil cuatrocientos cincuenta y seis"
    result, number_dict, _ = _literal_to_digits(text, "es")
    assert "123456" in result
    assert len(number_dict) > 0


# PII Finding Tests
def test_find_pii_dni():
    # Test DNI detection
    original_text = "Mi DNI es doce treinta y cuatro cincuenta y seis setenta y ocho A"
    speaker_texts = {
        "speaker0": [
            {
                "text": "Mi DNI es 12 34 56 78 A",
                "start_position": 0,
                "end_position": len(original_text),
            }
        ]
    }
    number_dict = {
        "12": [{"start": 10, "end": 12}],
        "34": [{"start": 13, "end": 15}],
        "56": [{"start": 16, "end": 18}],
        "78": [{"start": 19, "end": 21}],
    }
    word_dict = {
        "Mi": [{"start": 0, "end": 2}],
        "DNI": [{"start": 10, "end": 12}],
        "es": [{"start": 13, "end": 15}],
        "A": [{"start": 22, "end": 23}],
    }
    result = _find_pii(original_text, speaker_texts, number_dict, word_dict, "DNI")
    assert len(result) > 0
    assert result[0]["pii_type"] == "DNI"


def test_find_pii_nie():
    # Test NIE detection
    original_text = "Mi NIE es X uno dos tres cuatro cinco seis siete B"
    speaker_texts = {
        "speaker0": [
            {
                "text": "Mi NIE es X 1 2 3 4 5 6 7 B",
                "start_position": 0,
                "end_position": len(original_text),
            }
        ]
    }
    number_dict = {
        "1": [{"start": 10, "end": 11}],
        "2": [{"start": 12, "end": 13}],
        "3": [{"start": 14, "end": 15}],
        "4": [{"start": 16, "end": 17}],
        "5": [{"start": 18, "end": 19}],
        "6": [{"start": 20, "end": 21}],
        "7": [{"start": 22, "end": 23}],
    }
    word_dict = {
        "Mi": [{"start": 0, "end": 2}],
        "NIE": [{"start": 10, "end": 12}],
        "es": [{"start": 13, "end": 15}],
        "X": [{"start": 16, "end": 17}],
        "B": [{"start": 23, "end": 24}],
    }
    result = _find_pii(original_text, speaker_texts, number_dict, word_dict, "NIE")
    assert len(result) > 0
    assert result[0]["pii_type"] == "NIE"


# Text Tagging Tests
def test_tag_text_with_positions():
    # Test text tagging with PII positions
    text = "Mi DNI es 12345678A"
    positions = [{"start": 10, "end": 19, "pii_type": "DNI"}]
    result = _tag_text_with_positions(text, positions, True)
    assert "[DNI_A]" in result


def test_tag_text_with_positions_multiple():
    # Test multiple PII tagging
    text = "Mi DNI es 12345678A y mi NIE es X1234567B"
    positions = [
        {"start": 10, "end": 19, "pii_type": "DNI"},
        {"start": 31, "end": 39, "pii_type": "NIE"},
    ]
    result = _tag_text_with_positions(text, positions, True)
    assert "[DNI_A]" in result
    assert "[NIE_A]" in result


def test_tag_text_with_positions_overlapping():
    # Test overlapping PII tagging
    text = "DNI 12345678A"
    positions = [
        {"start": 4, "end": 13, "pii_type": "NIE"},
        {"start": 4, "end": 13, "pii_type": "DNI"},
    ]
    result = _tag_text_with_positions(text, positions, True)
    assert "[DNI_A]" in result and "[NIE_A]" not in result
