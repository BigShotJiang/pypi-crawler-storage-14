import pytest
from datetime import datetime
from unittest.mock import patch, MagicMock
from analytics_toolkit.transcribe import (
    send_audio_transcription,
    get_audio_transcription,
    _format_transcription,
)


@pytest.fixture
def mock_boto3_client():
    with patch("boto3.client") as mock_client:
        yield mock_client


@pytest.fixture
def mock_requests_get():
    with patch("requests.get") as mock_get:
        yield mock_get


def test_send_audio_transcription_success(mock_boto3_client):
    # Arrange
    mock_transcribe = MagicMock()
    mock_boto3_client.return_value = mock_transcribe
    expected_job_name = "20240321123456_audio.mp3"

    # Act
    result = send_audio_transcription(
        s3_bucket="test-bucket",
        audio_path="path/to/audio.mp3",
        fec_proceso=datetime(2024, 3, 21, 12, 34, 56),
    )

    # Assert
    assert result == expected_job_name
    mock_boto3_client.assert_called_once_with("transcribe", region_name="eu-west-1")
    mock_transcribe.start_transcription_job.assert_called_once()


def test_send_audio_transcription_error(mock_boto3_client):
    # Arrange
    mock_transcribe = MagicMock()
    mock_boto3_client.return_value = mock_transcribe
    mock_transcribe.start_transcription_job.side_effect = Exception("AWS Error")

    # Act
    result = send_audio_transcription(
        s3_bucket="test-bucket", audio_path="path/to/audio.mp3"
    )

    # Assert
    assert result is None


def test_get_audio_transcription_success(mock_boto3_client, mock_requests_get):
    # Arrange
    mock_transcribe = MagicMock()
    mock_boto3_client.return_value = mock_transcribe

    # Mock AWS response
    mock_transcribe.get_transcription_job.return_value = {
        "TranscriptionJob": {
            "TranscriptionJobStatus": "COMPLETED",
            "StartTime": datetime(2024, 3, 21, 12, 0, 0),
            "CompletionTime": datetime(2024, 3, 21, 12, 5, 0),
            "Transcript": {"TranscriptFileUri": "https://example.com/transcript.json"},
        }
    }

    # Mock transcription response
    mock_response = MagicMock()
    mock_response.text = """
    {
        "results": {
            "transcripts": [{"transcript": "Hello world"}],
            "items": [
                {
                    "channel_label": "ch_0",
                    "alternatives": [{"content": "Hello"}],
                    "type": "pronunciation"
                },
                {
                    "channel_label": "ch_0",
                    "alternatives": [{"content": "world"}],
                    "type": "pronunciation"
                }
            ],
            "language_code": "en-US"
        }
    }
    """
    mock_requests_get.return_value = mock_response

    # Act
    result = get_audio_transcription("test_job", datetime(2024, 3, 21, 12, 0, 0))

    # Assert
    assert result is not None
    assert result["transcripcion"] == "Hello world"
    assert result["lenguaje"] == "en-US"
    assert result["transcripcion_formateada"] == "speaker0: Hello world"


def test_get_audio_transcription_failed_job(mock_boto3_client):
    # Arrange
    mock_transcribe = MagicMock()
    mock_boto3_client.return_value = mock_transcribe
    mock_transcribe.get_transcription_job.return_value = {
        "TranscriptionJob": {"TranscriptionJobStatus": "FAILED"}
    }

    # Act
    result = get_audio_transcription("test_job", datetime.now())

    # Assert
    assert result is None


def test_get_audio_transcription_with_pii(mock_boto3_client, mock_requests_get):
    # Arrange
    mock_transcribe = MagicMock()
    mock_boto3_client.return_value = mock_transcribe

    mock_transcribe.get_transcription_job.return_value = {
        "TranscriptionJob": {
            "TranscriptionJobStatus": "COMPLETED",
            "StartTime": datetime(2024, 3, 21, 12, 0, 0),
            "CompletionTime": datetime(2024, 3, 21, 12, 5, 0),
            "Transcript": {
                "RedactedTranscriptFileUri": "https://example.com/transcript.json"
            },
        }
    }

    # Mock transcription response with PII
    mock_response = MagicMock()
    mock_response.text = """
    {
        "results": {
            "transcripts": [{"transcript": "My name is [PII]"}],
            "items": [
                {
                    "channel_label": "ch_0",
                    "alternatives": [
                        {
                            "content": "[PII]",
                            "redactions": [{"type": "NAME"}]
                        }
                    ],
                    "type": "pronunciation"
                }
            ],
            "language_code": "en-US"
        }
    }
    """
    mock_requests_get.return_value = mock_response

    # Act
    result = get_audio_transcription("test_job", datetime(2024, 3, 21, 12, 0, 0))

    # Assert
    assert result is not None
    assert "[NAME]" in result["transcripcion_formateada"]


def test_format_transcription_basic():
    # Test basic transcription with single speaker
    items = [
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "Hola"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "mundo"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "!"}],
            "type": "punctuation",
        },
    ]

    result = _format_transcription(items)
    assert result == "speaker0: Hola mundo!"


def test_format_transcription_multiple_speakers():
    # Test transcription with multiple speakers
    items = [
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "Hola"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "!"}],
            "type": "punctuation",
        },
        {
            "channel_label": "ch_1",
            "alternatives": [{"content": "¿Qué"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_1",
            "alternatives": [{"content": "tal"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_1",
            "alternatives": [{"content": "?"}],
            "type": "punctuation",
        },
    ]

    result = _format_transcription(items)
    assert result == "speaker0: Hola! | speaker1: ¿Qué tal?"


def test_format_transcription_with_pii():
    # Test transcription with PII redaction
    items = [
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "Mi nombre es"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "[PII]", "redactions": [{"type": "NOMBRE"}]}],
            "type": "pronunciation",
        },
    ]

    result = _format_transcription(items)
    assert result == "speaker0: Mi nombre es [NOMBRE]"


def test_format_transcription_empty_items():
    # Test with empty items list
    result = _format_transcription([])
    assert result == ""


def test_format_transcription_complex_conversation():
    # Test complex conversation with multiple speakers and punctuation
    items = [
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "Cómo"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "estás"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "?"}],
            "type": "punctuation",
        },
        {
            "channel_label": "ch_1",
            "alternatives": [{"content": "Estoy"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_1",
            "alternatives": [{"content": "bien"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_1",
            "alternatives": [{"content": "."}],
            "type": "punctuation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "Qué"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "bueno"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "!"}],
            "type": "punctuation",
        },
    ]

    result = _format_transcription(items)
    assert (
        result == "speaker0: Cómo estás? | speaker1: Estoy bien. | speaker0: Qué bueno!"
    )


def test_format_transcription_missing_alternatives():
    # Test handling of items with missing alternatives
    items = [
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "Buenos"}],
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [],  # Empty alternatives
            "type": "pronunciation",
        },
        {
            "channel_label": "ch_0",
            "alternatives": [{"content": "días"}],
            "type": "pronunciation",
        },
    ]

    result = _format_transcription(items)
    assert result == "speaker0: Buenos días"
