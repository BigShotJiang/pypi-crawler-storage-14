import pytest
import pandas as pd
import requests
import json
from unittest.mock import patch, Mock
from analytics_toolkit.email import send_emails


@pytest.fixture
def sample_df():
    return pd.DataFrame({"name": ["John", "Jane"], "age": [30, 25]})


@pytest.fixture
def mock_config():
    return {
        "email_host": "http://test-email-service.com",
        "email_clienid": "test-client-id",
        "email_call_env": "test",
        "email_log_env": "test",
    }


class TestSendEmails:
    @patch("analytics_toolkit.email._config")
    def test_basic_email_send(self, mock_config_patch, mock_config):
        """Test sending a basic email without attachments"""
        mock_config_patch.return_value = mock_config
        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.content = b'{"status": "success"}'
            mock_post.return_value = mock_response

            result = send_emails(
                subject="Test Subject",
                body="Test Body",
                recipients=["test@example.com"],
            )

            # Verify the request was made with correct parameters
            mock_post.assert_called_once()
            call_kwargs = mock_post.call_args.kwargs
            sent_data = json.loads(call_kwargs["data"])

            assert sent_data["comunicacion"] == "ANALYTICS_COMUNICACION_GENERICA"
            assert result == {"status": "success"}

    @patch("analytics_toolkit.email._config")
    def test_email_with_attachment(self, mock_config_patch, mock_config, sample_df):
        """Test sending an email with DataFrame attachment"""
        mock_config_patch.return_value = mock_config
        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.content = b'{"status": "success"}'
            mock_post.return_value = mock_response

            result = send_emails(
                subject="Test Subject",
                body="Test Body",
                recipients=["test@example.com"],
                files={"test.csv": sample_df},
            )

            # Verify the request was made with correct parameters
            mock_post.assert_called_once()
            call_kwargs = mock_post.call_args.kwargs
            sent_data = json.loads(call_kwargs["data"])

            assert (
                sent_data["comunicacion"] == "ANALYTICS_COMUNICACION_GENERICA_ADJUNTO"
            )
            assert "adjuntos" in sent_data
            assert result == {"status": "success"}

    @patch("analytics_toolkit.email._config")
    def test_multiple_recipients(self, mock_config_patch, mock_config):
        """Test sending email to multiple recipients"""
        mock_config_patch.return_value = mock_config
        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.content = b'{"status": "success"}'
            mock_post.return_value = mock_response

            recipients = ["test1@example.com", "test2@example.com"]
            result = send_emails(
                subject="Test Subject",
                body="Test Body",
                recipients=recipients,
            )

            # Verify all recipients are included in the request
            call_kwargs = mock_post.call_args.kwargs
            sent_data = json.loads(call_kwargs["data"])
            sent_recipients = [d["email"] for d in sent_data["destinatarios"]]

            assert all(email in sent_recipients for email in recipients)
            assert result == {"status": "success"}

    @patch("analytics_toolkit.email._config")
    def test_http_error_handling(self, mock_config_patch, mock_config):
        """Test handling of HTTP errors"""
        mock_config_patch.return_value = mock_config
        with patch("requests.post") as mock_post:
            mock_post.side_effect = requests.HTTPError("404 Client Error")

            result = send_emails(
                subject="Test Subject",
                body="Test Body",
                recipients=["test@example.com"],
            )

            assert "HTTP error occurred" in result

    @patch("analytics_toolkit.email._config")
    def test_general_error_handling(self, mock_config_patch, mock_config):
        """Test handling of general errors"""
        mock_config_patch.return_value = mock_config
        with patch("requests.post") as mock_post:
            mock_post.side_effect = Exception("Unknown error")

            result = send_emails(
                subject="Test Subject",
                body="Test Body",
                recipients=["test@example.com"],
            )

            assert "An error occurred" in result

    @patch("analytics_toolkit.email._config")
    def test_multiline_body_formatting(self, mock_config_patch, mock_config):
        """Test formatting of multiline body content"""
        mock_config_patch.return_value = mock_config
        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.content = b'{"status": "success"}'
            mock_post.return_value = mock_response

            multiline_body = "Line 1\nLine 2\nLine 3"
            result = send_emails(
                subject="Test Subject",
                body=multiline_body,
                recipients=["test@example.com"],
            )

            # Get the actual request data
            call_kwargs = mock_post.call_args.kwargs
            sent_data = json.loads(call_kwargs["data"])

            # Decode the body content from base64
            import base64

            decoded_body = base64.b64decode(
                sent_data["personalizacion"]["cuerpo"]["BODY"]
            ).decode("utf-8")

            # Verify that the body contains HTML formatting
            assert "<tr><td" in decoded_body
            assert "Line 1" in decoded_body
            assert "Line 2" in decoded_body
            assert "Line 3" in decoded_body
            assert result == {"status": "success"}
