import pytest
import logging
import os
import shutil
from analytics_toolkit.logger import Logger


@pytest.fixture(scope="function")
def cleanup_logs():
    """Fixture to clean up log files before and after tests"""
    # Clean up before test
    if os.path.exists("logs"):
        # Close all handlers to release file locks
        logging.shutdown()
        # Use shutil.rmtree with error handling
        try:
            shutil.rmtree("logs", ignore_errors=True)
        except Exception:
            pass

    yield

    # Clean up after test
    # Close all handlers to release file locks
    logging.shutdown()
    if os.path.exists("logs"):
        try:
            shutil.rmtree("logs", ignore_errors=True)
        except Exception:
            pass

    # Reset the Logger's initialization flag for clean tests
    Logger._initialized = False


def test_logger_initialization(cleanup_logs):
    """Test basic logger initialization"""
    logger = Logger()
    log = logger.get_logger()

    assert isinstance(log, logging.Logger)
    assert os.path.exists("logs/log.log")
    assert log.level == logging.INFO


def test_debug_mode(cleanup_logs):
    """Test logger in debug mode"""
    logger = Logger(debug=True)
    log = logger.get_logger()

    assert log.level == logging.DEBUG

    # Test that analytics_toolkit logger is set to DEBUG
    analytics_logger = logging.getLogger("analytics_toolkit")
    assert analytics_logger.level == logging.DEBUG


def test_custom_library_name(cleanup_logs):
    """Test logger with custom library name"""
    library_name = "test_library"
    logger = Logger(library_name=library_name)
    log = logger.get_logger()

    assert log.name == library_name


def test_external_libraries_logging_levels(cleanup_logs):
    """Test logging levels for external libraries"""
    logger = Logger()  # Normal mode

    # Check external libraries are set to CRITICAL in normal mode
    external_libs = ["boto3", "botocore", "openai", "httpx"]
    for lib in external_libs:
        lib_logger = logging.getLogger(lib)
        assert lib_logger.level == logging.CRITICAL

    # Check in debug mode
    debug_logger = Logger(debug=True)
    for lib in external_libs:
        lib_logger = logging.getLogger(lib)
        assert lib_logger.level == logging.INFO


def test_multiple_logger_instances(cleanup_logs):
    """Test behavior with multiple logger instances"""
    # First logger initialization
    logger1 = Logger()
    log1 = logger1.get_logger()

    # Second logger with different settings
    logger2 = Logger(library_name="second_logger", debug=True)
    log2 = logger2.get_logger()

    assert log1.level == logging.INFO
    assert log2.level == logging.DEBUG
    assert log2.name == "second_logger"


def test_logging_output(cleanup_logs):
    """Test actual logging output"""
    logger = Logger(library_name="test_logger")
    log = logger.get_logger()

    test_message = "Test log message"
    log.info(test_message)

    # Read the log file
    with open("logs/log.log", "r") as f:
        log_content = f.read()

    assert test_message in log_content
    assert "test_logger" in log_content
    assert "INFO" in log_content


def test_logger_directory_creation(cleanup_logs):
    """Test log directory creation"""
    logger = Logger()

    assert os.path.exists("logs")
    assert os.path.isfile("logs/log.log")
