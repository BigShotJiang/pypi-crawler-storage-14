import pytest
import boto3
from moto import mock_aws
from analytics_toolkit.config import Configuration


@pytest.fixture
def sample_local_config_file(tmp_path):
    """
    Create a temporary configuration file for testing local config loading
    """
    config_content = """
[PROD]
database_host = prod-db.example.com
api_key = prod_secret_key

[NONPROD]
database_host = nonprod-db.example.com
api_key = nonprod_secret_key
"""
    config_path = tmp_path / "config.ini"
    config_path.write_text(config_content)
    return str(config_path)


@pytest.fixture
def s3_config_setup():
    """
    Mock S3 configuration for testing S3 config loading
    """
    with mock_aws():
        # Create S3 client with explicit region
        s3 = boto3.client("s3", region_name="us-west-1")

        # Create bucket with location constraint matching the region
        bucket_name = "test-config-bucket"
        s3.create_bucket(
            Bucket=bucket_name,
            CreateBucketConfiguration={"LocationConstraint": "us-west-1"},
        )

        # Prepare config content
        config_content = """
[PROD]
database_host = prod-db.example.com
api_key = prod_secret_key

[NONPROD]
database_host = nonprod-db.example.com
api_key = nonprod_secret_key
"""
        # Put object in the bucket
        s3.put_object(
            Bucket=bucket_name,
            Key="config/test_config.ini",
            Body=config_content.encode("utf-8"),
        )

        yield bucket_name


def test_configuration_initialization():
    """
    Test basic Configuration class initialization
    """
    config_dict = {"key1": "value1", "key2": "value2"}
    config = Configuration(config_dict)

    assert isinstance(config, dict)
    assert config["key1"] == "value1"
    assert config["key2"] == "value2"


def test_from_local_default_environment(sample_local_config_file, monkeypatch):
    """
    Test loading local configuration with default PROD environment
    """
    monkeypatch.delenv("ENVIRONMENT", raising=False)
    config = Configuration.from_local(sample_local_config_file)

    assert config["database_host"] == "prod-db.example.com"
    assert config["api_key"] == "prod_secret_key"


def test_from_local_nonprod_environment(sample_local_config_file, monkeypatch):
    """
    Test loading local configuration with NONPROD environment
    """
    monkeypatch.setenv("ENVIRONMENT", "NONPROD")
    config = Configuration.from_local(sample_local_config_file)

    assert config["database_host"] == "nonprod-db.example.com"
    assert config["api_key"] == "nonprod_secret_key"


def test_from_local_file_not_found():
    """
    Test error handling when local configuration file is not found
    """
    with pytest.raises(ValueError, match="Archivo de configuración no encontrado"):
        Configuration.from_local("/path/to/nonexistent/config.ini")


def test_from_local_missing_environment_section(sample_local_config_file, monkeypatch):
    """
    Test error handling when the specified environment section is missing
    """
    monkeypatch.setenv("ENVIRONMENT", "STAGING")
    with pytest.raises(ValueError, match="Sección de entorno STAGING no encontrada"):
        Configuration.from_local(sample_local_config_file)


@mock_aws
def test_from_s3_default_environment(s3_config_setup, monkeypatch):
    """
    Test loading configuration from S3 with default PROD environment
    """
    monkeypatch.delenv("ENVIRONMENT", raising=False)

    config = Configuration.from_s3(s3_config_setup, "config/test_config.ini")

    assert config["database_host"] == "prod-db.example.com"
    assert config["api_key"] == "prod_secret_key"


@mock_aws
def test_from_s3_nonprod_environment(s3_config_setup, monkeypatch):
    """
    Test loading configuration from S3 with NONPROD environment
    """
    monkeypatch.setenv("ENVIRONMENT", "NONPROD")

    config = Configuration.from_s3(s3_config_setup, "config/test_config.ini")

    assert config["database_host"] == "nonprod-db.example.com"
    assert config["api_key"] == "nonprod_secret_key"


@mock_aws
def test_from_s3_file_not_found(s3_config_setup):
    """
    Test error handling when S3 configuration file is not found
    """
    with pytest.raises(
        ValueError, match="Archivo de configuración no encontrado en S3"
    ):
        Configuration.from_s3(s3_config_setup, "config/nonexistent_config.ini")
