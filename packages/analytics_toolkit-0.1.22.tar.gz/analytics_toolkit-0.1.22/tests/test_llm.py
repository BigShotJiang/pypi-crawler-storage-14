import pytest
import pandas as pd
import asyncio
from datetime import datetime
from unittest.mock import Mock, patch

# Add this import for async tests
import pytest_asyncio

from analytics_toolkit.llm import (
    PromptsConfig,
    llm_call,
    llm_call_async,
    _get_model_prices,
    _set_dicctionary_py,
)


@pytest.fixture
def sample_df():
    """Fixture that creates a sample DataFrame for testing"""
    return pd.DataFrame(
        {
            "id": ["doc1", "doc2"],
            "text": [
                "El cambio climático afecta gravemente al planeta.",
                "La innovación tecnológica impulsa el desarrollo económico.",
            ],
        }
    )


@pytest.fixture
def prompts_config_single():
    """Fixture that creates a PromptsConfig with single prompt"""
    return PromptsConfig(
        context="Eres un analista experto", prompt="Resume el siguiente texto"
    )


@pytest.fixture
def prompts_config_multiple():
    """Fixture that creates a PromptsConfig with multiple prompts"""
    return PromptsConfig(
        context="Eres un analista experto",
        prompt=["Identifica el tema", "Extrae palabras clave"],
        keys_list=["tema", "keywords"],
    )


@pytest.fixture
def mock_s3_storage():
    """Fixture that creates a mocked S3Storage instance"""
    mock_storage = Mock()
    mock_storage.get_history.return_value = pd.DataFrame()
    mock_storage.upload_df = Mock()
    return mock_storage


@pytest.fixture
def mock_llm_response():
    """Fixture that creates a mock LLM response"""
    return {
        "model": "gpt-4",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "Test response"},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "promptTokens": 10,
            "completionTokens": 5,
            "totalTokens": 15,
            "totalPrice": 0.0015,
        },
    }


@pytest.fixture
def mock_llm_response_multiple():
    """Fixture that creates a mock LLM response for multiple prompts"""
    return {
        "model": "gpt-4",
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": '{"tema": "Test tema", "keywords": "test, keywords"}',
                },
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "promptTokens": 15,
            "completionTokens": 8,
            "totalTokens": 23,
            "totalPrice": 0.0025,
        },
    }


def test_prompts_config_single():
    """Test PromptsConfig initialization with single prompt"""
    config = PromptsConfig(context="Test context", prompt="Test prompt")

    assert config.context == "Test context"
    assert config.prompt == "Test prompt"
    assert config.keys_list is None
    assert config.context_template == ""


def test_prompts_config_multiple():
    """Test PromptsConfig initialization with multiple prompts"""
    prompts = ["Prompt 1", "Prompt 2"]
    keys = ["key1", "key2"]

    config = PromptsConfig(context="Test context", prompt=prompts, keys_list=keys)

    assert config.context == "Test context"
    assert config.prompt == prompts
    assert config.keys_list == keys
    assert config.context_template != ""


def test_prompts_config_from_redshift():
    """Test PromptsConfig.from_redshift creation method"""
    with patch("analytics_toolkit.llm._rs_connection") as mock_rs:
        # Mock single prompt response
        mock_rs.query.side_effect = [
            pd.DataFrame({"context": ["Test context"]}),
            pd.DataFrame({"prompt_id": [1], "prompt": ["Test prompt"]}),
        ]

        config = PromptsConfig.from_redshift(1, [1])
        assert config.context == "Test context"
        assert config.prompt == ["Test prompt"]

        # Reset mock side_effect for multiple prompts test
        mock_rs.query.side_effect = [
            pd.DataFrame({"context": ["Test context"]}),
            pd.DataFrame({"prompt_id": [1, 2], "prompt": ["Prompt 1", "Prompt 2"]}),
        ]

        config = PromptsConfig.from_redshift(1, [1, 2])
        assert config.context == "Test context"
        assert isinstance(config.prompt, list)
        assert len(config.prompt) == 2


def test_prompts_config_context_template():
    """Test PromptsConfig context template generation"""
    # Single prompt
    config_single = PromptsConfig(context="Test context", prompt="Single prompt")
    assert config_single.context_template == ""

    # Multiple prompts
    config_multiple = PromptsConfig(
        context="Test context",
        prompt=["Prompt 1", "Prompt 2"],
        keys_list=["key1", "key2"],
    )
    assert "dictionary" in config_multiple.context_template.lower()
    assert "key-value pairs" in config_multiple.context_template.lower()


def test_prompts_config_validation():
    """Test PromptsConfig validation for mismatched prompts and keys"""
    prompts = ["Prompt 1", "Prompt 2"]
    keys = ["key1"]

    with pytest.raises(ValueError):
        PromptsConfig(context="Test context", prompt=prompts, keys_list=keys)


def test_get_formatted_prompts_single():
    """Test get_formatted_prompts with single prompt"""
    config = PromptsConfig(context="Test context", prompt="Test prompt")

    result = config.get_formatted_prompts()
    assert result == "Test prompt"


def test_get_formatted_prompts_multiple():
    """Test get_formatted_prompts with multiple prompts"""
    config = PromptsConfig(
        context="Test context",
        prompt=["Prompt 1", "Prompt 2"],
        keys_list=["key1", "key2"],
    )

    result = config.get_formatted_prompts()
    assert isinstance(result, dict)
    assert "str" in result
    assert "keys" in result
    assert result["keys"] == ["key1", "key2"]


def test_set_dictionary_py():
    """Test _set_dicctionary_py function"""
    # Test valid JSON string
    json_str = '{"key1": "value1", "key2": "value2"}'
    result = _set_dicctionary_py(json_str)
    assert isinstance(result, dict)
    assert result == {"key1": "value1", "key2": "value2"}

    # Test valid Python dict string
    py_str = "{'key1': 'value1', 'key2': 'value2'}"
    result = _set_dicctionary_py(py_str)
    assert isinstance(result, dict)
    assert result == {"key1": "value1", "key2": "value2"}

    # Test invalid string
    invalid_str = "Not a dictionary"
    result = _set_dicctionary_py(invalid_str)
    assert result is None


@patch("analytics_toolkit.llm._rs_connection")
def test_get_model_prices(mock_rs_connection):
    """Test _get_model_prices function"""
    # Mock the query response
    mock_df = pd.DataFrame(
        {
            "modelo": ["gpt-4"],
            "precio_input_token": [0.01],
            "precio_output_token": [0.02],
        }
    )
    mock_rs_connection.query.return_value = mock_df

    result = _get_model_prices("test_table", 1)

    assert result.modelo == "gpt-4"
    assert result.precio_input_token == 0.01
    assert result.precio_output_token == 0.02


@pytest_asyncio.fixture
async def mock_async_response():
    """Async fixture for LLM response"""
    return {
        "model": "gpt-4",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "Test response"},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "promptTokens": 10,
            "completionTokens": 5,
            "totalTokens": 15,
            "totalPrice": 0.0015,
        },
    }


@pytest.mark.asyncio
@patch("analytics_toolkit.llm._get_model_prices")
@patch("analytics_toolkit.llm._format_llm_call")
async def test_llm_call_async(
    mock_format_llm_call,
    mock_get_model_prices,
    sample_df,
    prompts_config_single,
    mock_s3_storage,
):
    """Test llm_call_async function"""
    # Mock model prices
    mock_get_model_prices.return_value = pd.Series(
        {"modelo": "gpt-4", "precio_input_token": 0.01, "precio_output_token": 0.02}
    )

    # Mock LLM response for single prompt
    mock_format_llm_call.return_value = {
        "model": "gpt-4",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "Test response"},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "promptTokens": 10,
            "completionTokens": 5,
            "totalTokens": 15,
            "totalPrice": 0.0015,
        },
    }

    results = await llm_call_async(
        analysis_info=sample_df,
        id_field="id",
        analysis_field="text",
        prompts_config=prompts_config_single,
        process="test_process",
        service="nfq",
        storage_config=mock_s3_storage,
        trace=False,
    )

    assert len(results) == 2
    assert all(isinstance(r, dict) for r in results)
    assert all("response" in r for r in results)
    assert mock_s3_storage.upload_df.call_count == 1


def test_llm_call_validation(sample_df, prompts_config_single):
    """Test llm_call input validation"""
    # Test with invalid id_field
    with pytest.raises(ValueError):
        llm_call(
            analysis_info=sample_df,
            id_field="invalid_id",
            analysis_field="text",
            prompts_config=prompts_config_single,
            process="test_process",
            service="nfq",
        )

    # Test with invalid analysis_field
    with pytest.raises(ValueError):
        llm_call(
            analysis_info=sample_df,
            id_field="id",
            analysis_field="invalid_field",
            prompts_config=prompts_config_single,
            process="test_process",
            service="nfq",
        )


@pytest.mark.asyncio
async def test_llm_call_with_empty_values(
    sample_df, prompts_config_single, mock_s3_storage
):
    """Test llm_call handling of empty/NaN values"""
    # Add a row with NaN value
    df_with_nan = sample_df.copy()
    df_with_nan.loc[len(df_with_nan)] = ["doc3", float("nan")]

    with (
        patch("analytics_toolkit.llm._get_model_prices") as mock_prices,
        patch("analytics_toolkit.llm._format_llm_call") as mock_llm,
    ):

        mock_prices.return_value = pd.Series(
            {"modelo": "gpt-4", "precio_input_token": 0.01, "precio_output_token": 0.02}
        )

        # Mock LLM response
        mock_llm.return_value = {
            "model": "gpt-4",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "Test response"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "promptTokens": 10,
                "completionTokens": 5,
                "totalTokens": 15,
                "totalPrice": 0.0015,
            },
        }

        results = await llm_call_async(
            analysis_info=df_with_nan,
            id_field="id",
            analysis_field="text",
            prompts_config=prompts_config_single,
            process="test_process",
            service="nfq",
        )

        # Should only process non-NaN rows
        assert len(results) == 2
        assert all(r["id"] != "doc3" for r in results)
        # Verify that mock_llm was called only twice (for non-NaN rows)
        assert mock_llm.call_count == 2


@pytest.mark.asyncio
async def test_llm_call_with_retries(mock_llm_response, prompts_config_single):
    """Test llm_call retry mechanism"""
    df = pd.DataFrame({"id": ["doc1"], "text": ["Test text"]})

    with (
        patch("analytics_toolkit.llm._get_model_prices") as mock_prices,
        patch("analytics_toolkit.llm._format_llm_call") as mock_llm,
    ):

        mock_prices.return_value = pd.Series(
            {"modelo": "gpt-4", "precio_input_token": 0.01, "precio_output_token": 0.02}
        )

        # Simulate 2 failures followed by success
        mock_llm.side_effect = [None, None, mock_llm_response]

        results = await llm_call_async(
            analysis_info=df,
            id_field="id",
            analysis_field="text",
            prompts_config=prompts_config_single,
            process="test_process",
            service="nfq",
        )

        assert len(results) == 1
        assert results[0]["retries"] == 2


@pytest.mark.asyncio
async def test_llm_call_multiple_prompts(
    sample_df, prompts_config_multiple, mock_s3_storage
):
    """Test llm_call with multiple prompts"""
    with (
        patch("analytics_toolkit.llm._get_model_prices") as mock_prices,
        patch("analytics_toolkit.llm._format_llm_call") as mock_llm,
    ):

        mock_prices.return_value = pd.Series(
            {"modelo": "gpt-4", "precio_input_token": 0.01, "precio_output_token": 0.02}
        )

        # Mock LLM response for multiple prompts
        mock_llm.return_value = {
            "model": "gpt-4",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": '{"tema": "Test tema", "keywords": "test, keywords"}',
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "promptTokens": 15,
                "completionTokens": 8,
                "totalTokens": 23,
                "totalPrice": 0.0025,
            },
        }

        results = await llm_call_async(
            analysis_info=sample_df,
            id_field="id",
            analysis_field="text",
            prompts_config=prompts_config_multiple,
            process="test_process",
            service="nfq",
            storage_config=mock_s3_storage,
            trace=False,
        )

        assert len(results) == 2
        for result in results:
            assert isinstance(result["response"], pd.DataFrame)
            assert "tema" in result
            assert "keywords" in result
            assert len(result["response"]) == 2  # Two prompts


@pytest.mark.asyncio
async def test_llm_call_concurrency(
    sample_df, prompts_config_single, mock_llm_response
):
    """Test llm_call concurrency control"""
    # Create larger dataset
    large_df = pd.concat([sample_df] * 5, ignore_index=True)

    with (
        patch("analytics_toolkit.llm._get_model_prices") as mock_prices,
        patch("analytics_toolkit.llm._format_llm_call") as mock_llm,
    ):

        mock_prices.return_value = pd.Series(
            {"modelo": "gpt-4", "precio_input_token": 0.01, "precio_output_token": 0.02}
        )

        mock_llm.return_value = mock_llm_response

        # Test with different concurrency values
        for max_concurrency in [2, 5]:
            # Reset the mock for each concurrency test
            mock_llm.reset_mock()

            results = await llm_call_async(
                analysis_info=large_df,
                id_field="id",
                analysis_field="text",
                prompts_config=prompts_config_single,
                process="test_process",
                service="nfq",
                max_concurrency=max_concurrency,
                trace=False,
            )

            assert len(results) == len(large_df)

            # Verify that calls were made in batches
            call_args_list = mock_llm.call_args_list
            assert len(call_args_list) == len(large_df)

            # Verify that calls were made in appropriate batch sizes
            num_full_batches = len(large_df) // max_concurrency
            remaining_items = len(large_df) % max_concurrency

            # Check the timing of calls to ensure they were made in batches
            for batch_idx in range(num_full_batches):
                batch_calls = call_args_list[
                    batch_idx * max_concurrency : (batch_idx + 1) * max_concurrency
                ]
                assert len(batch_calls) == max_concurrency

            if remaining_items:
                final_batch = call_args_list[num_full_batches * max_concurrency :]
                assert len(final_batch) == remaining_items

            # Verify each result has the expected structure
            for result in results:
                assert "response" in result
                assert "id" in result
                assert "fec_proceso" in result
                assert "proceso" in result
                assert "metodo" in result
                assert "model" in result
                assert "prompt_tokens" in result
                assert "completion_tokens" in result
                assert "total_price" in result
                assert "retries" in result
