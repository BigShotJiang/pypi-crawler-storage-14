import pytest
import boto3
import pandas as pd
from moto import mock_aws
from datetime import datetime
from analytics_toolkit.storage import S3Storage
from unittest.mock import patch, MagicMock


@pytest.fixture
def s3_bucket():
    """Create test bucket."""
    with mock_aws():
        bucket_name = "test-storage-bucket"
        s3 = boto3.client("s3", region_name="eu-west-1")
        s3.create_bucket(
            Bucket=bucket_name,
            CreateBucketConfiguration={"LocationConstraint": "eu-west-1"},
        )
        yield bucket_name


@pytest.fixture
def sample_df():
    """Sample DataFrame for testing."""
    return pd.DataFrame({"id": [1, 2, 3], "value": ["a", "b", "c"]})


@pytest.fixture
def storage(s3_bucket):
    """S3Storage instance for testing."""
    return S3Storage(
        bucket=s3_bucket,
        path="test/results",
        file_name="test_data",
        date=datetime(2024, 1, 1),
    )


def test_storage_initialization(storage):
    """Test storage initialization."""
    assert storage.bucket == "test-storage-bucket"
    assert storage.path == "test/results"
    assert storage.file_name == "test_data"
    assert storage.date == datetime(2024, 1, 1)
    assert (
        storage.s3_path
        == "s3://test-storage-bucket/test/results/test_data/20240101_test_data.csv"
    )


@patch("pandas.DataFrame.to_csv")
def test_upload_df(mock_to_csv, storage, sample_df):
    """Test DataFrame upload."""
    storage.upload_df(sample_df)

    mock_to_csv.assert_called_once_with(
        storage.s3_path, sep="#", index=False, mode="w", lineterminator="\n"
    )


@patch("boto3.client")
@patch("pandas.read_csv")
def test_get_history_existing_file(mock_read_csv, mock_boto3, storage, sample_df):
    """Test history retrieval with existing file."""
    # Mock S3 client
    mock_s3 = MagicMock()
    mock_boto3.return_value = mock_s3

    # Mock successful head_object call
    mock_s3.head_object.return_value = {}

    # Mock read_csv return value
    mock_read_csv.return_value = sample_df

    result_df = storage.get_history("id")

    # Verify S3 client calls
    mock_s3.head_object.assert_called_once()

    # Verify read_csv call
    mock_read_csv.assert_called_once_with(storage.s3_path, delimiter="#", dtype=object)

    pd.testing.assert_frame_equal(result_df, sample_df)


@patch("pandas.read_csv")
@patch("boto3.client")
def test_get_history_non_existing_file(mock_boto3, mock_read_csv, storage):
    """Test history retrieval with non-existing file."""
    # Mock S3 client
    mock_s3 = MagicMock()
    mock_boto3.return_value = mock_s3

    # Mock head_object to raise NoSuchKey
    mock_s3.head_object.side_effect = boto3.client("s3").exceptions.NoSuchKey(
        {}, "HeadObject"
    )

    # Create empty DataFrame with id column
    empty_df = pd.DataFrame(columns=["id"])
    mock_read_csv.return_value = empty_df

    result_df = storage.get_history("id")

    assert list(result_df.columns) == ["id"]
    assert len(result_df) == 0
