import pytest
import pandas as pd
import psycopg2
from unittest.mock import patch, MagicMock
from analytics_toolkit.aws import RedshiftConnect


class TestRedshiftConnect:
    @pytest.fixture
    def mock_config(self):
        """Fixture to mock the configuration settings"""
        return {
            "rs_dbname": "test_database",
            "rs_host": "test-cluster.redshift.amazonaws.com",
            "rs_port": "5439",
            "rs_user": "test_user",
            "rs_password": "test_password",
        }

    def test_init_method(self):
        """Test the initialization of RedshiftConnect"""
        conn = RedshiftConnect(
            dbname="test_db",
            host="test-host",
            port="5439",
            user="test_user",
            password="test_pass",
        )

        assert conn.dbname == "test_db"
        assert conn.host == "test-host"
        assert conn.port == "5439"
        assert conn.user == "test_user"
        assert conn.password == "test_pass"

    @pytest.fixture
    def mock_config_data(self):
        """Fixture to provide mock configuration data"""
        return {
            "rs_dbname": "test_database",
            "rs_host": "test-cluster.redshift.amazonaws.com",
            "rs_port": "5439",
            "rs_user": "test_user",
            "rs_password": "test_password",
        }

    @patch("analytics_toolkit._shared._config")
    def test_from_analytics_method(self, mock_config, mock_config_data):
        """Test the from_analytics class method"""
        # Directly set the mock configuration values
        mock_config.__getitem__ = lambda self, key: mock_config_data[key]

        # Create the connection using from_analytics method
        conn = RedshiftConnect.from_analytics()

        # Assertions
        assert conn.dbname == mock_config_data["rs_dbname"]
        assert conn.host == mock_config_data["rs_host"]
        assert conn.port == mock_config_data["rs_port"]
        assert conn.user == mock_config_data["rs_user"]
        assert conn.password == mock_config_data["rs_password"]

    @patch("psycopg2.connect")
    @patch("pandas.read_sql")
    def test_query_successful(self, mock_read_sql, mock_connect):
        """Test successful query execution"""
        # Setup mock data
        mock_connection = MagicMock()
        mock_connect.return_value = mock_connection

        expected_df = pd.DataFrame({"id": [1, 2], "name": ["John", "Jane"]})
        mock_read_sql.return_value = expected_df

        # Create RedshiftConnect instance
        conn = RedshiftConnect(
            dbname="test_database",
            host="test-host",
            port="5439",
            user="test_user",
            password="test_pass",
        )

        # Execute query
        result_df = conn.query("SELECT * FROM test_table")

        # Assertions
        mock_connect.assert_called_once_with(
            dbname="test_database",
            host="test-host",
            port="5439",
            user="test_user",
            password="test_pass",
        )
        mock_read_sql.assert_called_once_with(
            "SELECT * FROM test_table", con=mock_connection
        )
        pd.testing.assert_frame_equal(result_df, expected_df)
        mock_connection.close.assert_called_once()

    @patch("psycopg2.connect")
    @patch("analytics_toolkit._shared._logger")
    def test_query_error_handling(self, mock_logger, mock_connect):
        """Test error handling in query method"""
        # Simulate connection error
        mock_connect.side_effect = psycopg2.Error("Connection failed")

        # Create RedshiftConnect instance
        conn = RedshiftConnect(
            dbname="test_db",
            host="test-host",
            port="5439",
            user="test_user",
            password="test_pass",
        )

        # Execute query
        result_df = conn.query("SELECT * FROM test_table")

        # Assertions
        assert result_df.empty
        mock_logger.critical.assert_called_once()
        assert mock_logger.critical.call_args[0][0].startswith(
            "Se ha producido un error al ejecutar la query"
        )

    def test_query_method_signature(self):
        """Test the query method signature"""
        conn = RedshiftConnect(
            dbname="test_db",
            host="test-host",
            port="5439",
            user="test_user",
            password="test_pass",
        )

        # Check method exists and accepts a string parameter
        assert hasattr(conn, "query")
        assert callable(conn.query)

        with pytest.raises(TypeError):
            conn.query()  # Should raise TypeError if no argument is provided
