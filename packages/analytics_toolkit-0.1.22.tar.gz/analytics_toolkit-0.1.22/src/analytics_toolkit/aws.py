"""
Módulo de Conexión a Amazon Redshift para Analytics Toolkit

Este módulo proporciona herramientas para interactuar de manera segura
y eficiente con bases de datos Amazon Redshift, facilitando la ejecución
de consultas y la recuperación de datos.

Características principales:
- Conexión simplificada a bases de datos Redshift
- Ejecución de consultas SQL
- Conversión automática de resultados a DataFrames
- Manejo seguro de credenciales
- Gestión de conexiones y errores

Componentes principales:
- RedshiftConnect: Clase para manejar conexiones a Redshift
- query(): Método para ejecutar consultas SQL
- from_analytics(): Método de clase para configuración predeterminada

Ejemplo de uso básico:
```python
from analytics_toolkit.aws import RedshiftConnect

# Crear conexión usando configuración predeterminada
conn = RedshiftConnect.from_analytics()

# Ejecutar una consulta simple
df_usuarios = conn.query("SELECT * FROM usuarios LIMIT 10")

# Ejecutar una consulta con filtros
df_filtrado = conn.query('''
    SELECT nombre, edad
    FROM usuarios
    WHERE departamento = 'Ventas'
''')
```

Funcionalidades de conexión:
- Autenticación segura
- Configuración flexible de parámetros de conexión
- Soporte para múltiples entornos

Métodos de inicialización:
- Configuración manual de credenciales
- Carga automática desde configuración de analytics

Gestión de conexiones:
- Conexión y desconexión automática
- Manejo de errores
- Registro de errores críticos

Dependencias:
- psycopg2: Conexión a bases de datos PostgreSQL/Redshift
- pandas: Conversión de resultados a DataFrames

Patrones de uso:
- Extracción de datos para análisis
- Consultas de reporting
- Integración de datos
- Preparación de datasets

Consideraciones de seguridad:
- No almacenar credenciales directamente en código
- Usar métodos seguros de configuración
- Manejar excepciones de conexión
- Cerrar conexiones después de su uso

Tipos de consultas soportadas:
- Consultas SELECT
- Consultas de agregación
- Joins
- Subconsultas

Manejo de errores:
- Registro de errores críticos
- Devolución de DataFrame vacío en caso de error
- Cierre de conexión incluso en caso de excepción

Formato de resultados:
- Conversión automática a pandas DataFrame
- Preservación de tipos de datos originales
- Fácil manipulación y análisis
"""

import psycopg2
import pandas as pd
import threading
import time


__all__ = ["RedshiftConnect"]


class RedshiftConnect:
    """Configuración para utilizar base de datos en Redshift

    Esta clase contiene los parámetros necesarios para establecer
    una conexión con una base de datos Amazon Redshift.

    Attributes
    ----------
    dbname : str
        Nombre de la base de datos Redshift.
        Identifica la base de datos específica a la que se conectará.

    host : str
        Hostname o dirección IP del cluster Redshift.
        Especifica la ubicación del servidor de base de datos.

    port : str
        Puerto para la conexión (típicamente 5439).
        Define el puerto de comunicación con el servidor de base de datos.

    user : str
        Nombre de usuario para autenticación.
        Credencial utilizada para acceder a la base de datos.

    password : str
        Contraseña para autenticación.
        Credencial segura para verificar la identidad del usuario.
    """

    @classmethod
    def from_analytics(cls) -> "RedshiftConnect":
        """
        Crea una instancia de RedshiftConnect usando la configuración de base de datos de analytics.

        Returns
        -------
        RedshiftConnect
            Nueva instancia configurada con las credenciales de analytics.

        Notes
        -----
        - Utiliza la configuración predefinida en el módulo _shared
        - Extrae las credenciales de Redshift desde _config
        """
        from ._shared import _config

        return cls(
            dbname=_config["rs_dbname"],
            host=_config["rs_host"],
            port=_config["rs_port"],
            user=_config["rs_user"],
            password=_config["rs_password"],
        )

    def __init__(self, dbname: str, host: str, port: str, user: str, password: str):
        """
        Inicializa una nueva configuración de Redshift.

        Parameters
        ----------
        dbname : str
            Nombre de la base de datos Redshift.
            Identifica la base de datos específica a la que se conectará.

        host : str
            Hostname o dirección IP del cluster Redshift.
            Especifica la ubicación del servidor de base de datos.

        port : str
            Puerto para la conexión (típicamente 5439).
            Define el puerto de comunicación con el servidor de base de datos.

        user : str
            Nombre de usuario para autenticación.
            Credencial utilizada para acceder a la base de datos.

        password : str
            Contraseña para autenticación.
            Credencial segura para verificar la identidad del usuario.

        Examples
        --------
        Crear una conexión usando credenciales directas:
        >>> conn = RedshiftConnect(
        ...     dbname="mi_base_datos",
        ...     host="mi-cluster.redshift.amazonaws.com",
        ...     port="5439",
        ...     user="mi_usuario",
        ...     password="mi_contraseña_segura"
        ... )

        Crear una conexión usando configuración de analytics:
        >>> conn = RedshiftConnect.from_analytics()
        """
        self.dbname = dbname
        self.host = host
        self.port = port
        self.user = user
        self.password = password

    def query(
        self, query: str, chunksize: int = 10000, timeout: int = 600, retries: int = 10
    ) -> pd.DataFrame:
        """
        Función para lanzar una query a la base de datos de Redshift.

        Parameters
        ----------
        query : str
            La consulta SQL a ejecutar.
            Debe ser una cadena de texto con una consulta SQL válida.
        chunksize : int, optional
            Número de filas por chunk al leer los datos.
            Por defecto es 10000.
        timeout : int, optional
            Tiempo máximo de espera en segundos para la ejecución completa de la consulta.
            Por defecto es 600 (10 minutos).
            Este timeout garantiza la interrupción a nivel de Python.
        retries : int, optional
            Número de reintentos si la consulta falla o alcanza el timeout.
            Por defecto es 10.

        Returns
        -------
        pandas.DataFrame
            El resultado de la consulta SQL.
            Devuelve los datos recuperados como un DataFrame de pandas.
        """
        from ._shared import _logger

        _logger.debug(
            f"Iniciando consulta con timeout={timeout}s, reintentos={retries}"
        )

        # Implementar reintentos
        for attempt in range(1, retries + 1):
            if attempt > 1:
                _logger.debug(f"Reintento {attempt}/{retries} de la consulta")
                # Pequeña pausa antes de reintentar, aumentando con cada intento
                time.sleep(attempt * 5)  # Espera progresiva: 5s, 10s, 15s...

            # Usamos un objeto Event para señalizar cuando la consulta debe detenerse
            stop_event = threading.Event()
            result = None
            error = None

            def _execute_query():
                nonlocal result, error
                con = None
                try:
                    # Verificar si debemos detener la ejecución
                    if stop_event.is_set():
                        return

                    con = psycopg2.connect(
                        dbname=self.dbname,
                        host=self.host,
                        port=self.port,
                        user=self.user,
                        password=self.password,
                    )

                    # Verificar si debemos detener la ejecución
                    if stop_event.is_set():
                        if con:
                            con.close()
                        return

                    _logger.debug(
                        f"Iniciando lectura de datos en chunks de {chunksize} filas"
                    )

                    chunks = []
                    total_rows = 0
                    chunk_count = 0

                    # Crear un cursor y ejecutar la consulta
                    cursor = con.cursor()
                    cursor.execute(query)

                    # Procesar resultados en chunks
                    while True:
                        # Verificar si debemos detener la ejecución
                        if stop_event.is_set():
                            break

                        # Obtener un chunk de datos
                        rows = cursor.fetchmany(chunksize)
                        if not rows:
                            break

                        # Convertir a DataFrame
                        columns = [desc[0] for desc in cursor.description]
                        chunk = pd.DataFrame(rows, columns=columns)

                        chunk_count += 1
                        chunk_rows = len(chunk)
                        total_rows += chunk_rows
                        _logger.debug(
                            f"Procesando chunk {chunk_count}: {chunk_rows} filas (total acumulado: {total_rows})"
                        )
                        chunks.append(chunk)

                    # Combinar todos los chunks
                    if chunks and not stop_event.is_set():
                        df = pd.concat(chunks, ignore_index=True)
                        _logger.debug(
                            f"Lectura completada. Total de chunks: {chunk_count}, total de filas: {len(df)}"
                        )
                        result = df
                    elif not stop_event.is_set():
                        _logger.warning("La consulta no devolvió ningún resultado")
                        result = pd.DataFrame()

                except Exception as e:
                    if (
                        not stop_event.is_set()
                    ):  # Solo registrar errores si no estamos deteniendo intencionalmente
                        error_message = (
                            f"Se ha producido un error al ejecutar la query: {str(e)}"
                        )
                        _logger.warning(error_message)
                        error = str(e)
                finally:
                    if con:
                        try:
                            con.close()
                        except:
                            pass

            # Iniciar el hilo de ejecución
            query_thread = threading.Thread(target=_execute_query)
            query_thread.daemon = True
            query_thread.start()

            # Esperar a que el hilo termine o se alcance el timeout
            query_thread.join(timeout=timeout)

            # Si el hilo sigue vivo después del timeout
            if query_thread.is_alive():
                _logger.warning(
                    f"Timeout alcanzado después de {timeout} segundos (intento {attempt}/{retries})"
                )
                stop_event.set()  # Señalizar al hilo que debe detenerse

                # Esperar un poco para que el hilo se detenga limpiamente
                cleanup_timeout = 2.0  # 2 segundos para limpieza
                cleanup_start = time.time()
                while (
                    query_thread.is_alive()
                    and (time.time() - cleanup_start) < cleanup_timeout
                ):
                    time.sleep(0.1)

                # Si después de esperar el hilo sigue vivo, continuamos con el siguiente intento
                if attempt < retries:
                    _logger.debug(
                        f"Reintentando después del timeout (intento {attempt}/{retries})"
                    )
                    continue
                else:
                    _logger.critical(f"Todos los intentos alcanzaron el timeout")
                    return pd.DataFrame()

            # Si el hilo terminó normalmente y tenemos un resultado
            if result is not None:
                if attempt > 1:
                    _logger.debug(f"Consulta exitosa después de {attempt} intentos")
                return result

            # Si hubo un error pero no es el último intento
            if error is not None and attempt < retries:
                _logger.warning(
                    f"Intento {attempt}/{retries} falló: {error}. Reintentando..."
                )
            # Si es el último intento y falló
            elif error is not None:
                _logger.critical(f"Todos los intentos fallaron. Último error: {error}")

        # Si llegamos aquí, todos los intentos fallaron
        return pd.DataFrame()
