"""
Módulo de Gestión de Configuraciones para Analytics Toolkit

Este módulo proporciona una solución flexible y segura para manejar
configuraciones de entorno, con soporte para carga desde archivos locales
y almacenamiento remoto en Amazon S3.

Características principales:
- Carga de configuraciones desde archivos locales e S3
- Soporte para múltiples entornos (PROD, NONPROD)
- Manejo seguro de credenciales y parámetros de configuración
- Abstracción de fuentes de configuración
- Gestión dinámica de variables de entorno

Componentes principales:
- Configuration: Clase para manejar configuraciones como diccionario
- from_s3(): Método para cargar configuraciones desde S3
- from_local(): Método para cargar configuraciones desde archivos locales

Ejemplo de uso básico:
```python
from analytics_toolkit.config import Configuration

# Cargar configuración desde S3
config_s3 = Configuration.from_s3(
    s3_bucket="mi-bucket",
    s3_path="config/config.ini"
)

# Cargar configuración desde archivo local
config_local = Configuration.from_local(
    config_path="/path/to/config.ini"
)

# Acceder a configuraciones
database_host = config_s3['database_host']
api_key = config_local['api_key']
```

Fuentes de configuración:
- Archivos locales (.ini)
- Almacenamiento en Amazon S3
- Variables de entorno

Entornos soportados:
- PROD: Configuración de producción
- NONPROD: Configuración de no producción
- Personalizable mediante variable de entorno ENVIRONMENT

Funcionalidades avanzadas:
- Selección dinámica de entorno
- Manejo de errores en carga de configuraciones
- Codificación UTF-8 para archivos de configuración
- Herencia de configuraciones de ConfigParser

Dependencias:
- configparser: Lectura de archivos de configuración
- os: Manejo de variables de entorno
- boto3: Interacción con Amazon S3

Patrones de uso:
- Gestión de credenciales
- Configuración de servicios
- Parametrización de entornos
- Separación de configuraciones sensibles

Consideraciones de seguridad:
- No almacenar credenciales directamente en código
- Usar variables de entorno
- Restringir acceso a archivos de configuración
- Usar HTTPS para transferencias desde S3

Formato de archivo de configuración:
```ini
[PROD]
database_host = production-db.example.com
api_key = secret_production_key

[NONPROD]
database_host = staging-db.example.com
api_key = secret_staging_key
```

Manejo de errores:
- Validación de existencia de archivos
- Detección de entornos no configurados
- Información descriptiva de errores
"""

import configparser
import os
import boto3


__all__ = ["Configuration"]


class Configuration(dict):
    def __init__(self, config_dict: dict):
        """
        Inicializa Configuration con un diccionario de configuraciones.

        Parameters
        ----------
        config_dict : dict
            Diccionario con los parámetros de configuración.

        Examples
        --------
        >>> config = Configuration({"key1": "value1", "key2": "value2"})
        """
        super().__init__(config_dict)

    @classmethod
    def from_s3(cls, s3_bucket: str, s3_path: str) -> "Configuration":
        """
        Crea una instancia de Configuration desde un archivo de configuración en S3.

        Parameters
        ----------
        s3_bucket : str
            Nombre del bucket de S3 donde se encuentra el archivo de configuración.
            Identifica el bucket de almacenamiento en AWS S3.

        s3_path : str
            Ruta del archivo de configuración dentro del bucket.
            Especifica la ubicación exacta en S3 del archivo de configuración.

        Returns
        -------
        Configuration
            Instancia de Configuration con las configuraciones del entorno.

        Examples
        --------
        >>> config = Configuration.from_s3("mi-bucket", "config/config.ini")

        Notes
        -----
        - Utiliza la variable de entorno ENVIRONMENT para seleccionar la configuración
        - Por defecto usa el entorno "NONPROD" si no se especifica ENVIRONMENT
        - Maneja errores de acceso y lectura del archivo de configuración
        """
        from ._shared import _environment

        s3 = boto3.client("s3", region_name="us-west-1")

        try:
            # Verificar si el bucket existe
            s3.head_bucket(Bucket=s3_bucket)

            # Intentar recuperar el objeto
            obj = s3.get_object(Bucket=s3_bucket, Key=s3_path)
            config_content = obj["Body"].read().decode("utf-8")
            config = configparser.ConfigParser()
            config.read_string(config_content)

            # Verificar si la seccion de entorno existe
            if _environment not in config.sections():
                raise ValueError(
                    f"Sección de entorno {_environment} no encontrada en el archivo de configuración"
                )

            return cls(dict(config[_environment]))
        except s3.exceptions.NoSuchBucket:
            raise ValueError(f"Bucket no encontrado: {s3_bucket}")
        except s3.exceptions.NoSuchKey:
            raise ValueError(f"Archivo de configuración no encontrado en S3: {s3_path}")
        except Exception as e:
            raise ValueError(f"Error accediendo a la configuración en S3: {str(e)}")

    @classmethod
    def from_local(cls, config_path: str) -> "Configuration":
        """
        Crea una instancia de Configuration desde un archivo de configuración local.

        Parameters
        ----------
        config_path : str
            Ruta del archivo de configuración local.
            Especifica la ubicación del archivo de configuración en el sistema de archivos.

        Returns
        -------
        Configuration
            Instancia de Configuration con las configuraciones del entorno.

        Examples
        --------
        >>> config = Configuration.from_local("/path/to/config.ini")

        Notes
        -----
        - Utiliza la variable de entorno ENVIRONMENT para seleccionar la configuración
        - Por defecto usa el entorno "NONPROD" si no se especifica ENVIRONMENT
        - Maneja errores de acceso y lectura del archivo de configuración
        """
        from ._shared import _environment

        # Verificar si el archivo existe
        if not os.path.exists(config_path):
            raise ValueError(f"Archivo de configuración no encontrado: {config_path}")

        try:
            config = configparser.ConfigParser()
            config.read(config_path)

            # Verificar si la seccion de entorno existe
            if _environment not in config.sections():
                raise ValueError(
                    f"Sección de entorno {_environment} no encontrada en el archivo de configuración"
                )

            return cls(dict(config[_environment]))
        except Exception as e:
            raise ValueError(f"Error al leer configuración local: {str(e)}")
