"""
Módulo de Detección y Etiquetado de Información Personal Identificable (PII)

Este módulo proporciona funcionalidades para detectar y etiquetar información
personal identificable (PII) en transcripciones de audios. Está especialmente diseñado
para procesar transcripciones de AWS Transcribe formateadas con separación por hablantes con el formato:

```
speaker0: ... | speaker1: ... | ...
```

pero también puede procesar texto sin separación por hablantes.

Características principales:
- Detección de múltiples tipos de PII
    - DNI
    - NIE
    - Teléfonos
    - Expedientes
    - Pólizas
- Procesamiento de números escritos en texto
- Manejo de referencias a letras (ej: "P de Pamplona")
- Soporte para textos con múltiples hablantes
- Etiquetado no intrusivo de información sensible

Funciones principales:
- detect_and_tag_pii: Detecta y etiqueta PII en un texto

Ejemplo de uso básico:
```python
from analytics_toolkit.pii import detect_and_tag_pii

# Procesar texto con información sensible
texto = "Mi DNI es doce treinta y cuatro cincuenta y seis setenta y ocho B"
texto_procesado, posiciones = detect_and_tag_pii(texto)
print(texto_procesado)  # Salida: "Mi DNI es [DNI_A]"
```

Configuraciones avanzadas:
- Detección de múltiples formatos de PII
- Manejo de diferentes patrones de números
- Procesamiento de referencias a letras
- Priorización de tipos de PII
- Resolución de solapamientos

Dependencias:
- re: Procesamiento de expresiones regulares
- number_parser: Conversión de números escritos a dígitos
- heapq: Gestión de prioridades en detección
- bisect: Búsqueda eficiente en rangos

Notas:
- El módulo está optimizado para transcripciones de AWS Transcribe con separación por hablantes
- Los tipos de PII se procesan en orden de prioridad
- Se evita el doble etiquetado de información
- El formato de etiquetado es [TIPO_A] para mantener legibilidad o [PII_A] para mantener la privacidad
"""

import re
from number_parser import parse
import heapq
from bisect import bisect_left

COMMON_WORDS = [
    # Unidades de tiempo
    "segundo",
    "segundos",
    "minuto",
    "minutos",
    "hora",
    "horas",
    "dia",
    "dias",
    "día",
    "días",
    "semana",
    "semanas",
    "mes",
    "meses",
    "año",
    "años",
    # Unidades de longitud
    "metro",
    "metros",
    "centimetro",
    "centímetro",
    "centimetros",
    "centímetros",
    "kilometro",
    "kilometros",
    "kilómetro",
    "kilómetros",
    "milla",
    "millas",
    # Unidades de peso
    "gramo",
    "gramos",
    "kilogramo",
    "kilogramos",
    "tonelada",
    "toneladas",
    # Unidades de volumen
    "litro",
    "litros",
    "mililitro",
    "mililitros",
    # Unidades monetarias
    "euro",
    "euros",
    "centimo",
    "céntimo",
    "centimos",
    "céntimos",
    "peseta",
    "pesetas",
    # Unidades de área
    "metro cuadrado",
    "metros cuadrados",
    "hectarea",
    "hectárea",
    "hectareas",
    "hectáreas",
    # Unidades de temperatura
    "grado",
    "grados",
    # Unidades de velocidad
    "kilometro por hora",
    "kilómetro por hora",
    "kilometros por hora",
    "kilómetros por hora",
    # Unidades de energía
    "vatio",
    "vatios",
    "kilovatio",
    "kilovatios",
    # Palabras genéricas de cantidad
    "unidad",
    "unidades",
    "pieza",
    "piezas",
    "par",
    "pares",
    "docena",
    "docenas",
    "centena",
    "centenas",
    "millar",
    "millares",
    "millones",
    # Dias de la semana
    "lunes",
    "martes",
    "miércoles",
    "miercoles",
    "jueves",
    "viernes",
    "sábado",
    "sabado",
    "domingo",
    # Meses del año
    "enero",
    "febrero",
    "marzo",
    "abril",
    "mayo",
    "junio",
    "julio",
    "agosto",
    "septiembre",
    "octubre",
    "noviembre",
    "diciembre",
    # Caracteres especiales
    "%",
    "$",
    "€",
    "£",
    "¥",
    "¢",
    "¢",
]


def _literal_to_digits(text: str, language: str) -> tuple[str, dict]:
    """
    Convierte números escritos en palabras a dígitos en el texto.

    Parameters
    ----------
    text : str
        Texto que contiene números escritos en palabras.
        El texto debe estar en el idioma especificado.

    language : str
        Idioma del texto para la conversión de números.
        Por ejemplo, 'es' para español.

    Returns
    -------
    tuple[str, dict]
        Una tupla que contiene:
        - El texto procesado con números convertidos a dígitos
        - Un diccionario con las posiciones de los números encontrados

    Notes
    -----
    - Utiliza caché para optimizar el rendimiento de la conversión
    - Maneja casos especiales como números con sufijos
    - Evita procesar rangos de texto ya procesados
    """
    words = text.split()

    word_positions = {}  # Formato: {(word, idx): (start, end)}
    current_pos = 0

    for idx, word in enumerate(words):
        word_start = text.find(word, current_pos)
        if word_start == -1:
            # Prueba desde el principio si no se encuentra
            current_pos = 0
            word_start = text.find(word, current_pos)

        word_end = word_start + len(word)
        word_positions[(word, idx)] = (word_start, word_end)
        current_pos = word_end

    # Agregar caché de parser para reducir el cuello de botella
    parse_cache = {}

    # Crear otras estructuras de seguimiento
    number_occurrences = {}
    number_heap = []

    # Almacenar rangos procesados como listas ordenadas para búsqueda binaria
    processed_ranges = []  # [(start1, end1), (start2, end2), ...]

    # Intentar cada tamaño de ventana desde el más grande al más pequeño
    for window_size in range(7, 0, -1):
        i = 0
        while i <= len(words) - window_size:
            # Obtener las posiciones inicial y final para esta frase
            first_word_key = (words[i], i)
            last_word_key = (words[i + window_size - 1], i + window_size - 1)

            if (
                first_word_key not in word_positions
                or last_word_key not in word_positions
            ):
                i += 1
                continue

            phrase_start = word_positions[first_word_key][0]
            phrase_end = word_positions[last_word_key][1]

            # Verificación eficiente de superposición usando búsqueda binaria
            overlaps = False

            # Búsqueda binaria para intervalos potencialmente superpuestos
            idx = bisect_left([r[0] for r in processed_ranges], phrase_start)

            # Verificar rangos que podrían superponerse
            # Verificar el rango en idx si existe
            if idx < len(processed_ranges) and processed_ranges[idx][0] < phrase_end:
                overlaps = True

            # También verificar el rango antes de idx, ya que podría superponerse
            if idx > 0 and processed_ranges[idx - 1][1] > phrase_start:
                overlaps = True

            if overlaps:
                i += 1
                continue

            # Obtener la frase y limpiarla
            phrase = " ".join(words[i : i + window_size])
            clean_phrase = re.split(r"[.,;:!?]", phrase.strip().lower())
            if len(clean_phrase) > 1:
                if len(clean_phrase[1]) > 0:
                    i += 1
                    continue
                else:
                    clean_phrase = clean_phrase[0]
                    phrase_end = phrase_start + len(clean_phrase) + 1
            else:
                clean_phrase = clean_phrase[0]

            if clean_phrase in ["un", "una", "unos", "unas", "ciento"]:
                i += 1
                continue

            try:
                # Usar caché para evitar análisis repetido
                if clean_phrase in parse_cache:
                    num = parse_cache[clean_phrase]
                else:
                    num = parse(clean_phrase, language=language)
                    parse_cache[clean_phrase] = num

                converted = str(num)

                # Verificar si el resultado contiene solo dígitos
                if converted.isdigit():
                    # Si la última palabra es "y", omitir el número porque deberia ser detectado con un window_size menor
                    if clean_phrase[-1] == "y":
                        i += 1
                        continue

                    # Rastrear el recuento de ocurrencias para este número
                    if converted not in number_occurrences:
                        number_occurrences[converted] = 0
                    number_occurrences[converted] += 1

                    # Agregar al max-heap con posición inicial negada
                    heapq.heappush(
                        number_heap,
                        (
                            -phrase_start,
                            converted,
                            phrase_end,
                            number_occurrences[converted],
                            i,
                            i + window_size,
                        ),
                    )

                    # Si se encuentra un número válido, agregarlo a los rangos procesados y mantenerlo ordenado
                    insert_idx = bisect_left(
                        [r[0] for r in processed_ranges], phrase_start
                    )
                    processed_ranges.insert(insert_idx, (phrase_start, phrase_end))

                    # Omitir las palabras que se han procesado
                    i += window_size
                    continue
            except:
                # Almacenar resultados negativos en caché para evitar intentos repetidos
                parse_cache[clean_phrase] = None
                pass

            i += 1

    # Crear el texto procesado con todos los números encontrados
    processed_words = words.copy()

    # Crear number_dict para construir durante la sustitución
    number_dict = {}

    # Procesar directamente desde el max-heap
    while number_heap:
        neg_start, num, end, occurrence, start_word_idx, end_word_idx = heapq.heappop(
            number_heap
        )
        start = -neg_start  # Convertir de vuelta a posición inicial positiva

        # Agregar a number_dict mientras se procesa cada número
        if num not in number_dict:
            number_dict[num] = []

        position_info = {"start": start, "end": end, "occurrence": occurrence}
        number_dict[num].append(position_info)

        # Agregar guión bajo con número de ocurrencia si es la segunda o posterior ocurrencia
        if occurrence > 1:
            modified_num = f"{num}_{occurrence - 1}"
        else:
            modified_num = num

        # Reemplazar las palabras con el número
        processed_words[start_word_idx:end_word_idx] = [modified_num]

    # Crear word_dict y procesar palabras repetidas
    word_dict = {}
    word_occurrences = {}
    current_pos = 0

    # Primero recolectar todas las palabras y sus posiciones
    for idx, word in enumerate(processed_words):
        # Ignorar palabras que ya son números
        number_word, number_occurrence = _get_word_value_and_index(word)
        if number_word in number_dict:
            current_pos = number_dict[number_word][-number_occurrence - 1]["end"]
            continue

        # Ignorar etiquetas de speaker, caracteres de separación "|" y palabras con corchetes
        if (
            re.match(r"speaker\d+", word)
            or re.match(r"\|", word)
            or re.search(r"\[.*\]", word)
        ):
            current_pos += len(word)
            continue

        # Obtener la posición original de la palabra
        word_start = text.find(word, current_pos)
        if word_start == -1:
            # Si no se encuentra desde la posición actual, buscar desde el principio
            current_pos = 0
            word_start = text.find(word, current_pos)
            if word_start == -1:
                # Si aún no se encuentra, continuar con la siguiente palabra
                continue

        word_end = word_start + len(word)
        current_pos = word_end

        # Actualizar el contador de ocurrencias
        if word not in word_occurrences:
            word_occurrences[word] = 0
        word_occurrences[word] += 1

        # Agregar la información de posición al diccionario
        if word not in word_dict:
            word_dict[word] = []

        position_info = {
            "start": word_start,
            "end": word_end,
            "occurrence": word_occurrences[word],
        }
        word_dict[word].append(position_info)

        # Modificar la palabra si es una ocurrencia posterior
        if word_occurrences[word] > 1:
            processed_words[idx] = f"{word}_{word_occurrences[word] - 1}"

    return " ".join(processed_words), number_dict, word_dict


def _split_by_speaker(text: str) -> dict[str, str]:
    """
    Divide el texto por identificadores de hablantes y retorna un diccionario con
    el texto concatenado de cada hablante.

    Parameters
    ----------
    text : str
        Texto que contiene identificadores de hablantes (speaker0:, speaker1:, etc.)
        y sus respectivos mensajes.

    Returns
    -------
    dict[str, str]
        Diccionario donde las claves son los identificadores de hablantes
        y los valores son sus textos concatenados y limpios.

    Notes
    -----
    - Si no se encuentran hablantes, asigna todo el texto a speaker0
    - Elimina puntuación y caracteres especiales
    - Normaliza espacios múltiples a espacios simples
    """
    # Inicializar un diccionario vacío para almacenar textos por hablante
    speaker_texts = {}

    # Expresión regular para coincidir con patrones de hablante
    pattern = r"(speaker\d+):\s*(.*?)(?=speaker\d+:|$)"

    # Si no se encuentran hablantes, asignar todo el texto a speaker0
    matches = list(re.finditer(pattern, text, re.DOTALL))
    if not matches:
        # Eliminar puntuación y caracteres especiales
        cleaned_text = re.sub(r"[\"'|\-]|\[.*?\](?:_\d+)?(?:[.,;:!?])?", "", text)

        # Eliminar espacios adicionales y normalizar a espacios simples
        cleaned_text = re.sub(r"\s+", " ", cleaned_text.strip())
        speaker_texts["speaker0"] = [
            {
                "text": cleaned_text,
                "start_position": 0,
                "end_position": len(text),
            }
        ]
        return speaker_texts

    # Procesar cada coincidencia si se encontraron hablantes
    for match in matches:
        speaker_key = match.group(1)
        speaker_text = match.group(2)
        start_pos = match.start(2)  # Inicio del texto del hablante
        end_pos = match.end(2)  # Fin del texto del hablante

        # Eliminar puntuación y caracteres especiales
        cleaned_text = re.sub(
            r"[\"'|\-]|\[.*?\](?:_\d+)?(?:[.,;:!?])?", "", speaker_text
        )

        # Eliminar espacios adicionales y normalizar a espacios simples
        cleaned_text = re.sub(r"\s+", " ", cleaned_text.strip())

        # Si el hablante ya existe en el diccionario, agregar el texto
        if speaker_key in speaker_texts:
            speaker_texts[speaker_key].append(
                {
                    "text": cleaned_text,
                    "start_position": start_pos,
                    "end_position": end_pos,
                }
            )
        else:
            speaker_texts[speaker_key] = [
                {
                    "text": cleaned_text,
                    "start_position": start_pos,
                    "end_position": end_pos,
                }
            ]

    return speaker_texts


def _prepare_text(text: str) -> tuple[str, dict[str, str], dict]:
    """
    Prepara el texto para el procesamiento de PII separando letras de números
    y procesando el texto por hablantes.

    Parameters
    ----------
    text : str
        Texto original a procesar.

    Returns
    -------
    tuple[str, dict[str, str], dict]
        Una tupla que contiene:
        - El texto original procesado
        - Diccionario con textos por hablante
        - Diccionario con información de números encontrados

    Notes
    -----
    - Separa letras de números excepto para patrones speaker0 y speaker1
    - Convierte números escritos en palabras a dígitos
    - Divide el texto por hablantes
    """

    # Reemplazar guiones bajos y guiones por espacios
    text = text.replace("_", " ").replace("-", " ")

    # Añadir siempre un espacio después de la puntuación si no está seguida de un espacio
    text = re.sub(r"([.,;!?])([^\s])", r"\1 \2", text)

    # Eliminar caracter ¿ no es necesario
    text = text.replace("¿", "")

    # Separa todas las letras que están unidas a un número (por ejemplo: 123A = 123 A, A123B = A 123 B, a123b = a 123 b)
    text = re.sub(
        r"(\d+)([A-Za-z])",
        lambda m: f"{m.group(1)} {m.group(2)}",
        text,
    )
    text = re.sub(
        r"(?<!speake)([A-Za-z])(\d+)",
        lambda m: f"{m.group(1)} {m.group(2)}",
        text,
    )

    text_digits, number_dict, word_dict = _literal_to_digits(text, "es")
    speaker_texts = _split_by_speaker(text_digits)
    return text, speaker_texts, number_dict, word_dict


def _detect_letter_reference(
    text: str,
    word_dict: dict,
    words: list[str],
    words_index: int,
    backward_search: bool = False,
) -> dict:
    """
    Detecta referencias a letras en el texto, como "P de Pamplona" o "C".

    Parameters
    ----------
    text : str
        Texto completo donde buscar las referencias.

    words : list[str]
        Lista de palabras del texto.

    words_index : int
        Índice de la palabra actual en la lista de palabras.

    search_start : int
        Posición inicial para comenzar la búsqueda.

    backward_search : bool, optional
        Si es True, busca hacia atrás desde la posición inicial.
        Por defecto es False.

    Returns
    -------
    dict
        Diccionario con la información de la referencia encontrada:
        - start: posición inicial
        - end: posición final
        - original_text: texto original de la referencia

    Notes
    -----
    - Busca en una ventana de 6 palabras
    - Maneja diferentes patrones de referencias a letras
    - Ajusta dinámicamente la ventana de búsqueda si es necesario
    """

    # Patrón para coincidir con referencias a letras como "P de Pamplona", "C de", "C"
    letter_pattern = r"(?:\b[A-Za-z][.,;:!?\s]?(?:_\d+)?\s+[dD]e[.,;:!?\s]?(?:_\d+)?\s+\w+(?:[.,;:!?\s](?:_\d+)?|_\d+|(?=[.,;:!?\s]|_\d|$)))|(?:\b[A-Za-z](?:[.,;:!?\s](?:_\d+)?|_\d+|(?=[.,;:!?\s]|_\d|$)))"

    original_position = {}

    if backward_search:
        word_reference = words_index - 8 if words_index - 8 > 0 else 0
        text_to_search = " ".join(words[word_reference:words_index])
        words_to_search = words[word_reference:words_index]
    else:
        word_reference = words_index + 8 if words_index + 8 < len(words) else len(words)
        text_to_search = " ".join(words[words_index + 1 : word_reference])
        words_to_search = words[words_index + 1 : word_reference]

    letter_matches = re.finditer(
        letter_pattern,
        text_to_search,
    )
    match_group = next(letter_matches, None)

    # Guardar la coincidencia exacta de la referencia de letra si se encuentra (siempre buscar referencia de letra con mas de una palabra)
    if match_group:
        if len(match_group.group(0).split()) == 1:
            for match in letter_matches:
                if len(match.group(0).split()) > 1:
                    match_group = match
                    break

                if backward_search and not words_to_search[::-1].index(
                    match.group(0).strip()
                ):
                    match_group = match
                    break

        search_words = match_group.group(0).split()
        first_word = search_words[0]

        if len(search_words) > 1:
            if _clean_word(search_words[-1])[0] == _clean_word(first_word)[0]:
                last_word = search_words[-1]
            else:
                search_words.pop()
                last_word = search_words[1]
        else:
            last_word = first_word

        # Get the exact position in the words list
        if backward_search:
            # Find position of first word when searching backward
            word_reference = word_reference + text_to_search.split().index(first_word)
        else:
            # Find position of last word when searching forward
            word_reference = words_index + 1 + text_to_search.split().index(last_word)

        if first_word == last_word and _clean_word(first_word) in ["a", "o", "y"]:
            search_words.pop()
            if abs(word_reference - words_index) > 1:
                return {}

        word_prefix, word_index = _get_word_value_and_index(first_word)

        reference_start = word_dict[word_prefix][word_index]["start"]

        # Handle last word
        last_word_prefix, last_word_index = _get_word_value_and_index(last_word)

        reference_end = word_dict[last_word_prefix][last_word_index]["end"]

        original_position = {
            "start": reference_start,
            "end": reference_end,
            "word_index": word_reference,
            "words_found": search_words,
            "original_text": text[reference_start:reference_end],
        }

    return original_position


def _clean_word(word: str) -> str:
    """
    Limpia la palabra:
    - Elimina el sufijo _número
    - Elimina la puntuación
    - Elimina espacios al final
    """
    if "_" in word:
        word = word.split("_")[0]
    word = re.sub(r"[.,;:!?\s]+", "", word)
    word = word.lower()

    return word


def _get_word_value_and_index(word: str) -> tuple[str, int]:
    """
    Obtiene el valor de la palabra y el índice de una palabra con un sufijo _número opcional.
    """
    if "_" in word:
        base_word = word.split("_")[0]
        occurrence_index = int(word.split("_")[1]) if len(word.split("_")) > 1 else 0
    else:
        base_word = word
        occurrence_index = 0
    return base_word, occurrence_index


def _check_pii_vicinity(
    text: str,
    window_start: int,
    window_end: int,
    words: list[str],
    word_dict: dict,
    number_dict: dict,
    digits_found: list[str],
    letters_found: list[str],
    pii_type: str,
):

    vicinity_positions = []
    # Verificar referencias de dígitos o letras antes
    digits_matches = []
    for index, word in enumerate(words[window_start:window_end]):
        if _clean_word(word) in letters_found:
            word_prefix, word_index = _get_word_value_and_index(word)
            original_position = word_dict[word_prefix][word_index]
            vicinity_positions.append(
                {
                    "start": original_position["start"],
                    "end": original_position["end"],
                    "word_index": index + window_start,
                    "original_text": text[
                        original_position["start"] : original_position["end"]
                    ],
                    "pii_type": pii_type,
                }
            )
        if re.search(r"\d", _clean_word(word)):
            digits_matches.append((word, index + window_start))

    if digits_matches:
        for digit_word, word_index in digits_matches:
            base_digit_word, occurrence_index = _get_word_value_and_index(digit_word)

            if base_digit_word in digits_found:
                original_position = number_dict[base_digit_word][-occurrence_index - 1]
                vicinity_positions.append(
                    {
                        "start": original_position["start"],
                        "end": original_position["end"],
                        "word_index": word_index,
                        "original_text": text[
                            original_position["start"] : original_position["end"]
                        ],
                        "pii_type": pii_type,
                    }
                )

    return vicinity_positions


def _find_pii(
    original_text: str,
    speaker_texts: dict[str, str],
    number_dict: dict,
    word_dict: dict,
    pii_type: str,
) -> list[dict]:
    """
    Busca información de identificación personal (PII) en el texto.

    Parameters
    ----------
    original_text : str
        Texto original sin procesar.

    speaker_texts : dict[str, str]
        Diccionario con textos separados por hablante.

    number_dict : dict
        Diccionario con información de números encontrados.

    pii_type : str
        Tipo de PII a buscar (EXPEDIENTE, POLIZA, NIE, DNI).

    Returns
    -------
    list[dict]
        Lista de diccionarios con las posiciones y tipos de PII encontrados.

    Notes
    -----
    - Configura diferentes reglas según el tipo de PII
    - Busca patrones específicos de números y letras
    - Maneja casos especiales para cada tipo de PII
    """
    pii_config = {
        "EXPEDIENTE": {
            "number_of_digits": 13,
            "search_letter_before": False,
            "search_letter_after": False,
        },
        "POLIZA": {
            "number_of_digits": 12,
            "search_letter_before": False,
            "search_letter_after": False,
        },
        "PHONE": {
            "number_of_digits": 9,
            "search_letter_before": False,
            "search_letter_after": False,
        },
        "DNI": {
            "number_of_digits": 8,
            "search_letter_before": False,
            "search_letter_after": True,
        },
        "NIE": {
            "number_of_digits": 7,
            "search_letter_before": True,
            "search_letter_after": True,
        },
        "PII": {
            "number_of_digits": 5,
            "search_letter_before": True,
            "search_letter_after": True,
        },
    }

    number_of_digits = pii_config[pii_type]["number_of_digits"]
    search_letter_before = pii_config[pii_type]["search_letter_before"]
    search_letter_after = pii_config[pii_type]["search_letter_after"]
    disable_letter_references = not search_letter_before and not search_letter_after

    modify_positions = []

    for _, speaker_text in speaker_texts.items():
        words = " ".join([text["text"] for text in speaker_text]).split()
        window_size = min(
            number_of_digits if len(speaker_texts) > 1 else number_of_digits + 4,
            len(words),
        )

        if pii_type == "PII":
            window_size += 1

        i = 0
        while i <= len(words) - window_size:
            window_words = words[i : i + window_size]

            # Cuenta dígitos en la ventana, excluyendo aquellos después de un guión bajo, antes de un espacio y aquellos que están seguidos de una palabra común de cantidades
            digits = []
            for j, word in enumerate(window_words):
                # Solo toma dígitos antes del guión bajo
                word_to_check, _ = _get_word_value_and_index(word)

                if i + j + 1 < len(words):
                    next_word = _clean_word(words[i + j + 1])

                    if next_word in COMMON_WORDS:
                        continue

                digits.extend(list(word_to_check) if word_to_check.isdigit() else [])

            if len(digits) >= number_of_digits:
                modify_positions_before = len(modify_positions)
                digit_positions = []
                digits_found = []
                for idx, word in enumerate(window_words):
                    # Solo cuenta números antes del guión bajo, o todos los números si no hay guión bajo
                    word_to_check, _ = _get_word_value_and_index(word)

                    if i + idx + 1 < len(words):
                        next_word = _clean_word(words[i + idx + 1])

                        if next_word in COMMON_WORDS:
                            continue

                    if word_to_check.isdigit():
                        digit_positions.append(i + idx)
                        digits_found.append(word_to_check)

                # Se verifica si son 5 numeros deben tener al menos tres palabras
                if pii_type == "PII":
                    sum_of_distances = sum(
                        digit_positions[i + 1] - digit_positions[i] - 1
                        for i in range(len(digit_positions) - 1)
                    )

                    if (
                        len(digits) == 5
                        and (len(digit_positions) < 2 or sum_of_distances > 1)
                    ) or sum_of_distances > 2:
                        i = digit_positions[-1] + 1
                        continue

                # Procesa cada número en la ventana
                for digit_pos in digit_positions:
                    digit_word = words[digit_pos]

                    # Verifica si la palabra tiene un guión bajo y extrae el índice
                    base_digit_word, occurrence_index = _get_word_value_and_index(
                        digit_word
                    )

                    if base_digit_word not in number_dict:
                        disable_letter_references = True
                        break

                    original_position = number_dict[base_digit_word][
                        -occurrence_index - 1
                    ]

                    modify_positions.append(
                        {
                            "start": original_position["start"],
                            "end": original_position["end"],
                            "word_index": digit_pos,
                            "original_text": original_text[
                                original_position["start"] : original_position["end"]
                            ],
                            "pii_type": pii_type,
                        }
                    )

                letters_found = []
                if not disable_letter_references:
                    if search_letter_before:
                        letter_reference_before = _detect_letter_reference(
                            original_text,
                            word_dict,
                            words,
                            digit_positions[0],
                            backward_search=True,
                        )
                        if letter_reference_before:
                            letter_reference_before["pii_type"] = pii_type
                            letters_found.extend(letter_reference_before["words_found"])
                            # Remove words_found key from letter_reference_before dictionary
                            del letter_reference_before["words_found"]
                            modify_positions.append(letter_reference_before)

                    if search_letter_after:
                        letter_reference_after = _detect_letter_reference(
                            original_text,
                            word_dict,
                            words,
                            digit_positions[-1],
                        )
                        if letter_reference_after:
                            letter_reference_after["pii_type"] = pii_type
                            letters_found.extend(letter_reference_after["words_found"])
                            # Remove words_found key from letter_reference_after dictionary
                            del letter_reference_after["words_found"]
                            modify_positions.append(letter_reference_after)

                    letter_reference_between = _detect_letter_reference(
                        original_text,
                        word_dict,
                        words,
                        digit_positions[0],
                        backward_search=False,
                    )

                    if letter_reference_between:
                        letter_reference_between["pii_type"] = pii_type
                        letters_found.extend(letter_reference_between["words_found"])
                        # Remove words_found key from letter_reference_between dictionary
                        del letter_reference_between["words_found"]
                        modify_positions.append(letter_reference_between)

                # Analizar la vecindad del PII encontrado
                modify_positions_after = len(modify_positions)

                sort_modify_positions = sorted(
                    modify_positions[
                        modify_positions_before - modify_positions_after :
                    ],
                    key=lambda x: x["word_index"],
                )

                cleaned_letters_found = [
                    _clean_word(word)
                    for word in letters_found
                    if _clean_word(word) != "de"
                ]

                window_start = sort_modify_positions[0]["word_index"] - 1
                window_end = sort_modify_positions[-1]["word_index"] + 1

                before_window = max(0, window_start - window_size)
                after_window = min(len(words), window_end + window_size)

                modify_positions.extend(
                    _check_pii_vicinity(
                        original_text,
                        before_window,
                        window_start,
                        words,
                        word_dict,
                        number_dict,
                        digits_found,
                        cleaned_letters_found,
                        pii_type,
                    )
                )

                modify_positions.extend(
                    _check_pii_vicinity(
                        original_text,
                        window_end,
                        after_window,
                        words,
                        word_dict,
                        number_dict,
                        digits_found,
                        cleaned_letters_found,
                        pii_type,
                    )
                )

                i = digit_positions[-1] + 1
            else:
                i += 1

    return modify_positions


def _tag_text_with_positions(
    text: str, positions: list[dict], keep_tags: bool = False
) -> str:
    """
    Etiqueta el texto con marcadores PII en las posiciones especificadas.

    Parameters
    ----------
    text : str
        Texto original a etiquetar.

    positions : list[dict]
        Lista de diccionarios con las posiciones y tipos de PII.

    keep_tags : bool, optional (default=False)
        Si es True, mantiene las etiquetas especificas.

    Returns
    -------
    str
        Texto con las etiquetas PII insertadas.

    Notes
    -----
    - Inserta etiquetas en el formato [TIPO_A] si keep_tags es False o [PII_A] si keep_tags es True
    - Evita duplicar etiquetas existentes
    - Mantiene el orden original del texto
    """
    tagged_text = text
    for pos in positions:
        start_pos = pos["start"]
        end_pos = pos["end"]

        if keep_tags:
            pii_type = pos["pii_type"]
        else:
            pii_type = "PII"

        # Verificar SIEMPRE si el texto a reemplazar tiene el patrón de speaker
        speaker_pattern = r"^(.+?)(\s+\|\s+speaker\d+:.+)(\|\s+speaker\d+:\s+)(.+)$"
        match = re.match(speaker_pattern, pos["original_text"])

        if not match:
            # Lógica para textos sin patrón de speaker
            if tagged_text[end_pos : end_pos + len(pii_type) + 5] == f" [{pii_type}_A]":
                # La siguiente posición ya está taggeada, unir las etiquetas
                tagged_text = tagged_text[: start_pos - 1] + "" + tagged_text[end_pos:]
            else:
                replace_text = f"[{pii_type}_A]"
                tagged_text = (
                    tagged_text[:start_pos] + replace_text + tagged_text[end_pos:]
                )
        else:
            # Lógica para textos con patrón de speaker
            _ = match.group(1)  # texto inicial hasta " |"
            middle1 = match.group(2)  # " | speaker1: texto"
            middle2 = match.group(3)  # "| speaker0: "
            _ = match.group(4)  # texto final

            if tagged_text[end_pos : end_pos + len(pii_type) + 5] == f" [{pii_type}_A]":
                # La siguiente posición ya está taggeada, mantener el patrón de speaker pero sin la etiqueta final
                replace_text = f"[{pii_type}_A]{middle1}{middle2}"
                tagged_text = (
                    tagged_text[:start_pos] + replace_text + tagged_text[end_pos:]
                )
            else:
                # Aplicamos etiquetas PII al principio y final, manteniendo el patrón de speaker
                replace_text = f"[{pii_type}_A]{middle1}{middle2}[{pii_type}_A]"
                tagged_text = (
                    tagged_text[:start_pos] + replace_text + tagged_text[end_pos:]
                )

    return tagged_text


def detect_and_tag_pii(
    original_text: str, keep_tags: bool = False, identifier: str = None
) -> tuple[str, list[dict]]:
    """
    Detecta y etiqueta información de identificación personal (PII) en el texto.

    Parameters
    ----------
    original_text : str
        Texto original donde se buscará y etiquetará PII.

    keep_tags : bool, optional (default=False)
        Si es True, mantiene las etiquetas especificas.

    identifier : str, optional (default=None)
        Identificador del texto a anonimizar. Para trazabilidad de errores en logs.

    Returns
    -------
    tuple[str, list[dict]]
        Una tupla que contiene:
        - El texto procesado con etiquetas PII
        - Lista de diccionarios con las posiciones y tipos de PII encontrados

    Examples
    --------
    >>> text = "El DNI doce, treinta y cuatro, cincuenta y seis, setenta y ocho, A y el NIE X uno, dos, tres, cuatro, cinco, seis, siete, B"
    >>> processed_text, positions = detect_and_tag_pii(text, True, "id_1")
    >>> print(processed_text)
    "El DNI [DNI_A] y el NIE [NIE_A]"

    Notes
    -----
    - Procesa diferentes tipos de PII en orden de prioridad
    - Elimina posiciones superpuestas manteniendo la prioridad más alta
    - Maneja casos especiales para cada tipo de PII
    """
    pii_order = ["EXPEDIENTE", "POLIZA", "PHONE", "DNI", "NIE", "PII"]
    pii_priority = {pii_type: idx for idx, pii_type in enumerate(pii_order)}

    try:
        procesed_text, speaker_texts, number_dict, word_dict = _prepare_text(
            original_text
        )
        modify_positions = []

        for pii_type in pii_order:
            modify_positions.extend(
                _find_pii(
                    procesed_text,
                    speaker_texts,
                    number_dict,
                    word_dict,
                    pii_type,
                )
            )

        # Ordenar de mayor a menor por posición inicial y prioridad de PII
        modify_positions.sort(key=lambda x: (-x["start"], pii_priority[x["pii_type"]]))

        # Eliminar posiciones superpuestas, manteniendo las de mayor prioridad
        filtered_positions = []
        for pos in modify_positions:
            overlapping = False
            for existing_pos in filtered_positions:
                if (
                    pos["start"] <= existing_pos["end"]
                    and pos["end"] >= existing_pos["start"]
                ):
                    overlapping = True
                    break
            if not overlapping:
                filtered_positions.append(pos)

        # Aplicar todas las modificaciones restantes de una vez usando tag_text_with_positions
        final_text = _tag_text_with_positions(
            procesed_text, filtered_positions, keep_tags
        )
    except:
        from ._shared import _logger

        if identifier is not None:
            _logger.error(f"Error al anonimizar el identificador: {identifier}")
        else:
            _logger.error(f"Error al anonimizar el texto:")

        final_text = original_text
        filtered_positions = []

    return final_text, filtered_positions
