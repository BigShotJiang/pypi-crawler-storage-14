"""
Módulo de Gestión de Logs para Analytics Toolkit

Este módulo proporciona una solución flexible y configurable para el registro
de logs en aplicaciones de análisis de datos, con soporte para múltiples
niveles de verbosidad y configuraciones personalizadas.

Características principales:
- Configuración dinámica de niveles de logging
- Registro simultáneo en archivo y consola
- Control granular de logs para bibliotecas externas
- Soporte para modo de depuración
- Formato de logs personalizado

Clase principal:
- Logger: Gestiona la configuración y creación de objetos de logging

Ejemplo de uso básico:
```python
from analytics_toolkit.logger import Logger

# Crear un logger en modo normal
logger = Logger()
log = logger.get_logger()
log.info('Mensaje informativo')

# Crear un logger en modo debug
debug_logger = Logger(library_name='mi_modulo', debug=True)
debug_log = debug_logger.get_logger()
debug_log.debug('Mensaje de depuración detallado')
```

Modos de configuración:
- Modo normal: Logs de nivel INFO
- Modo debug: Logs de nivel DEBUG con más detalles

Configuraciones avanzadas:
- Nombre personalizado del logger
- Control de niveles de log para bibliotecas externas
- Generación automática de directorios de logs

Dependencias:
- logging: Módulo estándar de Python para logging
- os: Manejo de directorios y rutas de archivos

Características de logging:
- Formato de logs:
  * Timestamp
  * Nombre del logger
  * Nivel de log
  * Mensaje
- Salida simultánea a archivo y consola
- Prevención de múltiples inicializaciones

Manejo de bibliotecas externas:
- Reducción de logs de bibliotecas ruidosas
- Configuración automática de niveles de log
- Bibliotecas monitoreadas:
  * boto3
  * botocore
  * s3transfer
  * openai
  * y más...

Consideraciones:
- El primer Logger inicializado configura el sistema de logging
- Los loggers subsiguientes heredan la configuración inicial
- Los archivos de log se generan en un directorio 'logs'

Patrones de uso:
- Registro de eventos en aplicaciones de análisis
- Depuración de código
- Seguimiento de procesos complejos
- Monitoreo de rendimiento
"""

import logging
import os


__all__ = ["Logger"]


class Logger:
    """
    Una clase para configurar y gestionar el registro de logs de manera personalizada.

    Esta clase proporciona una configuración flexible de logging con soporte para
    diferentes niveles de verbosidad, salida a consola y archivo, y control de
    logging para bibliotecas externas.

    Attributes
    ----------
    _initialized : bool
        Bandera de clase para prevenir múltiples inicializaciones del sistema de logging.

    logfile : str, optional
        Ruta completa al archivo de logs.

    Methods
    -------
    __init__(library_name=None, debug=False)
        Inicializa el sistema de logging con configuraciones personalizadas.

    get_logger()
        Devuelve el logger configurado.

    Notes
    -----
    - Configura logging tanto para archivo como para consola
    - Permite control granular de niveles de log
    - Gestiona logs de bibliotecas externas
    - Previene la inicialización múltiple del sistema de logging
    """

    _initialized = False

    def __init__(self, library_name: str = None, debug: bool = False):
        """
        Inicializa el sistema de logging con configuraciones personalizadas.

        Parameters
        ----------
        library_name : str, optional
            Nombre de la biblioteca o módulo para el logger.
            Si no se proporciona, se usa el logger raíz.
            Por defecto es None.

        debug : bool, optional
            Bandera para habilitar modo de depuración.
            - Si es True:
                * Nivel de log se establece en DEBUG
                * Logs de bibliotecas externas se establecen en INFO
                * Logs de analytics_toolkit en DEBUG
            - Si es False:
                * Nivel de log se establece en INFO
                * Logs de bibliotecas externas se establecen en CRITICAL
                * Logs de analytics_toolkit en INFO
            Por defecto es False.

        Raises
        ------
        OSError
            Si no se puede crear el directorio de logs.

        Examples
        --------
        Crear un logger para un módulo específico en modo debug:
        >>> logger = Logger(library_name='mi_modulo', debug=True)
        >>> log = logger.get_logger()
        >>> log.debug('Mensaje de depuración')

        Crear un logger predeterminado:
        >>> logger = Logger()
        >>> log = logger.get_logger()
        >>> log.info('Mensaje informativo')

        Notes
        -----
        - Configura logging para archivo y consola
        - Establece formato de logs con timestamp, nombre, nivel y mensaje
        - Gestiona niveles de log para bibliotecas externas
        """
        # Establecer nivel de log basado en la bandera de debug
        log_level = logging.DEBUG if debug else logging.INFO

        # Prevenir múltiples inicializaciones de logging
        if not Logger._initialized:
            cwd = os.getcwd()
            self.logfile = f"{cwd}/logs/log.log"

            try:
                # Crear directorio de logs si no existe
                if not os.path.exists(os.path.dirname(self.logfile)):
                    os.makedirs(os.path.dirname(self.logfile))
            except OSError as e:
                raise OSError(f"No se pudo crear el directorio de logs: {e}")

            # Limpiar manejadores existentes para prevenir duplicados
            for handler in logging.root.handlers[:]:
                logging.root.removeHandler(handler)

            # Configuración básica de logging
            logging.basicConfig(
                level=log_level,
                filename=self.logfile,
                filemode="a+",
                format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                encoding="utf-8",
            )

            # Configurar manejador de consola
            console = logging.StreamHandler()
            console.setLevel(log_level)
            formatter = logging.Formatter("%(name)-12s: %(levelname)-8s %(message)s")

            console.setFormatter(formatter)

            # Añadir manejador de consola
            logging.getLogger("").addHandler(console)

            Logger._initialized = True
        else:
            # Actualizar manejador de consola existente
            root_logger = logging.getLogger("")
            for handler in root_logger.handlers:
                if isinstance(handler, logging.StreamHandler):
                    handler.setLevel(log_level)

        # Lista de bibliotecas externas para configuración de log
        external_libraries = [
            "boto3",
            "botocore",
            "s3transfer",
            "s3fs",
            "aiobotocore",
            "urllib3",
            "fsspec",
            "asyncio",
            "openai",
            "httpx",
            "httpcore",
        ]

        # Configurar niveles de log para bibliotecas externas
        if debug:
            for lib in external_libraries:
                logging.getLogger(lib).setLevel(logging.INFO)
            logging.getLogger("analytics_toolkit").setLevel(logging.DEBUG)
        else:
            for lib in external_libraries:
                logging.getLogger(lib).setLevel(logging.CRITICAL)
            logging.getLogger("analytics_toolkit").setLevel(logging.INFO)

        # Crear logger con nombre especificado o por defecto
        self._logger = (
            logging.getLogger(library_name) if library_name else logging.getLogger()
        )

        # Establecer nivel de logger
        self._logger.setLevel(log_level)

    def get_logger(self) -> logging.Logger:
        """
        Obtiene el logger configurado.

        Returns
        -------
        logging.Logger
            El objeto logger configurado con los parámetros especificados.

        Examples
        --------
        >>> logger = Logger(debug=True)
        >>> log = logger.get_logger()
        >>> log.debug('Mensaje de depuración')
        >>> log.info('Mensaje informativo')
        """
        return self._logger
