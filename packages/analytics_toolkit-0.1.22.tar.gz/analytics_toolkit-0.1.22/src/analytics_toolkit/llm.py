"""
Módulo de Análisis de Lenguaje Natural con Modelos de Lenguaje de Gran Escala (LLM)

Este módulo proporciona herramientas avanzadas para realizar análisis de texto
utilizando modelos de lenguaje de inteligencia artificial, con soporte para
múltiples servicios, configuraciones de prompts y almacenamiento de resultados.

Características principales:
- Análisis de texto con modelos de lenguaje (GPT-4, etc.)
- Soporte para múltiples servicios (NFQ, AEGON)
- Configuración flexible de prompts
- Análisis síncrono y asíncrono
- Almacenamiento de resultados y trazabilidad en S3
- Gestión de tokens y cálculo de costos

Componentes principales:
- PromptsConfig: Configuración de contexto y prompts
- llm_call: Función síncrona para análisis de texto
- llm_call_async: Función asíncrona para análisis de texto

Ejemplo de uso básico:
```python
from analytics_toolkit.llm import PromptsConfig, llm_call
import pandas as pd

# Crear un DataFrame de ejemplo
df = pd.DataFrame({
    'id': ['doc1', 'doc2'],
    'texto': [
        'El cambio climático afecta gravemente al planeta.',
        'La innovación tecnológica impulsa el desarrollo económico.'
    ]
})

# Configurar el contexto y prompt
config = PromptsConfig(
    context="Eres un analista experto en resumir información",
    prompt="Genera un resumen conciso del siguiente texto"
)

# Realizar el análisis con el servicio NFQ
resultados = llm_call(
    analysis_info=df,
    id_field='id',
    analysis_field='texto',
    prompts_config=config,
    process='resumen',
    service='nfq'
)
```

Modos de análisis:
- Síncrono: llm_call()
- Asíncrono: llm_call_async()

Servicios soportados:
- NFQ (Azure OpenAI)
- AEGON (Azure OpenAI)

Configuraciones avanzadas:
- Múltiples prompts
- Almacenamiento en S3
- Trazabilidad de llamadas
- Control de concurrencia
- Logging configurable

Dependencias:
- pandas: Manipulación de datos
- asyncio: Programación asíncrona
- openai: Interacción con modelos de lenguaje
- S3Storage: Almacenamiento de resultados

Patrones de uso:
- Resumen de documentos
- Extracción de información
- Análisis de sentimientos
- Clasificación de texto
- Generación de metadatos

Consideraciones:
- Manejo de tokens y costos
- Configuración de contexto y prompts
- Gestión de errores y reintentos
- Almacenamiento opcional de resultados
"""

import pandas as pd
import asyncio
import aiohttp
import json
import ast
import typing

from numpy import nan
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
from openai import AsyncAzureOpenAI

from ._shared import _logger, _config, _rs_connection
from .storage import S3Storage


__all__ = ["PromptsConfig", "llm_call"]


# Lock para modificar de forma asíncrona los dataframes trazabilidad de llamadas a LLM
_trace_lock = asyncio.Lock()

# Lock para modificar de forma asíncrona los dataframes de salida en el paso de análisis
_save_output_lock = asyncio.Lock()

_azure_client = AsyncAzureOpenAI(
    azure_endpoint=_config["gpt_url_aegon_group"],
    api_key=_config["tokenaegongroup"],
    api_version=_config["api_version_aegon_group"],
    default_headers={
        "x-region": "eus",
        "x-unit": "gts",
        "x-department": "*",
        "x-function": "*",
        "x-service": "*",
        "x-seckey": _config["tokenaegongroup"],
    },
)


class PromptsConfig:
    """
    Clase para manejar la configuración de prompts y sus keys asociadas.

    Esta clase permite configurar y gestionar prompts para llamadas a modelos de lenguaje.

    Attributes
    ----------
    context : str
        El contexto para enviar las consultas al LLM.

    prompt : str or list
        Prompt o lista de prompts. Si se pasa como lista, el modelo intentará
        validar los outputs con las keys_list asociadas.

    keys_list : list, optional
        Lista de keys asociadas a los prompts. Si no se proporciona,
        se usarán índices numéricos como keys.
    """

    def __init__(
        self,
        context: str,
        prompt: typing.Union[str, list],
        keys_list: typing.Optional[list] = None,
    ):
        """
        Inicializa la configuración de prompts.

        Parameters
        ----------
        context : str
            El contexto para enviar las consultas al LLM.
            Proporciona el marco de referencia para la generación de respuestas.

        prompt : str or list
            Prompt o lista de prompts. Si se pasa como lista, el modelo intentará
            validar los outputs con las keys_list asociadas.

        keys_list : list, optional
            Lista de keys asociadas a los prompts. Si no se proporciona,
            se usarán índices numéricos como keys.
            Debe tener la misma longitud que la lista de prompts.

        Raises
        ------
        ValueError
            Si la cantidad de prompts y keys no coincide cuando se proporciona una lista.

        Examples
        --------
        Crear un PromptsConfig con un único prompt:
        >>> config = PromptsConfig(
        ...     context="Eres un asistente de análisis de datos",
        ...     prompt="Resume la información siguiente:"
        ... )

        Crear un PromptsConfig con múltiples prompts:
        >>> config = PromptsConfig(
        ...     context="Eres un asistente de análisis de datos",
        ...     prompt=["Prompt 1", "Prompt 2"],
        ...     keys_list=["prompt_1", "prompt_2"]
        ... )

        Notes
        -----
        - Si se proporciona una lista de prompts, se generará un contexto de plantilla
        - Las keys pueden ser personalizadas o generadas automáticamente
        """
        self.context = context
        self.prompt = prompt
        self.keys_list = keys_list
        self.context_template = ""

        if isinstance(prompt, list):
            if keys_list and len(prompt) != len(keys_list):
                raise ValueError("La cantidad de prompts y keys debe ser igual")

            if not self.keys_list:
                self.keys_list = [str(i) for i in range(len(prompt))]

            self.context_template = 'The result is a dictionary with key-value pairs, where the key is the question number and the value is the corresponding answers. Sample Input: {"4":"question","10":"question","13":"question",...}, Resulting dictionary: {"4":"answer","10":"answer","13":"answer",...}. Limit yourself to responding only the dictionary just as the example that i gave you earlier, DONT USE ANY FORMAT OR NEWLINES.'

    @classmethod
    def from_redshift(
        cls,
        index_context: str,
        index_prompts: str,
    ) -> "PromptsConfig":
        """
        Crea una instancia de PromptsConfig desde tablas de Redshift.

        Parameters
        ----------
        index_context : str
            Índice del contexto a utilizar en la tabla de contextos. Un string que represente un entero.

        index_prompts : str
            Índice o lista de índices de los prompts a utilizar en la tabla de prompts.
            Puede ser:
            - Un string que represente un entero
            - Un string con formato "(int,int,...)" si se desea lanzar mas de un prompt con el mismo contexto

        Returns
        -------
        PromptsConfig
            Nueva instancia configurada con datos de Redshift.

        Examples
        --------
        >>> config = PromptsConfig.from_redshift("1", "1")  # Un solo prompt
        >>> config = PromptsConfig.from_redshift("1", "(1)")  # Un solo prompt con formato de lista
        >>> config = PromptsConfig.from_redshift("1", "(1,2,3)")  # Mas de un prompt

        Notes
        -----
        - Recupera el contexto y los prompts desde tablas predefinidas en Redshift
        - Utiliza las configuraciones de _config para acceder a las tablas
        """
        table_context = _config["table_context"]
        table_prompts = _config["table_prompt"]

        context = _rs_connection.query(
            f"select context from {table_context} where context_id = {index_context}",
        ).context[0]

        if str(ast.literal_eval(index_prompts)) == index_prompts:
            index_prompts = int(index_prompts)

        if isinstance(index_prompts, int):
            prompt = _rs_connection.query(
                f"select prompt from {table_prompts} where prompt_id = {index_prompts}",
            ).prompt[0]

            keys_list = None
        else:
            prompts_df = _rs_connection.query(
                f"select prompt_id, prompt from {table_prompts} where prompt_id in {index_prompts}",
            )
            prompt = prompts_df.prompt.tolist()

            keys_list = prompts_df.prompt_id.astype(str).tolist()

        return cls(
            context=context,
            prompt=prompt,
            keys_list=keys_list,
        )

    def get_formatted_prompts(self) -> typing.Union[str, dict]:
        """
        Obtiene los prompts formateados según el formato requerido.

        Returns
        -------
        Union[str, dict]
            Prompts formateados según el formato requerido.
            Dependiendo del campo de prompt.

        Examples
        --------
        Ejemplo con un único prompt (string):
        >>> config = PromptsConfig(context="Eres un asistente de análisis", prompt="Resume el siguiente texto")
        >>> formatted = config.get_formatted_prompts()
        >>> print(formatted)
        'Resume el siguiente texto'

        Ejemplo con múltiples prompts (lista):
        >>> config = PromptsConfig(
        ...     context="Eres un asistente de análisis",
        ...     prompt=["Identifica el tema principal", "Extrae las palabras clave"],
        ...     keys_list=["tema", "palabras_clave"]
        ... )
        >>> formatted = config.get_formatted_prompts()
        >>> print(formatted)
        {
            'str': '{"tema": "Identifica el tema principal", "palabras_clave": "Extrae las palabras clave"}',
            'keys': ['tema', 'palabras_clave']
        }

        Notes
        -----
        - Para un único prompt, devuelve el prompt como string
        - Para múltiples prompts, devuelve un diccionario con:
            * 'str': Un string JSON con los prompts
            * 'keys': La lista de keys asociadas a los prompts
        """
        if isinstance(self.prompt, list):
            prompts_dict = dict(zip(self.keys_list, self.prompt))
            prompts_str = (
                "{" + ", ".join(f'"{k}": "{v}"' for k, v in prompts_dict.items()) + "}"
            )

            return {"str": prompts_str, "keys": self.keys_list}
        else:
            return self.prompt

    def get_context(self) -> str:
        """
        Obtiene el contexto completo incluyendo el template.

        Returns
        -------
        str
            Contexto completo con el template opcional.

        Examples
        --------
        Ejemplo con un único prompt:
        >>> config = PromptsConfig(
        ...     context="Eres un asistente de análisis de datos",
        ...     prompt="Resume la información siguiente"
        ... )
        >>> full_context = config.get_context()
        >>> print(full_context)
        "Eres un asistente de análisis de datos"

        Ejemplo con múltiples prompts:
        >>> config = PromptsConfig(
        ...     context="Eres un asistente de análisis de datos",
        ...     prompt=["Identifica el tema principal", "Extrae las palabras clave"],
        ...     keys_list=["tema", "palabras_clave"]
        ... )
        >>> full_context = config.get_context()
        >>> print(full_context)
        "Eres un asistente de análisis de datos
        The result is a dictionary with key-value pairs, where the key is the question number and the value is the corresponding answers. Sample Input: {"4":"question","10":"question","13":"question",...}, Resulting dictionary: {"4":"answer","10":"answer","13":"answer",...}. Limit yourself to responding only the dictionary just as the example that i gave you earlier, DONT USE ANY FORMAT OR NEWLINES."

        Notes
        -----
        - Para un único prompt, devuelve solo el contexto
        - Para múltiples prompts, añade un template de formato de diccionario
        - El template ayuda a estructurar la respuesta del modelo de lenguaje
        """
        return f"{self.context} \n{self.context_template}"


async def _get_aegon_gpt_response(
    messages: List[Dict[str, str]],
    model: str,
    input_token_price: float,
    output_token_price: float,
    retry_count: int,
    params: Dict[str, Any] = {},
) -> Optional[Dict[str, Any]]:
    """
    Función que obtiene la respuesta de la API de AEGON AZURE OPENAI.

    Parameters
    ----------
    messages : List[Dict[str, str]]
        Los mensajes a enviar a la API con el formato de Openai GPT.
        Contiene el contexto, el texto de entrada y el prompt.

    model : str
        El modelo de lenguaje a utilizar.
        Identifica la versión específica del modelo LLM.

    input_token_price : float
        El precio por token de entrada.
        Utilizado para calcular el costo de la llamada.

    output_token_price : float
        El precio por token de salida.
        Utilizado para calcular el costo de la llamada.

    retry_count : int
        El número de reintentos a realizar en caso de error.
        Permite manejar fallos temporales en la API.

    params : Dict[str, Any], optional
        Parámetros adicionales para la llamada a la API.
        Por defecto es un diccionario vacío.

    Returns
    -------
    Optional[Dict[str, Any]]
        La respuesta de la API en el formato de Openai GPT.
        Contiene información sobre la generación de texto, uso de tokens y precio.
        Devuelve None si no se puede obtener una respuesta después de los reintentos.

    Examples
    --------
    >>> messages = [
    ...     {"role": "system", "content": "Eres un asistente"},
    ...     {"role": "user", "content": "Hola"}
    ... ]
    >>> response = await _get_aegon_gpt_response(
    ...     messages, "gpt-4", 0.01, 0.02, 3
    ... )
    >>> print(response)
    {
        'model': 'gpt-4',
        'choices': [
            {
                'index': 0,
                'message': {
                    'role': 'assistant',
                    'content': 'Hola, ¿en qué puedo ayudarte hoy?'
                },
                'finish_reason': 'stop'
            }
        ],
        'usage': {
            'promptTokens': 20,
            'completionTokens': 15,
            'totalTokens': 35,
            'totalPrice': 0.0005  # Calculado basado en input_token_price y output_token_price y cantidad de reintentos
        }
    }

    Notes
    -----
    - Realiza llamadas asíncronas al servicio Azure OpenAI
    - Maneja errores y reintentos de forma automática
    - Calcula el precio total de la llamada basado en el uso de tokens
    """

    for i in range(retry_count):
        try:
            result = await _azure_client.chat.completions.create(
                model=model.lower(),
                messages=messages,
            )

            response_json = {
                "model": model,
                "choices": [
                    {
                        "index": choice.index,
                        "message": {
                            "role": choice.message.role,
                            "content": choice.message.content,
                        },
                        "finish_reason": choice.finish_reason,
                    }
                    for choice in result.choices
                ],
                "usage": {
                    "promptTokens": result.usage.prompt_tokens,
                    "completionTokens": result.usage.completion_tokens,
                    "totalTokens": result.usage.total_tokens,
                    "totalPrice": (
                        result.usage.prompt_tokens * input_token_price
                        + result.usage.completion_tokens * output_token_price
                    ),
                },
            }

            return response_json

        except:
            if i == retry_count - 1:
                return None

            await asyncio.sleep(10)


async def _get_gpt_response(
    messages: List[Dict[str, str]],
    model: str,
    input_token_price: float,
    output_token_price: float,
    retry_count: int,
    params: Dict[str, Any] = {},
) -> Optional[Dict[str, Any]]:
    """
    Función que obtiene la respuesta de la API de NFQ GPT.

    Parameters
    ----------
    messages : List[Dict[str, str]]
        Los mensajes a enviar a la API con el formato de Openai GPT.
        Contiene el contexto, el texto de entrada y el prompt.

    model : str
        El modelo de lenguaje a utilizar.
        Identifica la versión específica del modelo LLM.

    input_token_price : float
        El precio por token de entrada.
        Utilizado para calcular el costo de la llamada.

    output_token_price : float
        El precio por token de salida.
        Utilizado para calcular el costo de la llamada.

    retry_count : int
        El número de reintentos a realizar en caso de error.
        Permite manejar fallos temporales en la API.

    params : Dict[str, Any], optional
        Parámetros adicionales para la llamada a la API.
        Por defecto es un diccionario vacío.

    Returns
    -------
    Optional[Dict[str, Any]]
        La respuesta de la API en el formato de Openai GPT.
        Contiene información sobre la generación de texto, uso de tokens y precio.
        Devuelve None si no se puede obtener una respuesta después de los reintentos.

    Notes
    -----
    - Realiza llamadas asíncronas al servicio NFQ GPT
    - Maneja errores y reintentos de forma automática
    - Calcula el precio total de la llamada basado en el uso de tokens

    Examples
    --------
    >>> messages = [
    ...     {"role": "system", "content": "Eres un asistente"},
    ...     {"role": "user", "content": "Hola"}
    ... ]
    >>> response = await _get_gpt_response(
    ...     messages, "gpt-4", 0.01, 0.02, 3
    ... )
    >>> print(response)
    {
        'model': 'gpt-4',
        'choices': [
            {
                'index': 0,
                'message': {
                    'role': 'assistant',
                    'content': 'Hola, ¿en qué puedo ayudarte hoy?'
                },
                'finish_reason': 'stop'
            }
        ],
        'usage': {
            'promptTokens': 20,
            'completionTokens': 15,
            'totalTokens': 35,
            'totalPrice': 0.0005  # Calculado basado en input_token_price y output_token_price y cantidad de reintentos
        }
    }
    """

    headers = {
        "X-IBM-Client-Id": _config["tokenaegon"],
    }

    payload = {"messages": messages, **params}

    url = _config["gpt_url_aegon"]

    for i in range(retry_count):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, headers=headers) as response:
                    response.raise_for_status()
                    result = await response.json()
                    result["data"]["usage"]["totalPrice"] = (
                        result["data"]["usage"]["promptTokens"] * input_token_price
                        + result["data"]["usage"]["completionTokens"]
                        * output_token_price
                    )
                    result["data"]["model"] = model
                    return result["data"]

        except:
            if i == retry_count - 1:
                return None

            await asyncio.sleep(10)


async def _format_llm_call(
    txt, prompt, model, input_token_price, output_token_price, context="", service="nfq"
):
    """
    Función para formatear la llamada al LLM.

    Parameters
    ----------
    txt : str
        El texto a analizar.
        Contenido principal que se enviará al modelo de lenguaje.

    prompt : str
        El prompt a usar.
        Instrucciones específicas para guiar la generación de texto.

    model : str
        El modelo a usar.
        Identifica la versión específica del modelo LLM.

    input_token_price : float
        El precio por token de entrada.
        Utilizado para calcular el costo de la llamada.

    output_token_price : float
        El precio por token de salida.
        Utilizado para calcular el costo de la llamada.

    context : str, optional
        El contexto a usar.
        Proporciona información adicional para guiar la generación.
        Por defecto es una cadena vacía.

    service : str, optional
        El servicio a usar para la llamada de LLM.
        Opciones: "nfq", "aegon".
        Por defecto: "nfq".

    Returns
    -------
    dict
        La respuesta del LLM.
        Contiene la generación de texto y metadatos de la llamada.

    Notes
    -----
    - Prepara los mensajes para la llamada al modelo de lenguaje
    - Selecciona el servicio de LLM basado en el parámetro
    - Maneja diferentes proveedores de servicios LLM

    Examples
    --------
    >>> response = await _format_llm_call(
    ...     "Texto de análisis",
    ...     "Resume el texto",
    ...     "gpt-4",
    ...     0.01,
    ...     0.02,
    ...     context="Eres un asistente"
    ... )
    >>> print(response)
    {
        'model': 'gpt-4',
        'choices': [
            {
                'index': 0,
                'message': {
                    'role': 'assistant',
                    'content': 'Hola, ¿en qué puedo ayudarte hoy?'
                },
                'finish_reason': 'stop'
            }
        ],
        'usage': {
            'promptTokens': 20,
            'completionTokens': 15,
            'totalTokens': 35,
            'totalPrice': 0.0005  # Calculado basado en input_token_price y output_token_price y cantidad de reintentos
        }
    }
    """

    messages = [
        {"role": "system", "content": context},
        {"role": "user", "content": txt},
        {"role": "user", "content": prompt},
    ]

    if service == "nfq":
        return await _get_gpt_response(
            messages, model, input_token_price, output_token_price, 10
        )
    elif service == "aegon":
        return await _get_aegon_gpt_response(
            messages, model, input_token_price, output_token_price, 10
        )


async def _save_output_llm_calls(
    results: list, id_column_name: str, s3_storage: S3Storage
) -> None:
    """
    Función para guardar la respuesta de las llamadas a LLM en S3.

    Parameters
    ----------
    results : list
        La lista de resultados de las llamadas a LLM.
        Cada elemento es un diccionario con los resultados de una llamada.

    id_column_name : str
        Nombre de la columna del identificador.
        Ejemplo: nombreFichero, idSiniestro, etc.

    s3_storage : S3Storage
        Objeto para almacenar resultados en S3.
        Proporciona métodos para interactuar con el almacenamiento S3.

    Returns
    -------
    None
        No devuelve un valor. Guarda los resultados en S3.

    Notes
    -----
    - Procesa los resultados de las llamadas a LLM
    - Agrega columnas comunes a todos los resultados
    - Concatena y guarda los resultados en S3
    - Utiliza un lock para evitar problemas de concurrencia

    Examples
    --------
    Ejemplo de los resultados de LLM que se guardarán en S3:
    >>> # Supongamos que tenemos resultados de análisis de documentos
    >>> results = [
    ...     {
    ...         'response': pd.DataFrame([
    ...             ['tema_principal', 'Transformación digital'],
    ...             ['palabras_clave', 'innovación, tecnología, cambio']
    ...         ], columns=['analisis_articulo_prompt_id', 'analisis_articulo_rsp']),
    ...         'id': 'articulo1',
    ...         'fec_proceso': '2024-01-15 10:30:45',
    ...         'tema_principal': 'Transformación digital',
    ...         'palabras_clave': 'innovación, tecnología, cambio'
    ...     },
    ...     {
    ...         'response': pd.DataFrame([
    ...             ['tema_principal', 'Impacto del cambio climático'],
    ...             ['palabras_clave', 'medio ambiente, sostenibilidad, acción global']
    ...         ], columns=['analisis_articulo_prompt_id', 'analisis_articulo_rsp']),
    ...         'id': 'articulo2',
    ...         'fec_proceso': '2024-01-15 10:31:20',
    ...         'tema_principal': 'Impacto del cambio climático',
    ...         'palabras_clave': 'medio ambiente, sostenibilidad, acción global'
    ...     }
    ... ]
    >>>
    >>> # El DataFrame final guardado en S3 se verá así:
    >>> # df_s3 = pd.DataFrame([
    >>> #     {
    >>> #         'analisis_articulo_prompt_id': 'tema_principal',
    >>> #         'analisis_articulo_rsp': 'Transformación digital',
    >>> #         'fec_proceso': '2024-01-15 10:30:45',
    >>> #         'id': 'articulo1'
    >>> #     },
    >>> #     {
    >>> #         'analisis_articulo_prompt_id': 'palabras_clave',
    >>> #         'analisis_articulo_rsp': 'innovación, tecnología, cambio',
    >>> #         'fec_proceso': '2024-01-15 10:30:45',
    >>> #         'id': 'articulo1'
    >>> #     },
    >>> #     {
    >>> #         'analisis_articulo_prompt_id': 'tema_principal',
    >>> #         'analisis_articulo_rsp': 'Impacto del cambio climático',
    >>> #         'fec_proceso': '2024-01-15 10:31:20',
    >>> #         'id': 'articulo2'
    >>> #     },
    >>> #     {
    >>> #         'analisis_articulo_prompt_id': 'palabras_clave',
    >>> #         'analisis_articulo_rsp': 'medio ambiente, sostenibilidad, acción global',
    >>> #         'fec_proceso': '2024-01-15 10:31:20',
    >>> #         'id': 'articulo2'
    >>> #     }
    >>> # ])
    >>>
    >>> # Guardar los resultados en S3
    >>> await _save_output_llm_calls(
    ...     results=results,
    ...     id_column_name="id",
    ...     s3_storage=s3_storage_instance
    ... )
    """
    response_dicts = []
    for result in results:
        if result is not None:
            if isinstance(result["response"], pd.DataFrame):
                # For multiple prompts case
                response_df = result["response"]
            else:
                # For single prompt case
                response_df = pd.DataFrame(
                    [
                        {
                            f"{result['proceso'].lower()}_prompt_id": "response",
                            f"{result['proceso'].lower()}_rsp": result["response"],
                        }
                    ]
                )

            # Agrega las columnas comunes a todas las filas
            response_df["fec_proceso"] = result["fec_proceso"]
            response_df[id_column_name] = result[id_column_name]

            response_dicts.append(response_df)

    if response_dicts:
        # Concatena todos los DataFrames de respuesta
        df_response = pd.concat(response_dicts, ignore_index=True)

        async with _save_output_lock:
            df_analyzed = s3_storage.get_history(id_column_name)

            df_analyzed = pd.concat([df_analyzed, df_response], ignore_index=True).map(
                lambda x: (
                    str(x).replace(".", ",") if isinstance(x, (int, float)) else x
                )
            )

            s3_storage.upload_df(df_analyzed)


async def _trace_llm_calls(
    results: list, id_column_name: str, s3_trace: S3Storage
) -> None:
    """
    Función para tracear las llamadas a LLM en S3.

    Parameters
    ----------
    results : list
        La lista de resultados de las llamadas a LLM.
        Cada elemento es un diccionario con los resultados de una llamada.

    id_column_name : str
        Nombre de la columna del identificador.
        Ejemplo: nombreFichero, idSiniestro, etc.

    s3_trace : S3Storage
        Objeto para almacenar las trazas en S3.
        Proporciona métodos para interactuar con el almacenamiento S3.

    Returns
    -------
    None
        No devuelve un valor. Guarda las trazas en S3.

    Notes
    -----
    - Prepara la información de traza para todas las llamadas exitosas
    - Utiliza un lock para evitar problemas de concurrencia
    - Añade las nuevas trazas al historial existente
    - Convierte valores numéricos a cadenas para evitar problemas de formato

    Examples
    --------
    Ejemplo de los resultados de trazabilidad de LLM que se guardarán en S3:
    >>> # Supongamos que tenemos resultados de análisis de documentos
    >>> results = [
    ...     {
    ...         'response': pd.DataFrame([
    ...             ['tema_principal', 'Transformación digital'],
    ...             ['palabras_clave', 'innovación, tecnología, cambio']
    ...         ], columns=['analisis_articulo_prompt_id', 'analisis_articulo_rsp']),
    ...         'id': 'articulo1',
    ...         'fec_proceso': '2024-01-15 10:30:45',
    ...         'metodo': 'nfq',
    ...         'model': 'gpt-4',
    ...         'proceso': 'analisis_articulo',
    ...         'prompt_tokens': 150,
    ...         'completion_tokens': 200,
    ...         'total_price': 0.0075,
    ...         'retries': 0
    ...     },
    ...     {
    ...         'response': pd.DataFrame([
    ...             ['tema_principal', 'Impacto del cambio climático'],
    ...             ['palabras_clave', 'medio ambiente, sostenibilidad, acción global']
    ...         ], columns=['analisis_articulo_prompt_id', 'analisis_articulo_rsp']),
    ...         'id': 'articulo2',
    ...         'fec_proceso': '2024-01-15 10:31:20',
    ...         'metodo': 'aegon',
    ...         'model': 'gpt-4-turbo',
    ...         'proceso': 'analisis_articulo',
    ...         'prompt_tokens': 180,
    ...         'completion_tokens': 220,
    ...         'total_price': 0.0090,
    ...         'retries': 1
    ...     }
    ... ]
    >>>
    >>> # El DataFrame final guardado en S3 se verá así:
    >>> # df_s3 = pd.DataFrame([
    >>> #     {
    >>> #         'id': 'articulo1',
    >>> #         'fec_proceso': '2024-01-15 10:30:45',
    >>> #         'metodo': 'nfq',
    >>> #         'modelo': 'gpt-4',
    >>> #         'caso_uso': 'analisis_articulo',
    >>> #         'num_tokens_prompt': 150,
    >>> #         'num_tokens_completion': 200,
    >>> #         'precio': 0.0075,
    >>> #         'reintentos': 0
    >>> #     },
    >>> #     {
    >>> #         'id': 'articulo2',
    >>> #         'fec_proceso': '2024-01-15 10:31:20',
    >>> #         'metodo': 'aegon',
    >>> #         'modelo': 'gpt-4-turbo',
    >>> #         'caso_uso': 'analisis_articulo',
    >>> #         'num_tokens_prompt': 180,
    >>> #         'num_tokens_completion': 220,
    >>> #         'precio': 0.0090,
    >>> #         'reintentos': 1
    >>> #     }
    >>> # ])
    >>>
    >>> # Guardar las trazas en S3
    >>> await _trace_llm_calls(
    ...     results=results,
    ...     id_column_name="id",
    ...     s3_trace=s3_trace_instance
    ... )
    """
    # Prepara la información de traza para todas las llamadas exitosas
    trace_info = [
        {
            id_column_name: result[id_column_name],
            "fec_proceso": result["fec_proceso"],
            "metodo": result["metodo"],
            "modelo": result["model"],
            "caso_uso": result["proceso"],
            "num_tokens_prompt": result["prompt_tokens"],
            "num_tokens_completion": result["completion_tokens"],
            "precio": result["total_price"],
            "reintentos": int(result["retries"]),
        }
        for result in results
        if result is not None
    ]

    if trace_info:
        # Usa el lock cuando se accede a un recurso compartido
        async with _trace_lock:
            # Obtiene el historial existente
            df_analysis_info = s3_trace.get_history(id_column_name)

            # Añade las nuevas trazas
            df_analysis_info = pd.concat(
                [df_analysis_info, pd.DataFrame(trace_info)],
                ignore_index=True,
            )

            s3_trace.upload_df(df_analysis_info)


async def _llm_call_core(
    id: str,
    id_column_name: str,
    text: Dict[str, Any],
    context: str,
    prompts: Union[str, Dict[str, Any]],
    process: str,
    service: str,
    model: str,
    input_token_price: float,
    output_token_price: float,
    fec_proceso: datetime,
    logs_enabled: bool = True,
) -> Optional[Dict[str, Any]]:
    """
    Función asíncrona para realizar una llamada al modelo de lenguaje (LLM) y procesar su respuesta.

    Esta función gestiona la llamada a un modelo de lenguaje, maneja reintentos,
    procesa la respuesta y genera un diccionario de resultados con información detallada.

    Parameters
    ----------
    id : str
        Identificador único del texto a analizar.
        Se utiliza para rastreo y logging de la operación.

    id_column_name : str
        Nombre de la columna de identificación en el DataFrame de resultados.
        Ejemplo: 'nombreFichero', 'idSiniestro', etc.

    text : Dict[str, Any]
        El texto o contenido a analizar por el modelo de lenguaje.
        Puede ser un diccionario o un texto plano.

    context : str
        Contexto del sistema para guiar la generación de respuestas del LLM.
        Proporciona instrucciones o marco de referencia para el análisis.

    prompts : Union[str, Dict[str, Any]]
        Prompt o conjunto de prompts para el análisis.
        - Si es un string: prompt único para análisis general.
        - Si es un diccionario: contiene 'str' (prompts) y 'keys' (claves asociadas).

    process : str
        Nombre del proceso de análisis.
        Utilizado para logging y trazabilidad.

    service : str
        Servicio de LLM a utilizar.
        Opciones típicas: 'nfq', 'aegon'.

    model : str
        Modelo de lenguaje específico a utilizar.
        Ejemplo: 'gpt-4', 'gpt-3.5-turbo'.

    input_token_price : float
        Precio por token de entrada para cálculo de costos.

    output_token_price : float
        Precio por token de salida para cálculo de costos.

    fec_proceso : datetime
        Fecha y hora de inicio del proceso de análisis.

    logs_enabled : bool, optional
        Habilita o deshabilita el registro de logs.
        Por defecto es True.

    Returns
    -------
    Optional[Dict[str, Any]]
        Diccionario con los resultados del análisis, que incluye:
        - Respuesta del LLM (como string o DataFrame)
        - Metadatos del proceso (identificador, fecha, método, modelo)
        - Información de uso de tokens y precio
        - Número de reintentos realizados

        Retorna None si no se puede completar el análisis.

    Raises
    ------
    Exception
        Captura y registra cualquier error durante el proceso de análisis.

    Examples
    --------
    Ejemplo con un único prompt:
    >>> result = await _llm_call_core(
    ...     id='documento1',
    ...     id_column_name='id',
    ...     text='Texto de ejemplo para análisis',
    ...     context='Eres un asistente de análisis',
    ...     prompts='Resume el siguiente texto',
    ...     process='resumen',
    ...     service='nfq',
    ...     model='gpt-4',
    ...     input_token_price=0.01,
    ...     output_token_price=0.02,
    ...     fec_proceso=datetime.now()
    ... )

    Ejemplo con múltiples prompts:
    >>> result = await _llm_call_core(
    ...     id='documento2',
    ...     id_column_name='id',
    ...     text='Texto de ejemplo para análisis múltiple',
    ...     context='Eres un analista experto',
    ...     prompts={
    ...         'str': '{"tema": "Identifica el tema", "palabras_clave": "Extrae palabras clave"}',
    ...         'keys': ['tema', 'palabras_clave']
    ...     },
    ...     process='analisis_articulo',
    ...     service='aegon',
    ...     model='gpt-4-turbo',
    ...     input_token_price=0.015,
    ...     output_token_price=0.025,
    ...     fec_proceso=datetime.now()
    ... )

    Notes
    -----
    - Maneja llamadas a diferentes servicios de LLM de manera uniforme
    - Implementa un mecanismo de reintento configurable
    - Calcula el precio total basado en el uso de tokens
    - Soporta análisis con prompts únicos y múltiples
    """

    if logs_enabled:
        _logger.info(f"{process}: Realizando analisis del identificador: {id}")

    if isinstance(prompts, dict):
        prompt_str = prompts["str"]
        prompt_keys = prompts["keys"]
    else:
        prompt_str = prompts

    total_price = 0
    retries = -1
    try:
        while True:
            retries += 1
            response = await _format_llm_call(
                text,
                prompt_str,
                model,
                input_token_price,
                output_token_price,
                context,
                service,
            )

            if (
                response is None
                or "content" not in response["choices"][0]["message"].keys()
            ):
                _logger.error(
                    f"{process}: Error de GPT - Reintentando analisis del identificador {id}"
                )
                await asyncio.sleep(5)
                continue

            total_price += response["usage"]["totalPrice"]

            if isinstance(prompts, dict):
                val_response = _set_dicctionary_py(
                    response["choices"][0]["message"]["content"]
                )

                if val_response is None or sorted(prompt_keys) != sorted(
                    val_response.keys()
                ):
                    _logger.error(
                        f"{process}: Error de Formato Salida - Reintentando analisis del identificador {id}"
                    )

                    _logger.debug(
                        f"{process}: {response["choices"][0]["message"]["content"]}"
                    )

                    await asyncio.sleep(5)
                    continue

                output_response = pd.DataFrame(
                    list(val_response.items()),
                    columns=[process.lower() + "_prompt_id", process.lower() + "_rsp"],
                )
                # Convert DataFrame rows to dictionary entries
                response_dict = {
                    "response": output_response,
                    **{
                        f"{row[process.lower() + '_prompt_id']}": row[
                            process.lower() + "_rsp"
                        ]
                        for _, row in output_response.iterrows()
                    },
                }
            else:
                response_dict = {
                    "response": response["choices"][0]["message"]["content"]
                }

            break

        if logs_enabled:
            _logger.info(f"{process}: {id} analizado correctamente")

        return {
            **response_dict,
            id_column_name: id,
            "fec_proceso": fec_proceso.strftime("%Y-%m-%d %H:%M:%S"),
            "proceso": process,
            "metodo": service,
            "model": response["model"],
            "prompt_tokens": response["usage"]["promptTokens"],
            "completion_tokens": response["usage"]["completionTokens"],
            "total_price": total_price,
            "retries": retries,
        }
    except Exception as e:
        _logger.error(f"{process}: Error al analizar el identificador {id}: {e}")
        return None


def _set_dicctionary_py(txt: str) -> typing.Optional[dict]:
    """
    Convierte la respuesta del LLM en texto plano a un diccionario de Python.

    Parameters
    ----------
    txt : str
        El texto a convertir (respuesta del LLM en texto plano).
        Debe ser una representación de diccionario válida.

    Returns
    -------
    dict or None
        El diccionario convertido.
        Devuelve None si no se puede convertir.

    Examples
    --------
    >>> result = _set_dicctionary_py("{'key1': 'value1', 'key2': 'value2'}")
    >>> print(result)
    {'key1': 'value1', 'key2': 'value2'}

    >>> result = _set_dicctionary_py("Invalid dictionary")
    >>> print(result)
    None

    Notes
    -----
    - Intenta convertir el texto usando json.loads()
    - Si falla, intenta usar ast.literal_eval()
    - Devuelve None si ambos métodos fallan
    """
    try:
        return json.loads(txt)
    except json.JSONDecodeError:
        try:
            return ast.literal_eval(txt)
        except (ValueError, SyntaxError):
            return None


def _get_model_prices(table_prices: str, index_prices: int) -> pd.Series:
    """
    Obtiene los precios asociados al modelo utilizado en la llamada.

    Parameters
    ----------
    table_prices : str
        El nombre de la tabla que contiene los precios.
        Tabla en Redshift con información de precios de modelos.

    index_prices : int
        El índice de los precios a utilizar en la tabla_prices.
        Identifica la configuración específica de precios.

    Returns
    -------
    pandas.Series
        Los precios asociados al modelo.
        Contiene el modelo, precio de token de entrada y precio de token de salida.

    Examples
    --------
    >>> prices = _get_model_prices("tabla_precios", 1)
    >>> print(prices)
    modelo                 gpt-4
    precio_input_token     0.01
    precio_output_token    0.02
    Name: 0, dtype: object

    Notes
    -----
    - Recupera información de precios desde una tabla de Redshift
    - Utiliza una consulta SQL para obtener los datos
    - Devuelve un pandas.Series con la información de precios
    """
    return _rs_connection.query(
        f"select modelo, precio_input_token, precio_output_token from {table_prices} where price_id = {index_prices}",
    ).squeeze()


async def llm_call_async(
    analysis_info: pd.DataFrame,
    id_field: str,
    analysis_field: str,
    prompts_config: PromptsConfig,
    process: str,
    service: str,
    fec_proceso: datetime = datetime.now(),
    max_concurrency: int = 10,
    logs_enabled: bool = True,
    storage_config: Optional[S3Storage] = None,
    trace: bool = False,
) -> List[Dict[str, Any]]:
    """
    Función para llamar a un LLM para analizar información de forma asíncrona, los resultados se guardan y trazan en S3.

    Parameters
    ----------
    analysis_info : pandas.DataFrame
        Dataframe de textos de información con campos obligatorios: "id_field", "analysis_field"

    id_field : str
        Nombre de la columna de identificación del proceso dentro del dataframe.

    analysis_field : str
        Nombre de la columna a usar para el análisis dentro del dataframe.

    prompts_config : PromptsConfig
        Configuración para manejar el contexto, los prompts y sus keys asociadas.

    process : str
        Nombre del proceso a ejecutar (para logs).

    service : str
        Servicio a usar para la llamada de LLM.

    fec_proceso : datetime, optional
        Fecha del análisis. Por defecto: datetime.now().

    max_concurrency : int, optional
        Número máximo de llamados a procesar en paralelo. Por defecto: 10.

    logs_enabled : bool, optional
        Si se loggea la información de las operaciones del LLM. Por defecto: True.

    storage_config : S3Storage, optional
        Objeto para guardar resultados en S3.

    trace : bool, optional
        Si se debe guardar la trazabilidad de las llamadas al LLM en S3. Por defecto: False.

    Returns
    -------
    List[Dict[str, Any]]
        La lista de resultados de la llamada de LLM. Cada elemento es un diccionario con:

        * ``response`` (Union[pd.DataFrame, str]): Respuesta del LLM
            - Si se usaron múltiples prompts: DataFrame con columnas:
                - ``{process.lower()}_prompt_id`` (str): ID del prompt utilizado
                - ``{process.lower()}_rsp`` (str): Respuesta del LLM para ese prompt
            - Si se usó un único prompt: string con la respuesta directa del LLM

        * ``identificador`` (str): Identificador del texto analizado
        * ``fec_proceso`` (str): Fecha y hora del proceso en formato "YYYY-MM-DD HH:MM:SS"
        * ``proceso`` (str): Nombre del proceso ejecutado
        * ``metodo`` (str): Servicio utilizado (nfq o aegon)
        * ``model`` (str): Modelo de LLM utilizado
        * ``prompt_tokens`` (int): Número de tokens en el prompt
        * ``completion_tokens`` (int): Número de tokens en la respuesta
        * ``total_price`` (float): Costo total de la llamada
        * ``retries`` (int): Número de reintentos realizados

    Raises
    ------
    ValueError
        Si las columnas especificadas no existen en el dataframe.

    Examples
    --------
    Ejemplo con un único prompt para análisis de texto:
    >>> # Crear un DataFrame de ejemplo
    >>> df = pd.DataFrame({
    ...     'id': ['doc1', 'doc2', 'doc3'],
    ...     'texto': [
    ...         'El cambio climático afecta gravemente al planeta.',
    ...         'La innovación tecnológica impulsa el desarrollo económico.',
    ...         'La educación es clave para el progreso social.'
    ...     ]
    ... })
    >>>
    >>> # Configurar el contexto y prompt
    >>> config = PromptsConfig(
    ...     context="Eres un analista experto en resumir información",
    ...     prompt="Genera un resumen conciso del siguiente texto"
    ... )
    >>>
    >>> # Realizar el análisis con el servicio NFQ de forma asíncrona
    >>> resultados = await llm_call_async(
    ...     analysis_info=df,
    ...     id_field='id',
    ...     analysis_field='texto',
    ...     prompts_config=config,
    ...     process='resumen',
    ...     service='nfq'
    ... )
    >>>
    >>> # Imprimir los resultados
    >>> for resultado in resultados:
    ...     print(f"Documento {resultado['id']}: {resultado['response']}")

    Ejemplo con múltiples prompts para análisis de texto:
    >>> # Crear un DataFrame de ejemplo
    >>> df = pd.DataFrame({
    ...     'id': ['articulo1', 'articulo2'],
    ...     'texto': [
    ...         'La inteligencia artificial está transformando múltiples industrias.',
    ...         'El cambio climático requiere acciones globales inmediatas.'
    ...     ]
    ... })
    >>>
    >>> # Configurar el contexto y múltiples prompts
    >>> config = PromptsConfig(
    ...     context="Eres un analista experto en extracción de información",
    ...     prompt=[
    ...         "Identifica el tema principal del texto",
    ...         "Extrae las palabras clave"
    ...     ],
    ...     keys_list=['tema', 'palabras_clave']
    ... )
    >>>
    >>> # Realizar el análisis con el servicio AEGON de forma asíncrona
    >>> resultados = await llm_call_async(
    ...     analysis_info=df,
    ...     id_field='id',
    ...     analysis_field='texto',
    ...     prompts_config=config,
    ...     process='analisis_articulo',
    ...     service='aegon'
    ... )
    >>>
    >>> # Imprimir los resultados
    >>> for resultado in resultados:
    ...     print(f"Documento {resultado['id']}:")
    ...     print(f"  Tema: {resultado['tema']}")
    ...     print(f"  Palabras Clave: {resultado['palabras_clave']}")

    Ejemplo con almacenamiento en S3:
    >>> # Configurar almacenamiento S3
    >>> storage = S3Storage(
    ...     bucket='mi-bucket',
    ...     path='resultados/analisis/'
    ... )
    >>>
    >>> # Realizar análisis con almacenamiento y trazabilidad
    >>> resultados = await llm_call_async(
    ...     analysis_info=df,
    ...     id_field='id',
    ...     analysis_field='texto',
    ...     prompts_config=config,
    ...     process='analisis_con_s3',
    ...     service='nfq',
    ...     storage_config=storage,
    ...     trace=True
    ... )

    Notes
    -----
    - Los ejemplos muestran diferentes escenarios de uso de la función
    - Se pueden usar servicios 'nfq' o 'aegon'
    - Soporta prompts únicos y múltiples
    - Permite configurar almacenamiento y trazabilidad opcional en S3
    - La función es asíncrona, por lo que debe ser llamada con `await`
    """

    if id_field not in analysis_info.columns:
        raise ValueError(
            f"La columna '{id_field}' debe pertenecer al dataframe 'analysis_info'."
        )

    if analysis_field not in analysis_info.columns:
        raise ValueError(
            f"La columna '{analysis_field}' debe pertenecer al dataframe 'analysis_info'."
        )

    model_prices = _get_model_prices(_config["table_price"], _config["index_price"])

    results = []
    for no in range(0, len(analysis_info), max_concurrency):
        info_batch = analysis_info.iloc[no : no + max_concurrency]

        tasks = []
        for info in info_batch.itertuples(index=False):
            if getattr(info, analysis_field) is nan:
                _logger.warning(
                    f"{process}: {getattr(info, id_field)} con información vacia, no es posible analizar."
                )
                continue

            tasks.append(
                _llm_call_core(
                    getattr(info, id_field),
                    id_field,
                    getattr(info, analysis_field),
                    prompts_config.get_context(),
                    prompts_config.get_formatted_prompts(),
                    process,
                    service,
                    model_prices.modelo,
                    model_prices.precio_input_token,
                    model_prices.precio_output_token,
                    fec_proceso,
                    logs_enabled,
                )
            )

        if tasks:
            # Run batch of async tasks
            batch_results = await asyncio.gather(*tasks)
            batch_results = [r for r in batch_results if r is not None]
            results.extend(batch_results)

            # Preparar tareas de S3 según las configuraciones proporcionadas
            s3_tasks = []

            if storage_config:
                s3_tasks.append(
                    _save_output_llm_calls(batch_results, id_field, storage_config)
                )

            if trace:
                trace_storage = S3Storage(
                    bucket=_config["s3_bucket_trace"],
                    path=_config["s3_path_trace"],
                    file_name=process,
                    date=fec_proceso,
                )
                s3_tasks.append(
                    _trace_llm_calls(batch_results, id_field, trace_storage)
                )

            if s3_tasks:
                await asyncio.gather(*s3_tasks)

    return results


def llm_call(
    analysis_info: pd.DataFrame,
    id_field: str,
    analysis_field: str,
    prompts_config: PromptsConfig,
    process: str,
    service: str,
    fec_proceso: datetime = datetime.now(),
    max_concurrency: int = 10,
    logs_enabled: bool = True,
    storage_config: Optional[S3Storage] = None,
    trace: bool = False,
) -> List[Dict[str, Any]]:
    """
    Función para llamar a un LLM de forma síncrona, los resultados se guardan y trazan en S3.

    Parameters
    ----------
    analysis_info : pandas.DataFrame
        Dataframe de textos de información con campos obligatorios: "id_field", "analysis_field"

    id_field : str
        Nombre de la columna de identificación del proceso dentro del dataframe.

    analysis_field : str
        Nombre de la columna a usar para el análisis dentro del dataframe.

    prompts_config : PromptsConfig
        Configuración para manejar el contexto, los prompts y sus keys asociadas.

    process : str
        Nombre del proceso a ejecutar (para logs).

    service : str
        Servicio a usar para la llamada de LLM.

    fec_proceso : datetime, optional
        Fecha del análisis. Por defecto: datetime.now().

    max_concurrency : int, optional
        Número máximo de llamados a procesar en paralelo. Por defecto: 10.

    logs_enabled : bool, optional
        Si se loggea la información de las operaciones del LLM. Por defecto: True.

    storage_config : S3Storage, optional
        Objeto para guardar resultados en S3.

    trace : bool, optional
        Si se debe guardar la trazabilidad de las llamadas al LLM en S3. Por defecto: False.

    Returns
    -------
    List[Dict[str, Any]]
        La lista de resultados de la llamada de LLM. Cada elemento es un diccionario con:

        * ``response`` (Union[pd.DataFrame, str]): Respuesta del LLM
            - Si se usaron múltiples prompts: DataFrame con columnas:
                - ``{process.lower()}_prompt_id`` (str): ID del prompt utilizado
                - ``{process.lower()}_rsp`` (str): Respuesta del LLM para ese prompt
            - Si se usó un único prompt: string con la respuesta directa del LLM

        * ``identificador`` (str): Identificador del texto analizado
        * ``fec_proceso`` (str): Fecha y hora del proceso en formato "YYYY-MM-DD HH:MM:SS"
        * ``proceso`` (str): Nombre del proceso ejecutado
        * ``metodo`` (str): Servicio utilizado (nfq o aegon)
        * ``model`` (str): Modelo de LLM utilizado
        * ``prompt_tokens`` (int): Número de tokens en el prompt
        * ``completion_tokens`` (int): Número de tokens en la respuesta
        * ``total_price`` (float): Costo total de la llamada
        * ``retries`` (int): Número de reintentos realizados

    Raises
    ------
    ValueError
        Si las columnas especificadas no existen en el dataframe.

    Examples
    --------
    Ejemplo con un único prompt para análisis de texto:
    >>> # Crear un DataFrame de ejemplo
    >>> df = pd.DataFrame({
    ...     'id': ['doc1', 'doc2', 'doc3'],
    ...     'texto': [
    ...         'El cambio climático afecta gravemente al planeta.',
    ...         'La innovación tecnológica impulsa el desarrollo económico.',
    ...         'La educación es clave para el progreso social.'
    ...     ]
    ... })
    >>>
    >>> # Configurar el contexto y prompt
    >>> config = PromptsConfig(
    ...     context="Eres un analista experto en resumir información",
    ...     prompt="Genera un resumen conciso del siguiente texto"
    ... )
    >>>
    >>> # Realizar el análisis con el servicio NFQ
    >>> resultados = llm_call(
    ...     analysis_info=df,
    ...     id_field='id',
    ...     analysis_field='texto',
    ...     prompts_config=config,
    ...     process='resumen',
    ...     service='nfq'
    ... )
    >>>
    >>> # Imprimir los resultados
    >>> for resultado in resultados:
    ...     print(f"Documento {resultado['id']}: {resultado['response']}")

    Ejemplo con múltiples prompts para análisis de texto:
    >>> # Crear un DataFrame de ejemplo
    >>> df = pd.DataFrame({
    ...     'id': ['articulo1', 'articulo2'],
    ...     'texto': [
    ...         'La inteligencia artificial está transformando múltiples industrias.',
    ...         'El cambio climático requiere acciones globales inmediatas.'
    ...     ]
    ... })
    >>>
    >>> # Configurar el contexto y múltiples prompts
    >>> config = PromptsConfig(
    ...     context="Eres un analista experto en extracción de información",
    ...     prompt=[
    ...         "Identifica el tema principal del texto",
    ...         "Extrae las palabras clave"
    ...     ],
    ...     keys_list=['tema', 'palabras_clave']
    ... )
    >>>
    >>> # Realizar el análisis con el servicio AEGON
    >>> resultados = llm_call(
    ...     analysis_info=df,
    ...     id_field='id',
    ...     analysis_field='texto',
    ...     prompts_config=config,
    ...     process='analisis_articulo',
    ...     service='aegon'
    ... )
    >>>
    >>> # Imprimir los resultados
    >>> for resultado in resultados:
    ...     print(f"Documento {resultado['id']}:")
    ...     print(f"  Tema: {resultado['tema']}")
    ...     print(f"  Palabras Clave: {resultado['palabras_clave']}")

    Ejemplo con almacenamiento en S3:
    >>> # Configurar almacenamiento S3
    >>> storage = S3Storage(
    ...     bucket='mi-bucket',
    ...     path='resultados/analisis/'
    ... )
    >>>
    >>> # Realizar análisis con almacenamiento y trazabilidad
    >>> resultados = llm_call(
    ...     analysis_info=df,
    ...     id_field='id',
    ...     analysis_field='texto',
    ...     prompts_config=config,
    ...     process='analisis_con_s3',
    ...     service='nfq',
    ...     storage_config=storage,
    ...     trace=True
    ... )

    Notes
    -----
    - Los ejemplos muestran diferentes escenarios de uso de la función
    - Se pueden usar servicios 'nfq' o 'aegon'
    - Soporta prompts únicos y múltiples
    - Permite configurar almacenamiento y trazabilidad opcional en S3
    """
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(
        llm_call_async(
            analysis_info,
            id_field,
            analysis_field,
            prompts_config,
            process,
            service,
            fec_proceso,
            max_concurrency,
            logs_enabled,
            storage_config,
            trace,
        )
    )
