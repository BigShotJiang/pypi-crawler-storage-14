"""
Módulo de Envío de Correos Electrónicos para Analytics Toolkit

Este módulo proporciona una interfaz simplificada para enviar correos electrónicos
a través del servicio interno, con soporte para mensajes personalizados
y adjuntos de DataFrames.

Características principales:
- Envío de correos electrónicos personalizados
- Soporte para múltiples destinatarios
- Conversión de DataFrames a archivos adjuntos
- Codificación base64 para asunto y cuerpo del correo
- Integración con servicio de email

Componentes principales:
- send_emails(): Función para enviar correos electrónicos

Ejemplo de uso básico:
```python
from analytics_toolkit.email import send_emails
import pandas as pd

# Envío de un correo electrónico simple
send_emails(
    subject="Informe de Análisis",
    body="Adjunto el informe solicitado.",
    recipients=["usuario@ejemplo.com"]
)

# Envío de un correo electrónico con un DataFrame adjunto
df = pd.DataFrame({
    'nombre': ['Juan', 'María'],
    'edad': [30, 25]
})

send_emails(
    subject="Informe de Datos",
    body="Por favor, encuentra adjunto el informe de datos.",
    recipients=["usuario@ejemplo.com"],
    files={"informe.csv": df}
)
```

Tipos de plantillas de correo:
- Gn000: Comunicación genérica sin adjuntos
- Ad000: Comunicación con archivos adjuntos

Funcionalidades avanzadas:
- Formateo automático del cuerpo del correo con etiquetas HTML
- Codificación base64 de asunto y contenido
- Generación de UUID para cada solicitud
- Manejo de errores y excepciones

Dependencias:
- base64: Codificación de archivos
- requests: Envío de solicitudes HTTP
- pandas: Manipulación de DataFrames
- uuid: Generación de identificadores únicos

Patrones de uso:
- Envío de informes
- Notificaciones automatizadas
- Distribución de datos
- Comunicaciones internas

Consideraciones:
- Requiere configuración previa de credenciales
- Limitado al servicio de email interno
- Manejo de codificación y formato de correos

Seguridad:
- Uso de HTTPS
- Codificación de contenido sensible
- Control de acceso mediante client ID
"""

import base64
import json
import requests
import uuid
import pandas as pd

from ._shared import _config, _environment


__all__ = ["send_emails"]


def _dataframe_to_base64(dataframe: pd.DataFrame):
    """Convertir un DataFrame a un CSV en base64."""
    # Convert the DataFrame to a CSV string.
    csv_string = dataframe.to_csv(index=False)

    # Encode the CSV string as bytes and then as a base64 string.
    return base64.b64encode(csv_string.encode()).decode()


def send_email_analytics(
    subject: str,
    body: str,
    template_type: str = None,
    files: dict[str, pd.DataFrame] = {},
) -> str:
    """
    Envía correos electrónicos de reporting al buzon compartido por el equipo de Analytics.

    Parameters
    ----------
    subject : str
        El asunto del correo electrónico. Se codificará en base64 antes de ser enviado.
        Este parámetro determina la línea de asunto que verán los destinatarios.

    body : str
        El cuerpo del correo electrónico. Cada línea se formateará con etiquetas HTML
        Define el contenido principal del mensaje de correo electrónico.

    template_type : str, opcional
        Tipo de plantilla a utilizar para el correo. Valores posibles:
        - ``Ad000``: ``ANALYTICS_COMUNICACION_GENERICA_ADJUNTO``
        - ``Ad001``: ``ANALYTICS_COMUNICACION_GENERICA_ESANALITICA``
        Si es None, se selecciona automáticamente ``Ad000`` si hay archivos o ``Gn000`` si no hay archivos.

    files : dict[str, pd.DataFrame], opcional
        Diccionario de nombres de archivos y sus correspondientes DataFrames.
        Por defecto es un diccionario vacío.
        Las claves son los nombres de los archivos, los valores son los DataFrames.

    Returns
    -------
    dict or str
        Respuesta del servicio de envío de correos electrónicos.
        - Si el envío es exitoso, devuelve la respuesta del servidor.
        - Si ocurre un error, devuelve un mensaje de error.
        - Si el environment es ``NONPROD``, devuelve un diccionario con la información que se hubiera enviado.

    Notes
    -----
    - Solo se enviará el correo electrónico si el environment es ``PROD``. Para cualquier otro entorno se retornará un diccionario con la información que se hubiera enviado.
    - Para las plantillas ``Ad000`` y ``Ad001`` se enviara automaticamente el correo el buzon compartido del equipo de Analytics.
    """

    return send_emails(
        subject=subject,
        body=body,
        recipients=[_config["email_analytics"]],
        template_type=template_type,
        files=files,
    )


def send_emails(
    subject: str,
    body: str,
    recipients: list[str],
    cc_recipients: list[str] = None,
    bcc_recipients: list[str] = None,
    template_type: str = None,
    files: dict[str, pd.DataFrame] = {},
) -> str:
    """
    Envía correos electrónicos a través del servicio interno.

    Parameters
    ----------
    subject : str
        El asunto del correo electrónico. Se codificará en base64 antes de ser enviado.
        Este parámetro determina la línea de asunto que verán los destinatarios.

    body : str
        El cuerpo del correo electrónico. Cada línea se formateará con etiquetas HTML
        para mejorar la presentación visual.
        Define el contenido principal del mensaje de correo electrónico.

    recipients : list[str]
        Una lista de direcciones de correo electrónico de los destinatarios principales.
        Cada dirección de correo electrónico recibirá el mensaje.

    cc_recipients : list[str], opcional
        Una lista de direcciones de correo electrónico para copia ``(CC)``.
        Por defecto es None.

    bcc_recipients : list[str], opcional
        Una lista de direcciones de correo electrónico para copia oculta (BCC).
        Por defecto es None.

    template_type : str, opcional
        Tipo de plantilla a utilizar para el correo. Valores posibles:
        - ``Gn000``: ``ANALYTICS_COMUNICACION_GENERICA`` (valor por defecto si no hay archivos)
        - ``Gn001``: ``ANALYTICS_COMUNICACION_GENERICA_STD``
        - ``Ad000``: ``ANALYTICS_COMUNICACION_GENERICA_ADJUNTO`` (valor por defecto si hay archivos)
        - ``Ad001``: ``ANALYTICS_COMUNICACION_GENERICA_ESANALITICA``
        Si es None, se selecciona automáticamente ``Gn000`` si no hay archivos o ``Ad000`` si hay archivos.

    files : dict[str, pd.DataFrame], opcional
        Diccionario de nombres de archivos y sus correspondientes DataFrames.
        Por defecto es un diccionario vacío.
        Las claves son los nombres de los archivos, los valores son los DataFrames.

    Returns
    -------
    dict or str
        Respuesta del servicio de envío de correos electrónicos.
        - Si el envío es exitoso, devuelve la respuesta del servidor.
        - Si ocurre un error, devuelve un mensaje de error.
        - Si el environment es ``NONPROD``, devuelve un diccionario con la información que se hubiera enviado.

    Notes
    -----
    - Solo se enviará el correo electrónico si el environment es ``PROD``. Para cualquier otro entorno se retornará un diccionario con la información que se hubiera enviado.
    - Para las plantillas ``Ad000`` y ``Ad001`` se enviara automaticamente el correo el buzon compartido del equipo de Analytics.

    Examples
    --------
    Envío de un correo electrónico simple sin archivos adjuntos:

    >>> send_emails(
    ...     subject="Informe de Análisis",
    ...     body="Adjunto el informe solicitado.",
    ...     recipients=["usuario@ejemplo.com"]
    ... )

    Envío de un correo electrónico con copia y copia oculta:

    >>> send_emails(
    ...     subject="Informe de Análisis",
    ...     body="Adjunto el informe solicitado.",
    ...     recipients=["usuario@ejemplo.com"],
    ...     cc_recipients=["copia@ejemplo.com"],
    ...     bcc_recipients=["copia_oculta@ejemplo.com"]
    ... )

    Envío de un correo electrónico con un DataFrame adjunto:

    >>> send_emails(
    ...     subject="Informe de Análisis",
    ...     body="Adjunto el informe solicitado.",
    ...     recipients=["usuario@ejemplo.com"],
    ...     files={"informe.csv": dataframe}
    ... )

    Envío de un correo electrónico con una plantilla específica:

    >>> send_emails(
    ...     subject="Informe de Análisis",
    ...     body="Adjunto el informe solicitado.",
    ...     recipients=["usuario@ejemplo.com"],
    ...     template_type="Gn001"
    ... )
    """

    if template_type is None:
        # Inferir el template_type basado en la presencia de archivos
        template_type = "Ad000" if files else "Gn000"

    if not template_type.startswith("Ad") and files:
        raise ValueError(
            "Para enviar archivos adjuntos se debe usar la plantilla Ad000 o Ad001"
        )

    # Convertir archivos a base64
    base64_files = {name: _dataframe_to_base64(df) for name, df in files.items()}

    url = _config["email_host"]
    clientId = _config["email_clienid"]
    caller_environment = _config["email_call_env"]
    logical_environment = _config["email_log_env"]

    # Creación de los parametros necesarios para el envio de mail a traves de la api_manager
    headers = {
        "X-IBM-Client-Id": clientId,
        "Content-type": "application/json;charset=utf-8",
        "cache-control": "no-cache",
        "caller": "ANALYTICS",
        "company": "0001",
        "caller-environment": caller_environment,
        "request-id": str(uuid.uuid4()),
        "logical-environment": logical_environment,
    }

    # Se define todas las plantillas de emails que se han definido para el endpoint de ANALYTICS
    email_templates = {
        "Gn000": "ANALYTICS_COMUNICACION_GENERICA",
        "Gn001": "ANALYTICS_COMUNICACION_GENERICA_STD",
        "Ad000": "ANALYTICS_COMUNICACION_GENERICA_ADJUNTO",
        "Ad001": "ANALYTICS_COMUNICACION_GENERICA_ESANALITICA",
    }

    body_list = body.split("\n")
    formatted_body = "".join(
        [
            f'<tr><td valign="top" style="font-family: Verdana, Arial, Helvetica, sans-serif; background-color: #ffffff; font-size: 12px; line-height: 15px; color: #00000; text-align: justify; font-weight:normal; padding:3px 40px 3px 40px;">{line}</td></tr>'
            for line in body_list
        ]
    )

    encoded_subject = base64.b64encode(subject.encode("utf-8")).decode("utf-8")
    encoded_body = base64.b64encode(formatted_body.encode("utf-8")).decode("utf-8")

    # Construir la lista de destinatarios con sus tipos de envío
    destinatarios = []

    # Agregar destinatarios principales
    for email in recipients:
        destinatarios.append({"email": email})

    # Agregar destinatarios en copia
    if cc_recipients is not None:
        for email in cc_recipients:
            destinatarios.append({"email": email, "tipo_envio_email": "COPIA"})

    # Agregar destinatarios en copia oculta
    if bcc_recipients is not None:
        for email in bcc_recipients:
            destinatarios.append({"email": email, "tipo_envio_email": "COPIA_OCULTA"})

    data = {
        "comunicacion": email_templates[template_type],
        "destinatarios": destinatarios,
        "personalizacion": {
            "asunto": {"ASUNTO": encoded_subject},
            "cuerpo": {"BODY": encoded_body},
        },
    }

    if template_type.startswith("Ad"):
        data["adjuntos"] = {
            "binarios": [
                {"nombre_fichero": name, "binario": base64}
                for name, base64 in base64_files.items()
            ]
        }

    # Solo se enviará el correo electrónico si el environment es "PROD"
    if _environment == "PROD":
        try:
            response = requests.post(
                url, data=json.dumps(data), verify=True, headers=headers
            )
            outResponse = json.loads(response.content)
        except requests.HTTPError as http_err:
            outResponse = f"HTTP error occurred: {http_err}"
            return outResponse
        except Exception as err:
            outResponse = f"An error occurred: {err}"
            return outResponse

        return outResponse
    else:
        return {
            "recipients": recipients,
            "cc_recipients": cc_recipients,
            "bcc_recipients": bcc_recipients,
            "subject": subject,
            "body": body,
            "files": files,
        }
