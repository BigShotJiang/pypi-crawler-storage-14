"""
Módulo de Transcripción de Audio con AWS Transcribe

Este módulo proporciona funcionalidades para transcribir archivos de audio
almacenados en Amazon S3 utilizando el servicio AWS Transcribe. Ofrece
capacidades avanzadas de transcripción como identificación de idioma,
diarización de hablantes y redacción de información personal identificable (PII).

Características principales:
- Envío de archivos de audio para transcripción
- Recuperación de resultados de transcripción
- Soporte para múltiples idiomas
- Identificación de hablantes
- Redacción de información personal

Funciones principales:
- send_audio_transcription: Envía un archivo de audio para transcripción
- get_audio_transcription: Recupera y procesa los resultados de transcripción

Ejemplo de uso básico:
```python
from datetime import datetime
from analytics_toolkit.transcribe import send_audio_transcription, get_audio_transcription

# Enviar un archivo de audio para transcripción
job_name = send_audio_transcription(
    's3-bucket-name',
    'path/to/audio.mp3',
    language_codes=['es-US', 'en-US']
)

# Obtener la transcripción
if job_name:
    transcription_result = get_audio_transcription(job_name, datetime.now())
    print(transcription_result['transcripcion_formateada'])
```

Configuraciones avanzadas:
- Soporte para vocabularios personalizados
- Configuración de redacción de PII
- Identificación de múltiples idiomas
- Control de región de AWS

Dependencias:
- boto3: Interacción con servicios de AWS
- requests: Recuperación de archivos de transcripción
- json: Procesamiento de resultados de transcripción

Notas:
- Requiere configuración adecuada de credenciales de AWS
- La transcripción puede tardar dependiendo de la duración del archivo
- Se recomienda manejar excepciones al usar las funciones
"""

import boto3
import json
import requests
from time import sleep
from datetime import datetime
from typing import List, Optional, Dict, Union, Tuple
import pandas as pd
from ._shared import _logger
from .pii import detect_and_tag_pii

__all__ = ["send_audio_transcription", "get_audio_transcription"]


def _send_aws_transcribe_job(
    job_name: str,
    audio_file_uri: str,
    audio_type: str,
    language_codes: List[str] = ["es-US", "en-US"],
    redact_pii: bool = True,
    diarization: bool = True,
    vocabulary_name: Optional[str] = None,
    region_name: str = "eu-west-1",
) -> str:
    """
    Inicia un trabajo de transcripción de audio en AWS Transcribe.

    Envía un archivo de audio almacenado en Amazon S3 para su transcripción
    con opciones avanzadas de configuración.

    Parameters
    ----------
    job_name : str
        Nombre único para el trabajo de transcripción.
        Debe ser un identificador válido para AWS Transcribe.

    audio_file_uri : str
        URI de Amazon S3 del archivo de audio a transcribir.
        Debe ser una ruta completa al archivo en un bucket S3.

    audio_type : str
        Formato del archivo de audio (por ejemplo, 'wav', 'mp3').
        Debe ser un formato compatible con AWS Transcribe.

    language_codes : List[str], optional
        Lista de códigos de idioma para la identificación de idioma.
        Por defecto: ['es-US', 'en-US'].

    redact_pii : bool, optional
        Indica si se debe redactar información personal identificable.
        Por defecto: True.

    diarization : bool, optional
        Habilita la identificación de diferentes hablantes.
        Por defecto: True.

    vocabulary_name : str, optional
        Nombre de un vocabulario personalizado para mejorar la transcripción.
        Por defecto: None.

    region_name : str, optional
        Región de AWS donde se ejecutará el servicio Transcribe.
        Por defecto: 'eu-west-1'.

    Returns
    -------
    str
        Nombre del trabajo de transcripción iniciado.

    Raises
    ------
    botocore.exceptions.ClientError
        Si ocurre un error al iniciar el trabajo de transcripción.

    Examples
    --------
    >>> job_name = _send_aws_transcribe_job(
    ...     'mi_trabajo_transcripcion',
    ...     's3://mi-bucket/audio.mp3',
    ...     'mp3',
    ...     language_codes=['es-US'],
    ...     redact_pii=True
    ... )
    """
    transcribe_client = boto3.client("transcribe", region_name=region_name)

    job_settings = {
        "TranscriptionJobName": job_name,
        "Media": {"MediaFileUri": audio_file_uri},
        "MediaFormat": audio_type,
        "IdentifyLanguage": True,
        "LanguageOptions": language_codes,
    }

    language_id_settings = (
        {"es-US": {"VocabularyName": vocabulary_name}}
        if vocabulary_name and "es-US" in language_codes
        else None
    )

    if language_id_settings:
        job_settings["LanguageIdSettings"] = language_id_settings

    if redact_pii:
        job_settings["ContentRedaction"] = {
            "RedactionType": "PII",
            "RedactionOutput": "redacted",
        }

    if diarization:
        job_settings["Settings"] = {"ChannelIdentification": True}

    transcribe_client.start_transcription_job(**job_settings)

    return job_name


def send_audio_transcription(
    s3_bucket: str,
    audio_path: str,
    fec_proceso: datetime = datetime.now(),
    language_codes: List[str] = ["es-US", "en-US"],
    vocabulary_name: Optional[str] = None,
    redact_pii: bool = True,
    diarization: bool = True,
    region_name: str = "eu-west-1",
) -> Optional[str]:
    """
    Envía un archivo de audio al servicio AWS Transcribe para su procesamiento.

    Parameters
    ----------
    s3_bucket : str
        Nombre del bucket S3 donde se almacena el archivo de audio.

    audio_path : str
        Ruta al archivo de audio dentro del bucket S3.

    fec_proceso : datetime, optional
        Fecha del análisis. Por defecto: datetime.now().

    language_codes : List[str], optional
        Lista de códigos de idioma para la identificación de idioma.
        Por defecto: ['es-US', 'en-US'].

    vocabulary_name : str, optional
        Nombre de un vocabulario personalizado para mejorar la transcripción.
        Por defecto: None.

    redact_pii : bool, optional
        Indica si se debe redactar información personal identificable.
        Por defecto: True.

    diarization : bool, optional
        Habilita la identificación de diferentes hablantes.
        Por defecto: True.

    region_name : str, optional
        Región de AWS donde se ejecutará el servicio Transcribe.
        Por defecto: 'eu-west-1'.

    Returns
    -------
    Optional[str]
        Nombre del trabajo de transcripción si se inicia correctamente.
        None si ocurre un error.

    Raises
    ------
    FileNotFoundError
        Si el archivo de audio no se encuentra.
    IOError
        Si ocurre un error de entrada/salida.

    Examples
    --------
    >>> job_name = send_audio_transcription(
    ...     's3-bucket-name',
    ...     'path/to/audio.mp3',
    ...     language_codes=['es-US']
    ... )
    """
    nameAudio = audio_path.split("/")[-1]
    typeAudio = nameAudio.split(".")[-1]

    try:
        file_uri = f"s3://{s3_bucket}/{audio_path}"

        job_name = _send_aws_transcribe_job(
            fec_proceso.strftime("%Y%m%d%H%M%S") + "_" + nameAudio,
            file_uri,
            typeAudio,
            language_codes,
            redact_pii,
            diarization,
            vocabulary_name,
            region_name,
        )

        if job_name is None:
            _logger.error("Error al obtener la transcripción de AWS.")
            return None

        return job_name

    except FileNotFoundError:
        _logger.error("El archivo no fue encontrado.")
    except IOError as e:
        _logger.error(f"Error de E/S: {e}")
    except Exception as e:
        _logger.error(f"Ocurrió un error inesperado: {e}")

    return None


def _get_aws_transcribe_job(
    job_name: str, region_name: str = "eu-west-1"
) -> Tuple[Optional[Dict], Optional[datetime], Optional[datetime]]:
    """
    Obtiene el resultado de un trabajo de transcripción de AWS Transcribe.

    Parameters
    ----------
    job_name : str
        Nombre del trabajo de transcripción a recuperar.

    region_name : str, optional
        Región de AWS donde se ejecutó el servicio Transcribe.
        Por defecto: 'eu-west-1'.

    Returns
    -------
    Tuple[Optional[Dict], Optional[datetime], Optional[datetime]]
        - Diccionario con los resultados de la transcripción
        - Hora de inicio del trabajo
        - Hora de finalización del trabajo
        Retorna (None, None, None) si el trabajo falla.

    Raises
    ------
    botocore.exceptions.ClientError
        Si ocurre un error al consultar el estado del trabajo.

    Examples
    --------
    >>> transcription, start_time, end_time = _get_aws_transcribe_job('job_name')
    """
    transcribe_client = boto3.client("transcribe", region_name=region_name)

    max_error = 3
    while True:
        try:
            status = transcribe_client.get_transcription_job(
                TranscriptionJobName=job_name
            )
            if status["TranscriptionJob"]["TranscriptionJobStatus"] in [
                "COMPLETED",
                "FAILED",
            ]:
                break
        except:
            max_error -= 1

        if max_error == 0:
            return None, None, None

        sleep(5)

    if status["TranscriptionJob"]["TranscriptionJobStatus"] == "COMPLETED":
        transcript = status["TranscriptionJob"]["Transcript"]
        transcription_uri = transcript.get(
            "RedactedTranscriptFileUri"
        ) or transcript.get("TranscriptFileUri")

        response = requests.get(transcription_uri)

        return (
            json.loads(response.text),
            status["TranscriptionJob"]["StartTime"],
            status["TranscriptionJob"]["CompletionTime"],
        )
    else:
        return None, None, None


def get_audio_transcription(
    transcription_job: str, fec_proceso: datetime = None
) -> Optional[Dict[str, Union[str, float, bool, List]]]:
    """
    Obtiene y procesa la transcripción de un archivo de audio.

    Parameters
    ----------
    transcription_job : str
        Nombre del trabajo de transcripción a recuperar.

    fec_proceso : datetime, optional
        Fecha del análisis. Por defecto: se intenta extraer de la fecha del trabajo de transcripción. Si no es posible, se usa la fecha actual.

    Returns
    -------
    Optional[Dict[str, Union[str, float, bool, List]]]
        Diccionario con información detallada de la transcripción, incluyendo:
        - nombreFichero: Nombre del archivo original
        - fec_proceso: Fecha del procesamiento
        - ind_diarization: Indicador de diarización
        - ind_pii: Indicador de redacción de PII
        - fecha_ini_transcripcion: Hora de inicio de la transcripción
        - fecha_fin_transcripcion: Hora de finalización de la transcripción
        - duracion_transcripcion: Duración en segundos
        - transcripcion: Transcripción completa
        - segmentos_transcripcion: Elementos de transcripción separados por hablantes y tiempos
        - lenguaje: Código de idioma detectado
        - transcripcion_formateada: Transcripción formateada por hablantes

    Raises
    ------
    FileNotFoundError
        Si el archivo no se encuentra.
    IOError
        Si ocurre un error de entrada/salida.

    Examples
    --------
    >>> result = get_audio_transcription('job_name', datetime.now())
    >>> print(result['transcripcion_formateada'])
    """
    try:
        transcription_info, fecini_transcription, fecfin_transcription = (
            _get_aws_transcribe_job(transcription_job)
        )

        if transcription_info is None:
            _logger.error("Error al obtener la transcripción de AWS.")
            return None

        nombre_fichero = transcription_job.split("_")[-1]
        duracion_transcripcion = fecfin_transcription - fecini_transcription
        duracion_seconds = duracion_transcripcion.total_seconds()

        transcription = transcription_info["results"]

        if not transcription.get("items"):
            _logger.warning(
                f"{nombre_fichero} - La transcripción no contiene 'items'. El audio podría estar vacío."
            )
            return None

        transcription_raw = transcription["transcripts"][0]["transcript"]

        transcription_formatted = _format_items(transcription["items"])

        transcription_pii, _ = detect_and_tag_pii(
            transcription_formatted, False, nombre_fichero
        )

        speaker_segments = _format_items(transcription["items"], as_str=False)

        segments_pii = _pii_segments(speaker_segments, transcription_pii)

        if fec_proceso is None:
            try:
                fec_proceso = datetime.strptime(
                    transcription_job.split("_")[0], "%Y%m%d%H%M%S"
                )
            except:
                fec_proceso = datetime.now()

        return {
            "nombreFichero": nombre_fichero,
            "fec_proceso": fec_proceso.strftime("%Y-%m-%d %H:%M:%S"),
            "ind_diarization": True,
            "ind_pii": True,
            "fecha_ini_transcripcion": fecini_transcription.strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
            "fecha_fin_transcripcion": fecfin_transcription.strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
            "duracion_transcripcion": duracion_seconds,
            "transcripcion": transcription_raw,
            "segmentos_transcripcion": segments_pii,
            "lenguaje": transcription["language_code"],
            "transcripcion_formateada": transcription_pii,
        }

    except FileNotFoundError:
        _logger.error("El archivo no fue encontrado.")
    except IOError as e:
        _logger.error(f"Error de E/S: {e}")
    except Exception as e:
        _logger.error(f"Ocurrió un error inesperado: {e}")

    return None


def _process_transcription_items(
    transcription_items: List[Dict], as_str: bool = True
) -> Union[List[str], List[Dict]]:
    """
    Procesa los elementos de transcripción y los formatea según el formato solicitado.

    Parameters
    ----------
    transcription_items : List[Dict]
        Lista de elementos de transcripción de AWS Transcribe.
    as_str : bool, optional
        Si es True, devuelve un texto formateado.
        Si es False, devuelve una lista de diccionarios con información detallada de cada turno
        Por defecto: True.

    Returns
    -------
    Union[str, List[Dict]]
        Si as_str es True: string formateado con el formato "speakerX: texto | speakerY: texto | ..."
        Si as_str es False: Lista de diccionarios con información detallada de cada turno "['speaker': 'speakerX', 'text': 'texto', 'start_time': 0.0, 'end_time': 1.5]"

    """

    output = []
    current_channel = None
    current_phrase = []
    current_start_time = None
    current_end_time = None

    for item in transcription_items:
        channel = item.get("channel_label")
        alternatives = item.get("alternatives", [])
        item_type = item.get("type")

        if not alternatives:
            continue

        text = alternatives[0].get("content", "")
        start_time = float(item.get("start_time", 0))
        end_time = float(item.get("end_time", 0))

        # Manejo de redacciones de información personal
        if text == "[PII]" and "redactions" in alternatives[0]:
            text = f"[{alternatives[0]['redactions'][0]['type']}]"

        # Iniciar nuevo turno de hablante
        if (current_channel != channel and current_channel is not None) or (
            current_end_time and start_time - current_end_time > 5
        ):
            if as_str:
                output.append(
                    f"speaker{current_channel[-1]}: {' '.join(current_phrase).strip()}"
                )
            else:
                output.append(
                    {
                        "speaker": f"speaker{current_channel[-1]}",
                        "text": " ".join(current_phrase).strip(),
                        "start_time": current_start_time,
                        "end_time": current_end_time,
                    }
                )

            current_phrase = []
            current_start_time = None
            current_end_time = None

        # Actualizar tiempos
        if current_start_time is None:
            current_start_time = start_time

        if current_end_time is None:
            current_end_time = end_time

        # Añadir texto basado en el tipo
        if item_type == "punctuation":
            if current_phrase:
                current_phrase[-1] = current_phrase[-1] + text
        else:
            current_end_time = end_time
            current_phrase.append(text)

        current_channel = channel

    # Añadir frase final
    if current_phrase and current_channel:
        if as_str:
            output.append(
                f"speaker{current_channel[-1]}: {' '.join(current_phrase).strip()}"
            )
        else:
            output.append(
                {
                    "speaker": f"speaker{current_channel[-1]}",
                    "text": " ".join(current_phrase).strip(),
                    "start_time": current_start_time,
                    "end_time": current_end_time,
                }
            )

    # Convertir a string si se requiere formato de texto
    if as_str:
        output = " | ".join(output)

    return output


def _format_items(
    transcription_items: List[Dict], as_str: bool = True
) -> Union[str, List[Dict]]:
    """
    Formatea los elementos de transcripción en texto o lista de segmentos.

    Parameters
    ----------
    transcription_items : List[Dict]
        Lista de elementos de transcripción de AWS Transcribe.

    as_str : bool, optional
        Si es True, devuelve un texto formateado.
        Si es False, devuelve una lista de diccionarios con información detallada de cada turno
        Por defecto: True.

    Returns
    -------
    Union[str, List[Dict]]
        Lista de diccionarios con información detallada de cada turno de hablante o texto formateado.

    Examples
    --------
    >>> items = [...]  # Elementos de transcripción de AWS
    >>> segments = _format_items(items, as_str=False)
    >>> print(segments)
    [{'speaker': 'speaker0', 'text': 'Primera frase', 'start_time': 0.0, 'end_time': 1.5}, ...]
    >>> text = _format_items(items, as_str=True)
    >>> print(text)
    speaker0: Primera frase | speaker1: Segunda frase
    """
    df_items = (
        pd.DataFrame(transcription_items)
        .assign(
            end_time=lambda x: x["end_time"].ffill(),
            is_punctuation=lambda x: x["type"] == "punctuation",
            start_time=lambda x: x.apply(
                lambda row: float(
                    row["end_time"] if row["is_punctuation"] else row["start_time"]
                ),
                axis=1,
            ),
        )
        .sort_values(by="start_time", ascending=True)
        .query(
            "~(is_punctuation) | ((is_punctuation) & (channel_label == channel_label.shift(1)))"
        )
    )

    transcription_items = df_items.to_dict(orient="records")
    return _process_transcription_items(transcription_items, as_str=as_str)


def _pii_segments(speaker_segments: List[Dict], transcription_pii: str) -> List[Dict]:
    """
    Los segmentos de transcripción se actualizan eliminando el texto que contiene información personal.

    Parameters
    ----------
    speaker_segments : List[Dict]
        Lista de diccionarios con información detallada de cada turno de hablante.

    transcription_pii : str
        Transcripción formateada con etiquetas PII.

    Returns
    -------
    List[Dict]
        Lista de diccionarios con información detallada de cada turno de hablante.

    Examples
    --------
    >>> speaker_segments = [...]  # Lista de diccionarios con información detallada de cada turno de hablante.
    >>> transcription_pii = [...]  # Lista de diccionarios con información detallada de cada segmento de transcripción que contiene información personal.
    >>> segments_pii = _pii_segments(speaker_segments, transcription_pii)
    >>> print(segments_pii)
    [{'speaker': 'speaker0', 'text': 'Mi dni es [DNI_A]', 'start_time': 0.0, 'end_time': 1.5}, ...]
    """

    transcription_segments = transcription_pii.split(" | ")
    segments_text = []
    for segment in transcription_segments:
        # Extract only the text part after the speaker identifier (e.g. "speaker0: ")
        colon_index = segment.find(": ")
        if colon_index != -1:
            segments_text.append(segment[colon_index + 2 :])

    # Modificar los speaker_segments con los textos de los segmentos de transcripción
    for segment in speaker_segments:
        segment["text"] = segments_text[speaker_segments.index(segment)]

    return speaker_segments
