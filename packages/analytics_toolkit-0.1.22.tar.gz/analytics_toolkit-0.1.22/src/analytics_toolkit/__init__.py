"""
Analytics Toolkit: Herramientas Avanzadas de IA Generativa
==========================================================

Una biblioteca integral que simplifica y potencia flujos de trabajo
de análisis de datos mediante tecnologías de inteligencia artificial.

Características Principales
--------------------------
1. Procesamiento de Lenguaje Natural
   - Análisis de texto con modelos de lenguaje avanzados (GPT-4, etc.)
   - Soporte para múltiples servicios (NFQ, AEGON)
   - Configuración flexible de prompts
   - Análisis síncrono y asíncrono
   - Extracción de información estructurada

2. Transcripción de Audio Inteligente
   - Transcripción con AWS Transcribe
   - Diarización de altavoces
   - Redacción de información personal (PII)
   - Soporte para múltiples formatos de audio
   - Identificación de idiomas

3. Gestión de Configuraciones
   - Carga de configuraciones desde archivos locales y S3
   - Soporte para múltiples entornos (PROD, NONPROD)
   - Manejo seguro de credenciales
   - Configuración dinámica de parámetros

4. Conexiones de Datos
   - Conexión simplificada a Amazon Redshift
   - Ejecución de consultas SQL
   - Conversión automática a DataFrames
   - Manejo de errores y logging

5. Comunicación y Reporting
   - Envío de correos electrónicos personalizados
   - Adjuntos de DataFrames
   - Soporte para múltiples destinatarios
   - Formateo HTML de contenido

6. Logging y Monitoreo
   - Configuración flexible de logging
   - Soporte para múltiples niveles de verbosidad
   - Registro en archivo y consola
   - Control de logs para bibliotecas externas

7. Almacenamiento y Trazabilidad
   - Almacenamiento de resultados en Amazon S3
   - Trazabilidad de llamadas a modelos de lenguaje
   - Registro de métricas de uso (tokens, precio)
   - Gestión de historial de análisis

Ejemplo de Uso Integral
----------------------
```python
from analytics_toolkit import (
    PromptsConfig,
    llm_call,
    RedshiftConnect,
    S3Storage,
    send_emails,
    Configuration
)
import pandas as pd

# Cargar configuración
config = Configuration.from_s3('mi-bucket', 'config/config.ini')

# Conexión a Redshift
conn = RedshiftConnect.from_analytics()
df_datos = conn.query("SELECT * FROM mi_tabla")

# Configurar análisis de texto
prompts = PromptsConfig(
    context="Eres un analista experto",
    prompt="Resume el siguiente texto"
)

# Realizar análisis con LLM
resultados = llm_call(
    analysis_info=df_datos,
    id_field='id',
    analysis_field='texto',
    prompts_config=prompts,
    process='resumen',
    service='nfq',
    storage_config=S3Storage('mi-bucket', 'resultados/')
)

# Enviar resultados por email
send_emails(
    subject="Informe de Análisis",
    body="Adjunto los resultados del análisis",
    recipients=["usuario@ejemplo.com"],
    files={"resultados.csv": pd.DataFrame(resultados)}
)
```

Beneficios
----------
- Simplificación de flujos de análisis
- Integración de múltiples servicios de IA
- Manejo seguro de datos y credenciales
- Alta flexibilidad y configurabilidad
- Soporte para diversos casos de uso

Dependencias Principales
-----------------------
- pandas: Manipulación de datos
- boto3: Interacción con AWS
- openai: Modelos de lenguaje
- psycopg2: Conexiones a bases de datos

Versión: 0.1.22
Autor: Equipo de Desarrollo de Analytics Toolkit
Licencia: Uso interno
"""

import warnings

warnings.filterwarnings("ignore", category=UserWarning)

__version__ = "0.1.22"
