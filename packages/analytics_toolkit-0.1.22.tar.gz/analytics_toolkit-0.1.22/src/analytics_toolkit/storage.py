"""
Módulo de Almacenamiento en Amazon S3 para Analytics Toolkit

Este módulo proporciona una solución flexible y robusta para el almacenamiento
y recuperación de datos en Amazon S3, específicamente optimizado para el manejo
de DataFrames de análisis de datos.

Características principales:
- Almacenamiento de DataFrames en buckets de S3
- Recuperación de históricos de análisis
- Generación automática de rutas de archivos
- Manejo de archivos con separadores personalizados
- Soporte para múltiples formatos de datos

Clase principal:
- S3Storage: Gestiona todas las operaciones de almacenamiento y recuperación

Ejemplo de uso básico:
```python
from analytics_toolkit.storage import S3Storage
import pandas as pd

# Crear una instancia de almacenamiento S3
storage = S3Storage(
    bucket='mi-bucket',
    path='resultados/analisis',
    file_name='datos_procesados'
)

# Crear un DataFrame de ejemplo
df = pd.DataFrame({
    'id': [1, 2, 3],
    'valor': ['a', 'b', 'c']
})

# Subir el DataFrame a S3
storage.upload_df(df)

# Recuperar el historial
historial = storage.get_history('id')
print(historial)
```

Configuraciones avanzadas:
- Personalización de rutas de archivos
- Manejo de fechas específicas
- Separadores de archivos personalizados

Dependencias:
- boto3: Interacción con servicios de Amazon S3
- pandas: Manipulación de DataFrames
- botocore: Manejo de excepciones de AWS

Consideraciones:
- Requiere configuración adecuada de credenciales de AWS
- Todas las operaciones se realizan con separador '#'
- Las columnas se convierten a tipo objeto para flexibilidad

Patrones de uso:
- Ideal para almacenar resultados de análisis
- Útil para mantener históricos de procesamiento
- Permite fácil integración con otros componentes de Analytics Toolkit

Manejo de errores:
- Registro automático de errores de almacenamiento
- Creación automática de archivos si no existen
- Flexibilidad en el manejo de archivos inexistentes
"""

import boto3
import pandas as pd
import botocore.exceptions

from datetime import datetime
from typing import Optional
from ._shared import _logger

__all__ = ["S3Storage"]


class S3Storage:
    """
    Clase para gestionar el almacenamiento y recuperación de resultados en Amazon S3.

    Proporciona funcionalidades para cargar DataFrames en S3, recuperar
    históricos de análisis y manejar rutas de archivos de manera flexible.

    Attributes
    ----------
    bucket : str
        Nombre del bucket de S3 donde se almacenarán los resultados.

    path : str
        Ruta dentro del bucket donde se guardarán los archivos.

    file_name : str
        Nombre base del archivo para almacenar los resultados.

    date : datetime
        Fecha y hora de registro de los datos.
        Por defecto es la fecha y hora actual.

    s3_path : str
        Ruta completa del archivo en S3, generada automáticamente.

    Methods
    -------
    upload_df(df: pd.DataFrame)
        Sube un DataFrame a S3 en la ruta especificada.

    get_history(id_field: str)
        Recupera el historial de análisis para un campo de identificación.

    Notes
    -----
    - Utiliza boto3 para interacciones con Amazon S3
    - Maneja automáticamente la generación de rutas de archivos
    - Proporciona logging para operaciones de almacenamiento
    """

    def __init__(
        self, bucket: str, path: str, file_name: str, date: Optional[datetime] = None
    ):
        """
        Inicializa una nueva configuración de almacenamiento S3.

        Parameters
        ----------
        bucket : str
            Nombre del bucket de S3 donde se almacenarán los resultados.
            Debe ser un bucket válido y accesible.

        path : str
            Ruta dentro del bucket donde se guardarán los archivos.
            Se eliminan las barras iniciales y finales para normalizar la ruta.

        file_name : str
            Nombre base del archivo para almacenar los resultados.
            Se utilizará para generar el nombre del archivo CSV.

        date : datetime, optional
            Fecha y hora de registro de los datos.
            Si no se especifica, se usa la fecha y hora actual.
            Por defecto es None.

        Examples
        --------
        Crear una instancia de S3Storage:
        >>> storage = S3Storage(
        ...     bucket='mi-bucket',
        ...     path='resultados/analisis',
        ...     file_name='datos_procesados'
        ... )

        Crear una instancia con una fecha específica:
        >>> from datetime import datetime
        >>> fecha_especifica = datetime(2024, 1, 15)
        >>> storage = S3Storage(
        ...     bucket='mi-bucket',
        ...     path='resultados/analisis',
        ...     file_name='datos_procesados',
        ...     date=fecha_especifica
        ... )

        Notes
        -----
        - La ruta del archivo se genera automáticamente
        - Se utiliza el formato YYYYMMDD en la ruta del archivo
        - El separador de archivo es '#' para mayor compatibilidad
        """
        self.bucket = bucket
        self.path = path.strip("/")
        self.file_name = file_name
        self.date = date or datetime.now()
        self.s3_path = f"s3://{self.bucket}/{self.path}/{self.file_name}/{self.date.strftime('%Y%m%d')}_{self.file_name}.csv"

    def upload_df(self, df: pd.DataFrame) -> None:
        """
        Sube un DataFrame a S3 en la ruta especificada.

        Parameters
        ----------
        df : pandas.DataFrame
            DataFrame que se desea subir al almacenamiento S3.


        Examples
        --------
        Subir un DataFrame a S3:
        >>> import pandas as pd
        >>> storage = S3Storage('mi-bucket', 'resultados', 'datos')
        >>> df = pd.DataFrame({'columna1': [1, 2, 3], 'columna2': ['a', 'b', 'c']})
        >>> storage.upload_df(df)

        Notes
        -----
        - Utiliza separador '#' para mayor compatibilidad
        - Sin índice para mantener la estructura original del DataFrame
        - Maneja errores y registra cualquier problema de carga
        """
        try:
            df.to_csv(
                self.s3_path,
                sep="#",
                index=False,
                mode="w",
                lineterminator="\n",
            )
        except Exception as e:
            _logger.error(f"Error al guardar el archivo en S3: {e}")

    def get_history(self, id_field: str) -> pd.DataFrame:
        """
        Recupera el historial de los archivos de análisis en una fecha específica.
        Si el archivo no existe, se crea uno nuevo con solo la columna de identificación.

        Parameters
        ----------
        id_field : str
            La columna de identificación del proceso.
            Se utiliza para crear el DataFrame si no existe.

        Returns
        -------
        pandas.DataFrame
            El historial del archivo de análisis en la fecha especificada.
            Si no existe, se devuelve un DataFrame vacío con la columna de identificación.

        Examples
        --------
        Recuperar historial de análisis:
        >>> storage = S3Storage('mi-bucket', 'resultados', 'datos')
        >>> historial = storage.get_history('id_documento')
        >>> print(historial)

        Notes
        -----
        - Utiliza boto3 para operaciones con S3
        - Maneja automáticamente la creación de archivos
        - Lee archivos con separador '#'
        - Convierte todas las columnas a tipo objeto para flexibilidad
        """
        # Cliente S3 para realizar operaciones de entrada/salida
        _s3 = boto3.client("s3")

        file_path = f"{self.path}/{self.file_name}"
        file_key = f"{file_path}/{self.date.strftime('%Y%m%d')}_{self.file_name}.csv"

        try:
            # Verificar si el archivo existe
            _s3.head_object(Bucket=self.bucket, Key=file_key)

            # Retornar archivo existente
            return pd.read_csv(
                self.s3_path,
                delimiter="#",
                dtype=object,
            )

        except botocore.exceptions.ClientError as e:
            if e.response["Error"]["Code"] == "404":
                # Archivo no encontrado, crear uno nuevo
                _logger.debug(
                    f"El archivo histórico {self.file_name} no existe en el bucket. "
                    "Se crea el fichero solo con la cabecera."
                )
                df_analyzed = pd.DataFrame(columns=[id_field])

                # Guardar DataFrame vacío
                df_analyzed.to_csv(
                    self.s3_path,
                    sep="#",
                    index=False,
                    mode="w",
                )

                return df_analyzed
            else:
                # Otro tipo de error de S3
                _logger.error(f"Ha ocurrido un error al acceder al archivo: {e}")
