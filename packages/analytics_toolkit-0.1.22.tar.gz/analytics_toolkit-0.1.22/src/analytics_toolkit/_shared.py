from .logger import Logger
from .config import Configuration
from .aws import RedshiftConnect
import os


__all__ = []


# Logger
_logger = Logger("analytics_toolkit").get_logger()

_environment = os.environ.get("ENVIRONMENT", "PROD")

if _environment == "PROD":
    _s3_bucket = "aeg-spain-analyticspl-sagemaker-prd-master"
else:
    _s3_bucket = "aeg-spain-analyticspl-sagemaker-acc-master"

# Archivo de configuración
_config = Configuration.from_s3(
    _s3_bucket,
    "utilidades-ia-generativa/configurationEnviroment.ini",
)

# Configuracion de Redshift
_rs_connection = RedshiftConnect(
    dbname=_config["rs_dbname"],
    host=_config["rs_host"],
    port=_config["rs_port"],
    user=_config["rs_user"],
    password=_config["rs_password"],
)
