# Analytics Toolkit: Herramientas Avanzadas de IA Generativa

## Versión

Versión actual: 0.1.22

## Descripción

Analytics Toolkit es una biblioteca integral que simplifica y potencia flujos de trabajo de análisis de datos mediante tecnologías de inteligencia artificial. Ofrece herramientas avanzadas para procesamiento de lenguaje natural, transcripción de audio, gestión de configuraciones, conexiones de datos, comunicación y reporting.

## Características Principales

- 🤖 **Procesamiento de Lenguaje Natural**
  - Análisis de texto con modelos LLM
  - Soporte para múltiples servicios (NFQ, AEGON)
  - Análisis síncrono y asíncrono

- 🎙️ **Transcripción de Audio Inteligente**
  - Transcripción con AWS Transcribe
  - Diarización de hablantes
  - Redacción de información personal (PII)

- ⚙️ **Gestión de Configuraciones**
  - Carga de configuraciones desde archivos locales y S3
  - Soporte para múltiples entornos

- 💾 **Conexiones de Datos**
  - Conexión simplificada a Amazon Redshift
  - Ejecución de consultas SQL
  - Conversión automática a DataFrames

- 📧 **Comunicación y Reporting**
  - Envío de correos electrónicos personalizados
  - Adjuntos de DataFrames
  - Gestion simplificada de logs

## Instalación

### Instalación desde Test PyPI

```bash
pip install -i https://test.pypi.org/simple/ analytics-toolkit
```

## Ejemplo de Uso

```python
from analytics_toolkit import (
    PromptsConfig, 
    llm_call, 
    RedshiftConnect, 
    S3Storage, 
    send_emails,
    Configuration
)
import pandas as pd

# Cargar configuración
config = Configuration.from_s3('mi-bucket', 'config/config.ini')

# Conexión a Redshift
conn = RedshiftConnect.from_analytics()
df_datos = conn.query("SELECT * FROM mi_tabla")

# Configurar análisis de texto
prompts = PromptsConfig(
    context="Eres un analista experto",
    prompt="Resume el siguiente texto"
)

# Realizar análisis con LLM
resultados = llm_call(
    analysis_info=df_datos,
    id_field='id',
    analysis_field='texto',
    prompts_config=prompts,
    process='resumen',
    service='nfq',
    storage_config=S3Storage('mi-bucket', 'resultados/')
)

# Enviar resultados por email
send_emails(
    subject="Informe de Análisis",
    body="Adjunto los resultados del análisis",
    recipients=["usuario@ejemplo.com"],
    files={"resultados.csv": pd.DataFrame(resultados)}
)
```

## Contribución

### Configuración del Entorno de Desarrollo

1. Clonar el repositorio

```bash
git clone https://git-codecommit.eu-west-1.amazonaws.com/v1/repos/aeg-backend-analytics-utilidades-ia-generativa
cd aeg-backend-analytics-utilidades-ia-generativa
```

2. Crear un entorno virtual

```bash
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
```

3. Instalar en modo editable

```bash
pip install -e .[dev]
```

### Guía de Contribución

- Sigue las guías de estilo PEP 8
- Escribe docstrings detallados
- Incluye pruebas para nuevas funcionalidades
- Actualiza la documentación

### Proceso de Contribución

1. Realiza tus cambios
2. Ejecuta pruebas

```bash
python -m pytest
```

3. Commit y push
4. Crear un Pull Request

### Publicación (Para Mantenedores)

1. Configurar credenciales de TestPyPI

Primero, genera un token de acceso en TestPyPI:

- Visita <https://test.pypi.org/manage/account/token/>
- Crea un nuevo token con permisos de carga
- Copia el token generado

Luego, configura tus credenciales:

```bash
# Crear o editar el archivo ~/.pypirc
nano ~/.pypirc
```

Añade el siguiente contenido:

```ini
[testpypi]
username = __token__
password = tu_token_generado_aqui
```

2. Construir el paquete

```bash
python -m build
```

3. Publicar en Test PyPI

```bash
python -m twine upload --repository testpypi dist/*
```

Notas importantes:

- Protege tu token de acceso, no lo compartas públicamente
- Usa variables de entorno para mayor seguridad si es posible

## Dependencias

botocore==1.34.113
boto3==1.34.113
pandas==2.2.2
psycopg2==2.9.9
aiohttp==3.9.5
openai==1.65.2
s3fs==2024.6.1
s3transfer==0.10.1
requests==2.32.2
number_parser==0.3.2

## Licencia

[Licencia de Uso Interno de Aegon España](LICENSE)

Uso interno - Todos los derechos reservados

Consulte el archivo [LICENSE](LICENSE) para obtener más detalles sobre las restricciones de uso y términos de confidencialidad.

## Contacto

Para soporte o consultas, contactar con el Equipo de Desarrollo de Analytics Toolkit.

- Eric Martin Garcia (<eric.martingarcia@aegon.es>)
- David Adrian Garcia (<davidadrian.garciasantana@aegon.es>)
- Paula Genoves (<genoves.paula@aegon.es>)
- Gonzalo Hernando (<gonzalo.hernando@aegon.es>)
- Javier Monjas (<javier.monjas@aegon.es>)

Repositorio: [Repositorio de CodeCommit](https://git-codecommit.eu-west-1.amazonaws.com/v1/repos/aeg-backend-analytics-utilidades-ia-generativa)

