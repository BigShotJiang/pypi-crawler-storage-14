# Examples

```{toctree}
:maxdepth: 1
:caption: Examples

Backend comparison/backend_comparison
Patient-specific mapping of fundus photographs to three-dimensional ocular imaging/raytracing
Direct modification of the optical system in OpticStudio/direct_opticstudio_access
```