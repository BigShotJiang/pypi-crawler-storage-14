# nc_db/db/queries.py
from typing import Any

from psycopg import sql


def insert(schema: str, table: str):
    """
    One-shot insert that:
      1) reserves next id from the table's sequence
      2) inserts (id, body_with_id)
      3) returns the id
    """
    seq_lit = sql.Literal(f"{schema}.{table}_id_seq")  # e.g. nc_test_abc.scg_id_seq

    return sql.SQL("""
                   WITH new_id AS (SELECT nextval({seq}::regclass) AS id),
                        ins AS (
                   INSERT
                   INTO {sch}.{tbl} (id, body)
                   SELECT id,
                          jsonb_set(%s::jsonb, '{{id}}', to_jsonb(id))
                   FROM new_id RETURNING id
        )
                   SELECT id
                   FROM ins;
                   """).format(
        sch=sql.Identifier(schema),
        tbl=sql.Identifier(table),
        seq=seq_lit,
    )

def search(schema: str, table: str):
    """
    Build a SQL query that will search inside the JSONB 'body' column.

    BOTH are parameterized:
      - the JSON key (property_name)
      - the value
    so this function only cares about schema + table.
    """
    return sql.SQL("""
    SELECT id, body FROM {}.{} 
    WHERE body #>> %s::text[] = %s
    ORDER BY id; 
    """).format(
        sql.Identifier(schema),
        sql.Identifier(table),
    )


def update_merge(schema: str, table: str):
    """
    Batch-update: merge each JSON patch into existing body.
    - Input params: (%s::bigint[], %s::jsonb[])
    - Always sets body.id = row id
    - Returns: updated ids
    """
    return sql.SQL("""
                   WITH u AS (SELECT unnest(%s::bigint[]) AS id,
                                     unnest(%s::jsonb[])  AS patch)
                   UPDATE {sch}.{tbl} AS t
                   SET body = jsonb_set( t.body || u.patch, '{{id}}', to_jsonb(u.id), true )
                   FROM u
                   WHERE t.id = u.id
                       RETURNING t.id;
                   """).format(
        sch=sql.Identifier(schema),
        tbl=sql.Identifier(table),
    )


def update_replace(schema: str, table: str):
    """
    Batch-update: replace body entirely with the provided JSON.
    - Input params: (%s::bigint[], %s::jsonb[])
    - Always sets body.id = row id
    - Returns: updated ids
    """
    return sql.SQL("""
                   WITH u AS (SELECT unnest(%s::bigint[]) AS id,
                                     unnest(%s::jsonb[])  AS new_body)
                   UPDATE {sch}.{tbl} AS t
                   SET body = jsonb_set( u.new_body, '{{id}}', to_jsonb(u.id), true )
                   FROM u
                   WHERE t.id = u.id
                       RETURNING t.id;
                   """).format(
        sch=sql.Identifier(schema),
        tbl=sql.Identifier(table),
    )


def insert_with_id(schema: str, table: str):
    """
    Insert row with explicit client-provided id.
    Body should already contain the same id (or we'll add it in Python).
    Returns that id.
    """
    return sql.SQL("""
                   INSERT INTO {sch}.{tbl} (id, body)
                   VALUES (%s, %s::jsonb)
                       RETURNING id;
                   """).format(
        sch=sql.Identifier(schema),
        tbl=sql.Identifier(table),
    )


def select_all(schema: str, table: str):
    return sql.SQL("SELECT id, body FROM {}.{} ORDER BY id;").format(
        sql.Identifier(schema), sql.Identifier(table)
    )


def select_by_ids(schema: str, table: str):
    return sql.SQL("""
                   SELECT id, body
                   FROM {}.{}
                   WHERE id = ANY (%s::bigint[])
                   ORDER BY id;
                   """).format(sql.Identifier(schema), sql.Identifier(table))


def delete_by_ids(schema: str, table: str):
    return sql.SQL("""
                   DELETE
                   FROM {}.{}
                   WHERE id = ANY (%s::bigint[])
                       RETURNING id;
                   """).format(sql.Identifier(schema), sql.Identifier(table))


def delete_all(schema: str, table: str):
    return sql.SQL("DELETE FROM {}.{} RETURNING id;").format(
        sql.Identifier(schema), sql.Identifier(table)
    )


def truncate_restart(schema: str, table: str):
    return sql.SQL("TRUNCATE {}.{} RESTART IDENTITY CASCADE;").format(
        sql.Identifier(schema), sql.Identifier(table)
    )


GET_TABLE_LIST = """
                 SELECT table_name
                 FROM information_schema.tables
                 WHERE table_schema = %(schema)s
                   AND table_type = 'BASE TABLE';
                 """
