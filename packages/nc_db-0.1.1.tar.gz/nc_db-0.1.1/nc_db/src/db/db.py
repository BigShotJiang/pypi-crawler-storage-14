# nc_db/db/db.py
import json
import os
from typing import Any, Callable, Dict, List, Optional, Set, Type, TypeVar, overload, Union

from psycopg import IntegrityError
from psycopg.errors import UniqueViolation

from nc_db.src.db import queries
from nc_db.src.db.DbConfig import DbConfig

T = TypeVar("T")


class Db:
    def __init__(self, schema: str = "nc", config: Optional[DbConfig] = None):
        self.schema = schema
        self.config = config or DbConfig(
            user=os.getenv("PGUSER", "nc_admin"),
            password=os.getenv("PGPASSWORD", "bob"),
            host=os.getenv("PGHOST", "localhost"),
            port=int(os.getenv("PGPORT", 5432)),
            dbname=os.getenv("PGDATABASE", "nc-data"),
        )

        # cache available tables so we can validate
        with self.config.get_connection() as con:
            with con.cursor() as cur:
                cur.execute(queries.GET_TABLE_LIST, {"schema": schema})
                self.table_set = {row[0].lower() for row in cur.fetchall()}

    def _assert_table(self, table: str) -> str:
        t = table.lower()
        if t not in self.table_set:
            # Refresh once to account for tables created after init
            self.refresh_tables()
            if t not in self.table_set:
                raise ValueError(f"Unknown table '{table}'. Options: {sorted(self.table_set)}")
        return t

    def refresh_tables(self) -> None:
        """
        Reload the known table list from information_schema for this schema.
        Use this after creating tables at runtime so validation stays fresh.
        """
        with self.config.get_connection() as con:
            with con.cursor() as cur:
                cur.execute(queries.GET_TABLE_LIST, {"schema": self.schema})
                rows = cur.fetchall()
        self.table_set = {row[0].lower() for row in rows}

    # ---------- INSERT (trust optional id) ----------
    def insert(self, table: str, item: Dict[str, Any]) -> int:
        """
        Insert a row into `table` using:
          item = {"body": <dict or JSON-string>, optional "id": <int>}
        If 'id' exists in body (or top-level), trust it and insert with that id.
        Otherwise insert without id and let the sequence assign it.
        Returns the inserted id.
        """
        table = self._assert_table(table)

        if not isinstance(item, dict) or "body" not in item:
            raise TypeError("insert() expects a dict with a 'body' key")

        raw_body = item["body"]
        if isinstance(raw_body, str):
            body = json.loads(raw_body)
        elif isinstance(raw_body, dict):
            body = dict(raw_body)
        else:
            raise TypeError("'body' must be a dict or JSON string")

        # id can come from body['id'] or top-level item['id']
        provided_id = item.get("id", body.get("id"))
        if provided_id is not None and not isinstance(provided_id, int):
            raise TypeError("'id' (if provided) must be an integer")

        with self.config.get_connection() as con:
            with con.cursor() as cur:
                if provided_id is not None:
                    # Trust client id: ensure body contains it and insert explicitly
                    body["id"] = provided_id
                    try:
                        cur.execute(
                            queries.insert_with_id(self.schema, table),
                            (provided_id, json.dumps(body)),
                        )
                    except UniqueViolation as e:
                        raise ValueError(f"Duplicate id {provided_id}") from e
                    except IntegrityError as e:
                        # Fallback for other integrity errors
                        raise ValueError(f"Insert failed for explicit id={provided_id}: {e}") from e
                    new_id = cur.fetchone()[0]
                else:
                    # No client id: let DB reserve next id and jsonb_set it via helper
                    cur.execute(queries.insert(self.schema, table), (json.dumps(body),))
                    new_id = cur.fetchone()[0]

            con.commit()

        return int(new_id)

    # def search(self, cls: Type[T], property_name: str, value: Any) -> List[T]:
    #     if hasattr(cls, property_name):
    #         result = self.db.search(where(property_name) == value)
    #         return self._convert_to_class(cls, result)
    #     else:
    #         raise Exception("db.search was requested on a property that doesn't exist on the class")

    def search(
            self,
            cls: Type[T],
            table: str,
            property_path: str,
            value: Any,
    ) -> List[T]:
        """
        Search for rows where body[...] == value, where body is JSONB.

        `property_path` must point to a top-level JSON key (e.g. "name").
        """
        table = self._assert_table(table)

        field_name = property_path
        self._ensure_model_field(cls, field_name)
        field_names = self._get_model_field_names(cls)

        with self.config.get_connection() as con:
            with con.cursor() as cur:
                query = queries.search(self.schema, table)
                cur.execute(query, ([field_name], str(value)))
                rows = cur.fetchall()

        results: List[T] = []

        for id_, body in rows:
            if isinstance(body, str):
                body = json.loads(body)

            materialized = dict(body)
            materialized["id"] = int(id_)

            if field_names:
                payload = {name: materialized.get(name) for name in field_names}
                if "id" not in payload:
                    payload["id"] = materialized["id"]
            else:
                payload = dict(materialized)

            obj = self._instantiate_model(cls, payload)
            results.append(obj)

        return results


    def update(self, table: str, ids: List[int], items: List[Dict[str, Any]], *, mode: str = "merge") -> List[int]:
        """
        Batch update rows in `table` with JSON bodies.

        Args:
          table: validated table name (must have columns id, body jsonb)
          ids: list of row ids to update; if empty, derived from items[*].id or items[*]['body'].id
          items: list of objects; each must contain a JSON body:
                 - either {"body": <dict or JSON-string>, optional "id": <int>}
                 - or a raw {"id": <int>, ...} to treat as full body (we'll store it under body)
          mode: "merge" (default) or "replace"
                - merge: body := jsonb_set(old_body || patch, '{id}', id)
                - replace: body := jsonb_set(new_body, '{id}', id)

        Returns:
          List[int]: ids that were updated (in DB return order)
        """
        table = self._assert_table(table)

        if not items:
            return []

        # Normalize items -> (id, body_dict)
        norm_ids: List[int] = []
        bodies: List[Dict[str, Any]] = []

        if ids:
            if len(ids) != len(items):
                raise ValueError("len(ids) must match len(items) when ids are provided.")

        for it in items:
            if not isinstance(it, dict):
                raise TypeError("Each item must be a dict")

            # Determine raw body
            raw_body = it.get("body", it)  # accept either {"body": {...}} or treat whole item as body
            if isinstance(raw_body, str):
                body = json.loads(raw_body)
            elif isinstance(raw_body, dict):
                body = dict(raw_body)
            else:
                raise TypeError("'body' must be a dict or JSON string (or item must be a dict body)")

            # Determine id precedence: explicit ids param > item['id'] > body['id']
            if ids:
                row_id = ids[len(norm_ids)]
            else:
                cand = it.get("id", body.get("id"))
                if cand is None:
                    raise ValueError("Missing id: supply ids[] aligned with items or include id in each item/body")
                if not isinstance(cand, int):
                    raise TypeError("id must be an integer")
                row_id = int(cand)

            norm_ids.append(row_id)
            # Don't set body["id"] here; the SQL enforces it on write.
            bodies.append(body)

        # psycopg will adapt python lists into arrays; we add explicit casts in SQL (%s::bigint[], %s::jsonb[])
        jsonb_array = [json.dumps(b) for b in bodies]

        with self.config.get_connection() as con:
            with con.cursor() as cur:
                if mode == "replace":
                    cur.execute(queries.update_replace(self.schema, table), (norm_ids, jsonb_array))
                else:
                    cur.execute(queries.update_merge(self.schema, table), (norm_ids, jsonb_array))
                updated = [row[0] for row in cur.fetchall()]
            con.commit()

        return [int(x) for x in updated]

    # ---------- SELECT ----------
    @overload
    def get(
            self,
            table: str,
            ids: Optional[List[int]] = None,
    ) -> List[Dict[str, Any]]:
        ...

    @overload
    def get(
            self,
            table: str,
            ids: Optional[List[int]] = None,
            *,
            mapper: Callable[[int, dict], T],
    ) -> List[T]:
        ...

    def get(
            self,
            table: str,
            ids: Optional[List[int]] = None,
            mapper: Optional[Callable[[int, dict], T]] = None,
    ) -> Union[List[Dict[str, Any]], List[T]]:
        """
        Return rows from any table.
        - If mapper is provided: map (id, body_dict) -> model instance.
        - Else: return dicts like {"id": ..., "body": {...}}
        """
        table = self._assert_table(table)

        with self.config.get_connection() as con:
            with con.cursor() as cur:
                if ids is None:
                    cur.execute(queries.select_all(self.schema, table))
                else:
                    if not ids:
                        return []  # empty fast-path
                    cur.execute(queries.select_by_ids(self.schema, table), (ids,))
                rows = cur.fetchall()

        results = []
        for id_, body in rows:
            if isinstance(body, str):
                body = json.loads(body)
            # ensure body id always matches the row id on read
            body["id"] = int(id_)
            if mapper:
                results.append(mapper(int(id_), body))
            else:
                results.append({"id": int(id_), "body": body})
        return results

    # ---------- DELETE ----------
    def delete(self, table: str, ids: List[int]) -> List[int]:
        table = self._assert_table(table)
        if not ids:
            return []
        with self.config.get_connection() as con:
            with con.cursor() as cur:
                cur.execute(queries.delete_by_ids(self.schema, table), (ids,))
                deleted = [row[0] for row in cur.fetchall()]
            con.commit()
        return deleted

    def delete_all(self, table: str) -> List[int]:
        table = self._assert_table(table)
        with self.config.get_connection() as con:
            with con.cursor() as cur:
                cur.execute(queries.delete_all(self.schema, table))
                deleted = [row[0] for row in cur.fetchall()]
            con.commit()
        return deleted

    def truncate_restart_identity(self, table: str) -> None:
        table = self._assert_table(table)
        with self.config.get_connection() as con:
            with con.cursor() as cur:
                cur.execute(queries.truncate_restart(self.schema, table))
            con.commit()

    # ---------- Helpers ----------
    def _instantiate_model(self, cls: Type[T], payload: Dict[str, Any]) -> T:
        if hasattr(cls, "model_validate"):
            return cls.model_validate(payload)  # type: ignore[attr-defined]
        return cls(**payload)  # type: ignore[arg-type]

    def _ensure_model_field(self, cls: Type[Any], field_name: str) -> None:
        field_names = self._get_model_field_names(cls)
        if field_names and field_name not in field_names:
            raise AttributeError(
                f"db.search requested on '{field_name}', but that field "
                f"is not defined on class {cls.__name__}"
            )

    def _get_model_field_names(self, cls: Type[Any]) -> Set[str]:
        if hasattr(cls, "model_fields"):  # Pydantic v2
            return set(cls.model_fields.keys())  # type: ignore[attr-defined]

        annotations = getattr(cls, "__annotations__", {})
        return set(annotations.keys())
