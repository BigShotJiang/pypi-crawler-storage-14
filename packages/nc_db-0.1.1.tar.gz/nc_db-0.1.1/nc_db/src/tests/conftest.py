import pytest
import random
import string
from psycopg import sql

from nc_db.src.db.DbConfig import DbConfig



def _rand_suffix(n: int = 6) -> str:
    alphabet = string.ascii_lowercase + string.digits
    return "".join(random.choice(alphabet) for _ in range(n))


@pytest.fixture(scope="function")
def test_schema():
    """
    Create an isolated schema for tests and a minimal scg table.
    Dropped after the test.
    """
    config = DbConfig(
        user="nc_admin",
        password="bob",
        host="localhost",
        port=5432,
        dbname="nc-data",
    )

    schema = f"nc_test_{_rand_suffix()}"

    ddl = f"""
    CREATE SCHEMA IF NOT EXISTS {schema};

    CREATE TABLE IF NOT EXISTS {schema}.healthcheck
    (
        id int primary key,
        ok boolean
    );
    INSERT INTO {schema}.healthcheck (id, ok)
    VALUES (1, true)
    ON CONFLICT (id) DO NOTHING;

    CREATE TABLE IF NOT EXISTS {schema}.scg (
        id   BIGSERIAL PRIMARY KEY,
        body JSONB NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_{schema}_scg_body_gin
      ON {schema}.scg USING GIN (body);
    """

    # Open a fresh connection for setup
    with config.get_connection() as con:
        with con.cursor() as cur:
            cur.execute(ddl)
        con.commit()

    try:
        yield schema
    finally:
        # Open a fresh connection for teardown (don't reuse the old one)
        with config.get_connection() as con:
            with con.cursor() as cur:
                # Use identifiers to be extra safe
                cur.execute(
                    sql.SQL("DROP SCHEMA IF EXISTS {} CASCADE;")
                    .format(sql.Identifier(schema))
                )
            con.commit()
