# src/statsmodelp/snippets.py

SNIPPETS = {
    1: """import pandas as pd
df = pd.read_csv()
""",

    4: """import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error
from statsmodels.tsa.holtwinters import SimpleExpSmoothing, ExponentialSmoothing
import warnings
warnings.filterwarnings("ignore")
# LOAD DATA
# --------------------------------------------------
df = pd.read_csv("/content/AirPassengers - AirPassengers.csv", parse_dates=True, index_col='Month')
df.rename(columns={'#Passengers':'Passengers'}, inplace=True)
print(df.head())
# SIMPLE MOVING AVERAGE (SMA)
# --------------------------------------------------
def simple_moving_average(data, window):
    return data.rolling(window=window).mean()

window_size = 12
sma_values = simple_moving_average(df['Passengers'], window_size)

# PLOT SMA
plt.figure(figsize=(10,5))
plt.plot(df.index, df['Passengers'], label='Original', color='blue')
plt.plot(df.index, sma_values, label='SMA (12-month)', color='red')
plt.title("Simple Moving Average")
plt.legend()
plt.show()
# TRAIN TEST SPLIT
# --------------------------------------------------
train_size = int(len(df)*0.80)
train_data = df.iloc[:train_size]
test_data = df.iloc[train_size:]
print(train_data.shape, test_data.shape)
# TRAIN SMA
sma_train = simple_moving_average(train_data['Passengers'], window_size).dropna()

# TEST SMA: repeat last SMA value
last_sma = sma_train.iloc[-1]
sma_test = np.repeat(last_sma, len(test_data))

# METRICS FOR SMA
y_train_true = train_data['Passengers'].iloc[window_size-1:]  # correct alignment
y_train_pred = sma_train  # already aligned
print("\\n--- SMA Evaluation ---")
print("Train MAE:", mean_absolute_error(y_train_true, y_train_pred))
print("Train MSE:", mean_squared_error(y_train_true, y_train_pred))
print("Train RMSE:", np.sqrt(mean_squared_error(y_train_true, y_train_pred)))


print("\\nTest MAE:", mean_absolute_error(test_data['Passengers'], sma_test))
print("Test MSE:", mean_squared_error(test_data['Passengers'], sma_test))
print("Test RMSE:", np.sqrt(mean_squared_error(test_data['Passengers'], sma_test)))
# SIMPLE EXPONENTIAL SMOOTHING (SES)
# --------------------------------------------------
alpha = 0.5
ses_model = SimpleExpSmoothing(train_data['Passengers']).fit(smoothing_level=alpha)
ses_train_pred = ses_model.fittedvalues
ses_test_pred = ses_model.forecast(len(test_data))

print("\\n--- SES Evaluation ---")
print("Train MAE:", mean_absolute_error(train_data['Passengers'], ses_train_pred))
print("Test MAE:", mean_absolute_error(test_data['Passengers'], ses_test_pred))
# PLOT SES
plt.figure(figsize=(10,5))
plt.plot(train_data.index, train_data['Passengers'], label='Train', color='blue')
plt.plot(test_data.index, test_data['Passengers'], label='Test', color='green')
plt.plot(train_data.index, ses_train_pred, label='SES Train', color='red')
plt.plot(test_data.index, ses_test_pred, label='SES Test', color='orange')
plt.legend()
plt.title("Simple Exponential Smoothing")
plt.show()
# HOLT-WINTERS (Additive Trend + Multiplicative Seasonality)
# --------------------------------------------------
hw_model = ExponentialSmoothing(
    train_data['Passengers'],
    trend='add',
    seasonal='mul',
    seasonal_periods=12
).fit()

hw_train_pred = hw_model.fittedvalues
hw_test_pred = hw_model.forecast(len(test_data))

print("\\n--- Holt-Winters Evaluation ---")
print("Train MAE:", mean_absolute_error(train_data['Passengers'], hw_train_pred))
print("Test MAE:", mean_absolute_error(test_data['Passengers'], hw_test_pred))
# PLOT HW
plt.figure(figsize=(10,6))
plt.plot(train_data.index, train_data['Passengers'], label='Train', color='blue')
plt.plot(test_data.index, test_data['Passengers'], label='Test', color='green')
plt.plot(train_data.index, hw_train_pred, label='HW Train', color='red')
plt.plot(test_data.index, hw_test_pred, label='HW Test Forecast', color='orange')
plt.title("Holt-Winters Smoothing")
plt.legend()
plt.show()
""",
5:"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller, kpss
import warnings
warnings.filterwarnings("ignore")

# -------------------------------
# LOAD DATA
# -------------------------------
df = pd.read_csv("/content/AirPassengers - AirPassengers.csv",
                 parse_dates=True, index_col='Month')
df.rename(columns={'#Passengers': 'Passengers'}, inplace=True)

print(df.head())


# ============================================================
# i. GENERATE WHITE NOISE AND VISUALIZE
# ============================================================

np.random.seed(42)  # reproducibility
white_noise = np.random.normal(loc=0, scale=1, size=len(df))

plt.figure(figsize=(10, 4))
plt.plot(df.index, white_noise, color='purple')
plt.title("White Noise Sequence")
plt.xlabel("Time")
plt.ylabel("Value")
plt.show()


# ============================================================
# ii. COMPARE WHITE NOISE VS ORIGINAL TIME SERIES
# ============================================================

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(df.index, df['Passengers'], color='blue')
plt.title("AirPassengers Time Series (Original)")
plt.xlabel("Time")
plt.ylabel("Passengers")

plt.subplot(1, 2, 2)
plt.plot(df.index, white_noise, color='purple')
plt.title("White Noise")
plt.xlabel("Time")
plt.ylabel("Value")

plt.tight_layout()
plt.show()


# ============================================================
# iii. STATIONARITY TESTS (ADF + KPSS)
# ============================================================

# ------ AUGMENTED DICKEY FULLER (ADF) TEST ------
adf_result = adfuller(df['Passengers'])

print("\n===== ADF TEST =====")
print(f"ADF Statistic  : {adf_result[0]}")
print(f"p-value        : {adf_result[1]}")
print("Critical Values:")
for key, value in adf_result[4].items():
    print(f"    {key}: {value}")

if adf_result[1] < 0.05:
    print("→ ADF conclusion: Time series is STATIONARY")
else:
    print("→ ADF conclusion: Time series is NOT stationary")


# ------ KPSS TEST ------
kpss_result = kpss(df['Passengers'], regression='c')

print("\n===== KPSS TEST =====")
print(f"KPSS Statistic : {kpss_result[0]}")
print(f"p-value        : {kpss_result[1]}")
print("Critical Values:")
for key, value in kpss_result[3].items():
    print(f"    {key}: {value}")

if kpss_result[1] < 0.05:
    print("→ KPSS conclusion: Time series is NOT stationary")
else:
    print("→ KPSS conclusion: Time series is STATIONARY")
""",
6:"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
import warnings
warnings.filterwarnings("ignore")
# LOAD DATA
# -------------------------------
df = pd.read_csv("/content/AirPassengers - AirPassengers.csv",
                 parse_dates=True, index_col='Month')
df.rename(columns={'#Passengers': 'Passengers'}, inplace=True)
print(df.head())
# i. DETECT AND QUANTIFY TREND USING MOVING AVERAGE
# ============================================================
window_size = 12  # 12-month moving average
df['SMA_12'] = df['Passengers'].rolling(window=window_size).mean()
df['SMA_6'] = df['Passengers'].rolling(window=6).mean()  # shorter window for comparison
# Plot original vs moving averages
plt.figure(figsize=(12,5))
plt.plot(df.index, df['Passengers'], label='Original', color='blue')
plt.plot(df.index, df['SMA_12'], label='12-month SMA', color='red')
plt.plot(df.index, df['SMA_6'], label='6-month SMA', color='green')
plt.title("AirPassengers: Trend Detection using Moving Averages")
plt.xlabel("Date")
plt.ylabel("Number of Passengers")
plt.legend()
plt.show()

# Observation: Moving averages smooth out short-term fluctuations
# and highlight the upward trend over time.
# ii. PLOT ACF AND PACF
# ============================================================

plt.figure(figsize=(12,4))
plot_acf(df['Passengers'], lags=50, ax=plt.gca())
plt.title("Autocorrelation Function (ACF)")
plt.show()

plt.figure(figsize=(12,4))
plot_pacf(df['Passengers'], lags=50, method='ywm', ax=plt.gca())
plt.title("Partial Autocorrelation Function (PACF)")
plt.show()

""",
7:"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.ar_model import AutoReg
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.metrics import mean_squared_error, mean_absolute_error
import warnings
warnings.filterwarnings("ignore")
# LOAD DATA
# -------------------------------
df = pd.read_csv("/content/AirPassengers - AirPassengers.csv",
                 parse_dates=True, index_col='Month')
df.rename(columns={'#Passengers': 'Passengers'}, inplace=True)
print(df.head())
# i. ACF and PACF plots
# -----------------------------
plot_acf(df['Passengers'], lags=50)
plt.show()

plot_pacf(df['Passengers'], lags=50, method='ywm')
plt.show()
# ii. FIT AR(1) MODEL
# ============================================================

# Split train/test
train_size = int(len(df)*0.8)
train, test = df.iloc[:train_size], df.iloc[train_size:]

# Fit AR(1)
ar1_model = AutoReg(train['Passengers'], lags=1).fit()
print(ar1_model.summary())

# Predict
pred_ar1 = ar1_model.predict(start=len(train), end=len(df)-1, dynamic=False)

# Evaluate performance
mae = mean_absolute_error(test['Passengers'], pred_ar1)
mse = mean_squared_error(test['Passengers'], pred_ar1)
rmse = np.sqrt(mse)

print("\nAR(1) Model Performance on Test Data:")
print(f"MAE: {mae:.2f}, MSE: {mse:.2f}, RMSE: {rmse:.2f}")
# Plot predictions
plt.figure(figsize=(12,5))
plt.plot(train.index, train['Passengers'], label='Train', color='blue')
plt.plot(test.index, test['Passengers'], label='Test', color='green')
plt.plot(test.index, pred_ar1, label='AR(1) Forecast', color='red')
plt.title("AR(1) Model Forecast")
plt.xlabel("Date")
plt.ylabel("Passengers")
plt.legend()
plt.show()
# iii. FIT HIGHER LAG AR MODELS
# ============================================================

# Try AR(12) to capture seasonality (12-month lag)
ar12_model = AutoReg(train['Passengers'], lags=12).fit()
pred_ar12 = ar12_model.predict(start=len(train), end=len(df)-1, dynamic=False)

mae12 = mean_absolute_error(test['Passengers'], pred_ar12)
mse12 = mean_squared_error(test['Passengers'], pred_ar12)
rmse12 = np.sqrt(mse12)

print("\nAR(12) Model Performance on Test Data:")
print(f"MAE: {mae12:.2f}, MSE: {mse12:.2f}, RMSE: {rmse12:.2f}")
# Plot AR(12) predictions
plt.figure(figsize=(12,5))
plt.plot(train.index, train['Passengers'], label='Train', color='blue')
plt.plot(test.index, test['Passengers'], label='Test', color='green')
plt.plot(test.index, pred_ar12, label='AR(12) Forecast', color='orange')
plt.title("AR(12) Model Forecast")
plt.xlabel("Date")
plt.ylabel("Passengers")
plt.legend()
plt.show()

# Observation:
# - AR(1) captures basic autocorrelation but misses seasonality
# - AR(12) better captures yearly seasonal patterns in the dataset
""",
8:"""
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.metrics import mean_squared_error, mean_absolute_error
# LOAD DATA
# -------------------------------
df = pd.read_csv("/content/AirPassengers - AirPassengers.csv",
                 parse_dates=True, index_col='Month')
df.rename(columns={'#Passengers':'Passengers'}, inplace=True)
# i. Plot ACF and PACF
# -------------------------------
plot_acf(df['Passengers'], lags=50)
plt.show()

plot_pacf(df['Passengers'], lags=50, method='ywm')
plt.show()

# Split train/test
# -------------------------------
train_size = int(len(df)*0.8)
train = df.iloc[:train_size]
test = df.iloc[train_size:]
# ii. Fit MA(1) model
# -------------------------------
ma1_model = ARIMA(train['Passengers'], order=(0,0,1)).fit()
pred_ma1 = ma1_model.forecast(steps=len(test))

mae_ma1 = mean_absolute_error(test['Passengers'], pred_ma1)
rmse_ma1 = mean_squared_error(test['Passengers'], pred_ma1)** 0.5

print("MA(1) Model Performance:")
print(f"MAE: {mae_ma1:.2f}, RMSE: {rmse_ma1:.2f}")
# iii. Fit higher-lag MA model (MA-12)
# -------------------------------
ma12_model = ARIMA(train['Passengers'], order=(0,0,12)).fit()
pred_ma12 = ma12_model.forecast(steps=len(test))

mae_ma12 = mean_absolute_error(test['Passengers'], pred_ma12)
rmse_ma12 = mean_squared_error(test['Passengers'], pred_ma12)**0.5
print("MA(12) Model Performance:")
print(f"MAE: {mae_ma12:.2f}, RMSE: {rmse_ma12:.2f}")
# iv. Plot and compare
# -------------------------------
plt.figure(figsize=(12,5))
plt.plot(train.index, train['Passengers'], label='Train')
plt.plot(test.index, test['Passengers'], label='Test')
plt.plot(test.index, pred_ma1, label='MA(1) Forecast')
plt.plot(test.index, pred_ma12, label='MA(12) Forecast')
plt.title("Comparison of MA(1) vs MA(12) Forecasts")
plt.xlabel("Date")
plt.ylabel("Passengers")
plt.legend()
plt.show()
""",
9:"""
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np
# LOAD DATA
# -------------------------------
df = pd.read_csv("/content/AirPassengers - AirPassengers.csv",
                 parse_dates=True, index_col='Month')
df.rename(columns={'#Passengers':'Passengers'}, inplace=True)
# Make the series stationary (log-diff)
# -------------------------------
import numpy as np
df['log_passengers'] = np.log(df['Passengers'])
df['diff'] = df['log_passengers'].diff().dropna()
# Split train/test
# -------------------------------
train_size = int(len(df)*0.8)
train = df['diff'].iloc[1:train_size]   # skip first NaN
test = df['diff'].iloc[train_size:]
# i. Initialize and fit ARMA model
# -------------------------------
# ARMA(p,q) is ARIMA(p,0,q), so d=0
arma_model = ARIMA(train, order=(1,0,1))  # ARMA(1,1)
arma_fit = arma_model.fit()
print(arma_fit.summary())
# ii. Generate forecasts
# -------------------------------
start = len(train)
end = len(train) + len(test) - 1
pred = arma_fit.predict(start=start, end=end)
# iii. Evaluate forecasts
# -------------------------------
mae = mean_absolute_error(test, pred)
rmse = mean_squared_error(test, pred)**0.5
print("ARMA(1,1) Forecast Performance:")
print(f"MAE: {mae:.4f}, RMSE: {rmse:.4f}")
# Plot results
# -------------------------------
plt.figure(figsize=(12,5))
plt.plot(train.index, train, label='Train (diff log)')
plt.plot(test.index, test, label='Test (diff log)')
plt.plot(test.index, pred, label='ARMA Forecast')
plt.title("ARMA(1,1) Model Forecast")
plt.xlabel("Date")
plt.ylabel("Differenced Log Passengers")
plt.legend()
plt.show()

""",
10:"""
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np
# LOAD DATA
# -------------------------------
df = pd.read_csv("/content/AirPassengers - AirPassengers.csv",
                 parse_dates=True, index_col='Month')
df.rename(columns={'#Passengers':'Passengers'}, inplace=True)
# TRAIN-TEST SPLIT
# -------------------------------
train_size = int(len(df)*0.8)
train = df.iloc[:train_size]
test = df.iloc[train_size:]
# i. Initialize ARIMA(p,d,q)
# -------------------------------
# Example: ARIMA(1,1,1)
# p=1 (AR term), d=1 (difference to make stationary), q=1 (MA term)
arima_model = ARIMA(train['Passengers'], order=(1,1,1))
# ii. Fit the model
# -------------------------------
arima_fit = arima_model.fit()
print(arima_fit.summary())
# iii. Generate forecasts
# -------------------------------
start = len(train)
end = len(train) + len(test) - 1
pred = arima_fit.predict(start=start, end=end, typ='levels')  # typ='levels' returns actual values
# Evaluate forecast
# -------------------------------
mae = mean_absolute_error(test['Passengers'], pred)
rmse = np.sqrt(mean_squared_error(test['Passengers'], pred))

print("ARIMA(1,1,1) Forecast Performance:")
print(f"MAE: {mae:.2f}, RMSE: {rmse:.2f}")
# Plot forecasts
# -------------------------------
plt.figure(figsize=(12,5))
plt.plot(train.index, train['Passengers'], label='Train')
plt.plot(test.index, test['Passengers'], label='Test')
plt.plot(test.index, pred, label='ARIMA Forecast', color='red')
plt.title("ARIMA(1,1,1) Model Forecast")
plt.xlabel("Date")
plt.ylabel("Passengers")
plt.legend()
plt.show()

"""
}
