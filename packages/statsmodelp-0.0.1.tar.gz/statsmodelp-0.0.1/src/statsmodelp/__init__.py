# src/statsmodelp/__init__.py

from .snippets import SNIPPETS

try:
    import pyperclip
except ImportError:
    pyperclip = None


def get(snippet_id: int) -> str:
    """
    Return the code snippet as a string.
    """
    if snippet_id not in SNIPPETS:
        raise KeyError(f"Snippet {snippet_id} not found.")
    return SNIPPETS[snippet_id]


def show(snippet_id: int) -> None:
    """
    Print the snippet to the console.
    """
    print(get(snippet_id))


def copy(snippet_id: int) -> str:
    """
    Copy the snippet to the clipboard (if pyperclip is installed)
    and also return it as a string.
    """
    text = get(snippet_id)
    if pyperclip is None:
        raise RuntimeError(
            "pyperclip is not installed. "
            "Install it with: pip install pyperclip"
        )
    pyperclip.copy(text)
    return text


# Optional: expose s1, s3, etc. as variables
for _id, _code in SNIPPETS.items():
    globals()[f"s{_id}"] = _code

__all__ = ["get", "show", "copy"] + [f"s{_id}" for _id in SNIPPETS]
