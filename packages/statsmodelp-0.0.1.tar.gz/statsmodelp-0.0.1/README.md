# statsmodelp

A small helper package to store frequently used code snippets and quickly paste or display them.

## Usage

```python
import statsmodelp as smp

smp.show(1)       # prints snippet 1
smp.copy(3)       # copies snippet 3 to clipboard
