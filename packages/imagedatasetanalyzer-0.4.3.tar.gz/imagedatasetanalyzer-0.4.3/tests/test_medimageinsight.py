from PIL import Image
import os

def convertir_jpeg_a_png(directorio):
    """
    Convierte todos los archivos .jpg/.jpeg de un directorio a .png.
    Guarda los PNG en el mismo directorio.
    """
    for archivo in os.listdir(directorio):
        if archivo.lower().endswith((".jpg", ".jpeg")):
            ruta_jpeg = os.path.join(directorio, archivo)
            nombre_sin_ext = os.path.splitext(archivo)[0]
            ruta_png = os.path.join(directorio, nombre_sin_ext + ".png")

            with Image.open(ruta_jpeg) as img:
                img.save(ruta_png, "PNG")
                print(f"Convertido: {archivo} → {nombre_sin_ext}.png")

# Ejemplo de uso:
convertir_jpeg_a_png(r"C:\Users\joortif\Downloads\bkai-igh-neopolyp\train_gt")
