import sys
import os
import torch
import numpy as np
import logging


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from imagedatasetanalyzer.datasets.imagedataset import ImageDataset
from imagedatasetanalyzer.datasets.imagelabeldataset import ImageLabelDataset
from imagedatasetanalyzer.embeddings.tensorflowembedding import TensorflowEmbedding
from imagedatasetanalyzer.embeddings.torchembedding import PyTorchEmbedding
from imagedatasetanalyzer.embeddings.huggingfaceembedding import HuggingFaceEmbedding
from imagedatasetanalyzer.embeddings.opencvlbpembedding import OpenCVLBPEmbedding
from imagedatasetanalyzer.embeddings.medimageinsightembedding import MedImageInsightEmbedding

if __name__ == "__main__":

    root = logging.getLogger()
    if not root.handlers:
            handler = logging.StreamHandler(stream=sys.stdout)
            formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
            handler.setFormatter(formatter)
            root.addHandler(handler)
    root.setLevel(logging.INFO)

    img_dir = r"C:\Users\joortif\Desktop\datasets\Completos\NeoPolyp\train"
    labels_dir = r"C:\Users\joortif\Desktop\datasets\Completos\NeoPolyp\train_gt_binarized"

    imagelabel_dataset = ImageDataset(img_dir=img_dir)

    medimageinsight = MedImageInsightEmbedding(batch_size=8)

    embeddings = medimageinsight.generate_embeddings(imagelabel_dataset)

    """emb = OpenCVLBPEmbedding(radius=16, num_points=4, resize_height=384, resize_width=384)
    embeddings = emb.generate_embeddings(imagelabel_dataset)
    
    for file, emb in embeddings.items():
        print(f"{file} : {emb}")
    print(type(embeddings))"""
