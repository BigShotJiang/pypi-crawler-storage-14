from dbt_dry_run.cli import app


def main() -> None:
    exit(app())


if __name__ == "__main__":
    main()
