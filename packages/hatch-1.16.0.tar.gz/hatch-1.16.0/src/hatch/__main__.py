if __name__ == "__main__":
    from hatch.cli import main

    main()
