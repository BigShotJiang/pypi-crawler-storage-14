::: mkdocs-click
    :module: hatch.cli
    :command: hatch
    :depth: 0
    :style: table
    :remove_ascii_art: true
