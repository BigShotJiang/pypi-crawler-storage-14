# Community highlights

-----

## Integration

- Project Jupyter - https://blog.jupyter.org/packaging-for-jupyter-in-2022-c7be64c38926
- Visual Studio Code - https://code.visualstudio.com/updates/v1_88#_hatch-environment-discovery

## Adoption

- Black - https://ichard26.github.io/blog/2022/10/black-22.10.0/#goodbye-python-36-and-hello-hatchling
- "Switching to Hatch" - https://andrich.me/2023/08/switching-to-hatch/
