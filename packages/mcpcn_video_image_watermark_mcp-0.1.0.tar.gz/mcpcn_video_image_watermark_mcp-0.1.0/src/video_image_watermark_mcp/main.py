from mcp.server.fastmcp import FastMCP
import ffmpeg
import os
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import tempfile

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

package = "video-image-watermark-mcp"

log_dir = Path(tempfile.gettempdir()) / package
log_dir.mkdir(exist_ok=True)
log_file = log_dir / "debug.log"

file_handler = RotatingFileHandler(
    str(log_file), maxBytes=5_000_000, backupCount=3, encoding="utf-8"
)
file_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
)
logger.addHandler(file_handler)
logger.propagate = False

FFMPEG_BINARY = os.environ.get("FFMPEG_BINARY")
FFPROBE_BINARY = os.environ.get("FFPROBE_BINARY")


def _ffmpeg_run(stream_spec, **kwargs):
    if "overwrite_output" not in kwargs:
        kwargs["overwrite_output"] = True
    return ffmpeg.run(stream_spec, cmd=FFMPEG_BINARY, **kwargs)


def _ffprobe_probe(path: str, **kwargs):
    return ffmpeg.probe(path, cmd=FFPROBE_BINARY, **kwargs)


def _parse_time_to_seconds(time_str: str) -> float:
    if isinstance(time_str, (int, float)):
        return float(time_str)
    if ":" in time_str:
        parts = time_str.split(":")
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        elif len(parts) == 2:
            return int(parts[0]) * 60 + float(parts[1])
        else:
            raise ValueError(f"Invalid time format: {time_str}")
    return float(time_str)


def _prepare_path(input_path: str, output_path: str) -> None:
    if not os.path.exists(input_path):
        raise RuntimeError(f"Error: Input file not found at {input_path}")
    try:
        parent_dir = os.path.dirname(output_path)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
    except Exception as e:
        raise RuntimeError(
            f"Error creating output directory for {output_path}: {str(e)}"
        )
    if os.path.exists(output_path):
        raise RuntimeError(
            f"Error: Output file already exists at {output_path}. Please choose a different path or delete the existing file."
        )


mcp = FastMCP("VideoImageWatermarkServer")


def _process_single_video(
    video_path: str,
    output_video_path: str,
    image_path: str,
    position: str,
    opacity: float,
    start_time: str,
    end_time: str,
    width: str,
    height: str,
) -> str:
    """处理单个视频添加图片水印。"""
    _prepare_path(video_path, output_video_path)
    try:
        if not os.path.exists(video_path):
            raise RuntimeError(f"Error: Input video file not found at {video_path}")
        if not os.path.exists(image_path):
            raise RuntimeError(f"Error: Overlay image file not found at {image_path}")

        main_input = ffmpeg.input(video_path)
        overlay_input = ffmpeg.input(image_path)
        processed_overlay = overlay_input

        if width or height:
            w_val = width if width else "-1"
            h_val = height if height else "-1"
            processed_overlay = processed_overlay.filter("scale", w=w_val, h=h_val)

        if opacity is not None and 0.0 <= opacity <= 1.0:
            processed_overlay = processed_overlay.filter("format", "rgba")
            processed_overlay = processed_overlay.filter(
                "colorchannelmixer", aa=str(opacity)
            )

        overlay_x_pos = "0"
        overlay_y_pos = "0"
        if position == "top_left":
            overlay_x_pos, overlay_y_pos = "10", "10"
        elif position == "top_right":
            overlay_x_pos, overlay_y_pos = "main_w-overlay_w-10", "10"
        elif position == "bottom_left":
            overlay_x_pos, overlay_y_pos = "10", "main_h-overlay_h-10"
        elif position == "bottom_right":
            overlay_x_pos, overlay_y_pos = "main_w-overlay_w-10", "main_h-overlay_h-10"
        elif position == "center":
            overlay_x_pos, overlay_y_pos = (
                "(main_w-overlay_w)/2",
                "(main_h-overlay_h)/2",
            )
        elif ":" in position:
            pos_parts = position.split(":")
            for part in pos_parts:
                if part.startswith("x="):
                    overlay_x_pos = part.split("=")[1]
                if part.startswith("y="):
                    overlay_y_pos = part.split("=")[1]

        overlay_filter_kwargs = {"x": overlay_x_pos, "y": overlay_y_pos}
        if start_time is not None or end_time is not None:
            actual_start_sec = (
                _parse_time_to_seconds(start_time) if start_time is not None else 0
            )
            if end_time is not None:
                actual_end_sec = _parse_time_to_seconds(end_time)
                enable_expr = f"between(t,{actual_start_sec},{actual_end_sec})"
            else:
                enable_expr = f"gte(t,{actual_start_sec})"
            overlay_filter_kwargs["enable"] = enable_expr

        try:
            video_with_overlay = ffmpeg.filter(
                [main_input, processed_overlay], "overlay", **overlay_filter_kwargs
            )
            probe = _ffprobe_probe(video_path)
            has_audio = any(s["codec_type"] == "audio" for s in probe["streams"])
            if has_audio:
                output_node = ffmpeg.output(
                    video_with_overlay,
                    main_input.audio,
                    output_video_path,
                    vcodec="libx264",
                    pix_fmt="yuv420p",
                    acodec="copy",
                )
            else:
                output_node = ffmpeg.output(
                    video_with_overlay,
                    output_video_path,
                    vcodec="libx264",
                    pix_fmt="yuv420p",
                )
            _ffmpeg_run(output_node, capture_stdout=True, capture_stderr=True)
            return f"Image overlay added successfully to {output_video_path}"
        except ffmpeg.Error as e_acopy:
            try:
                video_with_overlay_fallback = ffmpeg.filter(
                    [main_input, processed_overlay], "overlay", **overlay_filter_kwargs
                )
                probe = _ffprobe_probe(video_path)
                has_audio = any(s["codec_type"] == "audio" for s in probe["streams"])
                if has_audio:
                    output_node_fallback = ffmpeg.output(
                        video_with_overlay_fallback,
                        main_input.audio,
                        output_video_path,
                        vcodec="libx264",
                        pix_fmt="yuv420p",
                        acodec="aac",
                    )
                else:
                    output_node_fallback = ffmpeg.output(
                        video_with_overlay_fallback,
                        output_video_path,
                        vcodec="libx264",
                        pix_fmt="yuv420p",
                    )
                _ffmpeg_run(
                    output_node_fallback, capture_stdout=True, capture_stderr=True
                )
                return f"Image overlay added successfully to {output_video_path}"
            except ffmpeg.Error as e_recode:
                err_acopy_msg = (
                    e_acopy.stderr.decode("utf8") if e_acopy.stderr else str(e_acopy)
                )
                err_recode_msg = (
                    e_recode.stderr.decode("utf8") if e_recode.stderr else str(e_recode)
                )
                raise RuntimeError(
                    f"Error adding image overlay. Audio copy attempt: {err_acopy_msg}. Full re-encode attempt: {err_recode_msg}"
                )
    except ffmpeg.Error as e:
        error_message = e.stderr.decode("utf8") if e.stderr else str(e)
        raise RuntimeError(f"Error processing image overlay: {error_message}")
    except FileNotFoundError:
        raise RuntimeError(
            f"Error: An input file was not found (video: '{video_path}', image: '{image_path}'). Please check paths."
        )
    except Exception as e:
        raise RuntimeError(
            f"An unexpected error occurred in add_image_overlay: {str(e)}"
        )


@mcp.tool()
def add_image_overlay(
    video_paths: list[str],
    output_dir: str,
    image_path: str,
    position: str = "top_right",
    opacity: float = None,
    start_time: str = None,
    end_time: str = None,
    width: str = None,
    height: str = None,
) -> str:
    """为多个视频批量添加图片叠加（水印/徽标）。

    Args:
        video_paths: 输入视频文件路径列表。
        output_dir: 输出目录路径，输出文件名为原文件名加_watermarked后缀。
        image_path: 叠加图片路径（支持透明通道）。
        position: 预设位置 'top_left'|'top_right'|'bottom_left'|'bottom_right'|'center'，或 'x=..:y=..' 自定义。
        opacity: 透明度（0.0~1.0）。
        start_time: 生效开始时间（秒或 'HH:MM:SS'）。
        end_time: 生效结束时间（秒或 'HH:MM:SS'）。
        width/height: 目标尺寸（像素或表达式；只设其一时另一边按比例自适应）。

    Returns:
        处理结果信息，包含成功和失败的文件列表。
    """
    if not video_paths:
        raise RuntimeError("Error: video_paths list is empty")

    if not os.path.exists(image_path):
        raise RuntimeError(f"Error: Overlay image file not found at {image_path}")

    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    results = []
    success_count = 0
    fail_count = 0

    for video_path in video_paths:
        try:
            # 生成输出文件路径
            base_name = os.path.basename(video_path)
            name, ext = os.path.splitext(base_name)
            output_video_path = os.path.join(output_dir, f"{name}_watermarked{ext}")

            result = _process_single_video(
                video_path=video_path,
                output_video_path=output_video_path,
                image_path=image_path,
                position=position,
                opacity=opacity,
                start_time=start_time,
                end_time=end_time,
                width=width,
                height=height,
            )
            results.append(f"✓ {video_path} -> {output_video_path}")
            success_count += 1
        except Exception as e:
            results.append(f"✗ {video_path}: {str(e)}")
            fail_count += 1

    summary = f"\n处理完成: {success_count} 成功, {fail_count} 失败\n"
    return summary + "\n".join(results)


def main():
    """Main entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
