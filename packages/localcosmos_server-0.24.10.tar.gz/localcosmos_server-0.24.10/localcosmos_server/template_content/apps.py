from django.apps import AppConfig


class TemplateContentConfig(AppConfig):
    name = 'localcosmos_server.template_content'
