CHANGELOG
---------

1.0.0
:::::
- Update project structure

0.2.0
:::::
- Fix for endianness of returned float on ``measure_voltage()`` command

0.1.1
:::::
- Add class ``SensorBridgeI2cProxy`` to provide a unified I²C port access

0.1.0
:::::
- Initial release
