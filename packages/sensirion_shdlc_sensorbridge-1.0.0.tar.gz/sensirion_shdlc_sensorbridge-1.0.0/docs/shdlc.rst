SHDLC Protocol
==============

SHDLC (Sensirion High-Level Data Link Control) is the protocol used to
communicate with the SEK-SensorBridge. It is also used by many other
Sensirion devices, thus it's documented in the SHDLC base driver
`here <https://sensirion.github.io/python-shdlc-driver/shdlc.html>`_.
