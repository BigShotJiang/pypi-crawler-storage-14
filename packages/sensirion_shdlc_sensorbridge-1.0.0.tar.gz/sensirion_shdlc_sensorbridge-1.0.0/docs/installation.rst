Installation
============

The package can be installed with pip:

.. sourcecode:: bash

    pip install sensirion-shdlc-sensorbridge

Recommended usage is within a virtualenv.
