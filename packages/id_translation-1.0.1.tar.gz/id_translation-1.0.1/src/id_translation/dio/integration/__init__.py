"""Integration modules.

Integrations in this module are automatically registered if the necessary dependencies are installed.
"""
