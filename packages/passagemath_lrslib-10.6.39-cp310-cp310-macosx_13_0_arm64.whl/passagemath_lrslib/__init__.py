# sage_setup: distribution = sagemath-lrslib

from sage.all__sagemath_lrslib import *
