"""
Primus Lens WandB Exporter
自动劫持 wandb 的上报功能，无需用户修改代码
"""

__version__ = "0.1.1"
__author__ = "Primus Team"

# 自动安装 hook（通过 .pth 文件触发）
# 这个模块会在 Python 启动时自动导入

