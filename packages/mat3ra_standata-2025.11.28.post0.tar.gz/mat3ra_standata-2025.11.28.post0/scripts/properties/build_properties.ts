import { PropertiesProcessor } from "../processors/PropertiesProcessor";

const processor = new PropertiesProcessor(__dirname);
processor.process();
