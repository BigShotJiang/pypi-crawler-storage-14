"""Module that contains the default imagery object

The Imagery object in this class can be subclassed by third-party objects to implement their own logic including
file readers and pixel-to-geodetic conversions
"""
from dataclasses import dataclass, field
import h5py
import numpy as np
from numpy.typing import NDArray
import pathlib
from typing import Union, Optional
import uuid
from vista.aoi import AOI
from vista.sensors.sensor import Sensor


@dataclass
class Imagery:
    """
    Container for multi-frame imagery datasets with metadata and coordinate conversion capabilities.

    VISTA's Imagery class represents a temporal sequence of image frames with associated metadata
    including timestamps, geodetic coordinate conversion polynomials, and sensor calibration data.
    This class serves as the foundation for all image-based analysis in VISTA.

    Core Attributes
    ---------------
    name : str
        Human-readable identifier for this imagery dataset
    images : NDArray[np.float32]
        3D array of image data with shape (num_frames, height, width).
        Pixel values are stored as 32-bit floats to support processing operations.
    frames : NDArray[np.int_]
        1D array of frame numbers corresponding to each image.
        Frame numbers need not be sequential or start at zero.
    row_offset : int, optional
        Row offset for imagery positioning (default: 0).
        Used when imagery represents a subset/crop of a larger scene.
    column_offset : int, optional
        Column offset for imagery positioning (default: 0).
        Used when imagery represents a subset/crop of a larger scene.

    Temporal Metadata
    -----------------
    times : NDArray[np.datetime64], optional
        Timestamp for each frame with microsecond precision.
        Enables time-based analysis and temporal coordinate conversion.

    Sensor Information
    ------------------
    sensor : Sensor
        Sensor object containing projection polynomials and radiometric calibration data.
        The Sensor provides geodetic coordinate conversion capabilities, sensor positions,
        and optional point spread function modeling for irradiance estimation.

    Internal Attributes
    -------------------
    description : str, optional
        Long-form description of the imagery (default: "")
    _histograms : dict, optional
        Cached histograms for performance. Maps frame_index -> (hist_y, hist_x).
        Computed lazily via get_histogram() method.
    uuid : str
        Unique identifier automatically generated for each Imagery instance

    Methods
    -------
    __getitem__(slice)
        Slice imagery by frame range, preserving metadata
    get_aoi(aoi)
        Extract spatial subset defined by Area of Interest
    pixel_to_geodetic(frame, rows, columns)
        Convert pixel coordinates to geodetic (lat/lon/alt)
    geodetic_to_pixel(frame, location)
        Convert geodetic coordinates to pixel (row/column)
    get_histogram(frame_index)
        Compute or retrieve cached histogram for a frame
    to_hdf5(file)
        Save imagery and all metadata to HDF5 file
    copy()
        Create a shallow copy of the imagery object

    Examples
    --------
    >>> # Create basic imagery
    >>> import numpy as np
    >>> images = np.random.randn(100, 256, 256).astype(np.float32)
    >>> frames = np.arange(100)
    >>> imagery = Imagery(name="Test", images=images, frames=frames)

    >>> # Create imagery with timestamps
    >>> times = np.array([np.datetime64('2024-01-01T00:00:00') +
    ...                   np.timedelta64(i*100, 'ms') for i in range(100)])
    >>> imagery = Imagery(name="Test", images=images, frames=frames, times=times)

    >>> # Slice imagery by frame range
    >>> subset = imagery[10:50]  # Frames 10-49

    >>> # Extract spatial subset via AOI
    >>> from vista.aoi import AOI
    >>> aoi = AOI(name="Region1", x=50, y=50, width=100, height=100)
    >>> cropped = imagery.get_aoi(aoi)

    Notes
    -----
    - Frame numbers in the `frames` array need not be contiguous or zero-indexed
    - All optional metadata (times, polynomials, calibration data) is preserved during
      slicing operations
    - Geodetic conversion requires valid polynomial coefficients for the frame of interest
    - Calibration frame arrays define ranges: frame N applies until frame N+1 starts
    """
    name: str
    images: NDArray[np.float32]
    frames: NDArray[np.int_]
    sensor: Sensor
    row_offset: int = None
    column_offset: int = None
    times: Optional[NDArray[np.datetime64]] = None
    description: str = ""
    # Cached histograms for performance (computed lazily)
    _histograms: Optional[dict] = None  # Maps frame_index -> (hist_y, hist_x)
    uuid: str = field(init=None, default=None)

    def __post_init__(self):
        if self.row_offset is None:
            self.row_offset = 0
        if self.column_offset is None:
            self.column_offset = 0
        self.uuid = uuid.uuid4()
        self.sensor.add_imagery(self)
    
    def __getitem__(self, s):
        if isinstance(s, slice):
            # Handle slice objects
            imagery_slice = self.copy()
            imagery_slice.images = imagery_slice.images[s]
            imagery_slice.frames = imagery_slice.frames[s]
            imagery_slice.times = imagery_slice.times[s] if imagery_slice.times is not None else None
            return imagery_slice
        else:
            raise TypeError("Invalid index or slice type.")
        
    def __len__(self):
        return self.images.shape[0]
    
    def __eq__(self, other):
        return hasattr(other, 'uuid') and (self.uuid == other.uuid)
    
    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"{self.__class__.__name__}({self.name}, {self.images.shape})"

    def copy(self):
        """Create a (soft) copy of this imagery"""
        return self.__class__(
            name = self.name + f" (copy)",
            images = self.images,
            frames = self.frames,
            sensor = self.sensor,
            row_offset = self.row_offset,
            column_offset = self.column_offset,
            times = self.times,
            description = self.description,
        )
    
    def compute_histograms(self, bins=256):
        """Pre-compute histograms for all frames (lazy caching)"""
        if self._histograms is None:
            self._histograms = {}

        # Compute histograms for all frames
        for i in range(len(self.images)):
            if i not in self._histograms:
                image = self.images[i]
                hist_y, hist_x = np.histogram(image, bins=bins)
                # Convert bin edges to bin centers for plotting
                bin_centers = (hist_x[:-1] + hist_x[1:]) / 2
                self._histograms[i] = (hist_y, bin_centers)

        return self._histograms

    def get_histogram(self, frame_index, bins=256):
        """Get histogram for a specific frame (computes if not cached)"""
        if self._histograms is None:
            self._histograms = {}

        if frame_index not in self._histograms:
            image = self.images[frame_index]
            hist_y, hist_x = np.histogram(image, bins=bins)
            # Convert bin edges to bin centers for plotting
            bin_centers = (hist_x[:-1] + hist_x[1:]) / 2
            self._histograms[frame_index] = (hist_y, bin_centers)

        return self._histograms[frame_index]

    def has_cached_histograms(self):
        """Check if histograms have been pre-computed"""
        return self._histograms is not None and len(self._histograms) == len(self.images)

    def get_aoi(self, aoi: AOI) -> "Imagery":
        # Extract AOI bounds
        row_start = int(aoi.y) - self.row_offset
        row_end = int(aoi.y + aoi.height) - self.row_offset
        col_start = int(aoi.x) - self.column_offset
        col_end = int(aoi.x + aoi.width) - self.column_offset

        # Crop imagery to AOI
        cropped_images = self.images[:, row_start:row_end, col_start:col_end]
        
        # Create imagery AOI from a copy of this imagery
        imagery_aoi = self.copy()
        imagery_aoi.name = self.name + f" (AOI: {aoi.name})"
        imagery_aoi.images = cropped_images
        imagery_aoi.row_offset = self.row_offset + row_start
        imagery_aoi.column_offset = self.column_offset + col_start

        return imagery_aoi
    
    def to_hdf5(self, group: h5py.Group):
        """
        Save imagery data to an HDF5 group.

        Parameters
        ----------
        group : h5py.Group
            HDF5 group to write imagery data to (typically sensors/<sensor_uuid>/imagery/<imagery_uuid>/)

        Notes
        -----
        This method writes only imagery-specific data:
        - Image arrays (chunked for efficient loading)
        - Frame numbers
        - Times (as unix_times and unix_fine_times)
        - Row/column offsets
        - Metadata attributes (name, description, uuid)

        Sensor data should be written separately using sensor.to_hdf5()
        """
        # Set imagery attributes
        group.attrs['name'] = self.name
        group.attrs['description'] = self.description
        group.attrs['uuid'] = str(self.uuid)
        group.attrs['row_offset'] = self.row_offset
        group.attrs['column_offset'] = self.column_offset

        # Save image data with chunking
        group.create_dataset('images', data=self.images, chunks=(1, self.images.shape[1], self.images.shape[2]))

        # Save frames
        group.create_dataset('frames', data=self.frames)

        # Save times if present
        if self.times is not None:
            # Convert datetime64 to unix seconds + nanoseconds
            total_nanoseconds = self.times.astype('datetime64[ns]').astype(np.int64)
            unix_times = (total_nanoseconds // 1_000_000_000).astype(np.int64)
            unix_fine_times = (total_nanoseconds % 1_000_000_000).astype(np.int64)

            group.create_dataset('unix_times', data=unix_times)
            group.create_dataset('unix_fine_times', data=unix_fine_times)


def save_imagery_hdf5(
    file_path: Union[str, pathlib.Path],
    sensor_imagery_map: dict[str, list[Imagery]]
):
    """
    Save imagery data to HDF5 file with hierarchical sensor/imagery structure.

    Parameters
    ----------
    file_path : Union[str, pathlib.Path]
        Path to the HDF5 file to create
    sensor_imagery_map : dict[str, list[Imagery]]
        Dictionary mapping Sensor object names to lists of Imagery objects from that sensor

    Notes
    -----
    The HDF5 file structure created is:
    ```
    root/
    ├── [attrs] format_version, created
    └── sensors/
        ├── <sensor_uuid>/
        │   ├── [attrs] name, uuid, sensor_type
        │   ├── position/ (SampledSensor only)
        │   ├── geolocation/ (if can_geolocate)
        │   ├── radiometric/ (if calibration data exists)
        │   └── imagery/
        │       ├── <imagery_uuid_1>/
        │       │   ├── [attrs] name, uuid, description, ...
        │       └── <imagery_uuid_2>/
        └── <sensor_uuid_2>/
            └── ...
    ```

    Examples
    --------
    >>> sensor = SampledSensor(name="MySensor", ...)
    >>> imagery1 = Imagery(name="img1", sensor=sensor, ...)
    >>> imagery2 = Imagery(name="img2", sensor=sensor, ...)
    >>> save_imagery_hdf5("data.h5", {"MySensor": [imagery1, imagery2]})
    """
    file_path = pathlib.Path(file_path)

    with h5py.File(file_path, 'w') as f:
        # Set root attributes
        f.attrs['format_version'] = '1.6'
        f.attrs['created'] = str(np.datetime64('now').astype(str))

        # Create sensors group
        sensors_group = f.create_group('sensors')

        # Iterate through sensor names and their imagery
        for sensor_name, imagery_list in sensor_imagery_map.items():
            if not imagery_list:
                continue  # Skip if no imagery for this sensor

            # Get sensor from first imagery (all imagery in list should have same sensor)
            sensor = imagery_list[0].sensor

            # Create sensor group using UUID (guaranteed unique, no sanitization needed)
            sensor_group = sensors_group.create_group(str(sensor.uuid))

            # Save sensor data
            sensor.to_hdf5(sensor_group)

            # Create imagery subgroup
            imagery_group = sensor_group.create_group('imagery')

            # Save each imagery dataset
            for imagery in imagery_list:
                # Create imagery group using UUID (guaranteed unique, no sanitization needed)
                img_group = imagery_group.create_group(str(imagery.uuid))

                # Save imagery data
                imagery.to_hdf5(img_group)
