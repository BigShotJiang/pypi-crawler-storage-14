# pylint: disable=useless-import-alias
from gen_epix.commondb.domain.repository.abac import (
    BaseAbacRepository as BaseAbacRepository,
)
from gen_epix.commondb.domain.repository.organization import (
    BaseOrganizationRepository as BaseOrganizationRepository,
)
from gen_epix.commondb.domain.repository.system import (
    BaseSystemRepository as BaseSystemRepository,
)
