from gen_epix.fastapp import BaseRepository


class BaseSystemRepository(BaseRepository):
    pass
