from gen_epix.fastapp import BaseRepository


class BaseGeoRepository(BaseRepository):
    pass
