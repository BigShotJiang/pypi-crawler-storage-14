from gen_epix.casedb.domain.service import BaseSubjectService


class SubjectService(BaseSubjectService):
    pass
