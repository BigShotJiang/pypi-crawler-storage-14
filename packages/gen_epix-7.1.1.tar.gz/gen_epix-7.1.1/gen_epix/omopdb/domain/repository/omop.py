from gen_epix.fastapp import BaseRepository


class BaseOmopRepository(BaseRepository):
    pass
