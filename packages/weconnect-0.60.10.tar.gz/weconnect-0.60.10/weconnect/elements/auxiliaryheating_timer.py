from weconnect.elements.climatization_timer import ClimatizationTimer


class AuxiliaryHeatingTimer(ClimatizationTimer):
    pass
