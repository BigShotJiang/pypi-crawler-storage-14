"""
MIT License

Copyright (c) 2024-present Jimmy Huang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

from . import _calc



# --- AES ---

def aes_encrypt_cbc_base64(orig_data, key_input):
    """Encrypts a string using AES in CBC mode and returns a Base64 string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Aes_encrypt_cbc_base64(orig_data, key_input)


def aes_decrypt_cbc_base64(encrypted_base64, key_input):
    """Decrypts a Base64 string using AES in CBC mode.

    Args:
        encrypted_base64: The Base64-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_cbc_base64(encrypted_base64, key_input)


def aes_encrypt_cbc_hex(orig_data, key_input):
    """Encrypts a string using AES in CBC mode and returns a hex string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Aes_encrypt_cbc_hex(orig_data, key_input)


def aes_decrypt_cbc_hex(encrypted_hex, key_input):
    """Decrypts a hex string using AES in CBC mode.

    Args:
        encrypted_hex: The hex-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_cbc_hex(encrypted_hex, key_input)


def aes_encrypt_ecb_base64(orig_data, key_input):
    """Encrypts a string using AES in ECB mode and returns a Base64 string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Aes_encrypt_ecb_base64(orig_data, key_input)


def aes_decrypt_ecb_base64(encrypted_base64, key_input):
    """Decrypts a Base64 string using AES in ECB mode.

    Args:
        encrypted_base64: The Base64-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_ecb_base64(encrypted_base64, key_input)


def aes_encrypt_ecb_hex(orig_data, key_input):
    """Encrypts a string using AES in ECB mode and returns a hex string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Aes_encrypt_ecb_hex(orig_data, key_input)


def aes_decrypt_ecb_hex(encrypted_hex, key_input):
    """Decrypts a hex string using AES in ECB mode.

    Args:
        encrypted_hex: The hex-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_ecb_hex(encrypted_hex, key_input)


def aes_encrypt_cfb_base64(orig_data, key_input):
    """Encrypts a string using AES in CFB mode and returns a Base64 string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Aes_encrypt_cfb_base64(orig_data, key_input)


def aes_decrypt_cfb_base64(encrypted_base64, key_input):
    """Decrypts a Base64 string using AES in CFB mode.

    Args:
        encrypted_base64: The Base64-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_cfb_base64(encrypted_base64, key_input)


def aes_encrypt_cfb_hex(orig_data, key_input):
    """Encrypts a string using AES in CFB mode and returns a hex string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Aes_encrypt_cfb_hex(orig_data, key_input)


def aes_decrypt_cfb_hex(encrypted_hex, key_input):
    """Decrypts a hex string using AES in CFB mode.

    Args:
        encrypted_hex: The hex-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_cfb_hex(encrypted_hex, key_input)


def aes_encrypt_ctr_base64(orig_data, key_input):
    """Encrypts a string using AES in CTR mode and returns a Base64 string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Aes_encrypt_ctr_base64(orig_data, key_input)


def aes_decrypt_ctr_base64(encrypted_base64, key_input):
    """Decrypts a Base64 string using AES in CTR mode.

    Args:
        encrypted_base64: The Base64-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_ctr_base64(encrypted_base64, key_input)


def aes_encrypt_ctr_hex(orig_data, key_input):
    """Encrypts a string using AES in CTR mode and returns a hex string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Aes_encrypt_ctr_hex(orig_data, key_input)


def aes_decrypt_ctr_hex(encrypted_hex, key_input):
    """Decrypts a hex string using AES in CTR mode.

    Args:
        encrypted_hex: The hex-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_ctr_hex(encrypted_hex, key_input)


def aes_encrypt_gcm_base64(orig_data, key_input):
    """Encrypts a string using AES in GCM mode and returns a Base64 string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Aes_encrypt_gcm_base64(orig_data, key_input)


def aes_decrypt_gcm_base64(encrypted_base64, key_input):
    """Decrypts a Base64 string using AES in GCM mode.

    Args:
        encrypted_base64: The Base64-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_gcm_base64(encrypted_base64, key_input)


def aes_encrypt_gcm_hex(orig_data, key_input):
    """Encrypts a string using AES in GCM mode and returns a hex string.

    Args:
        orig_data: The plaintext string to encrypt.
        key_input: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Aes_encrypt_gcm_hex(orig_data, key_input)


def aes_decrypt_gcm_hex(encrypted_hex, key_input):
    """Decrypts a hex string using AES in GCM mode.

    Args:
        encrypted_hex: The hex-encoded ciphertext.
        key_input: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Aes_decrypt_gcm_hex(encrypted_hex, key_input)


# --- SM Cipher ---

def sm2_encode(pub_key, plaintext, mode):
    """Encrypts a string using the SM2 public key.

    Args:
        pub_key: The SM2 public key.
        plaintext: The string to encrypt.
        mode: 0|C1C3C2默认, 1|C1C2C3

    Returns:
        The encrypted data as a hex string.
    """
    return _calc.calc_Sm2_encode(pub_key, plaintext, mode)

def sm2_decode(priv_key, data, mode):
    """Sm2_decode(str priv_key, str data, int mode) str

    Args:
        priv_key: The SM2 public key.
        data: The string to encrypt.
        mode: 0|C1C3C2默认, 1|C1C2C3

    Returns:
        The encrypted data as a hex string.
    """
    return _calc.calc_Sm2_decode(priv_key, data, mode)

def sm3_encode(plaintext):
    """Computes the SM3 hash of a string.

    Args:
        plaintext: The string to hash.

    Returns:
        The SM3 hash as a hex string.
    """
    return _calc.calc_Sm3_encode(plaintext)


def sm4_encrypt_cbc_base64(plaintext, key):
    """Encrypts a string using SM4 in CBC mode and returns a Base64 string.

    Args:
        plaintext: The string to encrypt.
        key: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Sm4_encrypt_cbc_base64(plaintext, key)


def sm4_decrypt_cbc_base64(ciphertext_base64, key):
    """Decrypts a Base64 string using SM4 in CBC mode.

    Args:
        ciphertext_base64: The Base64-encoded ciphertext.
        key: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Sm4_decrypt_cbc_base64(ciphertext_base64, key)


def sm4_encrypt_cbc_hex(plaintext, key):
    """Encrypts a string using SM4 in CBC mode and returns a hex string.

    Args:
        plaintext: The string to encrypt.
        key: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Sm4_encrypt_cbc_hex(plaintext, key)


def sm4_decrypt_cbc_hex(ciphertext_hex, key):
    """Decrypts a hex string using SM4 in CBC mode.

    Args:
        ciphertext_hex: The hex-encoded ciphertext.
        key: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Sm4_decrypt_cbc_hex(ciphertext_hex, key)


def sm4_encrypt_ecb_base64(plaintext, key):
    """Encrypts a string using SM4 in ECB mode and returns a Base64 string.

    Args:
        plaintext: The string to encrypt.
        key: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Sm4_encrypt_ecb_base64(plaintext, key)


def sm4_decrypt_ecb_base64(ciphertext_base64, key):
    """Decrypts a Base64 string using SM4 in ECB mode.

    Args:
        ciphertext_base64: The Base64-encoded ciphertext.
        key: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Sm4_decrypt_ecb_base64(ciphertext_base64, key)


def sm4_encrypt_ecb_hex(plaintext, key):
    """Encrypts a string using SM4 in ECB mode and returns a hex string.

    Args:
        plaintext: The string to encrypt.
        key: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Sm4_encrypt_ecb_hex(plaintext, key)


def sm4_decrypt_ecb_hex(ciphertext_hex, key):
    """Decrypts a hex string using SM4 in ECB mode.

    Args:
        ciphertext_hex: The hex-encoded ciphertext.
        key: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Sm4_decrypt_ecb_hex(ciphertext_hex, key)


def sm4_encrypt_cfb_base64(plaintext, key):
    """Encrypts a string using SM4 in CFB mode and returns a Base64 string.

    Args:
        plaintext: The string to encrypt.
        key: The secret key.

    Returns:
        The encrypted data, encoded as a Base64 string.
    """
    return _calc.calc_Sm4_encrypt_cfb_base64(plaintext, key)


def sm4_decrypt_cfb_base64(ciphertext_base64, key):
    """Decrypts a Base64 string using SM4 in CFB mode.

    Args:
        ciphertext_base64: The Base64-encoded ciphertext.
        key: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Sm4_decrypt_cfb_base64(ciphertext_base64, key)


def sm4_encrypt_cfb_hex(plaintext, key):
    """Encrypts a string using SM4 in CFB mode and returns a hex string.

    Args:
        plaintext: The string to encrypt.
        key: The secret key.

    Returns:
        The encrypted data, encoded as a hex string.
    """
    return _calc.calc_Sm4_encrypt_cfb_hex(plaintext, key)


def sm4_decrypt_cfb_hex(ciphertext_hex, key):
    """Decrypts a hex string using SM4 in CFB mode.

    Args:
        ciphertext_hex: The hex-encoded ciphertext.
        key: The secret key.

    Returns:
        The original plaintext string.
    """
    return _calc.calc_Sm4_decrypt_cfb_hex(ciphertext_hex, key)


# --- Hashing & HMAC ---

def md5_encode(content):
    """Computes the MD5 hash of a string.

    Args:
        content: The string to hash.

    Returns:
        The MD5 hash as a hex string.
    """
    return _calc.calc_Md5_encode(content)


def sha1_encode(content):
    """Computes the SHA1 hash of a string.

    Args:
        content: The string to hash.

    Returns:
        The SHA1 hash as a hex string.
    """
    return _calc.calc_Sha1_encode(content)


def sha256_encode(content):
    """Computes the SHA256 hash of a string.

    Args:
        content: The string to hash.

    Returns:
        The SHA256 hash as a hex string.
    """
    return _calc.calc_Sha256_encode(content)


def sha512_encode(content):
    """Computes the SHA512 hash of a string.

    Args:
        content: The string to hash.

    Returns:
        The SHA512 hash as a hex string.
    """
    return _calc.calc_Sha512_encode(content)


def hmac_sha1(message, key_input):
    """Computes the HMAC-SHA1 hash of a message.

    Args:
        message: The message string to hash.
        key_input: The secret key.

    Returns:
        The resulting HMAC-SHA1 hash as a hex string.
    """
    return _calc.calc_Hmac_sha1(message, key_input)


def hmac_sha256(message, key_input):
    """Computes the HMAC-SHA256 hash of a message.

    Args:
        message: The message string to hash.
        key_input: The secret key.

    Returns:
        The resulting HMAC-SHA256 hash as a hex string.
    """
    return _calc.calc_Hmac_sha256(message, key_input)


def hmac_sha512(message, key_input):
    """Computes the HMAC-SHA512 hash of a message.

    Args:
        message: The message string to hash.
        key_input: The secret key.

    Returns:
        The resulting HMAC-SHA512 hash as a hex string.
    """
    return _calc.calc_Hmac_sha512(message, key_input)