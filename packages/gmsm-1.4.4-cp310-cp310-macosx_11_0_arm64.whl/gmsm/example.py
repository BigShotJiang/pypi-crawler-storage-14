"""
MIT License

Copyright (c) 2024-present Jimmy Huang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import gmsm

# --- SM2 加解密 ---
# mode 0|C1C3C2默认, 1|C1C2C3
pub_key = '04e581fb5575aa046c4e00e1c893cdfd461b8276a7850730389573bffa3ce5e49f51a08d729834b13556fcf43891ecd2f5d02ce3a2948a375ade931c7de8e1e88d'
plaintext = 'hello world'
encrypted_hex = gmsm.sm2_encode(pub_key, plaintext, 0)
print(f"SM2 Encrypted (Hex): {encrypted_hex}")

priv_key = '3f9347edfafacdf29f1b968734110ec71aefae215030807dde3167875453b8ff'
decrypted = gmsm.sm2_decode(priv_key, encrypted_hex, 0) #解密时如果encrypted_hex开头不带04需要自己加上04
print(f"SM2 Decrypted: {decrypted}")

# --- SM4 加密 (输出为Hex) ---
key = '3l5a8r6h2o4s7c5p'
plaintext = 'hello world'
encrypted_hex = gmsm.sm4_encrypt_cbc_hex(plaintext, key)
print(f"SM4 Encrypt CBC (Hex): {encrypted_hex}")

decrypted = gmsm.sm4_decrypt_cbc_hex(encrypted_hex, key)
print(f"SM4 Decrypt CBC: {decrypted}")

encrypted_base64 = gmsm.sm4_encrypt_ecb_base64(plaintext, key)
print(f"SM4 Encrypt ECB (Base64): {encrypted_base64}")

decrypted = gmsm.sm4_decrypt_ecb_base64(encrypted_base64, key)
print(f"SM4 Decrypt ECB (Base64): {decrypted}")

# --- SM3 ---
plaintext = 'hello world'
sm3_hashed = gmsm.sm3_encode(plaintext)
print(f"SM3 {sm3_hashed}")

# --- AES Key ---
# AES-128 -> 16 个字符 (纯英文/数字)
# AES-192 -> 24 个字符
# AES-256 -> 32 个字符

# 密钥必须是字符串、如果为Base64需要手动转换
aeskey = '687b37450d97ce55389c718a16b56a1b'

# --- AES CBC 加密 (输出为Base64) ---
plaintext = 'hello world'
aes_cbc_encrypted = gmsm.aes_encrypt_cbc_base64(plaintext, aeskey)
print(f"AES CBC Encrypt: {aes_cbc_encrypted}")

# --- AES CBC 解密 (输入为Base64) ---
aes_cbc_encrypted_b64 = 'GWPVtL6EP7ZvlUorFgFU6Q=='
aes_cbc_decrypted_text = gmsm.aes_decrypt_cbc_base64(aes_cbc_encrypted_b64, aeskey)
print(f"AES CBC Decrypted: {aes_cbc_decrypted_text}")

# --- SHA256 ---
content_to_hash = "this is a very important message"
hash_result = gmsm.sha256_encode(content_to_hash)
print(f"SHA256: {hash_result}")


# --- HMAC ---
message = "data=payload&timestamp=1655186720"
hmac_key = "my-secret-api-key"
signature = gmsm.hmac_sha256(message, hmac_key)
print(f"HMAC Signature: {signature}")