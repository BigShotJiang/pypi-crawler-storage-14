#!/usr/bin/env python3
"""
Example: Single Symbol Backtest with Backtrader

This example demonstrates a simple moving average crossover strategy
on a single symbol using the DatahubStore integration.

Requirements:
- Trading Data Server running on http://localhost:8000
- backtrader installed: pip install backtrader
"""

import backtrader as bt
from trading_data_client.backtrader import DatahubStore
from datetime import datetime


class SMACrossStrategy(bt.Strategy):
    """
    Simple Moving Average Crossover Strategy.
    
    Buy when fast SMA crosses above slow SMA.
    Sell when fast SMA crosses below slow SMA.
    """
    
    params = (
        ('fast_period', 10),
        ('slow_period', 30),
    )
    
    def __init__(self):
        # Create indicators
        self.sma_fast = bt.indicators.SMA(
            self.data.close,
            period=self.p.fast_period
        )
        self.sma_slow = bt.indicators.SMA(
            self.data.close,
            period=self.p.slow_period
        )
        
        # Create crossover signal
        self.crossover = bt.indicators.CrossOver(
            self.sma_fast,
            self.sma_slow
        )
    
    def log(self, txt, dt=None):
        """Logging function"""
        dt = dt or self.datas[0].datetime.date(0)
        print(f'{dt.isoformat()} {txt}')
    
    def notify_order(self, order):
        """Notification of order status"""
        if order.status in [order.Submitted, order.Accepted]:
            return
        
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(
                    f'BUY EXECUTED, Price: {order.executed.price:.2f}, '
                    f'Cost: {order.executed.value:.2f}, '
                    f'Comm: {order.executed.comm:.2f}'
                )
            elif order.issell():
                self.log(
                    f'SELL EXECUTED, Price: {order.executed.price:.2f}, '
                    f'Cost: {order.executed.value:.2f}, '
                    f'Comm: {order.executed.comm:.2f}'
                )
        
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')
    
    def notify_trade(self, trade):
        """Notification of trade status"""
        if not trade.isclosed:
            return
        
        self.log(f'TRADE PROFIT, Gross: {trade.pnl:.2f}, Net: {trade.pnlcomm:.2f}')
    
    def next(self):
        """Strategy logic executed for each bar"""
        # Log current close price
        self.log(f'Close: {self.data.close[0]:.2f}')
        
        # Check if we have a position
        if not self.position:
            # Not in market - check for buy signal
            if self.crossover > 0:  # Fast crosses above slow
                self.log(f'BUY CREATE, {self.data.close[0]:.2f}')
                self.buy()
        else:
            # In market - check for sell signal
            if self.crossover < 0:  # Fast crosses below slow
                self.log(f'SELL CREATE, {self.data.close[0]:.2f}')
                self.sell()


def run_backtest():
    """Run the backtest"""
    
    # Create Cerebro engine
    cerebro = bt.Cerebro()
    
    # Create store
    print("Connecting to Trading Data Server...")
    store = DatahubStore(
        server_url='http://localhost:8000',
        timeout=30,
        max_retries=3
    )
    
    # Create data feed
    print("Creating data feed for AAPL...")
    data = store.getdata(
        symbol='AAPL',
        fromdate=datetime(2023, 1, 1),
        todate=datetime(2023, 12, 31),
        timeframe=bt.TimeFrame.Days
    )
    
    # Add data to Cerebro
    cerebro.adddata(data)
    
    # Add strategy
    cerebro.addstrategy(SMACrossStrategy)
    
    # Set broker
    broker = store.getbroker()
    cerebro.setbroker(broker)
    
    # Set initial cash
    cerebro.broker.setcash(100000.0)
    
    # Set commission
    cerebro.broker.setcommission(commission=0.001)  # 0.1%
    
    # Add analyzers
    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
    cerebro.addanalyzer(bt.analyzers.Returns, _name='returns')
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
    
    # Print starting conditions
    print('\n' + '='*60)
    print('Starting Portfolio Value: ${:.2f}'.format(cerebro.broker.getvalue()))
    print('='*60 + '\n')
    
    # Run backtest
    results = cerebro.run()
    
    # Print ending conditions
    print('\n' + '='*60)
    print('Final Portfolio Value: ${:.2f}'.format(cerebro.broker.getvalue()))
    print('='*60 + '\n')
    
    # Print analysis
    strat = results[0]
    
    print('Performance Metrics:')
    print('-' * 60)
    
    # Sharpe Ratio
    sharpe = strat.analyzers.sharpe.get_analysis()
    sharpe_ratio = sharpe.get('sharperatio', 0)
    if sharpe_ratio:
        print(f'Sharpe Ratio: {sharpe_ratio:.2f}')
    else:
        print('Sharpe Ratio: N/A')
    
    # Returns
    returns = strat.analyzers.returns.get_analysis()
    print(f'Total Return: {returns["rtot"]:.2%}')
    print(f'Average Return: {returns["ravg"]:.2%}')
    
    # Drawdown
    drawdown = strat.analyzers.drawdown.get_analysis()
    print(f'Max Drawdown: {drawdown["max"]["drawdown"]:.2%}')
    print(f'Max Drawdown Period: {drawdown["max"]["len"]} days')
    
    # Trades
    trades = strat.analyzers.trades.get_analysis()
    print(f'\nTotal Trades: {trades.total.closed}')
    print(f'Winning Trades: {trades.won.total}')
    print(f'Losing Trades: {trades.lost.total}')
    if trades.total.closed > 0:
        win_rate = trades.won.total / trades.total.closed * 100
        print(f'Win Rate: {win_rate:.1f}%')
    
    print('='*60 + '\n')
    
    # Plot results
    print("Generating plot...")
    cerebro.plot(style='candlestick')


if __name__ == '__main__':
    run_backtest()
