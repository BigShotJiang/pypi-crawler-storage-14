"""
Backtrader Data Feed implementation for Trading Data Server.

Design: .kiro/specs/backtrader-store-integration/design.md (DatahubData component)
Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 12.2
Interface: .kiro/specs/backtrader-store-integration/interfaces.md (DatahubData)
"""

import logging
from datetime import datetime
from typing import List, Dict, Optional

import backtrader as bt

from .converter import DataConverter
from .exceptions import ConfigurationError, DataError, ExceptionTranslator

logger = logging.getLogger(__name__)


class DatahubData(bt.DataBase):
    """
    Backtrader Data Feed for Trading Data Server.
    
    Fetches historical OHLCV data from Trading Data Server and delivers
    bars to backtrader strategies in chronological order.
    
    Design Pattern: Adapter Pattern - adapts server data to backtrader interface
    
    Attributes:
        params: Feed parameters (symbol, fromdate, todate, timeframe, compression)
        _bars: List of fetched bars in backtrader format
        _bar_index: Current position in bars list
        _started: Whether feed has been started
    
    Example:
        >>> store = DatahubStore(server_url='http://localhost:8000')
        >>> data = DatahubData(
        ...     dataname='AAPL',
        ...     fromdate=datetime(2023, 1, 1),
        ...     todate=datetime(2023, 12, 31),
        ...     timeframe=bt.TimeFrame.Days
        ... )
        >>> data._store = store
        >>> cerebro.adddata(data)
    """
    
    params = (
        ('symbol', None),                    # Ticker symbol
        ('fromdate', None),                  # Start date
        ('todate', None),                    # End date
        ('timeframe', bt.TimeFrame.Days),    # Timeframe
        ('compression', 1),                  # Compression factor
        ('historical', True),                # Historical mode (always True for now)
    )
    
    def __init__(self, **kwargs):
        """
        Initialize data feed.
        
        Validates parameters and initializes internal state.
        
        Args:
            **kwargs: Feed parameters (passed to parent class)
        
        Raises:
            ConfigurationError: If parameters are invalid
        """
        super(DatahubData, self).__init__(**kwargs)
        
        # Validate parameters
        self._validate_params()
        
        # Internal state
        self._bars: List[Dict] = []
        self._bar_index: int = 0
        self._started: bool = False
        
        # Backtrader required attributes
        self._tzinput = None  # Timezone for input data
        self._tz = None  # Timezone for output data
        self.fromdate = self.p.fromdate  # Make fromdate accessible as attribute
        self.todate = self.p.todate  # Make todate accessible as attribute
        
        logger.info(
            f"DatahubData initialized: symbol={self.p.symbol}, "
            f"fromdate={self.p.fromdate}, todate={self.p.todate}, "
            f"timeframe={self.p.timeframe}, compression={self.p.compression}"
        )
    
    def _validate_params(self) -> None:
        """
        Validate feed parameters.
        
        Raises:
            ConfigurationError: If any parameter is invalid
        """
        # Validate symbol
        if not self.p.symbol:
            raise ConfigurationError("symbol cannot be empty")
        
        if not isinstance(self.p.symbol, str):
            raise ConfigurationError("symbol must be a string")
        
        if len(self.p.symbol) < 1 or len(self.p.symbol) > 10:
            raise ConfigurationError("symbol must be between 1 and 10 characters")
        
        # Validate dates
        if not self.p.fromdate:
            raise ConfigurationError("fromdate is required")
        
        if not self.p.todate:
            raise ConfigurationError("todate is required")
        
        if not isinstance(self.p.fromdate, datetime):
            raise ConfigurationError("fromdate must be a datetime object")
        
        if not isinstance(self.p.todate, datetime):
            raise ConfigurationError("todate must be a datetime object")
        
        if self.p.fromdate >= self.p.todate:
            raise ConfigurationError("fromdate must be before todate")
        
        # Validate timeframe
        if not isinstance(self.p.timeframe, int):
            raise ConfigurationError("timeframe must be a backtrader TimeFrame constant")
        
        # Validate compression
        if not isinstance(self.p.compression, int):
            raise ConfigurationError("compression must be an integer")
        
        if self.p.compression < 1:
            raise ConfigurationError("compression must be positive")
        
        # Validate timeframe/compression combination is supported
        try:
            DataConverter.timeframe_to_server_string(
                self.p.timeframe,
                self.p.compression
            )
        except ValueError as e:
            raise ConfigurationError(f"Unsupported timeframe/compression combination: {e}")
    
    def start(self) -> None:
        """
        Start the feed and fetch historical data.
        
        Called by backtrader when the feed starts. Fetches all historical
        data from the Trading Data Server and stores it for iteration.
        
        Raises:
            ConnectionError: If server is unreachable
            ServerError: If server returns error
            DataError: If no valid data available
        """
        if self._started:
            logger.warning("DatahubData already started, ignoring duplicate start()")
            return
        
        logger.info(f"Starting DatahubData for {self.p.symbol}")
        
        try:
            # Get store and client
            if not hasattr(self, '_store') or self._store is None:
                raise ConfigurationError(
                    "Data feed not associated with store. "
                    "Use store.getdata() to create feeds."
                )
            
            client = self._store.get_client()
            
            # Convert timeframe to server format
            timeframe_str = DataConverter.timeframe_to_server_string(
                self.p.timeframe,
                self.p.compression
            )
            
            # Fetch historical data from server
            logger.info(
                f"Fetching historical data: symbol={self.p.symbol}, "
                f"start={self.p.fromdate}, end={self.p.todate}, "
                f"timeframe={timeframe_str}"
            )
            
            server_bars = client.get_historical_bars(
                symbol=self.p.symbol,
                start=self.p.fromdate,
                end=self.p.todate,
                timeframe=timeframe_str
            )
            
            # Convert bars to backtrader format
            self._bars = []
            invalid_count = 0
            
            for bar in server_bars:
                try:
                    bt_bar = DataConverter.server_to_backtrader_bar(bar)
                    
                    # Validate bar
                    if DataConverter.validate_bar(bt_bar):
                        self._bars.append(bt_bar)
                    else:
                        invalid_count += 1
                        logger.warning(
                            f"Invalid bar skipped: {bar.timestamp} "
                            f"(symbol={self.p.symbol})"
                        )
                except ValueError as e:
                    invalid_count += 1
                    logger.warning(
                        f"Failed to convert bar: {e} "
                        f"(symbol={self.p.symbol})"
                    )
            
            # Sort bars by datetime (should already be sorted, but ensure it)
            self._bars.sort(key=lambda b: b['datetime'])
            
            # Log results
            logger.info(
                f"Fetched {len(self._bars)} bars for {self.p.symbol} "
                f"({invalid_count} invalid bars skipped)"
            )
            
            if len(self._bars) == 0:
                logger.warning(
                    f"No valid data available for {self.p.symbol} "
                    f"in range {self.p.fromdate} to {self.p.todate}"
                )
            
            # Reset index and mark as started
            self._bar_index = 0
            self._started = True
            
        except Exception as e:
            # Translate exception to backtrader-compatible error
            translated = ExceptionTranslator.translate(e)
            logger.error(
                f"Failed to start DatahubData for {self.p.symbol}: {translated}"
            )
            raise translated
    
    def _load(self) -> bool:
        """
        Load next bar. Called by backtrader for each bar.
        
        Delivers the next bar to backtrader by updating the data lines.
        Returns False when no more bars are available.
        
        Returns:
            True if bar loaded successfully, False if no more bars
        """
        if not self._started:
            logger.error("_load() called before start()")
            return False
        
        # Check if more bars available
        if self._bar_index >= len(self._bars):
            logger.debug(f"No more bars for {self.p.symbol}")
            return False
        
        # Get next bar
        bar = self._bars[self._bar_index]
        self._bar_index += 1
        
        # Update backtrader data lines
        self.lines.datetime[0] = bt.date2num(bar['datetime'])
        self.lines.open[0] = bar['open']
        self.lines.high[0] = bar['high']
        self.lines.low[0] = bar['low']
        self.lines.close[0] = bar['close']
        self.lines.volume[0] = bar['volume']
        self.lines.openinterest[0] = bar['openinterest']
        
        logger.debug(
            f"Loaded bar {self._bar_index}/{len(self._bars)}: "
            f"{bar['datetime']} O={bar['open']} H={bar['high']} "
            f"L={bar['low']} C={bar['close']} V={bar['volume']}"
        )
        
        return True
    
    def stop(self) -> None:
        """
        Stop the feed and cleanup resources.
        
        Called by backtrader when the feed stops. Releases memory
        and resets internal state.
        
        Idempotent - safe to call multiple times.
        """
        if not self._started:
            return
        
        logger.info(
            f"Stopping DatahubData for {self.p.symbol} "
            f"({self._bar_index}/{len(self._bars)} bars delivered)"
        )
        
        # Clear bars to release memory
        self._bars.clear()
        self._bar_index = 0
        self._started = False
        
        logger.info(f"DatahubData stopped for {self.p.symbol}")
