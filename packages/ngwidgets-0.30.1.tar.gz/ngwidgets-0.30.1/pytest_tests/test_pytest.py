"""
Created on 2024-09-11

@author: wf
"""


def func(x):
    return x + 1


def test_answer():
    assert func(4) == 5
