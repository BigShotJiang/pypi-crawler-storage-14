VERSION = "0.29.0"
VENDOR = "qtoggle/qtoggleserver"
