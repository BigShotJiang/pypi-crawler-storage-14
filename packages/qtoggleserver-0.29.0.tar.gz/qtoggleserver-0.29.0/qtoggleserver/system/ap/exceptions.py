class APException(Exception):
    pass
