class Error(Exception):
    pass


class BadRequestException(Error):
    pass


class UnauthorizedException(Error):
    pass
