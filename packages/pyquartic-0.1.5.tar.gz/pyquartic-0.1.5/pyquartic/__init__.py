from . import pyquartic as _ext

solve_cubic = _ext.solve_cubic
solve_cubic_one = _ext.solve_cubic_one
solve_quartic = _ext.solve_quartic
