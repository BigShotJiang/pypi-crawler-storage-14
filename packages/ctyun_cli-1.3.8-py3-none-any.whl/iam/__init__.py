"""
统一身份认证(IAM)服务模块
"""

from .client import IAMClient

__all__ = ['IAMClient']