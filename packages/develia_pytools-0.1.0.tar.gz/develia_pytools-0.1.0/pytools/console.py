from contextlib import contextmanager as _contextmanager


@_contextmanager
def run(text: str):
    from pytools.timetools import Stopwatch
    from pytools.strings import pluralize

    print(text, end='')
    try:
        with Stopwatch() as sw:
            yield None
        total_seconds = sw.elapsed.total_seconds()

        if total_seconds < 60:
            unit = pluralize(total_seconds, 'second', 'seconds')
            n = total_seconds
        elif total_seconds < 60 * 60:
            unit = pluralize(total_seconds, 'minute', 'minutes')
            n = total_seconds / 60
        else:
            unit = pluralize(total_seconds, 'hour', 'hours')
            n = total_seconds / 60 / 60

        print(f" Done in {str(round(n, 2))} {unit}.")
    except Exception as ex:
        print(" Error: " + str(ex))
        raise
