import typing as _t


def pickle_deserialize(file: str, encoding: str = 'ASCII') -> _t.Any:
    import pickle
    with open(file, "rb") as file:
        return pickle.load(file=file, encoding=encoding)


def pickle_serialize(file: str, obj: _t.Any, protocol: _t.Optional[int] = None) -> None:
    import pickle
    with open(file, "wb") as file:
        return pickle.dump(obj=obj, file=file, protocol=protocol)


def json_serialize(file: str, obj: _t.Any) -> None:
    import json
    from pytools import io
    io.write_file(file, json.dumps(obj))


def json_deserialize(file: str) -> _t.Any:
    import json
    from pytools import io
    return json.loads(io.read_file(file))
