import typing as _typing


def parse_float(string: str,
                decimal_separator: str = ".",
                thousands_separator: str = ",",
                fallback=None) -> _typing.Any:
    try:
        if thousands_separator != ",":
            string = string.replace(thousands_separator, "")
        if decimal_separator != ".":
            string = string.replace(decimal_separator, ".")
        return float(string)

    except ValueError as exception:
        if fallback is not None:
            from pytools import evaluate
            return evaluate(fallback)
        else:
            raise exception


def parse_int(string: str,
              thousands_separator: str = ",",
              fallback=None) -> _typing.Any:
    try:
        if thousands_separator != ".":
            string = string.replace(thousands_separator, "")
        return int(string)

    except ValueError as exception:
        if fallback is not None:
            from pytools import evaluate
            return evaluate(fallback)
        else:
            raise exception
