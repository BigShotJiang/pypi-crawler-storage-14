def remove_suffix(string: str, suffix: str, case_sensitive: bool = True) -> str:
    if not case_sensitive:
        string = string.lower()
        suffix = suffix.lower()

    if string.endswith(suffix):
        return string[: -len(suffix)]
    else:
        return string


def remove_prefix(string: str, prefix: str, case_sensitive: bool = True) -> str:
    if not case_sensitive:
        string_lower = string.lower()
        prefix_lower = prefix.lower()
    else:
        string_lower = string
        prefix_lower = prefix

    if string_lower.startswith(prefix_lower):
        return string[len(prefix):]
    else:
        return string


def ensure_suffix(string: str, suffix: str) -> str:
    return string if string.endswith(suffix) else string + suffix


def ensure_prefix(string: str, prefix: str) -> str:
    return string if string.startswith(prefix) else prefix + string


def pluralize(n: float, singular: str, plural: str) -> str:
    if n == 1:
        return singular

    return plural
