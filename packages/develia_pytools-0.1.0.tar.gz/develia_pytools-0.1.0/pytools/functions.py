def identity(x):
    return x
