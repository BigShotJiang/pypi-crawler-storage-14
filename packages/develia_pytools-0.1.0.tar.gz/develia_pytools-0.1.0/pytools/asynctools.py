import asyncio as _asyncio
import typing as _t
from concurrent.futures import Future as _Future
from enum import Enum as _Enum
from multiprocessing import Process as _Process
from threading import Thread as _Thread

_T = _t.TypeVar('_T')


class AsyncType(_Enum):
    THREADING = "threading"
    MULTIPROCESSING = "multiprocessing"
    ASYNCIO = "asyncio"


def wait_all(tasks: _t.Optional[_t.Iterable] = None):
    tasks = [] if tasks is None else tasks
    for task in tasks:
        if isinstance(task, _Thread) or isinstance(task, _Process):
            task.join()
        elif isinstance(task, _asyncio.Task):
            _asyncio.get_running_loop().run_until_complete(task)


class EndSignal:
    def __new__(cls, *args, **kwargs):
        return cls


def run(func: _t.Callable[[], _T],
        async_type: _t.Optional[_t.Union[AsyncType, str]] = AsyncType.THREADING,
        *args,
        **kwarg) -> _Future[_T]:
    future = _Future()

    def job():
        try:
            future.set_result(func())
        except Exception as ex:
            future.set_exception(ex)

    if async_type == AsyncType.THREADING or async_type == AsyncType.THREADING.value:
        thread = _Thread(target=job, *args, **kwarg)
        thread.start()
        return future
    elif async_type == AsyncType.MULTIPROCESSING or async_type == AsyncType.MULTIPROCESSING.value:
        process = _Process(target=job, *args, **kwarg)
        process.start()
        return future

    raise ValueError("async_type")
