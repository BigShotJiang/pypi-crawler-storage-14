import typing as _t

_T = _t.TypeVar('_T')
_R = _t.TypeVar("_R")


class CircularQueue(_t.Sequence[_T]):

    def enqueue(self, item: _T):
        if len(self._queue) >= self._capacity:
            self[self._head] = item
            self._head = (self._head + 1) % len(self._queue)
        else:
            self._queue.append(item)

    def __setitem__(self, i: int, item: _T):
        self._queue[(i + self._head) % self._capacity] = item

    def __getitem__(self, i: int) -> _T:
        return self._queue[(i + self._head) % len(self._queue)]

    def __iter__(self) -> _t.Iterator[_T]:
        for i in range(len(self)):
            yield self[i]

    @property
    def capacity(self):
        return self._capacity

    def __init__(self, capacity: int):
        self._capacity = capacity
        self._queue = []
        self._head = 0

    def clear(self):
        self._queue = []
        self._head = 0

    def dequeue(self, n=None):
        if n is None:
            output = self._queue.pop(self._head)
            return output
        else:
            return [self.dequeue(None) for _ in range(n)]

    def __len__(self) -> int:
        return len(self._queue)


class BidirectionalDict:
    def __init__(self, initial_data: _t.Optional[_t.Dict] = None):
        self._keys = list()
        self._values = list()

        if initial_data is not None:
            for k, v in initial_data.items():
                self._keys.append(k)
                self._values.append(v)

    def set_value(self, key, value):
        try:
            key_index = self._keys.index(key)
            self._values[key_index] = value
        except ValueError:
            self._keys.append(key)
            self._values.append(value)

    def get_value(self, key):
        key_index = self._keys.index(key)
        return self._values[key_index]

    def get_key(self, value):
        value_index = self._values.index(value)
        return self._keys[value_index]

    def __getitem__(self, item):
        return self.get_value(item)

    def __setitem__(self, item, value):
        return self.set_value(item, value)


class EnhancedDefaultDict(dict):
    def __init__(self, factory):
        self._factory = factory
        super().__init__()

    def __missing__(self, key):
        item = self._factory(key)
        self[key] = item
        return item
