import threading as _threading
import typing as _t

_T = _t.TypeVar("_T")


class Lazy(_t.Generic[_T]):
    def __init__(self, factory_method: _t.Callable[[], _T], lock=None):
        self._factory_method = factory_method
        self._value_created = False
        self._value = None
        self._lock = lock if lock is not None else _threading.RLock()

    @property
    def value_created(self) -> bool:
        return self._value_created

    @property
    def value(self) -> _T:
        with self._lock:
            if not self._value_created:
                self._value = self._factory_method()
                self._value_created = True

            return self._value

    def __repr__(self):  # pragma: no cover
        with self._lock:
            if self._value_created:
                return repr(self._value)

            return "Value not created yet."
