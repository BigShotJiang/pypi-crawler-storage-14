import contextlib
import posixpath
import time
from ftplib import FTP_TLS, FTP


class FtpClient(contextlib.AbstractContextManager):

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if self._client is not None:
                self._client.quit()
        except:
            pass

    def __init__(self, host, username, password, secure=False):
        self._host = host
        self._username = username
        self._password = password
        self._secure = secure
        self._client = self._get_client(self._host, self._username, self._password, self._secure)

    def _try_command(self, callable):
        while True:
            try:
                return callable()
            except OSError as ex:

                if ex.errno == 10054 or ex.errno == 10013 or ex.errno == 10053:
                    try:
                        self._client.quit()
                    except:
                        pass
                    time.sleep(5)
                    self._client = self._get_client(self._host, self._username, self._password, self._secure)
                else:
                    break

    @staticmethod
    def _get_client(host, username, password, secure):
        if secure:
            tmp = FTP_TLS(host, user=username, passwd=password)
            tmp.prot_p()
            return tmp
        return FTP(host, user=username, passwd=password)

    def dir(self, path=None):
        return self._try_command(lambda: list(self._client.mlsd(path=path)))

    def download_file(self, remote_file, local_file):
        with open(local_file, "wb") as file:
            self._try_command(lambda: self._client.retrbinary("RETR " + remote_file, file.write))

    def download_directory(self, local_root_dir, remote_dir=None):
        if remote_dir is None:
            remote_dir = self._client.pwd()

        import os
        local_dir = os.path.join(local_root_dir, remote_dir.lstrip("/"))
        if not os.path.isdir(local_dir):
            os.makedirs(local_dir, exist_ok=True)

        response = self.dir(remote_dir)
        for entry_path, props in response:
            if props['type'] == "dir":

                self.download_directory(local_root_dir, posixpath.join(remote_dir, entry_path))

            elif props['type'] == "file":

                try:
                    remote_file = posixpath.join(remote_dir, entry_path)
                    local_dir = os.path.join(local_root_dir, remote_dir.lstrip("/"))
                    local_file = os.path.join(local_dir, entry_path)

                    if not os.path.isfile(local_file):
                        self.download_file(remote_file, local_file)

                    time.sleep(0.05)
                except OSError as ex:
                    if ex.errno != 22:
                        raise ex

    def upload_file(self, local_file, remote_file):
        with open(local_file, "rb") as file:
            self._try_command(lambda: self._client.storbinary("STOR " + remote_file, file))

    def pwd(self):
        return self._try_command(lambda: self._client.pwd())

    def delete_file(self, file):
        return self._try_command(lambda: self._client.delete(file))

    def file_exists(self, file):
        try:
            self._try_command(lambda: self._client.size(file))
            return True
        except Exception:
            return False
