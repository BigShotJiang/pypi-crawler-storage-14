import typing as _t

_T = _t.TypeVar("_T")


class Range(_t.Generic[_T]):
    def __init__(self, start: _T, end: _T):
        self.end = end
        self.start = start

    def contains(self, item: _T, start_inclusive: bool = True, end_inclusive: bool = True) -> bool:
        if isinstance(item, Range):
            return self.contains(item.start, start_inclusive, end_inclusive) and self.contains(item.end, start_inclusive, end_inclusive)
        else:
            return (((item >= self.start) if start_inclusive else (item > self.start)) and
                    ((item <= self.end) if end_inclusive else (item < self.end)))

    def overlaps(self, start: _T, end: _T, inclusive: bool = True) -> bool:
        return self.overlaps_range(Range(start, end), inclusive)

    def overlaps_range(self, range: "Range[_T]", inclusive: bool = True) -> bool:
        return self.contains(range.start, inclusive) or self.contains(range.end, inclusive) or \
            range.contains(self.start, inclusive) or range.contains(self.end, inclusive)

    def split(self, size) -> _t.List[_T]:

        output = []

        interval = Range(self.start, min(self.start + size, self.end))

        while self.contains(interval):
            output.append(interval)
            interval = Range(interval.start + size, min(interval.end + size, self.end))

        return output

    def __str__(self):
        return str(self.start) + " - " + str(self.end)

    def intersect(self, other: 'Range[_T]') -> _t.Optional['Range[_T]']:
        # Lógica para la intersección de intervalos
        start = max(self.start, other.start)
        end = min(self.end, other.end)
        if start < end:
            return Range(start, end)
        else:
            return None

    def subtract(self, other):
        if self.start >= other.end or self.end <= other.start:
            # No hay intersección
            return [Range(self.start, self.start)]
        elif other.start <= self.start and other.end >= self.end:
            # B cubre completamente A
            return []
        else:
            # Intersección parcial
            result = []
            if self.start < other.start:
                result.append(Range(self.start, other.start))
            if self.end > other.end:
                result.append(Range(other.end, self.end))
            return result

    def __and__(self, other) -> _t.Optional['Range[_T]']:
        return self.intersect(other)

    def __sub__(self, other) -> _t.List["Range[_T]"]:
        return self.subtract(other)
