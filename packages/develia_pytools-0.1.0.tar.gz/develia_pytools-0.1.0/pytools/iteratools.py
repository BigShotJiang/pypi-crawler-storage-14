import collections
import itertools as _itertools
import multiprocessing
import threading
import typing as _t

_T = _t.TypeVar("_T")
_R = _t.TypeVar("_R")

_builtin_filter = filter
_builtin_map = map
_builtin_reversed = reversed

_Predicate = _t.Union[_t.Callable[[_T], bool]]
_Mapper = _t.Union[_t.Callable[[_T], _R]]


def highest(iterable: _t.Iterable[_T], mapper: _t.Callable[[_T], _R]) -> _T:
    """
    Find the item with the highest value in an iterable, using a mapper function.

    :param iterable: An iterable containing items.
    :param mapper: A callable function that maps each item in the iterable to a value.
    :return: The item from the iterable with the highest value according to the mapper function.

    Example usage:
    --------------
    >>> numbers = [1, 2, 3, 4, 5]
    >>> highest(numbers, lambda x: x * 2)
    5

    >>> words = ["apple", "banana", "orange"]
    >>> highest(words, len)
    "banana"

    """
    max_value = None
    output = None

    for item in iterable:
        value = mapper(item)
        if output is None or value > max_value:
            output = item
            max_value = value

    return output


def lowest(iterable: _t.Iterable[_T], mapper: _t.Callable[[_T], _R]) -> _T:
    """
    :param iterable: The iterable containing the items to be evaluated.
    :param mapper: The function used to map each item in the iterable to a value.
    :return: The item from the iterable with the lowest mapped value.

    This method iterates through the given iterable, mapping each item using the provided mapper function. It then returns the item from the iterable with the lowest mapped value. If multiple
    * items have the same lowest mapped value, the method returns the first one encountered.

    Example usage:
    ```python
    numbers = [1, 2, 3, 4, 5]
    def square(x):
        return x * x

    lowest_num = lowest(numbers, square)
    print(lowest_num) # Output: 1
    ```
    """
    min_value = None
    output = None

    for item in iterable:
        value = mapper(item)
        if output is None or value < min_value:
            output = item
            min_value = value

    return output


def groupby(array: _t.Iterable[_T], group_fn: _t.Callable[[_T], _R], selector: _t.Callable[[_R, _t.List[_T]], _t.Any] = None) -> _t.Dict[_R, _t.Any]:
    """
    Groups elements from the given array based on the result of the group_fn function.

    :param array: The iterable containing the elements to be grouped.
    :param group_fn: A callable function that determines the group of each element.
    :param selector: An optional callable function that selects the desired value for each group. If not provided,
                     the grouped elements will be returned as a list.
    :return: A dictionary containing each group as key and the selected value or the grouped elements as value.

    Example Usage:
    >>> array = [1, 2, 3, 4, 5, 6]
    >>> def group_fn(x): return x % 2 == 0
    >>> groupby(array, group_fn)
    {True: [2, 4, 6], False: [1, 3, 5]}

    >>> array = [1, 2, 3, 4, 5, 6]
    >>> def group_fn(x): return x % 2 == 0
    >>> def selector(k, v): return sum(v)
    >>> groupby(array, group_fn, selector)
    {True: 12, False: 9}
    """
    keys = []
    values = []

    for item in array:
        key = group_fn(item)
        try:
            index = keys.index(key)
            values[index].append(item)
        except ValueError:
            keys.append(key)
            values.append([item])

    output = {}
    for k, v in zip(keys, values):
        output[k] = selector(k, v) if selector else v

    return output


def thread_safe_iter(it: _t.Iterable[_T], lock: _t.Union[threading.Lock, multiprocessing.Lock] = None) -> _t.Iterable[_T]:
    """
    :param it: An iterable object to be iterated over in a thread-safe manner.
    :param lock: A lock object used for synchronization. If not provided, a threading.Lock is used by default.
    :return: An iterable object that yields values from the input iterable in a thread-safe manner.

    This method takes an input iterable object `it` and a lock object `lock` (optional). The method returns an iterable object that can be safely iterated over from multiple threads.

    The method begins by creating an iterator from the input iterable using the `iter()` function. If a lock object is not provided, a threading.Lock object is created.

    The method enters an infinite loop, continuously trying to retrieve the next value from the iterator using the `next()` function. In each loop iteration, a lock is acquired using the
    * `with` statement to ensure mutual exclusion. This prevents multiple threads from accessing the iterator concurrently.

    If the `next()` function raises a StopIteration exception, it means that there are no more values left in the iterator. In this case, the method returns, ending the loop.

    Otherwise, the method yields the retrieved value, allowing the caller to process it. The lock is automatically released when exiting the `with` block.

    Example usage:

    ```
    lst = [1, 2, 3, 4, 5]

    # Using the method with default lock
    for num in thread_safe_iter(lst):
        print(num)

    # Using the method with custom lock
    lock = threading.Lock()
    for num in thread_safe_iter(lst, lock):
        print(num)
    ```
    """
    it = iter(it)

    if lock is None:
        lock = threading.Lock()

    while True:
        try:
            with lock:
                value = next(it)
        except StopIteration:
            return
        yield value


def skip_while(iterable: _t.Iterable[_T], predicate: _Predicate[_T]) -> _t.Iterable[_T]:
    """
    :param iterable: an iterable object containing elements to be skipped
    :param predicate: a function that will be applied to each element in the iterable until the predicate returns False
    :return: an iterable object containing elements after the predicate returns False

    The `skip_while` function is used to skip elements from an iterable object until a condition specified by the predicate function returns False. Once the condition is no longer satisfied
    *, the function returns the remaining elements.

    Example usage:
    ```python
    >>> numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    >>> def is_even(n):
    ...     return n % 2 == 0
    ...
    >>> result = skip_while(numbers, is_even)
    >>> list(result)
    [1, 3, 5, 7, 9, 10]
    ```
    In this example, the `skip_while` function skips all the even numbers until the first odd number, and returns the remaining elements.

    Please note that the function uses lazy evaluation, meaning that it yields values as they are requested, rather than generating the entire sequence at once. This can be useful when working
    * with large or infinite iterables.
    """
    iterator = iter(iterable)

    for item in iterator:
        if predicate(item):
            last_item = item
        else:
            break

    if "last_item" in locals():
        # noinspection PyUnboundLocalVariable
        yield last_item

    yield from iterator


def consume(iterator):
    """
    Consume an iterator without returning any value.

    :param iterator: The iterator to be consumed.
    :return: None
    """
    collections.deque(iterator, maxlen=0)


def filter(iterable: _t.Iterable[_T], fn: _t.Callable[[_T], bool]) -> _t.Iterable[_T]:
    """
    Filter the elements of an iterable based on a given function.

    :param iterable: The iterable from which to filter elements.
    :param fn: The function that will be applied to each element of the iterable. The function should return `True` for elements that should be included in the filtered iterable and `False
    *` for elements that should be excluded.
    :return: An iterable containing only the elements for which the function returns `True`.
    """
    return _builtin_filter(fn, iterable)


def map(iterable: _t.Iterable[_T], fn: _t.Callable[[_T], _R]) -> _t.Iterable[_R]:
    """
    Apply a function to each element in an iterable and return a new iterable.

    :param iterable: An iterable object.
    :param fn: A function to apply to each element in the iterable.
    :return: A new iterable with the results of applying the function to each element.
    """
    return _builtin_map(fn, iterable)


def empty() -> _t.Iterable:
    """
    Return an empty iterable.

    :return: The empty iterable.
    """
    return
    # noinspection PyUnreachableCode
    yield


def skip(iterable: _t.Iterable[_T], n: int) -> _t.Iterable[_T]:
    """
    :param iterable: An iterable object from which elements will be skipped.
    :param n: The number of elements to skip from the iterable.
    :return: An iterable object with the elements after skipping 'n' elements.
    """
    consume(_itertools.islice(iterable, n))
    return iterable


def take(iterable: _t.Iterable[_T], n: int) -> _t.Iterable[_T]:
    """
    Returns an iterable containing the first `n` elements from the given `iterable`.

    :param iterable: The iterable from which to take the elements.
    :param n: The number of elements to take.
    :return: An iterable containing the first `n` elements from the given `iterable`.
    """
    return _itertools.islice(iterable, n)


def first(iterable: _t.Iterable[_T], default: _t.Optional[_R] = None) -> _t.Union[_t.Optional[_T], _t.Optional[_R]]:
    """
    :param iterable: an iterable object from which to extract the first element
    :param default: a default value to return if the iterable is empty (default: None)
    :return: the first element of the iterable, or the default value if the iterable is empty
    """
    try:
        return next(iter(iterable))
    except StopIteration:
        return default


def rolling(iterable: _t.Iterable[_T], size=2) -> _t.Iterable[_t.List[_T]]:
    """
    :param iterable: An iterable object from which the sliding window will be created.
    :param size: The size of the sliding window. Defaults to 2.

    :return: An iterable object containing lists representing each step of the sliding window.

    """
    iterator = iter(iterable)
    output = list(take(iterator, size))
    if len(output) < size:
        return

    yield output

    for item in iterator:
        output.append(item)
        output.pop(0)
        yield output


def argmax(iterable: _t.Iterable) -> int:
    """
    :param iterable: an iterable containing elements to find the maximum value
    :return: the index of the maximum value in the iterable

    """
    output = None
    max_ = None

    for index, item in enumerate(iterable):
        if output is None or item > max_:
            max_ = item
            output = index

    return output


def argmin(iterable: _t.Iterable) -> int:
    """
    :param iterable: An iterable object containing values to find the minimum value index from.
    :return: The index of the minimum value found in the iterable.

    """
    output = None
    min_ = None

    for index, item in enumerate(iterable):
        if output is None or item <= min_:
            min_ = item
            output = index

    return output


def nth(iterable: _t.Iterable[_T], n: int, default: _t.Optional[_T] = None) -> _T:
    """
    Returns the nth item from the iterable.

    :param iterable: An iterable object from which to extract the nth item.
    :type iterable: Iterable

    :param n: The index of the item to be returned.
    :type n: int

    :param default: (Optional) A default value to return if the nth item does not exist. Defaults to None.
    :type default: Optional

    :return: The nth item from the iterable, or the default value if the nth item does not exist.
    :rtype: Any
    """
    return next(_itertools.islice(iterable, n, None), default)


def tail(iterable: _t.Iterable[_T], n: int) -> _t.Iterable[_T]:
    """
    :param iterable: The iterable from which to retrieve the tail elements.
    :param n: The number of tail elements to retrieve.
    :return: An iterable containing the last `n` elements from the input iterable.

    """
    return iter(collections.deque(iterable, maxlen=n))


def last(iterable: _t.Iterable[_T], default: _t.Optional[_R] = None) -> _t.Union[_t.Optional[_T], _t.Optional[_R]]:
    """
    Return the last element from an iterable.

    :param iterable: An iterable object.
    :param default: The default value to return if the iterable is empty. (default: None)
    :return: The last element from the iterable, or the default value if the iterable is empty.
    """
    for item in iterable:
        default = item
    return default


def flatten(iterable: _t.Iterable[_t.Iterable[_T]]) -> _t.Iterable[_T]:
    """
    Flattens a nested iterable into a single-dimensional iterable.

    :param iterable: The nested iterable to be flattened.
    :type iterable: Iterable[Iterable[_T]]
    :return: A single-dimensional iterable containing all the items from the nested iterable.
    :rtype: Iterable[_T]
    """
    for group in iterable:
        for item in group:
            yield item


def correlative(sequence: _t.List[_T], delta) -> bool:
    i = 1
    while i < len(sequence):
        if sequence[i] - sequence[i - 1] != delta:
            return False
        i = i + 1

    return True


def length(sequence: _t.Iterable) -> int:
    """
    Calculate the length of a given sequence.

    :param sequence: The sequence for which the length needs to be calculated.
    :return: The length of the sequence.
    """
    output = 0
    for _ in sequence:
        output += 1
    return output


def batch(sequence: _t.Iterable[_T], batch_size: int, drop_remainder: bool = False) -> _t.Iterable[_t.List[_T]]:
    """
    :param sequence: The input sequence to be batched.
    :param batch_size: The size of each batch.
    :param drop_remainder: Whether to drop the remaining elements if their count is less than batch_size.
    :return: An iterable of lists, where each list represents a batch of elements from the input sequence.
    """
    output = []
    for item in sequence:
        output.append(item)
        if len(output) == batch_size:
            yield output
            output = []

    if not drop_remainder and len(output) > 0:
        yield output


def shuffle(generator: _t.Iterable[_T], buffer_size: _t.Optional[int] = None) -> _t.Iterable[_T]:
    """
    Shuffles elements from a given generator using a buffer of specified size.

    :param generator: The generator that provides the elements to be shuffled.
    :param buffer_size: The number of elements to be stored in the buffer before shuffling.
    :return: An iterable that yields the shuffled elements from the generator.

    Example usage:

    ```python
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    shuffled_numbers = shuffle(numbers, 4)
    ```
    """
    import random
    iterator = iter(generator)

    if buffer_size is None or (isinstance(buffer_size, int) and buffer_size <= 0):
        buffer = list(iterator)
        random.shuffle(buffer)
        yield from buffer
        return

    while True:
        buffer = list(_itertools.islice(iterator, buffer_size))
        if len(buffer) == 0:
            break
        random.shuffle(buffer)
        for item in buffer:
            yield item


def reversed(iterable: _t.Iterable[_T]) -> _t.Iterable[_T]:
    """
    Reverse the given iterable.

    :param iterable: The iterable to be reversed.
    :return: An iterable containing the reversed elements.
    """
    if isinstance(iterable, _t.Sequence):
        for i in _builtin_reversed(range(len(iterable))):
            yield iterable[i]
    else:
        output = list(iterable)
        output.reverse()
        yield from output


def prefetch(iteratable: _t.Iterable[_T], n_prefetch=0) -> _t.Iterable[_T]:
    """
    Prefetches items from an iterable in a separate thread.

    :param iteratable: The iterable from which to prefetch items.
    :param n_prefetch: The maximum number of items to prefetch.
    :return: An iterable of prefetched items from the given iterable.

    """
    from queue import Queue
    queue = Queue(maxsize=n_prefetch)

    iterator = iter(iteratable)

    def loop():
        while True:
            try:
                queue.put(next(iterator))
            except StopIteration:
                return

    process = threading.Thread(target=loop)
    process.start()

    while process.is_alive() or not queue.empty():
        yield queue.get()

    pass


def average(sequence: _t.Iterable[_T]):
    """
    :param sequence: an iterable sequence of elements
    :return: the average of the elements in the sequence
    """
    count = 0
    total = 0.0
    for item in sequence:
        total += item
        count += 1

    return total / count


def min(iterable: _t.Iterable[_T], selector: _t.Optional[_t.Callable[[_T], _R]] = None) -> _R:
    """
    Finds the minimum value in the given iterable.

    :param iterable: An iterable object containing values.
    :param selector: (Optional) A function that takes each value in the iterable and returns a key for comparison.
    :return: The minimum value from the iterable, or None if the iterable is empty or if all values are None.
    """
    try:
        if selector is None:
            return min(filter(iterable, lambda x: x is not None))
        else:
            return min(filter(map(iterable, selector), lambda x: x is not None, ))
    except ValueError:
        return None


def max(iterable: _t.Iterable[_T], selector: _t.Optional[_t.Callable[[_T], _R]] = None) -> _R:
    """
    Finds the maximum value in an iterable based on an optional selector function.

    :param iterable: An iterable object.
    :param selector: An optional function to apply to each element in the iterable before comparison. (default=None)
    :return: The maximum value based on the given selector function, or None if the iterable is empty or contains only None values.

    """
    try:
        if selector is None:
            return max(filter(iterable, lambda x: x is not None))
        else:
            return max(filter(map(iterable, selector), lambda x: x is not None))
    except ValueError:
        return None


class IteratorHandler(_t.Generic[_T]):
    def __init__(self, iterable: _t.Iterable[_T]):
        self._iterator = iter(iterable)
        self._current = None

    # def __next__(self):
    #     return next(self._iterator)
    #
    # def __iter__(self):
    #     return self

    def next(self) -> bool:
        try:
            self._current = next(self._iterator)
            return True
        except StopIteration:
            return False

    @property
    def current(self) -> _T:
        return self._current
