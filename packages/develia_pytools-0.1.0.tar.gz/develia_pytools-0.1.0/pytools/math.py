import math as _math
import typing as _t


def average(numbers: _t.Iterable[float]) -> float:
    """
    This function calculates the average of a list of numbers.
    :param numbers: List of numbers
    :return: Average of the numbers
    """
    i = 0
    output = 0.0
    for item in numbers:
        output += item
        i += 1

    return output / i


def lerp(x: float, in_min: float, in_max: float, out_min: float, out_max: float) -> float:
    """
    This function calculates the linear interpolation.
    :param x: Value to be interpolated
    :param in_min: Minimum input range of interpolation
    :param in_max: Maximum input range of interpolation
    :param out_min: Minimum output range of interpolation
    :param out_max: Maximum output range of interpolation
    :return: Interpolated value
    """

    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min


def extrema(numbers: _t.List[float]) -> _t.Tuple[float, float]:
    """
    This function finds the minimum and maximum value in the list of numbers.
    :param numbers: List of numbers
    :return: A tuple containing (min value, max value)
    """
    min_ = None
    max_ = None

    for item in numbers:
        if min_ is None or item < min_:
            min_ = item

        if max_ is None or item > max_:
            max_ = item

    return min_, max_


def round_to_nearest_power(number: float, base: int) -> float:
    """
    This function rounds a number to the nearest power of a basis.
    :param number: The number to round
    :param base: The base of the power
    :return: The number rounded to the nearest power of the base
    """
    min_diff = None
    i = 0
    while True:
        diff = abs(number - (base ** i))
        if min_diff is None or diff < min_diff:
            min_diff = diff
            i += 1
        else:
            return base ** (i - 1)


def round_up_to_nearest_multiple(number: float, multiple: int) -> float:
    """
    This function rounds up a number to the nearest multiple of another number.
    :param number: The number to round
    :param multiple: The number whose multiple to round to
    :return: The number rounded up to the nearest multiple of the other number
    """
    return multiple * round_up(number / multiple, 0)


def round_down_to_nearest_multiple(number: float, multiple: int) -> float:
    """
    This function rounds down a number to the nearest multiple of another number.
    :param number: The number to round
    :param multiple: The number whose multiple to round to
    :return: The number rounded down to the nearest multiple of the other number
    """
    return multiple * round_down(number / multiple, 0)


def round_to_nearest_multiple(number: float, multiple: int) -> float:
    """
    This function rounds a number to the nearest multiple of another number.
    :param number: The number to round
    :param multiple: The number whose multiple to round to
    :return: The number rounded to the nearest multiple of the other number
    """
    return multiple * round(number / multiple)


def round_up(number: float, decimals: int = 0) -> float:
    """
    This function rounds up a number.
    :param number: The number to round
    :param decimals: The number of places to round to
    :return: The number rounded up
    """
    factor = 10 ** decimals
    return _math.ceil(number * factor) / factor


def round_up_to_even(number: float) -> int:
    """
    This function rounds up a number to the nearest even number.
    :param number: The number to round
    :return: The number rounded up to the nearest even number
    """
    return _math.ceil(number / 2.) * 2


def round_down(number: float, decimals: int = 0) -> float:
    """
    This function rounds down a number.
    :param number: The number to round
    :param decimals: The number of places to round to
    :return: The number rounded down
    """
    factor = 10 ** decimals
    return _math.floor(number * factor) / factor


def round_down_to_even(number: float) -> int:
    """
    This function rounds down a number to the nearest even number.
    :param number: The number to round
    :return: The number rounded down to the nearest even number.
    """
    return _math.floor(number / 2.) * 2
