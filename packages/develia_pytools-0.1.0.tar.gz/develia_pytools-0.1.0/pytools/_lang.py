import typing as _t


class segment:

    def __new__(cls, start: _t.Optional[int] = None, count: _t.Optional[int] = None, step: _t.Optional[int] = None) -> slice:
        return slice(start, (start + count) if (count is not None and start is not None) else start, step)

    def __class_getitem__(cls, item: slice) -> slice:
        return slice(item.start, (item.start + item.stop) if (item.stop is not None and item.start is not None) else item.start, item.step)
