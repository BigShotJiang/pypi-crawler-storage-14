__all__ = ["batch"]

import typing as _t

_T = _t.TypeVar('_T')
_R = _t.TypeVar('_R')


def batch(sequence: _t.Sequence[_T], batch_size: int) -> _t.Iterable[_t.Sequence[_T]]:
    for i in range(0, len(sequence), batch_size):
        yield sequence[i:i + batch_size]


def sliding_window(sequence: _t.Sequence[_T], window_length: int) -> _t.Iterable[_t.Sequence[_T]]:
    for i in range(0, len(sequence) - window_length + 1):
        yield sequence[i:i + window_length]
