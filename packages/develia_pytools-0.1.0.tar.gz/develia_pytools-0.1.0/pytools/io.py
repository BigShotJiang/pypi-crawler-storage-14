import typing as _t
from abc import ABC as _ABC
import enum as _enum


class Endianness(_enum.Enum):
    NATIVE = ''  # Usar la endianness nativa del sistema
    STANDARD = '='  # Standard size and alignment (no explicit byte order)
    LITTLE_ENDIAN = '<'  # Orden de bytes little-endian
    BIG_ENDIAN = '>'  # Orden de bytes big-endian
    NETWORK_ENDIAN = '!'  # Orden de bytes en la red (big-endian)

    @staticmethod
    def get_native_endian():
        import sys
        native_order = sys.byteorder
        if native_order == 'little':
            return Endianness.NATIVE
        elif native_order == 'big':
            return Endianness.BIG_ENDIAN
        else:
            return Endianness.NATIVE


class StructFormat(_enum.Enum):

    def __mul__(self, other):
        if isinstance(other, int):
            return str(other) + self.value
        raise TypeError()

    @staticmethod
    def build(endianness: Endianness, *args):
        output = endianness.value
        i = 0
        for arg in args:
            if isinstance(arg, StructFormat):
                output += arg.value
            else:
                output += str(arg)
            i += 1
        return output

    # Byte order, size and alignment
    NATIVE = '@'  # native order, size & alignment
    STANDARD = '='  # standard size & alignment
    LITTLE_ENDIAN = '<'  # little-endian
    BIG_ENDIAN = '>'  # big-endian
    NETWORK = '!'  # network (= big-endian)

    # Format characters
    CHAR = 'c'  # char
    SIGNED_CHAR = 'b'  # signed char
    UNSIGNED_CHAR = 'B'  # unsigned char
    BOOL = '?'  # _Bool
    SHORT = 'h'  # short
    UNSIGNED_SHORT = 'H'  # unsigned short
    INT = 'i'  # int
    UNSIGNED_INT = 'I'  # unsigned int
    LONG = 'l'  # long
    UNSIGNED_LONG = 'L'  # unsigned long
    LONG_LONG = 'q'  # long long
    UNSIGNED_LONG_LONG = 'Q'  # unsigned long long
    FLOAT = 'f'  # float
    DOUBLE = 'd'  # double
    POINTER = 'P'  # void *
    STRING = 's'  # char[]
    PASCAL_STRING = 'p'  # char[] (Pascal string)
    VOID = 'x'  # pad byte
    NATIVE_INT = 'n'  # ssize_t
    UNSIGNED_NATIVE_INT = 'N'  # size_t
    UNICODE_CHAR = 'u'  # Py_UNICODE (only for backward compatibility)


def ensure_dir(dir: str, recursive: bool = True) -> bool:
    """Returns true if directory was created."""
    import os as _os
    if recursive:
        parent = _os.path.dirname(dir)
        if not _os.path.isdir(parent):
            ensure_dir(parent, True)

    if not _os.path.isdir(dir):
        _os.mkdir(dir)
        return True

    return False


def get_char(txt=None, stream=None):
    if txt is not None:
        print(txt)

    import sys
    import os
    if os.name == 'nt':  # Windows
        import msvcrt
        return msvcrt.getch().decode('utf-8')
    else:  # UNIX, Linux, macOS
        import tty
        import termios

        stream = sys.stdin if stream is None else stream

        fd = stream.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(stream.fileno())
            ch = stream.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch


def read_file(file: str,
              binary: _t.Optional[bool] = None,
              encoding: _t.Optional[str] = None,
              newline: _t.Optional[str] = None) -> _t.AnyStr:
    with open(file=file,
              mode="r" + ('b' if binary else ''),
              newline=newline,
              encoding=encoding) as resource:
        return resource.read()


def write_file(file: str,
               content: _t.AnyStr,
               binary: _t.Optional[bool] = None,
               append: _t.Optional[bool] = None,
               encoding: _t.Optional[str] = None,
               newline: _t.Optional[str] = None) -> None:
    with open(file=file,
              mode=('w' if not append else 'a') + ('b' if binary else ''),
              newline=newline,
              encoding=encoding) as resource:
        resource.write(content)


class IOBase(_ABC):
    def __init__(self, io: _t.IO, close: _t.Optional[bool] = False):
        self._close = close
        self._io = io

    @property
    def io(self):
        return self._io

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._close:
            self._io.close()

    @property
    def position(self) -> int:
        return self._io.tell()

    @position.setter
    def position(self, value) -> None:
        import os
        self._io.seek(value, os.SEEK_SET)


class BinaryBase(IOBase):
    def __init__(self, io: _t.BinaryIO, endianness: _t.Optional[Endianness] = Endianness.NATIVE, close: _t.Optional[bool] = False):
        super().__init__(io, close)
        self.endianness = endianness


class BinaryReader(BinaryBase):

    def __init__(self, io: _t.BinaryIO, endianness: _t.Optional[Endianness] = Endianness.NATIVE, close: _t.Optional[bool] = False):
        super().__init__(io, close=close, endianness=endianness)

    def peek(self):
        pos = self._io.tell()
        output = self.read(1)
        self._io.seek(pos)
        return output

    def unpack(self, fmt: str) -> _t.Tuple:
        import struct
        size = struct.calcsize(fmt)
        return struct.unpack(fmt, self._io.read(size))

    def read_int(self) -> int:
        return self.unpack(self.endianness.value + "i")[0]

    def read_uint(self) -> int:
        return self.unpack(self.endianness.value + "I")[0]

    def read_float(self) -> float:
        return self.unpack(self.endianness.value + "f")[0]

    def read_double(self) -> float:
        return self.unpack(self.endianness.value + "d")[0]

    def read(self, n: int) -> bytes:
        return self._io.read(n)

    def read_object(self):
        import pickle
        size = self.read_int()
        data = self.read(size)
        return pickle.loads(data)

    def read_long(self) -> int:
        return self.unpack(self.endianness.value + "q")[0]

    def read_ulong(self) -> int:
        return self.unpack(self.endianness.value + "Q")[0]


class BinaryWriter(BinaryBase):

    def __init__(self, io: _t.BinaryIO, endianness: _t.Optional[Endianness] = Endianness.NATIVE, close: _t.Optional[bool] = False):
        super().__init__(io, close=close, endianness=endianness)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            self._io.flush()
        super().__exit__(exc_type, exc_val, exc_tb)

    def pack(self, fmt: str, *data: _t.Any) -> int:
        import struct
        return self._io.write(struct.pack(fmt, *data))

    def write_int(self, value: int) -> int:
        import struct
        return self._io.write(struct.pack(self.endianness.value + "i", value))

    def write_uint(self, value: int) -> int:
        import struct
        return self._io.write(struct.pack(self.endianness.value + "I", value))

    def write_float(self, value: float) -> int:
        import struct
        return self._io.write(struct.pack(self.endianness.value + "f", value))

    def write_double(self, value: float) -> int:
        import struct
        return self._io.write(struct.pack(self.endianness.value + "d", value))

    def write(self, value: bytes) -> int:
        return self._io.write(value)

    def write_object(self, value) -> int:
        output = 0
        import pickle
        dump = pickle.dumps(value)
        size = len(dump)
        output += self.write_int(size)
        output += self.write(dump)
        return output

    def write_long(self, value: int) -> int:
        self.write_float(2.3)
        import struct
        return self._io.write(struct.pack(self.endianness.value + "q", value))

    def write_ulong(self, value: int) -> int:
        import struct
        return self._io.write(struct.pack(self.endianness.value + "Q", value))


class BinaryFileReader(BinaryReader):
    def __init__(self, path: str):
        super().__init__(open(path, "rb"), close=True)


class BinaryFileWriter(BinaryWriter):
    def __init__(self, path: str):
        super().__init__(open(path, "wb"), close=True)


class ByteReader(BinaryReader):
    def __init__(self, bytes: _t.ByteString):
        import io
        super().__init__(io.BytesIO(bytes), close=True)

    def __bytes__(self):
        tmp = self.position
        self.position = 0
        output = self._io.read()
        self.position = tmp
        return output


class ByteWriter(BinaryWriter):
    def __init__(self, bytes: _t.ByteString = b''):
        import io
        super().__init__(io.BytesIO(bytes), close=True)

    def __bytes__(self):
        tmp = self.position
        self.position = 0
        output = self._io.read()
        self.position = tmp
        return output
