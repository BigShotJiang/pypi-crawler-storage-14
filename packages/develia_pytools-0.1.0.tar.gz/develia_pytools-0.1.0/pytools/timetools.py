import functools
import time as _time
import typing as _t
from datetime import timedelta, datetime


def _console_callback(name_: str, ms_: timedelta, avg_: timedelta):
    time = "{:.2f}".format(ms_.total_seconds() * 1000).rjust(10, ' ')
    avg = "{:.2f}".format(avg_.total_seconds() * 1000).rjust(10, ' ')
    print("\033[93m" + name_ + " - Last:" + time + "ms\tAvg:" + avg + "ms" + '\033[0m')


class Stopwatch:
    _start = datetime
    _end = datetime

    def __enter__(self):
        self._start = datetime.utcnow()
        self._end = None
        return self

    @property
    def elapsed(self) -> timedelta:
        end = self._end if self._end is not None else datetime.utcnow()
        return end - self._start

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._end = datetime.utcnow()


class Profiler:
    def __init__(self, name: str, callback: _t.Optional[_t.Callable[[str, timedelta, timedelta], _t.Any]] = _console_callback):
        self._name = name
        self._timer = Timer()
        self._callback = callback
        self._count = 0

    def __enter__(self):
        if not self._timer.running:
            self._timer.start()

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._timer.running:
            self._timer.stop()
            self._count += 1
            self._callback(self._name, self._timer.elapsed, self._timer.elapsed / self._count)


def profile(thing: _t.Union[_t.Iterable, _t.Callable] = None,
            name: str = None,
            callback: _t.Optional[_t.Callable[[str, timedelta, timedelta], _t.Any]] = _console_callback):
    if thing is None:
        return Profiler(name, callback)

    elif callable(thing):

        @functools.wraps(thing)
        def timed(*args, **kw):
            with Profiler(name if name is not None else thing.__name__, callback):
                return thing(*args, **kw)

        return timed

    elif isinstance(thing, _t.Iterable):
        return profile_iterable(thing, name if name is not None else str(thing), callback)


def profile_iterable(thing: _t.Iterable,
                     name: str,
                     callback: _t.Optional[_t.Callable[[str, timedelta, timedelta], _t.Any]] = _console_callback):
    profiler = Profiler(name, callback)
    thing = iter(thing)

    while True:
        with profiler:
            try:
                output = next(thing)
            except StopIteration:
                break
        yield output


class CrudeTimer:
    def __init__(self, interval: timedelta, fn: _t.Callable):
        self.interval = interval
        self._fn = fn
        self._next = None

    def run(self, *args, **kwargs):
        from datetime import datetime
        if self._next is None or datetime.now() >= self._next:
            self._next = datetime.now() + self.interval
            self._fn(*args, **kwargs)


class Timer:
    _start = _t.Optional[int]
    _end = _t.Optional[int]

    def __init__(self):
        self._running = False
        self._start = None
        self._end = None
        self.reset()

    @property
    def running(self):
        return self._running

    def reset(self):
        self._start = _time.time() if self._running else None
        self._end = None

    def restart(self):
        """Reset & Start"""
        self.reset()
        self.start()

    def start(self):
        if not self._running:
            self._start = _time.time()
            self._running = True

    @property
    def elapsed(self) -> timedelta:
        return timedelta(seconds=(_time.time() if self.running else self._end) - self._start)

    def stop(self):
        if self._running:
            self._end = _time.time()
            self._running = False

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc_info):
        self.stop()
