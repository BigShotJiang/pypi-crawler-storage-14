# from ._multipledispatch import dispatch
from ._lang import *
from ._functions import *
from ._lazy import Lazy
from ._segment import Segment
from ._range import Range
from ._result import Result
