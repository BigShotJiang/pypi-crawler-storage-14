import typing as _t

_T = _t.TypeVar('_T')
_R = _t.TypeVar("_R")


def staticinitialization(cls: _t.Type):
    """
    Perform static initialization for a given class.

    :param cls: The class to perform static initialization on.
    :return: The modified class with static initialization.
    :raises Exception: If `cls.__static_init__` is not callable.
    """
    if hasattr(cls, "__static_init__") and callable(cls.__static_init__):

        cls.__static_init__()

        def raise_exception(*args, **kwargs):
            raise Exception("The static initializer cannot be called more than once.")

        cls.__static_init__ = raise_exception

    else:
        raise Exception(f"Method \'{cls.__name__}__static_init__\' is not implemented")

    return cls


def new(cls: _t.Type[_T], *args, **kwargs) -> _T:
    """
    Create a new instance of a class.

    :param cls: The class to create an instance of.
    :param args: Positional arguments that will be passed to the class constructor.
    :param kwargs: Keyword arguments that will be passed to the class constructor.
    :return: The newly created instance of the class.
    """
    return cls.__new__(cls, *args, **kwargs)


def clamp(x, min, max):
    """
    Clamp a value to a specified range.

    :param x: The value to be clamped.
    :param min: The minimum value of the range.
    :param max: The maximum value of the range.
    :return: The clamped value.
    """
    if x < min:
        return min
    if x > max:
        return max
    return x


def compare(a: _t.Any, b: _t.Any) -> int:
    """
    :param a: The first value to compare.
    :param b: The second value to compare.
    :return: -1 if `a` is less than `b`, 1 if `a` is greater than `b`, 0 if `a` is equal to `b`.

    """
    if a < b:
        return -1
    elif a > b:
        return 1
    else:
        return 0


def unzip(iterable: _t.Iterable) -> _t.Iterable:
    """
    Unzips an iterable by transposing the elements of the nested iterables.

    :param iterable: An iterable containing nested iterables.
    :return: An iterable of tuples, each representing a column of the transposed elements.
    """
    return zip(*iterable)


def try_resolve(obj: _t.Any, key: str, fallback=None):
    """
    Tries to resolve the value of a given key in an object and returns a Result.

    :param obj: The object to resolve the key from.
    :param key: The key to resolve in the object.
    :param fallback: The fallback value to return if the key is not found. Default is None.
    :return: A Result object containing a boolean indicating if the key was found,
             and the value of the key if found or the fallback value if not found.
    """
    from pytools import Result

    if hasattr(obj, key):
        return Result(True, getattr(obj, key))

    return Result(False, fallback)


def debugging() -> bool:
    """
    Check if the Python interpreter is currently being run in a debugger.

    :return: Returns True if the interpreter is being run in a debugger, False otherwise.
    :rtype: bool
    """
    import sys
    output = hasattr(sys, 'gettrace') and sys.gettrace() is not None
    print(output)
    return output


def between(value, min, max, inclusive=True):
    """
    :param value: The value to check if it is between the minimum and maximum values.
    :param min: The minimum value of the range.
    :param max: The maximum value of the range.
    :param inclusive: Optional parameter indicating if the minimum and maximum values should be inclusive (default is True).
    :return: True if the value is between the minimum and maximum values (inclusive or exclusive based on the inclusive parameter), False otherwise.
    """
    if inclusive:
        return min <= value <= max
    else:
        return min < value < max


def evaluate(obj: _t.Union[_t.Callable[[], _T], _T]) -> _T:
    """
    :param obj: The object to be evaluated. It can either be a callable or a regular object.
    :return: The result of evaluating the object. If the object is callable, the returned value is the result of calling the object.
             If the object is not callable, the returned value is the object itself.

    """
    if callable(obj):
        return obj()
    return obj


def tap(obj: _T, callable: _t.Callable[[_T], _t.Any]) -> _T:
    """
    Apply a Callable function to an object and return the object.

    :param obj: The object to apply the callable function to.
    :param callable: The Callable function that will be applied to the object.
    :return: The object after applying the callable function.
    """
    callable(obj)
    return obj


def coalesce(arg1, arg2) -> _t.Optional[_T]:
    return arg1 if arg1 is not None else arg2

# def parse(target_type: _typing.Union[_typing.Type[int], _typing.Type[float]], string: str,
#           decimal_separator: str = ".",
#           thousands_separator: str = None,
#           fallback: _typing.Any = None) -> _typing.Any:
#     if thousands_separator is not None:
#         string = string.replace(thousands_separator, "")
#
#     try:
#         if target_type == float:
#             if decimal_separator != ".":
#                 string = string.replace(decimal_separator, ".")
#             return float(string)
#         elif target_type == int:
#             return int(string)
#
#         return fallback() if callable(fallback) else fallback
#     except ValueError:
#         return fallback() if callable(fallback) else fallback
