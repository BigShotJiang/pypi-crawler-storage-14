import typing
from functools import wraps
import typing as _t

_sequenciable = _t.Union[_t.Sequence, 'Segment', typing.List, typing.Tuple]

_T = typing.TypeVar('_T')


class Segment(_t.Generic[_T]):

    @property
    def stop(self):
        return self._stop

    @property
    def start(self):
        return self._start

    def __init__(self, sequence: _sequenciable, start: int, stop: int = None, count: int = None):

        assert not (stop is not None and count is not None)

        if count is not None:
            self._stop = start + count
            assert self._stop <= len(sequence)
        elif stop is not None:
            self._stop = stop
        else:
            self._stop = len(sequence)

        self._start = start
        self._sequence: _sequenciable = sequence

    def __getitem__(self, item) -> _T:
        # if isinstance(item, slice):
        #     start = item.start + self._start
        #     stop = start + item.stop
        #     return self._sequence[start:stop: item.step]

        return self._sequence[item]

    def __setitem__(self, item: int, value: _T):
        # if isinstance(item, slice):
        #     start = item.start + self._start
        #     stop = start + item.stop
        #     self._sequence[start:stop: item.step] = value

        self._sequence[item + self._start] = value

    def __iter__(self) -> _t.Iterator[_T]:
        for x in range(self._start, self._stop):
            yield self._sequence[x]

    def __len__(self):
        return self._stop - self._start

    # def __repr__(self):
    #     return self._sequence[self._start:self._stop].__repr__()
