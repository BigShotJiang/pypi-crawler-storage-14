from datetime import datetime as _datetime, time as _time, date as _date
from datetime import timedelta as _timedelta
import typing as _t


def start_of_day(input_date: _t.Union[_date, _datetime]) -> _datetime:
    """
    Convert the given input date to the start of the day.

    :param input_date: The input date, can be a date object or a datetime object.
    :return: The start of the day as a datetime object.
    """
    if isinstance(input_date, _datetime):
        input_date = input_date.date()
    return _datetime.combine(input_date, _time())


def end_of_day(input_date: _t.Union[_date, _datetime]) -> _datetime:
    """
    :param input_date: The input date for which the end of day is to be calculated.
    :return: The datetime object representing the end of the input date.
    """
    if isinstance(input_date, _datetime):
        input_date = input_date.date()
    return _datetime.combine(input_date, _time(23, 59, 59, 999999))


def datetime_to_unix(date: _datetime) -> float:
    """
    Converts a datetime object to a Unix timestamp.

    :param date: The datetime object to be converted.
    :return: The Unix timestamp representing the given datetime.
    """
    return (date - _datetime(1970, 1, 1)).total_seconds()


def unix_to_datetime(unix_timestamp: float) -> _datetime:
    """
    :param unix_timestamp: The Unix timestamp to be converted to a datetime object.
    :return: The datetime object corresponding to the given Unix timestamp.
    """
    return _datetime(1970, 1, 1) + _timedelta(seconds=unix_timestamp)


def truncate(datetime: _datetime, timedelta: _timedelta) -> _datetime:
    """
    Truncates the given datetime to the nearest timedelta interval.

    :param datetime: A datetime object to be truncated.
    :param timedelta: A timedelta object representing the interval to truncate to.
    :return: A truncated datetime object.

    """
    unix_timestamp = int(datetime_to_unix(datetime))
    timedelta_total_seconds = int(timedelta.total_seconds())
    surplus = unix_timestamp % timedelta_total_seconds
    return unix_to_datetime(unix_timestamp - surplus)


def day_of_year(date: _datetime) -> int:
    start_of_year = _datetime(date.year, 1, 1)
    return (date - start_of_year).days + 1


def days_in_month(month, year) -> int:
    """
    Determines the number of days in a given month of a specific year.

    Args:
    - year (int): Year.
    - month (int): Month (1 for January, 2 for February, ..., 12 for December).

    Returns:
    - int: Number of days in the specified month and year.
    """
    return [31, 29 if is_leap_year(year) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]


def is_leap_year(year: int):
    """
    Determines if a given year is a leap year.

    Args:
    - year (int): Year to check.

    Returns:
    - bool: True if the year is a leap year, False otherwise.
    """

    return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)
