import itertools as _itertools
from concurrent.futures import Executor as _Executor
from functools import singledispatch

from pytools import new as _new
from pytools import iteratools as _iteratools
from pytools.collections import LazySequence as _LazySequence

from pytools.io import BinaryFileReader as _BinaryFileReader, BinaryFileWriter as _BinaryFileWriter, ensure_dir
import typing as _t

_T = _t.TypeVar('_T')
_R = _t.TypeVar("_R")

_Predicate = _t.Union[_t.Callable[[_T], bool], dict]
_Mapper = _t.Union[_t.Callable[[_T], _R], _t.Sequence[str], str]


class Stream(_t.Iterable[_T], _t.Sized):
    """
    :class:`Stream`
    ==============

    A class representing a stream of elements that can be processed using various operations.

    """

    def __len__(self) -> int:
        return self.length()

    _get_iterator = _t.Callable[[], _t.Iterator[_T]]

    def _prefetch(self, n, pool_executor):
        from pytools.asynctools import EndSignal
        from concurrent.futures import ThreadPoolExecutor
        from multiprocessing import Queue

        if pool_executor is None:
            pool_executor = ThreadPoolExecutor(max_workers=1)

        iterator = iter(self)
        queue = Queue(n)

        def prefetch_next():
            nonlocal queue

            try:
                queue.put(next(iterator))
            except StopIteration:
                queue.put(EndSignal())

        for _ in range(n):
            pool_executor.submit(prefetch_next)

        while True:
            item = queue.get()
            if isinstance(item, EndSignal):
                return
            pool_executor.submit(prefetch_next)
            yield item

    def prefetch(self, n: int, pool_executor=None):
        """
        Prefetches `n` items from a `Stream` object.

        :param n: The number of items to prefetch.
        :param pool_executor: (optional) The executor to use for parallel processing.
        :return: A new `Stream` object with the prefetched items.
        """
        return Stream.from_fn(lambda: self._prefetch(n, pool_executor))

    def last(self, predicate: _t.Optional[_Predicate] = None) -> _T:
        """

        :param predicate: An optional predicate function used to filter the elements in the collection.
        :return: The last element in the collection that satisfies the predicate, or the last element if no predicate is specified.

        """
        output = None

        if predicate is None:
            for item in self._get_iterator():
                output = item
        else:
            for item in self._get_iterator():
                if predicate(item):
                    output = item
        return output

    def consume(self) -> "Stream[_T]":
        """
        Consume the elements of the stream.

        :return: None
        """
        _iteratools.consume(self._get_iterator())
        return self

    def union(self, *iterables) -> "Stream":
        """
        Combines multiple iterables into a single stream.

        :param iterables: The iterables to be combined.
        :return: A new Stream object that represents the combined iterables.
        """
        return Stream.from_fn(lambda: _itertools.chain(self, *iterables))

    def length(self):
        """
        Calculate the length of the iterable.

        :return: The length of the iterable.
        """
        return _iteratools.length(self._get_iterator())

    def __distinct(self, mapper: _Mapper = None):
        processed = []
        for item in self._get_iterator() if mapper is None else map(mapper, self._get_iterator()):
            if item not in processed:
                yield item
                processed.append(item)

    def distinct(self, mapper: _Mapper = None) -> "Stream[_T]":
        return Stream.from_fn(lambda: self.__distinct(mapper))

    def __init__(self, source: _t.Optional[_t.Union[_t.Iterable[_T], _t.Callable[[], _T]]] = None):
        """
        Initializes the object with a data source.

        :param source: A data source to be used for iteration. It can be either an iterable, a callable that returns an iterable, or None.
        :type source: Optional[Union[Iterable[T], Callable[[], T]]]

        Raises:
            Exception: If the source argument is invalid.
        """
        if source is not None:
            if isinstance(source, _t.Callable):
                self._get_iterator = source
            elif isinstance(source, _t.Iterator):
                self._get_iterator = _LazySequence(source).__iter__
            elif isinstance(source, _t.Iterable):
                self._get_iterator = source.__iter__
            else:
                raise ValueError("Invalid argument")
        else:
            self._get_iterator = [].__iter__

    def _cache(self, file: str, reader_fn: _t.Callable[[_BinaryFileReader], _T], writer_fn: _t.Callable[[_BinaryFileWriter, _T], None]):
        """
        Cache method.

        :param file: The file path to cache data into or read from.
        :param reader_fn: The function used to read data from the file.
        :param writer_fn: The function used to write data to the file.

        :return: A generator that yields data read from the file.

        .. note::
           If the file does not exist, it will be created and data will be written to it using the `writer_fn`
           function. The `reader_fn` function will then be used to read data from the file.

        .. warning::
           If the file already exists, its contents will not be modified or overwritten.

        """
        import os
        import tempfile
        import time
        import shutil

        if not os.path.isfile(file):

            temp_filepath = os.path.basename(file)
            temp_filepath = hex(int(time.time()))[2:] + "." + temp_filepath
            temp_filepath = os.path.join(tempfile.gettempdir(), temp_filepath)

            try:
                with _BinaryFileWriter(temp_filepath) as writer:
                    for item in self._get_iterator():
                        writer_fn(writer, item)

                if os.path.isfile(temp_filepath):

                    if os.path.isfile(file):
                        os.remove(file)

                    ensure_dir(os.path.dirname(file))
                    shutil.copy(temp_filepath, file)

            except Exception as e:
                raise e
            finally:
                if os.path.isfile(temp_filepath):
                    os.remove(temp_filepath)

        with _BinaryFileReader(file) as reader:
            while not reader.eof:
                yield reader_fn(reader)

    def cache(self, file: str,
              reader_fn: _t.Optional[_t.Callable[[_BinaryFileReader], _T]] = None,
              writer_fn: _t.Optional[_t.Callable[[_BinaryFileWriter, _T], None]] = None) -> "Stream[_T]":
        """
        :param file: The file path where the cached data will be stored or retrieved from.
        :param reader_fn: A function used to read the cached data from the file. Optional, defaults to None.
        :param writer_fn: A function used to write the data to the cache file. Optional, defaults to None.
        :return: A stream of type T that lazily reads or writes the cache data.

        This method caches the data to/from a file using the provided reader and writer functions.
        If the reader_fn is not provided, the default implementation uses pickle to deserialize the data from the file.
        If the writer_fn is not provided, the default implementation uses pickle to serialize the data and write it to the file.

        The caching process is done lazily, meaning the cache data is only read or written when requested.
        The returned stream allows accessing the cached data as needed.

        Example usage:
        cache(file_path, my_reader_function, my_writer_function)
        cache(file_path)  # Uses default reader_fn and writer_fn using pickle
        """
        if reader_fn is None:
            import pickle

            def reader_fn(reader: _BinaryFileReader):
                size = reader.read_int()
                return pickle.loads(reader.read(size))

        if writer_fn is None:
            import pickle

            def writer_fn(writer: _BinaryFileWriter, obj):
                data = pickle.dumps(obj)
                writer.write_int(len(data))
                writer.write(data)

        return Stream[_T](lambda: self._cache(file, reader_fn, writer_fn))

    def apply(self, function: _t.Callable[[_t.Iterable[_T]], _t.Iterable[_R]], batch_size: _t.Optional[int] = None) -> "Stream[_R]":
        """
        Apply a function to each batch or element in the stream.

        :param function: A callable function that takes an iterable of type T and returns an iterable of type R.
        :param batch_size: An optional integer representing the size of each batch. If None, the function will be applied to the entire stream. Defaults to None.
        :return: A new Stream object containing the transformed elements or batches.

        """
        if batch_size is None:
            return Stream.from_fn(lambda: function(self._get_iterator()))
        else:
            return Stream[_R].from_fn(lambda: _iteratools.flatten(function(batch) for batch in _iteratools.batch(self._get_iterator(), batch_size)))

    def foreach(self, func: _t.Callable[[_T], None]):
        """
        Apply the given function to each item in the container.

        :param func: The function to apply to each item. It should take one argument of type T and return None.
        :return: None

        """
        for item in self._get_iterator():
            func(item)

    def _tap(self, func: _t.Callable[[_T], None]) -> _t.Iterable[_T]:
        """
        :param func: The function to apply to each item in the iterator.
        :return: An iterable containing the same items as the original iterator.
        """
        for item in self._get_iterator():
            func(item)
            yield item

    def tap(self, func: _t.Callable[[_T], None]) -> "Stream[_T]":
        """
        Applies a function to each element of the stream and returns a new stream.

        :param func: the function to apply to each element of the stream.
        :type func: Callable[[T], None]

        :return: a new stream with the function applied to each element.
        :rtype: Stream[T]
        """
        return Stream[_T](lambda: self._tap(func))

    @staticmethod
    def from_fn(factory_fn: _t.Callable[[], _t.Iterable[_T]]) -> "Stream[_T]":
        """
        Create a new Stream using a factory function.

        :param factory_fn: A callable object that returns an iterable of items.
        :return: A new Stream object.

        Example usage:
            def my_factory_fn():
                return [1, 2, 3, 4, 5]

            stream = Stream.from_fn(my_factory_fn)
        """
        output = _new(Stream)
        output._get_iterator = factory_fn
        return output

    @staticmethod
    def from_iterable(iterable: _t.Iterable[_T]) -> "Stream[_T]":
        return Stream.from_fn(iterable.__iter__)

    @staticmethod
    def from_iterator(iterator: _t.Iterator[_T]) -> "Stream[_T]":
        """
        Create a Stream from an iterator.

        :param iterator: The iterator to create the Stream from.
        :return: The created Stream.

        Example usage:
            >>> iterator = iter([1, 2, 3])
            >>> stream = Stream.from_iterator(iterator)
        """
        return Stream.from_iterable(_LazySequence(iterator))

    @staticmethod
    def _to_predicate(predicate: _Predicate[_T]) -> _t.Callable[[_T], bool]:
        """
        :param predicate: The predicate which can be either a callable or a dictionary.
        :return: A callable that takes an argument of type T and returns a boolean value based on the given predicate.

        The method `_to_predicate` takes a predicate as input and returns a corresponding callable function.
        If the input predicate is already a callable, it is returned as-is.
        If the predicate is a dictionary, a dynamic function `fn` is created that checks if each key-value pair in the dictionary matches the corresponding attribute-value pair in the given
        * object of type T. The function returns True if all attribute-value pairs match, otherwise it returns False.
        If the input predicate is not a callable or a dictionary, a ValueError is raised.

        Example usage:
        ```
        predicate = lambda x: x > 5
        predicate_fn = _to_predicate(predicate)
        result = predicate_fn(10)  # Returns True

        predicate = {'name': 'John', 'age': 30}
        predicate_fn = _to_predicate(predicate)
        result = predicate_fn(Person(name='John', age=30))  # Returns True
        ```
        """
        if callable(predicate):
            return predicate

        if isinstance(predicate, dict):
            def fn(x):
                for k, v in predicate.items():
                    if k not in x:
                        raise KeyError()
                    if k in x and x[k] != v:
                        return False

                return True

            return fn

        raise ValueError("predicate")

    @staticmethod
    def _to_selector(selector: _Mapper) -> _t.Callable[[_T], _R]:
        """
        :param selector: The selector used to determine how to map the input.
            If the selector is a callable, it is returned as is.
            If the selector is a string, a lambda function is returned, which accesses the attribute with the same name on the input object.
            If the selector is a tuple or list, a lambda function is returned, which creates a dictionary by accessing the attributes specified in the selector from the input object.
        :return: A callable function that can be used to map the input according to the specified selector.
            If the selector is invalid, a ValueError is raised.
        """
        if callable(selector):
            return selector

        if isinstance(selector, str):
            return lambda x: getattr(x, selector)

        if isinstance(selector, (tuple, list)):
            return lambda x: {attr: getattr(x, attr) for attr in selector}

        raise ValueError("selector")

    def _shuffle(self):
        import random
        array = list(self)
        random.shuffle(array)
        return array

    def shuffle(self, buffer_size: _t.Optional[int] = None) -> "Stream[_T]":
        """
        Shuffle the elements of the stream using a buffer of specified size.

        :param buffer_size: The size of the shuffle buffer.
        :return: A new stream with elements shuffled.
        """

        if buffer_size is None or buffer_size == 0:
            return Stream.from_fn(self._shuffle)

        if isinstance(buffer_size, int) and buffer_size > 0:
            return Stream.from_fn(lambda: _iteratools.shuffle(self._get_iterator(), buffer_size))

        raise ValueError("buffer_size")

    def average(self):
        """
        Calculate the average of the values in the iterable.

        :return: The average of the values.
        :rtype: float
        """
        count = 0
        total = 0.0
        for item in self._get_iterator():
            total += item
            count += 1

        return total / count

    def _flatten(self):
        """
        Flattens a nested iterable into a single iterable.

        :return: The flattened iterable.
        :rtype: generator
        """
        for item in self._get_iterator():
            for subitem in item:
                yield subitem

    def flatten(self) -> "Stream":
        """
        Flattens the nested elements in the Stream.

        :return: A new Stream with the nested elements flattened.
        :rtype: Stream
        """
        return Stream[_T].from_fn(self._flatten)

    def filter(self, predicate: _Predicate) -> "Stream[_T]":
        """
        :param predicate: The predicate function used to filter the elements.
        :return: A new Stream object containing elements that satisfy the given predicate.

        """
        return Stream[_T].from_fn(lambda: filter(self._to_predicate(predicate), self))

    def _map_parallel(self, mapper: _Mapper, executor: _Executor):
        futures = [executor.submit(mapper, item) for item in self]
        for future in futures:
            yield future.result()

    def map(self, mapper: _Mapper, executor: _t.Optional[_Executor] = None) -> "Stream[_R]":
        """
        Maps each element in the stream using the provided mapper function.
        :param executor:
        :param mapper: The mapper function to apply to each element.
        :return: A new Stream with the mapped elements.
        """
        if executor is not None:
            return Stream[_R].from_fn(lambda: self._map_parallel(mapper, executor))
        return Stream[_R].from_fn(lambda: map(mapper, self))

    def orderby(self, selector: _Mapper = None, descending=False) -> "Stream[_R]":
        return Stream[_R].from_fn(lambda: sorted(self, key=selector, reverse=descending))

    def skip_while(self, predicate: _Predicate):
        """
        :param predicate: A function that takes an element as input and returns a boolean value indicating whether to skip the element or not.
        :return: A Stream object that skips elements from the source Stream while the predicate function returns True.
        """
        return Stream.from_fn(lambda: _iteratools.skip_while(self, predicate))

    def _mapmany(self, mapper: _Mapper) -> "Stream[_R]":
        for item in self:
            yield from mapper(item)

    def mapmany(self, mapper: _Mapper) -> "Stream[_R]":
        """
        :param mapper: A function that takes an item from the stream as input and returns a new item of type R.
        :return: A new Stream instance that applies the mapper function to each item in the current stream.

        Example usage:
            stream = Stream([1, 2, 3, 4, 5])
            mapped_stream = stream.mapmany(lambda x: [x, x**2])
            print(mapped_stream)  # Output: Stream([1, 1, 2, 4, 3, 9, 4, 16, 5, 25])

        """
        return Stream.from_fn(lambda: self._mapmany(mapper))

    def groupby(self, mapper: _Mapper) -> "Stream[Group[_T,_R]]":
        """
        Group the elements of the stream by the given mapper function.

        :param mapper: A function that maps elements of the stream to keys for grouping.
        :return: A new Stream containing tuples of keys and grouped elements.
        """
        return Stream.from_fn(lambda: self._groupby(mapper))

    def _groupby(self, mapper: _Mapper) -> _t.Iterable["Group[_T, _R]"]:

        output = {}
        for item in self:
            key = mapper(item)
            if key not in output:
                output[key] = []
            output[key].append(item)

        for k, v in output.items():
            yield Group(k, v)

    def __iter__(self):
        """
        Return an iterator object for the given sequence.

        :return: an iterator object that can be used to iterate over the sequence.
        :rtype: iterator
        """
        return iter(self._get_iterator())

    def first(self, predicate: _t.Optional[_Predicate] = None, fallback=None) -> _t.Optional[_T]:
        if predicate is None:
            for item in self:
                return item
        else:
            for item in self:
                if predicate(item):
                    return item

        return fallback

    def collect(self) -> "Stream[_T]":
        """
        Collect method collects elements from a stream and returns them in a new Stream.

        :param self: The current stream object.
        :return: A new Stream with the collected elements.
        :rtype: Stream[T]

        """
        return Stream.from_iterable(list(self))

    def single(self, predicate: _t.Optional[_Predicate] = None, fallback=None) -> _T:
        """
        :param predicate: A function that takes an element of the collection and returns a boolean value indicating whether the element should be included in the result. If omitted, all elements
        * will be considered.
        :param fallback: The value to return if the collection is empty. If omitted, an exception will be raised.
        :return: The single element of the collection that satisfies the predicate. If there is no such element, the fallback value will be returned. If the collection has more than one element
        *, an exception will be raised.

        """
        if predicate:
            filtered = self.filter(predicate)
        else:
            filtered = self._get_iterator()

        iterator = iter(filtered)

        try:
            item = next(iterator)
        except StopIteration:
            if fallback is not None:
                return fallback
            else:
                raise Exception("Collection has no elements.")

        try:
            next(iterator)
            raise Exception("Collection has more than one element.")
        except StopIteration:
            return item

    def conditional(self, condition: _t.Union[bool, _t.Callable[[], bool]], fn: _t.Callable[["Stream"], "Stream"]) -> "Stream":
        """
        :param condition: The condition to determine whether to apply the given function to the stream. It can either be a boolean value or a callable that returns a boolean.
        :param fn: The function to be applied to the stream if the condition is true.
        :return: A new Stream object with the applied function if the condition is true, otherwise returns the original Stream object.
        """
        return Stream.from_fn(lambda: fn(self)._get_iterator() if (condition() if callable(condition) else condition) else self._get_iterator())

    def rolling(self, size) -> "Stream[_t.List[_T]]":
        """
        :param size: The size of the sliding window
        :return: A stream of lists where each list represents a sliding window of `size` elements
        """
        return Stream.from_fn(lambda: _iteratools.rolling(self._get_iterator(), size))

    @_t.overload
    def __getitem__(self, idx: int) -> _T:
        pass

    @_t.overload
    def __getitem__(self, idx: slice) -> "Stream[_T]":
        pass

    def __getitem__(self, idx) -> _t.Union[_T, "Stream[_T]"]:
        """
        :param idx: Index of the item to retrieve.
        :return: The item at the specified index.

        """
        if isinstance(idx, slice):
            return Stream.from_fn(lambda: _itertools.islice(self._get_iterator(), idx.start, idx.stop, idx.step))

        for i, item in enumerate(self):
            if i == idx:
                return item

    def index(self, item) -> int:
        """
        Find the index of the given item in the object.

        :param item: The item to find the index of.
        :return: The index of the item if found, else None.
        """
        for i, element in enumerate(self):
            if item == element:
                return i

    def random(self, weights=None):
        """
        :param weights: A list of weights for the elements. If not provided, the method will select a random element from the sequence.
        :return: Returns a randomly selected element from the sequence based on the provided weights. If the sequence is empty, None will be returned.
        """
        import random

        elements = list(self)
        if len(elements) == 0:
            return None

        if weights is None:
            return random.choice(elements)

        else:
            total_weight = sum(weights)
            cumulative_weight = 0
            rand = random.randint(0, total_weight - 1)

            for i, item in enumerate(elements):
                cumulative_weight += weights[i]

                if rand <= cumulative_weight:
                    return item

            return None

    def extrema(self, selector: _t.Optional[_t.Callable[[_T], _t.Any]] = None):
        """
        Finds the minimum and maximum values in the given iterable, based on a selector function.

        :param selector: A callable function that selects a value from each item in the iterable. Defaults to identity function.
        :return: A tuple containing the minimum and maximum values found in the iterable.
        """
        from pytools import functions

        selector = functions.identity if selector is None else selector

        iterator = iter(self._get_iterator())

        try:
            item = selector(next(iterator))
            output_min = item
            output_max = item
        except StopIteration:
            return None, None

        for item in iterator:
            item = selector(item)
            output_min = min(item, output_min)
            output_max = max(item, output_max)

        return output_min, output_max

    def min(self, selector: _t.Optional[_t.Callable[[_T], _t.Any]] = None):
        """
            Returns the minimum value in the collection.

            :param selector: An optional callable function that specifies a custom selection criteria for finding the minimum value.
                             If provided, the function should take in an item from the collection and return a value to be compared.
            :type selector: Optional[Callable[[T], Any]]
            :return: The minimum value in the collection based on the selection criteria. If the collection is empty or if all values are `None`, `None` is returned.
            :rtype: Any
        """
        try:
            if selector is None:
                return min(filter(lambda x: x is not None, self._get_iterator()))
            else:
                return min(filter(lambda x: x is not None, map(selector, self._get_iterator())))
        except ValueError:
            return None

    def max(self, selector: _t.Optional[_t.Callable[[_T], _t.Any]] = None):
        """
        Finds the maximum value in the collection based on the given selector.

        :param selector: A callable function that takes an element from the collection and returns a value to compare.
                         If None, the maximum value will be determined directly from the elements in the collection.
        :type selector: Optional[Callable[[T], Any]]
        :return: The maximum value found in the collection based on the selector.
                 If the collection is empty or all elements are None, returns None.
        :rtype: Any
        """
        try:
            if selector is None:
                return max(filter(lambda x: x is not None, self._get_iterator()))
            else:
                return max(filter(lambda x: x is not None, map(selector, self._get_iterator())))
        except ValueError:
            return None

    def argmin(self, selector=lambda x: x) -> int:
        """
        Find the index of the minimum element in the given sequence according to the specified selector.

        :param selector: A function that defines the rule to select a value from each element in the sequence. It should
                         take one argument and return a value to compare.
        :type selector: function, optional
        :return: The index of the element with the minimum value based on the selector function.
        :rtype: int
        """
        idx = None
        best = None
        i = 0
        for item in map(selector, self):
            if best is None or item < best:
                best = item
                idx = i
            i += 1
        return idx

    def argmax(self, selector=lambda x: x) -> int:
        """
        Return the index of the maximum value in the iterable.

        :param selector: A function that maps each element of the iterable to a value. By default, it returns the element itself.
        :type selector: function
        :return: The index of the maximum value.
        :rtype: int
        """
        idx = None
        best = None
        i = 0
        for item in map(selector, self):
            if best is None or item > best:
                best = item
                idx = i
            i += 1
        return idx

    def all(self, predicate: _Predicate) -> bool:
        """
        :param predicate: The predicate function used to determine if each item in the iterable satisfies a certain condition.
        :return: Returns True if every item in the iterable satisfies the given predicate, False otherwise.
        """
        predicate = self._to_predicate(predicate)
        for item in self:
            if not predicate(item):
                return False

        return True

    def any(self, predicate: _Predicate) -> bool:
        """
        :param predicate: the function or method used to evaluate each item
        :return: boolean value indicating if any item meets the predicate condition

        """
        predicate = self._to_predicate(predicate)
        for item in self:
            if predicate(item):
                return True

        return False

    def reverse(self) -> "Stream[_T]":
        """
        Reverses the elements in the stream.

        :return: A new stream with the elements in reverse order.
        :rtype: Stream[T]
        """
        return Stream[_T].from_fn(lambda: _iteratools.reversed(self._get_iterator()))

    def take_while(self, condition: _Predicate[_T]) -> "Stream[_T]":
        """
        :param condition: A predicate function that takes an element of type T as input and returns True or False based on the condition that needs to be satisfied.
        :return: A new Stream object that contains elements from the current Stream object until the condition is no longer satisfied.

        """
        return Stream[_T].from_fn(lambda: _itertools.takewhile(condition, self._get_iterator()))

    def head(self, quantity: int) -> "Stream[_T]":
        """
        Take the specified quantity of elements from the stream.

        :param quantity: The number of elements to take.
        :return: A new Stream containing the taken elements.
        """
        return Stream[_T].from_fn(lambda: _itertools.islice(self._get_iterator(), quantity))

    def skip(self, quantity: int) -> "Stream[_T]":
        """
        :param quantity: int, the number of items to skip in the stream
        :return: Stream[T], a new stream containing the remaining items after skipping the specified quantity

        """
        return Stream[_T].from_fn(lambda x: _itertools.islice(self._get_iterator(), quantity, None))

    def _tail(self, n: int):
        iterator = self._get_iterator()
        output = []

        try:
            for _ in range(n):
                output.append(next(iterator))
        except:
            return output

        while True:
            try:
                tmp = next(iterator)
                output.pop(0)
                output.append(tmp)
            except:
                return output

    def tail(self, n: int) -> "Stream[_T]":
        """
        :param n: The number of elements to include in the tail. If `n` is `None`, the entire stream is returned.
        :return: A new stream containing the last `n` elements of the original stream.

        """
        return Stream.from_fn(lambda: self._tail(n))

    def batch(self, batch_size: int, drop_remainder: bool = False) -> "Stream[_t.List[_T]]":
        """
        :param batch_size: An integer representing the desired size of each batch.
        :param drop_remainder: A boolean indicating whether to drop the remaining elements if the total number of elements is not evenly divisible by the batch size.
        :return: A Stream object that produces batches of elements from the underlying iterator.

        """
        return Stream[_t.List[_T]].from_fn(lambda: _iteratools.batch(self._get_iterator(), batch_size, drop_remainder))

    def sum(self, mapper: _Mapper = None) -> _R:
        """
        Calculate the sum of the values in the iterator.

        :param mapper: A function that maps each value in the iterator before summing. Optional.
        :return: The sum of the values in the iterator.
        :rtype: R
        """
        if mapper is None:
            return sum(filter(lambda x: x is not None, self))
        return sum(filter(lambda x: x is not None, map(mapper, self)))

    def highest(self, mapper: _Mapper) -> _T:
        """
        Find the item with the highest value based on the mapping function.

        :param mapper: A callable that takes an item from the iterator and returns a value.
        :return: The item from the iterator with the highest value based on the mapping function.
        """
        max_value = None
        output = None

        for item in self._get_iterator():
            value = mapper(item)
            if output is None or value > max_value:
                output = item
                max_value = value

        return output

    def lowest(self, mapper: _Mapper) -> _T:
        """
        Finds the item with the lowest value based on the given mapper function.

        :param mapper: A function that maps an item to a value.
        :type mapper: function
        :return: The item with the lowest value according to the mapper function.
        :rtype: any
        """
        min_value = None
        output = None

        for item in self._get_iterator():
            value = mapper(item)
            if output is None or value < min_value:
                output = item
                min_value = value

        return output


class Group(Stream[_T], _t.Generic[_T, _R]):
    def __init__(self, key: _R, source):
        super().__init__(source)
        self._key = key

    @property
    def key(self):
        return self._key
