import typing as _t

_T = _t.TypeVar('_T')


class LazySequence(_t.Sequence[_T]):
    def __init__(self, iterable: _t.Iterable[_T]):
        self._iterator = iter(iterable)
        self._cache = []

    @property
    def cache(self):
        return self._cache

    def __iter__(self) -> _t.Iterator[_T]:
        for item in self._cache:
            yield item

        for item in self._iterator:
            self._cache.append(item)
            yield item

    def __len__(self) -> int:
        return len(self)

    def __getitem__(self, index: int) -> _T:
        i = 0
        for item in self:
            if i == index:
                return item
            i += 1
        raise IndexError()

    def __contains__(self, item: object) -> bool:
        for x in self:
            if x == item:
                return True
        return False
