def import_module(name, root_package=False, relative_globals=None, level=0):
    return __import__(name, locals=None,  # locals has no use
                      globals=relative_globals,
                      fromlist=[] if root_package else [None],
                      level=level)


def import_module_from_file(path: str):
    import importlib.util
    import os
    from pytools import strings

    module_name = strings.remove_suffix(os.path.basename(path), ".py", False)

    module_spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)

    return module


def import_module_from_package_file(package_path, module_name):
    package = import_module_from_file(package_path)
    return import_module_from_package(package, module_name)


def import_module_from_package(package, module_name: str, ):
    import importlib.util

    module_spec = importlib.util.spec_from_loader(module_name, package.__loader__)
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)

    return module
