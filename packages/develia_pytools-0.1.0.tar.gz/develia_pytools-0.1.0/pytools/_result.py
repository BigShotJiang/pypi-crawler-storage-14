import typing as _t

_T = _t.TypeVar("_T")


class Result(_t.Generic[_T]):
    def __init__(self, success: bool, data: _T):
        self._data: _T = data
        self._success: bool = success

    def __bool__(self):
        return self._success

    @property
    def value(self):
        return self._data
