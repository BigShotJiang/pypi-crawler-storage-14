"""Risk metrics (Sharpe, Sortino, etc.)."""

from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from ..math.stats import mean, stddev


def sharpe_ratio(
    returns: Iterable[Decimal], risk_free: Decimal = Decimal(0)
) -> Decimal | None:
    rets = [Decimal(r) - risk_free for r in returns]
    if not rets:
        return None
    volatility = stddev(rets, sample=True)
    if volatility == 0:
        return None
    return mean(rets) / volatility


def sortino_ratio(
    returns: Iterable[Decimal],
    risk_free: Decimal = Decimal(0),
    target: Decimal = Decimal(0),
) -> Decimal | None:
    rets = [Decimal(r) - risk_free for r in returns]
    downside = [min(Decimal(0), r - target) for r in rets]
    if not rets:
        return None
    downside_dev = stddev(downside, sample=True)
    if downside_dev == 0:
        return None
    return mean(rets) / downside_dev
