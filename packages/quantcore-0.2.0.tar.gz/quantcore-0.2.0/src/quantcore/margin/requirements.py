"""Margin requirement calculations."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Tuple

from ..core.types import Money, Rate, Price, Quantity
from ..utils.validation import ensure_non_negative


@dataclass(frozen=True)
class MarginRequirements:
    initial: Rate
    maintenance: Rate


@dataclass(frozen=True)
class MarginLevel:
    notional_threshold: Money
    initial: Rate
    maintenance: Rate


@dataclass(frozen=True)
class MarginSchedule:
    levels: Tuple[MarginLevel, ...]

    def for_notional(self, notional: Money) -> MarginRequirements:
        """Pick margin requirements for a given notional (highest threshold <= notional)."""
        if not self.levels:
            raise ValueError("MarginSchedule.levels must not be empty")

        notional_dec = abs(Decimal(notional))
        sorted_levels = sorted(
            self.levels, key=lambda level: Decimal(level.notional_threshold)
        )
        selected = sorted_levels[0]
        for level in sorted_levels:
            if notional_dec >= Decimal(level.notional_threshold):
                selected = level
        return MarginRequirements(
            initial=selected.initial,
            maintenance=selected.maintenance,
        )

    def for_size(self, size: Quantity, price: Price) -> MarginRequirements:
        """Pick margin requirements given position size and price."""
        notional = Money(abs(Decimal(size) * Decimal(price)))
        return self.for_notional(notional)

    def get_initial_margin_rate(
        self,
        *,
        notional: Money | None = None,
        size: Quantity | None = None,
        price: Price | None = None,
    ) -> Rate:
        """Convenience wrapper returning initial margin rate.

        Provide either:
          - notional, or
          - size and price (notional = |size * price|)
        """
        if notional is None:
            if size is None or price is None:
                raise ValueError("Provide either notional or (size and price)")
            notional = Money(abs(Decimal(size) * Decimal(price)))
        req = self.for_notional(notional)
        return Rate(req.initial)

    def get_maintenance_margin_rate(
        self,
        *,
        notional: Money | None = None,
        size: Quantity | None = None,
        price: Price | None = None,
    ) -> Rate:
        """Convenience wrapper returning maintenance margin rate.

        Provide either:
          - notional, or
          - size and price (notional = |size * price|)
        """
        if notional is None:
            if size is None or price is None:
                raise ValueError("Provide either notional or (size and price)")
            notional = Money(abs(Decimal(size) * Decimal(price)))
        req = self.for_notional(notional)
        return Rate(req.maintenance)


def calculate_initial_margin(notional: Money, req: MarginRequirements) -> Money:
    ensure_non_negative(notional, "notional")
    ensure_non_negative(req.initial, "initial margin rate")
    return abs(notional) * req.initial


def calculate_maintenance_margin(notional: Money, req: MarginRequirements) -> Money:
    ensure_non_negative(notional, "notional")
    ensure_non_negative(req.maintenance, "maintenance margin rate")
    return abs(notional) * req.maintenance
