"""Convenience helpers for common workflows."""

from __future__ import annotations

from typing import Sequence

from .core.protocols import BasePosition
from .events.fill import Fill
from .portfolio.portfolio import Portfolio
from .validators import validate_fill_sequence, validate_portfolio_state


def apply_fills(position: BasePosition, fills: Sequence[Fill]) -> BasePosition:
    """Apply a sequence of fills to a position."""
    validate_fill_sequence(fills)
    updated = position
    for fill in fills:
        updated = updated.apply_fill(fill)
    return updated


def apply_fills_to_portfolio(
    portfolio: Portfolio, fills: Sequence[Fill], *, timed_metric: str | None = None
) -> Portfolio:
    """Apply a sequence of fills to a portfolio, optionally timing the batch."""
    validate_fill_sequence(fills)
    if timed_metric:
        from .monitoring.metrics import timed_operation

        with timed_operation(timed_metric):
            for fill in fills:
                portfolio.apply_fill(fill)
    else:
        for fill in fills:
            portfolio.apply_fill(fill)

    validate_portfolio_state(portfolio, allow_negative_cash=True)
    return portfolio
