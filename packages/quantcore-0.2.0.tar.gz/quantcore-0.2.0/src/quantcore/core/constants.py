"""Global constants for quantcore."""

DEFAULT_DECIMAL_PRECISION: int = 28
DEFAULT_BASE_CURRENCY: str = "USD"
