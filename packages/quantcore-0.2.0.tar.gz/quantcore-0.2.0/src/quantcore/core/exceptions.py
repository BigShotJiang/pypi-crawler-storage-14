"""Custom exceptions used throughout quantcore."""


class QuantcoreError(Exception):
    """Base class for all quantcore-specific errors."""


class ValidationError(QuantcoreError):
    """Raised when inputs are invalid or invariants are violated."""


class MathError(QuantcoreError):
    """Raised when math operations fail or produce invalid results."""


class InsufficientMargin(QuantcoreError):
    """Raised when a margin requirement cannot be satisfied."""


class MarginViolationError(InsufficientMargin):
    """Raised when a margin requirement is explicitly violated."""


class PositionNotFound(QuantcoreError):
    """Raised when a requested position is missing."""


class InstrumentNotFound(QuantcoreError):
    """Raised when a requested instrument is missing."""


class InvalidFillError(ValidationError):
    """Raised when a fill is malformed or fails validation."""


class InconsistentPortfolioError(ValidationError):
    """Raised when portfolio/account invariants are violated."""
