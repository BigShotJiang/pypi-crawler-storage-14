"""Kelly criterion sizing."""

from __future__ import annotations

from decimal import Decimal


def kelly_fraction(win_rate: Decimal, win_loss_ratio: Decimal) -> Decimal:
    """Return Kelly fraction of bankroll to risk."""
    p = Decimal(win_rate)
    q = Decimal(1) - p
    if win_loss_ratio <= 0:
        raise ValueError("win_loss_ratio must be positive")
    return p - (q / Decimal(win_loss_ratio))
