"""Perpetual swap position implementation."""

from __future__ import annotations

from dataclasses import dataclass
from .base import BasePositionImpl


@dataclass(frozen=True)
class PerpetualPosition(BasePositionImpl):
    """Perpetual positions share base behavior; funding is applied via apply_funding."""

    pass
