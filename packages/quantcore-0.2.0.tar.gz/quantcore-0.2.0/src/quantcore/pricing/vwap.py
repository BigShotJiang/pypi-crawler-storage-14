"""VWAP calculation."""

from __future__ import annotations

from decimal import Decimal
from typing import Iterable, Tuple
from ..core.types import Price, Quantity


def vwap(data: Iterable[Tuple[Price, Quantity]]) -> Price:
    total_value = Decimal(0)
    total_qty = Decimal(0)
    for price, qty in data:
        total_value += Decimal(price) * Decimal(qty)
        total_qty += Decimal(qty)
    if total_qty == 0:
        raise ValueError("vwap requires positive total quantity")
    return total_value / total_qty
