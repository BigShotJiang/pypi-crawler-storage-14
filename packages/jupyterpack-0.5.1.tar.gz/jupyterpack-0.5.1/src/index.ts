import { spkPlugin } from './document/plugin';
import { swPlugin } from './swConnection';

export default [swPlugin, spkPlugin];
