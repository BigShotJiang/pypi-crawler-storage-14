declare module '*?raw' {
  const content: string;
  export default content;
}

declare module '*.svg' {
  const value: string;
  export default value;
}
