import { JupyterPackFramework } from '../../type';
import { BasePythonServer } from '../baseServer';

export class DashServer extends BasePythonServer {
  async init(options: {
    initCode?: string;
    instanceId: string;
    kernelClientId: string;
  }) {
    await super.init(options);
    const { initCode, instanceId, kernelClientId } = options;

    const baseURL = this.buildBaseURL({
      instanceId,
      kernelClientId,
      framework: JupyterPackFramework.DASH
    });
    await this.kernelExecutor.executeCode({
      code: `
      import os
      os.environ["DASH_URL_BASE_PATHNAME"] = "${baseURL}"
      `
    });
    if (initCode) {
      await this.kernelExecutor.executeCode({ code: initCode });
    }
    const loaderCode = `
      from jupyterpack.dash import DashServer
      ${this._server_var} = DashServer(app, "${baseURL}")
      `;
    await this.kernelExecutor.executeCode({ code: loaderCode });
  }

  async reloadPythonServer(options: {
    entryPath?: string;
    initCode?: string;
  }): Promise<void> {
    const { initCode } = options;
    if (initCode) {
      await this.kernelExecutor.executeCode({ code: initCode });
    }
    await this.kernelExecutor.executeCode(
      { code: `${this._server_var}.reload(app)` },
      true
    );
  }
}
