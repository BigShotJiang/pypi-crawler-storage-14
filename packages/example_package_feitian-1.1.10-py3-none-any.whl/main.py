
from example_package_fetian import *

print(add(1,2))
hello()