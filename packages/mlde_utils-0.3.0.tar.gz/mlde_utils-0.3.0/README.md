# Util code for ML downscaling emulator

## Configuration

### Environment variables

| Name | Description |
|------|-------------|
|`DATA_PATH`| The base path to where data is to be found |

