import warnings

warnings.warn(
    "relationalai.early_access.tests.* is deprecated. "
    "Please migrate to relationalai.semantics.tests.*",
    DeprecationWarning,
    stacklevel=2,
)