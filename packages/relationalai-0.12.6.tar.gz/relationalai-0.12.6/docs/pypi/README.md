# The RelationalAI Python Library

The Python library for building and querying knowledge graphs with RelationalAI.

For more information, visit our documentation at [https://relational.ai/docs](https://relational.ai/docs).
