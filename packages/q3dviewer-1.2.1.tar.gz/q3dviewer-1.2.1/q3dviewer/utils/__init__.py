from q3dviewer.utils.helpers import rainbow, text_to_rgba
from q3dviewer.utils.gl_helper import set_uniform