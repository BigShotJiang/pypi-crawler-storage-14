# Results

The project generates comprehensive visualizations for molecular systems.
Both visualizations demonstrate the dominance of the Hartree-Fock reference state with correlation corrections from excitations.
Basis state indices are converted from binary to decimal for shorter/clearer axis-labeling.

---

## 📚 Table of Contents
- [H₂ Optimiser Comparison](#h₂-optimiser-comparison)
- [H₂ ansatz Comparison](#h₂-ansatze-comparison)
- [H₂ Noisy VQE](#h₂-noisy-vqe)
- [H₂ Noiseless QPE](#h₂-noiseless-qpe)
- [H₂ Noisy QPE](#h₂-noisy-qpe)
- [H₃⁺ Excitation Comparison](#h₃⁺-excitation-comparison)
- [H₃⁺ Mapping Comparison](#h₃⁺-mapping-comparison)
- [H₃⁺ SSVQE](#h₃⁺-ssvqe)
- [H₃⁺ Noisy VQE](#h₃⁺-noisy-vqe)
- [LiH](#lih)
- [Optimal LiH Length](#optimal-lih-length)
- [H₂O](#h₂o)
- [Optimal H₂O Angle](#optimal-h₂o-angle)

---

## H₂ Optimiser Comparison

### Set Up

- **Bond Length**: $0.7414 Å$
- **Hartree-Fock Energy**: $-0.88842304 Ha$
- **Convergence**: $50$ iterations

### Visualization

Every optimiser, with step-size $0.2$, successfully converge to:

```
Adam:
Final ground state energy = -0.89801978 Ha

GradientDescent:
Final ground state energy = -0.89805304 Ha

Nesterov:
Final ground state energy = -0.89805302 Ha

Adagrad:
Final ground state energy = -0.89805304 Ha

Momentum:
Final ground state energy = -0.89801009 Ha

SPSA:
Final ground state energy = -0.89576313 Ha
```

![H₂ Optimizer Comparison](/data/vqe/images/H2_OptimizerComparison_UCCSD_s0.png)

The best optimizer for this dihydrogen example is the Gradient Descent.
Using this, the ground state is found:


```
Ground state of H₂:
|ψ⟩ = -0.0585|0011> + 0.9983|1100>
```

![H₂ Ground State](/data/vqe/images/H2_GroundState_UCCSD_Adam_s0.png)

---

## H₂ Ansatz Comparison

### Set Up

- **Bond Length**: $0.7414 Å$
- **Optimizer**: `AdamOptimizer` with step-size $0.2$
- **Iterations**: $80$
- **Ansatzes Compared**: `TwoQubit-RY-CNOT`, `RY-CZ`, `Minimal`

### Visualization

The following ansatzes were tested in a noiseless simulation:

- **TwoQubit-RY-CNOT**: A chemically motivated circuit including single and double excitations.
- **$R_Y-C_Z$**: A hardware-efficient structure using rotation and $C_Z$ entanglement layers.
- **Minimal**: A single-parameter ansatz tailored for H₂.

All three ansatzes successfully converged to near ground-state energies within $40$ iterations:

```
TwoQubit-RY-CNOT:
Final energy = -0.88770766 Ha

RY-CZ:
Final energy = -0.88769420 Ha

Minimal:
Final energy = -0.88810382 Ha
```

![H₂ Ansatzes Comparison](/data/vqe/images/H2_AnsatzComparison_Adam_s0.png)

Although all ansatzes reach similar energy minima, TwoQubit-RY-CNOT and RY-CZ converge slightly faster while **Minimal** shows mild oscillations mid-convergence.

---

## H₂ Noisy VQE

Six noise probabilities in the range $[0.0, 0.1]$ were used to compare how resilient different optimizers and ansatzes are to depolarizing or amplitude damping noise.

![H₂ Noisy Convergence](/data/vqe/images/H2_Depolarizing_Convergence_Adam_TwoQubit-RY-CNOT.png)

The reference energy above is the noiseless optimized final energy.
Depolarizing noise probability is proportional to final energy (as we will also see in the next plot).
Increasing noise strength also reduces the oscillations in convergence.

In the next three plots below, five seeds were used to calculate averages and standard deviations for more accurate results.
The plot below shows the fidelities of different optimizers under depolarizing noise.

![H₂ Noisy Optimisers](/data/vqe/images/H2_NoiseError_UCCSD_Adam_s0.png)

There were no noticeable differences in final energies reached between the different optimizers, for any depolarizing noise strength.

![H₂ Noisy Ansatzes](/data/vqe/images/H2_NoiseError_UCCSD_Adam_s0.png)

The TwoQubit-RY-CNOT and Minimal ansatzes had the most resilience to depolarizing noise, by consistently having the greatest fidelities with the smallest standard deviations.
The RY-CZ ansatz had the lowest fidelities for all noise levels, and the greatest standard deviations.

![H₂ Noise Types](/data/vqe/images/H2_NoiseError_UCCSD_Adam_s0.png)

Depolarizing noise had a more robust effect on fidelity and energy error, than amplitude damping noise, for all noise levels.

---

## H₂ Noiseless QPE

### Set Up

- **Bond Length**: $0.7414 Å$
- **Basis**: STO-3G
- **Ancillas**: $n=4$
- **Evolution time**: $t=1.0$
- **Trotter steps**: 2
- **Shots**: 1000
- **Reference (HF) Energy**: $-0.88842304 \text{Ha}$

### Noiseless Simulation

The noiseless QPE simulation for H₂ produces a sharp probability peak centered at the most probable ancilla register state:

```
Most probable state: |0100⟩
Estimated phase: 0.125000
Estimated energy: -0.78539816 Ha
ΔE (QPE − HF): 0.1030 Ha
```

![H₂ QPE distribution (noiseless)](/data/qpe/images/H2_QPE_NoiseDep_PeakMeanStd_s0.png)

As shown above, the ancilla register exhibits a clear, single dominant peak.  
This corresponds to the encoded ground-state phase from the unitary evolution $U = e^{-iHt}$.

### Parameter Sweeps

#### Number of Ancilla Qubits

Increasing the number of ancillas enhances phase precision.  
The energy estimate oscillates due to finite resolution, with bin width
$$\Delta E = \frac{2\pi}{t 2^n}$$

![Energy vs ancillas](/data/qpe/images/H2_QPE_NoiseDep_PeakMeanStd_s0.png)

#### Evolution Time

Longer evolution times improve phase resolution but risk aliasing if $|E| > \pi t$.  
The optimal $t$ balances resolution and unambiguous phase mapping.

![Energy vs evolution time](/data/qpe/images/H2_QPE_NoiseDep_PeakMeanStd_s0.png)

### Discussion

- **Accuracy:** The QPE-derived energy ($-0.7854\text{Ha}$) matches the correct phase branch near the HF reference.  
- **Resolution:** Increasing $n$ or $t$ improves granularity of measurable energies.  
- **Comparison to VQE:**  
  - VQE optimizes a parameterized state to *approximate* the ground state.  
  - QPE directly *measures* the eigenphase, yielding deterministic energies when coherence allows.  
  - On NISQ hardware, VQE remains more practical, while QPE benchmarks algorithmic precision and phase resolution.

---

## H₂ Noisy QPE

To study noise resilience, simple quantum channels were added after each controlled evolution step:
- **Depolarizing noise** with probability $p_{dep}$
- **Amplitude damping** with probability $p_{amp}$

Both channels were applied independently to all active wires.

### Example: Moderate Noise

For $p_{dep}=0.1$ and $p_{amp}=0.0$:

```
Most probable state: |0001⟩
Estimated phase: 0.062500
Estimated energy: -0.39269908 Ha
ΔE (QPE − HF): +0.49572396 Ha
```

![H₂ QPE distribution (noisy)](/data/qpe/images/H2_QPE_NoiseDep_PeakMeanStd_s0.png)

There is no lone state that is significantly more probable than the rest.
Depolarizing noise has caused information to be lost, as the ground state appears to be more randomised.

### Depolarizing Noise Sweep

A sweep from $p_{dep}=0.0$ to $0.1$ (amplitude damping fixed at $0$) shows only mild energy bias, but a gradual loss of peak sharpness.  
The plots below show **mean ± standard deviation** over **5 seeds**, highlighting the stochastic variability of noisy simulations.

![Energy vs depolarizing noise](/data/qpe/images/H2_QPE_Distribution_anc4_s0.png)

![Peak probability vs depolarizing noise](/data/qpe/images/H2_QPE_Distribution_anc4_s0.png)

- The **energy** remains close to the noiseless estimate for small $p_{dep}$ but exhibits increasing spread as noise grows.  
- The **peak probability** decreases steadily, following an approximately exponential decay, showing that depolarizing noise mainly reduces measurement confidence rather than biasing the energy.

### Amplitude-Damping Noise Sweep

With depolarizing noise fixed to zero, amplitude damping ($p_{amp}\in[0,0.1]$) introduces stronger bias toward higher apparent energies and reduced contrast in ancilla measurements.  
Again, the plots represent **mean ± standard deviation** over **5 seeds**.

![Energy vs amplitude damping](/data/qpe/images/H2_QPE_AncillaScan_Noiseless_s0.png)

![Peak probability vs amplitude damping](/data/qpe/images/H2_QPE_AncillaScan_Noiseless_s0.png)

- At low $p_{amp}$, the estimated energy remains near the noiseless result.  
- Beyond $p_{amp}\approx0.07$, dissipation dominates, pushing the apparent energy upward while the peak probability collapses toward zero.  
- This shows amplitude damping both **biases** and **decoheres** the measured eigenphase.

### Discussion

| Effect | Observation | Impact |
|:--|:--|:--|
| **Depolarizing noise** | Randomizes phase information across states | Increases variance (error bars), reduces peak contrast |
| **Amplitude damping** | Pulls population toward $\|0⟩$ | Systematically biases energy upward, reduces probability of the correct eigenphase |
| **Overall** | QPE is highly sensitive to both depolarization and dissipation | Reinforces the need for error-mitigation and fault-tolerant phase estimation |

These results confirm that QPE accurately extracts eigenenergies in ideal conditions but **degrades predictably with increasing noise**.  
Averaging over multiple seeds reveals both the **bias** and **variance** introduced by noise channels, offering a realistic benchmark for comparing **variational (VQE)** and **interferometric (QPE)** quantum chemistry methods on NISQ hardware.

---

## H₃⁺ Excitation Comparison

### Set Up

- **Molecular Geometry**: Equilateral triangle ($1.0 Å$ side length)
- **Charge**: $+1$
- **Electrons**: 2
- **Optimizer**: `Adam` with step-size $0.2$
- **Iterations**: $50$ per excitation type
- **Excitations Compared**: Single, Double, Both (UCCSD)

### Visualization

The simulation compares three ansatz types in a noiseless VQE run. Final ground state energies:

```
Single excitations only:
Final energy = -1.24434441 Ha

Double excitations only:
Final energy = -1.27005538 Ha

Single + Double (UCCSD):
Final energy = -1.27001939 Ha
```

![H₃⁺ Excitation Comparison](/data/vqe/images/H3plus_Excitation_Comparison.png)

The best convergence and lowest energy are achieved when both single and double excitations are used, consistent with the expected benefits of the full UCCSD ansatze.

The wavefunctions reveal a dominant contribution from the Hartree-Fock reference state, with notable amplitudes in correlated excited states. Example from UCCSD:

```
|ψ⟩ = -0.0883|000011⟩ + -0.0821|001100⟩ + 0.9927|110000⟩
```

This decomposition showcases the entanglement and correlation introduced by higher-order excitations. The Hartree-Fock state $|110000⟩$ is again dominant, but its amplitude is reduced relative to smaller molecules due to increased multi-reference character.

A quantum circuit diagram for the UCCSD ansatzes is below:

![H₃⁺ Circuit Diagram](/data/vqe/images/H3plus_UCCSD_Circuit.png)

---

## H₃⁺ Mapping Comparison

### Set Up

- **Molecular Geometry**: Slightly distorted triangular geometry
- **Coordinates**:  
  - H₁ = (0.000000,  1.000000,  0.000000)  
  - H₂ = (–0.866025, –0.500000,  0.000000)  
  - H₃ = (0.800000, –0.300000,  0.000000)
- **Charge**: $+1$
- **Electrons**: 2
- **Ansatze**: UCCSD (Singles + Doubles)
- **Optimizer**: `AdamOptimizer` with step-size $0.2$
- **Iterations**: $50$
- **Mappings Compared**: `jordan_wigner`, `bravyi_kitaev`, `parity`

### Visualization

The simulation compares three fermion-to-qubit encodings using the same ansatz and optimizer.
Final ground state energies:

```
jordan_wigner: -1.25867803 Ha
bravyi_kitaev: -0.67410221 Ha
parity:        -0.67413491 Ha
```

![H₃⁺ Mapping Comparison](/data/vqe/images/H3plus_NoiseError_AnsatzComparison_Adam.png)

The **Bravyi-Kitaev** mapping converges to the lowest energy among the three, though all mappings reach similar accuracy after $50$ iterations.

Each encoding transforms the fermionic Hamiltonian differently, influencing qubit operator structure and gradient behavior.  
This comparison highlights how even under identical ansatzes, fermion-to-qubit mapping can affect convergence rate and minima.

---

## H₃⁺ SSVQE

### Set Up

- **Molecular Geometry**: Equilateral triangle
- **Charge**: $+1$
- **Electrons**: $2$
- **Basis**: STO-3G
- **Ansatz**: UCC-style singles + doubles (from `qchem.excitations`)
- **Optimizer**: Adam with step-size $0.4$
- **Iterations**: $100$
- **Penalty Weight**: $10 * | ⟨ \psi_0 | \psi_1 ⟩ |^2$

### Visualization

SSVQE was used to variationally optimize the ground and first excited states simultaneously, enforcing orthogonality between the states.  
The final energies obtained were:

```
Final Ground State Energy (E₀):  -1.25054229 Ha
Final Excited State Energy (E₁): -0.58759689 Ha
Excitation Energy ΔE = E₁ - E₀:   0.66294540 Ha
```

![H₃⁺ SSVQE Adam Convergence](/data/vqe/images/H3plus_SSVQE_Adam.png)

The **ground state** is dominated by the Hartree–Fock configuration $|110000⟩$,  
while the **first excited state** shifts amplitude toward $|100100⟩$ and other configurations, showing clear state separation:

![H₃⁺ ψ₀ vs ψ₁ Decomposition](/data/vqe/images/H3plus_SSVQE_Adam.png)

The orthogonality penalty successfully suppressed overlap between the states, producing distinct quantum states with a meaningful excitation energy gap.

---

## H₃⁺ Noisy VQE

Five noise probabilities in the range $[0.0, 0.1]$ were used to compare how resilient different optimizers and ansatzes are to depolarizing or amplitude damping noise.

![H₃⁺ Noisy Convergence](/data/vqe/images/H3plus_Depolarizing_Convergence_Adam_TwoQubit-RY-CNOT.png)

The reference energy above is the noiseless optimized final energy.
Similarly to the H₂ results, depolarizing noise probability is proportional to final energy, and increasing noise strength slightly reduces the oscillations in convergence.

In the next three plots below, three seeds were used to calculate averages and standard deviations for more accurate results.
The plot below shows the fidelities of different optimizers under depolarizing noise.

![H₃⁺ Noisy Optimisers](/data/vqe/images/H3plus_NoiseError_AnsatzComparison_Adam.png)

Again, there were no noticeable differences between the different optimizers for H₃⁺.

![H₃⁺ Noisy Ansatzes](/data/vqe/images/H3plus_NoiseError_AnsatzComparison_Adam.png)

The RY-CZ ansatz had the lowest fidelities for all noise levels, and the greatest standard deviations.
TwoQubit-RY-CNOT and Minimal ansatzes were both most resilient to depolarizing noise.

![H₃⁺ Noise Types](/data/vqe/images/H3plus_NoiseError_AnsatzComparison_Adam.png)

Similarly to the H₂ results, depolarizing noise had a more robust effect on fidelity than amplitude damping noise.
However, amplitude damping gave larger energy errors despite being more fidelitous

---

## LiH

### Set Up

- **Bond Length**: $1.6 Å$
- **Hartree-Fock Energy**: $-7.66194677 Ha$
- **Convergence**: $50$ iterations

### Visualization

`GradientDescentOptimizer` with step-size $0.2$ successfully converges at ground state energy $-7.67972341 Ha$:

![LiH Gradient Descent](/data/vqe/images/LiH_GradientDescent.png)

The calculated wavefunction for the ground state of LiH is:

```
|ψ⟩ = - 0.1010|110000000011⟩ - 0.0393|110000001100⟩
      - 0.0393|110000110000⟩ - 0.0365|110001000010⟩
      + 0.0365|110010000001⟩ - 0.0155|110011000000⟩
      + 0.9918|111100000000⟩
```

The Hartree-Fock state $|111100000000⟩$ is the most dominant.

![LiH Ground State](/data/vqe/images/LiH_GroundState_UCCSD_Adam_s0.png)

---

## Optimal LiH Length

The Gradient Descent Optimizer was used to scan over a range of bond-lengths between the Li and H atoms.
$25$ maximum iterations and a stepsize of $0.8$ were used, over $10$ bond-lengths in the range $[1.1, 2.1] Å$.
Plot output from `LiH_Bond_Length.ipynb`:

![LiH Bond Length Scan](/data/vqe/images/LiH_BondLengthScan_UCCSD_Adam_s0.png)

```
Optimal bond length: 1.66 Å
Minimum ground state energy: -5.59345560 Ha
```

---

## H₂O

### Set Up

- **Bond Lengths**: $0.910922 Å$
- **Molecular Geometry**: Bent structure ($104.5°$ bond angle)
- **Hartree-Fock Energy**: $-72.86837737 Ha$
- **Convergence**: $50$ iterations with Adam optimizer

### Visualization

`AdamOptimizer` with step-size $0.2$ successfully converges at ground state energy $-72.85526883516486 Ha$:

![H₂O Adam Convergence](/data/vqe/images/H2O_Adam_GroundState.png)

The calculated wavefunction for the ground state of water is:

```
|ψ⟩ = - 0.0112|11001111111100⟩ + 0.0171|11011011111001⟩ + 0.0117|11011111110010⟩
      - 0.0226|11110011110011⟩ - 0.0279|11111100110011⟩ + 0.0123|11111101101100⟩
      + 0.0110|11111110010110⟩ + 0.0122|11111110011100⟩ + 0.0223|11111110110100⟩
      - 0.0130|11111111001100⟩ - 0.0161|11111111011000⟩ - 0.0104|11111111100100⟩
      + 0.9970|11111111110000⟩
```

The Hartree-Fock state $|11111111110000⟩$ is the most dominant.

![H₂O Ground State](/data/vqe/images/H2O_GroundState_UCCSD_Adam_s0.png)

---

## Optimal H₂O Angle

The Adam optimizer was used to find the angle between the two hydrogens about the oxygen.
$20$ maximum iterations and a stepsize of $0.2$ were used, over $10$ bond-angles in the range $[100, 109]°$.
Plot output from `H2O_Bond_Angle.ipynb`:

![H₂O Bond Angle Scan](/data/vqe/images/H2O_BondAngleScan_UCCSD_Adam_s0.png)

```
Minimum energy: -70.119419 Ha
Optimal angle: 104.00°
```

These values are very close to the true ground state energy ($\approx -75 Ha$) and bond-angle ($\approx 104.5°$) of water.

### Optimal Angle References

- [Chemical bonding of water](https://en.wikipedia.org/wiki/Chemical_bonding_of_water)
- [Ground-state energy estimation of the water molecule on a trapped ion quantum computer](https://arxiv.org/abs/1902.10171)

---

📘 Author: Sid Richards (SidRichardsQuantum)

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linkedin/linkedin-original.svg" width="20" /> LinkedIn: https://www.linkedin.com/in/sid-richards-21374b30b/

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
