from collections import Counter

class FrozenCounter:

    def __init__(self, iterable=None):
        if iterable is None:
            self._counter = Counter()
        else:
            self._counter = Counter(iterable)

        counter_items = self._counter.items()
        frozen_items = frozenset(counter_items)
        self._hash = hash(frozen_items)

    def __getitem__(self, key):
        return self._counter[key]

    def __iter__(self):
        return iter(self._counter)

    def __len__(self):
        return len(self._counter)

    def items(self):
        return self._counter.items()

    def keys(self):
        return self._counter.keys()

    def values(self):
        return self._counter.values()

    def __hash__(self):
        return self._hash

    def __eq__(self, other):
        if isinstance(other, FrozenCounter):
            return self._counter == other._counter
        return NotImplemented

    def __repr__(self):
        return f"FrozenCounter({dict(self._counter)})"