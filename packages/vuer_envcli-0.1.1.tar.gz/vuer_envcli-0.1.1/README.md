# Vuer Hub Environment CLI

`vuer.env` is a lightweight CLI for uploading and downloading environment
packages to/from a Vuer Hub backend. It is
built on top of [`params-proto`](https://github.com/episodeyang/params_proto)
and works great for CI/CD pipelines as
well as local development workflows.

## Features

- `push` – upload a packaged environment file with metadata (name, version,
  visibility, etc.)
- `pull` – download an environment by `environmentId`
- **Progress bars** – visual feedback for upload/download operations
- **Configurable timeouts** – set custom timeout values for large file
  transfers
- Automatic JWT handling via env variable (`VUER_AUTH_TOKEN`)
- Configurable API base URL (`VUER_BACKEND_ENDPOINT`)
- Friendly error messages and helpful command-level `--help` output

## Installation

```bash
pip install vuer-envcli
```

> During local development you can install the project in editable mode:
> ```bash
> cd /Users/masterchen/vur-hub-10-31/vuer-hub/envcli
> pip install -e .
> ```

## Environment Variables

| Variable                | Required | Description                                   |
|-------------------------|---------|-----------------------------------------------|
| `VUER_AUTH_TOKEN`       | ✅       | JWT token used for all authenticated requests |
| `VUER_BACKEND_ENDPOINT` | ❌       | Base URL of the Vuer Hub API backend(defaults to `https://staging-api.vuer.ai`)|

```bash
export VUER_AUTH_TOKEN="your-jwt-token"
export VUER_BACKEND_ENDPOINT="https://api.vuerhub.com"
```

## Usage Overview

```bash
vuer.env push --file <path> --name <name> --version <semver> [options...]
vuer.env pull --id <environmentId> [--output <dir>] [--filename <name>]
```

Run `vuer.env --help`, `vuer.env push --help`, or `vuer.env pull --help` to get
detailed descriptions of every option.

## Push Command

Upload a packaged environment:

```bash
vuer.env push \
  --file ./build/my-env.zip \
  --name demo-env \
  --version 1.2.3 \
  --description "Demo package" \
  --env-type isaac \
  --visibility PUBLIC \
  --push-timeout 600
```

### Push Flags

| Flag                     | Required | Description                                                |
|--------------------------|----------|------------------------------------------------------------|
| `--file PATH`            | ✅        | Path to the package file (zip/tar/etc.)                    |
| `--name NAME`            | ✅        | Environment name without spaces                            |
| `--version SEMVER`       | ✅        | Semver-compliant version string (`1.2.3`, `2.0.0-beta`, …) |
| `--description TEXT`     | ❌        | Optional text                                              |
| `--env-type TYPE`        | ❌        | Example: `isaac`, `mujoco`                                 |
| `--visibility VIS`       | ❌        | `PUBLIC` (default), `PRIVATE`, or `ORG_MEMBERS`            |
| `--push-timeout SECONDS` | ❌        | Request timeout in seconds (default: 300)                  |

## Pull Command

Download an environment by ID:

```bash
vuer.env pull \
  --id 252454509945688064 \
  --output ./downloads \
  --filename demo-env.zip \
  --pull-timeout 600
```

If `--filename` is omitted, the tool will try to derive the original filename
from the server’s `Content-Disposition`
header. Files are stored under the `downloads/` directory by default.

### Pull Flags

| Flag                     | Required | Description                                 |
|--------------------------|----------|---------------------------------------------|
| `--id ENVIRONMENT_ID`    | ✅        | Target environment’s `environmentId`        |
| `--output DIR`           | ❌        | Destination directory (default `downloads`) |
| `--filename NAME`        | ❌        | Override for the saved filename             |
| `--pull-timeout SECONDS` | ❌        | Request timeout in seconds (default: 300)   |

## Progress Bars

The CLI displays progress bars during upload and download operations:

- **Upload**: Shows file size and upload progress with transfer rate
- **Download**: Shows download progress with transfer rate (total size shown if
  available from server)

Progress bars automatically adjust for large files and provide real-time
feedback.

## Error Handling

All network and file-system errors are surfaced as readable messages (prefixed
with `[ERROR]`). Typical causes:

- Invalid JWT → ensure `VUER_AUTH_TOKEN` is set and not expired.
- Missing backend endpoint → ensure `VUER_BACKEND_ENDPOINT` is set.
- Duplicate name/version on `push` → server enforces `(name, versionId)`
  uniqueness.
- Missing file path on `push` or invalid target directory on `pull`.
- Timeout errors → increase `--push-timeout` or `--pull-timeout` for large
  files.

## Development

1. Clone the main repository and navigate into the CLI folder.
2. Install dependencies:
   ```bash
   pip install -e .
   ```
3. Run the CLI locally using `vuer.env ...`.
