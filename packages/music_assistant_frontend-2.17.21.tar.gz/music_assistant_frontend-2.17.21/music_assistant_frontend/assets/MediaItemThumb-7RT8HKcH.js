import{_ as a,cw as s}from"./index-It2prjj_.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
