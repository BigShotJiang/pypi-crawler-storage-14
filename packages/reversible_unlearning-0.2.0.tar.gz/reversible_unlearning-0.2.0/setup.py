﻿from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as fh:
    long_description = fh.read()

setup(
    name='reversible-unlearning',
    version='0.2.0',
    author='AUREON Labs',
    author_email='research@aureon.ai',
    description='AUREON: Universal Reversible Learning with 0.671 Constant',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/aureon-labs/reversible',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
    install_requires=['torch>=1.9.0', 'numpy>=1.19.0', 'transformers>=4.0.0', 'datasets>=2.0.0'],
)
