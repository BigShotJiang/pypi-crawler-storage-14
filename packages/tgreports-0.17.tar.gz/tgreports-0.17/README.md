# Telegram reports
Report logs and notifications on Telegram chat and in log files

[GitHub](https://github.com/chilleco/tgreports)
 | [PyPI](https://pypi.org/project/tgreports/)
