"""Fixtures package initialization."""
