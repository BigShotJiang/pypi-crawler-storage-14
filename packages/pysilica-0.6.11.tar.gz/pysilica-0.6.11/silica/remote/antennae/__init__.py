"""Antennae web application for remote workspace management.

Each antennae instance manages exactly one workspace containing a tmux session
running silica developer. The webapp provides HTTP endpoints for workspace
lifecycle management.
"""
