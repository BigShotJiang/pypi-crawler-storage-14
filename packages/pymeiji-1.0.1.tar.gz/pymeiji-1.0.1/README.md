# tamaki-solver-wrappers
Python and rust wrappers for meiji PACE 2017 treewidth solver
