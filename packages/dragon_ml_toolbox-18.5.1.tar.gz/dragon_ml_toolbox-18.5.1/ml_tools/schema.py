from ._core._schema import (
    FeatureSchema,
    info
)

__all__ = [
    "FeatureSchema"
]
