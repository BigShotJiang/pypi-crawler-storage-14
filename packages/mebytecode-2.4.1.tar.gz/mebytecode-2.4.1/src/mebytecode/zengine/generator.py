import sys
import types
import dis
from typing import Dict, List, Optional, Tuple, Any, Union, Callable

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]
OPMAP = dis.opmap
PYTHON_311_PLUS = PYTHON_VERSION >= (3, 11)

class GeneratorError(Exception):
    pass

class PythonVersionWarning(UserWarning):
    pass

class CodeBlock:
    
    def __init__(self, name=None):
        self.name = name or "_block"
        self.instructions = []
        self.labels = {}
        self.pending_jumps = []
    
    def add_instruction(self, instruction):
        self.instructions.append(instruction)
    
    def create_label(self, name=None):
        if name is None:
            name = "_L{}".format(len(self.labels))
        self.labels[name] = None
        return name
    
    def bind_label(self, name):
        self.labels[name] = len(self.instructions)
    
    def add_jump(self, opcode, label):
        self.pending_jumps.append((len(self.instructions), opcode, label))
        from .instructions import InstructionFactory
        self.instructions.append(InstructionFactory.create_from_opcode(opcode, 0))

def _get_opcode(name, fallback=None):
    return OPMAP.get(name, fallback)

class FunctionBuilder:
    
    def __init__(self, name="<generated>", filename="<generated>"):
        self.name = name
        self.filename = filename
        self._consts = [None]
        self._names = []
        self._varnames = []
        self._freevars = []
        self._cellvars = []
        self._code_buffer = bytearray()
        self._labels = {}
        self._pending_jumps = []
        self._argcount = 0
        self._kwonlyargcount = 0
        self._posonlyargcount = 0
        self._flags = 0
        self._firstlineno = 1
        self._resume_emitted = False
    
    def set_argcount(self, count):
        self._argcount = count
        return self
    
    def set_flags(self, flags):
        self._flags = flags
        return self
    
    def add_flag(self, flag):
        self._flags |= flag
        return self
    
    def _add_const(self, value):
        for i, c in enumerate(self._consts):
            if c == value and type(c) is type(value):
                return i
        index = len(self._consts)
        self._consts.append(value)
        return index
    
    def _add_name(self, name):
        if name in self._names:
            return self._names.index(name)
        index = len(self._names)
        self._names.append(name)
        return index
    
    def _add_varname(self, name):
        if name in self._varnames:
            return self._varnames.index(name)
        index = len(self._varnames)
        self._varnames.append(name)
        return index
    
    def _emit(self, opcode, arg=0):
        if PYTHON_VERSION >= (3, 6):
            while arg > 0xFF:
                self._code_buffer.extend([144, (arg >> 8) & 0xFF])
                arg &= 0xFF
            self._code_buffer.extend([opcode, arg])
        else:
            if opcode >= 90:
                self._code_buffer.extend([opcode, arg & 0xFF, (arg >> 8) & 0xFF])
            else:
                self._code_buffer.append(opcode)
    
    def emit_nop(self):
        self._emit(9)
        return self
    
    def emit_pop_top(self):
        self._emit(1)
        return self
    
    def emit_rot_two(self):
        self._emit(2)
        return self
    
    def emit_rot_three(self):
        self._emit(3)
        return self
    
    def emit_dup_top(self):
        self._emit(4)
        return self
    
    def emit_return_value(self):
        self._emit(83)
        return self
    
    def emit_load_const(self, value):
        index = self._add_const(value)
        self._emit(100, index)
        return self
    
    def emit_load_fast(self, name):
        index = self._add_varname(name)
        self._emit(124, index)
        return self
    
    def emit_store_fast(self, name):
        index = self._add_varname(name)
        self._emit(125, index)
        return self
    
    def emit_delete_fast(self, name):
        index = self._add_varname(name)
        self._emit(126, index)
        return self
    
    def emit_load_global(self, name):
        index = self._add_name(name)
        self._emit(116, index)
        return self
    
    def emit_store_global(self, name):
        index = self._add_name(name)
        self._emit(97, index)
        return self
    
    def emit_load_name(self, name):
        index = self._add_name(name)
        self._emit(101, index)
        return self
    
    def emit_store_name(self, name):
        index = self._add_name(name)
        self._emit(90, index)
        return self
    
    def emit_load_attr(self, name):
        index = self._add_name(name)
        self._emit(106, index)
        return self
    
    def emit_store_attr(self, name):
        index = self._add_name(name)
        self._emit(95, index)
        return self
    
    def emit_binary_add(self):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("BINARY_OP", 122), 0)
        else:
            self._emit(_get_opcode("BINARY_ADD", 23))
        return self
    
    def emit_binary_subtract(self):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("BINARY_OP", 122), 10)
        else:
            self._emit(_get_opcode("BINARY_SUBTRACT", 24))
        return self
    
    def emit_binary_multiply(self):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("BINARY_OP", 122), 5)
        else:
            self._emit(_get_opcode("BINARY_MULTIPLY", 20))
        return self
    
    def emit_binary_divide(self):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("BINARY_OP", 122), 11)
        else:
            self._emit(_get_opcode("BINARY_TRUE_DIVIDE", 27))
        return self
    
    def emit_binary_floor_divide(self):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("BINARY_OP", 122), 2)
        else:
            self._emit(_get_opcode("BINARY_FLOOR_DIVIDE", 26))
        return self
    
    def emit_binary_modulo(self):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("BINARY_OP", 122), 6)
        else:
            self._emit(_get_opcode("BINARY_MODULO", 22))
        return self
    
    def emit_binary_power(self):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("BINARY_OP", 122), 8)
        else:
            self._emit(_get_opcode("BINARY_POWER", 19))
        return self
    
    def emit_binary_subscr(self):
        self._emit(_get_opcode("BINARY_SUBSCR", 25))
        return self
    
    def emit_resume(self, arg=0):
        if PYTHON_VERSION >= (3, 11):
            self._emit(_get_opcode("RESUME", 151), arg)
        return self
    
    def _ensure_resume(self):
        if PYTHON_VERSION >= (3, 11) and not self._resume_emitted:
            self._resume_emitted = True
            resume_op = _get_opcode("RESUME", 151)
            temp = bytearray([resume_op, 0])
            temp.extend(self._code_buffer)
            self._code_buffer = temp
    
    def emit_unary_positive(self):
        self._emit(10)
        return self
    
    def emit_unary_negative(self):
        self._emit(11)
        return self
    
    def emit_unary_not(self):
        self._emit(12)
        return self
    
    def emit_unary_invert(self):
        self._emit(15)
        return self
    
    def emit_compare_op(self, op):
        ops = {"<": 0, "<=": 1, "==": 2, "!=": 3, ">": 4, ">=": 5}
        if isinstance(op, str):
            op = ops.get(op, 0)
        self._emit(107, op)
        return self
    
    def emit_call_function(self, argc):
        self._emit(131, argc)
        return self
    
    def emit_call_method(self, argc):
        self._emit(161, argc)
        return self
    
    def emit_load_method(self, name):
        index = self._add_name(name)
        self._emit(160, index)
        return self
    
    def emit_build_tuple(self, count):
        self._emit(102, count)
        return self
    
    def emit_build_list(self, count):
        self._emit(103, count)
        return self
    
    def emit_build_set(self, count):
        self._emit(104, count)
        return self
    
    def emit_build_map(self, count):
        self._emit(105, count)
        return self
    
    def emit_make_function(self, flags):
        self._emit(132, flags)
        return self
    
    def emit_get_iter(self):
        self._emit(68)
        return self
    
    def create_label(self, name=None):
        if name is None:
            name = "_L{}".format(len(self._labels))
        self._labels[name] = None
        return name
    
    def bind_label(self, name):
        self._labels[name] = len(self._code_buffer)
        return self
    
    def emit_jump_absolute(self, label):
        offset = len(self._code_buffer)
        self._pending_jumps.append((offset, 113, label))
        if PYTHON_VERSION >= (3, 6):
            self._code_buffer.extend([113, 0])
        else:
            self._code_buffer.extend([113, 0, 0])
        return self
    
    def emit_jump_forward(self, label):
        offset = len(self._code_buffer)
        self._pending_jumps.append((offset, 110, label))
        if PYTHON_VERSION >= (3, 6):
            self._code_buffer.extend([110, 0])
        else:
            self._code_buffer.extend([110, 0, 0])
        return self
    
    def emit_pop_jump_if_false(self, label):
        offset = len(self._code_buffer)
        self._pending_jumps.append((offset, 114, label))
        if PYTHON_VERSION >= (3, 6):
            self._code_buffer.extend([114, 0])
        else:
            self._code_buffer.extend([114, 0, 0])
        return self
    
    def emit_pop_jump_if_true(self, label):
        offset = len(self._code_buffer)
        self._pending_jumps.append((offset, 115, label))
        if PYTHON_VERSION >= (3, 6):
            self._code_buffer.extend([115, 0])
        else:
            self._code_buffer.extend([115, 0, 0])
        return self
    
    def emit_for_iter(self, label):
        offset = len(self._code_buffer)
        self._pending_jumps.append((offset, 93, label))
        if PYTHON_VERSION >= (3, 6):
            self._code_buffer.extend([93, 0])
        else:
            self._code_buffer.extend([93, 0, 0])
        return self
    
    def _resolve_jumps(self):
        for offset, opcode, label in self._pending_jumps:
            target = self._labels.get(label)
            if target is None:
                raise GeneratorError("Unbound label: {}".format(label))
            
            if opcode in (93, 110):
                delta = target - offset - 2
                if PYTHON_VERSION >= (3, 6):
                    self._code_buffer[offset + 1] = delta & 0xFF
                else:
                    self._code_buffer[offset + 1] = delta & 0xFF
                    self._code_buffer[offset + 2] = (delta >> 8) & 0xFF
            else:
                if PYTHON_VERSION >= (3, 6):
                    self._code_buffer[offset + 1] = target & 0xFF
                else:
                    self._code_buffer[offset + 1] = target & 0xFF
                    self._code_buffer[offset + 2] = (target >> 8) & 0xFF
    
    def build(self):
        self._ensure_resume()
        self._resolve_jumps()
        bytecode = bytes(self._code_buffer)
        stacksize = max(16, len(bytecode) // 4)
        nlocals = len(self._varnames)
        
        if PYTHON_VERSION >= (3, 11):
            code = types.CodeType(
                self._argcount,
                self._posonlyargcount,
                self._kwonlyargcount,
                nlocals,
                stacksize,
                self._flags,
                bytecode,
                tuple(self._consts),
                tuple(self._names),
                tuple(self._varnames),
                self.filename,
                self.name,
                self.name,
                self._firstlineno,
                b"",
                b"",
                tuple(self._freevars),
                tuple(self._cellvars)
            )
        elif PYTHON_VERSION >= (3, 8):
            code = types.CodeType(
                self._argcount,
                self._posonlyargcount,
                self._kwonlyargcount,
                nlocals,
                stacksize,
                self._flags,
                bytecode,
                tuple(self._consts),
                tuple(self._names),
                tuple(self._varnames),
                self.filename,
                self.name,
                self._firstlineno,
                b"",
                tuple(self._freevars),
                tuple(self._cellvars)
            )
        else:
            code = types.CodeType(
                self._argcount,
                self._kwonlyargcount,
                nlocals,
                stacksize,
                self._flags,
                bytecode,
                tuple(self._consts),
                tuple(self._names),
                tuple(self._varnames),
                self.filename,
                self.name,
                self._firstlineno,
                b"",
                tuple(self._freevars),
                tuple(self._cellvars)
            )
        
        return code
    
    def build_function(self, globals_dict=None):
        code = self.build()
        if globals_dict is None:
            globals_dict = {}
        return types.FunctionType(code, globals_dict, self.name)

class ExpressionGenerator:
    
    def __init__(self, builder):
        self._builder = builder
    
    def const(self, value):
        self._builder.emit_load_const(value)
        return self
    
    def var(self, name):
        self._builder.emit_load_fast(name)
        return self
    
    def global_var(self, name):
        self._builder.emit_load_global(name)
        return self
    
    def add(self):
        self._builder.emit_binary_add()
        return self
    
    def sub(self):
        self._builder.emit_binary_subtract()
        return self
    
    def mul(self):
        self._builder.emit_binary_multiply()
        return self
    
    def div(self):
        self._builder.emit_binary_divide()
        return self
    
    def call(self, argc):
        self._builder.emit_call_function(argc)
        return self
    
    def compare(self, op):
        self._builder.emit_compare_op(op)
        return self

def create_function_builder(name="<generated>", filename="<generated>"):
    return FunctionBuilder(name, filename)

def generate_simple_function(name, body_generator, argcount=0, argnames=None):
    builder = FunctionBuilder(name)
    builder.set_argcount(argcount)
    
    if argnames:
        for argname in argnames:
            builder._add_varname(argname)
    
    body_generator(builder)
    builder.emit_return_value()
    
    return builder.build_function()

def generate_constant_function(name, value):
    builder = FunctionBuilder(name)
    builder.emit_load_const(value)
    builder.emit_return_value()
    return builder.build_function()

def generate_identity_function(name="identity"):
    builder = FunctionBuilder(name)
    builder.set_argcount(1)
    builder._add_varname("x")
    builder.emit_load_fast("x")
    builder.emit_return_value()
    return builder.build_function()
