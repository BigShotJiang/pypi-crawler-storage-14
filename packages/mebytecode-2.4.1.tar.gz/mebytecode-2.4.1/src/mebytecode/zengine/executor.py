import sys
import types
import threading
from typing import Dict, List, Optional, Tuple, Any, Callable, Union

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class ExecutionError(Exception):
    pass

class ExecutionState:
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class ExecutionContext:
    
    def __init__(self, globals_dict=None, locals_dict=None):
        self.globals_dict = globals_dict if globals_dict is not None else {}
        self.locals_dict = locals_dict if locals_dict is not None else {}
        self.stack = []
        self.return_value = None
        self.exception = None
        self.state = ExecutionState.PENDING
        self.instruction_count = 0
        self.callbacks = {}
    
    def push(self, value):
        self.stack.append(value)
    
    def pop(self):
        if self.stack:
            return self.stack.pop()
        raise ExecutionError("Stack underflow")
    
    def peek(self, index=-1):
        if self.stack:
            return self.stack[index]
        return None
    
    def set_return(self, value):
        self.return_value = value
    
    def set_exception(self, exc):
        self.exception = exc
        self.state = ExecutionState.FAILED
    
    def add_callback(self, event, callback):
        if event not in self.callbacks:
            self.callbacks[event] = []
        self.callbacks[event].append(callback)
    
    def trigger(self, event, *args, **kwargs):
        for callback in self.callbacks.get(event, []):
            callback(self, *args, **kwargs)
    
    def copy(self):
        ctx = ExecutionContext(dict(self.globals_dict), dict(self.locals_dict))
        ctx.stack = list(self.stack)
        ctx.return_value = self.return_value
        ctx.exception = self.exception
        ctx.state = self.state
        ctx.instruction_count = self.instruction_count
        return ctx

class ExecutionConfig:
    
    def __init__(self):
        self.max_instructions = None
        self.max_stack_size = 1000
        self.timeout = None
        self.trace_enabled = False
        self.breakpoints = set()
        self.step_mode = False
    
    def set_max_instructions(self, count):
        self.max_instructions = count
        return self
    
    def set_max_stack(self, size):
        self.max_stack_size = size
        return self
    
    def set_timeout(self, seconds):
        self.timeout = seconds
        return self
    
    def enable_trace(self, enabled=True):
        self.trace_enabled = enabled
        return self
    
    def add_breakpoint(self, offset):
        self.breakpoints.add(offset)
        return self
    
    def remove_breakpoint(self, offset):
        self.breakpoints.discard(offset)
        return self
    
    def enable_step_mode(self, enabled=True):
        self.step_mode = enabled
        return self

class ExecutionResult:
    
    def __init__(self, context):
        self.value = context.return_value
        self.state = context.state
        self.exception = context.exception
        self.instruction_count = context.instruction_count
        self.final_stack = list(context.stack)
    
    @property
    def is_success(self):
        return self.state == ExecutionState.COMPLETED
    
    @property
    def is_failed(self):
        return self.state == ExecutionState.FAILED
    
    def __repr__(self):
        return "ExecutionResult(state={}, value={!r})".format(self.state, self.value)

class BytecodeExecutor:
    
    def __init__(self, code=None):
        self._code = code
        self._context = None
        self._config = ExecutionConfig()
        self._instructions = None
        self._offset = 0
        self._running = False
        self._lock = threading.Lock()
    
    def set_code(self, code):
        self._code = code
        self._instructions = None
        return self
    
    def set_config(self, config):
        self._config = config
        return self
    
    def set_context(self, context):
        self._context = context
        return self
    
    def _prepare(self):
        if self._code is None:
            raise ExecutionError("No code object provided")
        
        if self._context is None:
            self._context = ExecutionContext()
        
        if self._instructions is None:
            from .disassembler import BytecodeDisassembler
            disasm = BytecodeDisassembler(self._code)
            self._instructions = disasm.disassemble()
        
        self._offset = 0
        self._context.state = ExecutionState.RUNNING
    
    def execute(self, code=None, globals_dict=None, locals_dict=None):
        if code is not None:
            self._code = code
        
        if globals_dict is not None or locals_dict is not None:
            self._context = ExecutionContext(globals_dict, locals_dict)
        
        self._prepare()
        
        with self._lock:
            self._running = True
        
        try:
            result = self._run()
        except Exception as e:
            self._context.set_exception(e)
            result = ExecutionResult(self._context)
        finally:
            with self._lock:
                self._running = False
        
        return result
    
    def _run(self):
        offset_to_idx = {instr.offset: i for i, instr in enumerate(self._instructions)}
        idx = 0
        
        while idx < len(self._instructions):
            if self._config.max_instructions is not None:
                if self._context.instruction_count >= self._config.max_instructions:
                    raise ExecutionError("Maximum instruction count exceeded")
            
            if len(self._context.stack) > self._config.max_stack_size:
                raise ExecutionError("Maximum stack size exceeded")
            
            instr = self._instructions[idx]
            
            if instr.offset in self._config.breakpoints:
                self._context.state = ExecutionState.PAUSED
                self._context.trigger("breakpoint", instr)
            
            if self._config.trace_enabled:
                self._context.trigger("trace", instr)
            
            self._context.instruction_count += 1
            
            result = self._execute_instruction(instr)
            
            if result is None:
                idx += 1
            elif isinstance(result, int):
                target_idx = offset_to_idx.get(result)
                if target_idx is not None:
                    idx = target_idx
                else:
                    idx += 1
            elif result == "return":
                break
        
        if self._context.state == ExecutionState.RUNNING:
            self._context.state = ExecutionState.COMPLETED
        
        return ExecutionResult(self._context)
    
    def _execute_instruction(self, instr):
        opcode = instr.opcode
        arg = instr.arg if instr.arg is not None else 0
        
        if opcode == 1:
            self._context.pop()
        
        elif opcode == 2:
            a = self._context.pop()
            b = self._context.pop()
            self._context.push(a)
            self._context.push(b)
        
        elif opcode == 3:
            a = self._context.pop()
            b = self._context.pop()
            c = self._context.pop()
            self._context.push(a)
            self._context.push(c)
            self._context.push(b)
        
        elif opcode == 4:
            self._context.push(self._context.peek())
        
        elif opcode == 9:
            pass
        
        elif opcode == 10:
            a = self._context.pop()
            self._context.push(+a)
        
        elif opcode == 11:
            a = self._context.pop()
            self._context.push(-a)
        
        elif opcode == 12:
            a = self._context.pop()
            self._context.push(not a)
        
        elif opcode == 15:
            a = self._context.pop()
            self._context.push(~a)
        
        elif opcode == 19:
            b = self._context.pop()
            a = self._context.pop()
            self._context.push(a ** b)
        
        elif opcode == 20:
            b = self._context.pop()
            a = self._context.pop()
            self._context.push(a * b)
        
        elif opcode == 22:
            b = self._context.pop()
            a = self._context.pop()
            self._context.push(a % b)
        
        elif opcode == 23:
            b = self._context.pop()
            a = self._context.pop()
            self._context.push(a + b)
        
        elif opcode == 24:
            b = self._context.pop()
            a = self._context.pop()
            self._context.push(a - b)
        
        elif opcode == 25:
            key = self._context.pop()
            obj = self._context.pop()
            self._context.push(obj[key])
        
        elif opcode == 26:
            b = self._context.pop()
            a = self._context.pop()
            self._context.push(a // b)
        
        elif opcode == 27:
            b = self._context.pop()
            a = self._context.pop()
            self._context.push(a / b)
        
        elif opcode == 83:
            self._context.set_return(self._context.pop())
            return "return"
        
        elif opcode == 100:
            self._context.push(self._code.co_consts[arg])
        
        elif opcode == 101:
            name = self._code.co_names[arg]
            if name in self._context.locals_dict:
                self._context.push(self._context.locals_dict[name])
            elif name in self._context.globals_dict:
                self._context.push(self._context.globals_dict[name])
            else:
                import builtins
                self._context.push(getattr(builtins, name))
        
        elif opcode == 90:
            name = self._code.co_names[arg]
            self._context.locals_dict[name] = self._context.pop()
        
        elif opcode == 107:
            b = self._context.pop()
            a = self._context.pop()
            ops = [
                lambda x, y: x < y,
                lambda x, y: x <= y,
                lambda x, y: x == y,
                lambda x, y: x != y,
                lambda x, y: x > y,
                lambda x, y: x >= y,
            ]
            self._context.push(ops[arg](a, b))
        
        elif opcode == 110:
            target = instr.offset + instr.size + arg
            return target
        
        elif opcode == 113:
            return arg
        
        elif opcode == 114:
            if not self._context.pop():
                return arg
        
        elif opcode == 115:
            if self._context.pop():
                return arg
        
        elif opcode == 116:
            name = self._code.co_names[arg]
            if name in self._context.globals_dict:
                self._context.push(self._context.globals_dict[name])
            else:
                import builtins
                self._context.push(getattr(builtins, name))
        
        elif opcode == 124:
            name = self._code.co_varnames[arg]
            self._context.push(self._context.locals_dict[name])
        
        elif opcode == 125:
            name = self._code.co_varnames[arg]
            self._context.locals_dict[name] = self._context.pop()
        
        elif opcode == 131:
            args = [self._context.pop() for _ in range(arg)]
            args.reverse()
            func = self._context.pop()
            result = func(*args)
            self._context.push(result)
        
        return None
    
    def pause(self):
        with self._lock:
            if self._running:
                self._context.state = ExecutionState.PAUSED
    
    def resume(self):
        with self._lock:
            if self._context.state == ExecutionState.PAUSED:
                self._context.state = ExecutionState.RUNNING
    
    def cancel(self):
        with self._lock:
            self._running = False
            if self._context:
                self._context.state = ExecutionState.CANCELLED

class FunctionExecutor:
    
    def __init__(self, func):
        if not callable(func):
            raise TypeError("Expected callable")
        self._func = func
        self._executor = BytecodeExecutor(func.__code__)
    
    def execute(self, *args, **kwargs):
        context = ExecutionContext(self._func.__globals__)
        
        varnames = self._func.__code__.co_varnames
        for i, arg in enumerate(args):
            if i < len(varnames):
                context.locals_dict[varnames[i]] = arg
        
        for key, value in kwargs.items():
            context.locals_dict[key] = value
        
        self._executor.set_context(context)
        return self._executor.execute()

def execute(code, globals_dict=None, locals_dict=None):
    executor = BytecodeExecutor(code)
    return executor.execute(globals_dict=globals_dict, locals_dict=locals_dict)

def execute_function(func, *args, **kwargs):
    executor = FunctionExecutor(func)
    return executor.execute(*args, **kwargs)

def create_executor(code=None):
    return BytecodeExecutor(code)

def create_context(globals_dict=None, locals_dict=None):
    return ExecutionContext(globals_dict, locals_dict)

def create_config():
    return ExecutionConfig()
