import sys
import types
import struct
from typing import Dict, List, Optional, Tuple, Any, Union

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class AssemblerError(Exception):
    pass

class AssemblerToken:
    
    OPCODE = "OPCODE"
    LABEL = "LABEL"
    LABEL_REF = "LABEL_REF"
    NUMBER = "NUMBER"
    STRING = "STRING"
    NEWLINE = "NEWLINE"
    DIRECTIVE = "DIRECTIVE"
    COMMENT = "COMMENT"
    
    def __init__(self, token_type, value, line=0, column=0):
        self.type = token_type
        self.value = value
        self.line = line
        self.column = column
    
    def __repr__(self):
        return "Token({}, {!r})".format(self.type, self.value)

class AssemblerLexer:
    
    def __init__(self, source):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens = []
    
    def peek(self, offset=0):
        pos = self.pos + offset
        if pos < len(self.source):
            return self.source[pos]
        return None
    
    def advance(self):
        char = self.peek()
        self.pos += 1
        if char == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char
    
    def skip_whitespace(self):
        while self.peek() in (" ", "\t"):
            self.advance()
    
    def read_identifier(self):
        start = self.pos
        while self.peek() and (self.peek().isalnum() or self.peek() == "_"):
            self.advance()
        return self.source[start:self.pos]
    
    def read_number(self):
        start = self.pos
        if self.peek() == "-":
            self.advance()
        if self.peek() == "0" and self.peek(1) in ("x", "X"):
            self.advance()
            self.advance()
            while self.peek() and self.peek() in "0123456789abcdefABCDEF":
                self.advance()
        else:
            while self.peek() and self.peek().isdigit():
                self.advance()
        return self.source[start:self.pos]
    
    def read_string(self):
        quote = self.advance()
        start = self.pos
        while self.peek() and self.peek() != quote:
            if self.peek() == "\\":
                self.advance()
            self.advance()
        result = self.source[start:self.pos]
        self.advance()
        return result
    
    def tokenize(self):
        while self.pos < len(self.source):
            self.skip_whitespace()
            char = self.peek()
            
            if char is None:
                break
            
            if char == "\n":
                self.tokens.append(AssemblerToken(AssemblerToken.NEWLINE, "\n", self.line, self.column))
                self.advance()
                
            elif char == ";":
                while self.peek() and self.peek() != "\n":
                    self.advance()
                    
            elif char == ".":
                self.advance()
                name = self.read_identifier()
                self.tokens.append(AssemblerToken(AssemblerToken.DIRECTIVE, name, self.line, self.column))
                
            elif char == "@":
                self.advance()
                name = self.read_identifier()
                self.tokens.append(AssemblerToken(AssemblerToken.LABEL_REF, name, self.line, self.column))
                
            elif char in "\"'":
                line, col = self.line, self.column
                string = self.read_string()
                self.tokens.append(AssemblerToken(AssemblerToken.STRING, string, line, col))
                
            elif char.isdigit() or (char == "-" and self.peek(1) and self.peek(1).isdigit()):
                line, col = self.line, self.column
                number = self.read_number()
                self.tokens.append(AssemblerToken(AssemblerToken.NUMBER, number, line, col))
                
            elif char.isalpha() or char == "_":
                line, col = self.line, self.column
                name = self.read_identifier()
                if self.peek() == ":":
                    self.advance()
                    self.tokens.append(AssemblerToken(AssemblerToken.LABEL, name, line, col))
                else:
                    self.tokens.append(AssemblerToken(AssemblerToken.OPCODE, name, line, col))
            else:
                self.advance()
        
        return self.tokens

class AssemblerParser:
    
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.instructions = []
        self.labels = {}
        self.directives = {}
    
    def peek(self, offset=0):
        pos = self.pos + offset
        if pos < len(self.tokens):
            return self.tokens[pos]
        return None
    
    def advance(self):
        token = self.peek()
        self.pos += 1
        return token
    
    def expect(self, token_type):
        token = self.peek()
        if token is None or token.type != token_type:
            raise AssemblerError("Expected {}, got {}".format(token_type, token))
        return self.advance()
    
    def skip_newlines(self):
        while self.peek() and self.peek().type == AssemblerToken.NEWLINE:
            self.advance()
    
    def parse(self):
        offset = 0
        while self.pos < len(self.tokens):
            self.skip_newlines()
            token = self.peek()
            
            if token is None:
                break
            
            if token.type == AssemblerToken.LABEL:
                self.labels[token.value] = offset
                self.advance()
                
            elif token.type == AssemblerToken.DIRECTIVE:
                self.advance()
                name = token.value
                args = []
                while self.peek() and self.peek().type not in (AssemblerToken.NEWLINE, None):
                    arg_token = self.advance()
                    args.append(arg_token)
                self.directives[name] = args
                
            elif token.type == AssemblerToken.OPCODE:
                opname = token.value.upper()
                self.advance()
                arg = None
                label_ref = None
                if self.peek() and self.peek().type == AssemblerToken.NUMBER:
                    arg = int(self.advance().value, 0)
                elif self.peek() and self.peek().type == AssemblerToken.LABEL_REF:
                    label_ref = self.advance().value
                self.instructions.append({
                    "opname": opname,
                    "arg": arg,
                    "label_ref": label_ref,
                    "offset": offset
                })
                if PYTHON_VERSION >= (3, 6):
                    offset += 2
                else:
                    offset += 3 if self._has_arg(opname) else 1
            else:
                self.advance()
        
        return {
            "instructions": self.instructions,
            "labels": self.labels,
            "directives": self.directives
        }
    
    def _has_arg(self, opname):
        import dis
        opcode = dis.opmap.get(opname, 0)
        return opcode >= 90

class BytecodeAssembler:
    
    def __init__(self):
        self._opmap = None
        self._init_opmap()
        self._consts = [None]
        self._names = []
        self._varnames = []
        self._freevars = []
        self._cellvars = []
        self._filename = "<assembled>"
        self._name = "<module>"
        self._firstlineno = 1
        self._flags = 0
        self._argcount = 0
        self._kwonlyargcount = 0
        self._posonlyargcount = 0
    
    def _init_opmap(self):
        import dis
        self._opmap = dict(dis.opmap)
    
    def set_filename(self, filename):
        self._filename = filename
    
    def set_name(self, name):
        self._name = name
    
    def set_flags(self, flags):
        self._flags = flags
    
    def set_argcount(self, count):
        self._argcount = count
    
    def add_const(self, value):
        for i, c in enumerate(self._consts):
            if c == value and type(c) is type(value):
                return i
        index = len(self._consts)
        self._consts.append(value)
        return index
    
    def add_name(self, name):
        if name not in self._names:
            self._names.append(name)
        return self._names.index(name)
    
    def add_varname(self, name):
        if name not in self._varnames:
            self._varnames.append(name)
        return self._varnames.index(name)
    
    def assemble_source(self, source):
        lexer = AssemblerLexer(source)
        tokens = lexer.tokenize()
        parser = AssemblerParser(tokens)
        parsed = parser.parse()
        return self.assemble_parsed(parsed)
    
    def assemble_parsed(self, parsed):
        instructions = parsed["instructions"]
        labels = parsed["labels"]
        directives = parsed["directives"]
        
        self._process_directives(directives)
        
        bytecode = bytearray()
        pending_labels = []
        
        for instr in instructions:
            opname = instr["opname"]
            arg = instr["arg"]
            label_ref = instr["label_ref"]
            
            opcode = self._opmap.get(opname)
            if opcode is None:
                raise AssemblerError("Unknown opcode: {}".format(opname))
            
            if label_ref is not None:
                pending_labels.append((len(bytecode), opcode, label_ref))
                if PYTHON_VERSION >= (3, 6):
                    bytecode.extend([opcode, 0])
                else:
                    bytecode.extend([opcode, 0, 0])
            elif arg is not None:
                self._emit_instruction(bytecode, opcode, arg)
            else:
                self._emit_instruction(bytecode, opcode, 0)
        
        for offset, opcode, label_name in pending_labels:
            target = labels.get(label_name)
            if target is None:
                raise AssemblerError("Undefined label: {}".format(label_name))
            
            if self._is_relative_jump(opcode):
                target = target - offset - 2
            
            if PYTHON_VERSION >= (3, 6):
                bytecode[offset + 1] = target & 0xFF
            else:
                bytecode[offset + 1] = target & 0xFF
                bytecode[offset + 2] = (target >> 8) & 0xFF
        
        return self._create_code(bytes(bytecode))
    
    def _emit_instruction(self, bytecode, opcode, arg):
        if PYTHON_VERSION >= (3, 6):
            if arg > 0xFF:
                extended = arg >> 8
                if extended > 0xFF:
                    ext2 = extended >> 8
                    bytecode.extend([144, ext2 & 0xFF])
                    extended &= 0xFF
                bytecode.extend([144, extended & 0xFF])
            bytecode.extend([opcode, arg & 0xFF])
        else:
            if opcode >= 90:
                bytecode.extend([opcode, arg & 0xFF, (arg >> 8) & 0xFF])
            else:
                bytecode.append(opcode)
    
    def _is_relative_jump(self, opcode):
        return opcode in (93, 110, 122, 143, 154)
    
    def _process_directives(self, directives):
        if "filename" in directives:
            self._filename = directives["filename"][0].value
        if "name" in directives:
            self._name = directives["name"][0].value
        if "flags" in directives:
            self._flags = int(directives["flags"][0].value, 0)
        if "argcount" in directives:
            self._argcount = int(directives["argcount"][0].value, 0)
    
    def _create_code(self, bytecode):
        stacksize = self._calculate_stacksize(bytecode)
        nlocals = len(self._varnames)
        
        if PYTHON_VERSION >= (3, 11):
            return types.CodeType(
                self._argcount,
                self._posonlyargcount,
                self._kwonlyargcount,
                nlocals,
                stacksize,
                self._flags,
                bytecode,
                tuple(self._consts),
                tuple(self._names),
                tuple(self._varnames),
                self._filename,
                self._name,
                self._name,
                self._firstlineno,
                b"",
                b"",
                tuple(self._freevars),
                tuple(self._cellvars)
            )
        elif PYTHON_VERSION >= (3, 8):
            return types.CodeType(
                self._argcount,
                self._posonlyargcount,
                self._kwonlyargcount,
                nlocals,
                stacksize,
                self._flags,
                bytecode,
                tuple(self._consts),
                tuple(self._names),
                tuple(self._varnames),
                self._filename,
                self._name,
                self._firstlineno,
                b"",
                tuple(self._freevars),
                tuple(self._cellvars)
            )
        else:
            return types.CodeType(
                self._argcount,
                self._kwonlyargcount,
                nlocals,
                stacksize,
                self._flags,
                bytecode,
                tuple(self._consts),
                tuple(self._names),
                tuple(self._varnames),
                self._filename,
                self._name,
                self._firstlineno,
                b"",
                tuple(self._freevars),
                tuple(self._cellvars)
            )
    
    def _calculate_stacksize(self, bytecode):
        return max(16, len(bytecode) // 4)
    
    def assemble_instructions(self, instructions):
        bytecode = bytearray()
        for instr in instructions:
            opcode = instr.opcode
            arg = instr.arg if instr.arg is not None else 0
            self._emit_instruction(bytecode, opcode, arg)
        return bytes(bytecode)

class InstructionAssembler:
    
    def __init__(self):
        import dis
        self._opmap = dict(dis.opmap)
    
    def assemble(self, instructions):
        bytecode = bytearray()
        for instr in instructions:
            if hasattr(instr, "opcode"):
                opcode = instr.opcode
                arg = instr.arg if hasattr(instr, "arg") and instr.arg is not None else 0
            else:
                opcode = instr[0]
                arg = instr[1] if len(instr) > 1 else 0
            
            self._emit(bytecode, opcode, arg)
        
        return bytes(bytecode)
    
    def _emit(self, bytecode, opcode, arg):
        if PYTHON_VERSION >= (3, 6):
            while arg > 0xFF:
                bytecode.extend([144, (arg >> 8) & 0xFF])
                arg = arg & 0xFF
            bytecode.extend([opcode, arg])
        else:
            if opcode >= 90:
                bytecode.extend([opcode, arg & 0xFF, (arg >> 8) & 0xFF])
            else:
                bytecode.append(opcode)
    
    def assemble_single(self, opcode, arg=0):
        bytecode = bytearray()
        self._emit(bytecode, opcode, arg)
        return bytes(bytecode)

def assemble(source):
    assembler = BytecodeAssembler()
    return assembler.assemble_source(source)

def assemble_instructions(instructions):
    assembler = InstructionAssembler()
    return assembler.assemble(instructions)

def quick_assemble(opcode, arg=0):
    assembler = InstructionAssembler()
    return assembler.assemble_single(opcode, arg)
