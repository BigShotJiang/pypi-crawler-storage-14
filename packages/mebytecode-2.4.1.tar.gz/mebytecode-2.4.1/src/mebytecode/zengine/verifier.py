import sys
import types
from typing import Dict, List, Optional, Tuple, Any, Set, Union

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class VerificationError(Exception):
    
    def __init__(self, message, offset=None, opcode=None):
        super().__init__(message)
        self.offset = offset
        self.opcode = opcode

class VerificationWarning:
    
    def __init__(self, message, offset=None, opcode=None, severity="warning"):
        self.message = message
        self.offset = offset
        self.opcode = opcode
        self.severity = severity
    
    def __repr__(self):
        return "VerificationWarning({!r}, offset={})".format(self.message, self.offset)

class VerificationResult:
    
    def __init__(self):
        self.is_valid = True
        self.errors = []
        self.warnings = []
        self.info = {}
    
    def add_error(self, message, offset=None, opcode=None):
        self.errors.append(VerificationError(message, offset, opcode))
        self.is_valid = False
    
    def add_warning(self, message, offset=None, opcode=None):
        self.warnings.append(VerificationWarning(message, offset, opcode))
    
    def set_info(self, key, value):
        self.info[key] = value
    
    def __bool__(self):
        return self.is_valid
    
    def __repr__(self):
        return "VerificationResult(valid={}, errors={}, warnings={})".format(
            self.is_valid, len(self.errors), len(self.warnings))

class VerificationRule:
    
    name = "base_rule"
    
    def __init__(self, enabled=True):
        self.enabled = enabled
    
    def verify(self, instructions, context, result):
        raise NotImplementedError

class OpcodeValidityRule(VerificationRule):
    
    name = "opcode_validity"
    
    VALID_OPCODES = set(range(256))
    
    def __init__(self, enabled=True):
        super().__init__(enabled)
        import dis
        self._valid_opcodes = set(dis.opmap.values())
    
    def verify(self, instructions, context, result):
        for instr in instructions:
            if instr.opcode not in self._valid_opcodes:
                result.add_error(
                    "Invalid opcode: {}".format(instr.opcode),
                    offset=instr.offset,
                    opcode=instr.opcode
                )

class ArgumentValidityRule(VerificationRule):
    
    name = "argument_validity"
    
    def verify(self, instructions, context, result):
        for instr in instructions:
            if instr.opcode >= 90 and instr.arg is None:
                result.add_error(
                    "Opcode {} requires argument".format(instr.opname),
                    offset=instr.offset,
                    opcode=instr.opcode
                )
            
            if instr.opcode < 90 and instr.arg is not None and instr.arg != 0:
                result.add_warning(
                    "Opcode {} should not have non-zero argument".format(instr.opname),
                    offset=instr.offset,
                    opcode=instr.opcode
                )

class StackBalanceRule(VerificationRule):
    
    name = "stack_balance"
    
    STACK_EFFECTS = {
        1: -1, 2: 0, 3: 0, 4: 1, 5: 2, 9: 0,
        10: 0, 11: 0, 12: 0, 15: 0,
        19: -1, 20: -1, 22: -1, 23: -1, 24: -1, 25: -1,
        26: -1, 27: -1, 55: -1, 56: -1, 57: -1, 59: -1,
        60: -3, 61: -2, 62: -1, 63: -1, 64: -1, 65: -1, 66: -1,
        67: -1, 68: 0, 70: -1, 71: 1, 75: -1, 76: -1, 77: -1,
        78: -1, 79: -1, 83: -1, 84: -1, 86: 0, 87: 0, 89: -3,
    }
    
    def verify(self, instructions, context, result):
        stack_depth = 0
        min_depth = 0
        
        for instr in instructions:
            effect = self._get_stack_effect(instr)
            stack_depth += effect
            
            if stack_depth < 0:
                result.add_warning(
                    "Stack underflow at offset {}".format(instr.offset),
                    offset=instr.offset,
                    opcode=instr.opcode
                )
                min_depth = min(min_depth, stack_depth)
        
        result.set_info("final_stack_depth", stack_depth)
        result.set_info("min_stack_depth", min_depth)
    
    def _get_stack_effect(self, instr):
        opcode = instr.opcode
        arg = instr.arg if instr.arg else 0
        
        if opcode in self.STACK_EFFECTS:
            return self.STACK_EFFECTS[opcode]
        
        if opcode == 90:
            return -1
        if opcode == 100:
            return 1
        if opcode == 101:
            return 1
        if opcode == 102:
            return 1 - arg
        if opcode == 103:
            return 1 - arg
        if opcode == 104:
            return 1 - arg
        if opcode == 105:
            return 1 - 2 * arg
        if opcode == 106:
            return 0
        if opcode == 107:
            return -1
        if opcode in (110, 113):
            return 0
        if opcode in (111, 112, 114, 115):
            return -1
        if opcode == 116:
            return 1
        if opcode == 124:
            return 1
        if opcode == 125:
            return -1
        if opcode == 131:
            return -arg
        if opcode == 136:
            return 1
        if opcode == 137:
            return -1
        
        return 0

class JumpTargetRule(VerificationRule):
    
    name = "jump_targets"
    
    JUMP_OPCODES = {93, 110, 111, 112, 113, 114, 115, 121, 122, 143, 154}
    RELATIVE_JUMPS = {93, 110, 122, 143, 154}
    
    def verify(self, instructions, context, result):
        valid_offsets = {instr.offset for instr in instructions}
        
        for instr in instructions:
            if instr.opcode in self.JUMP_OPCODES:
                target = instr.arg if instr.arg else 0
                
                if instr.opcode in self.RELATIVE_JUMPS:
                    target = instr.offset + instr.size + target
                
                if target not in valid_offsets and target > max(valid_offsets):
                    pass
                elif target not in valid_offsets:
                    result.add_warning(
                        "Jump target {} not at instruction boundary".format(target),
                        offset=instr.offset,
                        opcode=instr.opcode
                    )

class ConstIndexRule(VerificationRule):
    
    name = "const_index"
    
    def verify(self, instructions, context, result):
        const_count = len(context.consts) if context.consts else 0
        
        for instr in instructions:
            if instr.opcode == 100:
                if instr.arg is not None and instr.arg >= const_count:
                    result.add_error(
                        "Const index {} out of range (max: {})".format(
                            instr.arg, const_count - 1),
                        offset=instr.offset,
                        opcode=instr.opcode
                    )

class NameIndexRule(VerificationRule):
    
    name = "name_index"
    
    NAME_OPCODES = {90, 91, 95, 96, 97, 98, 101, 106, 108, 109, 116, 160}
    
    def verify(self, instructions, context, result):
        name_count = len(context.names) if context.names else 0
        
        for instr in instructions:
            if instr.opcode in self.NAME_OPCODES:
                if instr.arg is not None and instr.arg >= name_count:
                    result.add_error(
                        "Name index {} out of range (max: {})".format(
                            instr.arg, name_count - 1),
                        offset=instr.offset,
                        opcode=instr.opcode
                    )

class LocalIndexRule(VerificationRule):
    
    name = "local_index"
    
    LOCAL_OPCODES = {124, 125, 126}
    
    def verify(self, instructions, context, result):
        local_count = len(context.varnames) if context.varnames else 0
        
        for instr in instructions:
            if instr.opcode in self.LOCAL_OPCODES:
                if instr.arg is not None and instr.arg >= local_count:
                    result.add_error(
                        "Local index {} out of range (max: {})".format(
                            instr.arg, local_count - 1),
                        offset=instr.offset,
                        opcode=instr.opcode
                    )

class ReturnPathRule(VerificationRule):
    
    name = "return_path"
    
    def verify(self, instructions, context, result):
        if not instructions:
            result.add_warning("Empty bytecode")
            return
        
        has_return = any(instr.opcode == 83 for instr in instructions)
        if not has_return:
            result.add_warning("No RETURN_VALUE instruction found")
        
        last_instr = instructions[-1]
        if last_instr.opcode not in (83, 110, 113, 130):
            result.add_warning(
                "Code does not end with RETURN_VALUE or unconditional jump",
                offset=last_instr.offset
            )

class VerificationContext:
    
    def __init__(self, code=None):
        self._code = code
        self.consts = code.co_consts if code else ()
        self.names = code.co_names if code else ()
        self.varnames = code.co_varnames if code else ()
        self.freevars = code.co_freevars if code else ()
        self.cellvars = code.co_cellvars if code else ()
        self.argcount = code.co_argcount if code else 0
        self.flags = code.co_flags if code else 0

class BytecodeVerifier:
    
    def __init__(self, code=None):
        self._code = code
        self._rules = [
            OpcodeValidityRule(),
            ArgumentValidityRule(),
            StackBalanceRule(),
            JumpTargetRule(),
            ConstIndexRule(),
            NameIndexRule(),
            LocalIndexRule(),
            ReturnPathRule(),
        ]
    
    def add_rule(self, rule):
        self._rules.append(rule)
        return self
    
    def remove_rule(self, name):
        self._rules = [r for r in self._rules if r.name != name]
        return self
    
    def enable_rule(self, name):
        for r in self._rules:
            if r.name == name:
                r.enabled = True
        return self
    
    def disable_rule(self, name):
        for r in self._rules:
            if r.name == name:
                r.enabled = False
        return self
    
    def verify(self, code=None):
        if code is not None:
            self._code = code
        
        if self._code is None:
            raise ValueError("No code object provided")
        
        from .disassembler import BytecodeDisassembler
        
        disasm = BytecodeDisassembler(self._code)
        instructions = disasm.disassemble()
        
        context = VerificationContext(self._code)
        result = VerificationResult()
        
        for rule in self._rules:
            if rule.enabled:
                rule.verify(instructions, context, result)
        
        return result
    
    def verify_bytecode(self, bytecode, consts=None, names=None, varnames=None):
        from .disassembler import BytecodeReader
        
        reader = BytecodeReader(bytecode)
        raw_instructions = list(reader)
        
        result = VerificationResult()
        
        import dis
        valid_opcodes = set(dis.opmap.values())
        
        for offset, opcode, arg, size in raw_instructions:
            if opcode not in valid_opcodes:
                result.add_error(
                    "Invalid opcode: {}".format(opcode),
                    offset=offset,
                    opcode=opcode
                )
        
        return result

class FunctionVerifier:
    
    def __init__(self, func):
        if not callable(func):
            raise TypeError("Expected callable")
        self._func = func
        self._verifier = BytecodeVerifier(func.__code__)
    
    def verify(self):
        return self._verifier.verify()

def verify(code):
    verifier = BytecodeVerifier(code)
    return verifier.verify()

def verify_function(func):
    verifier = FunctionVerifier(func)
    return verifier.verify()

def is_valid(code):
    result = verify(code)
    return result.is_valid

def get_errors(code):
    result = verify(code)
    return result.errors

def get_warnings(code):
    result = verify(code)
    return result.warnings

def quick_verify(bytecode):
    import dis
    valid_opcodes = set(dis.opmap.values())
    
    offset = 0
    while offset < len(bytecode):
        op = bytecode[offset]
        
        if op not in valid_opcodes and op != 0:
            return False
        
        if PYTHON_VERSION >= (3, 6):
            offset += 2
        else:
            offset += 3 if op >= 90 else 1
    
    return True
