import sys
import types
from typing import Dict, List, Optional, Tuple, Any, Set, Union

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class OptimizationError(Exception):
    pass

class OptimizationPass:
    
    name = "base"
    
    def __init__(self, enabled=True):
        self.enabled = enabled
        self.stats = {"applied": 0}
    
    def optimize(self, instructions, context):
        raise NotImplementedError
    
    def reset_stats(self):
        self.stats = {"applied": 0}

class ConstantFolding(OptimizationPass):
    
    name = "constant_folding"
    
    BINARY_OPS = {
        23: lambda a, b: a + b,
        24: lambda a, b: a - b,
        20: lambda a, b: a * b,
        27: lambda a, b: a / b,
        26: lambda a, b: a // b,
        22: lambda a, b: a % b,
        19: lambda a, b: a ** b,
        62: lambda a, b: a << b,
        63: lambda a, b: a >> b,
        64: lambda a, b: a & b,
        65: lambda a, b: a ^ b,
        66: lambda a, b: a | b,
    }
    
    UNARY_OPS = {
        10: lambda a: +a,
        11: lambda a: -a,
        12: lambda a: not a,
        15: lambda a: ~a,
    }
    
    def optimize(self, instructions, context):
        result = []
        i = 0
        
        while i < len(instructions):
            if i + 2 < len(instructions):
                folded = self._try_fold_binary(instructions[i:i+3], context)
                if folded:
                    result.append(folded)
                    self.stats["applied"] += 1
                    i += 3
                    continue
            
            if i + 1 < len(instructions):
                folded = self._try_fold_unary(instructions[i:i+2], context)
                if folded:
                    result.append(folded)
                    self.stats["applied"] += 1
                    i += 2
                    continue
            
            result.append(instructions[i])
            i += 1
        
        return result
    
    def _try_fold_binary(self, instrs, context):
        if len(instrs) < 3:
            return None
        
        i1, i2, i3 = instrs
        
        if i1.opcode != 100 or i2.opcode != 100:
            return None
        
        if i3.opcode not in self.BINARY_OPS:
            return None
        
        try:
            val1 = context.get_const(i1.arg)
            val2 = context.get_const(i2.arg)
            
            if not isinstance(val1, (int, float)) or not isinstance(val2, (int, float)):
                return None
            
            result = self.BINARY_OPS[i3.opcode](val1, val2)
            const_idx = context.add_const(result)
            
            from .instructions import InstructionFactory
            return InstructionFactory.load_const(const_idx, result, i1.offset)
        except Exception:
            return None
    
    def _try_fold_unary(self, instrs, context):
        if len(instrs) < 2:
            return None
        
        i1, i2 = instrs
        
        if i1.opcode != 100:
            return None
        
        if i2.opcode not in self.UNARY_OPS:
            return None
        
        try:
            val = context.get_const(i1.arg)
            
            if not isinstance(val, (int, float, bool)):
                return None
            
            result = self.UNARY_OPS[i2.opcode](val)
            const_idx = context.add_const(result)
            
            from .instructions import InstructionFactory
            return InstructionFactory.load_const(const_idx, result, i1.offset)
        except Exception:
            return None

class DeadCodeElimination(OptimizationPass):
    
    name = "dead_code_elimination"
    
    def optimize(self, instructions, context):
        if not instructions:
            return instructions
        
        reachable = self._find_reachable(instructions)
        result = []
        
        for i, instr in enumerate(instructions):
            if i in reachable:
                result.append(instr)
            else:
                self.stats["applied"] += 1
        
        return result
    
    def _find_reachable(self, instructions):
        reachable = set()
        worklist = [0]
        offset_to_idx = {instr.offset: i for i, instr in enumerate(instructions)}
        
        while worklist:
            idx = worklist.pop()
            if idx in reachable or idx >= len(instructions):
                continue
            
            reachable.add(idx)
            instr = instructions[idx]
            
            if self._is_unconditional_jump(instr.opcode):
                target = instr.arg if instr.arg else 0
                if self._is_relative_jump(instr.opcode):
                    target = instr.offset + instr.size + target
                target_idx = offset_to_idx.get(target, -1)
                if target_idx >= 0:
                    worklist.append(target_idx)
            elif self._is_conditional_jump(instr.opcode):
                target = instr.arg if instr.arg else 0
                if self._is_relative_jump(instr.opcode):
                    target = instr.offset + instr.size + target
                target_idx = offset_to_idx.get(target, -1)
                if target_idx >= 0:
                    worklist.append(target_idx)
                worklist.append(idx + 1)
            elif instr.opcode != 83:
                worklist.append(idx + 1)
        
        return reachable
    
    def _is_unconditional_jump(self, opcode):
        return opcode in (110, 113)
    
    def _is_conditional_jump(self, opcode):
        return opcode in (93, 111, 112, 114, 115, 121)
    
    def _is_relative_jump(self, opcode):
        return opcode in (93, 110, 122, 143)

class PeepholeOptimizer(OptimizationPass):
    
    name = "peephole"
    
    def optimize(self, instructions, context):
        result = list(instructions)
        changed = True
        
        while changed:
            changed = False
            new_result = []
            i = 0
            
            while i < len(result):
                pattern_applied = False
                
                if i + 1 < len(result):
                    if self._is_pop_dup_pattern(result[i], result[i + 1]):
                        self.stats["applied"] += 1
                        i += 2
                        pattern_applied = True
                        changed = True
                    
                    elif self._is_nop_pattern(result[i]):
                        self.stats["applied"] += 1
                        i += 1
                        pattern_applied = True
                        changed = True
                    
                    elif self._is_jump_to_next(result[i], result[i + 1]):
                        self.stats["applied"] += 1
                        i += 1
                        pattern_applied = True
                        changed = True
                
                if not pattern_applied:
                    new_result.append(result[i])
                    i += 1
            
            result = new_result
        
        return result
    
    def _is_pop_dup_pattern(self, i1, i2):
        return i1.opcode == 4 and i2.opcode == 1
    
    def _is_nop_pattern(self, instr):
        return instr.opcode == 9
    
    def _is_jump_to_next(self, i1, i2):
        if i1.opcode == 110:
            target = i1.offset + i1.size + (i1.arg or 0)
            return target == i2.offset
        if i1.opcode == 113:
            return i1.arg == i2.offset
        return False

class JumpOptimizer(OptimizationPass):
    
    name = "jump_optimization"
    
    def optimize(self, instructions, context):
        result = []
        jump_targets = {}
        
        for instr in instructions:
            if self._is_unconditional_jump(instr.opcode):
                target = instr.arg if instr.arg else 0
                if self._is_relative_jump(instr.opcode):
                    target = instr.offset + instr.size + target
                jump_targets[instr.offset] = target
        
        for instr in instructions:
            if self._is_jump(instr.opcode):
                target = instr.arg if instr.arg else 0
                if self._is_relative_jump(instr.opcode):
                    target = instr.offset + instr.size + target
                
                if target in jump_targets:
                    final_target = self._follow_chain(target, jump_targets)
                    if final_target != target:
                        new_instr = instr.with_arg(final_target)
                        result.append(new_instr)
                        self.stats["applied"] += 1
                        continue
            
            result.append(instr)
        
        return result
    
    def _follow_chain(self, target, jump_targets, visited=None):
        if visited is None:
            visited = set()
        
        if target in visited:
            return target
        
        visited.add(target)
        
        if target in jump_targets:
            return self._follow_chain(jump_targets[target], jump_targets, visited)
        
        return target
    
    def _is_jump(self, opcode):
        return opcode in (93, 110, 111, 112, 113, 114, 115, 121)
    
    def _is_unconditional_jump(self, opcode):
        return opcode in (110, 113)
    
    def _is_relative_jump(self, opcode):
        return opcode in (93, 110, 122, 143)

class OptimizationContext:
    
    def __init__(self, code):
        self._code = code
        self._consts = list(code.co_consts) if code else []
        self._names = list(code.co_names) if code else []
        self._varnames = list(code.co_varnames) if code else []
    
    def get_const(self, index):
        if 0 <= index < len(self._consts):
            return self._consts[index]
        return None
    
    def add_const(self, value):
        for i, c in enumerate(self._consts):
            if c == value and type(c) is type(value):
                return i
        index = len(self._consts)
        self._consts.append(value)
        return index
    
    def get_name(self, index):
        if 0 <= index < len(self._names):
            return self._names[index]
        return None
    
    def get_varname(self, index):
        if 0 <= index < len(self._varnames):
            return self._varnames[index]
        return None
    
    @property
    def consts(self):
        return tuple(self._consts)

class BytecodeOptimizer:
    
    def __init__(self, code=None):
        self._code = code
        self._passes = [
            ConstantFolding(),
            DeadCodeElimination(),
            PeepholeOptimizer(),
            JumpOptimizer(),
        ]
    
    def add_pass(self, optimization_pass):
        self._passes.append(optimization_pass)
    
    def remove_pass(self, name):
        self._passes = [p for p in self._passes if p.name != name]
    
    def enable_pass(self, name):
        for p in self._passes:
            if p.name == name:
                p.enabled = True
    
    def disable_pass(self, name):
        for p in self._passes:
            if p.name == name:
                p.enabled = False
    
    def optimize(self, code=None):
        if code is not None:
            self._code = code
        
        if self._code is None:
            raise OptimizationError("No code object provided")
        
        from .disassembler import BytecodeDisassembler
        from .assembler import BytecodeAssembler
        
        disasm = BytecodeDisassembler(self._code)
        instructions = disasm.disassemble()
        
        context = OptimizationContext(self._code)
        
        for opt_pass in self._passes:
            if opt_pass.enabled:
                instructions = opt_pass.optimize(instructions, context)
        
        self._recalculate_offsets(instructions)
        
        assembler = BytecodeAssembler()
        assembler._consts = list(context.consts)
        assembler._names = list(self._code.co_names)
        assembler._varnames = list(self._code.co_varnames)
        assembler._filename = self._code.co_filename
        assembler._name = self._code.co_name
        assembler._flags = self._code.co_flags
        assembler._argcount = self._code.co_argcount
        
        bytecode = assembler.assemble_instructions(instructions)
        return self._create_code(bytecode, context.consts)
    
    def _recalculate_offsets(self, instructions):
        offset = 0
        for instr in instructions:
            instr.offset = offset
            offset += instr.size
    
    def _create_code(self, bytecode, consts):
        if PYTHON_VERSION >= (3, 11):
            return types.CodeType(
                self._code.co_argcount,
                getattr(self._code, "co_posonlyargcount", 0),
                self._code.co_kwonlyargcount,
                self._code.co_nlocals,
                self._code.co_stacksize,
                self._code.co_flags,
                bytecode,
                consts,
                self._code.co_names,
                self._code.co_varnames,
                self._code.co_filename,
                self._code.co_name,
                getattr(self._code, "co_qualname", self._code.co_name),
                self._code.co_firstlineno,
                getattr(self._code, "co_linetable", self._code.co_lnotab),
                getattr(self._code, "co_exceptiontable", b""),
                self._code.co_freevars,
                self._code.co_cellvars
            )
        elif PYTHON_VERSION >= (3, 8):
            return types.CodeType(
                self._code.co_argcount,
                getattr(self._code, "co_posonlyargcount", 0),
                self._code.co_kwonlyargcount,
                self._code.co_nlocals,
                self._code.co_stacksize,
                self._code.co_flags,
                bytecode,
                consts,
                self._code.co_names,
                self._code.co_varnames,
                self._code.co_filename,
                self._code.co_name,
                self._code.co_firstlineno,
                self._code.co_lnotab,
                self._code.co_freevars,
                self._code.co_cellvars
            )
        else:
            return types.CodeType(
                self._code.co_argcount,
                self._code.co_kwonlyargcount,
                self._code.co_nlocals,
                self._code.co_stacksize,
                self._code.co_flags,
                bytecode,
                consts,
                self._code.co_names,
                self._code.co_varnames,
                self._code.co_filename,
                self._code.co_name,
                self._code.co_firstlineno,
                self._code.co_lnotab,
                self._code.co_freevars,
                self._code.co_cellvars
            )
    
    def get_stats(self):
        return {p.name: p.stats for p in self._passes}

def optimize(code):
    optimizer = BytecodeOptimizer(code)
    return optimizer.optimize()

def create_optimizer():
    return BytecodeOptimizer()
