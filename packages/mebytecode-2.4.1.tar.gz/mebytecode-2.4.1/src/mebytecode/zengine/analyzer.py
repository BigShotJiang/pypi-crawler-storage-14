import sys
import types
from typing import Dict, List, Optional, Tuple, Any, Set, Union

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class AnalysisError(Exception):
    pass

class BasicBlock:
    
    def __init__(self, start_offset):
        self.start_offset = start_offset
        self.end_offset = start_offset
        self.instructions = []
        self.predecessors = set()
        self.successors = set()
        self.is_entry = False
        self.is_exit = False
        self.exception_handlers = []
    
    def add_instruction(self, instruction):
        self.instructions.append(instruction)
        self.end_offset = instruction.offset + instruction.size
    
    def add_predecessor(self, block):
        self.predecessors.add(block.start_offset)
    
    def add_successor(self, block):
        self.successors.add(block.start_offset)
    
    def __repr__(self):
        return "BasicBlock(start={}, end={}, succs={})".format(
            self.start_offset, self.end_offset, list(self.successors))

class ControlFlowGraph:
    
    def __init__(self):
        self.blocks = {}
        self.entry = None
        self.exits = []
        self._edges = []
    
    def add_block(self, block):
        self.blocks[block.start_offset] = block
        if block.is_entry:
            self.entry = block
        if block.is_exit:
            self.exits.append(block)
    
    def get_block(self, offset):
        return self.blocks.get(offset)
    
    def add_edge(self, from_offset, to_offset):
        if from_offset in self.blocks and to_offset in self.blocks:
            self.blocks[from_offset].add_successor(self.blocks[to_offset])
            self.blocks[to_offset].add_predecessor(self.blocks[from_offset])
            self._edges.append((from_offset, to_offset))
    
    def get_successors(self, offset):
        block = self.blocks.get(offset)
        if block:
            return [self.blocks[s] for s in block.successors if s in self.blocks]
        return []
    
    def get_predecessors(self, offset):
        block = self.blocks.get(offset)
        if block:
            return [self.blocks[p] for p in block.predecessors if p in self.blocks]
        return []
    
    def iter_blocks(self):
        return iter(sorted(self.blocks.values(), key=lambda b: b.start_offset))
    
    def dominators(self):
        dom = {}
        all_blocks = set(self.blocks.keys())
        
        if self.entry:
            dom[self.entry.start_offset] = {self.entry.start_offset}
        
        for offset in self.blocks:
            if offset != self.entry.start_offset:
                dom[offset] = all_blocks.copy()
        
        changed = True
        while changed:
            changed = False
            for offset, block in self.blocks.items():
                if offset == self.entry.start_offset:
                    continue
                
                pred_doms = [dom.get(p, all_blocks) for p in block.predecessors]
                if pred_doms:
                    new_dom = set.intersection(*pred_doms) | {offset}
                else:
                    new_dom = {offset}
                
                if new_dom != dom[offset]:
                    dom[offset] = new_dom
                    changed = True
        
        return dom

class StackAnalyzer:
    
    STACK_EFFECTS = {
        1: -1,
        2: 0,
        3: 0,
        4: 1,
        5: 2,
        9: 0,
        10: 0,
        11: 0,
        12: 0,
        15: 0,
        19: -1,
        20: -1,
        22: -1,
        23: -1,
        24: -1,
        25: -1,
        26: -1,
        27: -1,
        55: -1,
        56: -1,
        57: -1,
        59: -1,
        60: -3,
        61: -2,
        62: -1,
        63: -1,
        64: -1,
        65: -1,
        66: -1,
        67: -1,
        68: 0,
        70: -1,
        71: 1,
        72: -1,
        75: -1,
        76: -1,
        77: -1,
        78: -1,
        79: -1,
        83: -1,
        84: -1,
        86: 0,
        87: 0,
        89: -3,
    }
    
    def __init__(self, code):
        self._code = code
        self._stack_depths = {}
    
    def analyze(self):
        from .disassembler import BytecodeDisassembler
        
        disasm = BytecodeDisassembler(self._code)
        instructions = disasm.disassemble()
        
        self._stack_depths = {}
        self._analyze_block(instructions, 0, 0)
        
        return self._stack_depths
    
    def _analyze_block(self, instructions, start_idx, initial_depth):
        depth = initial_depth
        
        for i in range(start_idx, len(instructions)):
            instr = instructions[i]
            offset = instr.offset
            
            if offset in self._stack_depths:
                if self._stack_depths[offset] != depth:
                    pass
                return
            
            self._stack_depths[offset] = depth
            effect = self._get_stack_effect(instr)
            depth = max(0, depth + effect)
            
            if self._is_unconditional_jump(instr.opcode):
                target = instr.arg if instr.arg else 0
                target_idx = self._find_instruction_index(instructions, target)
                if target_idx >= 0:
                    self._analyze_block(instructions, target_idx, depth)
                return
            
            if self._is_conditional_jump(instr.opcode):
                target = instr.arg if instr.arg else 0
                target_idx = self._find_instruction_index(instructions, target)
                if target_idx >= 0:
                    self._analyze_block(instructions, target_idx, depth)
            
            if instr.opcode == 83:
                return
    
    def _find_instruction_index(self, instructions, offset):
        for i, instr in enumerate(instructions):
            if instr.offset == offset:
                return i
        return -1
    
    def _get_stack_effect(self, instr):
        opcode = instr.opcode
        arg = instr.arg if instr.arg else 0
        
        if opcode in self.STACK_EFFECTS:
            return self.STACK_EFFECTS[opcode]
        
        if opcode == 90:
            return -1
        if opcode == 100:
            return 1
        if opcode == 101:
            return 1
        if opcode == 102:
            return 1 - arg
        if opcode == 103:
            return 1 - arg
        if opcode == 104:
            return 1 - arg
        if opcode == 105:
            return 1 - 2 * arg
        if opcode == 106:
            return 0
        if opcode == 107:
            return -1
        if opcode == 110:
            return 0
        if opcode in (111, 112):
            return -1
        if opcode == 113:
            return 0
        if opcode in (114, 115):
            return -1
        if opcode == 116:
            return 1
        if opcode == 124:
            return 1
        if opcode == 125:
            return -1
        if opcode == 131:
            return -arg
        if opcode == 132:
            return -1 - bool(arg & 0x01) - bool(arg & 0x02) - bool(arg & 0x04) - bool(arg & 0x08)
        if opcode == 136:
            return 1
        if opcode == 137:
            return -1
        
        return 0
    
    def _is_unconditional_jump(self, opcode):
        return opcode in (110, 113)
    
    def _is_conditional_jump(self, opcode):
        return opcode in (93, 111, 112, 114, 115, 121)
    
    def get_max_stack(self):
        if not self._stack_depths:
            self.analyze()
        return max(self._stack_depths.values()) if self._stack_depths else 0

class CFGBuilder:
    
    def __init__(self, code):
        self._code = code
        self._cfg = None
    
    def build(self):
        from .disassembler import BytecodeDisassembler
        
        disasm = BytecodeDisassembler(self._code)
        instructions = disasm.disassemble()
        
        leaders = self._find_leaders(instructions)
        self._cfg = ControlFlowGraph()
        
        current_block = None
        for instr in instructions:
            if instr.offset in leaders:
                if current_block:
                    self._cfg.add_block(current_block)
                current_block = BasicBlock(instr.offset)
                if instr.offset == 0:
                    current_block.is_entry = True
            
            if current_block:
                current_block.add_instruction(instr)
        
        if current_block:
            self._cfg.add_block(current_block)
        
        self._add_edges(instructions)
        
        return self._cfg
    
    def _find_leaders(self, instructions):
        leaders = {0}
        
        for i, instr in enumerate(instructions):
            if self._is_jump(instr.opcode):
                target = instr.arg if instr.arg else 0
                if self._is_relative_jump(instr.opcode):
                    target = instr.offset + instr.size + target
                leaders.add(target)
                
                if i + 1 < len(instructions):
                    leaders.add(instructions[i + 1].offset)
            
            if instr.opcode == 83:
                if i + 1 < len(instructions):
                    leaders.add(instructions[i + 1].offset)
        
        return leaders
    
    def _add_edges(self, instructions):
        for offset, block in self._cfg.blocks.items():
            if not block.instructions:
                continue
            
            last_instr = block.instructions[-1]
            
            if self._is_jump(last_instr.opcode):
                target = last_instr.arg if last_instr.arg else 0
                if self._is_relative_jump(last_instr.opcode):
                    target = last_instr.offset + last_instr.size + target
                self._cfg.add_edge(offset, target)
                
                if not self._is_unconditional_jump(last_instr.opcode):
                    next_offset = last_instr.offset + last_instr.size
                    if next_offset in self._cfg.blocks:
                        self._cfg.add_edge(offset, next_offset)
            
            elif last_instr.opcode != 83:
                next_offset = last_instr.offset + last_instr.size
                if next_offset in self._cfg.blocks:
                    self._cfg.add_edge(offset, next_offset)
            else:
                block.is_exit = True
    
    def _is_jump(self, opcode):
        return opcode in (93, 110, 111, 112, 113, 114, 115, 121, 122, 143)
    
    def _is_relative_jump(self, opcode):
        return opcode in (93, 110, 122, 143)
    
    def _is_unconditional_jump(self, opcode):
        return opcode in (110, 113)

class BytecodeAnalyzer:
    
    def __init__(self, code):
        self._code = code
        self._cfg = None
        self._stack_depths = None
        self._locals_info = None
    
    def analyze(self):
        cfg_builder = CFGBuilder(self._code)
        self._cfg = cfg_builder.build()
        
        stack_analyzer = StackAnalyzer(self._code)
        self._stack_depths = stack_analyzer.analyze()
        
        self._analyze_locals()
        
        return {
            "cfg": self._cfg,
            "stack_depths": self._stack_depths,
            "locals": self._locals_info,
            "max_stack": stack_analyzer.get_max_stack(),
            "block_count": len(self._cfg.blocks)
        }
    
    def _analyze_locals(self):
        from .disassembler import BytecodeDisassembler
        
        disasm = BytecodeDisassembler(self._code)
        instructions = disasm.disassemble()
        
        self._locals_info = {
            "reads": {},
            "writes": {},
            "undefined": set()
        }
        
        written = set()
        
        for instr in instructions:
            if instr.opcode == 124:
                var_idx = instr.arg
                if var_idx not in self._locals_info["reads"]:
                    self._locals_info["reads"][var_idx] = []
                self._locals_info["reads"][var_idx].append(instr.offset)
                if var_idx not in written:
                    self._locals_info["undefined"].add(var_idx)
            
            elif instr.opcode == 125:
                var_idx = instr.arg
                if var_idx not in self._locals_info["writes"]:
                    self._locals_info["writes"][var_idx] = []
                self._locals_info["writes"][var_idx].append(instr.offset)
                written.add(var_idx)
    
    def get_cfg(self):
        if self._cfg is None:
            cfg_builder = CFGBuilder(self._code)
            self._cfg = cfg_builder.build()
        return self._cfg
    
    def get_stack_depths(self):
        if self._stack_depths is None:
            stack_analyzer = StackAnalyzer(self._code)
            self._stack_depths = stack_analyzer.analyze()
        return self._stack_depths

def analyze(code):
    analyzer = BytecodeAnalyzer(code)
    return analyzer.analyze()

def build_cfg(code):
    builder = CFGBuilder(code)
    return builder.build()

def analyze_stack(code):
    analyzer = StackAnalyzer(code)
    return analyzer.analyze()

def get_basic_blocks(code):
    cfg = build_cfg(code)
    return list(cfg.iter_blocks())
