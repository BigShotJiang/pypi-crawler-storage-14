import sys
import types
import dis
from typing import Dict, List, Optional, Tuple, Any, Union, Iterator

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class DisassemblerError(Exception):
    pass

class DisassembledInstruction:
    
    __slots__ = ("offset", "opcode", "opname", "arg", "argval", "argrepr",
                 "starts_line", "is_jump_target", "size")
    
    def __init__(self, offset, opcode, opname, arg=None, argval=None,
                 argrepr="", starts_line=None, is_jump_target=False, size=2):
        self.offset = offset
        self.opcode = opcode
        self.opname = opname
        self.arg = arg
        self.argval = argval
        self.argrepr = argrepr
        self.starts_line = starts_line
        self.is_jump_target = is_jump_target
        self.size = size
    
    def __repr__(self):
        return "Instruction({}, opname={!r}, arg={})".format(
            self.offset, self.opname, self.arg)
    
    def format(self, with_offset=True, with_bytes=False):
        parts = []
        if self.starts_line is not None:
            parts.append("{:>4}".format(self.starts_line))
        else:
            parts.append("    ")
        
        if self.is_jump_target:
            parts.append(">>")
        else:
            parts.append("  ")
        
        if with_offset:
            parts.append("{:>6}".format(self.offset))
        
        parts.append("{:<20}".format(self.opname))
        
        if self.arg is not None:
            parts.append("{:>5}".format(self.arg))
            if self.argrepr:
                parts.append("({})".format(self.argrepr))
        
        return " ".join(parts)

class LineTable:
    
    def __init__(self, lnotab, firstlineno):
        self._lnotab = lnotab
        self._firstlineno = firstlineno
        self._line_starts = None
    
    def _build_line_starts(self):
        if self._line_starts is not None:
            return
        
        self._line_starts = {}
        lineno = self._firstlineno
        addr = 0
        
        for i in range(0, len(self._lnotab), 2):
            addr_incr = self._lnotab[i]
            line_incr = self._lnotab[i + 1]
            
            if line_incr >= 0x80:
                line_incr -= 0x100
            
            if addr_incr:
                self._line_starts[addr] = lineno
                addr += addr_incr
            
            lineno += line_incr
    
    def get_line(self, offset):
        self._build_line_starts()
        line = self._firstlineno
        for addr, lineno in sorted(self._line_starts.items()):
            if addr > offset:
                break
            line = lineno
        return line
    
    def get_line_starts(self):
        self._build_line_starts()
        return dict(self._line_starts)

class BytecodeDisassembler:
    
    def __init__(self, code=None):
        self._code = code
        self._opmap = dict(dis.opmap)
        self._opname = dict((v, k) for k, v in dis.opmap.items())
        self._instructions = None
        self._jump_targets = None
    
    def set_code(self, code):
        self._code = code
        self._instructions = None
        self._jump_targets = None
    
    def _find_jump_targets(self, bytecode):
        targets = set()
        offset = 0
        extended_arg = 0
        
        while offset < len(bytecode):
            op = bytecode[offset]
            
            if PYTHON_VERSION >= (3, 6):
                arg = bytecode[offset + 1] if offset + 1 < len(bytecode) else 0
                size = 2
            else:
                if op >= 90:
                    arg = bytecode[offset + 1] | (bytecode[offset + 2] << 8)
                    size = 3
                else:
                    arg = 0
                    size = 1
            
            if op == 144:
                extended_arg = (extended_arg | arg) << 8
                offset += size
                continue
            
            arg = extended_arg | arg
            extended_arg = 0
            
            if self._is_jump(op):
                if self._is_relative_jump(op):
                    target = offset + size + arg
                else:
                    target = arg
                targets.add(target)
            
            offset += size
        
        return targets
    
    def _is_jump(self, opcode):
        return opcode in (93, 110, 111, 112, 113, 114, 115, 121, 122, 143, 154)
    
    def _is_relative_jump(self, opcode):
        return opcode in (93, 110, 122, 143, 154)
    
    def disassemble(self, code=None):
        if code is not None:
            self._code = code
        
        if self._code is None:
            raise DisassemblerError("No code object provided")
        
        bytecode = self._code.co_code
        self._jump_targets = self._find_jump_targets(bytecode)
        
        line_table = LineTable(self._code.co_lnotab, self._code.co_firstlineno)
        line_starts = line_table.get_line_starts()
        
        instructions = []
        offset = 0
        extended_arg = 0
        
        while offset < len(bytecode):
            op = bytecode[offset]
            
            if PYTHON_VERSION >= (3, 6):
                arg = bytecode[offset + 1] if offset + 1 < len(bytecode) else 0
                size = 2
            else:
                if op >= 90:
                    arg = bytecode[offset + 1] | (bytecode[offset + 2] << 8)
                    size = 3
                else:
                    arg = 0
                    size = 1
            
            if op == 144:
                extended_arg = (extended_arg | arg) << 8
                offset += size
                continue
            
            arg = extended_arg | arg
            extended_arg = 0
            
            opname = self._opname.get(op, "UNKNOWN")
            argval, argrepr = self._get_arg_info(op, arg)
            
            starts_line = line_starts.get(offset)
            is_jump_target = offset in self._jump_targets
            
            instr = DisassembledInstruction(
                offset=offset,
                opcode=op,
                opname=opname,
                arg=arg if op >= 90 else None,
                argval=argval,
                argrepr=argrepr,
                starts_line=starts_line,
                is_jump_target=is_jump_target,
                size=size
            )
            instructions.append(instr)
            offset += size
        
        self._instructions = instructions
        return instructions
    
    def _get_arg_info(self, opcode, arg):
        argval = arg
        argrepr = ""
        
        if opcode in (100,):
            if arg < len(self._code.co_consts):
                argval = self._code.co_consts[arg]
                argrepr = repr(argval)
        
        elif opcode in (90, 91, 95, 96, 97, 98, 101, 106, 108, 109, 116, 160):
            if arg < len(self._code.co_names):
                argval = self._code.co_names[arg]
                argrepr = argval
        
        elif opcode in (124, 125, 126):
            if arg < len(self._code.co_varnames):
                argval = self._code.co_varnames[arg]
                argrepr = argval
        
        elif opcode in (135, 136, 137, 138, 148):
            if arg < len(self._code.co_cellvars):
                argval = self._code.co_cellvars[arg]
            elif arg < len(self._code.co_cellvars) + len(self._code.co_freevars):
                argval = self._code.co_freevars[arg - len(self._code.co_cellvars)]
            argrepr = argval if isinstance(argval, str) else ""
        
        elif opcode == 107:
            cmp_ops = ("<", "<=", "==", "!=", ">", ">=")
            if arg < len(cmp_ops):
                argval = cmp_ops[arg]
                argrepr = argval
        
        elif opcode in (110, 93, 122, 143, 154):
            argrepr = "to {}".format(argval)
        
        elif opcode in (111, 112, 113, 114, 115, 121):
            argrepr = "to {}".format(arg)
        
        return argval, argrepr
    
    def format(self):
        if self._instructions is None:
            self.disassemble()
        
        lines = []
        for instr in self._instructions:
            lines.append(instr.format())
        
        return "\n".join(lines)
    
    def get_instructions(self):
        if self._instructions is None:
            self.disassemble()
        return list(self._instructions)
    
    def iter_instructions(self):
        if self._instructions is None:
            self.disassemble()
        return iter(self._instructions)

class FunctionDisassembler:
    
    def __init__(self, func):
        if not callable(func):
            raise TypeError("Expected callable")
        self._func = func
        self._code = func.__code__
        self._disasm = BytecodeDisassembler(self._code)
    
    def disassemble(self):
        return self._disasm.disassemble()
    
    def format(self):
        header = "Disassembly of {}:\n".format(self._func.__name__)
        return header + self._disasm.format()
    
    def get_instructions(self):
        return self._disasm.get_instructions()
    
    def get_nested_codes(self):
        nested = []
        for const in self._code.co_consts:
            if isinstance(const, types.CodeType):
                nested.append(const)
        return nested

class ModuleDisassembler:
    
    def __init__(self, module):
        self._module = module
        self._functions = {}
        self._codes = {}
        self._find_functions()
    
    def _find_functions(self):
        for name in dir(self._module):
            obj = getattr(self._module, name)
            if callable(obj) and hasattr(obj, "__code__"):
                self._functions[name] = obj
                self._codes[name] = obj.__code__
    
    def disassemble_all(self):
        results = {}
        for name, func in self._functions.items():
            disasm = FunctionDisassembler(func)
            results[name] = disasm.get_instructions()
        return results
    
    def format_all(self):
        parts = []
        for name, func in sorted(self._functions.items()):
            disasm = FunctionDisassembler(func)
            parts.append(disasm.format())
            parts.append("")
        return "\n".join(parts)

class BytecodeReader:
    
    def __init__(self, bytecode):
        self._bytecode = bytecode
        self._offset = 0
    
    def read_instruction(self):
        if self._offset >= len(self._bytecode):
            return None
        
        op = self._bytecode[self._offset]
        
        if PYTHON_VERSION >= (3, 6):
            arg = self._bytecode[self._offset + 1] if self._offset + 1 < len(self._bytecode) else 0
            size = 2
        else:
            if op >= 90:
                arg = self._bytecode[self._offset + 1] | (self._bytecode[self._offset + 2] << 8)
                size = 3
            else:
                arg = 0
                size = 1
        
        result = (self._offset, op, arg, size)
        self._offset += size
        return result
    
    def reset(self):
        self._offset = 0
    
    def seek(self, offset):
        self._offset = offset
    
    def tell(self):
        return self._offset
    
    def __iter__(self):
        self.reset()
        return self
    
    def __next__(self):
        result = self.read_instruction()
        if result is None:
            raise StopIteration
        return result

def disassemble(code):
    disasm = BytecodeDisassembler(code)
    return disasm.disassemble()

def disassemble_function(func):
    disasm = FunctionDisassembler(func)
    return disasm.disassemble()

def format_bytecode(code):
    disasm = BytecodeDisassembler(code)
    return disasm.format()

def get_instructions(code):
    disasm = BytecodeDisassembler(code)
    return disasm.get_instructions()

def iter_instructions(code):
    disasm = BytecodeDisassembler(code)
    return disasm.iter_instructions()

def read_bytecode(bytecode):
    reader = BytecodeReader(bytecode)
    return list(reader)
