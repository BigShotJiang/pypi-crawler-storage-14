import sys
import types
import struct
from typing import Dict, List, Optional, Tuple, Any, Union, Callable

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class BytecodeError(Exception):
    pass

class BytecodeData:
    
    __slots__ = ("_code", "_consts", "_names", "_varnames", "_freevars", 
                 "_cellvars", "_filename", "_name", "_firstlineno", 
                 "_lnotab", "_flags", "_argcount", "_kwonlyargcount",
                 "_posonlyargcount", "_stacksize", "_nlocals")
    
    def __init__(self):
        self._code = b""
        self._consts = ()
        self._names = ()
        self._varnames = ()
        self._freevars = ()
        self._cellvars = ()
        self._filename = "<bytecode>"
        self._name = "<module>"
        self._firstlineno = 1
        self._lnotab = b""
        self._flags = 0
        self._argcount = 0
        self._kwonlyargcount = 0
        self._posonlyargcount = 0
        self._stacksize = 1
        self._nlocals = 0
    
    @classmethod
    def from_code(cls, code_obj):
        data = cls()
        data._code = code_obj.co_code
        data._consts = code_obj.co_consts
        data._names = code_obj.co_names
        data._varnames = code_obj.co_varnames
        data._freevars = code_obj.co_freevars
        data._cellvars = code_obj.co_cellvars
        data._filename = code_obj.co_filename
        data._name = code_obj.co_name
        data._firstlineno = code_obj.co_firstlineno
        data._lnotab = code_obj.co_lnotab
        data._flags = code_obj.co_flags
        data._argcount = code_obj.co_argcount
        data._kwonlyargcount = code_obj.co_kwonlyargcount
        if hasattr(code_obj, "co_posonlyargcount"):
            data._posonlyargcount = code_obj.co_posonlyargcount
        data._stacksize = code_obj.co_stacksize
        data._nlocals = code_obj.co_nlocals
        return data
    
    def to_code(self):
        if PYTHON_VERSION >= (3, 11):
            return types.CodeType(
                self._argcount,
                self._posonlyargcount,
                self._kwonlyargcount,
                self._nlocals,
                self._stacksize,
                self._flags,
                self._code,
                self._consts,
                self._names,
                self._varnames,
                self._filename,
                self._name,
                self._name,
                self._firstlineno,
                self._lnotab,
                b"",
                self._freevars,
                self._cellvars
            )
        elif PYTHON_VERSION >= (3, 8):
            return types.CodeType(
                self._argcount,
                self._posonlyargcount,
                self._kwonlyargcount,
                self._nlocals,
                self._stacksize,
                self._flags,
                self._code,
                self._consts,
                self._names,
                self._varnames,
                self._filename,
                self._name,
                self._firstlineno,
                self._lnotab,
                self._freevars,
                self._cellvars
            )
        else:
            return types.CodeType(
                self._argcount,
                self._kwonlyargcount,
                self._nlocals,
                self._stacksize,
                self._flags,
                self._code,
                self._consts,
                self._names,
                self._varnames,
                self._filename,
                self._name,
                self._firstlineno,
                self._lnotab,
                self._freevars,
                self._cellvars
            )
    
    @property
    def code(self):
        return self._code
    
    @code.setter
    def code(self, value):
        self._code = bytes(value)
    
    @property
    def consts(self):
        return self._consts
    
    @consts.setter
    def consts(self, value):
        self._consts = tuple(value)
    
    @property
    def names(self):
        return self._names
    
    @names.setter
    def names(self, value):
        self._names = tuple(value)
    
    @property
    def varnames(self):
        return self._varnames
    
    @varnames.setter
    def varnames(self, value):
        self._varnames = tuple(value)
    
    @property
    def freevars(self):
        return self._freevars
    
    @freevars.setter
    def freevars(self, value):
        self._freevars = tuple(value)
    
    @property
    def cellvars(self):
        return self._cellvars
    
    @cellvars.setter
    def cellvars(self, value):
        self._cellvars = tuple(value)
    
    @property
    def filename(self):
        return self._filename
    
    @filename.setter
    def filename(self, value):
        self._filename = str(value)
    
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        self._name = str(value)
    
    @property
    def firstlineno(self):
        return self._firstlineno
    
    @firstlineno.setter
    def firstlineno(self, value):
        self._firstlineno = int(value)
    
    @property
    def flags(self):
        return self._flags
    
    @flags.setter
    def flags(self, value):
        self._flags = int(value)
    
    @property
    def argcount(self):
        return self._argcount
    
    @argcount.setter
    def argcount(self, value):
        self._argcount = int(value)
    
    @property
    def stacksize(self):
        return self._stacksize
    
    @stacksize.setter
    def stacksize(self, value):
        self._stacksize = int(value)

class BytecodeModifier:
    
    def __init__(self, bytecode_data):
        self._data = bytecode_data
        self._modifications = []
    
    def add_const(self, value):
        consts = list(self._data.consts)
        for i, c in enumerate(consts):
            if c == value and type(c) is type(value):
                return i
        index = len(consts)
        consts.append(value)
        self._data.consts = tuple(consts)
        return index
    
    def add_name(self, name):
        names = list(self._data.names)
        for i, n in enumerate(names):
            if n == name:
                return i
        index = len(names)
        names.append(name)
        self._data.names = tuple(names)
        return index
    
    def add_varname(self, name):
        varnames = list(self._data.varnames)
        for i, n in enumerate(varnames):
            if n == name:
                return i
        index = len(varnames)
        varnames.append(name)
        self._data.varnames = tuple(varnames)
        self._data._nlocals = len(varnames)
        return index
    
    def remove_const(self, index):
        consts = list(self._data.consts)
        if 0 <= index < len(consts):
            consts.pop(index)
            self._data.consts = tuple(consts)
            return True
        return False
    
    def replace_const(self, index, value):
        consts = list(self._data.consts)
        if 0 <= index < len(consts):
            consts[index] = value
            self._data.consts = tuple(consts)
            return True
        return False
    
    def get_const(self, index):
        if 0 <= index < len(self._data.consts):
            return self._data.consts[index]
        return None
    
    def get_name(self, index):
        if 0 <= index < len(self._data.names):
            return self._data.names[index]
        return None
    
    def get_varname(self, index):
        if 0 <= index < len(self._data.varnames):
            return self._data.varnames[index]
        return None
    
    def set_code(self, bytecode):
        self._data.code = bytecode
    
    def get_code(self):
        return self._data.code
    
    def set_flags(self, flags):
        self._data.flags = flags
    
    def add_flag(self, flag):
        self._data.flags |= flag
    
    def remove_flag(self, flag):
        self._data.flags &= ~flag
    
    def has_flag(self, flag):
        return bool(self._data.flags & flag)

class BytecodeBuilder:
    
    def __init__(self, name="<module>", filename="<bytecode>"):
        self._data = BytecodeData()
        self._data.name = name
        self._data.filename = filename
        self._code_buffer = bytearray()
        self._consts = [None]
        self._names = []
        self._varnames = []
        self._freevars = []
        self._cellvars = []
        self._labels = {}
        self._pending_jumps = []
        self._lineno = 1
        self._lnotab = bytearray()
        self._last_lineno = 1
        self._last_offset = 0
    
    def _emit(self, opcode, arg=0):
        if PYTHON_VERSION >= (3, 6):
            self._emit_wordcode(opcode, arg)
        else:
            self._emit_legacy(opcode, arg)
    
    def _emit_wordcode(self, opcode, arg):
        if arg > 0xFFFFFF:
            self._code_buffer.extend([144, (arg >> 24) & 0xFF])
            self._code_buffer.extend([144, (arg >> 16) & 0xFF])
            self._code_buffer.extend([144, (arg >> 8) & 0xFF])
        elif arg > 0xFFFF:
            self._code_buffer.extend([144, (arg >> 16) & 0xFF])
            self._code_buffer.extend([144, (arg >> 8) & 0xFF])
        elif arg > 0xFF:
            self._code_buffer.extend([144, (arg >> 8) & 0xFF])
        self._code_buffer.extend([opcode, arg & 0xFF])
    
    def _emit_legacy(self, opcode, arg):
        if opcode >= 90:
            self._code_buffer.extend([opcode, arg & 0xFF, (arg >> 8) & 0xFF])
        else:
            self._code_buffer.append(opcode)
    
    def emit(self, opcode, arg=0):
        self._emit(opcode, arg)
        return len(self._code_buffer)
    
    def emit_nop(self):
        return self.emit(9)
    
    def emit_pop_top(self):
        return self.emit(1)
    
    def emit_return_value(self):
        return self.emit(83)
    
    def emit_load_const(self, value):
        index = self._add_const(value)
        return self.emit(100, index)
    
    def emit_load_fast(self, name):
        index = self._add_varname(name)
        return self.emit(124, index)
    
    def emit_store_fast(self, name):
        index = self._add_varname(name)
        return self.emit(125, index)
    
    def emit_load_global(self, name):
        index = self._add_name(name)
        return self.emit(116, index)
    
    def emit_store_global(self, name):
        index = self._add_name(name)
        return self.emit(97, index)
    
    def emit_load_name(self, name):
        index = self._add_name(name)
        return self.emit(101, index)
    
    def emit_store_name(self, name):
        index = self._add_name(name)
        return self.emit(90, index)
    
    def emit_binary_add(self):
        return self.emit(23)
    
    def emit_binary_subtract(self):
        return self.emit(24)
    
    def emit_binary_multiply(self):
        return self.emit(20)
    
    def emit_call_function(self, argc):
        return self.emit(131, argc)
    
    def _add_const(self, value):
        for i, c in enumerate(self._consts):
            if c == value and type(c) is type(value):
                return i
        index = len(self._consts)
        self._consts.append(value)
        return index
    
    def _add_name(self, name):
        for i, n in enumerate(self._names):
            if n == name:
                return i
        index = len(self._names)
        self._names.append(name)
        return index
    
    def _add_varname(self, name):
        for i, n in enumerate(self._varnames):
            if n == name:
                return i
        index = len(self._varnames)
        self._varnames.append(name)
        return index
    
    def create_label(self, name=None):
        if name is None:
            name = "_L{}".format(len(self._labels))
        self._labels[name] = None
        return name
    
    def bind_label(self, name):
        self._labels[name] = len(self._code_buffer)
    
    def emit_jump(self, opcode, label):
        offset = len(self._code_buffer)
        self._pending_jumps.append((offset, opcode, label))
        if PYTHON_VERSION >= (3, 6):
            self._code_buffer.extend([opcode, 0])
        else:
            self._code_buffer.extend([opcode, 0, 0])
        return offset
    
    def emit_jump_absolute(self, label):
        return self.emit_jump(113, label)
    
    def emit_pop_jump_if_false(self, label):
        return self.emit_jump(114, label)
    
    def emit_pop_jump_if_true(self, label):
        return self.emit_jump(115, label)
    
    def emit_jump_forward(self, label):
        return self.emit_jump(110, label)
    
    def set_line(self, lineno):
        self._lineno = lineno
    
    def _resolve_jumps(self):
        for offset, opcode, label in self._pending_jumps:
            target = self._labels.get(label)
            if target is None:
                raise BytecodeError("Unbound label: {}".format(label))
            if opcode == 110:
                delta = target - offset - 2
                if PYTHON_VERSION >= (3, 6):
                    self._code_buffer[offset + 1] = delta & 0xFF
                else:
                    self._code_buffer[offset + 1] = delta & 0xFF
                    self._code_buffer[offset + 2] = (delta >> 8) & 0xFF
            else:
                if PYTHON_VERSION >= (3, 6):
                    self._code_buffer[offset + 1] = target & 0xFF
                else:
                    self._code_buffer[offset + 1] = target & 0xFF
                    self._code_buffer[offset + 2] = (target >> 8) & 0xFF
    
    def build(self):
        self._resolve_jumps()
        self._data.code = bytes(self._code_buffer)
        self._data.consts = tuple(self._consts)
        self._data.names = tuple(self._names)
        self._data.varnames = tuple(self._varnames)
        self._data.freevars = tuple(self._freevars)
        self._data.cellvars = tuple(self._cellvars)
        self._data._nlocals = len(self._varnames)
        self._data._lnotab = bytes(self._lnotab)
        return self._data.to_code()

class Bytecode:
    
    def __init__(self, source=None):
        if source is None:
            self._data = BytecodeData()
        elif isinstance(source, types.CodeType):
            self._data = BytecodeData.from_code(source)
        elif isinstance(source, BytecodeData):
            self._data = source
        elif callable(source):
            self._data = BytecodeData.from_code(source.__code__)
        else:
            raise TypeError("Expected code object, callable, or BytecodeData")
        self._modifier = BytecodeModifier(self._data)
    
    @classmethod
    def from_function(cls, func):
        return cls(func.__code__)
    
    @classmethod
    def from_source(cls, source, filename="<string>", mode="exec"):
        code = compile(source, filename, mode)
        return cls(code)
    
    def to_code(self):
        return self._data.to_code()
    
    def to_function(self, globals_dict=None, name=None):
        code = self.to_code()
        if globals_dict is None:
            globals_dict = {}
        func = types.FunctionType(code, globals_dict, name or code.co_name)
        return func
    
    @property
    def data(self):
        return self._data
    
    @property
    def modifier(self):
        return self._modifier
    
    @property
    def code(self):
        return self._data.code
    
    @property
    def consts(self):
        return self._data.consts
    
    @property
    def names(self):
        return self._data.names
    
    @property
    def varnames(self):
        return self._data.varnames
    
    def copy(self):
        new_data = BytecodeData()
        new_data._code = self._data._code
        new_data._consts = self._data._consts
        new_data._names = self._data._names
        new_data._varnames = self._data._varnames
        new_data._freevars = self._data._freevars
        new_data._cellvars = self._data._cellvars
        new_data._filename = self._data._filename
        new_data._name = self._data._name
        new_data._firstlineno = self._data._firstlineno
        new_data._lnotab = self._data._lnotab
        new_data._flags = self._data._flags
        new_data._argcount = self._data._argcount
        new_data._kwonlyargcount = self._data._kwonlyargcount
        new_data._posonlyargcount = self._data._posonlyargcount
        new_data._stacksize = self._data._stacksize
        new_data._nlocals = self._data._nlocals
        return Bytecode(new_data)

def create_bytecode(name="<module>", filename="<bytecode>"):
    return BytecodeBuilder(name, filename)

def from_code(code_obj):
    return Bytecode(code_obj)

def from_function(func):
    return Bytecode.from_function(func)

def from_source(source, filename="<string>"):
    return Bytecode.from_source(source, filename)
