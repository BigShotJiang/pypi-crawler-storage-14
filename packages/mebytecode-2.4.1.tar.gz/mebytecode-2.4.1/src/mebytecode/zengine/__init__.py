import sys
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

__author__ = "mero"
__version__ = "1.0.0"
__all__ = [
    "Bytecode",
    "BytecodeBuilder",
    "BytecodeData",
    "BytecodeModifier",
    "BytecodeError",
    "Instruction",
    "InstructionBuilder",
    "InstructionSequence",
    "InstructionFactory",
    "Label",
    "LabelManager",
    "OpcodeInfo",
    "OpcodeCategory",
    "OpcodeFlags",
    "OpcodeRegistry",
    "OpcodeEncoder",
    "OpcodeDecoder",
    "BytecodeAssembler",
    "AssemblerError",
    "AssemblerToken",
    "AssemblerLexer",
    "AssemblerParser",
    "InstructionAssembler",
    "BytecodeDisassembler",
    "DisassembledInstruction",
    "FunctionDisassembler",
    "ModuleDisassembler",
    "DisassemblerError",
    "BytecodeAnalyzer",
    "BasicBlock",
    "ControlFlowGraph",
    "StackAnalyzer",
    "CFGBuilder",
    "AnalysisError",
    "BytecodeOptimizer",
    "OptimizationPass",
    "ConstantFolding",
    "DeadCodeElimination",
    "PeepholeOptimizer",
    "JumpOptimizer",
    "OptimizationError",
    "BytecodeTransformer",
    "Transform",
    "ReplaceTransform",
    "InstructionTransform",
    "InsertTransform",
    "RemoveTransform",
    "WrapTransform",
    "PatternMatcher",
    "InstructionMatcher",
    "TransformContext",
    "TransformError",
    "FunctionBuilder",
    "ExpressionGenerator",
    "CodeBlock",
    "GeneratorError",
    "BytecodeVerifier",
    "VerificationResult",
    "VerificationError",
    "VerificationWarning",
    "VerificationRule",
    "VerificationContext",
    "BytecodeExecutor",
    "ExecutionContext",
    "ExecutionConfig",
    "ExecutionResult",
    "ExecutionState",
    "ExecutionError",
    "FunctionExecutor",
    "assemble",
    "assemble_instructions",
    "disassemble",
    "disassemble_function",
    "format_bytecode",
    "get_instructions",
    "analyze",
    "build_cfg",
    "analyze_stack",
    "get_basic_blocks",
    "optimize",
    "create_optimizer",
    "transform_function",
    "create_transformer",
    "create_pattern",
    "create_matcher",
    "generate_simple_function",
    "generate_constant_function",
    "generate_identity_function",
    "create_function_builder",
    "verify",
    "verify_function",
    "is_valid",
    "get_errors",
    "get_warnings",
    "execute",
    "execute_function",
    "create_executor",
    "create_context",
    "create_config",
    "from_code",
    "from_function",
    "from_source",
    "create_bytecode",
    "get_opcode_info",
    "get_opcode_by_name",
    "is_jump_opcode",
    "has_argument",
    "list_all_opcodes",
]

from .bytecode import (
    Bytecode,
    BytecodeBuilder,
    BytecodeData,
    BytecodeModifier,
    BytecodeError,
    create_bytecode,
    from_code,
    from_function,
    from_source,
)

from .instructions import (
    Instruction,
    InstructionBuilder,
    InstructionSequence,
    InstructionFactory,
    Label,
    LabelManager,
    InstructionArg,
    create_instruction,
    create_instruction_sequence,
    instruction_from_tuple,
)

from .opcodes import (
    OpcodeInfo,
    OpcodeCategory,
    OpcodeFlags,
    OpcodeRegistry,
    OpcodeEncoder,
    OpcodeDecoder,
    OPCODE_MAP,
    OPNAME_MAP,
    COMPARE_OPS,
    get_opcode_info,
    get_opcode_by_name,
    is_jump_opcode,
    is_relative_jump,
    is_absolute_jump,
    get_stack_effect,
    has_argument,
    list_all_opcodes,
    list_opcodes_by_category,
)

from .assembler import (
    BytecodeAssembler,
    AssemblerError,
    AssemblerToken,
    AssemblerLexer,
    AssemblerParser,
    InstructionAssembler,
    assemble,
    assemble_instructions,
    quick_assemble,
)

from .disassembler import (
    BytecodeDisassembler,
    DisassembledInstruction,
    FunctionDisassembler,
    ModuleDisassembler,
    BytecodeReader,
    LineTable,
    DisassemblerError,
    disassemble,
    disassemble_function,
    format_bytecode,
    get_instructions,
    iter_instructions,
    read_bytecode,
)

from .analyzer import (
    BytecodeAnalyzer,
    BasicBlock,
    ControlFlowGraph,
    StackAnalyzer,
    CFGBuilder,
    AnalysisError,
    analyze,
    build_cfg,
    analyze_stack,
    get_basic_blocks,
)

from .optimizer import (
    BytecodeOptimizer,
    OptimizationPass,
    OptimizationContext,
    ConstantFolding,
    DeadCodeElimination,
    PeepholeOptimizer,
    JumpOptimizer,
    OptimizationError,
    optimize,
    create_optimizer,
)

from .transformer import (
    BytecodeTransformer,
    Transform,
    ReplaceTransform,
    InstructionTransform,
    InsertTransform,
    RemoveTransform,
    WrapTransform,
    PatternMatcher,
    InstructionMatcher,
    TransformContext,
    FunctionTransformer,
    TransformError,
    create_transformer,
    transform_function,
    create_pattern,
    create_matcher,
)

from .generator import (
    FunctionBuilder,
    ExpressionGenerator,
    CodeBlock,
    GeneratorError,
    create_function_builder,
    generate_simple_function,
    generate_constant_function,
    generate_identity_function,
)

from .verifier import (
    BytecodeVerifier,
    VerificationResult,
    VerificationError,
    VerificationWarning,
    VerificationRule,
    VerificationContext,
    OpcodeValidityRule,
    ArgumentValidityRule,
    StackBalanceRule,
    JumpTargetRule,
    ConstIndexRule,
    NameIndexRule,
    LocalIndexRule,
    ReturnPathRule,
    FunctionVerifier,
    verify,
    verify_function,
    is_valid,
    get_errors,
    get_warnings,
    quick_verify,
)

from .executor import (
    BytecodeExecutor,
    ExecutionContext,
    ExecutionConfig,
    ExecutionResult,
    ExecutionState,
    ExecutionError,
    FunctionExecutor,
    execute,
    execute_function,
    create_executor,
    create_context,
    create_config,
)

PYTHON_VERSION = sys.version_info[:2]

def get_version():
    return __version__

def get_python_version():
    return PYTHON_VERSION

def is_compatible():
    return PYTHON_VERSION >= (3, 5)

def create_code_from_source(source, name="<generated>", filename="<generated>"):
    code = compile(source, filename, "exec")
    return code

def modify_function(func, modifier_func):
    bytecode = Bytecode.from_function(func)
    modifier_func(bytecode)
    new_code = bytecode.to_code()
    import types
    return types.FunctionType(
        new_code,
        func.__globals__,
        func.__name__,
        func.__defaults__,
        func.__closure__
    )

def analyze_function(func):
    return analyze(func.__code__)

def optimize_function(func):
    new_code = optimize(func.__code__)
    import types
    return types.FunctionType(
        new_code,
        func.__globals__,
        func.__name__,
        func.__defaults__,
        func.__closure__
    )

def disassemble_to_string(code):
    return format_bytecode(code)

def get_instruction_count(code):
    instructions = get_instructions(code)
    return len(instructions)

def find_instructions(code, opname=None, opcode=None):
    instructions = get_instructions(code)
    results = []
    for instr in instructions:
        if opname is not None and instr.opname == opname:
            results.append(instr)
        elif opcode is not None and instr.opcode == opcode:
            results.append(instr)
    return results

def count_opcodes(code):
    instructions = get_instructions(code)
    counts = {}
    for instr in instructions:
        counts[instr.opname] = counts.get(instr.opname, 0) + 1
    return counts
