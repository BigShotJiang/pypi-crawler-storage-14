import sys
import types
from typing import Dict, List, Optional, Tuple, Any, Callable, Union

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class TransformError(Exception):
    pass

class InstructionMatcher:
    
    def __init__(self, opcode=None, opname=None, arg=None, predicate=None):
        self.opcode = opcode
        self.opname = opname
        self.arg = arg
        self.predicate = predicate
    
    def matches(self, instruction):
        if self.opcode is not None and instruction.opcode != self.opcode:
            return False
        if self.opname is not None and instruction.opname != self.opname:
            return False
        if self.arg is not None and instruction.arg != self.arg:
            return False
        if self.predicate is not None and not self.predicate(instruction):
            return False
        return True

class PatternMatcher:
    
    def __init__(self, matchers):
        self.matchers = matchers
    
    def match(self, instructions, start_index):
        if start_index + len(self.matchers) > len(instructions):
            return None
        
        matched = []
        for i, matcher in enumerate(self.matchers):
            instr = instructions[start_index + i]
            if not matcher.matches(instr):
                return None
            matched.append(instr)
        
        return matched

class Transform:
    
    name = "base_transform"
    
    def __init__(self, enabled=True):
        self.enabled = enabled
    
    def apply(self, instructions, context):
        raise NotImplementedError

class ReplaceTransform(Transform):
    
    name = "replace"
    
    def __init__(self, pattern, replacement_func, enabled=True):
        super().__init__(enabled)
        self.pattern = pattern
        self.replacement_func = replacement_func
    
    def apply(self, instructions, context):
        result = []
        i = 0
        
        while i < len(instructions):
            matched = self.pattern.match(instructions, i)
            if matched:
                replacement = self.replacement_func(matched, context)
                if replacement is not None:
                    if isinstance(replacement, list):
                        result.extend(replacement)
                    else:
                        result.append(replacement)
                    i += len(matched)
                    continue
            
            result.append(instructions[i])
            i += 1
        
        return result

class InstructionTransform(Transform):
    
    name = "instruction"
    
    def __init__(self, filter_func, transform_func, enabled=True):
        super().__init__(enabled)
        self.filter_func = filter_func
        self.transform_func = transform_func
    
    def apply(self, instructions, context):
        result = []
        for instr in instructions:
            if self.filter_func(instr):
                transformed = self.transform_func(instr, context)
                if transformed is not None:
                    if isinstance(transformed, list):
                        result.extend(transformed)
                    else:
                        result.append(transformed)
            else:
                result.append(instr)
        return result

class InsertTransform(Transform):
    
    name = "insert"
    
    def __init__(self, position_func, generator_func, enabled=True):
        super().__init__(enabled)
        self.position_func = position_func
        self.generator_func = generator_func
    
    def apply(self, instructions, context):
        result = []
        for i, instr in enumerate(instructions):
            if self.position_func(instr, i):
                generated = self.generator_func(instr, context)
                if generated:
                    if isinstance(generated, list):
                        result.extend(generated)
                    else:
                        result.append(generated)
            result.append(instr)
        return result

class RemoveTransform(Transform):
    
    name = "remove"
    
    def __init__(self, filter_func, enabled=True):
        super().__init__(enabled)
        self.filter_func = filter_func
    
    def apply(self, instructions, context):
        return [instr for instr in instructions if not self.filter_func(instr)]

class WrapTransform(Transform):
    
    name = "wrap"
    
    def __init__(self, filter_func, before_func=None, after_func=None, enabled=True):
        super().__init__(enabled)
        self.filter_func = filter_func
        self.before_func = before_func
        self.after_func = after_func
    
    def apply(self, instructions, context):
        result = []
        for instr in instructions:
            if self.filter_func(instr):
                if self.before_func:
                    before = self.before_func(instr, context)
                    if before:
                        if isinstance(before, list):
                            result.extend(before)
                        else:
                            result.append(before)
                
                result.append(instr)
                
                if self.after_func:
                    after = self.after_func(instr, context)
                    if after:
                        if isinstance(after, list):
                            result.extend(after)
                        else:
                            result.append(after)
            else:
                result.append(instr)
        return result

class TransformContext:
    
    def __init__(self, code=None):
        self._code = code
        self._consts = list(code.co_consts) if code else [None]
        self._names = list(code.co_names) if code else []
        self._varnames = list(code.co_varnames) if code else []
        self._data = {}
    
    def get_const(self, index):
        if 0 <= index < len(self._consts):
            return self._consts[index]
        return None
    
    def add_const(self, value):
        for i, c in enumerate(self._consts):
            if c == value and type(c) is type(value):
                return i
        index = len(self._consts)
        self._consts.append(value)
        return index
    
    def get_name(self, index):
        if 0 <= index < len(self._names):
            return self._names[index]
        return None
    
    def add_name(self, name):
        if name in self._names:
            return self._names.index(name)
        index = len(self._names)
        self._names.append(name)
        return index
    
    def get_varname(self, index):
        if 0 <= index < len(self._varnames):
            return self._varnames[index]
        return None
    
    def add_varname(self, name):
        if name in self._varnames:
            return self._varnames.index(name)
        index = len(self._varnames)
        self._varnames.append(name)
        return index
    
    def set_data(self, key, value):
        self._data[key] = value
    
    def get_data(self, key, default=None):
        return self._data.get(key, default)
    
    @property
    def consts(self):
        return tuple(self._consts)
    
    @property
    def names(self):
        return tuple(self._names)
    
    @property
    def varnames(self):
        return tuple(self._varnames)

class BytecodeTransformer:
    
    def __init__(self, code=None):
        self._code = code
        self._transforms = []
    
    def add_transform(self, transform):
        self._transforms.append(transform)
        return self
    
    def remove_transform(self, name):
        self._transforms = [t for t in self._transforms if t.name != name]
        return self
    
    def replace_pattern(self, pattern, replacement_func):
        transform = ReplaceTransform(pattern, replacement_func)
        self._transforms.append(transform)
        return self
    
    def transform_instruction(self, filter_func, transform_func):
        transform = InstructionTransform(filter_func, transform_func)
        self._transforms.append(transform)
        return self
    
    def insert_before(self, filter_func, generator_func):
        transform = InsertTransform(filter_func, generator_func)
        self._transforms.append(transform)
        return self
    
    def remove_instructions(self, filter_func):
        transform = RemoveTransform(filter_func)
        self._transforms.append(transform)
        return self
    
    def wrap_instruction(self, filter_func, before_func=None, after_func=None):
        transform = WrapTransform(filter_func, before_func, after_func)
        self._transforms.append(transform)
        return self
    
    def transform(self, code=None):
        if code is not None:
            self._code = code
        
        if self._code is None:
            raise TransformError("No code object provided")
        
        from .disassembler import BytecodeDisassembler
        from .assembler import BytecodeAssembler
        
        disasm = BytecodeDisassembler(self._code)
        instructions = disasm.disassemble()
        
        context = TransformContext(self._code)
        
        for transform in self._transforms:
            if transform.enabled:
                instructions = transform.apply(instructions, context)
        
        self._recalculate_offsets(instructions)
        
        assembler = BytecodeAssembler()
        assembler._consts = list(context.consts)
        assembler._names = list(context.names)
        assembler._varnames = list(context.varnames)
        assembler._filename = self._code.co_filename
        assembler._name = self._code.co_name
        assembler._flags = self._code.co_flags
        assembler._argcount = self._code.co_argcount
        
        bytecode = assembler.assemble_instructions(instructions)
        return self._create_code(bytecode, context)
    
    def _recalculate_offsets(self, instructions):
        offset = 0
        for instr in instructions:
            instr.offset = offset
            offset += instr.size
    
    def _create_code(self, bytecode, context):
        if PYTHON_VERSION >= (3, 11):
            return types.CodeType(
                self._code.co_argcount,
                getattr(self._code, "co_posonlyargcount", 0),
                self._code.co_kwonlyargcount,
                len(context.varnames),
                self._code.co_stacksize,
                self._code.co_flags,
                bytecode,
                context.consts,
                context.names,
                context.varnames,
                self._code.co_filename,
                self._code.co_name,
                getattr(self._code, "co_qualname", self._code.co_name),
                self._code.co_firstlineno,
                getattr(self._code, "co_linetable", self._code.co_lnotab),
                getattr(self._code, "co_exceptiontable", b""),
                self._code.co_freevars,
                self._code.co_cellvars
            )
        elif PYTHON_VERSION >= (3, 8):
            return types.CodeType(
                self._code.co_argcount,
                getattr(self._code, "co_posonlyargcount", 0),
                self._code.co_kwonlyargcount,
                len(context.varnames),
                self._code.co_stacksize,
                self._code.co_flags,
                bytecode,
                context.consts,
                context.names,
                context.varnames,
                self._code.co_filename,
                self._code.co_name,
                self._code.co_firstlineno,
                self._code.co_lnotab,
                self._code.co_freevars,
                self._code.co_cellvars
            )
        else:
            return types.CodeType(
                self._code.co_argcount,
                self._code.co_kwonlyargcount,
                len(context.varnames),
                self._code.co_stacksize,
                self._code.co_flags,
                bytecode,
                context.consts,
                context.names,
                context.varnames,
                self._code.co_filename,
                self._code.co_name,
                self._code.co_firstlineno,
                self._code.co_lnotab,
                self._code.co_freevars,
                self._code.co_cellvars
            )

class FunctionTransformer:
    
    def __init__(self, func):
        if not callable(func):
            raise TypeError("Expected callable")
        self._func = func
        self._transformer = BytecodeTransformer(func.__code__)
    
    def add_transform(self, transform):
        self._transformer.add_transform(transform)
        return self
    
    def transform(self):
        new_code = self._transformer.transform()
        new_func = types.FunctionType(
            new_code,
            self._func.__globals__,
            self._func.__name__,
            self._func.__defaults__,
            self._func.__closure__
        )
        return new_func

def create_transformer(code=None):
    return BytecodeTransformer(code)

def transform_function(func, transforms):
    transformer = FunctionTransformer(func)
    for t in transforms:
        transformer.add_transform(t)
    return transformer.transform()

def create_pattern(*matchers):
    return PatternMatcher([InstructionMatcher(**m) if isinstance(m, dict) else m for m in matchers])

def create_matcher(opcode=None, opname=None, arg=None, predicate=None):
    return InstructionMatcher(opcode, opname, arg, predicate)
