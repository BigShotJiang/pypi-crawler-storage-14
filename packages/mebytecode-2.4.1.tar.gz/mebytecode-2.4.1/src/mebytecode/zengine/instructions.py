import sys
from typing import Dict, List, Optional, Tuple, Any, Union, Iterator

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class InstructionArg:
    
    def __init__(self, value, arg_type=None, resolved=None):
        self.value = value
        self.arg_type = arg_type
        self.resolved = resolved
    
    def __repr__(self):
        if self.resolved is not None:
            return "InstructionArg({}, resolved={!r})".format(self.value, self.resolved)
        return "InstructionArg({})".format(self.value)
    
    def __eq__(self, other):
        if isinstance(other, InstructionArg):
            return self.value == other.value and self.arg_type == other.arg_type
        return self.value == other
    
    def __hash__(self):
        return hash((self.value, self.arg_type))

class Instruction:
    
    __slots__ = ("opcode", "opname", "arg", "argval", "argrepr", "offset", 
                 "starts_line", "is_jump_target", "positions", "_size")
    
    def __init__(self, opcode, opname, arg=None, argval=None, argrepr="",
                 offset=0, starts_line=None, is_jump_target=False, positions=None):
        self.opcode = opcode
        self.opname = opname
        self.arg = arg
        self.argval = argval
        self.argrepr = argrepr
        self.offset = offset
        self.starts_line = starts_line
        self.is_jump_target = is_jump_target
        self.positions = positions
        self._size = None
    
    @property
    def size(self):
        if self._size is not None:
            return self._size
        if PYTHON_VERSION >= (3, 6):
            if self.arg is None:
                return 2
            arg = self.arg
            size = 2
            while arg > 0xFF:
                size += 2
                arg >>= 8
            return size
        else:
            return 3 if self.opcode >= 90 else 1
    
    @size.setter
    def size(self, value):
        self._size = value
    
    @property
    def has_arg(self):
        return self.opcode >= 90
    
    def copy(self):
        return Instruction(
            opcode=self.opcode,
            opname=self.opname,
            arg=self.arg,
            argval=self.argval,
            argrepr=self.argrepr,
            offset=self.offset,
            starts_line=self.starts_line,
            is_jump_target=self.is_jump_target,
            positions=self.positions
        )
    
    def with_arg(self, arg, argval=None, argrepr=None):
        instr = self.copy()
        instr.arg = arg
        if argval is not None:
            instr.argval = argval
        if argrepr is not None:
            instr.argrepr = argrepr
        return instr
    
    def with_offset(self, offset):
        instr = self.copy()
        instr.offset = offset
        return instr
    
    def __repr__(self):
        return "Instruction(opname={!r}, arg={}, offset={})".format(
            self.opname, self.arg, self.offset)
    
    def __eq__(self, other):
        if not isinstance(other, Instruction):
            return False
        return (self.opcode == other.opcode and 
                self.arg == other.arg and
                self.offset == other.offset)
    
    def __hash__(self):
        return hash((self.opcode, self.arg, self.offset))

class InstructionBuilder:
    
    def __init__(self):
        self._opcode = 9
        self._opname = "NOP"
        self._arg = None
        self._argval = None
        self._argrepr = ""
        self._offset = 0
        self._starts_line = None
        self._is_jump_target = False
        self._positions = None
    
    def opcode(self, opcode):
        self._opcode = opcode
        return self
    
    def opname(self, opname):
        self._opname = opname
        return self
    
    def arg(self, arg):
        self._arg = arg
        return self
    
    def argval(self, argval):
        self._argval = argval
        return self
    
    def argrepr(self, argrepr):
        self._argrepr = argrepr
        return self
    
    def offset(self, offset):
        self._offset = offset
        return self
    
    def starts_line(self, line):
        self._starts_line = line
        return self
    
    def jump_target(self, is_target=True):
        self._is_jump_target = is_target
        return self
    
    def positions(self, positions):
        self._positions = positions
        return self
    
    def build(self):
        return Instruction(
            opcode=self._opcode,
            opname=self._opname,
            arg=self._arg,
            argval=self._argval,
            argrepr=self._argrepr,
            offset=self._offset,
            starts_line=self._starts_line,
            is_jump_target=self._is_jump_target,
            positions=self._positions
        )

class InstructionSequence:
    
    def __init__(self, instructions=None):
        self._instructions = list(instructions) if instructions else []
        self._offset_map = {}
        self._rebuild_map()
    
    def _rebuild_map(self):
        self._offset_map.clear()
        for i, instr in enumerate(self._instructions):
            self._offset_map[instr.offset] = i
    
    def __len__(self):
        return len(self._instructions)
    
    def __getitem__(self, index):
        return self._instructions[index]
    
    def __setitem__(self, index, instruction):
        old_offset = self._instructions[index].offset
        self._instructions[index] = instruction
        if old_offset in self._offset_map:
            del self._offset_map[old_offset]
        self._offset_map[instruction.offset] = index
    
    def __delitem__(self, index):
        offset = self._instructions[index].offset
        del self._instructions[index]
        if offset in self._offset_map:
            del self._offset_map[offset]
        self._rebuild_map()
    
    def __iter__(self):
        return iter(self._instructions)
    
    def append(self, instruction):
        self._offset_map[instruction.offset] = len(self._instructions)
        self._instructions.append(instruction)
    
    def insert(self, index, instruction):
        self._instructions.insert(index, instruction)
        self._rebuild_map()
    
    def remove(self, instruction):
        self._instructions.remove(instruction)
        self._rebuild_map()
    
    def pop(self, index=-1):
        instr = self._instructions.pop(index)
        self._rebuild_map()
        return instr
    
    def clear(self):
        self._instructions.clear()
        self._offset_map.clear()
    
    def get_by_offset(self, offset):
        index = self._offset_map.get(offset)
        if index is not None:
            return self._instructions[index]
        return None
    
    def index_of_offset(self, offset):
        return self._offset_map.get(offset, -1)
    
    def recalculate_offsets(self):
        current_offset = 0
        for instr in self._instructions:
            instr.offset = current_offset
            current_offset += instr.size
        self._rebuild_map()
    
    def copy(self):
        return InstructionSequence([instr.copy() for instr in self._instructions])
    
    def slice(self, start, end=None):
        if end is None:
            return InstructionSequence(self._instructions[start:])
        return InstructionSequence(self._instructions[start:end])
    
    def find(self, predicate):
        for instr in self._instructions:
            if predicate(instr):
                return instr
        return None
    
    def find_all(self, predicate):
        return [instr for instr in self._instructions if predicate(instr)]
    
    def find_by_opcode(self, opcode):
        return self.find_all(lambda i: i.opcode == opcode)
    
    def find_by_opname(self, opname):
        return self.find_all(lambda i: i.opname == opname)

class Label:
    
    _counter = 0
    
    def __init__(self, name=None):
        if name is None:
            Label._counter += 1
            name = "L{}".format(Label._counter)
        self.name = name
        self.offset = None
        self.references = []
    
    def bind(self, offset):
        self.offset = offset
    
    def add_reference(self, instruction):
        self.references.append(instruction)
    
    def is_bound(self):
        return self.offset is not None
    
    def __repr__(self):
        return "Label({!r}, offset={})".format(self.name, self.offset)

class LabelManager:
    
    def __init__(self):
        self._labels = {}
        self._pending = []
    
    def create_label(self, name=None):
        label = Label(name)
        if label.name in self._labels:
            raise ValueError("Label already exists: {}".format(label.name))
        self._labels[label.name] = label
        return label
    
    def get_label(self, name):
        return self._labels.get(name)
    
    def bind_label(self, label, offset):
        label.bind(offset)
    
    def add_pending_reference(self, label, instruction):
        label.add_reference(instruction)
        self._pending.append((label, instruction))
    
    def resolve_all(self):
        for label, instruction in self._pending:
            if label.is_bound():
                instruction.arg = label.offset
                instruction.argval = label.offset
            else:
                raise ValueError("Unbound label: {}".format(label.name))
        self._pending.clear()
    
    def all_labels(self):
        return list(self._labels.values())
    
    def bound_labels(self):
        return [l for l in self._labels.values() if l.is_bound()]
    
    def unbound_labels(self):
        return [l for l in self._labels.values() if not l.is_bound()]

class InstructionFactory:
    
    _opcode_table = None
    
    @classmethod
    def _init_table(cls):
        if cls._opcode_table is not None:
            return
        import dis
        cls._opcode_table = {}
        for name, code in dis.opmap.items():
            cls._opcode_table[name] = code
            cls._opcode_table[code] = name
    
    @classmethod
    def create(cls, opname, arg=None, argval=None, argrepr="", offset=0):
        cls._init_table()
        opcode = cls._opcode_table.get(opname, 9)
        return Instruction(
            opcode=opcode,
            opname=opname,
            arg=arg,
            argval=argval,
            argrepr=argrepr,
            offset=offset
        )
    
    @classmethod
    def create_from_opcode(cls, opcode, arg=None, argval=None, argrepr="", offset=0):
        cls._init_table()
        opname = cls._opcode_table.get(opcode, "UNKNOWN")
        return Instruction(
            opcode=opcode,
            opname=opname,
            arg=arg,
            argval=argval,
            argrepr=argrepr,
            offset=offset
        )
    
    @classmethod
    def nop(cls, offset=0):
        return cls.create("NOP", offset=offset)
    
    @classmethod
    def load_const(cls, const_index, const_value=None, offset=0):
        argrepr = repr(const_value) if const_value is not None else ""
        return cls.create("LOAD_CONST", arg=const_index, argval=const_value, 
                         argrepr=argrepr, offset=offset)
    
    @classmethod
    def load_fast(cls, var_index, var_name=None, offset=0):
        return cls.create("LOAD_FAST", arg=var_index, argval=var_name,
                         argrepr=var_name or "", offset=offset)
    
    @classmethod
    def store_fast(cls, var_index, var_name=None, offset=0):
        return cls.create("STORE_FAST", arg=var_index, argval=var_name,
                         argrepr=var_name or "", offset=offset)
    
    @classmethod
    def load_global(cls, name_index, name=None, offset=0):
        return cls.create("LOAD_GLOBAL", arg=name_index, argval=name,
                         argrepr=name or "", offset=offset)
    
    @classmethod
    def store_global(cls, name_index, name=None, offset=0):
        return cls.create("STORE_GLOBAL", arg=name_index, argval=name,
                         argrepr=name or "", offset=offset)
    
    @classmethod
    def return_value(cls, offset=0):
        return cls.create("RETURN_VALUE", offset=offset)
    
    @classmethod
    def pop_top(cls, offset=0):
        return cls.create("POP_TOP", offset=offset)
    
    @classmethod
    def dup_top(cls, offset=0):
        return cls.create("DUP_TOP", offset=offset)
    
    @classmethod
    def binary_add(cls, offset=0):
        return cls.create("BINARY_ADD", offset=offset)
    
    @classmethod
    def binary_subtract(cls, offset=0):
        return cls.create("BINARY_SUBTRACT", offset=offset)
    
    @classmethod
    def binary_multiply(cls, offset=0):
        return cls.create("BINARY_MULTIPLY", offset=offset)
    
    @classmethod
    def compare_op(cls, op_index, op_name="", offset=0):
        return cls.create("COMPARE_OP", arg=op_index, argval=op_name,
                         argrepr=op_name, offset=offset)
    
    @classmethod
    def jump_absolute(cls, target, offset=0):
        return cls.create("JUMP_ABSOLUTE", arg=target, argval=target,
                         argrepr="to {}".format(target), offset=offset)
    
    @classmethod
    def jump_forward(cls, delta, offset=0):
        return cls.create("JUMP_FORWARD", arg=delta, argval=offset + delta + 2,
                         argrepr="to {}".format(offset + delta + 2), offset=offset)
    
    @classmethod
    def pop_jump_if_false(cls, target, offset=0):
        return cls.create("POP_JUMP_IF_FALSE", arg=target, argval=target,
                         argrepr="to {}".format(target), offset=offset)
    
    @classmethod
    def pop_jump_if_true(cls, target, offset=0):
        return cls.create("POP_JUMP_IF_TRUE", arg=target, argval=target,
                         argrepr="to {}".format(target), offset=offset)
    
    @classmethod
    def call_function(cls, argc, offset=0):
        return cls.create("CALL_FUNCTION", arg=argc, argval=argc,
                         argrepr="{} positional".format(argc), offset=offset)
    
    @classmethod
    def build_tuple(cls, count, offset=0):
        return cls.create("BUILD_TUPLE", arg=count, argval=count, offset=offset)
    
    @classmethod
    def build_list(cls, count, offset=0):
        return cls.create("BUILD_LIST", arg=count, argval=count, offset=offset)
    
    @classmethod
    def build_map(cls, count, offset=0):
        return cls.create("BUILD_MAP", arg=count, argval=count, offset=offset)

def create_instruction(opname, **kwargs):
    return InstructionFactory.create(opname, **kwargs)

def create_instruction_sequence(instructions):
    return InstructionSequence(instructions)

def instruction_from_tuple(tup):
    return Instruction(
        opcode=tup[0],
        opname=tup[1],
        arg=tup[2] if len(tup) > 2 else None,
        argval=tup[3] if len(tup) > 3 else None,
        argrepr=tup[4] if len(tup) > 4 else "",
        offset=tup[5] if len(tup) > 5 else 0
    )
