import sys
import struct
from enum import IntEnum
from typing import Dict, List, Optional, Tuple, Any, Set, Union

__author__ = "mero"
__version__ = "1.0.0"

PYTHON_VERSION = sys.version_info[:2]

class OpcodeCategory(IntEnum):
    GENERAL = 0
    UNARY = 1
    BINARY = 2
    INPLACE = 3
    COMPARE = 4
    LOAD = 5
    STORE = 6
    DELETE = 7
    CONTROL = 8
    FUNCTION = 9
    IMPORT = 10
    BUILD = 11
    MISC = 12
    ASYNC = 13

class OpcodeFlags:
    HAS_ARG = 1
    HAS_CONST = 2
    HAS_NAME = 4
    HAS_JREL = 8
    HAS_JABS = 16
    HAS_LOCAL = 32
    HAS_FREE = 64
    HAS_COMPARE = 128
    
    def __init__(self, flags=0):
        self._flags = flags
    
    @property
    def has_arg(self):
        return bool(self._flags & self.HAS_ARG)
    
    @property
    def has_const(self):
        return bool(self._flags & self.HAS_CONST)
    
    @property
    def has_name(self):
        return bool(self._flags & self.HAS_NAME)
    
    @property
    def has_jrel(self):
        return bool(self._flags & self.HAS_JREL)
    
    @property
    def has_jabs(self):
        return bool(self._flags & self.HAS_JABS)
    
    @property
    def has_local(self):
        return bool(self._flags & self.HAS_LOCAL)
    
    @property
    def has_free(self):
        return bool(self._flags & self.HAS_FREE)
    
    @property
    def has_compare(self):
        return bool(self._flags & self.HAS_COMPARE)
    
    def is_jump(self):
        return self.has_jrel or self.has_jabs

class OpcodeInfo:
    
    def __init__(self, opcode, name, arg_count=0, stack_effect=None, category=OpcodeCategory.GENERAL, flags=0):
        self.opcode = opcode
        self.name = name
        self.arg_count = arg_count
        self._stack_effect = stack_effect
        self.category = category
        self.flags = OpcodeFlags(flags)
    
    @property
    def has_arg(self):
        return self.opcode >= 90
    
    def stack_effect(self, arg=0, jump=None):
        if self._stack_effect is not None:
            if callable(self._stack_effect):
                return self._stack_effect(arg, jump)
            return self._stack_effect
        return 0
    
    def __repr__(self):
        return "OpcodeInfo(opcode={}, name={!r})".format(self.opcode, self.name)

OPCODE_MAP = {}
OPNAME_MAP = {}

def _register_opcode(opcode, name, stack_effect=None, category=OpcodeCategory.GENERAL, flags=0):
    info = OpcodeInfo(opcode, name, 0, stack_effect, category, flags)
    OPCODE_MAP[opcode] = info
    OPNAME_MAP[name] = info
    return info

_register_opcode(1, "POP_TOP", -1, OpcodeCategory.GENERAL)
_register_opcode(2, "ROT_TWO", 0, OpcodeCategory.GENERAL)
_register_opcode(3, "ROT_THREE", 0, OpcodeCategory.GENERAL)
_register_opcode(4, "DUP_TOP", 1, OpcodeCategory.GENERAL)
_register_opcode(5, "DUP_TOP_TWO", 2, OpcodeCategory.GENERAL)
_register_opcode(6, "ROT_FOUR", 0, OpcodeCategory.GENERAL)
_register_opcode(9, "NOP", 0, OpcodeCategory.GENERAL)
_register_opcode(10, "UNARY_POSITIVE", 0, OpcodeCategory.UNARY)
_register_opcode(11, "UNARY_NEGATIVE", 0, OpcodeCategory.UNARY)
_register_opcode(12, "UNARY_NOT", 0, OpcodeCategory.UNARY)
_register_opcode(15, "UNARY_INVERT", 0, OpcodeCategory.UNARY)
_register_opcode(16, "BINARY_MATRIX_MULTIPLY", -1, OpcodeCategory.BINARY)
_register_opcode(17, "INPLACE_MATRIX_MULTIPLY", -1, OpcodeCategory.INPLACE)
_register_opcode(19, "BINARY_POWER", -1, OpcodeCategory.BINARY)
_register_opcode(20, "BINARY_MULTIPLY", -1, OpcodeCategory.BINARY)
_register_opcode(22, "BINARY_MODULO", -1, OpcodeCategory.BINARY)
_register_opcode(23, "BINARY_ADD", -1, OpcodeCategory.BINARY)
_register_opcode(24, "BINARY_SUBTRACT", -1, OpcodeCategory.BINARY)
_register_opcode(25, "BINARY_SUBSCR", -1, OpcodeCategory.BINARY)
_register_opcode(26, "BINARY_FLOOR_DIVIDE", -1, OpcodeCategory.BINARY)
_register_opcode(27, "BINARY_TRUE_DIVIDE", -1, OpcodeCategory.BINARY)
_register_opcode(28, "INPLACE_FLOOR_DIVIDE", -1, OpcodeCategory.INPLACE)
_register_opcode(29, "INPLACE_TRUE_DIVIDE", -1, OpcodeCategory.INPLACE)
_register_opcode(50, "GET_AITER", 0, OpcodeCategory.ASYNC)
_register_opcode(51, "GET_ANEXT", 1, OpcodeCategory.ASYNC)
_register_opcode(52, "BEFORE_ASYNC_WITH", 1, OpcodeCategory.ASYNC)
_register_opcode(54, "END_ASYNC_FOR", -7, OpcodeCategory.ASYNC)
_register_opcode(55, "INPLACE_ADD", -1, OpcodeCategory.INPLACE)
_register_opcode(56, "INPLACE_SUBTRACT", -1, OpcodeCategory.INPLACE)
_register_opcode(57, "INPLACE_MULTIPLY", -1, OpcodeCategory.INPLACE)
_register_opcode(59, "INPLACE_MODULO", -1, OpcodeCategory.INPLACE)
_register_opcode(60, "STORE_SUBSCR", -3, OpcodeCategory.STORE)
_register_opcode(61, "DELETE_SUBSCR", -2, OpcodeCategory.DELETE)
_register_opcode(62, "BINARY_LSHIFT", -1, OpcodeCategory.BINARY)
_register_opcode(63, "BINARY_RSHIFT", -1, OpcodeCategory.BINARY)
_register_opcode(64, "BINARY_AND", -1, OpcodeCategory.BINARY)
_register_opcode(65, "BINARY_XOR", -1, OpcodeCategory.BINARY)
_register_opcode(66, "BINARY_OR", -1, OpcodeCategory.BINARY)
_register_opcode(67, "INPLACE_POWER", -1, OpcodeCategory.INPLACE)
_register_opcode(68, "GET_ITER", 0, OpcodeCategory.GENERAL)
_register_opcode(69, "GET_YIELD_FROM_ITER", 0, OpcodeCategory.GENERAL)
_register_opcode(70, "PRINT_EXPR", -1, OpcodeCategory.GENERAL)
_register_opcode(71, "LOAD_BUILD_CLASS", 1, OpcodeCategory.LOAD)
_register_opcode(72, "YIELD_FROM", -1, OpcodeCategory.GENERAL)
_register_opcode(73, "GET_AWAITABLE", 0, OpcodeCategory.ASYNC)
_register_opcode(74, "LOAD_ASSERTION_ERROR", 1, OpcodeCategory.LOAD)
_register_opcode(75, "INPLACE_LSHIFT", -1, OpcodeCategory.INPLACE)
_register_opcode(76, "INPLACE_RSHIFT", -1, OpcodeCategory.INPLACE)
_register_opcode(77, "INPLACE_AND", -1, OpcodeCategory.INPLACE)
_register_opcode(78, "INPLACE_XOR", -1, OpcodeCategory.INPLACE)
_register_opcode(79, "INPLACE_OR", -1, OpcodeCategory.INPLACE)
_register_opcode(82, "LIST_TO_TUPLE", 0, OpcodeCategory.BUILD)
_register_opcode(83, "RETURN_VALUE", -1, OpcodeCategory.CONTROL)
_register_opcode(84, "IMPORT_STAR", -1, OpcodeCategory.IMPORT)
_register_opcode(85, "SETUP_ANNOTATIONS", 0, OpcodeCategory.GENERAL)
_register_opcode(86, "YIELD_VALUE", 0, OpcodeCategory.GENERAL)
_register_opcode(87, "POP_BLOCK", 0, OpcodeCategory.CONTROL)
_register_opcode(88, "END_FINALLY", -6, OpcodeCategory.CONTROL)
_register_opcode(89, "POP_EXCEPT", -3, OpcodeCategory.CONTROL)

_register_opcode(90, "STORE_NAME", -1, OpcodeCategory.STORE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(91, "DELETE_NAME", 0, OpcodeCategory.DELETE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(92, "UNPACK_SEQUENCE", lambda arg, _: arg - 1, OpcodeCategory.GENERAL, OpcodeFlags.HAS_ARG)
_register_opcode(93, "FOR_ITER", lambda arg, jump: -1 if jump else 1, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JREL)
_register_opcode(94, "UNPACK_EX", lambda arg, _: (arg & 0xFF) + (arg >> 8), OpcodeCategory.GENERAL, OpcodeFlags.HAS_ARG)
_register_opcode(95, "STORE_ATTR", -2, OpcodeCategory.STORE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(96, "DELETE_ATTR", -1, OpcodeCategory.DELETE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(97, "STORE_GLOBAL", -1, OpcodeCategory.STORE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(98, "DELETE_GLOBAL", 0, OpcodeCategory.DELETE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(100, "LOAD_CONST", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_CONST)
_register_opcode(101, "LOAD_NAME", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(102, "BUILD_TUPLE", lambda arg, _: 1 - arg, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(103, "BUILD_LIST", lambda arg, _: 1 - arg, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(104, "BUILD_SET", lambda arg, _: 1 - arg, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(105, "BUILD_MAP", lambda arg, _: 1 - 2 * arg, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(106, "LOAD_ATTR", 0, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(107, "COMPARE_OP", -1, OpcodeCategory.COMPARE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_COMPARE)
_register_opcode(108, "IMPORT_NAME", -1, OpcodeCategory.IMPORT, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(109, "IMPORT_FROM", 1, OpcodeCategory.IMPORT, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(110, "JUMP_FORWARD", 0, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JREL)
_register_opcode(111, "JUMP_IF_FALSE_OR_POP", lambda arg, jump: 0 if jump else -1, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JABS)
_register_opcode(112, "JUMP_IF_TRUE_OR_POP", lambda arg, jump: 0 if jump else -1, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JABS)
_register_opcode(113, "JUMP_ABSOLUTE", 0, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JABS)
_register_opcode(114, "POP_JUMP_IF_FALSE", -1, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JABS)
_register_opcode(115, "POP_JUMP_IF_TRUE", -1, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JABS)
_register_opcode(116, "LOAD_GLOBAL", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(117, "IS_OP", -1, OpcodeCategory.COMPARE, OpcodeFlags.HAS_ARG)
_register_opcode(118, "CONTAINS_OP", -1, OpcodeCategory.COMPARE, OpcodeFlags.HAS_ARG)
_register_opcode(119, "RERAISE", -3, OpcodeCategory.CONTROL)
_register_opcode(121, "JUMP_IF_NOT_EXC_MATCH", -2, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JABS)
_register_opcode(122, "SETUP_FINALLY", 6, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JREL)
_register_opcode(124, "LOAD_FAST", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_LOCAL)
_register_opcode(125, "STORE_FAST", -1, OpcodeCategory.STORE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_LOCAL)
_register_opcode(126, "DELETE_FAST", 0, OpcodeCategory.DELETE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_LOCAL)
_register_opcode(130, "RAISE_VARARGS", lambda arg, _: -arg, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG)
_register_opcode(131, "CALL_FUNCTION", lambda arg, _: -arg, OpcodeCategory.FUNCTION, OpcodeFlags.HAS_ARG)
_register_opcode(132, "MAKE_FUNCTION", lambda arg, _: -1 - ((arg & 0x01) + (arg & 0x02) + (arg & 0x04) + (arg & 0x08)), OpcodeCategory.FUNCTION, OpcodeFlags.HAS_ARG)
_register_opcode(133, "BUILD_SLICE", lambda arg, _: -2 if arg == 3 else -1, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(135, "LOAD_CLOSURE", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_FREE)
_register_opcode(136, "LOAD_DEREF", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_FREE)
_register_opcode(137, "STORE_DEREF", -1, OpcodeCategory.STORE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_FREE)
_register_opcode(138, "DELETE_DEREF", 0, OpcodeCategory.DELETE, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_FREE)
_register_opcode(141, "CALL_FUNCTION_KW", lambda arg, _: -arg - 1, OpcodeCategory.FUNCTION, OpcodeFlags.HAS_ARG)
_register_opcode(142, "CALL_FUNCTION_EX", lambda arg, _: -1 - ((arg & 0x01) != 0), OpcodeCategory.FUNCTION, OpcodeFlags.HAS_ARG)
_register_opcode(143, "SETUP_WITH", 6, OpcodeCategory.CONTROL, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JREL)
_register_opcode(144, "EXTENDED_ARG", 0, OpcodeCategory.GENERAL, OpcodeFlags.HAS_ARG)
_register_opcode(145, "LIST_APPEND", -1, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(146, "SET_ADD", -1, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(147, "MAP_ADD", -2, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(148, "LOAD_CLASSDEREF", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_FREE)
_register_opcode(154, "SETUP_ASYNC_WITH", 6, OpcodeCategory.ASYNC, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_JREL)
_register_opcode(155, "FORMAT_VALUE", lambda arg, _: -1 if (arg & 0x04) else 0, OpcodeCategory.GENERAL, OpcodeFlags.HAS_ARG)
_register_opcode(156, "BUILD_CONST_KEY_MAP", lambda arg, _: -arg, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(157, "BUILD_STRING", lambda arg, _: 1 - arg, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(160, "LOAD_METHOD", 1, OpcodeCategory.LOAD, OpcodeFlags.HAS_ARG | OpcodeFlags.HAS_NAME)
_register_opcode(161, "CALL_METHOD", lambda arg, _: -arg - 1, OpcodeCategory.FUNCTION, OpcodeFlags.HAS_ARG)
_register_opcode(162, "LIST_EXTEND", -1, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(163, "SET_UPDATE", -1, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(164, "DICT_MERGE", -1, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)
_register_opcode(165, "DICT_UPDATE", -1, OpcodeCategory.BUILD, OpcodeFlags.HAS_ARG)

COMPARE_OPS = ("<", "<=", "==", "!=", ">", ">=")

class OpcodeRegistry:
    
    def __init__(self):
        self._opcodes = dict(OPCODE_MAP)
        self._opnames = dict(OPNAME_MAP)
        self._custom_opcodes = {}
    
    def get_by_code(self, opcode):
        return self._opcodes.get(opcode)
    
    def get_by_name(self, name):
        return self._opnames.get(name)
    
    def register_custom(self, opcode, name, stack_effect=None, category=OpcodeCategory.GENERAL, flags=0):
        info = OpcodeInfo(opcode, name, 0, stack_effect, category, flags)
        self._custom_opcodes[opcode] = info
        self._opcodes[opcode] = info
        self._opnames[name] = info
        return info
    
    def unregister_custom(self, opcode):
        if opcode in self._custom_opcodes:
            info = self._custom_opcodes.pop(opcode)
            del self._opcodes[opcode]
            del self._opnames[info.name]
            return True
        return False
    
    def all_opcodes(self):
        return list(self._opcodes.values())
    
    def standard_opcodes(self):
        return [info for code, info in self._opcodes.items() if code not in self._custom_opcodes]
    
    def custom_opcodes(self):
        return list(self._custom_opcodes.values())
    
    def is_valid(self, opcode):
        return opcode in self._opcodes
    
    def is_custom(self, opcode):
        return opcode in self._custom_opcodes

class OpcodeEncoder:
    
    def __init__(self, registry=None):
        self.registry = registry or OpcodeRegistry()
    
    def encode_instruction(self, opcode, arg=0):
        if PYTHON_VERSION >= (3, 6):
            return self._encode_wordcode(opcode, arg)
        return self._encode_legacy(opcode, arg)
    
    def _encode_wordcode(self, opcode, arg):
        result = bytearray()
        if arg > 0xFFFFFF:
            result.extend([144, (arg >> 24) & 0xFF])
            result.extend([144, (arg >> 16) & 0xFF])
            result.extend([144, (arg >> 8) & 0xFF])
            result.extend([opcode, arg & 0xFF])
        elif arg > 0xFFFF:
            result.extend([144, (arg >> 16) & 0xFF])
            result.extend([144, (arg >> 8) & 0xFF])
            result.extend([opcode, arg & 0xFF])
        elif arg > 0xFF:
            result.extend([144, (arg >> 8) & 0xFF])
            result.extend([opcode, arg & 0xFF])
        else:
            result.extend([opcode, arg & 0xFF])
        return bytes(result)
    
    def _encode_legacy(self, opcode, arg):
        result = bytearray()
        if opcode >= 90:
            if arg > 0xFFFF:
                result.extend([144, (arg >> 16) & 0xFF, (arg >> 24) & 0xFF])
            result.extend([opcode, arg & 0xFF, (arg >> 8) & 0xFF])
        else:
            result.append(opcode)
        return bytes(result)

class OpcodeDecoder:
    
    def __init__(self, registry=None):
        self.registry = registry or OpcodeRegistry()
    
    def decode_instruction(self, bytecode, offset=0):
        if PYTHON_VERSION >= (3, 6):
            return self._decode_wordcode(bytecode, offset)
        return self._decode_legacy(bytecode, offset)
    
    def _decode_wordcode(self, bytecode, offset):
        extended_arg = 0
        pos = offset
        while pos < len(bytecode):
            op = bytecode[pos]
            arg = bytecode[pos + 1] if pos + 1 < len(bytecode) else 0
            if op == 144:
                extended_arg = (extended_arg | arg) << 8
                pos += 2
            else:
                arg = extended_arg | arg
                return (op, arg, pos + 2 - offset)
        return None
    
    def _decode_legacy(self, bytecode, offset):
        if offset >= len(bytecode):
            return None
        op = bytecode[offset]
        if op >= 90:
            if offset + 2 >= len(bytecode):
                return None
            arg = bytecode[offset + 1] | (bytecode[offset + 2] << 8)
            return (op, arg, 3)
        return (op, 0, 1)

def get_opcode_info(opcode):
    return OPCODE_MAP.get(opcode)

def get_opcode_by_name(name):
    info = OPNAME_MAP.get(name)
    return info.opcode if info else None

def is_jump_opcode(opcode):
    info = OPCODE_MAP.get(opcode)
    if info:
        return info.flags.is_jump()
    return False

def is_relative_jump(opcode):
    info = OPCODE_MAP.get(opcode)
    if info:
        return info.flags.has_jrel
    return False

def is_absolute_jump(opcode):
    info = OPCODE_MAP.get(opcode)
    if info:
        return info.flags.has_jabs
    return False

def get_stack_effect(opcode, arg=0, jump=None):
    info = OPCODE_MAP.get(opcode)
    if info:
        return info.stack_effect(arg, jump)
    return 0

def has_argument(opcode):
    return opcode >= 90

def list_all_opcodes():
    return sorted(OPCODE_MAP.keys())

def list_opcodes_by_category(category):
    return [info for info in OPCODE_MAP.values() if info.category == category]
