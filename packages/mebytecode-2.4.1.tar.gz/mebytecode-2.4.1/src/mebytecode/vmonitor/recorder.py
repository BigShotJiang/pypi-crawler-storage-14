__author__ = "mero"
__version__ = "1.0.0"

import sys
import os
import time
import threading
import json
import pickle
import gzip
from collections import OrderedDict


class RecordType:
    EVENT = "event"
    CALL = "call"
    RETURN = "return"
    EXCEPTION = "exception"
    STATE = "state"
    METRIC = "metric"
    LOG = "log"
    CUSTOM = "custom"


class Record:
    
    def __init__(self, record_type, data, timestamp=None, metadata=None):
        self.record_type = record_type
        self.data = data
        self.timestamp = timestamp if timestamp is not None else time.time()
        self.metadata = metadata if metadata is not None else {}
        self.sequence_number = 0
    
    def to_dict(self):
        return {
            "record_type": self.record_type,
            "data": self.data,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
            "sequence_number": self.sequence_number
        }
    
    @classmethod
    def from_dict(cls, d):
        record = cls(
            d["record_type"],
            d["data"],
            d["timestamp"],
            d.get("metadata", {})
        )
        record.sequence_number = d.get("sequence_number", 0)
        return record
    
    def __repr__(self):
        return "Record(type=%s, seq=%d, ts=%.3f)" % (
            self.record_type,
            self.sequence_number,
            self.timestamp
        )


class RecordBuffer:
    
    def __init__(self, max_size=10000, overflow_strategy="drop_oldest"):
        self._buffer = []
        self._max_size = max_size
        self._overflow_strategy = overflow_strategy
        self._lock = threading.Lock()
        self._sequence = 0
        self._dropped_count = 0
    
    def append(self, record):
        with self._lock:
            record.sequence_number = self._sequence
            self._sequence += 1
            if len(self._buffer) >= self._max_size:
                if self._overflow_strategy == "drop_oldest":
                    self._buffer.pop(0)
                    self._dropped_count += 1
                elif self._overflow_strategy == "drop_newest":
                    self._dropped_count += 1
                    return False
            self._buffer.append(record)
            return True
    
    def get_all(self):
        with self._lock:
            return list(self._buffer)
    
    def get_range(self, start_seq, end_seq):
        with self._lock:
            return [r for r in self._buffer if start_seq <= r.sequence_number <= end_seq]
    
    def get_by_type(self, record_type):
        with self._lock:
            return [r for r in self._buffer if r.record_type == record_type]
    
    def get_by_time_range(self, start_time, end_time):
        with self._lock:
            return [r for r in self._buffer if start_time <= r.timestamp <= end_time]
    
    def size(self):
        with self._lock:
            return len(self._buffer)
    
    def clear(self):
        with self._lock:
            self._buffer.clear()
            self._dropped_count = 0
    
    def get_dropped_count(self):
        return self._dropped_count


class RecordWriter:
    
    def __init__(self, output_path, format_type="json", compress=False):
        self._output_path = output_path
        self._format_type = format_type
        self._compress = compress
        self._lock = threading.Lock()
        self._file_handle = None
        self._records_written = 0
    
    def open(self):
        with self._lock:
            if self._file_handle is not None:
                return False
            mode = "wb" if self._format_type == "pickle" else "w"
            if self._compress:
                self._file_handle = gzip.open(self._output_path + ".gz", mode + "t")
            else:
                self._file_handle = open(self._output_path, mode)
            return True
    
    def close(self):
        with self._lock:
            if self._file_handle is not None:
                self._file_handle.close()
                self._file_handle = None
                return True
            return False
    
    def write(self, record):
        with self._lock:
            if self._file_handle is None:
                return False
            try:
                if self._format_type == "json":
                    self._file_handle.write(json.dumps(record.to_dict()) + "\n")
                elif self._format_type == "pickle":
                    pickle.dump(record.to_dict(), self._file_handle)
                else:
                    self._file_handle.write(str(record.to_dict()) + "\n")
                self._records_written += 1
                return True
            except Exception:
                return False
    
    def write_batch(self, records):
        count = 0
        for record in records:
            if self.write(record):
                count += 1
        return count
    
    def flush(self):
        with self._lock:
            if self._file_handle is not None:
                self._file_handle.flush()
    
    def get_records_written(self):
        return self._records_written


class RecordReader:
    
    def __init__(self, input_path, format_type="json", compressed=False):
        self._input_path = input_path
        self._format_type = format_type
        self._compressed = compressed
        self._file_handle = None
        self._records_read = 0
    
    def open(self):
        if self._file_handle is not None:
            return False
        path = self._input_path
        if self._compressed and not path.endswith(".gz"):
            path = path + ".gz"
        mode = "rb" if self._format_type == "pickle" else "r"
        if self._compressed:
            self._file_handle = gzip.open(path, mode + "t")
        else:
            self._file_handle = open(path, mode)
        return True
    
    def close(self):
        if self._file_handle is not None:
            self._file_handle.close()
            self._file_handle = None
            return True
        return False
    
    def read_one(self):
        if self._file_handle is None:
            return None
        try:
            if self._format_type == "json":
                line = self._file_handle.readline()
                if not line:
                    return None
                data = json.loads(line)
            elif self._format_type == "pickle":
                data = pickle.load(self._file_handle)
            else:
                line = self._file_handle.readline()
                if not line:
                    return None
                data = eval(line)
            self._records_read += 1
            return Record.from_dict(data)
        except Exception:
            return None
    
    def read_all(self):
        records = []
        while True:
            record = self.read_one()
            if record is None:
                break
            records.append(record)
        return records
    
    def get_records_read(self):
        return self._records_read


class ActivityRecorder:
    
    def __init__(self, buffer_size=10000, auto_flush=True, flush_interval=10.0):
        self._buffer = RecordBuffer(buffer_size)
        self._auto_flush = auto_flush
        self._flush_interval = flush_interval
        self._writer = None
        self._lock = threading.RLock()
        self._active = False
        self._flush_thread = None
        self._start_time = None
        self._filters = []
        self._transformers = []
        self._callbacks = []
    
    def start(self, output_path=None, format_type="json", compress=False):
        with self._lock:
            if self._active:
                return False
            self._active = True
            self._start_time = time.time()
            if output_path is not None:
                self._writer = RecordWriter(output_path, format_type, compress)
                self._writer.open()
            if self._auto_flush and self._writer is not None:
                self._flush_thread = threading.Thread(target=self._auto_flush_worker)
                self._flush_thread.daemon = True
                self._flush_thread.start()
            return True
    
    def stop(self):
        with self._lock:
            if not self._active:
                return False
            self._active = False
            if self._writer is not None:
                self.flush()
                self._writer.close()
                self._writer = None
            return True
    
    def record(self, record_type, data, metadata=None):
        if not self._active:
            return False
        record = Record(record_type, data, metadata=metadata)
        for filter_func in self._filters:
            if not filter_func(record):
                return False
        for transformer in self._transformers:
            record = transformer(record)
        self._buffer.append(record)
        for callback in self._callbacks:
            try:
                callback(record)
            except Exception:
                pass
        return True
    
    def record_event(self, event_name, data=None):
        return self.record(RecordType.EVENT, {"event": event_name, "data": data})
    
    def record_call(self, function_name, args=None, kwargs=None):
        return self.record(RecordType.CALL, {
            "function": function_name,
            "args": repr(args) if args else None,
            "kwargs": repr(kwargs) if kwargs else None
        })
    
    def record_return(self, function_name, return_value):
        return self.record(RecordType.RETURN, {
            "function": function_name,
            "return_value": repr(return_value)
        })
    
    def record_exception(self, exception, context=None):
        return self.record(RecordType.EXCEPTION, {
            "exception_type": type(exception).__name__,
            "message": str(exception),
            "context": context
        })
    
    def record_state(self, state_name, state_data):
        return self.record(RecordType.STATE, {
            "state": state_name,
            "data": state_data
        })
    
    def record_metric(self, metric_name, value, unit=None):
        return self.record(RecordType.METRIC, {
            "metric": metric_name,
            "value": value,
            "unit": unit
        })
    
    def record_log(self, level, message, extra=None):
        return self.record(RecordType.LOG, {
            "level": level,
            "message": message,
            "extra": extra
        })
    
    def add_filter(self, filter_func):
        self._filters.append(filter_func)
    
    def add_transformer(self, transformer):
        self._transformers.append(transformer)
    
    def add_callback(self, callback):
        self._callbacks.append(callback)
    
    def flush(self):
        with self._lock:
            if self._writer is None:
                return 0
            records = self._buffer.get_all()
            count = self._writer.write_batch(records)
            self._writer.flush()
            self._buffer.clear()
            return count
    
    def _auto_flush_worker(self):
        while self._active:
            time.sleep(self._flush_interval)
            if self._active:
                self.flush()
    
    def get_records(self, record_type=None):
        if record_type is not None:
            return self._buffer.get_by_type(record_type)
        return self._buffer.get_all()
    
    def get_stats(self):
        return {
            "buffer_size": self._buffer.size(),
            "dropped_count": self._buffer.get_dropped_count(),
            "records_written": self._writer.get_records_written() if self._writer else 0,
            "uptime": time.time() - self._start_time if self._start_time else 0
        }


class SessionRecorder:
    
    def __init__(self, session_id=None):
        self._session_id = session_id or "session_%d" % int(time.time() * 1000)
        self._recorder = ActivityRecorder()
        self._snapshots = []
        self._checkpoints = []
    
    def start(self, output_dir=None):
        if output_dir is not None:
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            output_path = os.path.join(output_dir, self._session_id + ".record")
            return self._recorder.start(output_path)
        return self._recorder.start()
    
    def stop(self):
        return self._recorder.stop()
    
    def record(self, record_type, data, metadata=None):
        if metadata is None:
            metadata = {}
        metadata["session_id"] = self._session_id
        return self._recorder.record(record_type, data, metadata)
    
    def create_snapshot(self, name, data):
        snapshot = {
            "name": name,
            "timestamp": time.time(),
            "data": data
        }
        self._snapshots.append(snapshot)
        self.record("snapshot", snapshot)
        return len(self._snapshots) - 1
    
    def create_checkpoint(self, name):
        checkpoint = {
            "name": name,
            "timestamp": time.time(),
            "sequence": self._recorder._buffer._sequence
        }
        self._checkpoints.append(checkpoint)
        self.record("checkpoint", checkpoint)
        return len(self._checkpoints) - 1
    
    def get_snapshots(self):
        return list(self._snapshots)
    
    def get_checkpoints(self):
        return list(self._checkpoints)
    
    def get_session_id(self):
        return self._session_id


_default_recorder = None


def get_recorder():
    global _default_recorder
    if _default_recorder is None:
        _default_recorder = ActivityRecorder()
    return _default_recorder


def start_recording(output_path=None):
    return get_recorder().start(output_path)


def stop_recording():
    return get_recorder().stop()


def record_event(event_name, data=None):
    return get_recorder().record_event(event_name, data)


def record_call(function_name, args=None, kwargs=None):
    return get_recorder().record_call(function_name, args, kwargs)


def record_exception(exception, context=None):
    return get_recorder().record_exception(exception, context)


def recorded(func):
    def wrapper(*args, **kwargs):
        recorder = get_recorder()
        recorder.record_call(func.__name__, args, kwargs)
        try:
            result = func(*args, **kwargs)
            recorder.record_return(func.__name__, result)
            return result
        except Exception as e:
            recorder.record_exception(e, func.__name__)
            raise
    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper
