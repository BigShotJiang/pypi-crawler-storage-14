__author__ = "mero"
__version__ = "1.0.0"

import sys
import os
import time
import threading
import weakref
import gc
import atexit
from collections import OrderedDict


class MonitorState:
    IDLE = 0
    RUNNING = 1
    PAUSED = 2
    STOPPED = 3
    ERROR = 4


class MonitorEvent:
    
    def __init__(self, event_type, source, data=None, timestamp=None):
        self.event_type = event_type
        self.source = source
        self.data = data if data is not None else {}
        self.timestamp = timestamp if timestamp is not None else time.time()
        self.processed = False
        self.handlers_called = 0
    
    def mark_processed(self):
        self.processed = True
    
    def to_dict(self):
        return {
            "event_type": self.event_type,
            "source": self.source,
            "data": self.data,
            "timestamp": self.timestamp,
            "processed": self.processed
        }


class MonitorConfig:
    
    def __init__(self):
        self.enabled = True
        self.auto_start = False
        self.buffer_size = 10000
        self.flush_interval = 5.0
        self.max_memory_usage = 100 * 1024 * 1024
        self.thread_safe = True
        self.capture_exceptions = True
        self.capture_calls = True
        self.capture_returns = True
        self.capture_memory = False
        self.output_directory = None
        self.log_level = 1
        self.callbacks = {}
    
    def set_option(self, key, value):
        if hasattr(self, key):
            setattr(self, key, value)
            return True
        return False
    
    def get_option(self, key, default=None):
        return getattr(self, key, default)
    
    def to_dict(self):
        return {
            "enabled": self.enabled,
            "auto_start": self.auto_start,
            "buffer_size": self.buffer_size,
            "flush_interval": self.flush_interval,
            "max_memory_usage": self.max_memory_usage,
            "thread_safe": self.thread_safe,
            "capture_exceptions": self.capture_exceptions,
            "capture_calls": self.capture_calls,
            "capture_returns": self.capture_returns,
            "capture_memory": self.capture_memory,
            "output_directory": self.output_directory,
            "log_level": self.log_level
        }


class MonitorBuffer:
    
    def __init__(self, max_size=10000):
        self._buffer = []
        self._max_size = max_size
        self._lock = threading.Lock()
        self._overflow_count = 0
    
    def append(self, item):
        with self._lock:
            if len(self._buffer) >= self._max_size:
                self._buffer.pop(0)
                self._overflow_count += 1
            self._buffer.append(item)
    
    def get_all(self):
        with self._lock:
            return list(self._buffer)
    
    def clear(self):
        with self._lock:
            self._buffer.clear()
            self._overflow_count = 0
    
    def size(self):
        with self._lock:
            return len(self._buffer)
    
    def get_overflow_count(self):
        return self._overflow_count


class MonitorContext:
    
    def __init__(self, monitor, name=None):
        self._monitor = monitor
        self._name = name or "context_%d" % id(self)
        self._start_time = None
        self._end_time = None
        self._data = {}
    
    def __enter__(self):
        self._start_time = time.time()
        self._monitor._on_context_enter(self)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self._end_time = time.time()
        self._data["duration"] = self._end_time - self._start_time
        if exc_type is not None:
            self._data["exception"] = str(exc_val)
            self._data["exception_type"] = exc_type.__name__
        self._monitor._on_context_exit(self)
        return False
    
    def set_data(self, key, value):
        self._data[key] = value
    
    def get_data(self, key, default=None):
        return self._data.get(key, default)


class Monitor:
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(Monitor, cls).__new__(cls)
        return cls._instance
    
    def __init__(self, config=None):
        if hasattr(self, "_initialized") and self._initialized:
            return
        self._initialized = True
        self._config = config if config is not None else MonitorConfig()
        self._state = MonitorState.IDLE
        self._buffer = MonitorBuffer(self._config.buffer_size)
        self._event_handlers = {}
        self._contexts = weakref.WeakValueDictionary()
        self._start_time = None
        self._stop_time = None
        self._lock = threading.RLock()
        self._thread = None
        self._running = False
        self._stats = {
            "events_processed": 0,
            "events_dropped": 0,
            "errors": 0,
            "contexts_created": 0
        }
        self._original_trace = None
        self._watchers = []
        self._trackers = []
        self._recorders = []
        if self._config.auto_start:
            self.start()
    
    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    @classmethod
    def reset_instance(cls):
        with cls._lock:
            if cls._instance is not None:
                cls._instance.stop()
                cls._instance = None
    
    def start(self):
        with self._lock:
            if self._state == MonitorState.RUNNING:
                return False
            self._state = MonitorState.RUNNING
            self._start_time = time.time()
            self._running = True
            if self._config.capture_calls or self._config.capture_returns:
                self._original_trace = sys.gettrace()
                sys.settrace(self._trace_callback)
            self._thread = threading.Thread(target=self._background_worker)
            self._thread.daemon = True
            self._thread.start()
            return True
    
    def stop(self):
        with self._lock:
            if self._state != MonitorState.RUNNING:
                return False
            self._running = False
            self._state = MonitorState.STOPPED
            self._stop_time = time.time()
            if self._original_trace is not None:
                sys.settrace(self._original_trace)
            if self._thread is not None:
                self._thread.join(timeout=5.0)
            return True
    
    def pause(self):
        with self._lock:
            if self._state != MonitorState.RUNNING:
                return False
            self._state = MonitorState.PAUSED
            return True
    
    def resume(self):
        with self._lock:
            if self._state != MonitorState.PAUSED:
                return False
            self._state = MonitorState.RUNNING
            return True
    
    def emit_event(self, event_type, source, data=None):
        if self._state != MonitorState.RUNNING:
            return False
        event = MonitorEvent(event_type, source, data)
        self._buffer.append(event)
        self._process_event(event)
        return True
    
    def _process_event(self, event):
        handlers = self._event_handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                handler(event)
                event.handlers_called += 1
            except Exception:
                self._stats["errors"] += 1
        event.mark_processed()
        self._stats["events_processed"] += 1
    
    def register_handler(self, event_type, handler):
        if event_type not in self._event_handlers:
            self._event_handlers[event_type] = []
        self._event_handlers[event_type].append(handler)
    
    def unregister_handler(self, event_type, handler):
        if event_type in self._event_handlers:
            try:
                self._event_handlers[event_type].remove(handler)
                return True
            except ValueError:
                pass
        return False
    
    def create_context(self, name=None):
        ctx = MonitorContext(self, name)
        self._contexts[id(ctx)] = ctx
        self._stats["contexts_created"] += 1
        return ctx
    
    def _on_context_enter(self, context):
        self.emit_event("context_enter", context._name, {"context_id": id(context)})
    
    def _on_context_exit(self, context):
        self.emit_event("context_exit", context._name, context._data)
    
    def _trace_callback(self, frame, event, arg):
        if self._state != MonitorState.RUNNING:
            return None
        if event == "call" and self._config.capture_calls:
            self.emit_event("call", frame.f_code.co_name, {
                "filename": frame.f_code.co_filename,
                "lineno": frame.f_lineno,
                "locals": dict(frame.f_locals)
            })
        elif event == "return" and self._config.capture_returns:
            self.emit_event("return", frame.f_code.co_name, {
                "value": repr(arg) if arg is not None else None
            })
        elif event == "exception" and self._config.capture_exceptions:
            exc_type, exc_value, exc_tb = arg
            self.emit_event("exception", frame.f_code.co_name, {
                "type": exc_type.__name__,
                "value": str(exc_value)
            })
        return self._trace_callback
    
    def _background_worker(self):
        while self._running:
            time.sleep(self._config.flush_interval)
            if self._config.capture_memory:
                self._check_memory_usage()
            self._flush_buffer()
    
    def _check_memory_usage(self):
        gc.collect()
        current_usage = sys.getsizeof(self._buffer._buffer)
        if current_usage > self._config.max_memory_usage:
            self._buffer.clear()
            self._stats["events_dropped"] += 1
    
    def _flush_buffer(self):
        if self._config.output_directory is not None:
            events = self._buffer.get_all()
            if events:
                self._write_events(events)
    
    def _write_events(self, events):
        if not os.path.exists(self._config.output_directory):
            os.makedirs(self._config.output_directory)
        filename = os.path.join(
            self._config.output_directory,
            "monitor_%d.log" % int(time.time())
        )
        with open(filename, "w") as f:
            for event in events:
                f.write(str(event.to_dict()) + "\n")
    
    def get_stats(self):
        return dict(self._stats)
    
    def get_state(self):
        return self._state
    
    def get_events(self):
        return self._buffer.get_all()
    
    def clear_events(self):
        self._buffer.clear()
    
    def add_watcher(self, watcher):
        self._watchers.append(watcher)
    
    def remove_watcher(self, watcher):
        try:
            self._watchers.remove(watcher)
            return True
        except ValueError:
            return False
    
    def add_tracker(self, tracker):
        self._trackers.append(tracker)
    
    def remove_tracker(self, tracker):
        try:
            self._trackers.remove(tracker)
            return True
        except ValueError:
            return False
    
    def add_recorder(self, recorder):
        self._recorders.append(recorder)
    
    def remove_recorder(self, recorder):
        try:
            self._recorders.remove(recorder)
            return True
        except ValueError:
            return False


def create_monitor(config=None):
    return Monitor(config)


def get_monitor():
    return Monitor.get_instance()


def monitor_function(func):
    def wrapper(*args, **kwargs):
        monitor = get_monitor()
        with monitor.create_context(func.__name__):
            return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper


def monitor_class(cls):
    original_init = cls.__init__
    def new_init(self, *args, **kwargs):
        monitor = get_monitor()
        with monitor.create_context(cls.__name__ + ".__init__"):
            original_init(self, *args, **kwargs)
    cls.__init__ = new_init
    return cls
