__author__ = "mero"
__version__ = "1.0.0"

import sys
import os
import time
import threading
import weakref
from collections import OrderedDict


class TrackingMode:
    NONE = 0
    CALLS = 1
    LINES = 2
    FULL = 3


class ExecutionFrame:
    
    def __init__(self, frame_id, function_name, filename, lineno, parent_id=None):
        self.frame_id = frame_id
        self.function_name = function_name
        self.filename = filename
        self.lineno = lineno
        self.parent_id = parent_id
        self.start_time = time.time()
        self.end_time = None
        self.return_value = None
        self.exception = None
        self.children = []
        self.locals_snapshot = {}
        self.call_count = 0
    
    def finish(self, return_value=None, exception=None):
        self.end_time = time.time()
        self.return_value = return_value
        self.exception = exception
    
    def get_duration(self):
        if self.end_time is None:
            return time.time() - self.start_time
        return self.end_time - self.start_time
    
    def add_child(self, child_id):
        self.children.append(child_id)
    
    def to_dict(self):
        return {
            "frame_id": self.frame_id,
            "function_name": self.function_name,
            "filename": self.filename,
            "lineno": self.lineno,
            "parent_id": self.parent_id,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.get_duration(),
            "return_value": repr(self.return_value) if self.return_value is not None else None,
            "exception": str(self.exception) if self.exception is not None else None,
            "children": self.children
        }


class CallStack:
    
    def __init__(self, max_depth=1000):
        self._stack = []
        self._max_depth = max_depth
        self._overflow = False
    
    def push(self, frame_id):
        if len(self._stack) >= self._max_depth:
            self._overflow = True
            return False
        self._stack.append(frame_id)
        return True
    
    def pop(self):
        if not self._stack:
            return None
        return self._stack.pop()
    
    def peek(self):
        if not self._stack:
            return None
        return self._stack[-1]
    
    def depth(self):
        return len(self._stack)
    
    def is_empty(self):
        return len(self._stack) == 0
    
    def clear(self):
        self._stack.clear()
        self._overflow = False
    
    def has_overflow(self):
        return self._overflow
    
    def get_stack(self):
        return list(self._stack)


class ExecutionTracker:
    
    def __init__(self, mode=TrackingMode.CALLS, max_frames=10000):
        self._mode = mode
        self._max_frames = max_frames
        self._frames = OrderedDict()
        self._call_stack = CallStack()
        self._frame_counter = 0
        self._lock = threading.RLock()
        self._active = False
        self._start_time = None
        self._end_time = None
        self._original_trace = None
        self._thread_stacks = {}
        self._excluded_modules = set()
        self._included_modules = set()
        self._stats = {
            "total_calls": 0,
            "total_returns": 0,
            "total_exceptions": 0,
            "max_depth": 0,
            "frames_dropped": 0
        }
    
    def start(self):
        with self._lock:
            if self._active:
                return False
            self._active = True
            self._start_time = time.time()
            self._original_trace = sys.gettrace()
            if self._mode != TrackingMode.NONE:
                sys.settrace(self._trace_handler)
                threading.settrace(self._trace_handler)
            return True
    
    def stop(self):
        with self._lock:
            if not self._active:
                return False
            self._active = False
            self._end_time = time.time()
            sys.settrace(self._original_trace)
            threading.settrace(None)
            return True
    
    def _trace_handler(self, frame, event, arg):
        if not self._active:
            return None
        filename = frame.f_code.co_filename
        if self._should_skip(filename):
            return self._trace_handler
        thread_id = threading.current_thread().ident
        if thread_id not in self._thread_stacks:
            self._thread_stacks[thread_id] = CallStack()
        stack = self._thread_stacks[thread_id]
        if event == "call":
            self._handle_call(frame, stack)
        elif event == "return":
            self._handle_return(frame, arg, stack)
        elif event == "exception":
            self._handle_exception(frame, arg, stack)
        elif event == "line" and self._mode == TrackingMode.LINES:
            self._handle_line(frame)
        return self._trace_handler
    
    def _should_skip(self, filename):
        if self._included_modules:
            for module in self._included_modules:
                if module in filename:
                    return False
            return True
        for module in self._excluded_modules:
            if module in filename:
                return True
        return False
    
    def _handle_call(self, frame, stack):
        with self._lock:
            self._stats["total_calls"] += 1
            parent_id = stack.peek()
            frame_id = self._frame_counter
            self._frame_counter += 1
            if len(self._frames) >= self._max_frames:
                oldest_key = next(iter(self._frames))
                del self._frames[oldest_key]
                self._stats["frames_dropped"] += 1
            exec_frame = ExecutionFrame(
                frame_id,
                frame.f_code.co_name,
                frame.f_code.co_filename,
                frame.f_lineno,
                parent_id
            )
            if self._mode == TrackingMode.FULL:
                exec_frame.locals_snapshot = dict(frame.f_locals)
            self._frames[frame_id] = exec_frame
            stack.push(frame_id)
            if parent_id is not None and parent_id in self._frames:
                self._frames[parent_id].add_child(frame_id)
            current_depth = stack.depth()
            if current_depth > self._stats["max_depth"]:
                self._stats["max_depth"] = current_depth
    
    def _handle_return(self, frame, return_value, stack):
        with self._lock:
            self._stats["total_returns"] += 1
            frame_id = stack.pop()
            if frame_id is not None and frame_id in self._frames:
                self._frames[frame_id].finish(return_value=return_value)
    
    def _handle_exception(self, frame, arg, stack):
        with self._lock:
            self._stats["total_exceptions"] += 1
            frame_id = stack.peek()
            if frame_id is not None and frame_id in self._frames:
                exc_type, exc_value, exc_tb = arg
                self._frames[frame_id].exception = exc_value
    
    def _handle_line(self, frame):
        pass
    
    def exclude_module(self, module_name):
        self._excluded_modules.add(module_name)
    
    def include_module(self, module_name):
        self._included_modules.add(module_name)
    
    def get_frame(self, frame_id):
        return self._frames.get(frame_id)
    
    def get_all_frames(self):
        return list(self._frames.values())
    
    def get_call_tree(self):
        roots = []
        for frame in self._frames.values():
            if frame.parent_id is None:
                roots.append(self._build_tree(frame))
        return roots
    
    def _build_tree(self, frame):
        node = frame.to_dict()
        node["children_frames"] = []
        for child_id in frame.children:
            child_frame = self._frames.get(child_id)
            if child_frame is not None:
                node["children_frames"].append(self._build_tree(child_frame))
        return node
    
    def get_stats(self):
        return dict(self._stats)
    
    def get_duration(self):
        if self._start_time is None:
            return 0
        if self._end_time is None:
            return time.time() - self._start_time
        return self._end_time - self._start_time
    
    def clear(self):
        with self._lock:
            self._frames.clear()
            self._call_stack.clear()
            self._thread_stacks.clear()
            self._frame_counter = 0
            for key in self._stats:
                self._stats[key] = 0


class FunctionTracker:
    
    def __init__(self):
        self._functions = {}
        self._lock = threading.Lock()
    
    def track(self, func):
        func_id = id(func)
        with self._lock:
            if func_id not in self._functions:
                self._functions[func_id] = {
                    "name": func.__name__,
                    "calls": 0,
                    "total_time": 0,
                    "min_time": float("inf"),
                    "max_time": 0,
                    "errors": 0
                }
        def wrapper(*args, **kwargs):
            start = time.time()
            try:
                result = func(*args, **kwargs)
                elapsed = time.time() - start
                with self._lock:
                    self._functions[func_id]["calls"] += 1
                    self._functions[func_id]["total_time"] += elapsed
                    if elapsed < self._functions[func_id]["min_time"]:
                        self._functions[func_id]["min_time"] = elapsed
                    if elapsed > self._functions[func_id]["max_time"]:
                        self._functions[func_id]["max_time"] = elapsed
                return result
            except Exception as e:
                elapsed = time.time() - start
                with self._lock:
                    self._functions[func_id]["calls"] += 1
                    self._functions[func_id]["total_time"] += elapsed
                    self._functions[func_id]["errors"] += 1
                raise
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    
    def get_stats(self, func=None):
        if func is not None:
            return self._functions.get(id(func))
        return dict(self._functions)
    
    def reset(self, func=None):
        with self._lock:
            if func is not None:
                func_id = id(func)
                if func_id in self._functions:
                    self._functions[func_id] = {
                        "name": self._functions[func_id]["name"],
                        "calls": 0,
                        "total_time": 0,
                        "min_time": float("inf"),
                        "max_time": 0,
                        "errors": 0
                    }
            else:
                for func_id in self._functions:
                    name = self._functions[func_id]["name"]
                    self._functions[func_id] = {
                        "name": name,
                        "calls": 0,
                        "total_time": 0,
                        "min_time": float("inf"),
                        "max_time": 0,
                        "errors": 0
                    }


class VariableTracker:
    
    def __init__(self):
        self._variables = {}
        self._history = {}
        self._max_history = 100
        self._lock = threading.Lock()
    
    def track(self, name, value):
        with self._lock:
            timestamp = time.time()
            old_value = self._variables.get(name)
            self._variables[name] = value
            if name not in self._history:
                self._history[name] = []
            self._history[name].append({
                "value": value,
                "timestamp": timestamp,
                "old_value": old_value
            })
            if len(self._history[name]) > self._max_history:
                self._history[name] = self._history[name][-self._max_history:]
    
    def get(self, name):
        return self._variables.get(name)
    
    def get_history(self, name):
        return list(self._history.get(name, []))
    
    def get_all(self):
        return dict(self._variables)
    
    def clear(self, name=None):
        with self._lock:
            if name is not None:
                if name in self._variables:
                    del self._variables[name]
                if name in self._history:
                    del self._history[name]
            else:
                self._variables.clear()
                self._history.clear()


_default_tracker = None
_function_tracker = None
_variable_tracker = None


def get_execution_tracker():
    global _default_tracker
    if _default_tracker is None:
        _default_tracker = ExecutionTracker()
    return _default_tracker


def get_function_tracker():
    global _function_tracker
    if _function_tracker is None:
        _function_tracker = FunctionTracker()
    return _function_tracker


def get_variable_tracker():
    global _variable_tracker
    if _variable_tracker is None:
        _variable_tracker = VariableTracker()
    return _variable_tracker


def track_function(func):
    return get_function_tracker().track(func)


def track_variable(name, value):
    get_variable_tracker().track(name, value)
    return value


def start_tracking(mode=TrackingMode.CALLS):
    tracker = get_execution_tracker()
    tracker._mode = mode
    return tracker.start()


def stop_tracking():
    return get_execution_tracker().stop()
