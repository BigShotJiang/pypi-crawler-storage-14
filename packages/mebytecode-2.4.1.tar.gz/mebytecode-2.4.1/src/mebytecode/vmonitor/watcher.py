__author__ = "mero"
__version__ = "1.0.0"

import sys
import os
import time
import threading
import weakref
import hashlib
from collections import OrderedDict


class WatcherState:
    INACTIVE = 0
    ACTIVE = 1
    SUSPENDED = 2
    TERMINATED = 3


class WatchEvent:
    
    def __init__(self, watcher_type, target, old_value, new_value, timestamp=None):
        self.watcher_type = watcher_type
        self.target = target
        self.old_value = old_value
        self.new_value = new_value
        self.timestamp = timestamp if timestamp is not None else time.time()
    
    def to_dict(self):
        return {
            "watcher_type": self.watcher_type,
            "target": str(self.target),
            "old_value": repr(self.old_value),
            "new_value": repr(self.new_value),
            "timestamp": self.timestamp
        }


class BaseWatcher:
    
    def __init__(self, callback=None, interval=1.0):
        self._callback = callback
        self._interval = interval
        self._state = WatcherState.INACTIVE
        self._thread = None
        self._running = False
        self._lock = threading.Lock()
        self._events = []
        self._start_time = None
        self._check_count = 0
    
    def start(self):
        with self._lock:
            if self._state == WatcherState.ACTIVE:
                return False
            self._state = WatcherState.ACTIVE
            self._running = True
            self._start_time = time.time()
            self._thread = threading.Thread(target=self._run)
            self._thread.daemon = True
            self._thread.start()
            return True
    
    def stop(self):
        with self._lock:
            if self._state != WatcherState.ACTIVE:
                return False
            self._running = False
            self._state = WatcherState.TERMINATED
            if self._thread is not None:
                self._thread.join(timeout=5.0)
            return True
    
    def suspend(self):
        with self._lock:
            if self._state != WatcherState.ACTIVE:
                return False
            self._state = WatcherState.SUSPENDED
            return True
    
    def resume(self):
        with self._lock:
            if self._state != WatcherState.SUSPENDED:
                return False
            self._state = WatcherState.ACTIVE
            return True
    
    def _run(self):
        while self._running:
            if self._state == WatcherState.ACTIVE:
                self._check()
                self._check_count += 1
            time.sleep(self._interval)
    
    def _check(self):
        raise NotImplementedError
    
    def _emit_event(self, event):
        self._events.append(event)
        if self._callback is not None:
            try:
                self._callback(event)
            except Exception:
                pass
    
    def get_events(self):
        return list(self._events)
    
    def clear_events(self):
        self._events.clear()
    
    def get_state(self):
        return self._state
    
    def get_check_count(self):
        return self._check_count


class FileWatcher(BaseWatcher):
    
    def __init__(self, path, callback=None, interval=1.0, recursive=False):
        super(FileWatcher, self).__init__(callback, interval)
        self._path = path
        self._recursive = recursive
        self._file_states = {}
        self._initialize_states()
    
    def _initialize_states(self):
        if os.path.isfile(self._path):
            self._file_states[self._path] = self._get_file_state(self._path)
        elif os.path.isdir(self._path):
            self._scan_directory(self._path)
    
    def _scan_directory(self, directory):
        try:
            for entry in os.listdir(directory):
                full_path = os.path.join(directory, entry)
                if os.path.isfile(full_path):
                    self._file_states[full_path] = self._get_file_state(full_path)
                elif os.path.isdir(full_path) and self._recursive:
                    self._scan_directory(full_path)
        except OSError:
            pass
    
    def _get_file_state(self, path):
        try:
            stat = os.stat(path)
            return {
                "mtime": stat.st_mtime,
                "size": stat.st_size,
                "hash": self._compute_hash(path)
            }
        except OSError:
            return None
    
    def _compute_hash(self, path):
        try:
            hasher = hashlib.md5()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except (IOError, OSError):
            return None
    
    def _check(self):
        current_files = set()
        if os.path.isfile(self._path):
            current_files.add(self._path)
            self._check_file(self._path)
        elif os.path.isdir(self._path):
            self._check_directory(self._path, current_files)
        for path in set(self._file_states.keys()) - current_files:
            event = WatchEvent("file_deleted", path, self._file_states[path], None)
            self._emit_event(event)
            del self._file_states[path]
    
    def _check_directory(self, directory, current_files):
        try:
            for entry in os.listdir(directory):
                full_path = os.path.join(directory, entry)
                if os.path.isfile(full_path):
                    current_files.add(full_path)
                    self._check_file(full_path)
                elif os.path.isdir(full_path) and self._recursive:
                    self._check_directory(full_path, current_files)
        except OSError:
            pass
    
    def _check_file(self, path):
        new_state = self._get_file_state(path)
        if path not in self._file_states:
            event = WatchEvent("file_created", path, None, new_state)
            self._emit_event(event)
            self._file_states[path] = new_state
        elif new_state != self._file_states[path]:
            event = WatchEvent("file_modified", path, self._file_states[path], new_state)
            self._emit_event(event)
            self._file_states[path] = new_state
    
    def add_path(self, path):
        if os.path.isfile(path):
            self._file_states[path] = self._get_file_state(path)
        elif os.path.isdir(path):
            self._scan_directory(path)
    
    def remove_path(self, path):
        if path in self._file_states:
            del self._file_states[path]


class VariableWatcher(BaseWatcher):
    
    def __init__(self, target_object, attribute_name, callback=None, interval=0.1):
        super(VariableWatcher, self).__init__(callback, interval)
        self._target_ref = weakref.ref(target_object) if target_object is not None else None
        self._attribute_name = attribute_name
        self._last_value = self._get_value()
    
    def _get_value(self):
        if self._target_ref is None:
            return None
        target = self._target_ref()
        if target is None:
            return None
        try:
            return getattr(target, self._attribute_name, None)
        except Exception:
            return None
    
    def _check(self):
        current_value = self._get_value()
        if current_value != self._last_value:
            event = WatchEvent(
                "variable_changed",
                self._attribute_name,
                self._last_value,
                current_value
            )
            self._emit_event(event)
            self._last_value = current_value
    
    def get_current_value(self):
        return self._get_value()
    
    def get_last_known_value(self):
        return self._last_value


class MemoryWatcher(BaseWatcher):
    
    def __init__(self, callback=None, interval=1.0, threshold_bytes=None):
        super(MemoryWatcher, self).__init__(callback, interval)
        self._threshold_bytes = threshold_bytes
        self._last_memory_info = self._get_memory_info()
        self._peak_memory = 0
    
    def _get_memory_info(self):
        try:
            import resource
            usage = resource.getrusage(resource.RUSAGE_SELF)
            return {
                "rss": usage.ru_maxrss * 1024,
                "shared": usage.ru_ixrss,
                "data": usage.ru_idrss
            }
        except ImportError:
            pass
        try:
            import psutil
            process = psutil.Process(os.getpid())
            mem = process.memory_info()
            return {
                "rss": mem.rss,
                "vms": mem.vms,
                "shared": getattr(mem, "shared", 0)
            }
        except ImportError:
            pass
        return {"estimated": sys.getsizeof([])}
    
    def _check(self):
        current_info = self._get_memory_info()
        rss = current_info.get("rss", 0)
        if rss > self._peak_memory:
            self._peak_memory = rss
        if self._threshold_bytes is not None and rss > self._threshold_bytes:
            event = WatchEvent(
                "memory_threshold_exceeded",
                "memory",
                self._last_memory_info,
                current_info
            )
            self._emit_event(event)
        last_rss = self._last_memory_info.get("rss", 0)
        if abs(rss - last_rss) > (last_rss * 0.1):
            event = WatchEvent(
                "memory_changed",
                "memory",
                self._last_memory_info,
                current_info
            )
            self._emit_event(event)
        self._last_memory_info = current_info
    
    def get_current_memory(self):
        return self._get_memory_info()
    
    def get_peak_memory(self):
        return self._peak_memory
    
    def set_threshold(self, bytes_threshold):
        self._threshold_bytes = bytes_threshold


class ObjectWatcher(BaseWatcher):
    
    def __init__(self, target_object, callback=None, interval=0.5, deep=False):
        super(ObjectWatcher, self).__init__(callback, interval)
        self._target_ref = weakref.ref(target_object) if target_object is not None else None
        self._deep = deep
        self._last_state = self._capture_state()
    
    def _capture_state(self):
        if self._target_ref is None:
            return {}
        target = self._target_ref()
        if target is None:
            return {}
        state = {}
        try:
            for attr in dir(target):
                if not attr.startswith("_"):
                    try:
                        value = getattr(target, attr)
                        if not callable(value):
                            state[attr] = self._hash_value(value)
                    except Exception:
                        pass
        except Exception:
            pass
        return state
    
    def _hash_value(self, value):
        try:
            return hash(repr(value))
        except Exception:
            return id(value)
    
    def _check(self):
        current_state = self._capture_state()
        for attr, value_hash in current_state.items():
            if attr not in self._last_state:
                event = WatchEvent("attribute_added", attr, None, value_hash)
                self._emit_event(event)
            elif value_hash != self._last_state[attr]:
                event = WatchEvent(
                    "attribute_changed",
                    attr,
                    self._last_state[attr],
                    value_hash
                )
                self._emit_event(event)
        for attr in set(self._last_state.keys()) - set(current_state.keys()):
            event = WatchEvent("attribute_removed", attr, self._last_state[attr], None)
            self._emit_event(event)
        self._last_state = current_state


class WatcherManager:
    
    def __init__(self):
        self._watchers = {}
        self._lock = threading.Lock()
        self._counter = 0
    
    def create_file_watcher(self, path, callback=None, interval=1.0, recursive=False):
        with self._lock:
            watcher_id = self._counter
            self._counter += 1
            watcher = FileWatcher(path, callback, interval, recursive)
            self._watchers[watcher_id] = watcher
            return watcher_id
    
    def create_variable_watcher(self, target, attribute, callback=None, interval=0.1):
        with self._lock:
            watcher_id = self._counter
            self._counter += 1
            watcher = VariableWatcher(target, attribute, callback, interval)
            self._watchers[watcher_id] = watcher
            return watcher_id
    
    def create_memory_watcher(self, callback=None, interval=1.0, threshold=None):
        with self._lock:
            watcher_id = self._counter
            self._counter += 1
            watcher = MemoryWatcher(callback, interval, threshold)
            self._watchers[watcher_id] = watcher
            return watcher_id
    
    def create_object_watcher(self, target, callback=None, interval=0.5, deep=False):
        with self._lock:
            watcher_id = self._counter
            self._counter += 1
            watcher = ObjectWatcher(target, callback, interval, deep)
            self._watchers[watcher_id] = watcher
            return watcher_id
    
    def get_watcher(self, watcher_id):
        return self._watchers.get(watcher_id)
    
    def start_watcher(self, watcher_id):
        watcher = self._watchers.get(watcher_id)
        if watcher is not None:
            return watcher.start()
        return False
    
    def stop_watcher(self, watcher_id):
        watcher = self._watchers.get(watcher_id)
        if watcher is not None:
            return watcher.stop()
        return False
    
    def start_all(self):
        for watcher in self._watchers.values():
            watcher.start()
    
    def stop_all(self):
        for watcher in self._watchers.values():
            watcher.stop()
    
    def remove_watcher(self, watcher_id):
        with self._lock:
            if watcher_id in self._watchers:
                watcher = self._watchers[watcher_id]
                watcher.stop()
                del self._watchers[watcher_id]
                return True
            return False
    
    def get_all_events(self):
        all_events = []
        for watcher in self._watchers.values():
            all_events.extend(watcher.get_events())
        return sorted(all_events, key=lambda e: e.timestamp)


_default_manager = None


def get_watcher_manager():
    global _default_manager
    if _default_manager is None:
        _default_manager = WatcherManager()
    return _default_manager


def watch_file(path, callback=None, interval=1.0, recursive=False, auto_start=True):
    manager = get_watcher_manager()
    watcher_id = manager.create_file_watcher(path, callback, interval, recursive)
    if auto_start:
        manager.start_watcher(watcher_id)
    return watcher_id


def watch_variable(target, attribute, callback=None, interval=0.1, auto_start=True):
    manager = get_watcher_manager()
    watcher_id = manager.create_variable_watcher(target, attribute, callback, interval)
    if auto_start:
        manager.start_watcher(watcher_id)
    return watcher_id


def watch_memory(callback=None, interval=1.0, threshold=None, auto_start=True):
    manager = get_watcher_manager()
    watcher_id = manager.create_memory_watcher(callback, interval, threshold)
    if auto_start:
        manager.start_watcher(watcher_id)
    return watcher_id


def watch_object(target, callback=None, interval=0.5, deep=False, auto_start=True):
    manager = get_watcher_manager()
    watcher_id = manager.create_object_watcher(target, callback, interval, deep)
    if auto_start:
        manager.start_watcher(watcher_id)
    return watcher_id
