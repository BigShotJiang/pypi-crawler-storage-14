__author__ = "mero"
__version__ = "1.0.0"

import sys
import os
import time
import threading
import json
import socket
import smtplib
from email.mime.text import MIMEText
from collections import OrderedDict


class AlertLevel:
    DEBUG = 0
    INFO = 1
    WARNING = 2
    ERROR = 3
    CRITICAL = 4
    EMERGENCY = 5


class AlertState:
    PENDING = 0
    SENT = 1
    ACKNOWLEDGED = 2
    RESOLVED = 3
    SUPPRESSED = 4


class Alert:
    
    def __init__(self, level, title, message, source=None, data=None):
        self.alert_id = "alert_%d_%d" % (int(time.time() * 1000), id(self))
        self.level = level
        self.title = title
        self.message = message
        self.source = source
        self.data = data if data is not None else {}
        self.timestamp = time.time()
        self.state = AlertState.PENDING
        self.sent_at = None
        self.acknowledged_at = None
        self.resolved_at = None
        self.notification_count = 0
        self.tags = []
    
    def acknowledge(self):
        self.state = AlertState.ACKNOWLEDGED
        self.acknowledged_at = time.time()
    
    def resolve(self):
        self.state = AlertState.RESOLVED
        self.resolved_at = time.time()
    
    def suppress(self):
        self.state = AlertState.SUPPRESSED
    
    def add_tag(self, tag):
        if tag not in self.tags:
            self.tags.append(tag)
    
    def to_dict(self):
        return {
            "alert_id": self.alert_id,
            "level": self.level,
            "title": self.title,
            "message": self.message,
            "source": self.source,
            "data": self.data,
            "timestamp": self.timestamp,
            "state": self.state,
            "tags": self.tags
        }
    
    def get_level_name(self):
        names = {
            AlertLevel.DEBUG: "DEBUG",
            AlertLevel.INFO: "INFO",
            AlertLevel.WARNING: "WARNING",
            AlertLevel.ERROR: "ERROR",
            AlertLevel.CRITICAL: "CRITICAL",
            AlertLevel.EMERGENCY: "EMERGENCY"
        }
        return names.get(self.level, "UNKNOWN")


class AlertChannel:
    
    def __init__(self, name):
        self._name = name
        self._enabled = True
        self._min_level = AlertLevel.INFO
        self._sent_count = 0
        self._error_count = 0
    
    def send(self, alert):
        raise NotImplementedError
    
    def can_send(self, alert):
        return self._enabled and alert.level >= self._min_level
    
    def enable(self):
        self._enabled = True
    
    def disable(self):
        self._enabled = False
    
    def set_min_level(self, level):
        self._min_level = level
    
    def get_stats(self):
        return {
            "name": self._name,
            "enabled": self._enabled,
            "min_level": self._min_level,
            "sent_count": self._sent_count,
            "error_count": self._error_count
        }


class ConsoleAlertChannel(AlertChannel):
    
    def __init__(self, name="console", stream=None):
        super(ConsoleAlertChannel, self).__init__(name)
        self._stream = stream if stream is not None else sys.stderr
    
    def send(self, alert):
        if not self.can_send(alert):
            return False
        try:
            message = "[%s] %s: %s - %s\n" % (
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(alert.timestamp)),
                alert.get_level_name(),
                alert.title,
                alert.message
            )
            self._stream.write(message)
            self._stream.flush()
            self._sent_count += 1
            return True
        except Exception:
            self._error_count += 1
            return False


class FileAlertChannel(AlertChannel):
    
    def __init__(self, name, file_path, max_size=10 * 1024 * 1024, backup_count=5):
        super(FileAlertChannel, self).__init__(name)
        self._file_path = file_path
        self._max_size = max_size
        self._backup_count = backup_count
        self._lock = threading.Lock()
    
    def send(self, alert):
        if not self.can_send(alert):
            return False
        with self._lock:
            try:
                self._rotate_if_needed()
                with open(self._file_path, "a") as f:
                    data = json.dumps(alert.to_dict()) + "\n"
                    f.write(data)
                self._sent_count += 1
                return True
            except Exception:
                self._error_count += 1
                return False
    
    def _rotate_if_needed(self):
        if not os.path.exists(self._file_path):
            return
        if os.path.getsize(self._file_path) < self._max_size:
            return
        for i in range(self._backup_count - 1, 0, -1):
            src = "%s.%d" % (self._file_path, i)
            dst = "%s.%d" % (self._file_path, i + 1)
            if os.path.exists(src):
                if os.path.exists(dst):
                    os.remove(dst)
                os.rename(src, dst)
        backup = "%s.1" % self._file_path
        if os.path.exists(self._file_path):
            os.rename(self._file_path, backup)


class EmailAlertChannel(AlertChannel):
    
    def __init__(self, name, smtp_host, smtp_port, username, password, 
                 from_addr, to_addrs, use_tls=True):
        super(EmailAlertChannel, self).__init__(name)
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._username = username
        self._password = password
        self._from_addr = from_addr
        self._to_addrs = to_addrs if isinstance(to_addrs, list) else [to_addrs]
        self._use_tls = use_tls
        self._min_level = AlertLevel.ERROR
    
    def send(self, alert):
        if not self.can_send(alert):
            return False
        try:
            subject = "[%s] %s" % (alert.get_level_name(), alert.title)
            body = "Alert: %s\n\nMessage: %s\n\nTime: %s\n\nSource: %s\n\nData: %s" % (
                alert.title,
                alert.message,
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(alert.timestamp)),
                alert.source or "N/A",
                json.dumps(alert.data, indent=2)
            )
            msg = MIMEText(body)
            msg["Subject"] = subject
            msg["From"] = self._from_addr
            msg["To"] = ", ".join(self._to_addrs)
            if self._use_tls:
                server = smtplib.SMTP(self._smtp_host, self._smtp_port)
                server.starttls()
            else:
                server = smtplib.SMTP(self._smtp_host, self._smtp_port)
            server.login(self._username, self._password)
            server.sendmail(self._from_addr, self._to_addrs, msg.as_string())
            server.quit()
            self._sent_count += 1
            return True
        except Exception:
            self._error_count += 1
            return False


class WebhookAlertChannel(AlertChannel):
    
    def __init__(self, name, url, method="POST", headers=None, timeout=10):
        super(WebhookAlertChannel, self).__init__(name)
        self._url = url
        self._method = method
        self._headers = headers if headers is not None else {"Content-Type": "application/json"}
        self._timeout = timeout
    
    def send(self, alert):
        if not self.can_send(alert):
            return False
        try:
            import urllib.request
            import urllib.error
            data = json.dumps(alert.to_dict()).encode("utf-8")
            req = urllib.request.Request(
                self._url,
                data=data,
                headers=self._headers,
                method=self._method
            )
            urllib.request.urlopen(req, timeout=self._timeout)
            self._sent_count += 1
            return True
        except Exception:
            self._error_count += 1
            return False


class AlertRule:
    
    def __init__(self, name, condition, actions=None, cooldown=60.0):
        self._name = name
        self._condition = condition
        self._actions = actions if actions is not None else []
        self._cooldown = cooldown
        self._last_triggered = 0
        self._trigger_count = 0
        self._enabled = True
    
    def evaluate(self, alert):
        if not self._enabled:
            return False
        current_time = time.time()
        if current_time - self._last_triggered < self._cooldown:
            return False
        try:
            if self._condition(alert):
                self._last_triggered = current_time
                self._trigger_count += 1
                return True
        except Exception:
            pass
        return False
    
    def get_actions(self):
        return list(self._actions)
    
    def enable(self):
        self._enabled = True
    
    def disable(self):
        self._enabled = False


class AlertManager:
    
    def __init__(self):
        self._channels = {}
        self._rules = []
        self._alerts = OrderedDict()
        self._max_alerts = 10000
        self._lock = threading.RLock()
        self._suppression_rules = []
        self._default_channel = None
        self._async_enabled = True
        self._queue = []
        self._worker_thread = None
        self._running = False
    
    def start(self):
        with self._lock:
            if self._running:
                return False
            self._running = True
            if self._async_enabled:
                self._worker_thread = threading.Thread(target=self._worker)
                self._worker_thread.daemon = True
                self._worker_thread.start()
            return True
    
    def stop(self):
        with self._lock:
            self._running = False
            if self._worker_thread is not None:
                self._worker_thread.join(timeout=5.0)
            return True
    
    def add_channel(self, channel, is_default=False):
        with self._lock:
            self._channels[channel._name] = channel
            if is_default or self._default_channel is None:
                self._default_channel = channel._name
    
    def remove_channel(self, name):
        with self._lock:
            if name in self._channels:
                del self._channels[name]
                return True
            return False
    
    def add_rule(self, rule):
        self._rules.append(rule)
    
    def add_suppression_rule(self, rule):
        self._suppression_rules.append(rule)
    
    def alert(self, level, title, message, source=None, data=None, channels=None):
        alert = Alert(level, title, message, source, data)
        return self.send_alert(alert, channels)
    
    def send_alert(self, alert, channels=None):
        with self._lock:
            for suppression in self._suppression_rules:
                if suppression(alert):
                    alert.suppress()
                    return False
            if len(self._alerts) >= self._max_alerts:
                oldest_key = next(iter(self._alerts))
                del self._alerts[oldest_key]
            self._alerts[alert.alert_id] = alert
            for rule in self._rules:
                if rule.evaluate(alert):
                    for action in rule.get_actions():
                        try:
                            action(alert)
                        except Exception:
                            pass
            if self._async_enabled and self._running:
                self._queue.append((alert, channels))
                return True
            else:
                return self._dispatch_alert(alert, channels)
    
    def _dispatch_alert(self, alert, channels=None):
        target_channels = []
        if channels is not None:
            for name in channels:
                if name in self._channels:
                    target_channels.append(self._channels[name])
        elif self._default_channel is not None:
            if self._default_channel in self._channels:
                target_channels.append(self._channels[self._default_channel])
        success = False
        for channel in target_channels:
            if channel.send(alert):
                alert.notification_count += 1
                success = True
        if success:
            alert.state = AlertState.SENT
            alert.sent_at = time.time()
        return success
    
    def _worker(self):
        while self._running:
            while self._queue:
                with self._lock:
                    if self._queue:
                        alert, channels = self._queue.pop(0)
                    else:
                        break
                self._dispatch_alert(alert, channels)
            time.sleep(0.1)
    
    def get_alert(self, alert_id):
        return self._alerts.get(alert_id)
    
    def get_alerts(self, level=None, state=None, limit=100):
        alerts = list(self._alerts.values())
        if level is not None:
            alerts = [a for a in alerts if a.level >= level]
        if state is not None:
            alerts = [a for a in alerts if a.state == state]
        return alerts[-limit:]
    
    def acknowledge_alert(self, alert_id):
        alert = self._alerts.get(alert_id)
        if alert is not None:
            alert.acknowledge()
            return True
        return False
    
    def resolve_alert(self, alert_id):
        alert = self._alerts.get(alert_id)
        if alert is not None:
            alert.resolve()
            return True
        return False
    
    def debug(self, title, message, source=None, data=None):
        return self.alert(AlertLevel.DEBUG, title, message, source, data)
    
    def info(self, title, message, source=None, data=None):
        return self.alert(AlertLevel.INFO, title, message, source, data)
    
    def warning(self, title, message, source=None, data=None):
        return self.alert(AlertLevel.WARNING, title, message, source, data)
    
    def error(self, title, message, source=None, data=None):
        return self.alert(AlertLevel.ERROR, title, message, source, data)
    
    def critical(self, title, message, source=None, data=None):
        return self.alert(AlertLevel.CRITICAL, title, message, source, data)
    
    def emergency(self, title, message, source=None, data=None):
        return self.alert(AlertLevel.EMERGENCY, title, message, source, data)
    
    def get_stats(self):
        channel_stats = {}
        for name, channel in self._channels.items():
            channel_stats[name] = channel.get_stats()
        return {
            "total_alerts": len(self._alerts),
            "pending": len([a for a in self._alerts.values() if a.state == AlertState.PENDING]),
            "sent": len([a for a in self._alerts.values() if a.state == AlertState.SENT]),
            "acknowledged": len([a for a in self._alerts.values() if a.state == AlertState.ACKNOWLEDGED]),
            "resolved": len([a for a in self._alerts.values() if a.state == AlertState.RESOLVED]),
            "suppressed": len([a for a in self._alerts.values() if a.state == AlertState.SUPPRESSED]),
            "channels": channel_stats
        }


_default_manager = None


def get_alert_manager():
    global _default_manager
    if _default_manager is None:
        _default_manager = AlertManager()
        _default_manager.add_channel(ConsoleAlertChannel(), is_default=True)
    return _default_manager


def alert(level, title, message, source=None, data=None):
    return get_alert_manager().alert(level, title, message, source, data)


def debug(title, message, source=None, data=None):
    return get_alert_manager().debug(title, message, source, data)


def info(title, message, source=None, data=None):
    return get_alert_manager().info(title, message, source, data)


def warning(title, message, source=None, data=None):
    return get_alert_manager().warning(title, message, source, data)


def error(title, message, source=None, data=None):
    return get_alert_manager().error(title, message, source, data)


def critical(title, message, source=None, data=None):
    return get_alert_manager().critical(title, message, source, data)
