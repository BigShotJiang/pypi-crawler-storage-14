__author__ = "mero"
__version__ = "1.0.0"

import sys
import os
import time
import threading
import weakref
import hashlib
from collections import OrderedDict


class DetectionType:
    CHANGE = "change"
    ANOMALY = "anomaly"
    THRESHOLD = "threshold"
    PATTERN = "pattern"
    DRIFT = "drift"
    SPIKE = "spike"


class Detection:
    
    def __init__(self, detection_type, source, description, severity=1, data=None):
        self.detection_type = detection_type
        self.source = source
        self.description = description
        self.severity = severity
        self.data = data if data is not None else {}
        self.timestamp = time.time()
        self.acknowledged = False
        self.resolved = False
    
    def acknowledge(self):
        self.acknowledged = True
    
    def resolve(self):
        self.resolved = True
    
    def to_dict(self):
        return {
            "detection_type": self.detection_type,
            "source": self.source,
            "description": self.description,
            "severity": self.severity,
            "data": self.data,
            "timestamp": self.timestamp,
            "acknowledged": self.acknowledged,
            "resolved": self.resolved
        }


class BaseDetector:
    
    def __init__(self, name, callback=None):
        self._name = name
        self._callback = callback
        self._detections = []
        self._enabled = True
        self._lock = threading.Lock()
        self._detection_count = 0
    
    def detect(self, data):
        raise NotImplementedError
    
    def _emit_detection(self, detection):
        with self._lock:
            self._detections.append(detection)
            self._detection_count += 1
            if self._callback is not None:
                try:
                    self._callback(detection)
                except Exception:
                    pass
    
    def get_detections(self):
        return list(self._detections)
    
    def clear_detections(self):
        with self._lock:
            self._detections.clear()
    
    def enable(self):
        self._enabled = True
    
    def disable(self):
        self._enabled = False
    
    def is_enabled(self):
        return self._enabled
    
    def get_detection_count(self):
        return self._detection_count


class ChangeDetector(BaseDetector):
    
    def __init__(self, name, callback=None, sensitivity=0.0):
        super(ChangeDetector, self).__init__(name, callback)
        self._sensitivity = sensitivity
        self._previous_values = {}
    
    def detect(self, key, value):
        if not self._enabled:
            return None
        if key in self._previous_values:
            old_value = self._previous_values[key]
            if self._has_changed(old_value, value):
                detection = Detection(
                    DetectionType.CHANGE,
                    self._name,
                    "Value changed for key: %s" % key,
                    severity=1,
                    data={"key": key, "old_value": old_value, "new_value": value}
                )
                self._emit_detection(detection)
                self._previous_values[key] = value
                return detection
        else:
            self._previous_values[key] = value
        return None
    
    def _has_changed(self, old_value, new_value):
        if type(old_value) != type(new_value):
            return True
        if isinstance(old_value, (int, float)) and isinstance(new_value, (int, float)):
            if self._sensitivity > 0:
                if old_value == 0:
                    return abs(new_value) > self._sensitivity
                return abs(new_value - old_value) / abs(old_value) > self._sensitivity
        return old_value != new_value
    
    def reset(self):
        self._previous_values.clear()


class ThresholdDetector(BaseDetector):
    
    def __init__(self, name, callback=None, min_threshold=None, max_threshold=None):
        super(ThresholdDetector, self).__init__(name, callback)
        self._min_threshold = min_threshold
        self._max_threshold = max_threshold
        self._consecutive_violations = 0
        self._required_consecutive = 1
    
    def detect(self, value):
        if not self._enabled:
            return None
        violated = False
        violation_type = None
        if self._min_threshold is not None and value < self._min_threshold:
            violated = True
            violation_type = "below_minimum"
        elif self._max_threshold is not None and value > self._max_threshold:
            violated = True
            violation_type = "above_maximum"
        if violated:
            self._consecutive_violations += 1
            if self._consecutive_violations >= self._required_consecutive:
                detection = Detection(
                    DetectionType.THRESHOLD,
                    self._name,
                    "Threshold violation: %s" % violation_type,
                    severity=2,
                    data={
                        "value": value,
                        "min_threshold": self._min_threshold,
                        "max_threshold": self._max_threshold,
                        "violation_type": violation_type,
                        "consecutive": self._consecutive_violations
                    }
                )
                self._emit_detection(detection)
                return detection
        else:
            self._consecutive_violations = 0
        return None
    
    def set_thresholds(self, min_threshold=None, max_threshold=None):
        self._min_threshold = min_threshold
        self._max_threshold = max_threshold
    
    def set_required_consecutive(self, count):
        self._required_consecutive = count


class AnomalyDetector(BaseDetector):
    
    def __init__(self, name, callback=None, window_size=100, std_threshold=3.0):
        super(AnomalyDetector, self).__init__(name, callback)
        self._window_size = window_size
        self._std_threshold = std_threshold
        self._values = []
        self._mean = 0.0
        self._std = 0.0
    
    def detect(self, value):
        if not self._enabled:
            return None
        self._values.append(value)
        if len(self._values) > self._window_size:
            self._values.pop(0)
        if len(self._values) < 10:
            return None
        self._calculate_stats()
        if self._std > 0:
            z_score = abs(value - self._mean) / self._std
            if z_score > self._std_threshold:
                detection = Detection(
                    DetectionType.ANOMALY,
                    self._name,
                    "Anomaly detected: z-score %.2f" % z_score,
                    severity=3,
                    data={
                        "value": value,
                        "mean": self._mean,
                        "std": self._std,
                        "z_score": z_score
                    }
                )
                self._emit_detection(detection)
                return detection
        return None
    
    def _calculate_stats(self):
        n = len(self._values)
        if n == 0:
            self._mean = 0.0
            self._std = 0.0
            return
        self._mean = sum(self._values) / n
        variance = sum((x - self._mean) ** 2 for x in self._values) / n
        self._std = variance ** 0.5
    
    def reset(self):
        self._values.clear()
        self._mean = 0.0
        self._std = 0.0


class PatternDetector(BaseDetector):
    
    def __init__(self, name, callback=None, patterns=None):
        super(PatternDetector, self).__init__(name, callback)
        self._patterns = patterns if patterns is not None else []
        self._history = []
        self._max_history = 1000
    
    def add_pattern(self, pattern, description=None, severity=1):
        self._patterns.append({
            "pattern": pattern,
            "description": description or "Pattern: %s" % str(pattern),
            "severity": severity
        })
    
    def detect(self, value):
        if not self._enabled:
            return None
        self._history.append(value)
        if len(self._history) > self._max_history:
            self._history.pop(0)
        for pattern_def in self._patterns:
            pattern = pattern_def["pattern"]
            if self._matches_pattern(pattern):
                detection = Detection(
                    DetectionType.PATTERN,
                    self._name,
                    pattern_def["description"],
                    severity=pattern_def["severity"],
                    data={
                        "pattern": pattern,
                        "history_tail": self._history[-len(pattern):]
                    }
                )
                self._emit_detection(detection)
                return detection
        return None
    
    def _matches_pattern(self, pattern):
        if len(self._history) < len(pattern):
            return False
        recent = self._history[-len(pattern):]
        for i, expected in enumerate(pattern):
            if expected is not None and recent[i] != expected:
                return False
        return True
    
    def reset(self):
        self._history.clear()


class DriftDetector(BaseDetector):
    
    def __init__(self, name, callback=None, baseline=None, drift_threshold=0.1):
        super(DriftDetector, self).__init__(name, callback)
        self._baseline = baseline
        self._drift_threshold = drift_threshold
        self._current_samples = []
        self._sample_size = 100
    
    def set_baseline(self, values):
        self._baseline = {
            "mean": sum(values) / len(values),
            "count": len(values)
        }
    
    def detect(self, value):
        if not self._enabled or self._baseline is None:
            return None
        self._current_samples.append(value)
        if len(self._current_samples) > self._sample_size:
            self._current_samples.pop(0)
        if len(self._current_samples) < 10:
            return None
        current_mean = sum(self._current_samples) / len(self._current_samples)
        baseline_mean = self._baseline["mean"]
        if baseline_mean != 0:
            drift = abs(current_mean - baseline_mean) / abs(baseline_mean)
        else:
            drift = abs(current_mean)
        if drift > self._drift_threshold:
            detection = Detection(
                DetectionType.DRIFT,
                self._name,
                "Distribution drift detected: %.2f%%" % (drift * 100),
                severity=2,
                data={
                    "baseline_mean": baseline_mean,
                    "current_mean": current_mean,
                    "drift_percentage": drift * 100
                }
            )
            self._emit_detection(detection)
            return detection
        return None
    
    def reset(self):
        self._current_samples.clear()


class SpikeDetector(BaseDetector):
    
    def __init__(self, name, callback=None, spike_threshold=2.0, cooldown=5.0):
        super(SpikeDetector, self).__init__(name, callback)
        self._spike_threshold = spike_threshold
        self._cooldown = cooldown
        self._last_value = None
        self._last_spike_time = 0
    
    def detect(self, value):
        if not self._enabled:
            return None
        current_time = time.time()
        if current_time - self._last_spike_time < self._cooldown:
            self._last_value = value
            return None
        if self._last_value is not None and self._last_value != 0:
            ratio = abs(value / self._last_value)
            if ratio > self._spike_threshold or (ratio > 0 and 1 / ratio > self._spike_threshold):
                detection = Detection(
                    DetectionType.SPIKE,
                    self._name,
                    "Spike detected: ratio %.2f" % ratio,
                    severity=2,
                    data={
                        "previous_value": self._last_value,
                        "current_value": value,
                        "ratio": ratio
                    }
                )
                self._emit_detection(detection)
                self._last_spike_time = current_time
                self._last_value = value
                return detection
        self._last_value = value
        return None


class DetectorManager:
    
    def __init__(self):
        self._detectors = {}
        self._global_callback = None
        self._lock = threading.Lock()
    
    def add_detector(self, detector):
        with self._lock:
            self._detectors[detector._name] = detector
            if self._global_callback is not None:
                detector._callback = self._global_callback
    
    def remove_detector(self, name):
        with self._lock:
            if name in self._detectors:
                del self._detectors[name]
                return True
            return False
    
    def get_detector(self, name):
        return self._detectors.get(name)
    
    def set_global_callback(self, callback):
        with self._lock:
            self._global_callback = callback
            for detector in self._detectors.values():
                detector._callback = callback
    
    def get_all_detections(self):
        all_detections = []
        for detector in self._detectors.values():
            all_detections.extend(detector.get_detections())
        return sorted(all_detections, key=lambda d: d.timestamp)
    
    def clear_all_detections(self):
        for detector in self._detectors.values():
            detector.clear_detections()
    
    def enable_all(self):
        for detector in self._detectors.values():
            detector.enable()
    
    def disable_all(self):
        for detector in self._detectors.values():
            detector.disable()


_default_manager = None


def get_detector_manager():
    global _default_manager
    if _default_manager is None:
        _default_manager = DetectorManager()
    return _default_manager


def create_change_detector(name, callback=None, sensitivity=0.0):
    detector = ChangeDetector(name, callback, sensitivity)
    get_detector_manager().add_detector(detector)
    return detector


def create_threshold_detector(name, min_val=None, max_val=None, callback=None):
    detector = ThresholdDetector(name, callback, min_val, max_val)
    get_detector_manager().add_detector(detector)
    return detector


def create_anomaly_detector(name, window_size=100, std_threshold=3.0, callback=None):
    detector = AnomalyDetector(name, callback, window_size, std_threshold)
    get_detector_manager().add_detector(detector)
    return detector
