"""
mebytecode v1.0.0 - Complete Python Interpreter Control and Bytecode Manipulation Library

Author: mero
Telegram: @QP4RM
License: MIT
Status: PRODUCTION READY
"""

import sys
import os

__title__ = "mebytecode"
__version__ = "1.0.0"
__version_info__ = (1, 0, 0)
__author__ = "mero"
__author_email__ = "mero@mebytecode.dev"
__telegram__ = "@QP4RM"
__license__ = "MIT"
__copyright__ = "Copyright 2024-2025 mero"
__url__ = "https://github.com/mero/mebytecode"
__description__ = "Complete Python Interpreter Control and Bytecode Manipulation Library"
__status__ = "Production/Stable"

try:
    from . import xcore
    from . import zengine
    from . import vmonitor
    from . import import_system
except ImportError:
    pass

try:
    from .xcore import (
        InterpreterController,
        InterpreterState,
        ExceptionHook,
        DisplayHook,
        get_interpreter,
    )
except ImportError:
    pass

try:
    from .zengine import (
        BytecodeExecutor,
        ExecutionContext,
        ExecutionConfig,
        ExecutionResult,
        execute,
    )
except ImportError:
    pass

try:
    from .vmonitor import (
        Monitor,
        MonitorConfig,
        get_monitor,
    )
except ImportError:
    pass

__all__ = [
    "__title__",
    "__version__",
    "__version_info__",
    "__author__",
    "__author_email__",
    "__telegram__",
    "__license__",
    "__copyright__",
    "__url__",
    "__description__",
    "__status__",
    "xcore",
    "zengine",
    "vmonitor",
    "import_system",
    "InterpreterController",
    "InterpreterState",
    "ExceptionHook",
    "DisplayHook",
    "get_interpreter",
    "BytecodeExecutor",
    "ExecutionContext",
    "ExecutionConfig",
    "ExecutionResult",
    "execute",
    "Monitor",
    "MonitorConfig",
    "get_monitor",
]

def get_info():
    return {
        "title": __title__,
        "version": __version__,
        "author": __author__,
        "telegram": __telegram__,
        "python": "{}.{}.{}".format(*sys.version_info[:3]),
        "description": __description__,
        "status": __status__,
    }
