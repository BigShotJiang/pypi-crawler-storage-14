import sys
import types
import dis
import struct
import marshal
import hashlib

__author__ = "mero"
__version__ = "1.0.0"

PY_VERSION = sys.version_info[:2]


class CodeInfo(object):
    
    def __init__(self, code):
        if not isinstance(code, types.CodeType):
            raise TypeError("Expected code object")
        self._code = code
    
    @property
    def code(self):
        return self._code
    
    @property
    def argcount(self):
        return self._code.co_argcount
    
    @property
    def kwonlyargcount(self):
        return self._code.co_kwonlyargcount
    
    @property
    def nlocals(self):
        return self._code.co_nlocals
    
    @property
    def stacksize(self):
        return self._code.co_stacksize
    
    @property
    def flags(self):
        return self._code.co_flags
    
    @property
    def bytecode(self):
        return self._code.co_code
    
    @property
    def constants(self):
        return self._code.co_consts
    
    @property
    def names(self):
        return self._code.co_names
    
    @property
    def varnames(self):
        return self._code.co_varnames
    
    @property
    def freevars(self):
        return self._code.co_freevars
    
    @property
    def cellvars(self):
        return self._code.co_cellvars
    
    @property
    def filename(self):
        return self._code.co_filename
    
    @property
    def name(self):
        return self._code.co_name
    
    @property
    def firstlineno(self):
        return self._code.co_firstlineno
    
    @property
    def lnotab(self):
        return self._code.co_lnotab
    
    def get_instructions(self):
        return list(dis.get_instructions(self._code))
    
    def get_bytecode_hex(self):
        return self._code.co_code.hex() if hasattr(self._code.co_code, 'hex') else self._code.co_code.encode('hex')
    
    def get_hash(self):
        return hashlib.sha256(self._code.co_code).hexdigest()
    
    def to_dict(self):
        return {
            'argcount': self.argcount,
            'kwonlyargcount': self.kwonlyargcount,
            'nlocals': self.nlocals,
            'stacksize': self.stacksize,
            'flags': self.flags,
            'constants': self.constants,
            'names': self.names,
            'varnames': self.varnames,
            'freevars': self.freevars,
            'cellvars': self.cellvars,
            'filename': self.filename,
            'name': self.name,
            'firstlineno': self.firstlineno
        }


class CodeFlags(object):
    
    CO_OPTIMIZED = 0x0001
    CO_NEWLOCALS = 0x0002
    CO_VARARGS = 0x0004
    CO_VARKEYWORDS = 0x0008
    CO_NESTED = 0x0010
    CO_GENERATOR = 0x0020
    CO_NOFREE = 0x0040
    CO_COROUTINE = 0x0080
    CO_ITERABLE_COROUTINE = 0x0100
    CO_ASYNC_GENERATOR = 0x0200
    
    @staticmethod
    def has_flag(code, flag):
        return (code.co_flags & flag) != 0
    
    @staticmethod
    def is_optimized(code):
        return CodeFlags.has_flag(code, CodeFlags.CO_OPTIMIZED)
    
    @staticmethod
    def has_varargs(code):
        return CodeFlags.has_flag(code, CodeFlags.CO_VARARGS)
    
    @staticmethod
    def has_varkeywords(code):
        return CodeFlags.has_flag(code, CodeFlags.CO_VARKEYWORDS)
    
    @staticmethod
    def is_generator(code):
        return CodeFlags.has_flag(code, CodeFlags.CO_GENERATOR)
    
    @staticmethod
    def is_coroutine(code):
        return CodeFlags.has_flag(code, CodeFlags.CO_COROUTINE)
    
    @staticmethod
    def is_async_generator(code):
        return CodeFlags.has_flag(code, CodeFlags.CO_ASYNC_GENERATOR)
    
    @staticmethod
    def is_nested(code):
        return CodeFlags.has_flag(code, CodeFlags.CO_NESTED)
    
    @staticmethod
    def has_freevars(code):
        return not CodeFlags.has_flag(code, CodeFlags.CO_NOFREE)
    
    @staticmethod
    def get_all_flags(code):
        flags = []
        if CodeFlags.is_optimized(code):
            flags.append('OPTIMIZED')
        if CodeFlags.has_varargs(code):
            flags.append('VARARGS')
        if CodeFlags.has_varkeywords(code):
            flags.append('VARKEYWORDS')
        if CodeFlags.is_generator(code):
            flags.append('GENERATOR')
        if CodeFlags.is_coroutine(code):
            flags.append('COROUTINE')
        if CodeFlags.is_async_generator(code):
            flags.append('ASYNC_GENERATOR')
        if CodeFlags.is_nested(code):
            flags.append('NESTED')
        return flags


class CodeBuilder(object):
    
    def __init__(self, template=None):
        if template is not None and isinstance(template, types.CodeType):
            self._init_from_template(template)
        else:
            self._init_default()
    
    def _init_default(self):
        self._argcount = 0
        self._kwonlyargcount = 0
        self._nlocals = 0
        self._stacksize = 1
        self._flags = 0
        self._code = b''
        self._consts = (None,)
        self._names = ()
        self._varnames = ()
        self._freevars = ()
        self._cellvars = ()
        self._filename = '<generated>'
        self._name = '<code>'
        self._firstlineno = 1
        self._lnotab = b''
        self._posonlyargcount = 0
    
    def _init_from_template(self, template):
        self._argcount = template.co_argcount
        self._kwonlyargcount = template.co_kwonlyargcount
        self._nlocals = template.co_nlocals
        self._stacksize = template.co_stacksize
        self._flags = template.co_flags
        self._code = template.co_code
        self._consts = template.co_consts
        self._names = template.co_names
        self._varnames = template.co_varnames
        self._freevars = template.co_freevars
        self._cellvars = template.co_cellvars
        self._filename = template.co_filename
        self._name = template.co_name
        self._firstlineno = template.co_firstlineno
        self._lnotab = template.co_lnotab
        if PY_VERSION >= (3, 8):
            self._posonlyargcount = template.co_posonlyargcount
        else:
            self._posonlyargcount = 0
    
    def set_argcount(self, count):
        self._argcount = count
        return self
    
    def set_kwonlyargcount(self, count):
        self._kwonlyargcount = count
        return self
    
    def set_nlocals(self, count):
        self._nlocals = count
        return self
    
    def set_stacksize(self, size):
        self._stacksize = size
        return self
    
    def set_flags(self, flags):
        self._flags = flags
        return self
    
    def add_flag(self, flag):
        self._flags |= flag
        return self
    
    def remove_flag(self, flag):
        self._flags &= ~flag
        return self
    
    def set_bytecode(self, bytecode):
        if isinstance(bytecode, str):
            bytecode = bytecode.encode('latin-1')
        self._code = bytes(bytecode)
        return self
    
    def set_constants(self, consts):
        self._consts = tuple(consts)
        return self
    
    def add_constant(self, const):
        if const not in self._consts:
            self._consts = self._consts + (const,)
        return self._consts.index(const)
    
    def set_names(self, names):
        self._names = tuple(names)
        return self
    
    def add_name(self, name):
        if name not in self._names:
            self._names = self._names + (name,)
        return self._names.index(name)
    
    def set_varnames(self, varnames):
        self._varnames = tuple(varnames)
        return self
    
    def set_freevars(self, freevars):
        self._freevars = tuple(freevars)
        return self
    
    def set_cellvars(self, cellvars):
        self._cellvars = tuple(cellvars)
        return self
    
    def set_filename(self, filename):
        self._filename = filename
        return self
    
    def set_name(self, name):
        self._name = name
        return self
    
    def set_firstlineno(self, lineno):
        self._firstlineno = lineno
        return self
    
    def set_lnotab(self, lnotab):
        if isinstance(lnotab, str):
            lnotab = lnotab.encode('latin-1')
        self._lnotab = bytes(lnotab)
        return self
    
    def build(self):
        if PY_VERSION >= (3, 8):
            return types.CodeType(
                self._argcount,
                self._posonlyargcount,
                self._kwonlyargcount,
                self._nlocals,
                self._stacksize,
                self._flags,
                self._code,
                self._consts,
                self._names,
                self._varnames,
                self._filename,
                self._name,
                self._firstlineno,
                self._lnotab,
                self._freevars,
                self._cellvars
            )
        else:
            return types.CodeType(
                self._argcount,
                self._kwonlyargcount,
                self._nlocals,
                self._stacksize,
                self._flags,
                self._code,
                self._consts,
                self._names,
                self._varnames,
                self._filename,
                self._name,
                self._firstlineno,
                self._lnotab,
                self._freevars,
                self._cellvars
            )


class CodeModifier(object):
    
    @staticmethod
    def replace_constants(code, replacements):
        new_consts = list(code.co_consts)
        for old_val, new_val in replacements.items():
            for i, const in enumerate(new_consts):
                if const == old_val:
                    new_consts[i] = new_val
        builder = CodeBuilder(code)
        builder.set_constants(new_consts)
        return builder.build()
    
    @staticmethod
    def replace_names(code, replacements):
        new_names = list(code.co_names)
        for old_name, new_name in replacements.items():
            for i, name in enumerate(new_names):
                if name == old_name:
                    new_names[i] = new_name
        builder = CodeBuilder(code)
        builder.set_names(new_names)
        return builder.build()
    
    @staticmethod
    def replace_varnames(code, replacements):
        new_varnames = list(code.co_varnames)
        for old_name, new_name in replacements.items():
            for i, name in enumerate(new_varnames):
                if name == old_name:
                    new_varnames[i] = new_name
        builder = CodeBuilder(code)
        builder.set_varnames(new_varnames)
        return builder.build()
    
    @staticmethod
    def set_filename(code, filename):
        builder = CodeBuilder(code)
        builder.set_filename(filename)
        return builder.build()
    
    @staticmethod
    def set_name(code, name):
        builder = CodeBuilder(code)
        builder.set_name(name)
        return builder.build()
    
    @staticmethod
    def set_firstlineno(code, lineno):
        builder = CodeBuilder(code)
        builder.set_firstlineno(lineno)
        return builder.build()
    
    @staticmethod
    def add_flag(code, flag):
        builder = CodeBuilder(code)
        builder.add_flag(flag)
        return builder.build()
    
    @staticmethod
    def remove_flag(code, flag):
        builder = CodeBuilder(code)
        builder.remove_flag(flag)
        return builder.build()


class CodeSerializer(object):
    
    @staticmethod
    def to_bytes(code):
        return marshal.dumps(code)
    
    @staticmethod
    def from_bytes(data):
        return marshal.loads(data)
    
    @staticmethod
    def to_dict(code):
        return CodeInfo(code).to_dict()
    
    @staticmethod
    def get_signature(code):
        data = (
            code.co_argcount,
            code.co_kwonlyargcount,
            code.co_nlocals,
            code.co_stacksize,
            code.co_flags,
            code.co_code,
            code.co_consts,
            code.co_names,
            code.co_varnames
        )
        return hashlib.sha256(repr(data).encode()).hexdigest()


class CodeAnalyzer(object):
    
    @staticmethod
    def get_referenced_names(code):
        return list(code.co_names)
    
    @staticmethod
    def get_local_names(code):
        return list(code.co_varnames)
    
    @staticmethod
    def get_free_names(code):
        return list(code.co_freevars)
    
    @staticmethod
    def get_cell_names(code):
        return list(code.co_cellvars)
    
    @staticmethod
    def get_constant_types(code):
        type_counts = {}
        for const in code.co_consts:
            type_name = type(const).__name__
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
        return type_counts
    
    @staticmethod
    def get_nested_codes(code):
        nested = []
        for const in code.co_consts:
            if isinstance(const, types.CodeType):
                nested.append(const)
        return nested
    
    @staticmethod
    def get_all_codes_recursive(code):
        codes = [code]
        for const in code.co_consts:
            if isinstance(const, types.CodeType):
                codes.extend(CodeAnalyzer.get_all_codes_recursive(const))
        return codes
    
    @staticmethod
    def count_instructions(code):
        return len(list(dis.get_instructions(code)))
    
    @staticmethod
    def get_instruction_counts(code):
        counts = {}
        for instr in dis.get_instructions(code):
            counts[instr.opname] = counts.get(instr.opname, 0) + 1
        return counts
    
    @staticmethod
    def has_calls(code):
        call_opcodes = {'CALL_FUNCTION', 'CALL_FUNCTION_KW', 'CALL_FUNCTION_EX', 'CALL_METHOD', 'CALL'}
        for instr in dis.get_instructions(code):
            if instr.opname in call_opcodes:
                return True
        return False
    
    @staticmethod
    def has_loops(code):
        loop_opcodes = {'FOR_ITER', 'JUMP_BACKWARD', 'JUMP_ABSOLUTE'}
        for instr in dis.get_instructions(code):
            if instr.opname in loop_opcodes:
                return True
        return False


def create_code(bytecode, consts=None, names=None, varnames=None, 
                filename='<generated>', name='<code>', argcount=0):
    builder = CodeBuilder()
    builder.set_bytecode(bytecode)
    if consts:
        builder.set_constants(consts)
    if names:
        builder.set_names(names)
    if varnames:
        builder.set_varnames(varnames)
        builder.set_nlocals(len(varnames))
    builder.set_filename(filename)
    builder.set_name(name)
    builder.set_argcount(argcount)
    return builder.build()


def analyze_code(code):
    return CodeInfo(code)


def modify_code(code):
    return CodeBuilder(code)


def serialize_code(code):
    return CodeSerializer.to_bytes(code)


def deserialize_code(data):
    return CodeSerializer.from_bytes(data)
