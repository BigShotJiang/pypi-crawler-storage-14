import sys
import builtins
import types
import weakref

__author__ = "mero"
__version__ = "1.0.0"


class BuiltinsSnapshot(object):
    
    def __init__(self):
        self._snapshot = {}
        self._original_keys = set()
        self._capture()
    
    def _capture(self):
        for name in dir(builtins):
            if not name.startswith('_'):
                self._snapshot[name] = getattr(builtins, name)
                self._original_keys.add(name)
    
    @property
    def snapshot(self):
        return dict(self._snapshot)
    
    @property
    def keys(self):
        return frozenset(self._original_keys)
    
    def get(self, name, default=None):
        return self._snapshot.get(name, default)
    
    def diff(self):
        current = set()
        for name in dir(builtins):
            if not name.startswith('_'):
                current.add(name)
        added = current - self._original_keys
        removed = self._original_keys - current
        modified = set()
        for name in self._original_keys & current:
            try:
                if getattr(builtins, name) is not self._snapshot.get(name):
                    modified.add(name)
            except Exception:
                pass
        return {
            'added': list(added),
            'removed': list(removed),
            'modified': list(modified)
        }


class BuiltinsController(object):
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(BuiltinsController, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._original_builtins = {}
        self._backup_all()
        self._hooks = {}
        self._disabled = set()
        self._snapshots = {}
        self._snapshot_counter = 0
    
    def _backup_all(self):
        for name in dir(builtins):
            if not name.startswith('_'):
                self._original_builtins[name] = getattr(builtins, name)
    
    def get(self, name, default=None):
        return getattr(builtins, name, default)
    
    def get_original(self, name, default=None):
        return self._original_builtins.get(name, default)
    
    def set(self, name, value):
        if not hasattr(builtins, name):
            self._original_builtins[name] = None
        old_value = getattr(builtins, name, None)
        setattr(builtins, name, value)
        return old_value
    
    def delete(self, name):
        if hasattr(builtins, name):
            old_value = getattr(builtins, name)
            delattr(builtins, name)
            return old_value
        return None
    
    def restore(self, name):
        if name in self._original_builtins:
            original = self._original_builtins[name]
            if original is not None:
                setattr(builtins, name, original)
            elif hasattr(builtins, name):
                delattr(builtins, name)
            return True
        return False
    
    def restore_all(self):
        for name, value in self._original_builtins.items():
            if value is not None:
                setattr(builtins, name, value)
        return len(self._original_builtins)
    
    def list_builtins(self):
        return [name for name in dir(builtins) if not name.startswith('_')]
    
    def list_modified(self):
        modified = []
        for name in dir(builtins):
            if not name.startswith('_'):
                current = getattr(builtins, name)
                original = self._original_builtins.get(name)
                if current is not original:
                    modified.append(name)
        return modified
    
    def list_added(self):
        original_set = set(self._original_builtins.keys())
        current_set = set(name for name in dir(builtins) if not name.startswith('_'))
        return list(current_set - original_set)
    
    def save_snapshot(self, name=None):
        if name is None:
            self._snapshot_counter += 1
            name = "snapshot_{0}".format(self._snapshot_counter)
        self._snapshots[name] = BuiltinsSnapshot()
        return name
    
    def restore_snapshot(self, name):
        if name not in self._snapshots:
            raise KeyError("Snapshot '{0}' not found".format(name))
        snapshot = self._snapshots[name]
        for builtin_name, value in snapshot.snapshot.items():
            setattr(builtins, builtin_name, value)
        return True
    
    def delete_snapshot(self, name):
        if name in self._snapshots:
            del self._snapshots[name]
            return True
        return False
    
    def list_snapshots(self):
        return list(self._snapshots.keys())


class BuiltinWrapper(object):
    
    def __init__(self, original, name):
        self._original = original
        self._name = name
        self._pre_hooks = []
        self._post_hooks = []
        self._enabled = True
    
    def __call__(self, *args, **kwargs):
        if not self._enabled:
            return self._original(*args, **kwargs)
        for hook in self._pre_hooks:
            try:
                result = hook(self._name, args, kwargs)
                if result is not None:
                    args, kwargs = result
            except Exception:
                pass
        result = self._original(*args, **kwargs)
        for hook in self._post_hooks:
            try:
                modified_result = hook(self._name, args, kwargs, result)
                if modified_result is not None:
                    result = modified_result
            except Exception:
                pass
        return result
    
    def add_pre_hook(self, hook):
        if callable(hook):
            self._pre_hooks.append(hook)
            return True
        return False
    
    def add_post_hook(self, hook):
        if callable(hook):
            self._post_hooks.append(hook)
            return True
        return False
    
    def remove_pre_hook(self, hook):
        if hook in self._pre_hooks:
            self._pre_hooks.remove(hook)
            return True
        return False
    
    def remove_post_hook(self, hook):
        if hook in self._post_hooks:
            self._post_hooks.remove(hook)
            return True
        return False
    
    def clear_hooks(self):
        count = len(self._pre_hooks) + len(self._post_hooks)
        self._pre_hooks = []
        self._post_hooks = []
        return count
    
    def enable(self):
        self._enabled = True
    
    def disable(self):
        self._enabled = False
    
    @property
    def original(self):
        return self._original


class BuiltinsHooker(object):
    
    def __init__(self):
        self._wrappers = {}
        self._controller = BuiltinsController()
    
    def hook(self, name):
        if name in self._wrappers:
            return self._wrappers[name]
        original = getattr(builtins, name, None)
        if original is None:
            raise ValueError("Builtin '{0}' not found".format(name))
        wrapper = BuiltinWrapper(original, name)
        self._wrappers[name] = wrapper
        setattr(builtins, name, wrapper)
        return wrapper
    
    def unhook(self, name):
        if name in self._wrappers:
            wrapper = self._wrappers.pop(name)
            setattr(builtins, name, wrapper.original)
            return True
        return False
    
    def unhook_all(self):
        count = 0
        for name, wrapper in list(self._wrappers.items()):
            setattr(builtins, name, wrapper.original)
            count += 1
        self._wrappers.clear()
        return count
    
    def get_wrapper(self, name):
        return self._wrappers.get(name)
    
    def list_hooked(self):
        return list(self._wrappers.keys())
    
    def is_hooked(self, name):
        return name in self._wrappers


class BuiltinsFilter(object):
    
    @staticmethod
    def functions():
        result = {}
        for name in dir(builtins):
            if not name.startswith('_'):
                obj = getattr(builtins, name)
                if isinstance(obj, types.BuiltinFunctionType):
                    result[name] = obj
        return result
    
    @staticmethod
    def types():
        result = {}
        for name in dir(builtins):
            if not name.startswith('_'):
                obj = getattr(builtins, name)
                if isinstance(obj, type):
                    result[name] = obj
        return result
    
    @staticmethod
    def exceptions():
        result = {}
        for name in dir(builtins):
            if not name.startswith('_'):
                obj = getattr(builtins, name)
                if isinstance(obj, type) and issubclass(obj, BaseException):
                    result[name] = obj
        return result
    
    @staticmethod
    def constants():
        result = {}
        for name in dir(builtins):
            if not name.startswith('_'):
                obj = getattr(builtins, name)
                if not callable(obj) and not isinstance(obj, type):
                    result[name] = obj
        return result
    
    @staticmethod
    def by_prefix(prefix):
        result = {}
        for name in dir(builtins):
            if name.startswith(prefix):
                result[name] = getattr(builtins, name)
        return result


class BuiltinsInjector(object):
    
    def __init__(self):
        self._controller = BuiltinsController()
        self._injected = set()
    
    def inject(self, name, value):
        self._controller.set(name, value)
        self._injected.add(name)
        return True
    
    def inject_many(self, items):
        for name, value in items.items():
            self._controller.set(name, value)
            self._injected.add(name)
        return len(items)
    
    def remove_injected(self, name):
        if name in self._injected:
            self._controller.restore(name)
            self._injected.remove(name)
            return True
        return False
    
    def remove_all_injected(self):
        count = 0
        for name in list(self._injected):
            self._controller.restore(name)
            count += 1
        self._injected.clear()
        return count
    
    def list_injected(self):
        return list(self._injected)


def get_controller():
    return BuiltinsController()


def get_hooker():
    return BuiltinsHooker()


def get_filter():
    return BuiltinsFilter()


def get_injector():
    return BuiltinsInjector()


def snapshot():
    return BuiltinsSnapshot()


def get_builtin(name, default=None):
    return getattr(builtins, name, default)


def set_builtin(name, value):
    controller = BuiltinsController()
    return controller.set(name, value)


def restore_builtin(name):
    controller = BuiltinsController()
    return controller.restore(name)


def restore_all_builtins():
    controller = BuiltinsController()
    return controller.restore_all()
