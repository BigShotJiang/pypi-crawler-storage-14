import sys
import threading
import weakref
import time
import ctypes

__author__ = "mero"
__version__ = "1.0.0"


class ThreadInfo(object):
    
    def __init__(self, thread):
        if not isinstance(thread, threading.Thread):
            raise TypeError("Expected Thread object")
        self._thread_ref = weakref.ref(thread)
    
    @property
    def thread(self):
        return self._thread_ref()
    
    @property
    def name(self):
        thread = self.thread
        if thread is not None:
            return thread.name
        return None
    
    @property
    def ident(self):
        thread = self.thread
        if thread is not None:
            return thread.ident
        return None
    
    @property
    def daemon(self):
        thread = self.thread
        if thread is not None:
            return thread.daemon
        return None
    
    def is_alive(self):
        thread = self.thread
        if thread is not None:
            return thread.is_alive()
        return False
    
    def is_main(self):
        thread = self.thread
        if thread is not None:
            return thread is threading.main_thread()
        return False
    
    def get_frame(self):
        thread = self.thread
        if thread is not None and thread.is_alive():
            frames = sys._current_frames()
            return frames.get(thread.ident)
        return None
    
    def to_dict(self):
        thread = self.thread
        if thread is None:
            return {}
        return {
            'name': thread.name,
            'ident': thread.ident,
            'daemon': thread.daemon,
            'alive': thread.is_alive(),
            'is_main': self.is_main()
        }


class ThreadsController(object):
    
    def __init__(self):
        self._tracked = weakref.WeakValueDictionary()
        self._thread_hooks = {}
        self._start_hooks = []
        self._stop_hooks = []
    
    def get_current(self):
        return threading.current_thread()
    
    def get_main(self):
        return threading.main_thread()
    
    def get_all(self):
        return list(threading.enumerate())
    
    def get_by_name(self, name):
        for thread in threading.enumerate():
            if thread.name == name:
                return thread
        return None
    
    def get_by_ident(self, ident):
        for thread in threading.enumerate():
            if thread.ident == ident:
                return thread
        return None
    
    def count(self):
        return threading.active_count()
    
    def list_names(self):
        return [t.name for t in threading.enumerate()]
    
    def list_idents(self):
        return [t.ident for t in threading.enumerate()]
    
    def list_alive(self):
        return [t for t in threading.enumerate() if t.is_alive()]
    
    def list_daemon(self):
        return [t for t in threading.enumerate() if t.daemon]
    
    def get_frames(self):
        return sys._current_frames()
    
    def get_frame_for_thread(self, thread):
        if isinstance(thread, int):
            ident = thread
        elif isinstance(thread, threading.Thread):
            ident = thread.ident
        else:
            return None
        frames = sys._current_frames()
        return frames.get(ident)
    
    def track(self, thread, key=None):
        if key is None:
            key = thread.name
        self._tracked[key] = thread
        return key
    
    def untrack(self, key):
        if key in self._tracked:
            del self._tracked[key]
            return True
        return False
    
    def get_tracked(self, key):
        return self._tracked.get(key)
    
    def list_tracked(self):
        return list(self._tracked.keys())


class ThreadMonitor(object):
    
    def __init__(self):
        self._samples = []
        self._monitoring = False
        self._monitor_thread = None
        self._interval = 1.0
        self._max_samples = 1000
    
    def _monitor_loop(self):
        while self._monitoring:
            sample = {
                'timestamp': time.time(),
                'thread_count': threading.active_count(),
                'threads': []
            }
            for thread in threading.enumerate():
                sample['threads'].append({
                    'name': thread.name,
                    'ident': thread.ident,
                    'alive': thread.is_alive(),
                    'daemon': thread.daemon
                })
            if len(self._samples) >= self._max_samples:
                self._samples.pop(0)
            self._samples.append(sample)
            time.sleep(self._interval)
    
    def start(self, interval=1.0):
        if self._monitoring:
            return False
        self._interval = interval
        self._monitoring = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name='ThreadMonitor',
            daemon=True
        )
        self._monitor_thread.start()
        return True
    
    def stop(self):
        if not self._monitoring:
            return False
        self._monitoring = False
        if self._monitor_thread is not None:
            self._monitor_thread.join(timeout=2.0)
        return True
    
    def is_running(self):
        return self._monitoring
    
    def get_samples(self):
        return list(self._samples)
    
    def get_latest(self):
        if self._samples:
            return self._samples[-1]
        return None
    
    def clear_samples(self):
        count = len(self._samples)
        self._samples = []
        return count
    
    def set_max_samples(self, max_samples):
        old_max = self._max_samples
        self._max_samples = max_samples
        return old_max


class ThreadBuilder(object):
    
    def __init__(self):
        self._target = None
        self._args = ()
        self._kwargs = {}
        self._name = None
        self._daemon = False
        self._group = None
    
    def set_target(self, target):
        if not callable(target):
            raise TypeError("Target must be callable")
        self._target = target
        return self
    
    def set_args(self, *args):
        self._args = args
        return self
    
    def set_kwargs(self, **kwargs):
        self._kwargs = kwargs
        return self
    
    def set_name(self, name):
        self._name = name
        return self
    
    def set_daemon(self, daemon):
        self._daemon = daemon
        return self
    
    def build(self):
        if self._target is None:
            raise ValueError("Target is required")
        thread = threading.Thread(
            group=self._group,
            target=self._target,
            name=self._name,
            args=self._args,
            kwargs=self._kwargs,
            daemon=self._daemon
        )
        return thread
    
    def build_and_start(self):
        thread = self.build()
        thread.start()
        return thread


class ThreadPool(object):
    
    def __init__(self, max_workers=4):
        self._max_workers = max_workers
        self._workers = []
        self._tasks = []
        self._lock = threading.Lock()
        self._running = False
        self._stop_event = threading.Event()
    
    def _worker_loop(self):
        while not self._stop_event.is_set():
            task = None
            with self._lock:
                if self._tasks:
                    task = self._tasks.pop(0)
            if task is not None:
                try:
                    func, args, kwargs = task
                    func(*args, **kwargs)
                except Exception:
                    pass
            else:
                time.sleep(0.01)
    
    def start(self):
        if self._running:
            return False
        self._running = True
        self._stop_event.clear()
        for i in range(self._max_workers):
            worker = threading.Thread(
                target=self._worker_loop,
                name="PoolWorker-{0}".format(i),
                daemon=True
            )
            worker.start()
            self._workers.append(worker)
        return True
    
    def stop(self, wait=True):
        if not self._running:
            return False
        self._stop_event.set()
        if wait:
            for worker in self._workers:
                worker.join(timeout=2.0)
        self._workers = []
        self._running = False
        return True
    
    def submit(self, func, *args, **kwargs):
        if not self._running:
            raise RuntimeError("Pool is not running")
        with self._lock:
            self._tasks.append((func, args, kwargs))
        return True
    
    def pending_count(self):
        with self._lock:
            return len(self._tasks)
    
    def worker_count(self):
        return len([w for w in self._workers if w.is_alive()])


class ThreadSynchronizer(object):
    
    def __init__(self):
        self._locks = {}
        self._events = {}
        self._conditions = {}
        self._semaphores = {}
        self._barriers = {}
    
    def create_lock(self, name):
        if name not in self._locks:
            self._locks[name] = threading.Lock()
        return self._locks[name]
    
    def create_rlock(self, name):
        if name not in self._locks:
            self._locks[name] = threading.RLock()
        return self._locks[name]
    
    def create_event(self, name):
        if name not in self._events:
            self._events[name] = threading.Event()
        return self._events[name]
    
    def create_condition(self, name, lock=None):
        if name not in self._conditions:
            self._conditions[name] = threading.Condition(lock)
        return self._conditions[name]
    
    def create_semaphore(self, name, value=1):
        if name not in self._semaphores:
            self._semaphores[name] = threading.Semaphore(value)
        return self._semaphores[name]
    
    def create_barrier(self, name, parties):
        if name not in self._barriers:
            self._barriers[name] = threading.Barrier(parties)
        return self._barriers[name]
    
    def get_lock(self, name):
        return self._locks.get(name)
    
    def get_event(self, name):
        return self._events.get(name)
    
    def get_condition(self, name):
        return self._conditions.get(name)
    
    def get_semaphore(self, name):
        return self._semaphores.get(name)
    
    def get_barrier(self, name):
        return self._barriers.get(name)
    
    def remove_lock(self, name):
        if name in self._locks:
            del self._locks[name]
            return True
        return False
    
    def remove_event(self, name):
        if name in self._events:
            del self._events[name]
            return True
        return False
    
    def clear_all(self):
        count = (len(self._locks) + len(self._events) + 
                len(self._conditions) + len(self._semaphores) + 
                len(self._barriers))
        self._locks.clear()
        self._events.clear()
        self._conditions.clear()
        self._semaphores.clear()
        self._barriers.clear()
        return count


def get_controller():
    return ThreadsController()


def get_monitor():
    return ThreadMonitor()


def get_builder():
    return ThreadBuilder()


def get_pool(max_workers=4):
    return ThreadPool(max_workers)


def get_synchronizer():
    return ThreadSynchronizer()


def info(thread):
    return ThreadInfo(thread)


def current():
    return threading.current_thread()


def main():
    return threading.main_thread()


def all_threads():
    return list(threading.enumerate())


def count():
    return threading.active_count()
