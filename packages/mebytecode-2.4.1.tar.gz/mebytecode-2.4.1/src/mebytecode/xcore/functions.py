import sys
import types
import functools
import weakref
import inspect

__author__ = "mero"
__version__ = "1.0.0"


class FunctionInfo(object):
    
    def __init__(self, func):
        if not callable(func):
            raise TypeError("Expected callable object")
        self._func = func
        self._is_function = isinstance(func, types.FunctionType)
        self._is_method = isinstance(func, types.MethodType)
        self._is_builtin = isinstance(func, types.BuiltinFunctionType)
    
    @property
    def func(self):
        return self._func
    
    @property
    def name(self):
        return getattr(self._func, '__name__', str(self._func))
    
    @property
    def qualname(self):
        return getattr(self._func, '__qualname__', self.name)
    
    @property
    def module(self):
        return getattr(self._func, '__module__', None)
    
    @property
    def doc(self):
        return getattr(self._func, '__doc__', None)
    
    @property
    def annotations(self):
        return getattr(self._func, '__annotations__', {})
    
    @property
    def defaults(self):
        return getattr(self._func, '__defaults__', None)
    
    @property
    def kwdefaults(self):
        return getattr(self._func, '__kwdefaults__', None)
    
    @property
    def globals(self):
        if self._is_function:
            return self._func.__globals__
        return None
    
    @property
    def closure(self):
        if self._is_function:
            return self._func.__closure__
        return None
    
    @property
    def code(self):
        if self._is_function:
            return self._func.__code__
        return None
    
    @property
    def dict(self):
        return getattr(self._func, '__dict__', {})
    
    def is_function(self):
        return self._is_function
    
    def is_method(self):
        return self._is_method
    
    def is_builtin(self):
        return self._is_builtin
    
    def is_lambda(self):
        return self._is_function and self._func.__name__ == '<lambda>'
    
    def is_generator(self):
        if self._is_function:
            return (self._func.__code__.co_flags & 0x20) != 0
        return False
    
    def is_coroutine(self):
        if self._is_function:
            return (self._func.__code__.co_flags & 0x80) != 0
        return False
    
    def is_async_generator(self):
        if self._is_function:
            return (self._func.__code__.co_flags & 0x200) != 0
        return False
    
    def get_argcount(self):
        if self._is_function:
            return self._func.__code__.co_argcount
        return 0
    
    def get_argnames(self):
        if self._is_function:
            code = self._func.__code__
            return list(code.co_varnames[:code.co_argcount])
        return []
    
    def get_closure_vars(self):
        if self._is_function and self._func.__closure__:
            freevars = self._func.__code__.co_freevars
            result = {}
            for i, name in enumerate(freevars):
                if i < len(self._func.__closure__):
                    try:
                        result[name] = self._func.__closure__[i].cell_contents
                    except ValueError:
                        result[name] = None
            return result
        return {}
    
    def to_dict(self):
        return {
            'name': self.name,
            'qualname': self.qualname,
            'module': self.module,
            'is_function': self._is_function,
            'is_method': self._is_method,
            'is_builtin': self._is_builtin,
            'is_generator': self.is_generator(),
            'is_coroutine': self.is_coroutine(),
            'argcount': self.get_argcount(),
            'argnames': self.get_argnames()
        }


class FunctionModifier(object):
    
    @staticmethod
    def set_name(func, name):
        if isinstance(func, types.FunctionType):
            func.__name__ = name
            return True
        return False
    
    @staticmethod
    def set_qualname(func, qualname):
        if isinstance(func, types.FunctionType):
            func.__qualname__ = qualname
            return True
        return False
    
    @staticmethod
    def set_module(func, module):
        if hasattr(func, '__module__'):
            func.__module__ = module
            return True
        return False
    
    @staticmethod
    def set_doc(func, doc):
        if hasattr(func, '__doc__'):
            func.__doc__ = doc
            return True
        return False
    
    @staticmethod
    def set_annotations(func, annotations):
        if isinstance(func, types.FunctionType):
            func.__annotations__ = annotations
            return True
        return False
    
    @staticmethod
    def set_defaults(func, defaults):
        if isinstance(func, types.FunctionType):
            func.__defaults__ = defaults
            return True
        return False
    
    @staticmethod
    def set_kwdefaults(func, kwdefaults):
        if isinstance(func, types.FunctionType):
            func.__kwdefaults__ = kwdefaults
            return True
        return False
    
    @staticmethod
    def set_globals(func, name, value):
        if isinstance(func, types.FunctionType):
            func.__globals__[name] = value
            return True
        return False
    
    @staticmethod
    def set_code(func, code):
        if isinstance(func, types.FunctionType) and isinstance(code, types.CodeType):
            func.__code__ = code
            return True
        return False
    
    @staticmethod
    def set_dict_item(func, key, value):
        if hasattr(func, '__dict__'):
            func.__dict__[key] = value
            return True
        return False
    
    @staticmethod
    def clear_dict(func):
        if hasattr(func, '__dict__') and isinstance(func.__dict__, dict):
            func.__dict__.clear()
            return True
        return False


class FunctionBuilder(object):
    
    def __init__(self, template=None):
        self._code = None
        self._globals = {}
        self._name = None
        self._argdefs = None
        self._closure = None
        self._kwdefaults = None
        self._annotations = {}
        self._doc = None
        if template is not None and isinstance(template, types.FunctionType):
            self._init_from_template(template)
    
    def _init_from_template(self, template):
        self._code = template.__code__
        self._globals = dict(template.__globals__)
        self._name = template.__name__
        self._argdefs = template.__defaults__
        self._closure = template.__closure__
        self._kwdefaults = template.__kwdefaults__
        self._annotations = dict(template.__annotations__) if template.__annotations__ else {}
        self._doc = template.__doc__
    
    def set_code(self, code):
        if not isinstance(code, types.CodeType):
            raise TypeError("Expected code object")
        self._code = code
        return self
    
    def set_globals(self, globals_dict):
        if not isinstance(globals_dict, dict):
            raise TypeError("Expected dict for globals")
        self._globals = globals_dict
        return self
    
    def update_globals(self, updates):
        self._globals.update(updates)
        return self
    
    def set_name(self, name):
        self._name = name
        return self
    
    def set_defaults(self, defaults):
        self._argdefs = defaults
        return self
    
    def set_closure(self, closure):
        self._closure = closure
        return self
    
    def set_kwdefaults(self, kwdefaults):
        self._kwdefaults = kwdefaults
        return self
    
    def set_annotations(self, annotations):
        self._annotations = annotations
        return self
    
    def set_doc(self, doc):
        self._doc = doc
        return self
    
    def build(self):
        if self._code is None:
            raise ValueError("Code object is required")
        if self._name is None:
            self._name = self._code.co_name
        func = types.FunctionType(
            self._code,
            self._globals,
            self._name,
            self._argdefs,
            self._closure
        )
        if self._kwdefaults:
            func.__kwdefaults__ = self._kwdefaults
        if self._annotations:
            func.__annotations__ = self._annotations
        if self._doc:
            func.__doc__ = self._doc
        return func


class FunctionWrapper(object):
    
    def __init__(self, func):
        if not callable(func):
            raise TypeError("Expected callable")
        self._func = func
        self._pre_hooks = []
        self._post_hooks = []
        self._error_hooks = []
        self._wrapper = None
        self._call_count = 0
        self._enabled = True
    
    def add_pre_hook(self, hook):
        if callable(hook):
            self._pre_hooks.append(hook)
            self._rebuild_wrapper()
            return True
        return False
    
    def add_post_hook(self, hook):
        if callable(hook):
            self._post_hooks.append(hook)
            self._rebuild_wrapper()
            return True
        return False
    
    def add_error_hook(self, hook):
        if callable(hook):
            self._error_hooks.append(hook)
            self._rebuild_wrapper()
            return True
        return False
    
    def remove_pre_hook(self, hook):
        if hook in self._pre_hooks:
            self._pre_hooks.remove(hook)
            self._rebuild_wrapper()
            return True
        return False
    
    def remove_post_hook(self, hook):
        if hook in self._post_hooks:
            self._post_hooks.remove(hook)
            self._rebuild_wrapper()
            return True
        return False
    
    def clear_hooks(self):
        count = len(self._pre_hooks) + len(self._post_hooks) + len(self._error_hooks)
        self._pre_hooks = []
        self._post_hooks = []
        self._error_hooks = []
        self._rebuild_wrapper()
        return count
    
    def _rebuild_wrapper(self):
        func = self._func
        pre_hooks = self._pre_hooks
        post_hooks = self._post_hooks
        error_hooks = self._error_hooks
        wrapper_ref = weakref.ref(self)
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            wrapper_obj = wrapper_ref()
            if wrapper_obj is None or not wrapper_obj._enabled:
                return func(*args, **kwargs)
            wrapper_obj._call_count += 1
            for hook in pre_hooks:
                try:
                    hook(func, args, kwargs)
                except Exception:
                    pass
            try:
                result = func(*args, **kwargs)
                for hook in post_hooks:
                    try:
                        hook(func, args, kwargs, result)
                    except Exception:
                        pass
                return result
            except Exception as e:
                for hook in error_hooks:
                    try:
                        hook(func, args, kwargs, e)
                    except Exception:
                        pass
                raise
        
        self._wrapper = wrapper
    
    def get_wrapper(self):
        if self._wrapper is None:
            self._rebuild_wrapper()
        return self._wrapper
    
    def enable(self):
        self._enabled = True
    
    def disable(self):
        self._enabled = False
    
    def get_call_count(self):
        return self._call_count
    
    def reset_call_count(self):
        old_count = self._call_count
        self._call_count = 0
        return old_count


class FunctionCopier(object):
    
    @staticmethod
    def shallow_copy(func):
        if not isinstance(func, types.FunctionType):
            raise TypeError("Expected function object")
        return types.FunctionType(
            func.__code__,
            func.__globals__,
            func.__name__,
            func.__defaults__,
            func.__closure__
        )
    
    @staticmethod
    def deep_copy(func):
        if not isinstance(func, types.FunctionType):
            raise TypeError("Expected function object")
        new_func = types.FunctionType(
            func.__code__,
            dict(func.__globals__),
            func.__name__,
            func.__defaults__,
            func.__closure__
        )
        if func.__kwdefaults__:
            new_func.__kwdefaults__ = dict(func.__kwdefaults__)
        if func.__annotations__:
            new_func.__annotations__ = dict(func.__annotations__)
        new_func.__doc__ = func.__doc__
        new_func.__dict__.update(func.__dict__)
        return new_func
    
    @staticmethod
    def with_new_globals(func, new_globals):
        if not isinstance(func, types.FunctionType):
            raise TypeError("Expected function object")
        merged_globals = dict(func.__globals__)
        merged_globals.update(new_globals)
        return types.FunctionType(
            func.__code__,
            merged_globals,
            func.__name__,
            func.__defaults__,
            func.__closure__
        )


class FunctionRegistry(object):
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(FunctionRegistry, cls).__new__(cls)
            cls._instance._registry = {}
            cls._instance._weak_registry = weakref.WeakValueDictionary()
        return cls._instance
    
    def register(self, name, func, weak=False):
        if weak:
            self._weak_registry[name] = func
        else:
            self._registry[name] = func
        return True
    
    def unregister(self, name):
        removed = False
        if name in self._registry:
            del self._registry[name]
            removed = True
        if name in self._weak_registry:
            del self._weak_registry[name]
            removed = True
        return removed
    
    def get(self, name):
        if name in self._registry:
            return self._registry[name]
        return self._weak_registry.get(name)
    
    def list_all(self):
        names = set(self._registry.keys())
        names.update(self._weak_registry.keys())
        return list(names)
    
    def clear(self):
        count = len(self._registry) + len(self._weak_registry)
        self._registry.clear()
        self._weak_registry.clear()
        return count


def info(func):
    return FunctionInfo(func)


def modify(func):
    return FunctionModifier()


def build(template=None):
    return FunctionBuilder(template)


def wrap(func):
    return FunctionWrapper(func)


def copy(func, deep=False):
    if deep:
        return FunctionCopier.deep_copy(func)
    return FunctionCopier.shallow_copy(func)


def get_registry():
    return FunctionRegistry()
