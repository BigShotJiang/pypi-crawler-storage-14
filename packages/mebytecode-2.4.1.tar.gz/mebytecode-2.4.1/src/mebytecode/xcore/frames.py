import sys
import types
import weakref
import ctypes
import inspect

__author__ = "mero"
__version__ = "1.0.0"


class FrameInfo(object):
    
    def __init__(self, frame):
        self._frame_ref = weakref.ref(frame) if frame is not None else None
        self._snapshot = None
        if frame is not None:
            self._create_snapshot(frame)
    
    def _create_snapshot(self, frame):
        self._snapshot = {
            'filename': frame.f_code.co_filename,
            'lineno': frame.f_lineno,
            'name': frame.f_code.co_name,
            'locals_keys': list(frame.f_locals.keys()),
            'globals_keys': list(frame.f_globals.keys()),
            'lasti': frame.f_lasti,
            'code_name': frame.f_code.co_name,
            'code_argcount': frame.f_code.co_argcount,
            'code_nlocals': frame.f_code.co_nlocals,
            'code_stacksize': frame.f_code.co_stacksize,
            'code_flags': frame.f_code.co_flags
        }
    
    @property
    def frame(self):
        if self._frame_ref is not None:
            return self._frame_ref()
        return None
    
    @property
    def filename(self):
        frame = self.frame
        if frame is not None:
            return frame.f_code.co_filename
        return self._snapshot.get('filename') if self._snapshot else None
    
    @property
    def lineno(self):
        frame = self.frame
        if frame is not None:
            return frame.f_lineno
        return self._snapshot.get('lineno') if self._snapshot else None
    
    @property
    def name(self):
        frame = self.frame
        if frame is not None:
            return frame.f_code.co_name
        return self._snapshot.get('name') if self._snapshot else None
    
    @property
    def locals(self):
        frame = self.frame
        if frame is not None:
            return dict(frame.f_locals)
        return None
    
    @property
    def globals(self):
        frame = self.frame
        if frame is not None:
            return dict(frame.f_globals)
        return None
    
    @property
    def builtins(self):
        frame = self.frame
        if frame is not None:
            return frame.f_builtins
        return None
    
    @property
    def code(self):
        frame = self.frame
        if frame is not None:
            return frame.f_code
        return None
    
    @property
    def back(self):
        frame = self.frame
        if frame is not None and frame.f_back is not None:
            return FrameInfo(frame.f_back)
        return None
    
    def is_alive(self):
        return self.frame is not None
    
    def to_dict(self):
        if self._snapshot:
            return dict(self._snapshot)
        return {}


class FrameStack(object):
    
    def __init__(self):
        self._frames = []
    
    def capture(self, depth=None):
        self._frames = []
        frame = sys._getframe()
        if frame.f_back is not None:
            frame = frame.f_back
        count = 0
        while frame is not None:
            if depth is not None and count >= depth:
                break
            self._frames.append(FrameInfo(frame))
            frame = frame.f_back
            count += 1
        return len(self._frames)
    
    def __len__(self):
        return len(self._frames)
    
    def __getitem__(self, index):
        return self._frames[index]
    
    def __iter__(self):
        return iter(self._frames)
    
    def get_frame(self, index):
        if 0 <= index < len(self._frames):
            return self._frames[index]
        return None
    
    def get_all(self):
        return list(self._frames)
    
    def clear(self):
        count = len(self._frames)
        self._frames = []
        return count


class FrameInspector(object):
    
    @staticmethod
    def get_current_frame():
        frame = sys._getframe()
        if frame.f_back is not None:
            return frame.f_back
        return frame
    
    @staticmethod
    def get_caller_frame(depth=1):
        frame = sys._getframe()
        for _ in range(depth + 1):
            if frame.f_back is not None:
                frame = frame.f_back
            else:
                break
        return frame
    
    @staticmethod
    def get_frame_at_depth(depth):
        frame = sys._getframe()
        for _ in range(depth + 1):
            if frame.f_back is not None:
                frame = frame.f_back
            else:
                return None
        return frame
    
    @staticmethod
    def get_frame_chain():
        frames = []
        frame = sys._getframe()
        if frame.f_back is not None:
            frame = frame.f_back
        while frame is not None:
            frames.append(frame)
            frame = frame.f_back
        return frames
    
    @staticmethod
    def get_frame_info(frame):
        return FrameInfo(frame)
    
    @staticmethod
    def get_local_variable(frame, name):
        if name in frame.f_locals:
            return frame.f_locals[name]
        return None
    
    @staticmethod
    def get_all_locals(frame):
        return dict(frame.f_locals)
    
    @staticmethod
    def get_global_variable(frame, name):
        if name in frame.f_globals:
            return frame.f_globals[name]
        return None
    
    @staticmethod
    def get_all_globals(frame):
        return dict(frame.f_globals)
    
    @staticmethod
    def get_free_variables(frame):
        code = frame.f_code
        freevars = code.co_freevars
        result = {}
        if hasattr(frame, 'f_closure') and frame.f_closure:
            for i, name in enumerate(freevars):
                if i < len(frame.f_closure):
                    cell = frame.f_closure[i]
                    try:
                        result[name] = cell.cell_contents
                    except ValueError:
                        result[name] = None
        return result
    
    @staticmethod
    def get_instruction_pointer(frame):
        return frame.f_lasti
    
    @staticmethod
    def get_line_number(frame):
        return frame.f_lineno
    
    @staticmethod
    def get_code_object(frame):
        return frame.f_code


class FrameModifier(object):
    
    _CTYPES_AVAILABLE = True
    
    @staticmethod
    def _get_frame_struct():
        try:
            class PyObject(ctypes.Structure):
                pass
            PyObject._fields_ = [
                ('ob_refcnt', ctypes.c_ssize_t),
                ('ob_type', ctypes.POINTER(PyObject)),
            ]
            return PyObject
        except Exception:
            return None
    
    @staticmethod
    def set_local_variable(frame, name, value):
        frame.f_locals[name] = value
        ctypes.pythonapi.PyFrame_LocalsToFast(
            ctypes.py_object(frame),
            ctypes.c_int(0)
        )
        return True
    
    @staticmethod
    def update_locals(frame, updates):
        for name, value in updates.items():
            frame.f_locals[name] = value
        ctypes.pythonapi.PyFrame_LocalsToFast(
            ctypes.py_object(frame),
            ctypes.c_int(0)
        )
        return len(updates)
    
    @staticmethod
    def delete_local_variable(frame, name):
        if name in frame.f_locals:
            del frame.f_locals[name]
            ctypes.pythonapi.PyFrame_LocalsToFast(
                ctypes.py_object(frame),
                ctypes.c_int(0)
            )
            return True
        return False
    
    @staticmethod
    def set_global_variable(frame, name, value):
        frame.f_globals[name] = value
        return True
    
    @staticmethod
    def delete_global_variable(frame, name):
        if name in frame.f_globals:
            del frame.f_globals[name]
            return True
        return False
    
    @staticmethod
    def set_line_number(frame, lineno):
        if hasattr(frame, 'f_lineno'):
            try:
                frame.f_lineno = lineno
                return True
            except ValueError:
                return False
        return False


class FrameBuilder(object):
    
    def __init__(self):
        self._code = None
        self._globals = None
        self._locals = None
        self._closure = None
    
    def set_code(self, code):
        if not isinstance(code, types.CodeType):
            raise TypeError("Expected code object")
        self._code = code
        return self
    
    def set_globals(self, globals_dict):
        if not isinstance(globals_dict, dict):
            raise TypeError("Expected dict for globals")
        self._globals = globals_dict
        return self
    
    def set_locals(self, locals_dict):
        if not isinstance(locals_dict, dict):
            raise TypeError("Expected dict for locals")
        self._locals = locals_dict
        return self
    
    def set_closure(self, closure):
        self._closure = closure
        return self
    
    def execute(self):
        if self._code is None:
            raise ValueError("Code object is required")
        if self._globals is None:
            self._globals = {}
        if self._locals is None:
            self._locals = {}
        exec(self._code, self._globals, self._locals)
        return self._locals


class FrameTracer(object):
    
    def __init__(self):
        self._trace_func = None
        self._frame_events = []
        self._active = False
        self._max_events = 10000
    
    def _trace_handler(self, frame, event, arg):
        if len(self._frame_events) < self._max_events:
            self._frame_events.append({
                'frame_id': id(frame),
                'filename': frame.f_code.co_filename,
                'lineno': frame.f_lineno,
                'name': frame.f_code.co_name,
                'event': event,
                'arg': str(arg) if arg is not None else None
            })
        return self._trace_handler
    
    def start(self):
        if not self._active:
            self._frame_events = []
            sys.settrace(self._trace_handler)
            self._active = True
        return self._active
    
    def stop(self):
        if self._active:
            sys.settrace(None)
            self._active = False
        return not self._active
    
    def get_events(self):
        return list(self._frame_events)
    
    def clear_events(self):
        count = len(self._frame_events)
        self._frame_events = []
        return count
    
    def set_max_events(self, max_events):
        old_max = self._max_events
        self._max_events = max_events
        return old_max
    
    def is_active(self):
        return self._active


class FrameAnalyzer(object):
    
    @staticmethod
    def get_call_info(frame):
        return {
            'function': frame.f_code.co_name,
            'filename': frame.f_code.co_filename,
            'line': frame.f_lineno,
            'module': frame.f_globals.get('__name__', '<unknown>'),
            'argcount': frame.f_code.co_argcount,
            'nlocals': frame.f_code.co_nlocals
        }
    
    @staticmethod
    def get_argument_info(frame):
        code = frame.f_code
        argcount = code.co_argcount
        varnames = code.co_varnames[:argcount]
        args = {}
        for name in varnames:
            if name in frame.f_locals:
                args[name] = frame.f_locals[name]
        return args
    
    @staticmethod
    def get_stack_depth(frame):
        depth = 0
        while frame is not None:
            depth += 1
            frame = frame.f_back
        return depth
    
    @staticmethod
    def find_frame_by_name(name, frame=None):
        if frame is None:
            frame = sys._getframe().f_back
        while frame is not None:
            if frame.f_code.co_name == name:
                return frame
            frame = frame.f_back
        return None
    
    @staticmethod
    def find_frame_by_filename(filename, frame=None):
        if frame is None:
            frame = sys._getframe().f_back
        while frame is not None:
            if filename in frame.f_code.co_filename:
                return frame
            frame = frame.f_back
        return None
    
    @staticmethod
    def get_exception_info(frame):
        exc_info = sys.exc_info()
        return {
            'type': exc_info[0],
            'value': exc_info[1],
            'traceback': exc_info[2]
        }


def get_current():
    return sys._getframe().f_back


def get_caller(depth=1):
    return FrameInspector.get_caller_frame(depth + 1)


def get_stack():
    stack = FrameStack()
    stack.capture()
    return stack


def inspect_frame(frame):
    return FrameInfo(frame)


def trace_frames():
    return FrameTracer()


def analyze_frame(frame):
    return FrameAnalyzer.get_call_info(frame)
