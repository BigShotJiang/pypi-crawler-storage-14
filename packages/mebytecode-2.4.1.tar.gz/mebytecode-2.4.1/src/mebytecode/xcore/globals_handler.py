import sys
import types
import weakref
import copy as copy_module

__author__ = "mero"
__version__ = "1.0.0"


class GlobalsSnapshot(object):
    
    def __init__(self, globals_dict, deep=False):
        if deep:
            self._snapshot = self._deep_copy(globals_dict)
        else:
            self._snapshot = dict(globals_dict)
        self._keys = frozenset(globals_dict.keys())
        self._timestamp = None
    
    def _deep_copy(self, d):
        result = {}
        for key, value in d.items():
            try:
                result[key] = copy_module.deepcopy(value)
            except Exception:
                result[key] = value
        return result
    
    @property
    def snapshot(self):
        return dict(self._snapshot)
    
    @property
    def keys(self):
        return self._keys
    
    def get(self, key, default=None):
        return self._snapshot.get(key, default)
    
    def contains(self, key):
        return key in self._snapshot
    
    def diff(self, other_globals):
        current_keys = set(other_globals.keys())
        added = current_keys - self._keys
        removed = self._keys - current_keys
        modified = set()
        for key in self._keys & current_keys:
            try:
                if self._snapshot.get(key) != other_globals.get(key):
                    modified.add(key)
            except Exception:
                modified.add(key)
        return {
            'added': list(added),
            'removed': list(removed),
            'modified': list(modified)
        }


class GlobalsController(object):
    
    def __init__(self, globals_dict=None):
        if globals_dict is None:
            frame = sys._getframe().f_back
            globals_dict = frame.f_globals
        self._globals = globals_dict
        self._snapshots = {}
        self._snapshot_counter = 0
        self._watchers = {}
        self._protected_keys = set()
    
    @property
    def globals(self):
        return self._globals
    
    def get(self, key, default=None):
        return self._globals.get(key, default)
    
    def set(self, key, value):
        if key in self._protected_keys:
            raise PermissionError("Key '{0}' is protected".format(key))
        old_value = self._globals.get(key)
        self._globals[key] = value
        self._notify_watchers(key, old_value, value)
        return old_value
    
    def delete(self, key):
        if key in self._protected_keys:
            raise PermissionError("Key '{0}' is protected".format(key))
        if key in self._globals:
            old_value = self._globals.pop(key)
            self._notify_watchers(key, old_value, None)
            return old_value
        return None
    
    def contains(self, key):
        return key in self._globals
    
    def keys(self):
        return list(self._globals.keys())
    
    def values(self):
        return list(self._globals.values())
    
    def items(self):
        return list(self._globals.items())
    
    def update(self, updates):
        for key in updates:
            if key in self._protected_keys:
                raise PermissionError("Key '{0}' is protected".format(key))
        for key, value in updates.items():
            old_value = self._globals.get(key)
            self._globals[key] = value
            self._notify_watchers(key, old_value, value)
        return len(updates)
    
    def clear(self, preserve_modules=True, preserve_builtins=True):
        protected = set(self._protected_keys)
        if preserve_modules:
            protected.add('__name__')
            protected.add('__doc__')
            protected.add('__package__')
            protected.add('__loader__')
            protected.add('__spec__')
            protected.add('__file__')
        if preserve_builtins:
            protected.add('__builtins__')
        keys_to_remove = [k for k in self._globals.keys() if k not in protected]
        for key in keys_to_remove:
            del self._globals[key]
        return len(keys_to_remove)
    
    def save_snapshot(self, name=None, deep=False):
        if name is None:
            self._snapshot_counter += 1
            name = "snapshot_{0}".format(self._snapshot_counter)
        self._snapshots[name] = GlobalsSnapshot(self._globals, deep)
        return name
    
    def restore_snapshot(self, name, merge=False):
        if name not in self._snapshots:
            raise KeyError("Snapshot '{0}' not found".format(name))
        snapshot = self._snapshots[name]
        if not merge:
            keys_to_remove = [k for k in self._globals.keys() 
                           if k not in self._protected_keys and k not in snapshot.keys]
            for key in keys_to_remove:
                del self._globals[key]
        for key, value in snapshot.snapshot.items():
            if key not in self._protected_keys:
                self._globals[key] = value
        return True
    
    def delete_snapshot(self, name):
        if name in self._snapshots:
            del self._snapshots[name]
            return True
        return False
    
    def list_snapshots(self):
        return list(self._snapshots.keys())
    
    def get_snapshot_diff(self, name):
        if name not in self._snapshots:
            raise KeyError("Snapshot '{0}' not found".format(name))
        return self._snapshots[name].diff(self._globals)
    
    def protect(self, key):
        self._protected_keys.add(key)
        return True
    
    def unprotect(self, key):
        if key in self._protected_keys:
            self._protected_keys.remove(key)
            return True
        return False
    
    def is_protected(self, key):
        return key in self._protected_keys
    
    def get_protected_keys(self):
        return list(self._protected_keys)
    
    def add_watcher(self, key, callback):
        if key not in self._watchers:
            self._watchers[key] = []
        if callback not in self._watchers[key]:
            self._watchers[key].append(callback)
            return True
        return False
    
    def remove_watcher(self, key, callback=None):
        if key in self._watchers:
            if callback is None:
                del self._watchers[key]
                return True
            elif callback in self._watchers[key]:
                self._watchers[key].remove(callback)
                return True
        return False
    
    def _notify_watchers(self, key, old_value, new_value):
        if key in self._watchers:
            for callback in self._watchers[key]:
                try:
                    callback(key, old_value, new_value)
                except Exception:
                    pass


class GlobalsFilter(object):
    
    def __init__(self, globals_dict):
        self._globals = globals_dict
    
    def by_type(self, type_filter):
        return {k: v for k, v in self._globals.items() if isinstance(v, type_filter)}
    
    def by_prefix(self, prefix):
        return {k: v for k, v in self._globals.items() if k.startswith(prefix)}
    
    def by_suffix(self, suffix):
        return {k: v for k, v in self._globals.items() if k.endswith(suffix)}
    
    def modules(self):
        return self.by_type(types.ModuleType)
    
    def functions(self):
        return self.by_type(types.FunctionType)
    
    def classes(self):
        return {k: v for k, v in self._globals.items() if isinstance(v, type)}
    
    def builtins(self):
        return self.by_type(types.BuiltinFunctionType)
    
    def private(self):
        return {k: v for k, v in self._globals.items() 
                if k.startswith('_') and not k.startswith('__')}
    
    def dunder(self):
        return {k: v for k, v in self._globals.items() 
                if k.startswith('__') and k.endswith('__')}
    
    def public(self):
        return {k: v for k, v in self._globals.items() if not k.startswith('_')}
    
    def callable_items(self):
        return {k: v for k, v in self._globals.items() if callable(v)}
    
    def non_callable(self):
        return {k: v for k, v in self._globals.items() if not callable(v)}


class GlobalsInjector(object):
    
    def __init__(self, globals_dict):
        self._globals = globals_dict
    
    def inject(self, name, value):
        self._globals[name] = value
        return True
    
    def inject_many(self, items):
        for name, value in items.items():
            self._globals[name] = value
        return len(items)
    
    def inject_module(self, module, names=None):
        if names is None:
            if hasattr(module, '__all__'):
                names = module.__all__
            else:
                names = [n for n in dir(module) if not n.startswith('_')]
        count = 0
        for name in names:
            if hasattr(module, name):
                self._globals[name] = getattr(module, name)
                count += 1
        return count
    
    def inject_from_dict(self, source, keys=None):
        if keys is None:
            keys = source.keys()
        count = 0
        for key in keys:
            if key in source:
                self._globals[key] = source[key]
                count += 1
        return count


class GlobalsProxy(object):
    
    def __init__(self, globals_dict):
        object.__setattr__(self, '_globals', globals_dict)
    
    def __getattr__(self, name):
        globals_dict = object.__getattribute__(self, '_globals')
        if name in globals_dict:
            return globals_dict[name]
        raise AttributeError("Global '{0}' not found".format(name))
    
    def __setattr__(self, name, value):
        globals_dict = object.__getattribute__(self, '_globals')
        globals_dict[name] = value
    
    def __delattr__(self, name):
        globals_dict = object.__getattribute__(self, '_globals')
        if name in globals_dict:
            del globals_dict[name]
        else:
            raise AttributeError("Global '{0}' not found".format(name))
    
    def __contains__(self, name):
        globals_dict = object.__getattribute__(self, '_globals')
        return name in globals_dict
    
    def __iter__(self):
        globals_dict = object.__getattribute__(self, '_globals')
        return iter(globals_dict)
    
    def __len__(self):
        globals_dict = object.__getattribute__(self, '_globals')
        return len(globals_dict)


def get_controller(globals_dict=None):
    if globals_dict is None:
        frame = sys._getframe().f_back
        globals_dict = frame.f_globals
    return GlobalsController(globals_dict)


def get_filter(globals_dict=None):
    if globals_dict is None:
        frame = sys._getframe().f_back
        globals_dict = frame.f_globals
    return GlobalsFilter(globals_dict)


def get_injector(globals_dict=None):
    if globals_dict is None:
        frame = sys._getframe().f_back
        globals_dict = frame.f_globals
    return GlobalsInjector(globals_dict)


def get_proxy(globals_dict=None):
    if globals_dict is None:
        frame = sys._getframe().f_back
        globals_dict = frame.f_globals
    return GlobalsProxy(globals_dict)


def snapshot(globals_dict=None, deep=False):
    if globals_dict is None:
        frame = sys._getframe().f_back
        globals_dict = frame.f_globals
    return GlobalsSnapshot(globals_dict, deep)
