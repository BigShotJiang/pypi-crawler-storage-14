import sys
import types
import importlib
import importlib.util
import weakref
import os

__author__ = "mero"
__version__ = "1.0.0"


class ModuleInfo(object):
    
    def __init__(self, module):
        if not isinstance(module, types.ModuleType):
            raise TypeError("Expected module object")
        self._module = module
    
    @property
    def module(self):
        return self._module
    
    @property
    def name(self):
        return getattr(self._module, '__name__', None)
    
    @property
    def file(self):
        return getattr(self._module, '__file__', None)
    
    @property
    def doc(self):
        return getattr(self._module, '__doc__', None)
    
    @property
    def package(self):
        return getattr(self._module, '__package__', None)
    
    @property
    def loader(self):
        return getattr(self._module, '__loader__', None)
    
    @property
    def spec(self):
        return getattr(self._module, '__spec__', None)
    
    @property
    def path(self):
        return getattr(self._module, '__path__', None)
    
    @property
    def cached(self):
        return getattr(self._module, '__cached__', None)
    
    def is_package(self):
        return self.path is not None
    
    def is_builtin(self):
        return self.file is None and self.name in sys.builtin_module_names
    
    def is_frozen(self):
        loader = self.loader
        return loader is not None and hasattr(loader, 'is_frozen_package')
    
    def get_attributes(self):
        return dir(self._module)
    
    def get_public_attributes(self):
        return [name for name in dir(self._module) if not name.startswith('_')]
    
    def get_exported(self):
        if hasattr(self._module, '__all__'):
            return list(self._module.__all__)
        return self.get_public_attributes()
    
    def get_submodules(self):
        if not self.is_package():
            return []
        submodules = []
        prefix = self.name + '.'
        for name in sys.modules:
            if name.startswith(prefix) and '.' not in name[len(prefix):]:
                submodules.append(name)
        return submodules
    
    def to_dict(self):
        return {
            'name': self.name,
            'file': self.file,
            'package': self.package,
            'is_package': self.is_package(),
            'is_builtin': self.is_builtin(),
            'cached': self.cached,
            'attributes': len(self.get_attributes())
        }


class ModulesController(object):
    
    def __init__(self):
        self._snapshots = {}
        self._snapshot_counter = 0
        self._hooks = []
        self._original_import = None
    
    def get(self, name):
        return sys.modules.get(name)
    
    def set(self, name, module):
        old_module = sys.modules.get(name)
        sys.modules[name] = module
        return old_module
    
    def remove(self, name, remove_submodules=False):
        if name in sys.modules:
            module = sys.modules.pop(name)
            if remove_submodules:
                prefix = name + '.'
                submodules = [n for n in sys.modules if n.startswith(prefix)]
                for subname in submodules:
                    sys.modules.pop(subname, None)
            return module
        return None
    
    def reload(self, name):
        if name not in sys.modules:
            raise KeyError("Module '{0}' not loaded".format(name))
        module = sys.modules[name]
        return importlib.reload(module)
    
    def contains(self, name):
        return name in sys.modules
    
    def list_loaded(self):
        return list(sys.modules.keys())
    
    def list_builtin(self):
        return list(sys.builtin_module_names)
    
    def count_loaded(self):
        return len(sys.modules)
    
    def clear_cache(self):
        if hasattr(importlib, 'invalidate_caches'):
            importlib.invalidate_caches()
        return True
    
    def save_snapshot(self, name=None):
        if name is None:
            self._snapshot_counter += 1
            name = "snapshot_{0}".format(self._snapshot_counter)
        self._snapshots[name] = {
            'modules': set(sys.modules.keys()),
            'meta_path': list(sys.meta_path),
            'path_hooks': list(sys.path_hooks),
            'path': list(sys.path)
        }
        return name
    
    def restore_snapshot(self, name):
        if name not in self._snapshots:
            raise KeyError("Snapshot '{0}' not found".format(name))
        snapshot = self._snapshots[name]
        current_modules = set(sys.modules.keys())
        added_modules = current_modules - snapshot['modules']
        for mod_name in added_modules:
            if mod_name in sys.modules:
                del sys.modules[mod_name]
        sys.meta_path[:] = snapshot['meta_path']
        sys.path_hooks[:] = snapshot['path_hooks']
        sys.path[:] = snapshot['path']
        return True
    
    def delete_snapshot(self, name):
        if name in self._snapshots:
            del self._snapshots[name]
            return True
        return False
    
    def list_snapshots(self):
        return list(self._snapshots.keys())


class ModuleLoader(object):
    
    @staticmethod
    def load_from_source(name, source, filename='<string>'):
        code = compile(source, filename, 'exec')
        module = types.ModuleType(name)
        module.__file__ = filename
        exec(code, module.__dict__)
        sys.modules[name] = module
        return module
    
    @staticmethod
    def load_from_file(name, filepath):
        spec = importlib.util.spec_from_file_location(name, filepath)
        if spec is None:
            raise ImportError("Cannot load module from '{0}'".format(filepath))
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module
    
    @staticmethod
    def create_empty(name):
        module = types.ModuleType(name)
        sys.modules[name] = module
        return module
    
    @staticmethod
    def create_package(name, path=None):
        module = types.ModuleType(name)
        module.__path__ = path if path is not None else []
        module.__package__ = name
        sys.modules[name] = module
        return module


class ModuleFinder(object):
    
    @staticmethod
    def find_by_file(filepath):
        for name, module in sys.modules.items():
            if hasattr(module, '__file__') and module.__file__ == filepath:
                return name
        return None
    
    @staticmethod
    def find_by_prefix(prefix):
        return [name for name in sys.modules if name.startswith(prefix)]
    
    @staticmethod
    def find_by_suffix(suffix):
        return [name for name in sys.modules if name.endswith(suffix)]
    
    @staticmethod
    def find_packages():
        packages = []
        for name, module in sys.modules.items():
            if hasattr(module, '__path__'):
                packages.append(name)
        return packages
    
    @staticmethod
    def find_builtins_loaded():
        return [name for name in sys.modules if name in sys.builtin_module_names]
    
    @staticmethod
    def find_submodules(package_name):
        prefix = package_name + '.'
        return [name for name in sys.modules if name.startswith(prefix)]


class ModuleModifier(object):
    
    @staticmethod
    def set_attribute(module, name, value):
        setattr(module, name, value)
        return True
    
    @staticmethod
    def delete_attribute(module, name):
        if hasattr(module, name):
            delattr(module, name)
            return True
        return False
    
    @staticmethod
    def update_dict(module, updates):
        module.__dict__.update(updates)
        return len(updates)
    
    @staticmethod
    def clear_dict(module, preserve_system=True):
        to_preserve = set()
        if preserve_system:
            to_preserve = {'__name__', '__doc__', '__package__', 
                          '__loader__', '__spec__', '__file__', '__path__'}
        keys_to_remove = [k for k in module.__dict__ if k not in to_preserve]
        for key in keys_to_remove:
            del module.__dict__[key]
        return len(keys_to_remove)
    
    @staticmethod
    def rename(old_name, new_name):
        if old_name not in sys.modules:
            raise KeyError("Module '{0}' not found".format(old_name))
        module = sys.modules.pop(old_name)
        module.__name__ = new_name
        sys.modules[new_name] = module
        return module


class ImportHooker(object):
    
    def __init__(self):
        self._pre_import_hooks = []
        self._post_import_hooks = []
        self._original_import = None
        self._installed = False
    
    def _custom_import(self, name, globals_dict=None, locals_dict=None, 
                       fromlist=(), level=0):
        for hook in self._pre_import_hooks:
            try:
                result = hook(name, globals_dict, locals_dict, fromlist, level)
                if result is not None:
                    return result
            except Exception:
                pass
        module = self._original_import(name, globals_dict, locals_dict, 
                                       fromlist, level)
        for hook in self._post_import_hooks:
            try:
                modified = hook(name, module, fromlist, level)
                if modified is not None:
                    module = modified
            except Exception:
                pass
        return module
    
    def install(self):
        if not self._installed:
            import builtins
            self._original_import = builtins.__import__
            builtins.__import__ = self._custom_import
            self._installed = True
        return self._installed
    
    def uninstall(self):
        if self._installed:
            import builtins
            builtins.__import__ = self._original_import
            self._installed = False
        return not self._installed
    
    def add_pre_hook(self, hook):
        if callable(hook):
            self._pre_import_hooks.append(hook)
            return True
        return False
    
    def add_post_hook(self, hook):
        if callable(hook):
            self._post_import_hooks.append(hook)
            return True
        return False
    
    def remove_pre_hook(self, hook):
        if hook in self._pre_import_hooks:
            self._pre_import_hooks.remove(hook)
            return True
        return False
    
    def remove_post_hook(self, hook):
        if hook in self._post_import_hooks:
            self._post_import_hooks.remove(hook)
            return True
        return False
    
    def clear_hooks(self):
        count = len(self._pre_import_hooks) + len(self._post_import_hooks)
        self._pre_import_hooks = []
        self._post_import_hooks = []
        return count


def get_controller():
    return ModulesController()


def get_loader():
    return ModuleLoader()


def get_finder():
    return ModuleFinder()


def get_modifier():
    return ModuleModifier()


def get_hooker():
    return ImportHooker()


def info(module):
    return ModuleInfo(module)


def get_module(name):
    return sys.modules.get(name)


def remove_module(name):
    controller = ModulesController()
    return controller.remove(name)


def reload_module(name):
    controller = ModulesController()
    return controller.reload(name)
