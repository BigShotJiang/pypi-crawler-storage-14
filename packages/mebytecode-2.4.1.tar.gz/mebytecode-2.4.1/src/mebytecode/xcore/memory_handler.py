import sys
import gc
import ctypes
import weakref
import struct

__author__ = "mero"
__version__ = "1.0.0"


class ObjectInfo(object):
    
    def __init__(self, obj):
        self._obj_ref = weakref.ref(obj) if self._can_weakref(obj) else None
        self._obj_id = id(obj)
        self._obj_type = type(obj)
        self._snapshot_size = sys.getsizeof(obj)
    
    def _can_weakref(self, obj):
        try:
            weakref.ref(obj)
            return True
        except TypeError:
            return False
    
    @property
    def obj(self):
        if self._obj_ref is not None:
            return self._obj_ref()
        return None
    
    @property
    def obj_id(self):
        return self._obj_id
    
    @property
    def obj_type(self):
        return self._obj_type
    
    def get_size(self):
        obj = self.obj
        if obj is not None:
            return sys.getsizeof(obj)
        return self._snapshot_size
    
    def get_refcount(self):
        obj = self.obj
        if obj is not None:
            return sys.getrefcount(obj)
        return 0
    
    def get_referrers(self):
        obj = self.obj
        if obj is not None:
            return gc.get_referrers(obj)
        return []
    
    def get_referents(self):
        obj = self.obj
        if obj is not None:
            return gc.get_referents(obj)
        return []
    
    def is_tracked(self):
        obj = self.obj
        if obj is not None and hasattr(gc, 'is_tracked'):
            return gc.is_tracked(obj)
        return None
    
    def is_alive(self):
        return self.obj is not None
    
    def to_dict(self):
        return {
            'id': self._obj_id,
            'type': self._obj_type.__name__,
            'size': self.get_size(),
            'refcount': self.get_refcount(),
            'alive': self.is_alive(),
            'tracked': self.is_tracked()
        }


class MemoryController(object):
    
    def __init__(self):
        self._tracked_objects = weakref.WeakValueDictionary()
        self._snapshots = {}
        self._snapshot_counter = 0
    
    def get_sizeof(self, obj):
        return sys.getsizeof(obj)
    
    def get_refcount(self, obj):
        return sys.getrefcount(obj)
    
    def get_id(self, obj):
        return id(obj)
    
    def get_referrers(self, obj):
        return gc.get_referrers(obj)
    
    def get_referents(self, obj):
        return gc.get_referents(obj)
    
    def get_gc_objects(self, generation=None):
        if generation is not None and hasattr(gc, 'get_objects'):
            try:
                return gc.get_objects(generation)
            except TypeError:
                return gc.get_objects()
        return gc.get_objects() if hasattr(gc, 'get_objects') else []
    
    def get_gc_count(self):
        return gc.get_count()
    
    def get_gc_stats(self):
        if hasattr(gc, 'get_stats'):
            return gc.get_stats()
        return None
    
    def collect(self, generation=2):
        return gc.collect(generation)
    
    def enable_gc(self):
        gc.enable()
        return gc.isenabled()
    
    def disable_gc(self):
        gc.disable()
        return not gc.isenabled()
    
    def is_gc_enabled(self):
        return gc.isenabled()
    
    def get_threshold(self):
        return gc.get_threshold()
    
    def set_threshold(self, threshold0, threshold1=None, threshold2=None):
        old = gc.get_threshold()
        if threshold1 is None:
            gc.set_threshold(threshold0)
        elif threshold2 is None:
            gc.set_threshold(threshold0, threshold1)
        else:
            gc.set_threshold(threshold0, threshold1, threshold2)
        return old
    
    def track(self, obj, key=None):
        if key is None:
            key = id(obj)
        self._tracked_objects[key] = obj
        return key
    
    def untrack(self, key):
        if key in self._tracked_objects:
            del self._tracked_objects[key]
            return True
        return False
    
    def get_tracked(self, key):
        return self._tracked_objects.get(key)
    
    def list_tracked(self):
        return list(self._tracked_objects.keys())
    
    def save_snapshot(self, name=None):
        if name is None:
            self._snapshot_counter += 1
            name = "snapshot_{0}".format(self._snapshot_counter)
        self._snapshots[name] = MemorySnapshot()
        return name
    
    def compare_snapshots(self, name1, name2):
        if name1 not in self._snapshots or name2 not in self._snapshots:
            raise KeyError("Snapshot not found")
        return self._snapshots[name1].diff(self._snapshots[name2])
    
    def delete_snapshot(self, name):
        if name in self._snapshots:
            del self._snapshots[name]
            return True
        return False
    
    def list_snapshots(self):
        return list(self._snapshots.keys())


class MemorySnapshot(object):
    
    def __init__(self):
        self._timestamp = None
        self._type_counts = {}
        self._total_objects = 0
        self._gc_counts = None
        self._capture()
    
    def _capture(self):
        import time
        self._timestamp = time.time()
        objects = gc.get_objects() if hasattr(gc, 'get_objects') else []
        self._total_objects = len(objects)
        for obj in objects:
            type_name = type(obj).__name__
            self._type_counts[type_name] = self._type_counts.get(type_name, 0) + 1
        self._gc_counts = gc.get_count()
    
    @property
    def timestamp(self):
        return self._timestamp
    
    @property
    def type_counts(self):
        return dict(self._type_counts)
    
    @property
    def total_objects(self):
        return self._total_objects
    
    @property
    def gc_counts(self):
        return self._gc_counts
    
    def diff(self, other):
        if not isinstance(other, MemorySnapshot):
            raise TypeError("Expected MemorySnapshot")
        result = {
            'object_diff': self._total_objects - other._total_objects,
            'type_diffs': {}
        }
        all_types = set(self._type_counts.keys()) | set(other._type_counts.keys())
        for type_name in all_types:
            count_self = self._type_counts.get(type_name, 0)
            count_other = other._type_counts.get(type_name, 0)
            if count_self != count_other:
                result['type_diffs'][type_name] = count_self - count_other
        return result
    
    def to_dict(self):
        return {
            'timestamp': self._timestamp,
            'total_objects': self._total_objects,
            'type_counts': self._type_counts,
            'gc_counts': self._gc_counts
        }


class MemoryAnalyzer(object):
    
    @staticmethod
    def get_type_distribution():
        objects = gc.get_objects() if hasattr(gc, 'get_objects') else []
        distribution = {}
        for obj in objects:
            type_name = type(obj).__name__
            distribution[type_name] = distribution.get(type_name, 0) + 1
        return distribution
    
    @staticmethod
    def get_largest_objects(count=10):
        objects = gc.get_objects() if hasattr(gc, 'get_objects') else []
        sized = []
        for obj in objects:
            try:
                size = sys.getsizeof(obj)
                sized.append((size, type(obj).__name__, id(obj)))
            except Exception:
                pass
        sized.sort(reverse=True)
        return sized[:count]
    
    @staticmethod
    def get_total_memory():
        objects = gc.get_objects() if hasattr(gc, 'get_objects') else []
        total = 0
        for obj in objects:
            try:
                total += sys.getsizeof(obj)
            except Exception:
                pass
        return total
    
    @staticmethod
    def get_memory_by_type():
        objects = gc.get_objects() if hasattr(gc, 'get_objects') else []
        by_type = {}
        for obj in objects:
            try:
                type_name = type(obj).__name__
                size = sys.getsizeof(obj)
                if type_name not in by_type:
                    by_type[type_name] = {'count': 0, 'size': 0}
                by_type[type_name]['count'] += 1
                by_type[type_name]['size'] += size
            except Exception:
                pass
        return by_type
    
    @staticmethod
    def find_cycles():
        gc.collect()
        return gc.garbage if hasattr(gc, 'garbage') else []
    
    @staticmethod
    def get_reference_chain(obj, max_depth=5):
        chain = []
        seen = set()
        current = [obj]
        for depth in range(max_depth):
            next_level = []
            for item in current:
                item_id = id(item)
                if item_id in seen:
                    continue
                seen.add(item_id)
                referrers = gc.get_referrers(item)
                for ref in referrers:
                    if id(ref) not in seen:
                        next_level.append(ref)
            if not next_level:
                break
            chain.append(len(next_level))
            current = next_level
        return chain


class WeakRefManager(object):
    
    def __init__(self):
        self._refs = {}
        self._callbacks = {}
    
    def create_ref(self, obj, name, callback=None):
        def _on_finalize(ref):
            if name in self._refs:
                del self._refs[name]
            if name in self._callbacks and self._callbacks[name] is not None:
                try:
                    self._callbacks[name](name)
                except Exception:
                    pass
        try:
            ref = weakref.ref(obj, _on_finalize)
            self._refs[name] = ref
            self._callbacks[name] = callback
            return True
        except TypeError:
            return False
    
    def get_ref(self, name):
        ref = self._refs.get(name)
        if ref is not None:
            return ref()
        return None
    
    def is_alive(self, name):
        ref = self._refs.get(name)
        if ref is not None:
            return ref() is not None
        return False
    
    def remove_ref(self, name):
        if name in self._refs:
            del self._refs[name]
            if name in self._callbacks:
                del self._callbacks[name]
            return True
        return False
    
    def list_refs(self):
        return list(self._refs.keys())
    
    def list_alive(self):
        return [name for name in self._refs if self.is_alive(name)]
    
    def clear(self):
        count = len(self._refs)
        self._refs.clear()
        self._callbacks.clear()
        return count


class MemoryProfiler(object):
    
    def __init__(self):
        self._samples = []
        self._profiling = False
        self._max_samples = 1000
    
    def sample(self):
        import time
        sample = {
            'timestamp': time.time(),
            'total_objects': len(gc.get_objects()) if hasattr(gc, 'get_objects') else 0,
            'gc_counts': gc.get_count(),
            'gc_enabled': gc.isenabled()
        }
        if len(self._samples) >= self._max_samples:
            self._samples.pop(0)
        self._samples.append(sample)
        return sample
    
    def get_samples(self):
        return list(self._samples)
    
    def get_latest(self):
        if self._samples:
            return self._samples[-1]
        return None
    
    def clear_samples(self):
        count = len(self._samples)
        self._samples = []
        return count
    
    def set_max_samples(self, max_samples):
        old_max = self._max_samples
        self._max_samples = max_samples
        return old_max
    
    def get_trend(self):
        if len(self._samples) < 2:
            return None
        first = self._samples[0]
        last = self._samples[-1]
        return {
            'object_change': last['total_objects'] - first['total_objects'],
            'time_span': last['timestamp'] - first['timestamp'],
            'sample_count': len(self._samples)
        }


def get_controller():
    return MemoryController()


def get_analyzer():
    return MemoryAnalyzer()


def get_profiler():
    return MemoryProfiler()


def get_weakref_manager():
    return WeakRefManager()


def info(obj):
    return ObjectInfo(obj)


def snapshot():
    return MemorySnapshot()


def sizeof(obj):
    return sys.getsizeof(obj)


def refcount(obj):
    return sys.getrefcount(obj)


def collect(generation=2):
    return gc.collect(generation)
