import sys
import ctypes
import types
import copy as copy_module

__author__ = "mero"
__version__ = "1.0.0"


class LocalsSnapshot(object):
    
    def __init__(self, locals_dict, deep=False):
        if deep:
            self._snapshot = self._deep_copy(locals_dict)
        else:
            self._snapshot = dict(locals_dict)
        self._keys = frozenset(locals_dict.keys())
    
    def _deep_copy(self, d):
        result = {}
        for key, value in d.items():
            try:
                result[key] = copy_module.deepcopy(value)
            except Exception:
                result[key] = value
        return result
    
    @property
    def snapshot(self):
        return dict(self._snapshot)
    
    @property
    def keys(self):
        return self._keys
    
    def get(self, key, default=None):
        return self._snapshot.get(key, default)
    
    def contains(self, key):
        return key in self._snapshot
    
    def diff(self, other_locals):
        current_keys = set(other_locals.keys())
        added = current_keys - self._keys
        removed = self._keys - current_keys
        modified = set()
        for key in self._keys & current_keys:
            try:
                if self._snapshot.get(key) != other_locals.get(key):
                    modified.add(key)
            except Exception:
                modified.add(key)
        return {
            'added': list(added),
            'removed': list(removed),
            'modified': list(modified)
        }


class LocalsAccessor(object):
    
    def __init__(self, frame=None):
        if frame is None:
            self._frame = sys._getframe().f_back
        else:
            self._frame = frame
        self._use_ctypes = True
    
    @property
    def frame(self):
        return self._frame
    
    @property
    def locals(self):
        return self._frame.f_locals
    
    def get(self, name, default=None):
        return self._frame.f_locals.get(name, default)
    
    def set(self, name, value):
        self._frame.f_locals[name] = value
        if self._use_ctypes:
            self._sync_locals()
        return value
    
    def delete(self, name):
        if name in self._frame.f_locals:
            value = self._frame.f_locals.pop(name)
            if self._use_ctypes:
                self._sync_locals()
            return value
        return None
    
    def _sync_locals(self):
        try:
            ctypes.pythonapi.PyFrame_LocalsToFast(
                ctypes.py_object(self._frame),
                ctypes.c_int(0)
            )
        except Exception:
            pass
    
    def contains(self, name):
        return name in self._frame.f_locals
    
    def keys(self):
        return list(self._frame.f_locals.keys())
    
    def values(self):
        return list(self._frame.f_locals.values())
    
    def items(self):
        return list(self._frame.f_locals.items())
    
    def update(self, updates):
        for name, value in updates.items():
            self._frame.f_locals[name] = value
        if self._use_ctypes:
            self._sync_locals()
        return len(updates)
    
    def clear(self):
        keys = list(self._frame.f_locals.keys())
        for key in keys:
            del self._frame.f_locals[key]
        if self._use_ctypes:
            self._sync_locals()
        return len(keys)
    
    def to_dict(self):
        return dict(self._frame.f_locals)


class LocalsController(object):
    
    def __init__(self, frame=None):
        if frame is None:
            self._frame = sys._getframe().f_back
        else:
            self._frame = frame
        self._snapshots = {}
        self._snapshot_counter = 0
        self._watchers = {}
        self._accessor = LocalsAccessor(self._frame)
    
    @property
    def frame(self):
        return self._frame
    
    def get(self, name, default=None):
        return self._accessor.get(name, default)
    
    def set(self, name, value):
        old_value = self._accessor.get(name)
        self._accessor.set(name, value)
        self._notify_watchers(name, old_value, value)
        return old_value
    
    def delete(self, name):
        old_value = self._accessor.delete(name)
        if old_value is not None:
            self._notify_watchers(name, old_value, None)
        return old_value
    
    def contains(self, name):
        return self._accessor.contains(name)
    
    def keys(self):
        return self._accessor.keys()
    
    def values(self):
        return self._accessor.values()
    
    def items(self):
        return self._accessor.items()
    
    def update(self, updates):
        for name, value in updates.items():
            old_value = self._accessor.get(name)
            self._accessor.set(name, value)
            self._notify_watchers(name, old_value, value)
        return len(updates)
    
    def save_snapshot(self, name=None, deep=False):
        if name is None:
            self._snapshot_counter += 1
            name = "snapshot_{0}".format(self._snapshot_counter)
        self._snapshots[name] = LocalsSnapshot(self._accessor.to_dict(), deep)
        return name
    
    def restore_snapshot(self, name):
        if name not in self._snapshots:
            raise KeyError("Snapshot '{0}' not found".format(name))
        snapshot = self._snapshots[name]
        for key, value in snapshot.snapshot.items():
            self._accessor.set(key, value)
        return True
    
    def delete_snapshot(self, name):
        if name in self._snapshots:
            del self._snapshots[name]
            return True
        return False
    
    def list_snapshots(self):
        return list(self._snapshots.keys())
    
    def get_snapshot_diff(self, name):
        if name not in self._snapshots:
            raise KeyError("Snapshot '{0}' not found".format(name))
        return self._snapshots[name].diff(self._accessor.to_dict())
    
    def add_watcher(self, name, callback):
        if name not in self._watchers:
            self._watchers[name] = []
        if callback not in self._watchers[name]:
            self._watchers[name].append(callback)
            return True
        return False
    
    def remove_watcher(self, name, callback=None):
        if name in self._watchers:
            if callback is None:
                del self._watchers[name]
                return True
            elif callback in self._watchers[name]:
                self._watchers[name].remove(callback)
                return True
        return False
    
    def _notify_watchers(self, name, old_value, new_value):
        if name in self._watchers:
            for callback in self._watchers[name]:
                try:
                    callback(name, old_value, new_value)
                except Exception:
                    pass


class LocalsFilter(object):
    
    def __init__(self, locals_dict):
        self._locals = locals_dict
    
    def by_type(self, type_filter):
        return {k: v for k, v in self._locals.items() if isinstance(v, type_filter)}
    
    def by_prefix(self, prefix):
        return {k: v for k, v in self._locals.items() if k.startswith(prefix)}
    
    def by_suffix(self, suffix):
        return {k: v for k, v in self._locals.items() if k.endswith(suffix)}
    
    def functions(self):
        return self.by_type(types.FunctionType)
    
    def classes(self):
        return {k: v for k, v in self._locals.items() if isinstance(v, type)}
    
    def private(self):
        return {k: v for k, v in self._locals.items() 
                if k.startswith('_') and not k.startswith('__')}
    
    def public(self):
        return {k: v for k, v in self._locals.items() if not k.startswith('_')}
    
    def callable_items(self):
        return {k: v for k, v in self._locals.items() if callable(v)}
    
    def non_callable(self):
        return {k: v for k, v in self._locals.items() if not callable(v)}
    
    def numerics(self):
        return {k: v for k, v in self._locals.items() 
                if isinstance(v, (int, float, complex))}
    
    def strings(self):
        return self.by_type(str)
    
    def lists(self):
        return self.by_type(list)
    
    def dicts(self):
        return self.by_type(dict)


class LocalsInjector(object):
    
    def __init__(self, frame=None):
        if frame is None:
            self._frame = sys._getframe().f_back
        else:
            self._frame = frame
        self._accessor = LocalsAccessor(self._frame)
    
    def inject(self, name, value):
        self._accessor.set(name, value)
        return True
    
    def inject_many(self, items):
        for name, value in items.items():
            self._accessor.set(name, value)
        return len(items)
    
    def inject_from_globals(self, names=None):
        globals_dict = self._frame.f_globals
        if names is None:
            names = [n for n in globals_dict.keys() if not n.startswith('_')]
        count = 0
        for name in names:
            if name in globals_dict:
                self._accessor.set(name, globals_dict[name])
                count += 1
        return count


class LocalsProxy(object):
    
    def __init__(self, frame=None):
        if frame is None:
            frame = sys._getframe().f_back
        object.__setattr__(self, '_frame', frame)
        object.__setattr__(self, '_accessor', LocalsAccessor(frame))
    
    def __getattr__(self, name):
        accessor = object.__getattribute__(self, '_accessor')
        if accessor.contains(name):
            return accessor.get(name)
        raise AttributeError("Local '{0}' not found".format(name))
    
    def __setattr__(self, name, value):
        accessor = object.__getattribute__(self, '_accessor')
        accessor.set(name, value)
    
    def __delattr__(self, name):
        accessor = object.__getattribute__(self, '_accessor')
        if accessor.contains(name):
            accessor.delete(name)
        else:
            raise AttributeError("Local '{0}' not found".format(name))
    
    def __contains__(self, name):
        accessor = object.__getattribute__(self, '_accessor')
        return accessor.contains(name)
    
    def __iter__(self):
        accessor = object.__getattribute__(self, '_accessor')
        return iter(accessor.keys())
    
    def __len__(self):
        accessor = object.__getattribute__(self, '_accessor')
        return len(accessor.keys())


class LocalsAnalyzer(object):
    
    def __init__(self, frame=None):
        if frame is None:
            self._frame = sys._getframe().f_back
        else:
            self._frame = frame
    
    def get_argument_values(self):
        code = self._frame.f_code
        argcount = code.co_argcount
        varnames = code.co_varnames[:argcount]
        result = {}
        for name in varnames:
            if name in self._frame.f_locals:
                result[name] = self._frame.f_locals[name]
        return result
    
    def get_local_only_vars(self):
        code = self._frame.f_code
        argcount = code.co_argcount
        varnames = code.co_varnames[argcount:]
        result = {}
        for name in varnames:
            if name in self._frame.f_locals:
                result[name] = self._frame.f_locals[name]
        return result
    
    def get_type_distribution(self):
        distribution = {}
        for value in self._frame.f_locals.values():
            type_name = type(value).__name__
            distribution[type_name] = distribution.get(type_name, 0) + 1
        return distribution
    
    def get_memory_usage(self):
        total = 0
        for value in self._frame.f_locals.values():
            try:
                total += sys.getsizeof(value)
            except Exception:
                pass
        return total


def get_accessor(frame=None):
    if frame is None:
        frame = sys._getframe().f_back
    return LocalsAccessor(frame)


def get_controller(frame=None):
    if frame is None:
        frame = sys._getframe().f_back
    return LocalsController(frame)


def get_filter(frame=None):
    if frame is None:
        frame = sys._getframe().f_back
    return LocalsFilter(frame.f_locals)


def get_injector(frame=None):
    if frame is None:
        frame = sys._getframe().f_back
    return LocalsInjector(frame)


def get_proxy(frame=None):
    if frame is None:
        frame = sys._getframe().f_back
    return LocalsProxy(frame)


def get_analyzer(frame=None):
    if frame is None:
        frame = sys._getframe().f_back
    return LocalsAnalyzer(frame)


def snapshot(frame=None, deep=False):
    if frame is None:
        frame = sys._getframe().f_back
    return LocalsSnapshot(frame.f_locals, deep)
