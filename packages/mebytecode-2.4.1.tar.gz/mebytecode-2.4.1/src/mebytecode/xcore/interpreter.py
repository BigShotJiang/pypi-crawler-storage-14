import sys
import gc
import os
import platform
import ctypes
import struct
import weakref

__author__ = "mero"
__version__ = "1.0.0"

try:
    from os import getpid, getppid
except ImportError:
    def getpid():
        return os.environ.get('PID', -1)
    def getppid():
        return os.environ.get('PPID', -1)


class InterpreterState(object):
    
    _instance = None
    _lock = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(InterpreterState, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._hooks = {}
        self._trace_callbacks = []
        self._profile_callbacks = []
        self._import_hooks = []
        self._audit_hooks = []
        self._state_snapshots = []
        self._original_recursion_limit = sys.getrecursionlimit()
        self._original_check_interval = self._get_check_interval()
        self._flags_backup = None
        self._exception_hooks = []
    
    def _get_check_interval(self):
        if hasattr(sys, 'getswitchinterval'):
            return sys.getswitchinterval()
        elif hasattr(sys, 'getcheckinterval'):
            return sys.getcheckinterval()
        return 100
    
    def _set_check_interval(self, interval):
        if hasattr(sys, 'setswitchinterval'):
            sys.setswitchinterval(interval)
        elif hasattr(sys, 'setcheckinterval'):
            sys.setcheckinterval(int(interval * 1000))


class InterpreterController(object):
    
    def __init__(self):
        self._state = InterpreterState()
        self._platform = platform.system().lower()
        self._is_windows = self._platform == 'windows'
        self._is_android = hasattr(sys, 'getandroidapilevel')
        self._is_ios = self._platform == 'darwin' and platform.machine().startswith('iP')
        self._pointer_size = struct.calcsize('P')
        self._is_64bit = self._pointer_size == 8
        self._saved_states = {}
        self._state_counter = 0
    
    def get_version_info(self):
        return {
            'major': sys.version_info.major,
            'minor': sys.version_info.minor,
            'micro': sys.version_info.micro,
            'releaselevel': sys.version_info.releaselevel,
            'serial': sys.version_info.serial,
            'version': sys.version,
            'api_version': sys.api_version,
            'hexversion': sys.hexversion
        }
    
    def get_platform_info(self):
        info = {
            'platform': sys.platform,
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'architecture': platform.architecture(),
            'is_windows': self._is_windows,
            'is_android': self._is_android,
            'is_ios': self._is_ios,
            'is_64bit': self._is_64bit,
            'pointer_size': self._pointer_size,
            'byteorder': sys.byteorder
        }
        if hasattr(sys, 'getwindowsversion') and self._is_windows:
            info['windows_version'] = sys.getwindowsversion()
        return info
    
    def get_recursion_limit(self):
        return sys.getrecursionlimit()
    
    def set_recursion_limit(self, limit):
        if not isinstance(limit, int) or limit < 1:
            raise ValueError("Recursion limit must be a positive integer")
        old_limit = sys.getrecursionlimit()
        sys.setrecursionlimit(limit)
        return old_limit
    
    def reset_recursion_limit(self):
        old_limit = sys.getrecursionlimit()
        sys.setrecursionlimit(self._state._original_recursion_limit)
        return old_limit
    
    def get_check_interval(self):
        return self._state._get_check_interval()
    
    def set_check_interval(self, interval):
        old = self._state._get_check_interval()
        self._state._set_check_interval(interval)
        return old
    
    def reset_check_interval(self):
        old = self._state._get_check_interval()
        self._state._set_check_interval(self._state._original_check_interval)
        return old
    
    def get_modules(self):
        return sys.modules.copy()
    
    def get_module(self, name):
        return sys.modules.get(name, None)
    
    def set_module(self, name, module):
        sys.modules[name] = module
        return True
    
    def remove_module(self, name):
        if name in sys.modules:
            del sys.modules[name]
            return True
        return False
    
    def has_module(self, name):
        return name in sys.modules
    
    def get_path(self):
        return sys.path.copy()
    
    def add_path(self, path):
        if path not in sys.path:
            sys.path.insert(0, path)
            return True
        return False
    
    def remove_path(self, path):
        if path in sys.path:
            sys.path.remove(path)
            return True
        return False
    
    def set_path(self, paths):
        old = sys.path.copy()
        sys.path[:] = paths
        return old
    
    def get_first_path(self):
        return sys.path[0] if sys.path else None
    
    def clear_path(self):
        sys.path.clear()
    
    def get_path_importer_cache(self):
        return sys.path_importer_cache.copy()
    
    def clear_path_importer_cache(self):
        sys.path_importer_cache.clear()
    
    def clear_path_cache_for(self, path):
        if path in sys.path_importer_cache:
            del sys.path_importer_cache[path]
    
    def get_meta_path(self):
        return sys.meta_path.copy()
    
    def add_meta_path_hook(self, finder):
        if finder not in sys.meta_path:
            sys.meta_path.insert(0, finder)
            return True
        return False
    
    def remove_meta_path_hook(self, finder):
        if finder in sys.meta_path:
            sys.meta_path.remove(finder)
            return True
        return False
    
    def clear_meta_path(self):
        sys.meta_path.clear()
    
    def has_meta_path_hook(self, finder):
        return finder in sys.meta_path
    
    def get_path_hooks(self):
        return sys.path_hooks.copy()
    
    def set_trace(self, func):
        sys.settrace(func)
    
    def get_trace(self):
        return sys.gettrace()
    
    def clear_trace(self):
        sys.settrace(None)
    
    def set_profile(self, func):
        sys.setprofile(func)
    
    def get_profile(self):
        return sys.getprofile() if hasattr(sys, 'getprofile') else None
    
    def clear_profile(self):
        sys.setprofile(None)
    
    def get_executable(self):
        return sys.executable
    
    def get_prefix(self):
        return sys.prefix
    
    def get_exec_prefix(self):
        return sys.exec_prefix
    
    def get_base_prefix(self):
        return getattr(sys, 'base_prefix', sys.prefix)
    
    def get_sizeof(self, obj):
        return sys.getsizeof(obj)
    
    def get_refcount(self, obj):
        return sys.getrefcount(obj)
    
    def get_force_gc_collection(self):
        return gc.collect()
    
    def set_gc_threshold(self, threshold0, threshold1=None, threshold2=None):
        old_threshold = gc.get_threshold()
        if threshold1 is None:
            gc.set_threshold(threshold0)
        elif threshold2 is None:
            gc.set_threshold(threshold0, threshold1)
        else:
            gc.set_threshold(threshold0, threshold1, threshold2)
        return old_threshold
    
    def get_gc_threshold(self):
        return gc.get_threshold()
    
    def enable_gc(self):
        gc.enable()
        return gc.isenabled()
    
    def disable_gc(self):
        gc.disable()
        return not gc.isenabled()
    
    def is_gc_enabled(self):
        return gc.isenabled()
    
    def get_gc_count(self):
        return gc.get_count()
    
    def get_gc_stats(self):
        return gc.get_stats() if hasattr(gc, 'get_stats') else None
    
    def force_gc(self, generation=None):
        if generation is not None:
            return gc.collect(generation)
        return gc.collect()
    
    def get_gc_objects(self, generation=None):
        if generation is not None:
            return gc.get_objects(generation) if hasattr(gc, 'get_objects') else []
        return gc.get_objects() if hasattr(gc, 'get_objects') else []
    
    def get_gc_referrers(self, *objs):
        return gc.get_referrers(*objs)
    
    def get_gc_referents(self, *objs):
        return gc.get_referents(*objs)
    
    def is_gc_tracked(self, obj):
        return gc.is_tracked(obj) if hasattr(gc, 'is_tracked') else None
    
    def freeze_gc(self):
        if hasattr(gc, 'freeze'):
            gc.freeze()
            return True
        return False
    
    def unfreeze_gc(self):
        if hasattr(gc, 'unfreeze'):
            gc.unfreeze()
            return True
        return False
    
    def get_pid(self):
        return getpid()
    
    def get_parent_pid(self):
        return getppid()
    
    def get_process_name(self):
        try:
            with open(f'/proc/{getpid()}/comm', 'r') as f:
                return f.read().strip()
        except:
            return 'python'
    
    def get_process_info(self):
        return {'pid': getpid(), 'ppid': getppid(), 'name': self.get_process_name()}
    
    def get_process_status(self):
        try:
            status = {}
            with open(f'/proc/{getpid()}/status', 'r') as f:
                for line in f:
                    if ':' in line:
                        k, v = line.split(':', 1)
                        status[k.strip()] = v.strip()
            return status
        except:
            return {}
    
    def get_cmdline(self):
        try:
            with open(f'/proc/{getpid()}/cmdline', 'r') as f:
                return f.read().split('\x00')
        except:
            return []
    
    def get_environ(self):
        return os.environ.copy()
    
    def get_cwd(self):
        return os.getcwd()
    
    def get_file_descriptors(self):
        try:
            fds = {}
            for fd_name in os.listdir(f'/proc/{getpid()}/fd'):
                try:
                    fds[int(fd_name)] = os.readlink(f'/proc/{getpid()}/fd/{fd_name}')
                except:
                    pass
            return fds
        except:
            return {}
    
    def get_cpu_times(self):
        try:
            with open(f'/proc/{getpid()}/stat', 'r') as f:
                data = f.read().split()
                return {'utime': int(data[13]), 'stime': int(data[14])}
        except:
            return {}
    
    def get_io_stats(self):
        try:
            io_stats = {}
            with open(f'/proc/{getpid()}/io', 'r') as f:
                for line in f:
                    if ':' in line:
                        k, v = line.split(':', 1)
                        io_stats[k.strip()] = int(v.strip())
            return io_stats
        except:
            return {}
    
    def get_maps(self):
        try:
            maps = []
            with open(f'/proc/{getpid()}/maps', 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 5:
                        maps.append({
                            'range': parts[0],
                            'perms': parts[1],
                            'offset': parts[2],
                            'device': parts[3],
                            'inode': parts[4]
                        })
            return maps
        except:
            return []
    
    def get_smaps(self):
        try:
            with open(f'/proc/{getpid()}/smaps', 'r') as f:
                return f.readlines()
        except:
            return []
    
    def get_numa_stats(self):
        try:
            with open(f'/proc/{getpid()}/numa_maps', 'r') as f:
                return f.readlines()
        except:
            return []
    
    def get_stack_info(self):
        frame = sys._getframe()
        stack = []
        while frame:
            stack.append({
                'filename': frame.f_code.co_filename,
                'function': frame.f_code.co_name,
                'lineno': frame.f_lineno
            })
            frame = frame.f_back
        return stack
    
    def get_stdin(self):
        return sys.stdin
    
    def get_stdout(self):
        return sys.stdout
    
    def get_stderr(self):
        return sys.stderr
    
    def set_stdin(self, stream):
        old = sys.stdin
        sys.stdin = stream
        return old
    
    def set_stdout(self, stream):
        old = sys.stdout
        sys.stdout = stream
        return old
    
    def set_stderr(self, stream):
        old = sys.stderr
        sys.stderr = stream
        return old
    
    def print_to_stdout(self, msg):
        sys.stdout.write(str(msg) + '\n')
        sys.stdout.flush()
    
    def print_to_stderr(self, msg):
        sys.stderr.write(str(msg) + '\n')
        sys.stderr.flush()
    
    def capture_output(self):
        import io
        capture = io.StringIO()
        old = sys.stdout
        sys.stdout = capture
        return capture, old
    
    def restore_output(self, old):
        sys.stdout = old
    
    def get_flags(self):
        flags = {}
        if hasattr(sys, 'flags'):
            for attr in dir(sys.flags):
                if not attr.startswith('_'):
                    flags[attr] = getattr(sys.flags, attr)
        return flags
    
    def get_reference_count(self, obj):
        return sys.getrefcount(obj)
    
    def is_optimized(self):
        return not __debug__
    
    def get_default_encoding(self):
        return sys.getdefaultencoding()
    
    def get_filesystem_encoding(self):
        return sys.getfilesystemencoding()
    
    def get_max_int(self):
        return sys.maxsize
    
    def get_float_info(self):
        return {
            'max': sys.float_info.max,
            'min': sys.float_info.min,
            'epsilon': sys.float_info.epsilon
        }
    
    def is_frozen(self):
        return getattr(sys, 'frozen', False)
    
    def save_state(self, state_id):
        self._saved_states[state_id] = {
            'recursion_limit': self.get_recursion_limit(),
            'path': self.get_path(),
            'modules': list(self.get_modules().keys())
        }
        return state_id
    
    def restore_state(self, state_id):
        if state_id not in self._saved_states:
            return False
        state = self._saved_states[state_id]
        self.set_recursion_limit(state['recursion_limit'])
        return True
    
    def list_states(self):
        return list(self._saved_states.keys())
    
    def delete_state(self, state_id):
        if state_id in self._saved_states:
            del self._saved_states[state_id]
            return True
        return False


class ExceptionHook(object):
    
    def __init__(self):
        self._original_excepthook = sys.excepthook
        self._hooks = []
        self._installed = False
    
    def _dispatch(self, exc_type, exc_value, exc_tb):
        for hook in self._hooks:
            try:
                hook(exc_type, exc_value, exc_tb)
            except Exception:
                pass
        self._original_excepthook(exc_type, exc_value, exc_tb)
    
    def install(self):
        if not self._installed:
            sys.excepthook = self._dispatch
            self._installed = True
        return self._installed
    
    def uninstall(self):
        if self._installed:
            sys.excepthook = self._original_excepthook
            self._installed = False
        return not self._installed
    
    def add_hook(self, hook):
        if callable(hook) and hook not in self._hooks:
            self._hooks.append(hook)
            return True
        return False
    
    def remove_hook(self, hook):
        if hook in self._hooks:
            self._hooks.remove(hook)
            return True
        return False
    
    def clear_hooks(self):
        count = len(self._hooks)
        self._hooks.clear()
        return count


class DisplayHook(object):
    
    def __init__(self):
        self._original_displayhook = sys.displayhook
        self._hooks = []
        self._installed = False
    
    def _dispatch(self, value):
        for hook in self._hooks:
            try:
                result = hook(value)
                if result is not None:
                    value = result
            except Exception:
                pass
        self._original_displayhook(value)
    
    def install(self):
        if not self._installed:
            sys.displayhook = self._dispatch
            self._installed = True
        return self._installed
    
    def uninstall(self):
        if self._installed:
            sys.displayhook = self._original_displayhook
            self._installed = False
        return not self._installed
    
    def add_hook(self, hook):
        if callable(hook) and hook not in self._hooks:
            self._hooks.append(hook)
            return True
        return False
    
    def remove_hook(self, hook):
        if hook in self._hooks:
            self._hooks.remove(hook)
            return True
        return False


def get_interpreter():
    return InterpreterController()


def get_interpreter_state():
    return InterpreterState()


def get_exception_hook():
    return ExceptionHook()


def get_display_hook():
    return DisplayHook()


class CompleteInterpreterController(InterpreterController):
    
    def execute_code(self, code, globals_dict=None, locals_dict=None):
        if globals_dict is None:
            globals_dict = {}
        if locals_dict is None:
            locals_dict = globals_dict
        exec(code, globals_dict, locals_dict)
        return locals_dict
    
    def evaluate_code(self, expr, globals_dict=None, locals_dict=None):
        if globals_dict is None:
            globals_dict = {}
        if locals_dict is None:
            locals_dict = globals_dict
        return eval(expr, globals_dict, locals_dict)
    
    def compile_code(self, source, filename="<string>", mode="exec"):
        return compile(source, filename, mode)
    
    def create_function(self, code_obj, globals_dict=None):
        import types
        if globals_dict is None:
            globals_dict = {}
        return types.FunctionType(code_obj, globals_dict)
    
    def get_function_code(self, func):
        return func.__code__ if hasattr(func, '__code__') else None
    
    def get_function_globals(self, func):
        return func.__globals__ if hasattr(func, '__globals__') else {}
    
    def get_function_locals(self, func):
        return func.__locals__ if hasattr(func, '__locals__') else {}
    
    def get_function_closure(self, func):
        return func.__closure__ if hasattr(func, '__closure__') else None
    
    def set_function_code(self, func, code_obj):
        import types
        if hasattr(func, '__code__'):
            func.__code__ = code_obj
            return True
        return False
    
    def get_class_bases(self, cls):
        return cls.__bases__ if hasattr(cls, '__bases__') else ()
    
    def get_class_dict(self, cls):
        return dict(cls.__dict__) if hasattr(cls, '__dict__') else {}
    
    def get_class_mro(self, cls):
        return cls.__mro__ if hasattr(cls, '__mro__') else ()
    
    def get_object_attributes(self, obj):
        return {attr: getattr(obj, attr) for attr in dir(obj) if not attr.startswith('_')}
    
    def get_object_dict(self, obj):
        return obj.__dict__ if hasattr(obj, '__dict__') else {}
    
    def set_object_attribute(self, obj, name, value):
        setattr(obj, name, value)
        return True
    
    def delete_object_attribute(self, obj, name):
        try:
            delattr(obj, name)
            return True
        except:
            return False
    
    def get_module_dict(self, module_name):
        if module_name in sys.modules:
            return dict(sys.modules[module_name].__dict__)
        return {}
    
    def get_module_file(self, module_name):
        if module_name in sys.modules:
            return getattr(sys.modules[module_name], '__file__', None)
        return None
    
    def get_module_name(self, module_name):
        if module_name in sys.modules:
            return getattr(sys.modules[module_name], '__name__', None)
        return None
    
    def get_module_doc(self, module_name):
        if module_name in sys.modules:
            return getattr(sys.modules[module_name], '__doc__', None)
        return None
    
    def reload_module(self, module_name):
        import importlib
        if module_name in sys.modules:
            try:
                return importlib.reload(sys.modules[module_name])
            except:
                return None
        return None
    
    def import_module(self, module_name):
        import importlib
        try:
            return importlib.import_module(module_name)
        except:
            return None
    
    def get_all_attributes(self, obj):
        return dir(obj)
    
    def get_builtin_functions(self):
        import builtins
        return {name: getattr(builtins, name) for name in dir(builtins) if not name.startswith('_')}
    
    def get_builtin_modules(self):
        return [name for name in sys.builtin_module_names]
    
    def get_frozen_modules(self):
        return [name for name in sys.modules if sys.modules[name].__loader__.__class__.__name__ == 'FrozenImporter'] if hasattr(sys, 'modules') else []
    
    def get_namespace(self):
        return {'builtins': self.get_builtin_functions(), 'modules': list(sys.modules.keys())}
    
    def get_locals_namespace(self):
        frame = sys._getframe(1)
        return frame.f_locals
    
    def get_globals_namespace(self):
        frame = sys._getframe(1)
        return frame.f_globals
    
    def create_namespace(self):
        return {}
    
    def merge_namespaces(self, ns1, ns2):
        result = ns1.copy()
        result.update(ns2)
        return result
    
    def get_frame_info(self, depth=0):
        try:
            frame = sys._getframe(depth + 1)
            return {
                'filename': frame.f_code.co_filename,
                'function': frame.f_code.co_name,
                'line': frame.f_lineno,
                'locals': len(frame.f_locals),
                'globals': len(frame.f_globals)
            }
        except:
            return {}
    
    def get_all_frames(self):
        frames = []
        frame = sys._getframe()
        while frame:
            frames.append({
                'filename': frame.f_code.co_filename,
                'function': frame.f_code.co_name,
                'line': frame.f_lineno
            })
            frame = frame.f_back
        return frames
    
    def get_code_object_info(self, code_obj):
        return {
            'filename': code_obj.co_filename,
            'name': code_obj.co_name,
            'argcount': code_obj.co_argcount,
            'kwonlyargcount': code_obj.co_kwonlyargcount,
            'nlocals': code_obj.co_nlocals,
            'stacksize': code_obj.co_stacksize,
            'flags': code_obj.co_flags,
            'firstlineno': code_obj.co_firstlineno,
            'varnames': code_obj.co_varnames,
            'names': code_obj.co_names
        }
    
    def get_bytecode(self, code_obj):
        import dis
        return code_obj.co_code
    
    def disassemble_code(self, code_obj):
        import dis
        import io
        output = io.StringIO()
        dis.disassemble(code_obj, file=output)
        return output.getvalue()
    
    def get_code_constants(self, code_obj):
        return code_obj.co_consts if hasattr(code_obj, 'co_consts') else ()
    
    def get_code_names(self, code_obj):
        return code_obj.co_names if hasattr(code_obj, 'co_names') else ()
    
    def get_code_varnames(self, code_obj):
        return code_obj.co_varnames if hasattr(code_obj, 'co_varnames') else ()
    
    def get_code_freevars(self, code_obj):
        return code_obj.co_freevars if hasattr(code_obj, 'co_freevars') else ()
    
    def get_code_cellvars(self, code_obj):
        return code_obj.co_cellvars if hasattr(code_obj, 'co_cellvars') else ()
    
    def inspect_object(self, obj):
        return {
            'type': type(obj).__name__,
            'id': id(obj),
            'size': sys.getsizeof(obj),
            'refcount': sys.getrefcount(obj),
            'attributes': [attr for attr in dir(obj) if not attr.startswith('_')],
            'callable': callable(obj),
            'hasdict': hasattr(obj, '__dict__')
        }
    
    def get_object_type(self, obj):
        return type(obj)
    
    def get_object_id(self, obj):
        return id(obj)
    
    def get_object_size(self, obj):
        return sys.getsizeof(obj)
    
    def is_callable(self, obj):
        return callable(obj)
    
    def is_instance(self, obj, cls):
        return isinstance(obj, cls)
    
    def is_subclass(self, cls1, cls2):
        try:
            return issubclass(cls1, cls2)
        except:
            return False
    
    def get_mro(self, cls):
        try:
            return cls.__mro__
        except:
            return ()
    
    def call_function(self, func, *args, **kwargs):
        return func(*args, **kwargs)
    
    def call_function_safe(self, func, *args, **kwargs):
        try:
            return func(*args, **kwargs), None
        except Exception as e:
            return None, str(e)
    
    def get_lambda_code(self, lambda_func):
        return self.get_function_code(lambda_func)
    
    def create_wrapper(self, func):
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper
    
    def get_exception_type(self):
        import sys as _sys
        exc_type, exc_value, exc_tb = _sys.exc_info()
        return exc_type
    
    def get_exception_value(self):
        import sys as _sys
        exc_type, exc_value, exc_tb = _sys.exc_info()
        return exc_value
    
    def get_exception_traceback(self):
        import sys as _sys
        exc_type, exc_value, exc_tb = _sys.exc_info()
        return exc_tb
    
    def format_exception(self, exc_type=None, exc_value=None, exc_tb=None):
        import traceback
        if exc_type is None:
            import sys as _sys
            exc_type, exc_value, exc_tb = _sys.exc_info()
        return ''.join(traceback.format_exception(exc_type, exc_value, exc_tb))
    
    def get_last_exception(self):
        import sys as _sys
        exc_type, exc_value, exc_tb = _sys.exc_info()
        return {'type': exc_type, 'value': exc_value, 'traceback': exc_tb}
    
    def clear_exception(self):
        import sys as _sys
        _sys.exc_clear() if hasattr(_sys, 'exc_clear') else None
        return True
    
    def get_object_methods(self, obj):
        return [attr for attr in dir(obj) if callable(getattr(obj, attr)) and not attr.startswith('_')]
    
    def get_object_properties(self, obj):
        return [attr for attr in dir(obj) if not callable(getattr(obj, attr)) and not attr.startswith('_')]
    
    def get_class_methods(self, cls):
        methods = {}
        for attr in dir(cls):
            if not attr.startswith('_'):
                obj = getattr(cls, attr)
                if callable(obj):
                    methods[attr] = obj
        return methods
    
    def get_class_properties(self, cls):
        props = {}
        for attr in dir(cls):
            if not attr.startswith('_'):
                obj = getattr(cls, attr)
                if not callable(obj):
                    props[attr] = obj
        return props
    
    def get_instance_methods(self, obj):
        return self.get_object_methods(obj)
    
    def get_instance_properties(self, obj):
        return self.get_object_properties(obj)
    
    def list_all_functions(self):
        funcs = []
        for name, obj in self.get_builtin_functions().items():
            if callable(obj):
                funcs.append(name)
        for name in sys.modules:
            try:
                module = sys.modules[name]
                for attr in dir(module):
                    obj = getattr(module, attr)
                    if callable(obj) and not attr.startswith('_'):
                        funcs.append(f"{name}.{attr}")
            except:
                pass
        return funcs
    
    def list_all_classes(self):
        classes = []
        for name in sys.modules:
            try:
                module = sys.modules[name]
                for attr in dir(module):
                    obj = getattr(module, attr)
                    if isinstance(obj, type) and not attr.startswith('_'):
                        classes.append(f"{name}.{attr}")
            except:
                pass
        return classes
    
    def get_system_info(self):
        return {
            'version': self.get_version_info(),
            'platform': self.get_platform_info(),
            'encoding': self.get_default_encoding(),
            'filesystem_encoding': self.get_filesystem_encoding(),
            'prefix': self.get_prefix(),
            'exec_prefix': self.get_exec_prefix(),
            'executable': self.get_executable(),
            'builtin_modules': self.get_builtin_modules(),
            'loaded_modules': len(self.get_modules())
        }
    
    def get_complete_interpreter_state(self):
        return {
            'pid': self.get_pid(),
            'ppid': self.get_parent_pid(),
            'recursion_limit': self.get_recursion_limit(),
            'gc_enabled': self.is_gc_enabled(),
            'modules': len(self.get_modules()),
            'paths': len(self.get_path()),
            'system_info': self.get_system_info(),
            'frame_info': self.get_frame_info(),
            'exception': self.get_last_exception()
        }
    
    def apply_all_controls(self, **kwargs):
        results = {}
        if 'recursion_limit' in kwargs:
            results['recursion_limit'] = self.set_recursion_limit(kwargs['recursion_limit'])
        if 'gc_enabled' in kwargs:
            if kwargs['gc_enabled']:
                results['gc_enabled'] = self.enable_gc()
            else:
                results['gc_enabled'] = self.disable_gc()
        if 'add_paths' in kwargs:
            results['add_paths'] = [self.add_path(p) for p in kwargs['add_paths']]
        return results


def get_complete_interpreter():
    return CompleteInterpreterController()
