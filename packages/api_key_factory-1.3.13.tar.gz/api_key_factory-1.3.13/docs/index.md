# Overview

Version: 1.3.13

A simple CLI tools to generate API keys and their corresponding SHA-256 hashes.
