"""Centralized configuration constants for klaude_code.

This module consolidates all magic numbers and configuration values
that were previously scattered across the codebase.
"""

# =============================================================================
# Agent Configuration
# =============================================================================

# Timeout for waiting for the first event from LLM (seconds)
FIRST_EVENT_TIMEOUT_S = 200.0

# Maximum number of retry attempts for failed turns
MAX_FAILED_TURN_RETRIES = 10

# Initial delay before retrying a failed turn (seconds)
INITIAL_RETRY_DELAY_S = 1.0

# Maximum delay between retries (seconds)
MAX_RETRY_DELAY_S = 30.0

# Message shown when a tool call is cancelled by the user
CANCEL_OUTPUT = "[Request interrupted by user for tool use]"

# Default maximum tokens for LLM responses
DEFAULT_MAX_TOKENS = 32000

# Default temperature for LLM requests
DEFAULT_TEMPERATURE = 1.0

# Default thinking budget tokens for Anthropic models
DEFAULT_ANTHROPIC_THINKING_BUDGET_TOKENS = 2048

# Tool call count threshold for todo reminder
TODO_REMINDER_TOOL_CALL_THRESHOLD = 10


# =============================================================================
# Tool
# =============================================================================

# -- Read Tool --
# Maximum characters per line before truncation
READ_CHAR_LIMIT_PER_LINE = 2000

# Maximum number of lines to read from a file
READ_GLOBAL_LINE_CAP = 2000

# Maximum total characters to read
READ_MAX_CHARS = 60000

# Maximum file size in KB for text files
READ_MAX_KB = 256

# Maximum image file size in bytes (4MB)
READ_MAX_IMAGE_BYTES = 4 * 1024 * 1024

# -- Bash Tool --
# Default timeout for bash commands (milliseconds)
BASH_DEFAULT_TIMEOUT_MS = 120000

# -- Tool Output --
# Maximum length for tool output before truncation
TOOL_OUTPUT_MAX_LENGTH = 50000

# Characters to show from the beginning of truncated output
TOOL_OUTPUT_DISPLAY_HEAD = 10000

# Characters to show from the end of truncated output
TOOL_OUTPUT_DISPLAY_TAIL = 10000

# Directory for saving full truncated output
TOOL_OUTPUT_TRUNCATION_DIR = "/tmp/klaude"


# =============================================================================
# UI
# =============================================================================

# Width of line number prefix in diff display
DIFF_PREFIX_WIDTH = 4

# Maximum lines to show in diff output
MAX_DIFF_LINES = 1000

# Maximum length for invalid tool call display
INVALID_TOOL_CALL_MAX_LENGTH = 500

# Maximum line length for truncated display output
TRUNCATE_DISPLAY_MAX_LINE_LENGTH = 1000

# Maximum lines for truncated display output
TRUNCATE_DISPLAY_MAX_LINES = 10

# Maximum lines for sub-agent result display
SUB_AGENT_RESULT_MAX_LINES = 12


# UI refresh rate (frames per second) for debounced content streaming
UI_REFRESH_RATE_FPS = 20

# Number of lines to keep visible at bottom of markdown streaming window
MARKDOWN_STREAM_LIVE_WINDOW = 20

# Status shimmer animation
# Horizontal padding used when computing shimmer band position
STATUS_SHIMMER_PADDING = 10
# Duration in seconds for one full shimmer sweep across the text
STATUS_SHIMMER_SWEEP_SECONDS = 2
# Half-width of the shimmer band in characters
STATUS_SHIMMER_BAND_HALF_WIDTH = 5.0
# Scale factor applied to shimmer intensity when blending colors
STATUS_SHIMMER_ALPHA_SCALE = 0.7

# Spinner breathing animation
# Duration in seconds for one full breathe-in + breathe-out cycle
# Keep in sync with STATUS_SHIMMER_SWEEP_SECONDS for visual consistency
SPINNER_BREATH_PERIOD_SECONDS = 2


# =============================================================================
# Debug / Logging
# =============================================================================

# Default debug log file path
DEFAULT_DEBUG_LOG_FILE = "debug.log"

# Maximum log file size before rotation (10MB)
LOG_MAX_BYTES = 10 * 1024 * 1024

# Number of backup log files to keep
LOG_BACKUP_COUNT = 3
