import json
from pathlib import Path

from rich.console import RenderableType
from rich.padding import Padding
from rich.text import Text

from klaude_code import const
from klaude_code.protocol import events, model
from klaude_code.protocol.sub_agent import is_sub_agent_tool as _is_sub_agent_tool
from klaude_code.ui.renderers import diffs as r_diffs
from klaude_code.ui.renderers.common import create_grid
from klaude_code.ui.rich.theme import ThemeKey
from klaude_code.ui.utils.common import truncate_display


def is_sub_agent_tool(tool_name: str) -> bool:
    return _is_sub_agent_tool(tool_name)


def render_path(path: str, style: str, is_directory: bool = False) -> Text:
    if path.startswith(str(Path().cwd())):
        path = path.replace(str(Path().cwd()), "").lstrip("/")
    elif path.startswith(str(Path().home())):
        path = path.replace(str(Path().home()), "~")
    elif not path.startswith("/") and not path.startswith("."):
        path = "./" + path
    if is_directory:
        path = path.rstrip("/") + "/"
    return Text(path, style=style)


def render_generic_tool_call(tool_name: str, arguments: str, markup: str = "•") -> RenderableType:
    grid = create_grid()

    tool_name_column = Text.assemble((markup, ThemeKey.TOOL_MARK), " ", (tool_name, ThemeKey.TOOL_NAME))
    arguments_column = Text("")
    if not arguments:
        grid.add_row(tool_name_column, arguments_column)
        return grid
    try:
        json_dict = json.loads(arguments)
        if len(json_dict) == 0:
            arguments_column = Text("", ThemeKey.TOOL_PARAM)
        elif len(json_dict) == 1:
            arguments_column = Text(str(next(iter(json_dict.values()))), ThemeKey.TOOL_PARAM)
        else:
            arguments_column = Text(
                ", ".join([f"{k}: {v}" for k, v in json_dict.items()]),
                ThemeKey.TOOL_PARAM,
            )
    except json.JSONDecodeError:
        arguments_column = Text(
            arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
    grid.add_row(tool_name_column, arguments_column)
    return grid


def render_update_plan_tool_call(arguments: str) -> RenderableType:
    grid = create_grid()
    tool_name_column = Text.assemble(("◎", ThemeKey.TOOL_MARK), " ", ("Update Plan", ThemeKey.TOOL_NAME))
    explanation_column = Text("")

    if arguments:
        try:
            payload = json.loads(arguments)
        except json.JSONDecodeError:
            explanation_column = Text(
                arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
                style=ThemeKey.INVALID_TOOL_CALL_ARGS,
            )
        else:
            explanation = payload.get("explanation")
            if isinstance(explanation, str) and explanation.strip():
                explanation_column = Text(explanation.strip(), style=ThemeKey.TODO_EXPLANATION)

    grid.add_row(tool_name_column, explanation_column)
    return grid


def render_read_tool_call(arguments: str) -> RenderableType:
    grid = create_grid()
    render_result: Text = Text.assemble(("Read", ThemeKey.TOOL_NAME), " ")
    try:
        json_dict = json.loads(arguments)
        file_path = json_dict.get("file_path")
        limit = json_dict.get("limit", None)
        offset = json_dict.get("offset", None)
        render_result = render_result.append_text(render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH))
        if limit is not None and offset is not None:
            render_result = (
                render_result.append_text(Text(" "))
                .append_text(Text(str(offset), ThemeKey.TOOL_PARAM_BOLD))
                .append_text(Text(":", ThemeKey.TOOL_PARAM))
                .append_text(Text(str(offset + limit - 1), ThemeKey.TOOL_PARAM_BOLD))
            )
        elif limit is not None:
            render_result = (
                render_result.append_text(Text(" "))
                .append_text(Text("1", ThemeKey.TOOL_PARAM_BOLD))
                .append_text(Text(":", ThemeKey.TOOL_PARAM))
                .append_text(Text(str(limit), ThemeKey.TOOL_PARAM_BOLD))
            )
        elif offset is not None:
            render_result = (
                render_result.append_text(Text(" "))
                .append_text(Text(str(offset), ThemeKey.TOOL_PARAM_BOLD))
                .append_text(Text(":", ThemeKey.TOOL_PARAM))
                .append_text(Text("-", ThemeKey.TOOL_PARAM_BOLD))
            )
    except json.JSONDecodeError:
        render_result = render_result.append_text(
            Text(
                arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
                style=ThemeKey.INVALID_TOOL_CALL_ARGS,
            )
        )
    grid.add_row(Text("←", ThemeKey.TOOL_MARK), render_result)
    return grid


def render_edit_tool_call(arguments: str) -> Text:
    render_result: Text = Text.assemble(("→ ", ThemeKey.TOOL_MARK))
    try:
        json_dict = json.loads(arguments)
        file_path = json_dict.get("file_path")
        render_result = (
            render_result.append_text(Text("Edit", ThemeKey.TOOL_NAME))
            .append_text(Text(" "))
            .append_text(render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH))
        )
    except json.JSONDecodeError:
        render_result = (
            render_result.append_text(Text("Edit", ThemeKey.TOOL_NAME))
            .append_text(Text(" "))
            .append_text(
                Text(
                    arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
                    style=ThemeKey.INVALID_TOOL_CALL_ARGS,
                )
            )
        )
    return render_result


def render_write_tool_call(arguments: str) -> Text:
    render_result: Text = Text.assemble(("→ ", ThemeKey.TOOL_MARK))
    try:
        json_dict = json.loads(arguments)
        file_path = json_dict.get("file_path")
        op_label = "Create"
        if isinstance(file_path, str):
            abs_path = Path(file_path)
            if not abs_path.is_absolute():
                abs_path = (Path().cwd() / abs_path).resolve()
            if abs_path.exists():
                op_label = "Overwrite"
        render_result = (
            render_result.append_text(Text(op_label, ThemeKey.TOOL_NAME))
            .append_text(Text(" "))
            .append_text(render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH))
        )
    except json.JSONDecodeError:
        render_result = (
            render_result.append_text(Text("Write", ThemeKey.TOOL_NAME))
            .append_text(Text(" "))
            .append_text(
                Text(
                    arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
                    style=ThemeKey.INVALID_TOOL_CALL_ARGS,
                )
            )
        )
    return render_result


def render_multi_edit_tool_call(arguments: str) -> Text:
    render_result: Text = Text.assemble(("→ ", ThemeKey.TOOL_MARK), ("MultiEdit", ThemeKey.TOOL_NAME), " ")
    try:
        json_dict = json.loads(arguments)
        file_path = json_dict.get("file_path")
        edits = json_dict.get("edits", [])
        render_result = (
            render_result.append_text(render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH))
            .append_text(Text(" - "))
            .append_text(Text(f"{len(edits)}", ThemeKey.TOOL_PARAM_BOLD))
            .append_text(Text(" updates", ThemeKey.TOOL_PARAM_FILE_PATH))
        )
    except json.JSONDecodeError:
        render_result = render_result.append_text(
            Text(
                arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
                style=ThemeKey.INVALID_TOOL_CALL_ARGS,
            )
        )
    return render_result


def render_apply_patch_tool_call(arguments: str) -> RenderableType:
    try:
        payload = json.loads(arguments)
    except json.JSONDecodeError:
        return Text.assemble(
            ("→ ", ThemeKey.TOOL_MARK),
            ("Apply Patch", ThemeKey.TOOL_NAME),
            " ",
            Text(
                arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
                style=ThemeKey.INVALID_TOOL_CALL_ARGS,
            ),
        )

    patch_content = payload.get("patch", "")

    grid = create_grid()
    header = Text.assemble(("→ ", ThemeKey.TOOL_MARK), ("Apply Patch", ThemeKey.TOOL_NAME))
    summary = Text("", ThemeKey.TOOL_PARAM)

    if isinstance(patch_content, str):
        lines = [line for line in patch_content.splitlines() if line and not line.startswith("*** Begin Patch")]
        if lines:
            summary = Text(lines[0][: const.INVALID_TOOL_CALL_MAX_LENGTH], ThemeKey.TOOL_PARAM)
    else:
        summary = Text(
            str(patch_content)[: const.INVALID_TOOL_CALL_MAX_LENGTH],
            ThemeKey.INVALID_TOOL_CALL_ARGS,
        )

    if summary.plain:
        grid.add_row(header, summary)
    else:
        grid.add_row(header, Text("", ThemeKey.TOOL_PARAM))

    return grid


def render_todo(tr: events.ToolResultEvent) -> RenderableType:
    if tr.ui_extra is None:
        return Text.assemble(
            ("  ✘", ThemeKey.ERROR_BOLD),
            " ",
            Text("(no content)", style=ThemeKey.ERROR),
        )
    if tr.ui_extra.type != model.ToolResultUIExtraType.TODO_LIST or tr.ui_extra.todo_list is None:
        return Text.assemble(
            ("  ✘", ThemeKey.ERROR_BOLD),
            " ",
            Text("(invalid ui_extra)", style=ThemeKey.ERROR),
        )

    ui_extra = tr.ui_extra.todo_list
    todo_grid = create_grid()
    for todo in ui_extra.todos:
        is_new_completed = todo.content in ui_extra.new_completed
        match todo.status:
            case "pending":
                mark = "▢"
                mark_style = ThemeKey.TODO_PENDING_MARK
                text_style = ThemeKey.TODO_PENDING
            case "in_progress":
                mark = "◉"
                mark_style = ThemeKey.TODO_IN_PROGRESS_MARK
                text_style = ThemeKey.TODO_IN_PROGRESS
            case "completed":
                mark = "✔"
                mark_style = ThemeKey.TODO_NEW_COMPLETED_MARK if is_new_completed else ThemeKey.TODO_COMPLETED_MARK
                text_style = ThemeKey.TODO_NEW_COMPLETED if is_new_completed else ThemeKey.TODO_COMPLETED
        text = Text(todo.content)
        text.stylize(text_style)
        todo_grid.add_row(Text(mark, style=mark_style), text)

    return Padding.indent(todo_grid, level=2)


def render_generic_tool_result(result: str, *, is_error: bool = False) -> RenderableType:
    """Render a generic tool result as indented, truncated text."""
    style = ThemeKey.ERROR if is_error else ThemeKey.TOOL_RESULT
    return Padding.indent(Text(truncate_display(result), style=style), level=2)


def _extract_mermaid_link(
    ui_extra: model.ToolResultUIExtra | None,
) -> model.MermaidLinkUIExtra | None:
    if ui_extra is None:
        return None
    if ui_extra.type != model.ToolResultUIExtraType.MERMAID_LINK:
        return None
    return ui_extra.mermaid_link


def render_memory_tool_call(arguments: str) -> RenderableType:
    grid = create_grid()
    command_display_names: dict[str, str] = {
        "view": "View",
        "create": "Create",
        "str_replace": "Replace",
        "insert": "Insert",
        "delete": "Delete",
        "rename": "Rename",
    }

    try:
        payload: dict[str, str] = json.loads(arguments)
    except json.JSONDecodeError:
        tool_name_column = Text.assemble(("★", ThemeKey.TOOL_MARK), " ", ("Memory", ThemeKey.TOOL_NAME))
        summary = Text(
            arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
        grid.add_row(tool_name_column, summary)
        return grid

    command = payload.get("command", "")
    display_name = command_display_names.get(command, command.title())
    tool_name_column = Text.assemble(("★", ThemeKey.TOOL_MARK), " ", (f"{display_name} Memory", ThemeKey.TOOL_NAME))

    summary = Text("", ThemeKey.TOOL_PARAM)
    path = payload.get("path")
    old_path = payload.get("old_path")
    new_path = payload.get("new_path")

    if command == "rename" and old_path and new_path:
        summary = Text.assemble(
            Text(old_path, ThemeKey.TOOL_PARAM_FILE_PATH),
            Text(" -> ", ThemeKey.TOOL_PARAM),
            Text(new_path, ThemeKey.TOOL_PARAM_FILE_PATH),
        )
    elif command == "insert" and path:
        insert_line = payload.get("insert_line")
        summary = Text(path, ThemeKey.TOOL_PARAM_FILE_PATH)
        if insert_line is not None:
            summary.append(f" line {insert_line}", ThemeKey.TOOL_PARAM)
    elif command == "view" and path:
        view_range = payload.get("view_range")
        summary = Text(path, ThemeKey.TOOL_PARAM_FILE_PATH)
        if view_range and isinstance(view_range, list) and len(view_range) >= 2:
            summary.append(f" {view_range[0]}:{view_range[1]}", ThemeKey.TOOL_PARAM)
    elif path:
        summary = Text(path, ThemeKey.TOOL_PARAM_FILE_PATH)

    grid.add_row(tool_name_column, summary)
    return grid


def render_mermaid_tool_call(arguments: str) -> RenderableType:
    grid = create_grid()
    tool_name_column = Text.assemble(("⧉", ThemeKey.TOOL_MARK), " ", ("Mermaid", ThemeKey.TOOL_NAME))
    summary = Text("", ThemeKey.TOOL_PARAM)

    try:
        payload: dict[str, str] = json.loads(arguments)
    except json.JSONDecodeError:
        summary = Text(
            arguments.strip()[: const.INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
    else:
        code = payload.get("code", "")
        if code:
            line_count = len(code.splitlines())
            summary = Text(f"{line_count} lines", ThemeKey.TOOL_PARAM)
        else:
            summary = Text("0 lines", ThemeKey.TOOL_PARAM)

    grid.add_row(tool_name_column, summary)
    return grid


def render_mermaid_tool_result(tr: events.ToolResultEvent) -> RenderableType:
    link_info = _extract_mermaid_link(tr.ui_extra)
    if link_info is None:
        return render_generic_tool_result(tr.result, is_error=tr.status == "error")

    link_text = Text.from_markup(f"[blue u][link={link_info.link}]Command+click to view[/link][/blue u]")
    return Padding.indent(link_text, level=2)


def _extract_truncation(
    ui_extra: model.ToolResultUIExtra | None,
) -> model.TruncationUIExtra | None:
    if ui_extra is None:
        return None
    if ui_extra.type != model.ToolResultUIExtraType.TRUNCATION:
        return None
    return ui_extra.truncation


def render_truncation_info(ui_extra: model.TruncationUIExtra) -> RenderableType:
    """Render truncation info for the user."""
    original_kb = ui_extra.original_length / 1024
    truncated_kb = ui_extra.truncated_length / 1024
    text = Text.assemble(
        ("Output truncated: ", ThemeKey.TOOL_RESULT),
        (f"{original_kb:.1f}KB", ThemeKey.TOOL_RESULT),
        (" total, ", ThemeKey.TOOL_RESULT),
        (f"{truncated_kb:.1f}KB", ThemeKey.TOOL_RESULT_BOLD),
        (" hidden\nFull output saved to ", ThemeKey.TOOL_RESULT),
        (ui_extra.saved_file_path, ThemeKey.TOOL_RESULT),
        ("\nUse Read with limit+offset or rg/grep to inspect", ThemeKey.TOOL_RESULT),
    )
    return Padding.indent(text, level=2)


def get_truncation_info(tr: events.ToolResultEvent) -> model.TruncationUIExtra | None:
    """Extract truncation info from a tool result event."""
    return _extract_truncation(tr.ui_extra)


# Tool name to mark mapping
_TOOL_MARKS: dict[str, str] = {
    "Read": "←",
    "Edit": "→",
    "Write": "→",
    "MultiEdit": "→",
    "Bash": ">",
    "apply_patch": "→",
    "TodoWrite": "◎",
    "update_plan": "◎",
    "Mermaid": "⧉",
    "Memory": "★",
    "Skill": "◈",
}

# Tool name to active form mapping (for spinner status)
_TOOL_ACTIVE_FORM: dict[str, str] = {
    "Bash": "Bashing",
    "apply_patch": "Patching",
    "Edit": "Editing",
    "MultiEdit": "Editing",
    "Read": "Reading",
    "Write": "Writing",
    "TodoWrite": "Planning",
    "update_plan": "Planning",
    "Skill": "Skilling",
    "Mermaid": "Diagramming",
    "Memory": "Memorizing",
    "WebFetch": "Fetching",
}


def get_tool_active_form(tool_name: str) -> str:
    """Get the active form of a tool name for spinner status.

    Checks both the static mapping and sub agent profiles.
    """
    if tool_name in _TOOL_ACTIVE_FORM:
        return _TOOL_ACTIVE_FORM[tool_name]

    # Check sub agent profiles
    from klaude_code.protocol.sub_agent import get_sub_agent_profile_by_tool

    profile = get_sub_agent_profile_by_tool(tool_name)
    if profile and profile.active_form:
        return profile.active_form

    return f"Calling {tool_name}"


def render_tool_call(e: events.ToolCallEvent) -> RenderableType | None:
    """Unified entry point for rendering tool calls.

    Returns a Rich Renderable or None if the tool call should not be rendered.
    """
    from klaude_code.protocol import tools

    if is_sub_agent_tool(e.tool_name):
        return None

    match e.tool_name:
        case tools.READ:
            return render_read_tool_call(e.arguments)
        case tools.EDIT:
            return render_edit_tool_call(e.arguments)
        case tools.WRITE:
            return render_write_tool_call(e.arguments)
        case tools.MULTI_EDIT:
            return render_multi_edit_tool_call(e.arguments)
        case tools.BASH:
            return render_generic_tool_call(e.tool_name, e.arguments, ">")
        case tools.APPLY_PATCH:
            return render_apply_patch_tool_call(e.arguments)
        case tools.TODO_WRITE:
            return render_generic_tool_call("Update Todos", "", "◎")
        case tools.UPDATE_PLAN:
            return render_update_plan_tool_call(e.arguments)
        case tools.MERMAID:
            return render_mermaid_tool_call(e.arguments)
        case tools.MEMORY:
            return render_memory_tool_call(e.arguments)
        case tools.SKILL:
            return render_generic_tool_call(e.tool_name, e.arguments, "◈")
        case _:
            return render_generic_tool_call(e.tool_name, e.arguments)


def _extract_diff_text(ui_extra: model.ToolResultUIExtra | None) -> str | None:
    if ui_extra is None:
        return None
    if ui_extra.type == model.ToolResultUIExtraType.DIFF_TEXT:
        return ui_extra.diff_text
    return None


def render_tool_result(e: events.ToolResultEvent) -> RenderableType | None:
    """Unified entry point for rendering tool results.

    Returns a Rich Renderable or None if the tool result should not be rendered.
    """
    from klaude_code.protocol import tools
    from klaude_code.ui.renderers import errors as r_errors

    if is_sub_agent_tool(e.tool_name):
        return None

    # Handle error case
    if e.status == "error" and e.ui_extra is None:
        error_msg = Text(truncate_display(e.result))
        return r_errors.render_error(error_msg)

    # Show truncation info if output was truncated and saved to file
    truncation_info = get_truncation_info(e)
    if truncation_info:
        return render_truncation_info(truncation_info)

    diff_text = _extract_diff_text(e.ui_extra)

    match e.tool_name:
        case tools.READ:
            return None
        case tools.EDIT | tools.MULTI_EDIT | tools.WRITE:
            return Padding.indent(r_diffs.render_diff(diff_text or ""), level=2)
        case tools.MEMORY:
            if diff_text:
                return Padding.indent(r_diffs.render_diff(diff_text), level=2)
            elif len(e.result.strip()) > 0:
                return render_generic_tool_result(e.result)
            return None
        case tools.TODO_WRITE | tools.UPDATE_PLAN:
            return render_todo(e)
        case tools.MERMAID:
            return render_mermaid_tool_result(e)
        case _:
            if e.tool_name in (tools.BASH, tools.APPLY_PATCH) and e.result.startswith("diff --git"):
                return r_diffs.render_diff_panel(e.result, show_file_name=True)
            if e.tool_name == tools.APPLY_PATCH and diff_text:
                return Padding.indent(r_diffs.render_diff(diff_text, show_file_name=True), level=2)
            if len(e.result.strip()) == 0:
                return render_generic_tool_result("(no content)")
            return render_generic_tool_result(e.result)
