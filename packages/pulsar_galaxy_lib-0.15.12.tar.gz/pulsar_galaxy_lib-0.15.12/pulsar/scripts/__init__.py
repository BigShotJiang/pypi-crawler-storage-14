""" This module contains entry points into various Pulsar scripts. Corresponding
shell scripts that setup the deployment specific environments and then
delegate to these Python scripts can be found in ``PULSAR_ROOT/scripts``.
"""
