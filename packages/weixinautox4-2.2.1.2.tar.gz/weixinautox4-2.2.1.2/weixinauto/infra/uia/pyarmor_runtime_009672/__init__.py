# Pyarmor 9.2.0 (basic), 009672, 2025-11-29T13:52:16.758397
from .pyarmor_runtime import __pyarmor__
