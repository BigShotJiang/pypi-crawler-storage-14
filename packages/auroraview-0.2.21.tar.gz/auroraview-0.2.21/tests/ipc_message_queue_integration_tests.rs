//! Integration tests for IPC MessageQueue
//!
//! These tests verify the complete message queue functionality including
//! push/pop operations, backpressure handling, retry logic, and dead letter queue integration.

use auroraview_core::ipc::message_queue::{MessageQueue, MessageQueueConfig};
use auroraview_core::ipc::WebViewMessage;
use rstest::*;

#[fixture]
fn small_queue_no_retry() -> MessageQueue {
    let cfg = MessageQueueConfig {
        capacity: 1,
        block_on_full: false,
        max_retries: 0,
        retry_delay_ms: 1,
    };
    MessageQueue::with_config(cfg)
}

#[fixture]
fn small_queue_with_retry() -> MessageQueue {
    let cfg = MessageQueueConfig {
        capacity: 1,
        block_on_full: false,
        max_retries: 1,
        retry_delay_ms: 1,
    };
    MessageQueue::with_config(cfg)
}

#[rstest]
fn test_push_pop_and_metrics(small_queue_no_retry: MessageQueue) {
    let q = small_queue_no_retry;
    q.push(WebViewMessage::EvalJs("1+1".into()));

    let mut processed = 0;
    processed += q.process_all(|m| match m {
        WebViewMessage::EvalJs(s) => assert_eq!(s, "1+1"),
        _ => unreachable!(),
    });

    assert_eq!(processed, 1, "Should process exactly one message");

    let snap = q.get_metrics_snapshot();
    assert_eq!(snap.messages_sent, 1, "Should have sent 1 message");
    assert_eq!(snap.messages_received, 1, "Should have received 1 message");
    assert!(
        snap.peak_queue_length >= 1,
        "Peak queue length should be at least 1"
    );
}

#[rstest]
fn test_backpressure_drop_and_retry_to_dlq(small_queue_with_retry: MessageQueue) {
    let q = small_queue_with_retry;

    // Fill the queue
    q.push(WebViewMessage::EvalJs("a".into()));

    // This immediate push should drop due to full queue
    q.push(WebViewMessage::EvalJs("b".into()));

    let snap = q.get_metrics_snapshot();
    assert!(
        snap.messages_dropped >= 1,
        "Should have dropped at least 1 message due to full queue"
    );

    // push_with_retry should attempt and then go to DLQ
    let err = q
        .push_with_retry(WebViewMessage::EvalJs("c".into()))
        .unwrap_err();

    assert!(
        err.contains("queue full") || err.contains("Channel disconnected"),
        "Error should indicate queue full or disconnected, got: {}",
        err
    );

    let stats = q.get_dlq_stats();
    assert!(stats.total >= 1, "DLQ should have at least 1 message");
    assert!(
        stats.queue_full >= 1 || stats.disconnected >= 1,
        "DLQ should have queue_full or disconnected failures"
    );

    // Drain queue to keep later tests stable
    let _ = q.process_all(|_| {});
}

#[rstest]
fn test_message_queue_creation() {
    let cfg = MessageQueueConfig {
        capacity: 10,
        block_on_full: false,
        max_retries: 3,
        retry_delay_ms: 10,
    };
    let q = MessageQueue::with_config(cfg);

    let snap = q.get_metrics_snapshot();
    assert_eq!(
        snap.messages_sent, 0,
        "New queue should have 0 messages sent"
    );
    assert_eq!(
        snap.messages_received, 0,
        "New queue should have 0 messages received"
    );
}

#[rstest]
fn test_multiple_message_types(small_queue_no_retry: MessageQueue) {
    let q = small_queue_no_retry;

    q.push(WebViewMessage::EvalJs("test".into()));

    let mut count = 0;
    q.process_all(|msg| match msg {
        WebViewMessage::EvalJs(s) => {
            assert_eq!(s, "test");
            count += 1;
        }
        _ => unreachable!("Should only have EvalJs messages"),
    });

    assert_eq!(count, 1, "Should process exactly one message");
}
