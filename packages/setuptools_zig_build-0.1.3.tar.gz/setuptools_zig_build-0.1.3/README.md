# Setuptools zig build

A setuptools extension, for building cpython extensions with zig build,
enabling source-only pip distributions that compile at install time.

## References

@ruamel and [setuptools-zig](https://sourceforge.net/p/setuptools-zig)
