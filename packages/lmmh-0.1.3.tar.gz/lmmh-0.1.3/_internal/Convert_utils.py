KeyNumber = 2 
DETER = 'LSLMMHLS'

def New_Convert_To_LMMH_Data(Text):
    """
    Convert plain text to its encrypted string using a random substitution map.
    """
    import random
    import string  # Only used here
    
    
    decoded_text = ""
    
    conver0 = ''.join(random.choices(string.ascii_letters + string.digits, k=KeyNumber))
  
    conver1 = ''.join(random.choices(string.ascii_letters + string.digits, k=KeyNumber))
        
    # Define static substitution for '0' and '1'
    substitution_map = {
        '0': conver0,
        '1': conver1
    }    
    
    
    
    # Convert the text into a corresponding encrypted string
    for char in Text:
        # Get the binary equivalent of each character (8 bits)
        binary_char = format(ord(char), '08b')
        
        # For each bit in the binary string, use the substitution map
        for bit in binary_char:
            decoded_text += substitution_map[bit]
            
    decoded_text = conver0 + DETER + conver1 + '\n' + decoded_text
    
    return decoded_text






def Old_Convert_To_LMMH_Data(OLD,Text):

    import re  # Optional: if you plan to validate pattern formats

    """
    Convert plain text to its encrypted string using the substitution map.
    This is essentially the reverse of the Convert_To_LMMH_Data function.
    """
    
    
    
    first_line = OLD.splitlines()[0]

    
    
    part1, part2 = first_line.split(DETER)



    # Define static substitution for '0' and '1'
    substitution_map = {
        '0': part1,
        '1': part2
    }
    
    
    decoded_text = ""
        
    
    # Convert the text into a corresponding encrypted string
    for char in Text:
        # Get the binary equivalent of each character (8 bits)
        binary_char = format(ord(char), '08b')
        
        # For each bit in the binary string, use the substitution map
        for bit in binary_char:
            decoded_text += substitution_map[bit]

    final_text = '\n' + decoded_text
     

    


    
    return final_text



def Convert_To_Text_Data(Text):

    import re  # Optional: if you plan to validate pattern formats

    """
    Convert an encrypted text (using substitution_map) back to binary, 
    then decode the binary string into the original text.
    """
    
    # Split the text into lines and remove the first one
    lines = Text.splitlines()
    first_line = lines[0]  # This is the first line we don't need to process
    rest_of_text = "\n".join(lines[1:])  # Join the rest of the lines
    
    # Split the first line into two parts using a unique delimiter
    try:
        part1, part2 = first_line.split(DETER)
    except ValueError:
        raise ValueError("The first line does not contain the expected delimiter. Please check the format.")

    # Define static substitution for '0' and '1'
    substitution_map = {
        '0': part1,
        '1': part2
    }
    
    # Reverse the substitution map for decoding
    reverse_substitution_map = {v: k for k, v in substitution_map.items()}
    
    binary_string = ""
    temp = ""
    
    # Process the rest of the text to extract the binary string
    for char in rest_of_text:
        temp += char
        
        # Check if temp matches one of the substitution values
        if temp in reverse_substitution_map:
            binary_string += reverse_substitution_map[temp]
            temp = ""  # Reset temp to collect the next part
            
    
    # Convert the binary string back to text (in chunks of 8 bits)
    encrypted_string = ''.join(chr(int(binary_string[i:i+8], 2)) for i in range(0, len(binary_string), 8))
            
    
    return encrypted_string

    
    
    
    
    
#print(Convert_To_Text_Data(""""""))
