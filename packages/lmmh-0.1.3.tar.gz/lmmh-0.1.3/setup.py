from setuptools import setup, find_packages
import pathlib

this_dir = pathlib.Path(__file__).parent
long_description = (this_dir / "README.md").read_text(encoding="utf-8")

setup(
    name="LMMH",
    version="0.1.3",
    author="Laith Madhat M. AL-Haware",
    author_email="landr41@gmail.com",
    description="👽 LMMH - Comprehensive Library of AI (Chat, Text AI & Vision AI Processing)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/LaithALhaware/LMMH",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[
        "flask",
        "flask-cors",
        "torch",
        "TTS",
        "faster-whisper",
        "pandas",
        "python-docx",
        "PyMuPDF",
        "pydub",
        "beautifulsoup4",
        "googlesearch-python",
        "aiohttp",
        "langdetect",
        "googletrans==4.0.0rc1",
        "Pillow",
        "tqdm",
        "torchvision",
        "transformers",
        "attrdict",
        "einops",
        "timm"
    ],
    entry_points={
        "console_scripts": [
            "LMMH-install = LMMH.installer:main",
        ],
    },
    license="MIT",
)

