This module assigns automatically delivery carrier on sale order create or
confirmation.

You may also have a look at the module delivery_auto_refresh in
delivery-carrier repository that assigns the carrier on creation and
automatically refresh the cost line while editing the sales quotation.
