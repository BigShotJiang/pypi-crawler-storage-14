#. Go to *Settings > Sales > Shipping*.

* Enable on creation: only the carrier will be set.
* Enable on confirmation: the carrier and delivery line will be set.
