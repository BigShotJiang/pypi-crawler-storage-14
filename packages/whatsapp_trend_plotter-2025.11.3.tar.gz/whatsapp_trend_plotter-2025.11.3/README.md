# whatsapp-trend-plotter

I was interested when people were washing their laundry in my apartment complex.
This matches a regex against an exported whatsapp chat to produce an overview of matches over time.