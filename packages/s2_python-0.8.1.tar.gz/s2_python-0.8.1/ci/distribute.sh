. .venv/bin/activate
tox -e build
