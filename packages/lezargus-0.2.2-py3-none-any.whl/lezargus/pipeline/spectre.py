"""Main SPECTRE pipeline class.

All of the data reduction which is done for SPECTRE is done here. Though this
class can be considered more of an orchestrator as a lot of the heavy lifting
is done by other parts of this module.
"""
