"""All of the pipeline aspects of the Lezargus package."""

from lezargus.pipeline.extraction import SpectreExtractor
