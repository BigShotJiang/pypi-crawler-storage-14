from google import genai

_client = None  # global gemini client

def set_gemini_key(key: str):
    global _client
    _client = genai.Client(api_key=key)

def get_gemini_client():
    if _client is None:
        raise ValueError("Gemini API key not set. Use set_gemini_key('YOUR_KEY')")
    return _client
