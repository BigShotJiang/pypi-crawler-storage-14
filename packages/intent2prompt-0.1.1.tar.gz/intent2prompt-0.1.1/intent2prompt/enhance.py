from .core import IntentToPrompt
from .config import get_gemini_client
from . import convert

def enhance(intent: str, model: str = "gemini-2.5-flash", **kwargs) -> str:
    """
    Enhances the output of convert() with Gemini AI.
    """
    base_prompt = convert(intent, **kwargs)  # offline prompt

    client = get_gemini_client()  # gemini client

    response = client.models.generate_content(
        model=model,
        contents=f"Improve, expand, and structure this prompt professionally:\n{base_prompt}"
    )

    return response.text.strip()
