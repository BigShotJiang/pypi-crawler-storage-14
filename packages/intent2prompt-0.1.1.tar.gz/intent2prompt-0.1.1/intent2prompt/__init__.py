from .core import IntentToPrompt, PromptConfig
from .config import set_gemini_key
from .core import IntentToPrompt

_default_engine = IntentToPrompt()

def convert(intent: str, **kwargs) -> str:
    return _default_engine.convert(intent, **kwargs)

from .enhance import enhance  # expose enhance()

__all__ = [
    "convert",
    "enhance",
    "set_gemini_key",
    "IntentToPrompt",
    "PromptConfig"
]
