from dataclasses import dataclass
from typing import Optional

@dataclass
class PromptConfig:
    tone: str = "neutral"
    output_format: Optional[str] = None
    language: str = "en"
    extra: Optional[str] = None

class IntentToPrompt:
    def __init__(self, config: PromptConfig = PromptConfig()):
        self.config = config

    def convert(self, intent: str, **overrides) -> str:
        cfg = self._merge(overrides)
        task = self._detect_task(intent)
        instructions = self._instructions(task, cfg)

        return f"""
You are an AI assistant.
{instructions}

User intention:
\"\"\"{intent}\"\"\"

Generate a complete response that satisfies this intention.
""".strip()

    def _merge(self, overrides):
        return PromptConfig(
            tone = overrides.get("tone", self.config.tone),
            output_format = overrides.get("output_format", self.config.output_format),
            language = overrides.get("language", self.config.language),
            extra = overrides.get("extra", self.config.extra),
        )

    def _detect_task(self, text: str) -> str:
        text = text.lower()

        if "email" in text or "mail" in text:
            return "email"
        elif "sql" in text or "query" in text:
            return "sql"
        elif "ppt" in text or "presentation" in text:
            return "ppt"
        elif "summary" in text:
            return "summary"
        elif "explain" in text or "what is" in text or "how" in text:
            return "explanation"
        else:
            return "generic"

    def _instructions(self, task, cfg):
        base = []

        if cfg.tone != "neutral":
            base.append(f"Use a {cfg.tone} tone.")

        if task == "email":
            base.append("Write a complete email with greeting, body, and closing.")
        elif task == "sql":
            base.append("Write an SQL query. No explanation.")
        elif task == "ppt":
            base.append("Create a PPT outline with slide-wise bullet points.")
        elif task == "summary":
            base.append("Summarize the content concisely.")
        elif task == "explanation":
            base.append("Explain the concept step-by-step.")
        else:
            base.append("Break the task into clear steps.")

        if cfg.output_format:
            base.append(f"Format output as {cfg.output_format}.")

        if cfg.extra:
            base.append(cfg.extra)

        return " ".join(base)
