# 📌 intent2prompt

**intent2prompt** converts natural, incomplete user instructions into structured, context-aware prompts that are ready for any LLM.  
It understands the user’s intention, identifies the task type, and transforms vague commands into well-defined prompts.  
Optionally, it can refine and improve the output using **Google Gemini**.

---

## 🚀 Why intent2prompt?

AI responses are only as good as the prompts they receive. Users often type:

```
email boss leave tomorrow
sql sales last month region west
ppt on ai future
```

These are not prompts — they are *intentions*.  
This library converts those intentions into prompts that models actually understand.

---

## ✨ Core Capabilities

✔️ Detects the nature of the task automatically  
(email, SQL query, PPT outline, explanation, summary, or generic instructions)

✔️ Generates structured prompts including:
- Tone  
- Output format  
- Expected response style  
- Additional constraints

✔️ Provides optional Gemini enhancement for:
- Better clarity
- Professional tone
- Domain-aware restructuring
- Expandable context

✔️ Works with one-line API calls:
`convert()` for offline use, `enhance()` for Gemini integration

---

## 📦 Installation

```bash
pip install intent2prompt
```

---

## 🛠️ Usage

### 1️⃣ Convert intent into a structured prompt (offline)

```python
from intent2prompt import convert

prompt = convert("email boss leave for 2 days", tone="formal")
print(prompt)
```

### 2️⃣ Enhance the prompt using Gemini

```python
from intent2prompt import enhance, set_gemini_key

set_gemini_key("YOUR_GEMINI_API_KEY")
print(enhance("email boss leave for 2 days", tone="formal"))
```

---

## 🧪 Example

**Input**

```
email boss leave for 2 days
```

**convert() output**

```
You are an AI assistant.
Use a formal tone. Write a complete email with greeting, body, and closing.

User intention:
"email boss leave for 2 days"

Generate a complete response that satisfies this intention.
```

**enhance() output (Gemini)**

```
Draft a professional email requesting a two-day leave from your manager.
Specify dates, provide a brief reason, and include a polite closing line.
```

---

## 🔍 Where to Use intent2prompt

- AI chatbots and assistants  
- Customer support systems  
- Email automation workflows  
- HR or employee request assistants  
- SQL prompt builders for BI tools  
- Documentation and training bots  
- Agentic AI pipelines where user input is raw

If your users type **intent**, this library gives you the **prompt**.

---

## 🧭 Future Scope

The library is designed with expansion in mind:

🚧 **v0.2.0 planned features**
- Support for OpenAI, Claude, and Perplexity models  
- Domain-specific prompt packs:
  - HR communication
  - Finance & accounting workflows
  - Power BI reporting prompts
  - Restaurant & delivery ecosystem prompts
- Multi-language prompt generation
- Automatic tone detection
- Command Line Interface: `i2p "email boss leave"`

🚀 **Long-term vision**
Make intent2prompt the foundational layer for every agentic AI system —  
where users simply express intent, and the system generates the best possible prompt.

---

## 👤 Author

**Rajdeep Rao**

---

