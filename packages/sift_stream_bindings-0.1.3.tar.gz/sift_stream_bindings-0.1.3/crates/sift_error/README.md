# sift_error

This is an internal sub-crate for all Sift crates and is primarily concerned with defining error types.

**Important Note**: This crate is re-exported in every other Sift crate so users shouldn't have to manually install
this crate to get the error types.
