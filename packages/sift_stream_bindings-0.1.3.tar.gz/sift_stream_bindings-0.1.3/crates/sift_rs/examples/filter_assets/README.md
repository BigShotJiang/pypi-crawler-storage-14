# filter_assets

```
SIFT_API_KEY="$MY_API_KEY" SIFT_URI="$SIFT_GRPC_URL" cargo r --example filter_assets
```
