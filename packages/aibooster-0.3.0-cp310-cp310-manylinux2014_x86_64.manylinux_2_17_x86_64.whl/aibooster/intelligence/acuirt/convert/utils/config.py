from typing import Dict
from ...dataclasses import AcuiRTBaseConversionReport


def flatten_converted_models(config: AcuiRTBaseConversionReport):
    ret: Dict[str, AcuiRTBaseConversionReport] = {}
    if config.rt_mode is not None:
        return {"": config}
    elif config.children is None:
        return None
    else:
        for key, value in config.children.items():
            models = flatten_converted_models(value)
            if models is None:
                return None
            for el, conf in models.items():
                if el == "":
                    ret[key] = conf
                elif el is not None:
                    ret[f"{key}.{el}"] = conf
    return ret
