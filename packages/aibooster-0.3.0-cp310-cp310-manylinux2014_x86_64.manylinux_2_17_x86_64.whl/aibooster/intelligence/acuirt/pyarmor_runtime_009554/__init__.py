# Pyarmor 9.1.9 (basic), 009554, 2025-11-28T02:50:11.932015
from .pyarmor_runtime import __pyarmor__
