"""Permission domain model."""

from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from apex.infrastructure.database.base import BaseModel


class BasePermission(BaseModel):
    """
    Abstract base permission model.

    Users should extend this class to create their own Permission model.
    Example:
        class Permission(BasePermission):
            __tablename__ = "permissions"
    """

    __abstract__ = True

    # Basic fields
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    slug: Mapped[str | None] = mapped_column(String(100), unique=True, nullable=True, index=True)
    resource: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    action: Mapped[str | None] = mapped_column(String(50), nullable=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Relationships
    roles: Mapped[list["BaseRole"]] = relationship(
        "BaseRole",
        secondary="role_permission_association",
        back_populates="permissions",
        lazy="selectin",
    )

