"""CLI utilities module."""

from apex.cli.main import app

__all__ = ["app"]

