"""Main CLI application using Typer."""

import typer
from typing_extensions import Annotated

app = typer.Typer(
    name="apex",
    help="Apex CLI utilities",
    add_completion=False,
)


@app.command()
def version():
    """Show package version."""
    from apex import __version__

    typer.echo(f"Apex v{__version__}")


@app.command()
def init_db(
    create_tables: Annotated[
        bool,
        typer.Option("--create-tables", help="Create database tables"),
    ] = False,
):
    """
    Initialize database.

    This is a base implementation. Users should extend this to work with
    their specific models and database setup.
    """
    typer.echo("Database initialization")
    typer.echo("Note: This is a base implementation.")
    typer.echo("Please configure your database models and run migrations using Alembic.")


@app.command()
def create_superuser(
    email: Annotated[str, typer.Option(help="Superuser email")],
    password: Annotated[str, typer.Option(prompt=True, hide_input=True, help="Password")],
    full_name: Annotated[str | None, typer.Option(help="Full name")] = None,
):
    """
    Create a superuser account.

    This is a base implementation. Users should extend this to work with
    their specific User model.
    """
    typer.echo(f"Creating superuser: {email}")
    typer.echo("Note: This is a base implementation.")
    typer.echo("Please implement this command with your User model.")


@app.command()
def check():
    """Check configuration and database connection."""
    from apex.core.config import get_settings

    settings = get_settings()
    typer.echo("Configuration check:")
    typer.echo(f"  Database URL: {settings.DATABASE_URL}")
    typer.echo(f"  Debug mode: {settings.DEBUG}")
    typer.echo(
        "  Secret key set: "
        + (
            "Yes"
            if settings.SECRET_KEY != "change-this-secret-key-in-production"
            else "No (WARNING!)"
        )
    )


def main():
    """CLI entry point."""
    app()


if __name__ == "__main__":
    main()

