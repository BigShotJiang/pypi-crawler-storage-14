"""
SDK for the Agentic Layer.
Provides some utilities and configurations for integrating a Google ADK-based agent into the Agentic Layer.
"""
