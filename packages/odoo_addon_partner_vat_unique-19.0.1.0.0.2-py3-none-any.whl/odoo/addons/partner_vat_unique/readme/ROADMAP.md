- Creation of the partner from XML-RPC.
- Partner creation by importing a CSV file, in those cases you miss the
  notice.
