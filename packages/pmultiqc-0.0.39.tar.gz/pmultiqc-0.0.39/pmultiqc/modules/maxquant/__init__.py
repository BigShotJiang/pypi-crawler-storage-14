from .maxquant import MaxQuantModule

__all__ = ["MaxQuantModule"]
