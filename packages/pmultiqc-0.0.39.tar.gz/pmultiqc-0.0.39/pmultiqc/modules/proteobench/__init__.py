from .proteobench import ProteoBenchModule

__all__ = ["ProteoBenchModule"]