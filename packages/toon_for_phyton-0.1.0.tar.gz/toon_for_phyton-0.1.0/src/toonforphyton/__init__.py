"""Public API for the Toon for Phyton library."""

from __future__ import annotations

from typing import Any, Optional

from .decoder import ValueDecoder
from .encoder import ValueEncoder
from .options import (
    KeyFoldingMode,
    LengthMismatchBehavior,
    PathExpansionMode,
    ToonDecodeOptions,
    ToonDecodeWarning,
    ToonDelimiter,
    ToonOptions,
)

__all__ = [
    "encode",
    "decode",
    "ToonOptions",
    "ToonDecodeOptions",
    "ToonDelimiter",
    "KeyFoldingMode",
    "PathExpansionMode",
    "LengthMismatchBehavior",
    "ToonDecodeWarning",
]

__version__ = "0.1.0"


def encode(value: Any, options: Optional[ToonOptions] = None) -> str:
    opts = options or ToonOptions()
    if opts.indent < 0:
        raise ValueError("Indent must be non-negative.")
    encoder = ValueEncoder(opts)
    return encoder.encode(value)


def decode(text: str, options: Optional[ToonDecodeOptions] = None) -> Any:
    if text is None:
        raise ValueError("Input text cannot be None.")
    opts = options or ToonDecodeOptions()
    if opts.indent < 0:
        raise ValueError("Indent must be non-negative.")
    decoder = ValueDecoder(opts)
    return decoder.decode(text)
