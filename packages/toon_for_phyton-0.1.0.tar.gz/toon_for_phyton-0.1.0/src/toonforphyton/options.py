"""Configuration objects and enums for Toon for Phyton."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterable, List, Optional


class ToonDelimiter(str, Enum):
    COMMA = ","
    TAB = "\t"
    PIPE = "|"

    @property
    def char(self) -> str:
        return str(self.value)


class KeyFoldingMode(str, Enum):
    OFF = "off"
    SAFE = "safe"


class PathExpansionMode(str, Enum):
    OFF = "off"
    SAFE = "safe"


class LengthMismatchBehavior(str, Enum):
    SILENT = "silent"
    WARN = "warn"
    ERROR = "error"


@dataclass
class ToonDecodeWarning:
    kind: str
    key: Optional[str]
    declared_length: int
    actual_length: int
    line_number: int


@dataclass
class ToonOptions:
    indent: int = 1
    delimiter: ToonDelimiter = ToonDelimiter.COMMA
    use_length_marker: bool = False
    key_folding: KeyFoldingMode = KeyFoldingMode.OFF
    flatten_depth: int = 2**31 - 1
    new_line: str = "\n"
    default_converter: Optional[Callable[[Any], Any]] = None


@dataclass
class ToonDecodeOptions:
    indent: int = 1
    strict: bool = True
    expand_paths: PathExpansionMode = PathExpansionMode.OFF
    length_mismatch_behavior: LengthMismatchBehavior = LengthMismatchBehavior.SILENT
    warning_sink: Optional[List[ToonDecodeWarning]] = field(default=None)
