"""Encoding logic that converts Python objects into TOON text."""

from __future__ import annotations

import dataclasses
import math
from collections.abc import Iterable, Mapping, Sequence
from decimal import Decimal
from typing import Any, Dict, List, Optional

from . import constants as c
from .options import KeyFoldingMode, ToonDelimiter, ToonOptions
from .string_utils import escape_string, is_valid_identifier

_STRUCTURAL_TOKEN_PATTERN = r"^\[(\d+|#\d+)\]$|^\{[\w,]+\}$"


class LineWriter:
    def __init__(self, indent_size: int, new_line: str) -> None:
        self._sb: List[str] = []
        self._indent_size = max(0, indent_size)
        self._new_line = "\n" if not new_line else new_line
        self._depth = 0
        self._needs_newline = False

    def increase_depth(self) -> None:
        self._depth += 1

    def decrease_depth(self) -> None:
        if self._depth > 0:
            self._depth -= 1

    def write_line(self, content: str) -> None:
        if self._needs_newline:
            self._sb.append(self._new_line)
        if self._depth > 0:
            self._sb.append(" " * (self._depth * self._indent_size))
        self._sb.append(content)
        self._needs_newline = True

    def write(self, content: str) -> None:
        self._sb.append(content)

    def write_new_line(self) -> None:
        self._sb.append(self._new_line)
        self._needs_newline = False

    @property
    def depth(self) -> int:
        return self._depth

    def __str__(self) -> str:
        return "".join(self._sb).rstrip("\r\n")


class PrimitiveEncoder:
    @staticmethod
    def encode_primitive(value: Any, delimiter: ToonDelimiter) -> str:
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, str):
            return PrimitiveEncoder._encode_string(value, delimiter)
        return PrimitiveEncoder._encode_number(value)

    @staticmethod
    def _encode_string(value: str, delimiter: ToonDelimiter) -> str:
        if PrimitiveEncoder._should_quote_string(value, delimiter):
            return f'"{escape_string(value)}"'
        return value

    @staticmethod
    def _should_quote_string(value: str, delimiter: ToonDelimiter) -> bool:
        import re

        if value == "":
            return True
        if value[0].isspace() or value[-1].isspace():
            return True

        delimiter_char = delimiter.char
        if (
            delimiter_char in value
            or c.COLON in value
            or '"' in value
            or "\\" in value
            or any(ord(ch) < 0x20 for ch in value)
        ):
            return True

        if value in {"true", "false", "null"}:
            return True

        number_pattern = r"^-?\d+(\.\d+)?([eE][+-]?\d+)?$"
        if re.match(number_pattern, value):
            return True

        if value.startswith(c.LIST_ITEM_PREFIX):
            return True

        if re.match(_STRUCTURAL_TOKEN_PATTERN, value):
            return True

        return False

    @staticmethod
    def _encode_number(value: Any) -> str:
        # Keep bool check above; here handle numbers/others.
        if isinstance(value, Decimal):
            return format(value, "f")
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            if math.isnan(value) or math.isinf(value):
                return "null"
            return format(value, ".17g")
        return PrimitiveEncoder._encode_string(str(value), ToonDelimiter.COMMA)

    @staticmethod
    def encode_key(key: str) -> str:
        if is_valid_identifier(key):
            return key
        return f'"{escape_string(key)}"'

    @staticmethod
    def format_array_header(
        key: Optional[str],
        length: int,
        delimiter: ToonDelimiter,
        use_length_marker: bool,
        fields: Optional[List[str]] = None,
    ) -> str:
        parts = []
        if key is not None:
            parts.append(PrimitiveEncoder.encode_key(key))

        marker = f"{c.LENGTH_MARKER}{length}" if use_length_marker else str(length)
        parts.append(f"{c.OPEN_BRACKET}{marker}")
        if delimiter != ToonDelimiter.COMMA:
            parts.append(delimiter.char)
        parts.append(c.CLOSE_BRACKET)

        if fields:
            parts.append(c.OPEN_BRACE)
            parts.append(delimiter.char.join(fields))
            parts.append(c.CLOSE_BRACE)

        parts.append(c.COLON)
        return "".join(parts)

    @staticmethod
    def join_primitives(values: Iterable[Any], delimiter: ToonDelimiter) -> str:
        encoded = (PrimitiveEncoder.encode_primitive(v, delimiter) for v in values)
        return delimiter.char.join(encoded)


class ValueEncoder:
    def __init__(self, options: ToonOptions) -> None:
        self._options = options
        self._writer = LineWriter(options.indent, options.new_line)

    def encode(self, value: Any) -> str:
        normalized = self._normalize_value(value)
        if isinstance(normalized, Mapping):
            self._encode_object(normalized, 0)
        elif isinstance(normalized, list):
            self._encode_array(None, normalized, 0)
        else:
            return PrimitiveEncoder.encode_primitive(normalized, self._options.delimiter)
        return str(self._writer)

    def _encode_object(
        self,
        obj: Mapping[str, Any],
        depth: int,
        scope_literal_keys: Optional[set[str]] = None,
    ) -> None:
        if scope_literal_keys is None:
            scope_literal_keys = self._collect_literal_keys(obj)

        for key, value in obj.items():
            self._encode_key_value_pair(key, value, depth, scope_literal_keys)

    def _encode_key_value_pair(
        self,
        key: str,
        value: Any,
        depth: int,
        scope_literal_keys: Optional[set[str]] = None,
        line_prefix: Optional[str] = None,
    ) -> None:
        encoded_key = PrimitiveEncoder.encode_key(key)
        apply_prefix = (
            (lambda content: f"{line_prefix}{content}")
            if line_prefix
            else lambda content: content
        )

        if (
            self._options.key_folding == KeyFoldingMode.SAFE
            and isinstance(value, Mapping)
            and self._can_fold_key(value, scope_literal_keys)
        ):
            folded = self._try_fold_key_chain(key, value, depth, scope_literal_keys)
            if folded:
                return

        if isinstance(value, list):
            self._encode_array(key, value, depth, line_prefix)
        elif isinstance(value, Mapping):
            if value:
                self._writer.write_line(apply_prefix(f"{encoded_key}{c.COLON}"))
                self._writer.increase_depth()
                self._encode_object(value, depth + 1)
                self._writer.decrease_depth()
            else:
                self._writer.write_line(apply_prefix(f"{encoded_key}{c.COLON}"))
        else:
            encoded_value = PrimitiveEncoder.encode_primitive(
                value, self._options.delimiter
            )
            self._writer.write_line(apply_prefix(f"{encoded_key}{c.COLON} {encoded_value}"))

    def _try_fold_key_chain(
        self,
        key: str,
        value: Mapping[str, Any],
        depth: int,
        scope_literal_keys: Optional[set[str]],
    ) -> bool:
        chain: List[str] = [key]
        current: Any = value
        max_segments = self._options.flatten_depth if self._options.flatten_depth > 0 else 0
        if max_segments <= 1:
            return False

        while isinstance(current, Mapping) and len(chain) < max_segments:
            if len(current) != 1:
                break
            next_key = next(iter(current))
            candidate_path = ".".join(chain + [next_key])
            if scope_literal_keys and candidate_path in scope_literal_keys:
                return False
            chain.append(next_key)
            current = current[next_key]

        if len(chain) < 2:
            return False

        dotted_key = ".".join(chain)
        encoded_key = PrimitiveEncoder.encode_key(dotted_key)

        if isinstance(current, list):
            self._encode_array(dotted_key, current, depth)
        elif isinstance(current, Mapping):
            if current:
                self._writer.write_line(f"{encoded_key}{c.COLON}")
                self._writer.increase_depth()
                self._encode_object(current, depth + 1)
                self._writer.decrease_depth()
            else:
                self._writer.write_line(f"{encoded_key}{c.COLON}")
        else:
            encoded_value = PrimitiveEncoder.encode_primitive(
                current, self._options.delimiter
            )
            self._writer.write_line(f"{encoded_key}{c.COLON} {encoded_value}")

        return True

    def _can_fold_key(
        self, obj: Mapping[str, Any], root_literal_keys: Optional[set[str]]
    ) -> bool:
        if len(obj) != 1:
            return False
        next_key = next(iter(obj))
        return not (root_literal_keys and next_key in root_literal_keys)

    def _encode_array(
        self,
        key: Optional[str],
        array: List[Any],
        depth: int,
        line_prefix: Optional[str] = None,
    ) -> None:
        items = list(array)
        length = len(items)
        apply_prefix = (
            (lambda content: f"{line_prefix}{content}")
            if line_prefix
            else lambda content: content
        )

        if length == 0:
            header = PrimitiveEncoder.format_array_header(
                key, 0, self._options.delimiter, self._options.use_length_marker
            )
            self._writer.write_line(apply_prefix(header))
            return

        if self._is_tabular_array(items):
            fields = [k for k in items[0].keys()]  # preserve order
            self._encode_tabular_array(key, items, fields, depth, line_prefix)
        elif all(self._is_primitive(item) for item in items):
            self._encode_inline_array(key, items, depth, line_prefix)
        else:
            self._encode_list_array(key, items, depth, line_prefix)

    def _encode_tabular_array(
        self,
        key: Optional[str],
        items: List[Mapping[str, Any]],
        fields: List[str],
        depth: int,
        line_prefix: Optional[str],
    ) -> None:
        header = PrimitiveEncoder.format_array_header(
            key,
            len(items),
            self._options.delimiter,
            self._options.use_length_marker,
            fields,
        )
        if line_prefix:
            header = f"{line_prefix}{header}"
        self._writer.write_line(header)

        self._writer.increase_depth()
        for item in items:
            row_values = [item.get(field) for field in fields]
            encoded_row = PrimitiveEncoder.join_primitives(
                row_values, self._options.delimiter
            )
            self._writer.write_line(encoded_row)
        self._writer.decrease_depth()

    def _encode_inline_array(
        self,
        key: Optional[str],
        items: List[Any],
        depth: int,
        line_prefix: Optional[str],
    ) -> None:
        header = PrimitiveEncoder.format_array_header(
            key, len(items), self._options.delimiter, self._options.use_length_marker
        )
        if line_prefix:
            header = f"{line_prefix}{header}"
        encoded_values = PrimitiveEncoder.join_primitives(
            (self._get_primitive_value(item) for item in items), self._options.delimiter
        )
        self._writer.write_line(f"{header} {encoded_values}")

    def _encode_list_array(
        self,
        key: Optional[str],
        items: List[Any],
        depth: int,
        line_prefix: Optional[str],
    ) -> None:
        header = PrimitiveEncoder.format_array_header(
            key, len(items), self._options.delimiter, self._options.use_length_marker
        )
        if line_prefix:
            header = f"{line_prefix}{header}"
        self._writer.write_line(header)

        self._writer.increase_depth()
        for item in items:
            if isinstance(item, Mapping):
                props = list(item.items())
                if props:
                    nested_literal_keys = self._collect_literal_keys(item)
                    first_key, first_value = props[0]
                    self._encode_key_value_pair(
                        first_key,
                        first_value,
                        depth + 2,
                        nested_literal_keys,
                        line_prefix=c.LIST_ITEM_PREFIX,
                    )
                    for prop_key, prop_value in props[1:]:
                        self._encode_key_value_pair(
                            prop_key, prop_value, depth + 2, nested_literal_keys
                        )
                else:
                    self._writer.write_line(c.LIST_ITEM_PREFIX)
            elif isinstance(item, list):
                self._encode_array(None, item, depth + 1, c.LIST_ITEM_PREFIX)
            else:
                encoded_value = PrimitiveEncoder.encode_primitive(
                    item, self._options.delimiter
                )
                self._writer.write_line(f"{c.LIST_ITEM_PREFIX}{encoded_value}")
        self._writer.decrease_depth()

    def _is_tabular_array(self, items: List[Any]) -> bool:
        if not items or not isinstance(items[0], Mapping):
            return False

        first = items[0]
        primitive_props = [
            (k, v) for k, v in first.items() if self._is_primitive(v)
        ]
        if not primitive_props:
            return False
        if any(not self._is_primitive(v) for _, v in first.items()):
            return False

        ordered_fields = [k for k, _ in primitive_props]
        normalized = sorted(ordered_fields)

        for item in items[1:]:
            if not isinstance(item, Mapping):
                return False
            if any(not self._is_primitive(v) for v in item.values()):
                return False
            fields = sorted(item.keys())
            if fields != normalized:
                return False

        return True

    def _collect_literal_keys(self, obj: Mapping[str, Any]) -> Optional[set[str]]:
        keys = {key for key in obj.keys() if c.DOT in key}
        return keys or None

    def _is_primitive(self, value: Any) -> bool:
        return value is None or isinstance(value, (str, bool, int, float, Decimal))

    def _get_primitive_value(self, value: Any) -> Any:
        return value

    def _normalize_value(self, value: Any) -> Any:
        return _normalize_value(value, self._options.default_converter)


def _normalize_value(
    value: Any, default_converter: Optional[callable] = None, _seen: Optional[set[int]] = None
) -> Any:
    from datetime import date, datetime, time

    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (str, int, float, Decimal)):
        return value
    if isinstance(value, (bytes, bytearray)):
        try:
            return value.decode("utf-8")
        except Exception:
            return value.hex()
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()

    if _seen is None:
        _seen = set()
    obj_id = id(value)
    if obj_id in _seen:
        raise ValueError("Cyclic reference detected while normalizing value.")
    _seen.add(obj_id)

    if default_converter:
        converted = default_converter(value)
        if converted is not value:
            result = _normalize_value(converted, default_converter, _seen)
            _seen.discard(obj_id)
            return result

    if dataclasses.is_dataclass(value):
        result = _normalize_value(dataclasses.asdict(value), default_converter, _seen)
        _seen.discard(obj_id)
        return result

    if isinstance(value, Mapping):
        result = {
            str(k): _normalize_value(v, default_converter, _seen) for k, v in value.items()
        }
        _seen.discard(obj_id)
        return result

    if isinstance(value, (list, tuple, set)):
        result = [_normalize_value(v, default_converter, _seen) for v in value]
        _seen.discard(obj_id)
        return result

    if hasattr(value, "_asdict"):
        try:
            result = _normalize_value(value._asdict(), default_converter, _seen)
            _seen.discard(obj_id)
            return result
        except Exception:
            pass

    if hasattr(value, "__dict__"):
        data = {k: v for k, v in vars(value).items() if not k.startswith("_")}
        result = {
            str(k): _normalize_value(v, default_converter, _seen) for k, v in data.items()
        }
        _seen.discard(obj_id)
        return result

    raise TypeError(f"Unsupported value type for TOON encoding: {type(value)!r}")
