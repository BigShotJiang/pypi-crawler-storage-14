"""Decode TOON text back into Python data structures."""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, List, Optional, Tuple

from . import constants as c
from .options import (
    LengthMismatchBehavior,
    PathExpansionMode,
    ToonDecodeOptions,
    ToonDecodeWarning,
    ToonDelimiter,
)
from .string_utils import unescape_string


@dataclass
class ParsedLine:
    raw: str
    depth: int
    indent: int
    content: str
    line_number: int


class Scanner:
    def __init__(self, indent_size: int, strict: bool) -> None:
        self._indent_size = max(1, indent_size)
        self._strict = strict

    def scan(self, input_text: str) -> List[ParsedLine]:
        lines: List[ParsedLine] = []
        raw_lines = re.split(r"\r\n|\r|\n", input_text)

        line_number = 0
        for raw in raw_lines:
            line_number += 1
            if raw.strip() == "":
                continue
            indent, content_index = self._measure_indentation(raw)
            depth = indent // self._indent_size

            if self._strict and indent % self._indent_size != 0:
                raise ValueError(
                    f"Line {line_number}: Invalid indentation. Expected multiple of {self._indent_size}, got {indent}."
                )

            content = raw[content_index:]
            lines.append(
                ParsedLine(
                    raw=raw,
                    depth=depth,
                    indent=indent,
                    content=content,
                    line_number=line_number,
                )
            )
        return lines

    def _measure_indentation(self, line: str) -> Tuple[int, int]:
        indent = 0
        idx = 0
        while idx < len(line):
            ch = line[idx]
            if ch == " ":
                indent += 1
            elif ch == "\t":
                indent += self._indent_size
            else:
                break
            idx += 1
        return indent, idx


class LineCursor:
    def __init__(self, lines: List[ParsedLine]) -> None:
        self._lines = lines
        self._pos = 0

    def peek(self) -> Optional[ParsedLine]:
        return self._lines[self._pos] if self._pos < len(self._lines) else None

    def peek_at(self, offset: int) -> Optional[ParsedLine]:
        pos = self._pos + offset
        if 0 <= pos < len(self._lines):
            return self._lines[pos]
        return None

    def advance(self) -> Optional[ParsedLine]:
        if self._pos < len(self._lines):
            line = self._lines[self._pos]
            self._pos += 1
            return line
        return None

    def has_more(self) -> bool:
        return self._pos < len(self._lines)

    def get_lines_at_depth(self, target_depth: int, count: int) -> List[ParsedLine]:
        result: List[ParsedLine] = []
        scanned = 0
        while scanned < count and self._pos < len(self._lines):
            line = self._lines[self._pos]
            if line.depth == target_depth:
                result.append(line)
                scanned += 1
            self._pos += 1
        return result


@dataclass
class ArrayHeader:
    key: Optional[str]
    length: int
    delimiter: ToonDelimiter
    fields: Optional[List[str]]
    has_length_marker: bool
    line_number: int = -1


class PrimitiveParser:
    @staticmethod
    def parse_primitive_token(token: str) -> Any:
        if token is None:
            return None
        token = token.strip()
        if token == "":
            return None

        if token.startswith('"'):
            if len(token) < 2 or not token.endswith('"'):
                raise ValueError(f"Unterminated quoted string: {token}")
            inner = token[1:-1]
            return unescape_string(inner)

        if token == "true":
            return True
        if token == "false":
            return False
        if token == "null":
            return None

        try:
            return int(token)
        except ValueError:
            pass

        try:
            return Decimal(token)
        except Exception:
            pass

        try:
            return float(token)
        except ValueError:
            pass

        return token

    @staticmethod
    def parse_delimited_values(content: str, delimiter: ToonDelimiter) -> List[Any]:
        values: List[Any] = []
        sb: List[str] = []
        in_quotes = False
        escaped = False
        delimiter_char = delimiter.value

        for ch in content:
            if escaped:
                sb.append(ch)
                escaped = False
                continue

            if ch == "\\":
                sb.append(ch)
                escaped = True
                continue

            if ch == '"':
                in_quotes = not in_quotes
                sb.append(ch)
                continue

            if ch == delimiter_char and not in_quotes:
                values.append(PrimitiveParser.parse_primitive_token("".join(sb)))
                sb = []
                continue

            sb.append(ch)

        if sb or content.endswith(delimiter_char):
            values.append(PrimitiveParser.parse_primitive_token("".join(sb)))

        return values

    @staticmethod
    def parse_key_token(token: str) -> str:
        token = token.strip()
        if token.startswith('"'):
            if len(token) < 2 or not token.endswith('"'):
                raise ValueError(f"Unterminated quoted key: {token}")
            inner = token[1:-1]
            return unescape_string(inner)
        return token


class PathExpander:
    @staticmethod
    def expand_paths(node: Any, mode: PathExpansionMode) -> Any:
        if node is None or mode == PathExpansionMode.OFF:
            return node

        if isinstance(node, dict):
            return PathExpander._expand_object(node, mode)
        if isinstance(node, list):
            return [PathExpander.expand_paths(item, mode) for item in node]
        return node

    @staticmethod
    def _expand_object(obj: dict, mode: PathExpansionMode) -> dict:
        expanded_values = {k: PathExpander.expand_paths(v, mode) for k, v in obj.items()}
        dotted_keys = [k for k in expanded_values.keys() if "." in k]

        if not dotted_keys:
            return {k: PathExpander._clone(v) for k, v in expanded_values.items()}

        if mode == PathExpansionMode.SAFE and PathExpander._has_conflicts(
            expanded_values.keys(), dotted_keys
        ):
            return {k: PathExpander._clone(v) for k, v in expanded_values.items()}

        result: dict = {}
        for key, value in expanded_values.items():
            if "." not in key:
                result[key] = PathExpander._clone(value)

        for key in dotted_keys:
            PathExpander._set_nested_value(result, key, expanded_values[key])

        return result

    @staticmethod
    def _has_conflicts(keys: Any, dotted_keys: List[str]) -> bool:
        key_set = set(keys)
        for dotted in dotted_keys:
            parts = dotted.split(".")
            for i in range(1, len(parts)):
                prefix = ".".join(parts[:i])
                if prefix in key_set:
                    return True
            for other in key_set:
                if other != dotted and other.startswith(f"{dotted}."):
                    return True
        return False

    @staticmethod
    def _set_nested_value(root: dict, path: str, value: Any) -> None:
        parts = path.split(".")
        current = root
        for part in parts[:-1]:
            if part not in current or not isinstance(current.get(part), dict):
                current[part] = {}
            current = current[part]
        current[parts[-1]] = PathExpander._clone(value)

    @staticmethod
    def _clone(value: Any) -> Any:
        if isinstance(value, dict):
            return {k: PathExpander._clone(v) for k, v in value.items()}
        if isinstance(value, list):
            return [PathExpander._clone(v) for v in value]
        return value


class ValueDecoder:
    def __init__(self, options: ToonDecodeOptions) -> None:
        self._options = options
        self._scanner = Scanner(options.indent, options.strict)

    def decode(self, input_text: str) -> Any:
        lines = self._scanner.scan(input_text)
        if not lines:
            return {}

        cursor = LineCursor(lines)
        first = cursor.peek()
        if first is None:
            return {}

        if self._is_array_header(first.content):
            header_syntax = first.content
            inline_content = None
            colon_index = self._find_colon_index(first.content)
            if colon_index >= 0:
                inline_content = first.content[colon_index + 1 :].strip()
                header_syntax = first.content[:colon_index].strip()

            header = self._parse_array_header(header_syntax)
            if header:
                header.line_number = first.line_number
                cursor.advance()
                if inline_content:
                    result = self._decode_inline_array(header, inline_content)
                else:
                    result = self._decode_array(header, cursor, 0)
                return PathExpander.expand_paths(result, self._options.expand_paths)

        if len(lines) == 1 and not self._is_key_value_line(first.content):
            return PrimitiveParser.parse_primitive_token(first.content.strip())

        result = self._decode_object(cursor, 0)
        return PathExpander.expand_paths(result, self._options.expand_paths)

    def _decode_object(self, cursor: LineCursor, depth: int) -> dict:
        obj: dict = {}

        while cursor.has_more():
            line = cursor.peek()
            if line is None or line.depth < depth:
                break
            if line.depth > depth:
                cursor.advance()
                continue
            key, value = self._parse_key_value_pair(line, cursor, depth)
            obj[key] = value

        return obj

    def _parse_key_value_pair(
        self, line: ParsedLine, cursor: LineCursor, depth: int
    ) -> Tuple[str, Any]:
        cursor.advance()
        return self._parse_key_value_content(line.content, line.line_number, depth, cursor)

    def _parse_key_value_content(
        self, content: str, line_number: int, depth: int, cursor: LineCursor
    ) -> Tuple[str, Any]:
        colon_index = self._find_colon_index(content)
        if colon_index == -1:
            raise ValueError(f"Line {line_number}: Missing colon in key-value pair")

        key_part = content[:colon_index].strip()
        value_part = content[colon_index + 1 :].strip()

        key, array_header = self._parse_key(key_part)

        if array_header:
            array_header.key = key
            array_header.line_number = line_number
            if value_part:
                return key, self._decode_inline_array(array_header, value_part)
            return key, self._decode_array(array_header, cursor, depth)

        if value_part:
            return key, PrimitiveParser.parse_primitive_token(value_part)

        next_line = cursor.peek()
        if next_line and next_line.depth > depth:
            return key, self._decode_object(cursor, depth + 1)

        return key, {}

    def _decode_array(self, header: ArrayHeader, cursor: LineCursor, depth: int) -> list:
        array: List[Any] = []

        if header.length == 0:
            return array

        if header.fields:
            return self._decode_tabular_array(header, cursor, depth)

        return self._decode_list_array(header, cursor, depth)

    def _decode_tabular_array(
        self, header: ArrayHeader, cursor: LineCursor, depth: int
    ) -> list:
        array: List[Any] = []
        rows = cursor.get_lines_at_depth(depth + 1, header.length)

        if len(rows) != header.length:
            if self._options.strict:
                raise ValueError(
                    f"Array length mismatch: expected {header.length}, got {len(rows)}"
                )
            self._handle_length_mismatch(header, len(rows))

        for row in rows:
            values = PrimitiveParser.parse_delimited_values(row.content, header.delimiter)
            if self._options.strict and len(values) != len(header.fields or []):
                raise ValueError(
                    f"Line {row.line_number}: Field count mismatch. Expected {len(header.fields or [])}, got {len(values)}"
                )
            obj: dict = {}
            for idx, field in enumerate(header.fields or []):
                if idx < len(values):
                    obj[field] = values[idx]
            array.append(obj)

        return array

    def _decode_inline_array(self, header: ArrayHeader, content: str) -> list:
        array: List[Any] = []
        values = PrimitiveParser.parse_delimited_values(content, header.delimiter)

        if len(values) != header.length:
            if self._options.strict:
                raise ValueError(
                    f"Array length mismatch: expected {header.length}, got {len(values)}"
                )
            self._handle_length_mismatch(header, len(values))

        array.extend(values)
        return array

    def _decode_list_array(self, header: ArrayHeader, cursor: LineCursor, depth: int) -> list:
        array: List[Any] = []
        items_found = 0

        while cursor.has_more() and items_found < header.length:
            line = cursor.peek()
            if line is None or line.depth < depth + 1:
                break
            if line.depth > depth + 1:
                cursor.advance()
                continue

            if line.content.startswith(c.LIST_ITEM_PREFIX):
                items_found += 1
                cursor.advance()
                content = line.content[len(c.LIST_ITEM_PREFIX) :]

                if self._is_array_header(content):
                    header_syntax = content
                    inline_content = None
                    colon_index = self._find_colon_index(content)
                    if colon_index >= 0:
                        inline_content = content[colon_index + 1 :].strip()
                        header_syntax = content[:colon_index].strip()
                    nested_header = self._parse_array_header(header_syntax)
                    if nested_header:
                        nested_header.line_number = line.line_number
                        nested_array = (
                            self._decode_inline_array(nested_header, inline_content)
                            if inline_content
                            else self._decode_array(nested_header, cursor, depth + 1)
                        )
                        array.append(nested_array)
                elif content.strip() == "":
                    obj: dict = {}
                    while cursor.has_more():
                        nxt = cursor.peek()
                        if nxt is None or nxt.depth <= depth + 1:
                            break
                        prop_key, prop_value = self._parse_key_value_pair(
                            nxt, cursor, depth + 2
                        )
                        obj[prop_key] = prop_value

                    while cursor.has_more():
                        sibling = cursor.peek()
                        if sibling is None or sibling.depth != depth + 1:
                            break
                        if sibling.content.startswith(c.LIST_ITEM_PREFIX):
                            break
                        prop_key, prop_value = self._parse_key_value_pair(
                            sibling, cursor, depth + 1
                        )
                        obj[prop_key] = prop_value

                    array.append(obj)
                elif self._is_key_value_line(content):
                    item_lines: List[ParsedLine] = [
                        ParsedLine(
                            raw=line.raw,
                            content=content,
                            depth=depth + 1,
                            indent=depth + 1,
                            line_number=line.line_number,
                        )
                    ]
                    while cursor.has_more():
                        nxt = cursor.peek()
                        if nxt is None:
                            break
                        if nxt.depth < depth + 1:
                            break
                        if nxt.depth == depth + 1 and nxt.content.startswith(
                            c.LIST_ITEM_PREFIX
                        ):
                            break
                        cursor.advance()
                        item_lines.append(nxt)

                    item_cursor = LineCursor(item_lines)
                    obj = self._decode_object(item_cursor, depth + 1)
                    array.append(obj)
                else:
                    array.append(PrimitiveParser.parse_primitive_token(content))

        if items_found != header.length:
            if self._options.strict:
                raise ValueError(
                    f"Array length mismatch: expected {header.length}, got {items_found}"
                )
            self._handle_length_mismatch(header, items_found)

        return array

    def _parse_key(self, key_part: str) -> Tuple[str, Optional[ArrayHeader]]:
        array_header = None
        bracket_index = key_part.find(c.OPEN_BRACKET)
        if bracket_index >= 0:
            key = key_part[:bracket_index]
            array_syntax = key_part[bracket_index:]
            array_header = self._parse_array_header(array_syntax)
            return PrimitiveParser.parse_key_token(key), array_header
        return PrimitiveParser.parse_key_token(key_part), array_header

    def _is_array_header(self, content: str) -> bool:
        return content.strip().startswith(c.OPEN_BRACKET)

    def _parse_array_header(self, content: str) -> Optional[ArrayHeader]:
        content = content.strip()
        if not content.startswith(c.OPEN_BRACKET):
            return None
        close_index = content.find(c.CLOSE_BRACKET)
        if close_index == -1:
            return None

        bracket_content = content[1:close_index]
        delimiter = ToonDelimiter.COMMA
        has_length_marker = False

        if bracket_content.startswith(c.LENGTH_MARKER):
            has_length_marker = True
            bracket_content = bracket_content[1:]

        if bracket_content.endswith("\t"):
            delimiter = ToonDelimiter.TAB
            bracket_content = bracket_content[:-1]
        elif bracket_content.endswith("|"):
            delimiter = ToonDelimiter.PIPE
            bracket_content = bracket_content[:-1]

        try:
            length = int(bracket_content)
        except ValueError:
            return None

        fields = None
        remaining = content[close_index + 1 :]
        if remaining.startswith(c.OPEN_BRACE):
            close_brace = remaining.find(c.CLOSE_BRACE)
            if close_brace > 0:
                fields_content = remaining[1:close_brace]
                fields = [f.strip() for f in fields_content.split(delimiter.value)]

        return ArrayHeader(
            key=None,
            length=length,
            delimiter=delimiter,
            fields=fields,
            has_length_marker=has_length_marker,
        )

    def _find_colon_index(self, content: str) -> int:
        in_quotes = False
        escaped = False
        for idx, ch in enumerate(content):
            if escaped:
                escaped = False
                continue
            if ch == "\\":
                escaped = True
                continue
            if ch == '"':
                in_quotes = not in_quotes
                continue
            if ch == c.COLON and not in_quotes:
                return idx
        return -1

    def _is_key_value_line(self, content: str) -> bool:
        return self._find_colon_index(content) >= 0

    def _handle_length_mismatch(self, header: ArrayHeader, actual_length: int) -> None:
        if header.line_number < 0:
            header.line_number = 0

        behavior = self._options.length_mismatch_behavior
        if behavior == LengthMismatchBehavior.ERROR:
            name = header.key or "<root array>"
            raise ValueError(
                f"Array length mismatch for '{name}' on line {header.line_number}: expected {header.length}, got {actual_length}."
            )
        if behavior == LengthMismatchBehavior.WARN and self._options.warning_sink is not None:
            self._options.warning_sink.append(
                ToonDecodeWarning(
                    kind="length_mismatch",
                    key=header.key,
                    declared_length=header.length,
                    actual_length=actual_length,
                    line_number=header.line_number,
                )
            )
