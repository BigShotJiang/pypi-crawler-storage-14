"""String helpers used across the encoder and decoder."""

from __future__ import annotations

import re


def is_identifier_start(ch: str) -> bool:
    return ch.isalpha() or ch == "_"


def is_identifier_part(ch: str) -> bool:
    return ch.isalnum() or ch in {"_", "."}


def is_valid_identifier(value: str) -> bool:
    if not value:
        return False

    if not is_identifier_start(value[0]):
        return False

    return all(is_identifier_part(ch) for ch in value[1:])


def escape_string(value: str) -> str:
    escaped = []
    for ch in value:
        if ch == '"':
            escaped.append(r"\"")
        elif ch == "\\":
            escaped.append(r"\\")
        elif ch == "\n":
            escaped.append(r"\n")
        elif ch == "\r":
            escaped.append(r"\r")
        elif ch == "\t":
            escaped.append(r"\t")
        elif ord(ch) < 0x20:
            escaped.append(f"\\u{ord(ch):04x}")
        else:
            escaped.append(ch)
    return "".join(escaped)


def unescape_string(value: str) -> str:
    result = []
    i = 0
    while i < len(value):
        ch = value[i]
        if ch != "\\":
            result.append(ch)
            i += 1
            continue

        i += 1
        if i >= len(value):
            result.append("\\")
            break

        esc = value[i]
        if esc == '"':
            result.append('"')
        elif esc == "\\":
            result.append("\\")
        elif esc == "n":
            result.append("\n")
        elif esc == "r":
            result.append("\r")
        elif esc == "t":
            result.append("\t")
        elif esc == "u" and i + 4 < len(value):
            hex_part = value[i + 1 : i + 5]
            try:
                result.append(chr(int(hex_part, 16)))
                i += 4
            except ValueError:
                result.append("\\u")
                result.append(hex_part)
        else:
            result.append("\\")
            result.append(esc)
        i += 1
    return "".join(result)


def find_closing_quote(value: str, start_index: int) -> int:
    escaped = False
    for idx in range(start_index + 1, len(value)):
        ch = value[idx]
        if escaped:
            escaped = False
            continue
        if ch == "\\":
            escaped = True
            continue
        if ch == '"':
            return idx
    return -1
