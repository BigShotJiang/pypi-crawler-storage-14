"""Shared constants for the Toon for Phyton encoder and decoder."""

DEFAULT_DELIMITER = ","
COLON = ":"
DOT = "."
LIST_ITEM_PREFIX = "- "
LIST_ITEM_MARKER = "-"
QUOTE = '"'
BACKSLASH = "\\"
OPEN_BRACKET = "["
CLOSE_BRACKET = "]"
OPEN_BRACE = "{"
CLOSE_BRACE = "}"
LENGTH_MARKER = "#"
