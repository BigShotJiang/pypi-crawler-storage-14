import pytest

from toonforphyton import (
    KeyFoldingMode,
    LengthMismatchBehavior,
    PathExpansionMode,
    ToonDecodeOptions,
    ToonDelimiter,
    ToonOptions,
    decode,
    encode,
)


def test_encode_simple_object():
    payload = {"name": "Alice", "age": 30}

    text = encode(payload)

    assert "name: Alice" in text
    assert "age: 30" in text


def test_encode_tabular_array():
    payload = {"users": [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]}

    text = encode(payload)

    assert "users[2]{id,name}:" in text
    assert "1,Alice" in text
    assert "2,Bob" in text


def test_encode_inline_primitive_array():
    payload = {"tags": ["prod", "api", "v1"]}

    text = encode(payload)

    assert "tags[3]:" in text
    assert "prod,api,v1" in text


def test_key_folding_safe():
    payload = {"api": {"v1": {"status": "ok"}}}
    options = ToonOptions(key_folding=KeyFoldingMode.SAFE)

    text = encode(payload, options)

    assert "api.v1.status: ok" in text
    assert "api:" not in text  # folded path should replace nested keys


def test_decode_path_expansion_safe():
    text = 'api.v1.status: "ok"'
    opts = ToonDecodeOptions(expand_paths=PathExpansionMode.SAFE)

    data = decode(text, opts)

    assert data["api"]["v1"]["status"] == "ok"


def test_decode_length_mismatch_warns_and_recovers():
    text = "items[3]: a,b"
    warnings: list = []
    opts = ToonDecodeOptions(
        strict=False,
        length_mismatch_behavior=LengthMismatchBehavior.WARN,
        warning_sink=warnings,
    )

    data = decode(text, opts)

    assert data["items"] == ["a", "b"]
    assert len(warnings) == 1
    warning = warnings[0]
    assert warning.kind == "length_mismatch"
    assert warning.declared_length == 3
    assert warning.actual_length == 2


def test_encode_decode_empty_structures():
    payload = {"empty_array": [], "empty_object": {}}

    text = encode(payload)
    data = decode(text)

    assert "empty_array[0]:" in text
    assert "empty_object:" in text
    assert data["empty_array"] == []
    assert data["empty_object"] == {}


def test_root_array_empty_and_non_empty():
    text_empty = encode([])
    assert text_empty.strip().startswith("[0]")
    assert decode(text_empty) == []

    text_values = encode([1, 2])
    assert "[2]" in text_values
    assert decode(text_values) == [1, 2]


def test_custom_converter_handles_custom_type():
    class Custom:
        def __init__(self, x: int) -> None:
            self.x = x

    obj = {"item": Custom(5)}
    opts = ToonOptions(default_converter=lambda o: {"value": o.x} if isinstance(o, Custom) else o)

    text = encode(obj, opts)
    assert "value: 5" in text

    data = decode(text)
    assert data["item"]["value"] == 5


@pytest.mark.parametrize(
    "delimiter, marker",
    [
        (ToonDelimiter.TAB, "\t"),
        (ToonDelimiter.PIPE, "|"),
    ],
)
def test_delimiter_variations_tab_and_pipe(delimiter, marker):
    payload = {"rows": [{"a": 1, "b": 2}, {"a": 3, "b": 4}]}
    opts = ToonOptions(delimiter=delimiter)

    text = encode(payload, opts)

    assert f"rows[2{marker}]{{a{marker}b}}:" in text
    assert marker in text.splitlines()[1]  # row delimiter present
