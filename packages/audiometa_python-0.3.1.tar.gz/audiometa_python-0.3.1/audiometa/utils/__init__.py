"""Utility classes and functions for audio metadata processing."""
