# acl/__init__.py
from .db_base import Base

from .models import (
    Permission,
    IkonRolePermission,
    IkonRoleMembership,
    IkonGroup,
    IkonGroupMembership,
    EntityDatasourceMapping,
)

from .repository import (
    DynamicAclRepository,
    JpaAclRepositoryImpl,
    AclRepositoryFactory,
)

from .security import (
    get_db,
    get_current_user_id,
    get_current_account_id,
    permission_required,
    permission_service as PermissionService,
    register_permission_handler,
    PermissionHandler
)

from .seed import seed_default_permissions

__all__ = [
    "Base",
    "Permission",
    "IkonRolePermission",
    "IkonRoleMembership",
    "IkonGroup",
    "IkonGroupMembership",
    "EntityDatasourceMapping",
    "AclRepositoryFactory",
    "DynamicAclRepository",
    "JpaAclRepositoryImpl",
    "PermissionService",
    "permission_required",
    "seed_default_permissions",
]
