import TgQuickReply

def r():
    TgQuickReply.app_run()
    
 
    
r()
