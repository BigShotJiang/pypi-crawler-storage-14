#[allow(clippy::module_inception)]
mod pygrep;

pub(crate) use pygrep::Pygrep;
