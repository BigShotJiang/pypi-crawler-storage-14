﻿"""
GUIDE AI Ethics Framework
G - Governance
U - Understanding  
I - Integrity
D - Disclosure
E - Equity
"""

__version__ = "1.0.0"
__author__ = "GUIDE Ethics Team"

from .guide import GUIDEAuditor

__all__ = ["GUIDEAuditor"]