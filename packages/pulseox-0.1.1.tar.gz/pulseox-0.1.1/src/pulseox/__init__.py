"""PulseOx - Python tools for GitHub pulse dashboards."""

__version__ = "0.1.0"
