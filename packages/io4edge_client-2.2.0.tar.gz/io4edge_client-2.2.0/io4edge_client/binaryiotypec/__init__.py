# SPDX-License-Identifier: Apache-2.0

from .client import Client
import io4edge_client.api.binaryIoTypeC.python.binaryIoTypeC.v1alpha1.binaryIoTypeC_pb2 as Pb

__all__ = ["Client", "Pb"]
