# This module refers to the `citation` GROBID model
