import logging
from sciencebeam_parser.cli import main


if __name__ == '__main__':
    logging.basicConfig(level='INFO')
    main()
