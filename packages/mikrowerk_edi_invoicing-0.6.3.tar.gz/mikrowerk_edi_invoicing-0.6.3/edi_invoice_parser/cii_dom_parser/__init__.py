from .dom_elements_helper import get_string_from_text as get_string_from_text
from .xml_cii_dom_parser import XRechnungCIIXMLParser

__all__ = ['XRechnungCIIXMLParser']

version = "2.4.0"
