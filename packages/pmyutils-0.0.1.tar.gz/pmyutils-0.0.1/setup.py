from setuptools import setup, find_packages

setup(
    name='pmyutils',
    version='0.0.1',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'open3d',
    ],
    author='PMY',
    author_email='863102089@qq.com',
    description='personal utils',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/mingyangpeng/pmyutils.git',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    # 添加项目页面和bug跟踪链接
    project_urls={
        'Bug Reports': 'https://github.com/mingyangpeng/pmyutils/issues',
        'Source': 'https://github.com/mingyangpeng/pmyutils',
    },
)