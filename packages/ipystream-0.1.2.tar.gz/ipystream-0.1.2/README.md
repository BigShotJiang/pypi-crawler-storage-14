# ipystream

Easy interactive Jupyter dashboards, flowing top to bottom like a stream

`python -m pytest`

`poetry publish --build`