def test_doa_encoding() -> None:
    pass
