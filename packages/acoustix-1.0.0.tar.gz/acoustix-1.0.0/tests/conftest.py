import matplotlib

matplotlib.use("module://sixel")
