"""
Project Management Automation MCP Server

MCP server for project management automation tools.
"""

__version__ = "0.1.11"
