"""
MCP Resource Handlers for Project Management Automation

These modules provide resource access for automation status, history, and metadata.
"""
