def mul(a, b):
    return a * b
