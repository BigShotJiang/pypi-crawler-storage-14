from mcp.server.fastmcp import FastMCP

mcp_prospectio = FastMCP(name="Prospectio MCP", stateless_http=True)
