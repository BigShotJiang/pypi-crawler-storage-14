# baloot
My personal helper functions
