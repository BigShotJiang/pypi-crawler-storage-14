if __name__ == "__main__":
    from scrybe.main import main
    main()

