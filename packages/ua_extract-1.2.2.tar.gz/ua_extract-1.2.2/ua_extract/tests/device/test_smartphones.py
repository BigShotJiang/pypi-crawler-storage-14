from ..base import DetectorBaseTest


class TestDetectSmartPhone(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone.yml',
    ]


class TestDetectSmartPhone1(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-1.yml',
    ]


class TestDetectSmartPhone2(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-2.yml',
    ]


class TestDetectSmartPhone3(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-3.yml',
    ]


class TestDetectSmartPhone4(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-4.yml',
    ]


class TestDetectSmartPhone5(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-5.yml',
    ]


class TestDetectSmartPhone6(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-6.yml',
    ]


class TestDetectSmartPhone7(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-7.yml',
    ]


class TestDetectSmartPhone8(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-8.yml',
    ]


class TestDetectSmartPhone9(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-9.yml',
    ]


class TestDetectSmartPhone10(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-10.yml',
    ]


class TestDetectSmartPhone11(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-11.yml',
    ]


class TestDetectSmartPhone12(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-12.yml',
    ]


class TestDetectSmartPhone13(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-13.yml',
    ]


class TestDetectSmartPhone14(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-14.yml',
    ]


class TestDetectSmartPhone15(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-15.yml',
    ]


class TestDetectSmartPhone16(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-16.yml',
    ]


class TestDetectSmartPhone17(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-17.yml',
    ]


class TestDetectSmartPhone18(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-18.yml',
    ]


class TestDetectSmartPhone19(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-19.yml',
    ]


class TestDetectSmartPhone20(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-20.yml',
    ]


class TestDetectSmartPhone21(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-21.yml',
    ]


class TestDetectSmartPhone22(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-22.yml',
    ]


class TestDetectSmartPhone23(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-23.yml',
    ]


class TestDetectSmartPhone24(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-24.yml',
    ]


class TestDetectSmartPhone25(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-25.yml',
    ]


class TestDetectSmartPhone26(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-26.yml',
    ]


class TestDetectSmartPhone27(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-27.yml',
    ]


class TestDetectSmartPhone28(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-28.yml',
    ]


class TestDetectSmartPhone29(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-29.yml',
    ]


class TestDetectSmartPhone30(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-30.yml',
    ]


class TestDetectSmartPhone31(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-31.yml',
    ]


class TestDetectSmartPhone32(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-32.yml',
    ]


class TestDetectSmartPhone33(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-33.yml',
    ]


class TestDetectSmartPhone34(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-34.yml',
    ]


class TestDetectSmartPhone35(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-36.yml',
    ]


class TestDetectSmartPhone38(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-37.yml',
    ]


class TestDetectSmartPhone39(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-39.yml',
    ]


class TestDetectSmartPhone40(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-40.yml',
    ]


class TestDetectSmartPhone41(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-41.yml',
    ]


class TestDetectSmartPhone42(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/smartphone-42.yml',
    ]
