## FourierSplit Imaging Method  
---  

### Overview  
Same method as *Fourier Shift*, but using the *splitting* technique instead.  

| Development Status | Technique Specificity | Measurement Output Format | Example Patterns |
|--------------------|-----------------------|----------------------------|------------------|
| Functional and final | Classical SPI | Datacube | <p align="center"> <img src="img/fouriersplit.png" alt="hub" width="100"/> </p> |

## install 
tested with python 3.9
```bash
pip install onepix_fouriersplit
```

### 🔗 Source Code  
📁 Access the source code on GitHub:  
👉 [ONE-PIX – FourierSplit Imaging Method](https://github.com/PhotonicsOpenProjects/ONE-PIX/tree/main/plugins/imaging_methods/FourierSplit)

## 🧪 Author & Contributor  
🔧 Made by [POP](https://www.photonics-open-projects.com/) 💡