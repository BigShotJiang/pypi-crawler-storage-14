"""KernelMonitor - Observability and Metrics-as-Data.

This module implements the observability layer for the Malha kernel,
collecting metrics and storing them as queryable data in DuckDB.

Key Features:
- Metrics-as-Data: All metrics stored in DuckDB for SQL queries
- Low overhead: Async collection, batch writes
- Rich context: Captures operation, duration, status, metadata
- Time-series ready: Timestamp-indexed for trend analysis
- Zero dependencies: Uses existing DuckDB driver

Architecture:
    KernelMonitor
        ├─ collect_metric()     # Record single metric
        ├─ collect_batch()      # Record multiple metrics
        ├─ query_metrics()      # SQL queries on metrics
        └─ get_summary()        # Aggregated statistics

Metrics Schema:
    CREATE TABLE kernel_metrics (
        timestamp TIMESTAMP,
        operation VARCHAR,      -- 'save', 'query', 'replicate', etc.
        duration_ms DOUBLE,     -- Operation duration
        status VARCHAR,         -- 'success', 'error', 'timeout'
        resource_type VARCHAR,  -- Model/resource type
        node_id VARCHAR,        -- Node identifier
        metadata JSON           -- Additional context
    )

Usage:
    monitor = KernelMonitor(analytics_driver)
    
    # Collect metric
    await monitor.collect_metric(
        operation='save_versioned',
        duration_ms=45.2,
        status='success',
        resource_type='TestModel',
        metadata={'rid': 'test:123', 'version': 2}
    )
    
    # Query metrics
    results = await monitor.query_metrics(
        "SELECT operation, AVG(duration_ms) FROM kernel_metrics GROUP BY operation"
    )
    
    # Get summary
    summary = await monitor.get_summary(hours=24)
"""

import asyncio
import logging
import time
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)


class KernelMonitor:
    """Observability and metrics collection for the Malha kernel.
    
    Implements Metrics-as-Data pattern: all metrics are stored in DuckDB
    as queryable tables, enabling SQL-based analysis and monitoring.
    """

    def __init__(
        self,
        analytics_driver,
        node_id: str = "local",
        batch_size: int = 100,
        flush_interval: float = 10.0,
    ):
        """Initialize the kernel monitor.
        
        Args:
            analytics_driver: DuckDB driver for metrics storage
            node_id: Identifier for this node
            batch_size: Number of metrics to batch before writing
            flush_interval: Seconds between automatic flushes
        """
        self.analytics = analytics_driver
        self.node_id = node_id
        self.batch_size = batch_size
        self.flush_interval = flush_interval

        self._metrics_buffer: list[dict[str, Any]] = []
        self._buffer_lock = asyncio.Lock()
        self._flush_task: asyncio.Task | None = None
        self._running = False

        # Initialize metrics table
        self._init_metrics_table()

    def _init_metrics_table(self) -> None:
        """Create the kernel_metrics table if it doesn't exist."""
        try:
            self.analytics.conn.execute("""
                CREATE TABLE IF NOT EXISTS kernel_metrics (
                    timestamp TIMESTAMP,
                    operation VARCHAR,
                    duration_ms DOUBLE,
                    status VARCHAR,
                    resource_type VARCHAR,
                    node_id VARCHAR,
                    metadata JSON
                )
            """)
            logger.info("[Monitor] Metrics table initialized")
        except Exception as e:
            logger.error(f"[Monitor] Failed to initialize metrics table: {e}")

    async def collect_metric(
        self,
        operation: str,
        duration_ms: float,
        status: str = "success",
        resource_type: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Collect a single metric.
        
        Metrics are buffered and written in batches for efficiency.
        
        Args:
            operation: Operation name (e.g., 'save_versioned', 'query')
            duration_ms: Operation duration in milliseconds
            status: Operation status ('success', 'error', 'timeout')
            resource_type: Type of resource (model name)
            metadata: Additional context as JSON
        """
        metric = {
            "timestamp": datetime.now(UTC),
            "operation": operation,
            "duration_ms": duration_ms,
            "status": status,
            "resource_type": resource_type or "unknown",
            "node_id": self.node_id,
            "metadata": metadata or {},
        }

        async with self._buffer_lock:
            self._metrics_buffer.append(metric)

            # Auto-flush if buffer is full
            if len(self._metrics_buffer) >= self.batch_size:
                await self._flush_metrics()

    async def collect_batch(self, metrics: list[dict[str, Any]]) -> None:
        """Collect multiple metrics at once.
        
        Args:
            metrics: List of metric dictionaries
        """
        async with self._buffer_lock:
            self._metrics_buffer.extend(metrics)

            if len(self._metrics_buffer) >= self.batch_size:
                await self._flush_metrics()

    async def _flush_metrics(self) -> None:
        """Write buffered metrics to DuckDB.
        
        Note: Must be called with _buffer_lock held.
        """
        if not self._metrics_buffer:
            return

        try:
            # Prepare batch insert
            import json

            values = []
            for m in self._metrics_buffer:
                metadata_json = json.dumps(m["metadata"])
                values.append(
                    f"('{m['timestamp'].isoformat()}', '{m['operation']}', "
                    f"{m['duration_ms']}, '{m['status']}', '{m['resource_type']}', "
                    f"'{m['node_id']}', '{metadata_json}')",
                )

            values_str = ", ".join(values)

            self.analytics.conn.execute(f"""
                INSERT INTO kernel_metrics 
                (timestamp, operation, duration_ms, status, resource_type, node_id, metadata)
                VALUES {values_str}
            """)

            logger.debug(f"[Monitor] Flushed {len(self._metrics_buffer)} metrics")
            self._metrics_buffer.clear()

        except Exception as e:
            logger.error(f"[Monitor] Failed to flush metrics: {e}")
            # Keep metrics in buffer for retry

    async def start_auto_flush(self) -> None:
        """Start background task to periodically flush metrics."""
        self._running = True

        async def _flush_loop():
            while self._running:
                try:
                    await asyncio.sleep(self.flush_interval)
                    async with self._buffer_lock:
                        await self._flush_metrics()
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"[Monitor] Error in flush loop: {e}")

        self._flush_task = asyncio.create_task(_flush_loop())
        logger.info(f"[Monitor] Auto-flush started (interval={self.flush_interval}s)")

    async def stop(self) -> None:
        """Stop the monitor and flush remaining metrics."""
        self._running = False

        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass

        # Final flush
        async with self._buffer_lock:
            await self._flush_metrics()

        logger.info("[Monitor] Stopped")

    def query_metrics(self, sql: str) -> list[tuple]:
        """Execute SQL query on metrics table.
        
        Args:
            sql: SQL query string
            
        Returns:
            Query results as list of tuples
            
        Example:
            results = monitor.query_metrics(
                "SELECT operation, AVG(duration_ms) "
                "FROM kernel_metrics "
                "WHERE timestamp > NOW() - INTERVAL 1 HOUR "
                "GROUP BY operation"
            )
        """
        try:
            return self.analytics.conn.execute(sql).fetchall()
        except Exception as e:
            logger.error(f"[Monitor] Query failed: {e}")
            return []

    def get_summary(self, hours: int = 24) -> dict[str, Any]:
        """Get aggregated metrics summary.
        
        Args:
            hours: Number of hours to look back
            
        Returns:
            Dictionary with summary statistics
        """
        try:
            # Total operations
            total = self.analytics.conn.execute(f"""
                SELECT COUNT(*) FROM kernel_metrics
                WHERE timestamp > NOW() - INTERVAL {hours} HOUR
            """).fetchone()[0]

            # By operation
            by_operation = self.analytics.conn.execute(f"""
                SELECT 
                    operation,
                    COUNT(*) as count,
                    AVG(duration_ms) as avg_duration,
                    MAX(duration_ms) as max_duration,
                    SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors
                FROM kernel_metrics
                WHERE timestamp > NOW() - INTERVAL {hours} HOUR
                GROUP BY operation
                ORDER BY count DESC
            """).fetchall()

            # By status
            by_status = self.analytics.conn.execute(f"""
                SELECT status, COUNT(*) as count
                FROM kernel_metrics
                WHERE timestamp > NOW() - INTERVAL {hours} HOUR
                GROUP BY status
            """).fetchall()

            # By node
            by_node = self.analytics.conn.execute(f"""
                SELECT node_id, COUNT(*) as count
                FROM kernel_metrics
                WHERE timestamp > NOW() - INTERVAL {hours} HOUR
                GROUP BY node_id
            """).fetchall()

            return {
                "period_hours": hours,
                "total_operations": total,
                "by_operation": [
                    {
                        "operation": row[0],
                        "count": row[1],
                        "avg_duration_ms": row[2],
                        "max_duration_ms": row[3],
                        "errors": row[4],
                    }
                    for row in by_operation
                ],
                "by_status": {row[0]: row[1] for row in by_status},
                "by_node": {row[0]: row[1] for row in by_node},
            }
        except Exception as e:
            logger.error(f"[Monitor] Failed to get summary: {e}")
            return {}


class MetricTimer:
    """Context manager for timing operations and collecting metrics.
    
    Usage:
        async with MetricTimer(monitor, 'save_versioned', resource_type='TestModel'):
            await manager.save_versioned(resource)
    """

    def __init__(
        self,
        monitor: KernelMonitor,
        operation: str,
        resource_type: str | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        self.monitor = monitor
        self.operation = operation
        self.resource_type = resource_type
        self.metadata = metadata or {}
        self.start_time = 0.0
        self.status = "success"

    async def __aenter__(self):
        self.start_time = time.perf_counter()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        duration_ms = (time.perf_counter() - self.start_time) * 1000

        if exc_type is not None:
            self.status = "error"
            self.metadata["error"] = str(exc_val)

        await self.monitor.collect_metric(
            operation=self.operation,
            duration_ms=duration_ms,
            status=self.status,
            resource_type=self.resource_type,
            metadata=self.metadata,
        )

        return False  # Don't suppress exceptions
