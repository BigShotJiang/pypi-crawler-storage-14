"""
Malha Bootloader - System Recovery and Initialization
======================================================

The Bootloader is the "defibrillator" of the Malha OS. It runs before any
user requests are accepted and ensures the system recovers from crashes.

Responsibilities:
1. WAL Recovery: Process orphaned .wal files from StreamDriver
2. Process Recovery: Detect and handle zombie processes (workflows/sagas)
3. Sanity Checks: Verify database consistency

Usage:
    ```python
    from malha import connect
    
    # Boot is automatic when auto_boot=True (default)
    kernel = await connect(auto_boot=True)
    
    # Or manual boot
    from malha.boot import Bootloader
    bootloader = Bootloader(kernel)
    await bootloader.run()
    ```
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, UTC
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Any

from sqlalchemy import select, update

if TYPE_CHECKING:
    from .malha import UnifiedDataManager

logger = logging.getLogger("malha.boot")


# ==============================================================================
# WORKFLOW REGISTRY (For Process Recovery)
# ==============================================================================

# Registry mapping process_type -> recovery handler
# Populated by @recoverable decorator or manual registration
WORKFLOW_REGISTRY: dict[str, Callable] = {}


def recoverable(process_type: str):
    """Decorator to register a workflow class for crash recovery.
    
    Example:
        ```python
        @recoverable("order_workflow")
        class OrderWorkflow:
            @classmethod
            async def recover(cls, process: SysProcess, kernel):
                state = json.loads(process.state_payload)
                workflow = cls(order_id=state["order_id"])
                await workflow.resume_from_step(state["current_step"])
        ```
    """
    def decorator(cls):
        if hasattr(cls, "recover"):
            WORKFLOW_REGISTRY[process_type] = cls.recover
        else:
            logger.warning(
                f"[Boot] Class {cls.__name__} registered as recoverable "
                f"but has no 'recover' method"
            )
        return cls
    return decorator


def register_recovery_handler(process_type: str, handler: Callable):
    """Manually register a recovery handler for a process type.
    
    Args:
        process_type: The process_type string stored in SysProcess
        handler: Async function(process: SysProcess, kernel) -> None
    
    Example:
        ```python
        async def recover_order(process, kernel):
            state = json.loads(process.state_payload)
            # ... resume logic ...
        
        register_recovery_handler("order_workflow", recover_order)
        ```
    """
    WORKFLOW_REGISTRY[process_type] = handler
    logger.info(f"[Boot] Registered recovery handler for '{process_type}'")


# ==============================================================================
# BOOTLOADER
# ==============================================================================

class Bootloader:
    """System bootloader for crash recovery and initialization.
    
    The Bootloader runs during kernel startup to:
    1. Recover data from WAL files (StreamDriver)
    2. Detect and handle zombie processes
    3. Perform sanity checks on databases
    4. Apply pending database migrations (optional)
    
    Attributes:
        kernel: The UnifiedDataManager instance
        heartbeat_timeout: Seconds before a process is considered dead (default: 300)
        auto_recover: Whether to automatically resume recoverable processes
        auto_migrate: Whether to apply pending Alembic migrations on boot
        migrations_path: Path to Alembic migrations directory
    """
    
    def __init__(
        self, 
        kernel: "UnifiedDataManager",
        heartbeat_timeout: int = 300,
        auto_recover: bool = False,
        auto_migrate: bool = False,
        migrations_path: str = "./migrations",
    ):
        """Initialize the Bootloader.
        
        Args:
            kernel: The kernel instance to boot
            heartbeat_timeout: Seconds without heartbeat before process is dead
            auto_recover: If True, attempt to resume processes with registered handlers.
                         If False (default), just mark them as FAILED for manual review.
            auto_migrate: If True, apply pending Alembic migrations before boot.
                         Requires migrations directory to be initialized.
            migrations_path: Path to Alembic migrations directory
        """
        self.kernel = kernel
        self.heartbeat_timeout = heartbeat_timeout
        self.auto_recover = auto_recover
        self.auto_migrate = auto_migrate
        self.migrations_path = migrations_path
        self._recovered_count = 0
        self._failed_count = 0

    async def run(self) -> "BootResult":
        """Execute the full boot sequence.
        
        Returns:
            BootResult with statistics about recovery operations
        """
        logger.info("🚀 Malha OS Booting...")
        start_time = datetime.now(UTC)
        
        # 0. Apply pending migrations (if enabled)
        migrations_applied = 0
        if self.auto_migrate:
            migrations_applied = await self._apply_migrations()
        
        # 1. Recover Stream WAL (data that was in RAM buffers)
        wal_records = await self._recover_streams()
        
        # 2. Recover zombie processes (workflows that died mid-execution)
        zombies_found, zombies_recovered = await self._recover_processes()
        
        # 3. Sanity checks (optional, can be extended)
        await self._sanity_checks()
        
        duration = (datetime.now(UTC) - start_time).total_seconds()
        
        result = BootResult(
            duration_seconds=duration,
            wal_records_recovered=wal_records,
            zombies_found=zombies_found,
            zombies_recovered=zombies_recovered,
            zombies_failed=zombies_found - zombies_recovered,
            migrations_applied=migrations_applied,
        )
        
        logger.info(f"✅ Boot complete in {duration:.2f}s: {result}")
        return result

    async def _apply_migrations(self) -> int:
        """Apply pending Alembic migrations.
        
        Returns:
            Number of migrations applied (0 if none pending or not initialized)
        """
        try:
            from pathlib import Path
            migrations_dir = Path(self.migrations_path)
            
            if not migrations_dir.exists():
                logger.debug("[Boot] Migrations directory not found, skipping")
                return 0
            
            from malha.drivers.alembic import AlembicDriver
            
            driver = AlembicDriver(self.kernel, migrations_path=self.migrations_path)
            
            if not driver.is_initialized:
                logger.debug("[Boot] Alembic not initialized, skipping migrations")
                return 0
            
            # Check for pending migrations
            pending = await driver.pending()
            if not pending:
                logger.debug("[Boot] No pending migrations")
                return 0
            
            logger.info(f"[Boot] 📦 Applying {len(pending)} pending migrations...")
            
            result = await driver.upgrade("head")
            
            if result.success:
                logger.info(f"[Boot] ✅ Migrations applied successfully")
                return len(pending)
            else:
                logger.error(f"[Boot] ❌ Migration failed: {result.error}")
                return 0
                
        except ImportError:
            logger.debug("[Boot] Alembic not installed, skipping migrations")
            return 0
        except Exception as e:
            logger.error(f"[Boot] Migration error: {e}")
            return 0

    async def _recover_streams(self) -> int:
        """Recover data from WAL files left by StreamDriver.
        
        The ParquetStreamDriver automatically recovers WAL on __init__,
        but we can force a flush here to ensure data is persisted.
        
        Returns:
            Number of records recovered from WAL
        """
        records_recovered = 0
        
        # Check if kernel has a stream driver
        if not hasattr(self.kernel, "stream") or self.kernel.stream is None:
            logger.debug("[Boot] No stream driver configured, skipping WAL recovery")
            return 0
        
        stream = self.kernel.stream
        
        # The ParquetStreamDriver recovers WAL in __init__ via _recover_from_wal()
        # Here we just ensure a flush happens to persist any recovered data
        try:
            # Check if it's our ParquetStreamDriver with WAL
            if hasattr(stream, "wal_enabled") and stream.wal_enabled:
                # Check for pending WAL records
                if hasattr(stream, "_wal_path") and stream._wal_path.exists():
                    with open(stream._wal_path, "r") as f:
                        records_recovered = sum(1 for _ in f)
                    
                    if records_recovered > 0:
                        logger.info(f"[Boot] Found {records_recovered} records in WAL, flushing...")
                        await stream.flush()
                        logger.info(f"[Boot] WAL recovery complete: {records_recovered} records")
                        
        except Exception as e:
            logger.error(f"[Boot] WAL recovery failed: {e}")
        
        return records_recovered

    async def _recover_processes(self) -> tuple[int, int]:
        """Detect and recover zombie processes using atomic state transition.
        
        This implementation uses the Compare-and-Swap (CAS) pattern to prevent
        race conditions in clustered deployments. Instead of SELECT-then-UPDATE,
        we UPDATE-then-SELECT to atomically claim ownership of zombie processes.
        
        Race Condition Prevention:
            In a cluster (e.g., 3 Kubernetes pods), multiple nodes may boot
            simultaneously after a crash. Without atomic claiming:
            
            1. Node-A SELECTs 10 zombies
            2. Node-B SELECTs the same 10 zombies
            3. Both nodes try to recover the same processes
            4. Result: Double execution (duplicate charges, emails, etc.)
            
            With atomic claiming (this implementation):
            
            1. Node-A UPDATEs zombies WHERE status=RUNNING → status=RECOVERING
            2. Node-B UPDATEs zombies WHERE status=RUNNING → finds none (already claimed)
            3. Each node only processes what it successfully claimed
        
        Returns:
            Tuple of (zombies_found, zombies_recovered)
        """
        from .malha import SysProcess, ProcessStatus
        
        # Get this node's identifier for ownership tracking
        my_node_id = getattr(self.kernel, 'node_id', 'local')
        
        zombies_found = 0
        zombies_recovered = 0
        
        try:
            async with await self.kernel.sql_driver.get_session() as session:
                # Step 1: Atomically claim zombie processes
                # This UPDATE is atomic - only one node can claim each process
                # Uses Compare-and-Swap: only update if status is still RUNNING
                
                heartbeat_cutoff = datetime.now(UTC) - timedelta(seconds=self.heartbeat_timeout)
                
                claim_stmt = (
                    update(SysProcess)
                    .where(
                        SysProcess.status == ProcessStatus.RUNNING.value,
                        # Only claim processes with stale heartbeats
                        # This prevents killing processes that are actually alive
                        (SysProcess.heartbeat < heartbeat_cutoff) | (SysProcess.heartbeat.is_(None))
                    )
                    .values(
                        status="RECOVERING",  # Transitional status - prevents double-claim
                        node_id=my_node_id,   # Mark ownership
                        heartbeat=datetime.now(UTC),  # Update heartbeat
                    )
                )
                
                result = await session.execute(claim_stmt)
                await session.commit()
                
                # Step 2: Fetch only the processes THIS node claimed
                # Other nodes will see status=RECOVERING and skip them
                my_zombies_stmt = select(SysProcess).where(
                    SysProcess.status == "RECOVERING",
                    SysProcess.node_id == my_node_id,
                )
                result = await session.execute(my_zombies_stmt)
                my_zombies = result.scalars().all()
                zombies_found = len(my_zombies)
                
                if not my_zombies:
                    logger.info("[Boot] No zombie processes claimed by this node")
                    return 0, 0
                
                logger.warning(
                    f"[Boot] 🧟 Claimed {zombies_found} zombie processes "
                    f"(node_id={my_node_id})"
                )
                
                # Step 3: Process each claimed zombie
                for proc in my_zombies:
                    recovered = await self._recover_single_process(session, proc)
                    if recovered:
                        zombies_recovered += 1
                
                await session.commit()
                
        except Exception as e:
            logger.error(f"[Boot] Process recovery failed: {e}")
        
        return zombies_found, zombies_recovered

    async def _recover_single_process(self, session, proc) -> bool:
        """Attempt to recover a single zombie process.
        
        The process is already in RECOVERING status (claimed by this node).
        This method either:
        1. Starts auto-recovery (if handler exists and auto_recover=True)
        2. Marks as FAILED (if no handler or auto_recover=False)
        
        Args:
            session: Database session
            proc: SysProcess instance (status=RECOVERING)
            
        Returns:
            True if process was successfully recovered/handled
        """
        from .malha import ProcessStatus
        
        logger.info(
            f"[Boot] Processing zombie: {proc.process_name} "
            f"(type={proc.process_type}, id={proc.id})"
        )
        
        # Check if we have a recovery handler
        handler = WORKFLOW_REGISTRY.get(proc.process_type)
        
        if handler and self.auto_recover:
            try:
                # Attempt automatic recovery
                logger.info(f"[Boot] Attempting auto-recovery for process {proc.id}")
                
                # Transition from RECOVERING back to RUNNING
                # The recovery handler will manage the process from here
                proc.status = ProcessStatus.RUNNING.value
                proc.heartbeat = datetime.now(UTC)
                proc.error = "Recovery initiated by bootloader"
                session.add(proc)
                
                # Fire and forget - recovery runs in background
                # The handler is responsible for updating status to COMPLETED/FAILED
                asyncio.create_task(
                    self._execute_recovery(handler, proc)
                )
                
                return True
                
            except Exception as e:
                logger.error(f"[Boot] Auto-recovery failed for {proc.id}: {e}")
                # Fall through to mark as failed
        
        # No handler or auto_recover disabled: mark as failed
        proc.status = ProcessStatus.FAILED.value
        proc.completed_at = datetime.now(UTC)
        proc.error = (
            f"Process died during execution. "
            f"Last heartbeat: {proc.heartbeat}. "
            f"Recovery handler: {'available' if handler else 'not registered'}"
        )
        session.add(proc)
        
        logger.warning(
            f"[Boot] Marked process {proc.id} ({proc.process_name}) as FAILED"
        )
        return False

    async def _execute_recovery(self, handler: Callable, proc) -> None:
        """Execute a recovery handler in the background.
        
        Args:
            handler: The recovery function
            proc: SysProcess instance
        """
        from .malha import ProcessStatus
        
        try:
            await handler(proc, self.kernel)
            logger.info(f"[Boot] Recovery successful for process {proc.id}")
            
        except Exception as e:
            logger.error(f"[Boot] Recovery execution failed for {proc.id}: {e}")
            
            # Mark as dead letter (unrecoverable)
            try:
                async with await self.kernel.sql_driver.get_session() as session:
                    stmt = (
                        update(type(proc))
                        .where(type(proc).id == proc.id)
                        .values(
                            status=ProcessStatus.DEAD_LETTER.value,
                            error=f"Recovery failed: {e}",
                            completed_at=datetime.now(UTC),
                        )
                    )
                    await session.execute(stmt)
                    await session.commit()
            except Exception as db_error:
                logger.error(f"[Boot] Failed to update process status: {db_error}")

    async def _sanity_checks(self) -> None:
        """Perform sanity checks on the system.
        
        Currently checks:
        - SQL connection is working
        - Graph database is accessible
        - No critical inconsistencies
        """
        logger.debug("[Boot] Running sanity checks...")
        
        # Check SQL
        try:
            async with await self.kernel.sql_driver.get_session() as session:
                await session.execute(select(1))
            logger.debug("[Boot] SQL: OK")
        except Exception as e:
            logger.error(f"[Boot] SQL sanity check failed: {e}")
        
        # Check Graph (Kùzu)
        try:
            if hasattr(self.kernel, "graph_driver"):
                # Simple query to verify graph is accessible
                await self.kernel.graph_driver.query("RETURN 1")
            logger.debug("[Boot] Graph: OK")
        except Exception as e:
            logger.warning(f"[Boot] Graph sanity check failed: {e}")


# ==============================================================================
# BOOT RESULT
# ==============================================================================

class BootResult:
    """Result of a boot operation with statistics."""
    
    def __init__(
        self,
        duration_seconds: float = 0.0,
        wal_records_recovered: int = 0,
        zombies_found: int = 0,
        zombies_recovered: int = 0,
        zombies_failed: int = 0,
        migrations_applied: int = 0,
    ):
        self.duration_seconds = duration_seconds
        self.wal_records_recovered = wal_records_recovered
        self.zombies_found = zombies_found
        self.zombies_recovered = zombies_recovered
        self.zombies_failed = zombies_failed
        self.migrations_applied = migrations_applied
    
    def __str__(self) -> str:
        parts = [f"wal={self.wal_records_recovered}"]
        if self.migrations_applied > 0:
            parts.append(f"migrations={self.migrations_applied}")
        parts.extend([
            f"zombies={self.zombies_found}",
            f"recovered={self.zombies_recovered}",
            f"failed={self.zombies_failed}",
        ])
        return f"BootResult({', '.join(parts)})"
    
    def __repr__(self) -> str:
        return self.__str__()


# ==============================================================================
# CONVENIENCE FUNCTION
# ==============================================================================

async def boot_kernel(
    kernel: "UnifiedDataManager",
    heartbeat_timeout: int = 300,
    auto_recover: bool = False,
    auto_migrate: bool = False,
    migrations_path: str = "./migrations",
) -> BootResult:
    """Convenience function to boot a kernel.
    
    Args:
        kernel: The kernel to boot
        heartbeat_timeout: Seconds before process is considered dead
        auto_recover: Attempt automatic recovery for registered handlers
        auto_migrate: Apply pending Alembic migrations before boot
        migrations_path: Path to Alembic migrations directory
        
    Returns:
        BootResult with recovery statistics
    """
    bootloader = Bootloader(
        kernel,
        heartbeat_timeout=heartbeat_timeout,
        auto_recover=auto_recover,
        auto_migrate=auto_migrate,
        migrations_path=migrations_path,
    )
    return await bootloader.run()
