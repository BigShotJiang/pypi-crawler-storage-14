EX4= r"""
from keras.preprocessing.image import load_img
    from keras.preprocessing.image import img_to_array
    from keras.applications.vgg16 import preprocess_input
    from keras.applications.vgg16 import decode_predictions
    from keras.applications.vgg16 import VGG16


    print("\n=== EXERCISE 4 — IMAGE CLASSIFICATION USING VGG16 ===\n")

    # --------------------------------------------------------
    # (1) YOU SAID YOU WANT THIS ENTIRE QUOTED CODE INCLUDED
    # --------------------------------------------------------
    from tensorflow.keras.applications import VGG16,VGG19,ResNet50,InceptionV3,Xception,imagenet_utils
    from tensorflow.keras.applications.inception_v3 import preprocess_input
    from tensorflow.keras.preprocessing.image import load_img,img_to_array
    import numpy as np

    model_name = "ResNet50"
    path = "bird.jpg"

    models = {
        "VGG16":(VGG16,(224,224),imagenet_utils.preprocess_input),
        "VGG19":(VGG19,(224,224),imagenet_utils.preprocess_input),
        "ResNet50":(ResNet50,(224,224),imagenet_utils.preprocess_input),
        "InceptionV3":(InceptionV3,(299,299),preprocess_input),
        "xception":(Xception,(299,299),preprocess_input)
    }

    model,size,preprocess = models[model_name]
    Model = model(weights = "imagenet")
    img = load_img(path,target_size = size)
    arr = img_to_array(img)
    img = np.expand_dims(arr,0)
    img = preprocess(img)

    preds = Model.predict(img)
    decoded = imagenet_utils.decode_predictions(preds,top= 3)[0]

    for (i,(id,label,prob)) in enumerate(decoded):
        print(f"{i+1} {label} : {prob*100:.2f}%")
    

    # --------------------------------------------------------
    # (2) ACTUAL EXECUTABLE PART OF EX4
    # --------------------------------------------------------

    model = VGG16()

    # Load image
    image = load_img(r'D:\Studies\Sem-7\Deep Learning Concepts and Architectures\Exercise\Bird.jpg',
                     target_size=(224, 224))

    image = img_to_array(image)
    image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))

    image = preprocess_input(image)

    # Make prediction
    yhat = model.predict(image)
    label = decode_predictions(yhat)
    label = label[0][0]

    # Print top prediction
    print("\nPredicted Class:")
    print('%s (%.2f%%)' % (label[1], label[2] * 100))


"""


def get4():
    print(EX4)
    return EX4
    
