from .ex1 import get1
from .ex2 import get2
from .ex3 import get3
from .ex4 import get4
from .ex5 import get5
from .ex6 import get6
from .ex7 import get7

__all__ = ["get1", "get2", "get3", "get4", "get5", "get6", "get7"]
