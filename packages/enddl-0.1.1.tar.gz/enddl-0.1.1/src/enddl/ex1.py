EX1 = r"""
import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt
    from pycm import ConfusionMatrix
    
    confusion_matrix = {
        "Red Disease":       {"Red Disease": 92, "Aeromoniasis": 0,  "Gill Disease": 3, "Saprolegniasis": 2, "Healthy Fish": 0,  "Parasitic Disease": 0,  "White Tail Disease": 3},
        "Aeromoniasis":      {"Red Disease": 0,  "Aeromoniasis": 94, "Gill Disease": 3, "Saprolegniasis": 0, "Healthy Fish": 3,  "Parasitic Disease": 0,  "White Tail Disease": 0},
        "Gill Disease":      {"Red Disease": 2,  "Aeromoniasis": 0,  "Gill Disease": 95,"Saprolegniasis": 0, "Healthy Fish": 0,  "Parasitic Disease": 1,  "White Tail Disease": 2},
        "Saprolegniasis":    {"Red Disease": 5,  "Aeromoniasis": 1,  "Gill Disease": 0, "Saprolegniasis": 90,"Healthy Fish": 1,  "Parasitic Disease": 3,  "White Tail Disease": 0},
        "Healthy Fish":      {"Red Disease": 1,  "Aeromoniasis": 0,  "Gill Disease": 0, "Saprolegniasis": 0, "Healthy Fish": 99, "Parasitic Disease": 0,  "White Tail Disease": 0},
        "Parasitic Disease": {"Red Disease": 0,  "Aeromoniasis": 3,  "Gill Disease": 7, "Saprolegniasis": 1, "Healthy Fish": 4,  "Parasitic Disease": 83, "White Tail Disease": 2},
        "White Tail Disease":{"Red Disease": 4,  "Aeromoniasis": 0,  "Gill Disease": 3, "Saprolegniasis": 2, "Healthy Fish": 5,  "Parasitic Disease": 1,  "White Tail Disease": 85}
    }

    cm = ConfusionMatrix(matrix=confusion_matrix)

    print(cm)
    print("Overall Accuracy:", cm.Overall_ACC)
    print("Kappa:", cm.Kappa)
    print("Macro F1:", cm.F1_Macro)
    print("Micro F1:", cm.F1_Micro)
    print("Macro Precision:", cm.PPV_Macro)
    print("Macro Recall (Sensitivity):", cm.TPR_Macro)
    print("Macro Specificity:", cm.TNR_Macro)

    classes = ["Red Disease","Aeromoniasis","Gill Disease","Saprolegniasis","Healthy Fish","Parasitic Disease","White Tail Disease"]

    df = pd.DataFrame(confusion_matrix)
    df = df.reindex(index=classes, columns=classes).astype(int)

    plt.figure(figsize=(14, 12))
    sns.heatmap(df, annot=True, fmt="d", cmap="YlGnBu", cbar=True, square=True)
    plt.title("Confusion Matrix for MobileNetV2 based Classifier Model")
    plt.xlabel("Predicted Disease")
    plt.ylabel("Actual Disease")
    plt.tight_layout()
    plt.show()
"""

def get1():
    
    print(EX1)
    return EX1
