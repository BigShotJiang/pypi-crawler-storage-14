# dcmtags_lyx

This is a simple example package.