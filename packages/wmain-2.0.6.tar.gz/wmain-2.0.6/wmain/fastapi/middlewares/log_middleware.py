import time
from datetime import datetime, timezone
from typing import Optional, Callable, Awaitable

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import StreamingResponse, FileResponse
from pydantic import BaseModel


class LogInfo(BaseModel):
    client: str
    method: str
    url: str
    scheme: str
    host: str
    port: int
    path: str
    query_string: str
    http_version: str

    # Request
    request_headers: dict
    request_body: Optional[bytes]

    # Response
    response_status: int
    response_headers: dict
    response_body: Optional[bytes]

    # 必填, 时间, 格式按照 iso format
    request_time: str
    response_time: str
    request_timestamp: float
    response_timestamp: float
    duration: float


def make_logging_middleware(
        callback: Callable[[LogInfo], Awaitable[None]],
        max_body_size: int = 1024,
):
    class LoggingMiddleware(BaseHTTPMiddleware):

        async def dispatch(self, request: Request, call_next):

            # ------------------------- request 时间 -------------------------
            req_ts = time.time()
            req_time_str = datetime.fromtimestamp(req_ts, tz=timezone.utc).isoformat()

            # ------------------------- 读取 request body -------------------------
            body_bytes: Optional[bytes] = await request.body()
            if body_bytes and len(body_bytes) > max_body_size:
                body_bytes = None

            # 支持 FastAPI 后续读取
            async def receive():
                return {
                    "type": "http.request",
                    "body": body_bytes or b"",
                    "more_body": False
                }
            request._receive = receive

            # ------------------------- 调用下游 -------------------------
            t0 = time.monotonic()
            response = await call_next(request)
            duration = round(time.monotonic() - t0, 6)

            # ------------------------- response 时间 -------------------------
            resp_ts = time.time()
            resp_time_str = datetime.fromtimestamp(resp_ts, tz=timezone.utc).isoformat()

            # ------------------------- 读取 response body -------------------------
            response_bytes = None
            if not isinstance(response, (StreamingResponse, FileResponse)):
                collected = b""
                async for chunk in response.body_iterator:
                    collected += chunk
                if len(collected) <= max_body_size:
                    response_bytes = collected

                # 重置 body_iterator
                async def new_iter():
                    yield collected
                response.body_iterator = new_iter()

            # ------------------------- 构建 LogInfo -------------------------
            client = f"{request.client.host}:{request.client.port}" if request.client else None

            info = LogInfo(
                client=client,
                method=request.method,
                url=str(request.url),
                scheme=request.url.scheme,
                host=request.url.hostname or "",
                port=request.url.port,
                path=request.url.path,
                query_string=request.url.query or "",
                http_version=request.scope.get("http_version", ""),

                request_headers=dict(request.headers),
                request_body=body_bytes,

                response_status=response.status_code,
                response_headers=dict(response.headers),
                response_body=response_bytes,

                request_time=req_time_str,
                response_time=resp_time_str,
                request_timestamp=req_ts,
                response_timestamp=resp_ts,
                duration=duration,
            )

            if callback:
                await callback(info)

            return response

    return LoggingMiddleware

