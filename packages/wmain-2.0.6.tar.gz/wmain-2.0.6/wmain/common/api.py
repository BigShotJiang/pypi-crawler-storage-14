import functools
import inspect
import re
import copy
from typing import TypeVar, ParamSpec, Callable, Awaitable, Union
import httpx
from wmain.util.web.url import Url

# 用于类型标注函数参数和返回值
P = ParamSpec("P")
R = TypeVar("R", bound=httpx.Response)


class Api:
    # 占位符正则，用于替换 URL 和请求体中的 {attr}
    PLACEHOLDER_PATTERN = re.compile(r"{(\w+)}")

    def __init__(self,
                 base_url: str = None,
                 client: httpx.Client = None,
                 async_client: httpx.AsyncClient = None,
                 headers: dict = None,
                 params: dict = None,
                 json: dict = None,
                 data: dict = None,
                 timeout: int = None):
        """
        初始化 API 实例
        - base_url: API 基础 URL
        - client / async_client: 可自定义 httpx 同步/异步客户端
        - headers / params / json / data: 默认请求参数
        - timeout: 请求超时时间
        """
        self.base_url: Url = Url(base_url or "")
        self.headers: dict = headers or {}
        self.params: dict = params or {}
        self.json: dict = json or {}
        self.data: dict = data or {}
        self.timeout: int = timeout or None
        self.attrs: dict = {}  # 用于存放全局占位符值，例如 token
        self.client: httpx.Client = client or httpx.Client(base_url=base_url, headers=headers, timeout=timeout)
        self.async_client: httpx.AsyncClient = async_client or httpx.AsyncClient(
            base_url=base_url, headers=headers, timeout=timeout
        )

    def __setitem__(self, key, value):
        """可以用 c['token'] = 'xxx' 设置占位符"""
        self.attrs[key] = value

    def __getitem__(self, key):
        """获取占位符"""
        return self.attrs[key]

    def replace_placeholder(self, s: str, replace_dic: dict):
        """替换字符串中的 {attr} 占位符。
           如果整个字符串是单一占位符，则直接返回其值本身，不强制转 str。
        """
        matches = self.PLACEHOLDER_PATTERN.findall(s)

        if not matches:
            return s

        # 情况1：整个字符串就是一个占位符，比如 "{id}"
        if len(matches) == 1 and s.strip() == f"{{{matches[0]}}}":
            name = matches[0]
            if name not in replace_dic:
                raise ValueError(f"Missing value for placeholder '{name}'")
            value = replace_dic.get(name)
            return value  # 不转 str

        # 情况2：常规替换
        for name in matches:
            if name not in replace_dic:
                raise ValueError(f"Missing value for placeholder '{name}'")
            value = replace_dic.get(name)
            s = s.replace(f"{{{name}}}", str(value))

        return s

    def replace_placeholders(self, dic: dict, replace_dic: dict):
        """递归替换 dict 中所有字符串值中的占位符"""
        for k, v in dic.copy().items():
            if isinstance(v, dict):
                self.replace_placeholders(v, replace_dic)
            elif isinstance(v, str):
                dic[k] = self.replace_placeholder(v, replace_dic)
                if dic[k] is None:
                    dic.pop(k)

    def _prepare_request_kwargs(self, func, method, path_or_uri, headers, params, json_data, data, timeout,
                                args, kwargs):
        """
        核心方法：准备请求参数字典
        - 根据函数参数和全局 attrs 替换占位符
        - 返回可直接传给 httpx 客户端的方法参数
        """
        sig = inspect.signature(func)
        bound = sig.bind(self, *args, **kwargs)
        bound.apply_defaults()

        final_headers = copy.deepcopy({**self.headers, **(headers or {})})
        final_params = copy.deepcopy({**self.params, **(params or {})})
        final_json = copy.deepcopy({**self.json, **(json_data or {})})
        final_data = copy.deepcopy({**self.data, **(data or {})})

        # 用于占位符替换，优先函数参数，其次全局 attrs
        replace_dic = {**self.attrs, **bound.arguments}

        # 替换请求体、参数、头部中的占位符
        for dic in [final_headers, final_params, final_json, final_data]:
            self.replace_placeholders(dic, replace_dic)

        # 获取完整 url
        url = self.base_url.join(path_or_uri)

        kwargs_dict = {
            "url": self.replace_placeholder(str(url), replace_dic),
            "headers": final_headers,
            "params": final_params,
            "json": final_json if method.lower() in ["post", "put", "patch"] else None,
            "data": final_data if method.lower() in ["post", "put", "patch"] else None,
            "timeout": timeout or self.timeout
        }
        # 去掉值为 None 的项
        return {k: v for k, v in kwargs_dict.items() if v is not None}


def request(method: str,
            path_or_uri: str,
            headers=None,
            params=None,
            json=None,
            data=None,
            timeout=None,
            **httpx_kwargs):
    """
    通用装饰器
    - 支持同步函数和异步函数
    - 自动根据函数是否 async 决定使用 self.client 或 self.async_client
    """

    def decorator(func: Callable[P, Union[R, Awaitable[R]]]) -> Callable[P, Union[R, Awaitable[R]]]:
        is_async = inspect.iscoroutinefunction(func)

        # 异步包装器
        @functools.wraps(func)
        async def async_wrapper(self: Api, *args: P.args, **kwargs) -> R:
            req_kwargs = self._prepare_request_kwargs(func, method, path_or_uri,
                                                      headers, params, json, data, timeout, args, kwargs)
            client_method = getattr(self.async_client, method.lower())
            return await client_method(**{**req_kwargs, **httpx_kwargs})

        # 同步包装器
        @functools.wraps(func)
        def sync_wrapper(self: Api, *args: P.args, **kwargs) -> R:
            req_kwargs = self._prepare_request_kwargs(func, method, path_or_uri,
                                                      headers, params, json, data, timeout, args, kwargs)
            client_method = getattr(self.client, method.lower())
            return client_method(**{**req_kwargs, **httpx_kwargs})

        return async_wrapper if is_async else sync_wrapper

    return decorator
