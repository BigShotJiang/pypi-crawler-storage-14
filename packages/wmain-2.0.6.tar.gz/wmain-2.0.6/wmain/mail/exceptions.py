class MailException(Exception):
    """
    邮件发送异常。
    """
    pass
