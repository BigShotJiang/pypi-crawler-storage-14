from email.message import EmailMessage
from email.header import Header
from email.utils import formataddr, parseaddr
from typing import List


def build_email(from_addr_with_display: str, to_addrs: str | List[str], subject: str, body: str) -> EmailMessage:
    msg = EmailMessage()

    # 1. 解析 from_addr 字符串，提取显示名称和邮箱地址
    display_name, email_address = parseaddr(from_addr_with_display)

    # 2. 构造 From 头部：使用 Header 对中文显示名称进行 MIME 编码
    encoded_from_header = formataddr((str(Header(display_name, 'utf-8')), email_address))

    # 3. 设置邮件头部
    msg['From'] = encoded_from_header
    msg['To'] = ", ".join([to_addrs] if isinstance(to_addrs, str) else to_addrs)
    msg['Subject'] = subject

    # 4. 设置邮件内容
    msg.set_content(body, charset='utf-8')

    return msg