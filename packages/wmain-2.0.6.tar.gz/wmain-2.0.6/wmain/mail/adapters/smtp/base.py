from email.utils import parseaddr
from smtplib import SMTP_SSL
from typing import List

import aiosmtplib
from aiosmtplib import SMTPResponse

from wmain.mail.utils import build_email


class SmtpMailSender:
    """
    使用 SMTP 协议发送邮件的实现类。
    """

    def __init__(self, host: str, port: int, username: str, password: str) -> None:
        self.host = host
        self.port = port
        self.username = username
        self.password = password

    def send(self, from_addr: str, to_addrs: str | List[str], subject: str, body: str) -> dict[str, tuple[int, bytes]]:
        # 1. 调用 build_email (from_addr 仍为带显示名称的字符串)
        msg = build_email(from_addr, to_addrs, subject, body)

        # 2. 从 from_addr 字符串中解析出纯邮箱地址
        _, mail_from_address = parseaddr(from_addr)  # 提取 'notifications@terraria-server.de'

        with SMTP_SSL(self.host, self.port) as smtp:
            smtp.set_debuglevel(1)
            smtp.login(self.username, self.password)

            # 关键修改：显式指定发件地址 (MAIL FROM)
            # 这会覆盖 smtplib 自动提取的逻辑，确保使用纯 ASCII 地址
            return smtp.send_message(msg, from_addr=mail_from_address)

    async def async_send(self, from_addr: str, to_addrs: str | List[str], subject: str, body: str) -> \
            tuple[dict[str, SMTPResponse], str]:
        msg = build_email(from_addr, to_addrs, subject, body)

        async with aiosmtplib.SMTP(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                start_tls=True,
        ) as smtp:
            return await smtp.send_message(msg)


smtp = SmtpMailSender(host="202.61.233.212", port=465,
                      username="notifications@terraria-server.de",
                      password="notifyWYN123")

smtp.send(
    # 将完整的 '显示名称 <邮箱地址>' 字符串作为第一个参数
    # build_email 函数必须从中提取出 "notifications@terraria-server.de"
    # 作为 MAIL FROM 地址，并将 "泰拉瑞亚服务器" 编码进 From 头部。
    "泰拉瑞亚服务器 <notifications@terraria-server.de>",
    ["2259819653@qq.com", "heiwynhhh@gmail.com"],
    "hello",
    "验证码是203814"
)
