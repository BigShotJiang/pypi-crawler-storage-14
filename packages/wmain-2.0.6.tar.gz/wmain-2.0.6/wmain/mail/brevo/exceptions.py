from wmain.mail.exceptions import MailException


class BrevoNoCustomerException(MailException):
    """
    用户不存在
    """
    pass

