def work():
    print("Color Blink is Installed and Working!")