from .de_pixelation import reduce_image_size_argparse, reduce_image_size
from .image_to_excel_pixels import image_to_excel_argparse, image_to_excel_cell_by_cell
from .color_sheet_generator import blink_excel_cell, blink_excel_cell_argparse
from .test import work