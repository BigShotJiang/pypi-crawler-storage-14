# Color Blink

This is a  fun tool to play with excel and python.