# bfan

# Build
pip install --upgrade build
python -m build
# upload
pip install --upgrade twine
twine upload dist/*
A simple Python package that provides a command-line tool.

## Installation

```sh
pip install bfan

#Usage
bfan

