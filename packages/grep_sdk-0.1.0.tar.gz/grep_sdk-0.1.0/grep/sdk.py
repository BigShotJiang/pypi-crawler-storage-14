
from traceloop.sdk import Traceloop
from .otel import configure_otel_exporter


class Grep:
    """
    GREP Observability SDK
    A branded wrapper around OpenLLMetry (Traceloop) with custom backend routing.
    """

    @staticmethod
    def init(
        backend_endpoint: str = None,
        disable_batch: bool = False,
        **kwargs
    ):
        """
        Initialize GREP Observability for your application.

        Args:
            backend_endpoint (str): OTLP-compatible endpoint for your backend.
            disable_batch (bool): Disable OTEL batching for local debugging.
        """

        # Configure OpenTelemetry exporter to your backend
        if backend_endpoint:
            configure_otel_exporter(backend_endpoint)

        # Initialize OpenLLMetry (Traceloop) under the hood
        return Traceloop.init(disable_batch=disable_batch, **kwargs)
