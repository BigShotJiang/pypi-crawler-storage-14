from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry import trace


def configure_otel_exporter(endpoint: str):
    """
    Configures OpenTelemetry to export spans to your backend endpoint.

    Example endpoint:
      https://your-backend.com/v1/traces
    """

    provider = TracerProvider()

    exporter = OTLPSpanExporter(
        endpoint=endpoint,
    )

    processor = BatchSpanProcessor(exporter)

    provider.add_span_processor(processor)
    trace.set_tracer_provider(provider)
