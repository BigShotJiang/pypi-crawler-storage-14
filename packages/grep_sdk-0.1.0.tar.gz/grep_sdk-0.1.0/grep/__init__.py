# grep/__init__.py

from .sdk import Grep

__all__ = ["Grep"]
