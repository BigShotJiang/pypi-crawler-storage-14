# Example 1: Basic Message Sending

This example demonstrates how to send a basic message using Telegram Multi-Account Message Sender.

## Scenario

Send a welcome message to a new recipient using a single account.

## Steps

1. **Add an Account**:
   - Go to Accounts tab
   - Click "Add Account"
   - Enter phone number: `+1234567890`
   - Complete authorization

2. **Create a Template**:
   - Go to Templates tab
   - Click "Add Template"
   - Name: `Welcome Message`
   - Content: `Hello! Welcome to our service.`

3. **Add a Recipient**:
   - Go to Recipients tab
   - Click "Add Recipient"
   - Type: `USER`
   - Username: `@username`
   - Name: `John Doe`

4. **Test the Message**:
   - Go to Testing tab
   - Select the account
   - Select the recipient
   - Choose the template
   - Click "Send Test Message"

5. **Create a Campaign**:
   - Go to Campaigns tab
   - Click "Create Campaign"
   - Name: `Welcome Campaign`
   - Select template
   - Select recipient
   - Click "Start Campaign"

## Result

The message "Hello! Welcome to our service." will be sent to the recipient using the selected account.

## Next Steps

- See [Example 2](example-02.md) for advanced usage
- Read [Usage Guide](../usage.md) for more details

