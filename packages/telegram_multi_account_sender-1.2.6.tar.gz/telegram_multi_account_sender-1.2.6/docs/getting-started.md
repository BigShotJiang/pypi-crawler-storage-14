# Getting Started

Welcome to Telegram Multi-Account Message Sender! This guide will help you get started with the application.

## Prerequisites

- Python 3.10 or higher
- Internet connection
- Telegram API credentials (API ID and API Hash)

## Installation

See the [Installation Guide](installation.md) for detailed installation instructions.

## Quick Setup

1. **Install the application**:
   ```bash
   pip install telegram-multi-account-sender
   ```

2. **Get Telegram API credentials**:
   - Visit [my.telegram.org](https://my.telegram.org)
   - Log in with your phone number
   - Go to "API development tools"
   - Create a new application
   - Copy your API ID and API Hash

3. **Launch the application**:
   ```bash
   python main.py
   ```
   Or if installed via pip:
   ```bash
   python -m app.cli
   ```

4. **Configure settings**:
   - Open the Settings tab
   - Enter your API credentials
   - Set your preferred theme and language
   - Save settings

5. **Add your first account**:
   - Go to the Accounts tab
   - Click "Add Account"
   - Enter your phone number
   - Complete the authorization process

## Next Steps

- Read the [Usage Guide](usage.md) to learn how to use the application
- Check out [Examples](examples/example-01.md) for practical examples
- Review the [FAQ](faq.md) for common questions
- See [Troubleshooting](troubleshooting.md) if you encounter issues

## Need Help?

- Check the [FAQ](faq.md)
- Review [Troubleshooting](troubleshooting.md)
- Visit [Support](../SUPPORT.md) for additional help

