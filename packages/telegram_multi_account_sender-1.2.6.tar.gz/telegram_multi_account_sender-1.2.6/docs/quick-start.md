# Quick Start Guide

Get up and running with Telegram Multi-Account Message Sender in minutes!

## Installation

```bash
pip install telegram-multi-account-sender
```

## Basic Usage

1. **Start the application**:
   ```bash
   python main.py
   ```

2. **Add an account**:
   - Go to Accounts tab
   - Click "Add Account"
   - Enter phone number and authorize

3. **Create a template**:
   - Go to Templates tab
   - Click "Add Template"
   - Enter your message

4. **Add recipients**:
   - Go to Recipients tab
   - Click "Add Recipient"
   - Enter recipient information

5. **Create a campaign**:
   - Go to Campaigns tab
   - Click "Create Campaign"
   - Select template and recipients
   - Start the campaign

## Example: Send a Test Message

1. Go to the Testing tab
2. Select an account
3. Select a recipient
4. Choose or enter a message
5. Click "Send Test Message"

## Next Steps

- See [Getting Started](getting-started.md) for detailed setup
- Read [Usage Guide](usage.md) for comprehensive usage
- Check [Examples](examples/example-01.md) for more examples

