"""
CyMeta Training Utilities.

Utilities for joint training of meta-dictionaries, index maps, and gating networks,
including knowledge distillation from full-precision teacher models.
"""

from cymeta.training.compressor import CyMetaCompressor
from cymeta.training.trainer import CyMetaTrainer
from cymeta.training.distillation import KnowledgeDistillation

__all__ = [
    "CyMetaCompressor",
    "CyMetaTrainer",
    "KnowledgeDistillation",
]

