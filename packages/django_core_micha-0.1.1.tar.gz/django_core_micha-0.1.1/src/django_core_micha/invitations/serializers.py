from rest_framework import serializers


class InviteUserSerializer(serializers.Serializer):
    """Simple serializer holding the invite target email address."""
    email = serializers.EmailField()
