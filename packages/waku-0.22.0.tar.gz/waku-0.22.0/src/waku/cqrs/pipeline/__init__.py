from waku.cqrs.pipeline.chain import PipelineBehaviorWrapper

__all__ = [
    'PipelineBehaviorWrapper',
]
