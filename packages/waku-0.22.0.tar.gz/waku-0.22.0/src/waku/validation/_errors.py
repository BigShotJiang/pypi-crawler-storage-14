from waku.exceptions import WakuError

__all__ = ['ValidationError']


class ValidationError(WakuError):
    pass
