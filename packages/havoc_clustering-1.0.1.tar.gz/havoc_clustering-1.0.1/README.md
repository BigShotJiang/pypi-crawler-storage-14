# Histomic Atlases of Variation Of Cancers (HAVOC)

HAVOC is a versatile tool that maps histomic heterogeneity across H&E-stained digital slide images to help guide regional deployment of molecular resources to the most relevant/biodiverse tumor niches

## Cloud usage
Explore HAVOC on https://www.codido.co to run on the cloud

## Version Notes

- **v1.x** (current): Uses a foundation-model feature extractor ([Prov-GigaPath](https://huggingface.co/prov-gigapath/prov-gigapath)) with adaptive grid sampling for large tiles. This is recommended for all new applications.

- **v0.x** (legacy): VGG19-based implementation used in the original paper.
  Still available on PyPI for reproducibility.

**Note:** The v0.x implementation will not receive new features.

## Installation (v1.x)

> **Note:** HAVOC requires the **torch**, **torchvision**, and **timm** packages, which are not installed automatically. Please install the appropriate PyTorch build (CPU or GPU) *before* installing HAVOC.

> **Note:** System-level OpenSlide must be installed manually from: https://openslide.org/download/
> 
> 

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install havoc-clustering.

```bash
pip install havoc-clustering
```

## Usage (v1.x)


```python
from huggingface_hub import login
from havoc_clustering.havoc import HAVOC, HAVOCConfig
from havoc_clustering.general_utility.slide import Slide

# Required to perform initial download of the feature extractor (prov-gigapath) from Huggingface.
login(token=hf_token)

# To run HAVOC, it requires:
# 1. a Slide object
s = Slide(slide_path)

# 2. a HAVOCConfig object
# Below are the default config values
config = HAVOCConfig(
    out_dir='./', # root save dir. results will be stored per slide in `root_save_dir`\<slide_name>\`
    k_vals=[7, 8, 9],
    # save the tiles belonging to each color cluster within the havoc map for a given k
    # ie [7,9] would save the colored tiles belonging to k=7 and k=9
    # NOTE: this should be a subset of k_vals
    save_tiles_k_vals=[], 

    tile_size=512,
    desired_tile_mpp=0.504,
    safe_mpp=False,

    min_tissue_amt=0.5, # blank filtering
    
    # for each k value, make a tsne and/or dendrogram and/or pearson coefficient clustermap
    extra_metrics=['tsne', 'dendrogram', 'corr_clustmap']
)
    

havoc = HAVOC(config)
havoc.run(s)
```


## Installation (v0.x)

> **Note:** HAVOC requires the **tensorflow** package, which is not installed automatically.

> **Note:** System-level OpenSlide must be installed manually from: https://openslide.org/download/
> 
> 

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install havoc-clustering.

```bash
pip install havoc-clustering==0.*
```

## Usage (v0.x)

```python
from havoc_clustering.havoc import HAVOC
from havoc_clustering.general_utility.slide import Slide

# create a new Slide object that represents the image.
# Requirements allow to filter out undesired images within ie a loop
s = Slide(
    slide_path,
    img_requirements={
        'compression': [70],
        'mpp': None  # all mpp values (magnification) are supported currently
    }
)

# to instantiate a HAVOC instance requires the following:
# 1. a Slide object
# 2. the directory to save output to
# 3. size of the tiles to extract and work with within the slide.
# 4. by default, we use the slide's resized thumbnail as the background for the colortile map. turn off to make it HD at the expense of time
havoc = HAVOC(s, save_dir, tile_size=512, hd_backdrop=False)

# to run, requires the following:
# 1. the k values to use for clustering
# 2. the blank filter cutoff. 0.5 means that there must be less than (100-50=50)% blank within a tile to decide to use it.
    # ie tiles that are >50% blank would be skipped; a non-conservative number to only cluster tiles with plentiful tissue
# 3. the layer name within the feature extractor model that is responsible for generating the features
# 4. Additional kwargs; OPTIONAL
kwargs = {
    # saves a thumbnail image of the original slide
    'save_thumbnail': False,
    # make a dendrogram of the clustering used to make the colortile maps (generated for each k value)
    'make_dendrogram': True,
    # make a tsne of each color cluster (generated for each k value)
    'make_tsne': True,
    # make a Pearson coeffcient clustermap of each color cluster (generated for each k value)
    'make_corr_map': True,
    # save the tiles belonging to each color cluster within the colortile map for a given k
    # ie [4,9] would save the colored tiles belonging to k=4 and k=9
    # NOTE: this should be a subset of k_vals
    'save_tiles_k_vals': []
}
havoc.run(k_vals=[9], min_non_blank_amt=0.5, layer_name='global_average_pooling2d_1', **kwargs)
```

## Result output
- Colortiled maps
- CSV file of cluster info + DLFVs (cluster_info_df.csv)
- Optionally:
    - Original slide thumbnail
    - TSNEs
    - Dendrograms
    - Correlation clustermap

## Multi-slide correlation map

By running HAVOC on multiple slides, you may want to combine all the generated correlation clustermaps into a mega clustermap.

1. Create a folder containing each slide's cluster_info_df.csv file
2. 
```python
from havoc_clustering.correlation_of_dlfv_groups import create_correlation_clustermap_multi_slide

create_correlation_clustermap_multi_slide(folder_of_csvs, target_k=9)
```

NOTE: the target_k should be a k-value you ran HAVOC with 

## Citation

Please refer to the paper "HAVOC: Small-scale histomic mapping of cancer biodiversity across large tissue distances using deep neural networks" (DOI: [10.1126/sciadv.adg1894](https://doi.org/10.1126/sciadv.adg1894))

## License
[GNU General Public License v3 (GPLv3)](https://www.gnu.org/licenses/gpl-3.0.txt)
