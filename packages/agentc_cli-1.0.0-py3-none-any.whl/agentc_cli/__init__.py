from .main import main as main

# DO NOT edit this value, the plugin "poetry-dynamic-versioning" will automatically set this.
__version__ = "1.0.0"
