from pathlib import Path

RESOURCES_DIR = Path(__file__).parent.parent.parent / "resources"
