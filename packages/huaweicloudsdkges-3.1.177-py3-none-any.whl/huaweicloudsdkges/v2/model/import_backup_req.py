# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ImportBackupReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'import_path': 'str'
    }

    attribute_map = {
        'import_path': 'import_path'
    }

    def __init__(self, import_path=None):
        r"""ImportBackupReq

        The model defined in huaweicloud sdk

        :param import_path: 备份文件路径
        :type import_path: str
        """
        
        

        self._import_path = None
        self.discriminator = None

        self.import_path = import_path

    @property
    def import_path(self):
        r"""Gets the import_path of this ImportBackupReq.

        备份文件路径

        :return: The import_path of this ImportBackupReq.
        :rtype: str
        """
        return self._import_path

    @import_path.setter
    def import_path(self, import_path):
        r"""Sets the import_path of this ImportBackupReq.

        备份文件路径

        :param import_path: The import_path of this ImportBackupReq.
        :type import_path: str
        """
        self._import_path = import_path

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ImportBackupReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
