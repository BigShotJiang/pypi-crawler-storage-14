"""Modules/Feature Flags API routes."""

from apex.api.v1.modules.router import router

__all__ = ["router"]

