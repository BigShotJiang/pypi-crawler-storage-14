# Copyright (C) 2023 - 2025 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
"""Module containing the model tools service implementation (abstraction layer)."""

from abc import ABC, abstractmethod

import grpc


class GRPCModelToolsService(ABC):  # pragma: no cover
    """Model tools service for gRPC communication with the Geometry server.

    Parameters
    ----------
    channel : grpc.Channel
        The gRPC channel to the server.
    """

    def __init__(self, channel: grpc.Channel):
        """Initialize the GRPCModelToolsService class."""
        pass

    @abstractmethod
    def chamfer(self, **kwargs) -> dict:
        """Create a chamfer on the specified edges of a body."""
        pass

    @abstractmethod
    def fillet(self, **kwargs) -> dict:
        """Create a fillet on the specified edges of a body."""
        pass

    @abstractmethod
    def full_fillet(self, **kwargs) -> dict:
        """Create a full fillet on the specified edges of a body."""
        pass

    @abstractmethod
    def move_rotate(self, **kwargs) -> dict:
        """Rotate the specified entities."""
        pass

    @abstractmethod
    def move_translate(self, **kwargs) -> dict:
        """Translate the specified entities."""
        pass

    @abstractmethod
    def create_sketch_line(self, **kwargs) -> dict:
        """Create a sketch line in the design."""
        pass
