
__version__ = '0.4.4'

def version() -> str:
    """Returns the version of the bookchain package."""
    return __version__
