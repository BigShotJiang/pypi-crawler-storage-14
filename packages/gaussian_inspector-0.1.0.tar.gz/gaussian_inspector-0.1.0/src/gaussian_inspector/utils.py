import importlib.metadata
import os
import sys
from typing import Any, Dict

import numpy as np
from rich.console import Console

from gaussian_inspector.const import STUBS_FOLDER_NAME, VIEWER_SNAKE_NAME
from gaussian_inspector.stubs.dockerfile import template as docker_template


def validate_config(config: Dict, console: Console) -> Dict:
    if "time_range" not in config:
        console.print(
            f"Please define 'time_range' in the user context ({VIEWER_SNAKE_NAME}/configuration.py)",
            style="bold red",
        )
        raise KeyError("'time_range' not defined in user context")
    else:
        time_range = config["time_range"]
        assert (
            isinstance(time_range, tuple)
            and len(time_range) == 2
            and all(isinstance(t, float) for t in time_range)
            and time_range[0] < time_range[1]
        ), (
            "'time_range' must be a tuple of two floats (start_time, end_time) with start_time < end_time"
        )
    return config


def validate_camera(camera: Any) -> Any:
    assert hasattr(camera, "R"), "Camera object must have rotation attribute 'R'"
    assert hasattr(camera, "T"), "Camera object must have translation attribute 'T'"
    return camera


def validate_render_frame(frame: np.ndarray) -> np.ndarray:
    assert isinstance(frame, np.ndarray), "Rendered frame must be a numpy array"
    assert len(frame.shape) == 3 and frame.shape[2] == 3, (
        "Rendered frame must have shape (H, W, 3)"
    )
    assert frame.dtype == np.uint8, "Rendered frame must have dtype uint8"
    return frame


def make_dockerfile(build_submodules: Dict[str, str]) -> str:
    custom_docker_file = docker_template.replace(
        "{{COPY_OPS}}",
        "\n".join(
            [f"COPY {path} ./{os.path.basename(path)}" for path in build_submodules]
        ),
    )
    custom_docker_file = custom_docker_file.replace(
        "{{RUN_OPS}}",
        "\n".join(
            [f"RUN pip install ./{os.path.basename(path)}" for path in build_submodules]
        )
        + "\n"
        + "\n".join(
            [f"RUN rm -rf ./{os.path.basename(path)}" for path in build_submodules]
        ),
    )
    custom_docker_file = custom_docker_file.replace(
        "{{VIEWER_SNAKE_NAME}}", VIEWER_SNAKE_NAME
    )
    custom_docker_file = custom_docker_file.replace(
        "{{STUBS_FOLDER_NAME}}", STUBS_FOLDER_NAME
    )
    dbg_pip_package = os.environ.get("DBG_PIP_PACKAGE", None)
    if dbg_pip_package:
        custom_docker_file = custom_docker_file.replace(
            "{{PIP_PACKAGE_INSTALL}}",
            f"COPY {dbg_pip_package} ./max_viewer_pip_pkg\nRUN pip install ./max_viewer_pip_pkg",
        )
    else:
        try:
            package_version = importlib.metadata.version(VIEWER_SNAKE_NAME)
        except importlib.metadata.PackageNotFoundError:
            package_version = "latest"
        custom_docker_file = custom_docker_file.replace(
            "{{PIP_PACKAGE_INSTALL}}",
            f"RUN pip install {VIEWER_SNAKE_NAME}=={package_version}",
        )

    return custom_docker_file


def find_viewer_file_by_introspection() -> str:
    for path in reversed(sys.path):
        for root, _, files in os.walk(path):
            if "viewer.py" in files:
                return os.path.join(root, "viewer.py")
    raise FileNotFoundError("Could not find viewer.py in sys.path")
