template = """\
# syntax=docker/dockerfile:1
FROM nvcr.io/nvidia/cuda:12.4.1-cudnn-devel-ubuntu22.04
RUN apt update && apt install -y python3 python3-pip ffmpeg libsm6 libxext6
RUN apt update && apt install -y git cmake ninja-build build-essential \
			libboost-program-options-dev libboost-graph-dev \
			libboost-system-dev libeigen3-dev libflann-dev \
			libfreeimage-dev libmetis-dev libgoogle-glog-dev \
			libgtest-dev libgmock-dev libsqlite3-dev libglew-dev \
			qtbase5-dev libqt5opengl5-dev libcgal-dev libceres-dev \
                        libxrandr-dev libxinerama-dev libxcursor-dev libxi-dev \
                        libglfw3-dev

ENV TORCH_CUDA_ARCH_LIST="7.0;8.0;8.6;8.9;9.0"
RUN ln -s /usr/bin/python3 /usr/bin/python

WORKDIR /tmp/
COPY ./{{STUBS_FOLDER_NAME}}/requirements.txt ./requirements.txt
RUN pip install setuptools cython wheel
RUN pip install moderngl-window moderngl-window[imgui] moderngl \
                redis numpy omegaconf pyrr rich imagesize 

RUN git clone --branch v1.6.3 --depth 1 --recursive https://github.com/pthom/imgui_bundle
WORKDIR imgui_bundle
RUN cmake -B build -DIMGUI_BUNDLE_BUILD_GLFW_OPENGL2=OFF -DIMGUI_BUNDLE_BUILD_GLFW_OPENGL3=ON -DHELLOIMGUI_DOWNLOAD_FREETYPE_IF_NEEDED=ON.
RUN cmake --build build -j$(nproc)
RUN pip install .
WORKDIR ..

RUN pip install -r requirements.txt

{{COPY_OPS}}
{{RUN_OPS}}

RUN git clone -b 3.11.1 https://github.com/colmap/colmap.git
WORKDIR  colmap
RUN  mkdir build
WORKDIR build
# RUN  compute_cap=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader | tr -d '.')
RUN  cmake .. -GNinja -DCMAKE_CUDA_ARCHITECTURES=89
RUN  ninja
RUN  ninja install


WORKDIR /home/
ENV DEB_PYTHON_INSTALL_LAYOUT=deb_system
{{PIP_PACKAGE_INSTALL}}
"""

custom_builds = [
    "./diff-gaussian-rasterization",
    "./simple-knn",
    "./pointops2",
]
