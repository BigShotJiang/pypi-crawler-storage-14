import inspect
from typing import Any, Dict


def get_viewpoint_camera(user_context: Dict[str, Any]) -> Any:
    """
    Return the default viewpoint camera for the scene. This camera will be used as
    initialization for camera controls. It must be a valid camera object compatible with
    the rasterizer of your project.

    Args:
    user_context (Dict[str, Any]): The user context returned by the configure()
        function in configuration.py. This user context may store the Scene object or
        whatever you  need to fetch or create the initial camera.
    """
    raise NotImplementedError("Viewpoint camera function not implemented yet.")


def hook_viewpoint_camera(camera: Any, user_context: Dict[str, Any]) -> Any:
    """
    Hook to modify the default viewpoint camera before using it in the viewer. This
    function is called right after get_viewpoint_camera() and before passing the camera
    to the viewer. Mainly, we need the camera object to have a set_rt(R, T) method that
    allows updating the camera pose from the viewer.
    Args:
    camera (Any): The default viewpoint camera returned by get_viewpoint_camera().
    user_context (Dict[str, Any]): The user context returned by the configure()
        function in configuration.py. This user context may store the Scene object or
        whatever you need to modify the camera.
    """
    # NOTE: Here's a default implementation that should work for many projects based on
    # the original 3DGS implementation:
    code = """def set_rt(self, R, T, trans=np.array([0.0, 0.0, 0.0])):
        self.world_view_transform = (
            torch.tensor(getWorld2View2(R, T, self.trans + trans, self.scale))
            .transpose(0, 1)
            .cuda()
        )
        self.full_proj_transform = (
            (
                self.world_view_transform.unsqueeze(0).bmm(
                    self.projection_matrix.unsqueeze(0)
                )
            )
            .squeeze(0)
            .cuda()
        )
        self.camera_center = self.world_view_transform.inverse()[3, :3].cuda()
        """
    cam_module = inspect.getmodule(camera)
    exec_namespace = vars(cam_module)
    eval(code, exec_namespace)
    setattr(
        camera, "set_tr", lambda *args, **kwargs: exec_namespace["set_rt"](args, kwargs)
    )
