import inspect
import os
from typing import List

import docker
import typer
import yaml
from rich.console import Console
from rich.panel import Panel
from typing_extensions import Annotated

from gaussian_inspector import stubs
from gaussian_inspector.const import STUBS_FOLDER_NAME, VIEWER_SNAKE_NAME
from gaussian_inspector.utils import make_dockerfile

app = typer.Typer()
console = Console()

from rich.traceback import install


@app.command()
def init(
    force: Annotated[
        bool, typer.Option("--force", help="Overwrite existing stubs.")
    ] = False,
):
    f"""Initialize the {VIEWER_SNAKE_NAME.title()} viewer stubs in the current directory."""
    if os.path.exists(STUBS_FOLDER_NAME) and not force:
        console.print(
            f"The directory ./{STUBS_FOLDER_NAME}/ already exists. Aborting.",
            style="bold red",
        )
        console.print(
            "Run this command with --force to overwrite.", style="italic yellow"
        )
        raise typer.Exit(code=1)
    console.print("Creating viewer stubs...", style="green on black")
    os.makedirs(STUBS_FOLDER_NAME, exist_ok=True)
    os.makedirs(os.path.join(STUBS_FOLDER_NAME, ".tmp"), exist_ok=True)
    with open(f"{STUBS_FOLDER_NAME}/build_submodules.yaml", "w") as f:
        yaml.dump(stubs.dockerfile.custom_builds, f)
    with open(f"{STUBS_FOLDER_NAME}/configuration.py", "w") as f:
        f.write(inspect.getsource(stubs.configuration))
    with open(f"{STUBS_FOLDER_NAME}/camera.py", "w") as f:
        f.write(inspect.getsource(stubs.camera))
    with open(f"{STUBS_FOLDER_NAME}/rendering.py", "w") as f:
        f.write(inspect.getsource(stubs.rendering))
    with open(f"{STUBS_FOLDER_NAME}/requirements.txt", "w") as f:
        f.write("# Add your Python dependencies here\n")
    console.print(
        f"Stubs created in ./{STUBS_FOLDER_NAME}/ directory.\n"
        + "Please implement each of them according to the documentation.",
        style="bold green",
    )


@app.command()
def build(
    verbose: Annotated[bool, typer.Option("-v", help="Print build logs.")] = False,
):
    f"""Build the Docker image for the {VIEWER_SNAKE_NAME.title()} application."""
    tag_name = f"{VIEWER_SNAKE_NAME}/{os.path.basename(os.getcwd())}"
    with console.status(
        f"Building the Docker image [bold green]{tag_name}[/bold green]...",
        spinner="pong",
    ):
        with open(f"{STUBS_FOLDER_NAME}/.tmp/Dockerfile", "w") as f:
            with open(f"{STUBS_FOLDER_NAME}/build_submodules.yaml", "r") as sf:
                build_submodules_dict = yaml.safe_load(sf)
            f.write(make_dockerfile(build_submodules_dict))
        install(suppress=[docker])
        docker_client = docker.from_env()

        try:
            _, logs = docker_client.images.build(
                path=".",
                dockerfile=os.path.join(STUBS_FOLDER_NAME, ".tmp", "Dockerfile"),
                tag=tag_name,
                rm=True,
                forcerm=True,
                # buildargs=docker_template_args,
                shmsize=16_000_000_000,  # 16 GB
            )
            if verbose:
                iterable = iter(logs)
                steps = []
                for it in iterable:
                    if isinstance(it, dict) and "stream" in it:
                        steps.append(it["stream"])
                    else:
                        steps.append(str(it))
                console.print(Panel.fit("".join(steps), title="Docker Build Log"))
            console.print(
                Panel.fit(
                    f"Docker image [bold green]{tag_name}[/bold green] built successfully!",
                    title="Docker Build Success",
                )
            )
        except docker.errors.BuildError as buildError:
            iterable = iter(buildError.build_log)
            steps = []
            while True:
                try:
                    item = next(iterable)
                    if "errorDetail" in item:
                        steps.append(
                            f"[bold red]ERROR:[/bold red] {item['errorDetail']['message']}\n"
                        )
                    else:
                        steps.append(item["stream"] if "stream" in item else str(item))
                except StopIteration:
                    break
            console.print(Panel.fit("".join(steps), title="Docker Build Log"))
            raise buildError
        except Exception as error:
            raise error


@app.command(
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def launch_with_docker(
    mount_volumes: Annotated[
        List[str],
        typer.Option(
            "--mount",
            "-m",
            help="Additional volumes to mount in the Docker container (format: host_path:container_path).",
        ),
    ] = [],
    extra_args: List[str] = typer.Argument(
        None, help="Additional arguments to pass to the configuration stub."
    ),
):
    f"""Launch the {VIEWER_SNAKE_NAME.title()} application inside the custom Docker image."""
    tag_name = f"{VIEWER_SNAKE_NAME}/{os.path.basename(os.getcwd())}"
    console.print(f"Running the Docker image [bold green]{tag_name}[/bold green]...")
    install(suppress=[docker])
    docker_client = docker.from_env()
    try:
        if extra_args is None:
            extra_args = []

        user_mounts = []
        for volume in mount_volumes:
            user_mounts.append(
                docker.types.Mount(
                    target=volume.split(":")[1],
                    source=volume.split(":")[0],
                    type="bind",
                )
            )
        logs = docker_client.containers.run(
            tag_name,
            command="gaussian-inspector launch " + " ".join(extra_args),
            mounts=[
                docker.types.Mount(target="/home/", source=os.getcwd(), type="bind")
            ]
            + user_mounts,
            runtime="nvidia",
            environment=["DISPLAY=:0"],
            privileged=True,
            shm_size=16_000_000_000,  # 16 GB
            volumes=[
                "/tmp/.X11-unix:/tmp/.X11-unix",  # To enable GUI
            ],
        )
        print(logs)
    except docker.errors.ContainerError as containerError:
        console.print(
            Panel.fit(
                containerError.container.logs().decode("utf-8"),
                title="Docker Container Log",
            )
        )
        docker_client.containers.prune()
        raise containerError


@app.command(
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def launch(
    extra_args: List[str] = typer.Argument(
        None, help="Additional arguments to pass to the configuration stub."
    ),
):
    f"""Launch the {VIEWER_SNAKE_NAME.title()} application inside the current environment."""
    console.print(f"Launching the {VIEWER_SNAKE_NAME.title()} application...")

    import moderngl_window as mglw

    from gaussian_inspector.viewer import RadianceView

    window_cls = mglw.get_local_window_cls("glfw")  # or 'glfw', 'sdl2'
    window = window_cls(
        title="Radiance View",
        size=RadianceView.window_size,
        fullscreen=False,
        resizable=True,
        gl_version=(3, 3),
        vsync=True,
    )
    instance = RadianceView(extra_args, ctx=window.ctx, wnd=window)
    window.config = instance
    mglw.run_window_config_instance(instance)


if __name__ == "__main__":
    app()
