import enum
import math
import os
import sys
import time
from collections import defaultdict
from dataclasses import dataclass
from typing import Optional

import moderngl
import moderngl_window as mglw
import numpy as np
import redis
import torch
from imgui_bundle import hello_imgui, imgui, implot
from moderngl_window.integrations.imgui_bundle import ModernglWindowRenderer
from pyrr import Matrix44, Quaternion, Vector3
from rich.console import Console

from gaussian_inspector.utils import validate_camera, validate_config

console = Console()

from gaussian_inspector.const import STUBS_FOLDER_NAME

try:
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)
    # from max_viewer_stubs import configuration as viewer_config
    exec(f"from {STUBS_FOLDER_NAME} import configuration as viewer_config", globals())
    exec(f"from {STUBS_FOLDER_NAME} import camera as viewer_camera", globals())
    exec(f"from {STUBS_FOLDER_NAME} import rendering as viewer_rendering", globals())
    if os.getcwd() in sys.path:
        del sys.path[sys.path.index(os.getcwd())]
except ImportError as e:
    console.print(
        "Please run 'viewer init' to create the viewer stubs. You must then implement them.",
        style="bold red",
    )
    raise e


def rotmat(a, b):
    a, b = a / np.linalg.norm(a), b / np.linalg.norm(b)
    v = np.cross(a, b)
    c = np.dot(a, b)
    s = np.linalg.norm(v)
    kmat = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + kmat + kmat.dot(kmat) * ((1 - c) / (s**2 + 1e-10))


class Controller(enum.Enum):
    KEYBOARD_MOUSE = enum.auto()
    SLAM = enum.auto()
    ORBIT = enum.auto()


@dataclass
class HistData:
    data: np.ndarray = np.zeros(1000, dtype=np.float32)
    mean: float = 0.0
    std: float = 0.0
    min: float = 0.0
    max: float = 0.0
    hist_flags = implot.HistogramFlags_.density


class RadianceView(mglw.WindowConfig):
    gl_version = (3, 3)
    title = "RadianceViewer"
    window_size = (1352, 1014)
    aspect_ratio = None
    resizable = True

    def __init__(self, sys_argv, **kwargs):
        super().__init__(**kwargs)

        assert (
            "viewer_config" in globals()
            and "viewer_camera" in globals()
            and "viewer_rendering" in globals()
        ), "stub imports failed"

        self.width, self.height = self.window_size

        self.user_context = validate_config(viewer_config.configure(sys_argv), console)
        self.viewpoint_cam = validate_camera(
            viewer_camera.get_viewpoint_camera(self.user_context)
        )
        viewer_camera.hook_viewpoint_camera(self.viewpoint_cam, self.user_context)
        self.time_range = self.user_context["time_range"]
        self.scene_bounds = self.user_context["scene_bounds"]

        try:
            self.redis_server = redis.Redis(host="redis", port=6379, db=0)
            self.redis_sub = self.redis_server.pubsub()
            self.redis_sub.subscribe("orbSlam_Pose")
        except redis.ConnectionError as e:
            console.print("Redis connection error:", e, style="bold red")
        time.sleep(0.1)
        self.redis_sub.get_message()
        self.controller_choice = Controller.ORBIT
        self.panning_dir = 1

        # ======= Controls
        R, t = self.viewpoint_cam.R, self.viewpoint_cam.T
        self.right = R[:, 0]
        self.up = R[:, 1]
        self.forward = R[:, 2]
        self.R_init = R.copy()
        self.canonical_pose = np.eye(4, dtype=np.float32)
        self.canonical_pose[:3, :3] = R
        self.canonical_pose[:3, 3] = t.squeeze()
        # Initialize position and orientation from given R, t
        self.position = Vector3(t.squeeze())
        # Extract yaw/pitch from rotation matrix
        self.yaw = 0.0
        self.pitch = 0.0
        # self.yaw = np.arctan2(R[1, 2], R[2, 2])
        # self.pitch = np.arcsin(-R[2, 2])
        self.slam_alignement = None
        self.slam_pose = np.eye(4, dtype=np.float32)
        self.slam_pose_init = None
        self.slam_trans_app = None
        self.R_slam = None
        self.slam_pose_prev = None
        self.paused = False
        # self.canonical_t = t
        self.speed = 0.1
        self.sensitivity = 0.005
        self.keys = set()
        self.time_speed = 1
        self.scaling_factor = 5
        self.release_action_keys = [
            self.wnd.keys.SPACE,
            self.wnd.keys.NUMBER_0,
            self.wnd.keys.NUMBER_1,
            self.wnd.keys.NUMBER_2,
            self.wnd.keys.NUMBER_3,
            self.wnd.keys.NUMBER_4,
            self.wnd.keys.NUMBER_5,
            self.wnd.keys.NUMBER_9,
        ]

        ######## GUI and plotting ############
        self.collection_stream = torch.cuda.Stream()
        self.dof_filter_id = 0
        self.p_sigma_range = [0.0, 10]
        self.opa_sigma_range = [0.0, 5.0]
        self.vel_norm_range = [0.0, 1.0]
        self.enable_max_op_sigma = False
        self.enable_max_vel_sigma = False
        self.enable_max_vel_norm = False
        self.plot_data = {}
        # self.reset_plot_data()
        imgui.create_context()
        implot.create_context()
        self.wnd.ctx.error
        self.imgui = ModernglWindowRenderer(self.wnd)
        ##################################
        # Fullscreen quad
        vertices = np.array(
            [
                -1.0,
                -1.0,
                0.0,
                0.0,
                1.0,
                -1.0,
                1.0,
                0.0,
                -1.0,
                1.0,
                0.0,
                1.0,
                1.0,
                1.0,
                1.0,
                1.0,
            ],
            dtype="f4",
        )
        self.vbo = self.ctx.buffer(vertices.tobytes())
        self.vao = self.ctx.simple_vertex_array(
            self.create_shader(), self.vbo, "in_pos", "in_uv"
        )
        # Texture
        self.texture = self.ctx.texture((self.width, self.height), 3)
        self.texture.filter = (moderngl.NEAREST, moderngl.NEAREST)
        # PBO for async upload
        self.pbo = self.ctx.buffer(reserve=self.width * self.height * 3)
        self.pbo.orphan()  # hint that data will be frequently updated
        self._frames, self._export_n_frames = [], 500
        self._export_vid = False

    def reset_plot_data(self):
        self.plot_data = {
            "hist": {
                "temporal_mean_histograms": defaultdict(HistData),
                "temporal_spread_histograms": defaultdict(HistData),
                "velocity_histograms": defaultdict(HistData),
            },
            "hist_config": {"n_bins": 1000},
            "active_guassians": self.gaussians.xyz.shape[0],
            "temporal_func": {},
        }

    def create_shader(self):
        return self.ctx.program(
            vertex_shader="""
                #version 330
                in vec2 in_pos;
                in vec2 in_uv;
                out vec2 v_uv;
                void main() {
                    gl_Position = vec4(in_pos, 0.0, 1.0);
                    v_uv = vec2(in_uv.x, 1.0 - in_uv.y);  // flip vertically
                    //v_uv = in_uv;
                }
            """,
            fragment_shader="""
                #version 330
                uniform sampler2D tex;
                in vec2 v_uv;
                out vec4 f_color;
                void main() {
                    f_color = texture(tex, v_uv);
                }
            """,
        )

    # --- Mouse drag handler ---
    def on_mouse_position_event(self, x, y, dx, dy):
        self.imgui.mouse_position_event(x, y, dx, dy)

    def on_mouse_drag_event(self, x, y, dx, dy):
        if (
            self.controller_choice == Controller.KEYBOARD_MOUSE
            and not imgui.get_io().want_capture_mouse
        ):
            self.yaw += dx * self.sensitivity
            self.pitch += dy * self.sensitivity
        # self.pitch = np.clip(self.pitch, -np.pi / 2 + 1e-3, np.pi / 2 - 1e-3)
        self.imgui.mouse_drag_event(x, y, dx, dy)

    def on_mouse_scroll_event(self, x_offset, y_offset):
        self.imgui.mouse_scroll_event(x_offset, y_offset)

    def on_mouse_press_event(self, x, y, button):
        self.imgui.mouse_press_event(x, y, button)

    def on_mouse_release_event(self, x: int, y: int, button: int):
        self.imgui.mouse_release_event(x, y, button)

    # --- Key press/release handler ---
    def on_key_event(self, key, action, modifiers):
        if not imgui.get_io().want_capture_keyboard:
            if (
                key in self.release_action_keys
                and action == self.wnd.keys.ACTION_RELEASE
            ):
                if key in self.keys:
                    self.keys.discard(key)
                else:
                    self.keys.add(key)
            elif (
                key not in self.release_action_keys
                and action == self.wnd.keys.ACTION_PRESS
            ):
                self.keys.add(key)
            elif (
                key not in self.release_action_keys
                and action == self.wnd.keys.ACTION_RELEASE
            ):
                self.keys.discard(key)
        self.imgui.key_event(key, action, modifiers)

    # --- Update translation ---
    def update_controller(self):
        if self.wnd.keys.SPACE in self.keys:
            self.paused = not self.paused
            self.keys.discard(self.wnd.keys.SPACE)
        if self.wnd.keys.NUMBER_1 in self.keys:
            self.paused = False
            self.time_speed = 1
            self.keys.discard(self.wnd.keys.NUMBER_1)
        if self.wnd.keys.NUMBER_2 in self.keys:
            self.paused = False
            self.time_speed = 0.1
            self.keys.discard(self.wnd.keys.NUMBER_2)
        if self.wnd.keys.NUMBER_3 in self.keys:
            self.paused = False
            self.time_speed = 10
            self.keys.discard(self.wnd.keys.NUMBER_3)
        if self.wnd.keys.NUMBER_0 in self.keys:
            self.controller_choice = (
                Controller.ORBIT
                if self.controller_choice != Controller.ORBIT
                else Controller.KEYBOARD_MOUSE
            )
            self.keys.discard(self.wnd.keys.NUMBER_0)
            print("Switched to ", self.controller_choice)
            self.position = Vector3(self.canonical_pose[:3, 3].squeeze())
            # Extract yaw/pitch from rotation matrix
            self.yaw = 0.0
            self.pitch = 0.0
        if self.wnd.keys.NUMBER_9 in self.keys:
            self.controller_choice = (
                Controller.SLAM
                if self.controller_choice != Controller.SLAM
                else Controller.KEYBOARD_MOUSE
            )
            self.keys.discard(self.wnd.keys.NUMBER_9)
            print("Switched to ", self.controller_choice)
            self.position = Vector3(self.canonical_pose[:3, 3].squeeze())
            # Extract yaw/pitch from rotation matrix
            self.yaw = 0.0
            self.pitch = 0.0
        if self.controller_choice == Controller.KEYBOARD_MOUSE:
            # # Local axes from yaw/pitch
            forward = -np.array(
                [
                    np.cos(self.pitch) * np.sin(self.yaw),
                    np.sin(self.pitch),
                    np.cos(self.pitch) * np.cos(self.yaw),
                ]
            )
            right = np.array(
                [np.sin(self.yaw - np.pi / 2), 0.0, np.cos(self.yaw - np.pi / 2)]
            )
            up = np.cross(right, forward)

            if self.wnd.keys.W in self.keys:
                self.position += forward * self.speed
            if self.wnd.keys.S in self.keys:
                self.position -= forward * self.speed
            if self.wnd.keys.A in self.keys:
                self.position -= right * self.speed
            if self.wnd.keys.D in self.keys:
                self.position += right * self.speed
            if self.wnd.keys.Q in self.keys:
                self.position += up * self.speed
            if self.wnd.keys.E in self.keys:
                self.position -= up * self.speed
        elif self.controller_choice == Controller.SLAM:
            # Get pose from Redis
            try:
                pose_data = np.frombuffer(
                    self.redis_server.get("orbSlam_Pose"), dtype=np.float32
                ).reshape(4, 4)
                # print("Pose: ", pose_data)
                self.slam_pose = pose_data
            except Exception as e:
                print("No SLAM data received...", e)
                pass
        elif self.controller_choice == Controller.ORBIT:
            forward = -np.array(
                [
                    np.cos(self.pitch) * np.sin(self.yaw),
                    np.sin(self.pitch),
                    np.cos(self.pitch) * np.cos(self.yaw),
                ]
            )
            right = np.array(
                [np.sin(self.yaw - np.pi / 2), 0.0, np.cos(self.yaw - np.pi / 2)]
            )
            up = np.cross(right, forward)
            strife = torch.norm(
                (torch.from_numpy(self.position.xyz) - self.canonical_pose[:3, 3])
            ).item()
            if strife >= self.scene_bounds:
                self.panning_dir *= -1
            self.position += self.panning_dir * right * self.speed * 0.3
            self.position += (
                self.panning_dir
                * up
                * self.speed
                * np.sin(strife / self.scene_bounds * 2 * np.pi)
                * 0.3
            )
            self.yaw -= self.panning_dir * self.sensitivity

    # --- Get R and t ---
    def get_rt(self):
        if self.controller_choice in [Controller.KEYBOARD_MOUSE, Controller.ORBIT]:
            # R = Matrix44.from_eulers([self.pitch, self.yaw, 0.0])[:3, :3]
            yaw_delta = self.yaw
            pitch_delta = self.pitch

            # R_yaw = Matrix44.from_axis_rotation(Vector3(self.up), yaw_delta)
            # R_pitch = Matrix44.from_axis_rotation(Vector3(self.right), pitch_delta)
            # R_keyboard = R_yaw @ R_pitch
            q_yaw = Quaternion.from_axis_rotation(Vector3(self.up), yaw_delta)
            q_pitch = Quaternion.from_axis_rotation(-Vector3(self.right), pitch_delta)

            # combine: yaw first, then pitch
            q_total = (
                q_yaw * q_pitch
            )  # quaternion multiplication applies pitch after yaw

            # convert to rotation matrix
            R_keyboard = Matrix44.from_quaternion(q_total)[:3, :3]
            R = R_keyboard @ self.R_init
            t = self.position
            # print(t, self.canonical_pose[:3, 3])
            trans = np.array([0.0, 0.0, 0.0])
        elif self.controller_choice == Controller.SLAM:
            R = self.canonical_pose[:3, :3] @ self.slam_pose[:3, :3].T
            t = (self.scaling_factor * self.slam_pose[:3, 3]) + self.canonical_pose[
                :3, 3
            ]
            trans = np.array([0.0, 0.0, 0.0])

        else:
            raise ValueError("Unknown controller choice")
        return R, t, trans

    def _move_collection_to_cpu(self):
        def recurse(d):
            if isinstance(d, dict):
                return {k: recurse(v) for k, v in d.items()}
            elif isinstance(d, list):
                return [recurse(v) for v in d]
            elif isinstance(d, torch.Tensor):
                return d.detach().to("cpu", non_blocking=True)
            elif isinstance(d, HistData) and isinstance(d.data, torch.Tensor):
                d.data = d.data.detach().to("cpu", non_blocking=True)
                return d
            else:
                return d

        self.plot_data = recurse(self.plot_data)

    def _convert_collection_to_numpy(self):
        def recurse(d):
            if isinstance(d, dict):
                return {k: recurse(v) for k, v in d.items()}
            elif isinstance(d, list):
                return [recurse(v) for v in d]
            elif isinstance(d, torch.Tensor):
                return d.numpy()
            elif isinstance(d, HistData) and isinstance(d.data, torch.Tensor):
                d.data = d.data.numpy()
                return d
            else:
                return d

        self.plot_data = recurse(self.plot_data)

    def _update_timestamp(self, frame_time: float):
        if not self.paused:
            self.viewpoint_cam.timestamp += frame_time * self.time_speed
            if self.viewpoint_cam.timestamp > self.time_range[1]:
                self.viewpoint_cam.timestamp = self.time_range[0]

    def on_render(self, time: float, frame_time: float):
        self.update_controller()
        self._update_timestamp(frame_time)
        # with torch.cuda.stream(self.collection_stream):
        #     self._collect_data_cuda()
        #     self._move_collection_to_cpu()
        with torch.no_grad():
            R, t, trans = self.get_rt()
            self.viewpoint_cam.set_rt(R, t)
            image = viewer_rendering.render_frame(
                self.user_context, self.viewpoint_cam.timestamp, self.viewpoint_cam
            )

        # Map PBO and write data
        self.pbo.write(image.tobytes())
        # Bind PBO to texture
        self.texture.write(self.pbo)
        # Render quad
        self.ctx.clear(0.0, 0.0, 0.0, 1.0)
        self.texture.use()
        self.vao.render(moderngl.TRIANGLE_STRIP)
        # self.collection_stream.synchronize()
        # self._convert_collection_to_numpy()
        # self.render_ui()

    def _collect_data_cuda(self):
        with torch.no_grad():
            mask = self.custom_mask
            if mask is None:
                mask = torch.ones(
                    self.gaussians.xyz.shape[0], dtype=torch.bool, device="cuda"
                )
            mask = torch.logical_and(mask, self.temporal_mask)
            n_bins = min(max(mask.sum().item() // 10, 2), 1000)
            self.reset_plot_data()

            op_sigma_data = self.gaussians.opacity_rbf_sigma[mask].exp().squeeze(1)
            op_sigma_obj = self.plot_data["hist"]["temporal_spread_histograms"][
                "opacity_sigma"
            ]
            op_sigma_obj.data = op_sigma_data
            if len(op_sigma_data) > 0:
                op_sigma_obj.mean = op_sigma_data.mean().item()
                op_sigma_obj.min = op_sigma_data.min().item()
                op_sigma_obj.max = op_sigma_data.max().item()

            op_mu_data = self.gaussians.opacity_rbf_mu[mask].squeeze(1)
            op_mu_obj = self.plot_data["hist"]["temporal_mean_histograms"]["opacity_mu"]
            op_mu_obj.data = op_mu_data
            if len(op_mu_data) > 0:
                op_mu_obj.mean = op_mu_data.mean().item()
                op_mu_obj.min = op_mu_data.min().item()
                op_mu_obj.max = op_mu_data.max().item()

            indices = self.gaussians.position_indices[mask]
            p_mu = self.gaussians.position_rbf_mu
            p_sigma = self.gaussians.position_rbf_sigma
            p_vel = self.gaussians.position_vel

            for dof in range(0, self.dof_filter_id + 1):
                dof_indices = indices[:, dof]
                dof_indices = dof_indices[dof_indices > -1].unsqueeze(-1)
                v_norm_obj = self.plot_data["hist"]["velocity_histograms"][
                    f"v{dof}_norm"
                ]
                v_norm_data = torch.gather(p_vel, 0, dof_indices).norm(dim=-1).squeeze()
                if len(v_norm_data) > 0:
                    v_norm_obj.data = v_norm_data
                    v_norm_obj.mean = v_norm_data.mean().item()
                    v_norm_obj.min = v_norm_data.min().item()
                    v_norm_obj.max = v_norm_data.max().item()
                v_sigma_obj = self.plot_data["hist"]["temporal_spread_histograms"][
                    f"v{dof}_sigma"
                ]
                v_sigma_data = torch.gather(p_sigma, 0, dof_indices).exp().squeeze()
                if len(v_sigma_data) > 0:
                    v_sigma_obj.data = v_sigma_data
                    v_sigma_obj.mean = v_sigma_data.mean().item()
                    v_sigma_obj.min = v_sigma_data.min().item()
                    v_sigma_obj.max = v_sigma_data.max().item()
                v_mu_obj = self.plot_data["hist"]["temporal_mean_histograms"][
                    f"v{dof}_mu"
                ]
                assert indices.shape[0] == mask.sum().item()
                if self.gaussians.opacity_mode == "gaussian":
                    v_mu_data = torch.gather(
                        p_mu, 0, dof_indices
                    ).squeeze() + self.gaussians.opacity_rbf_mu[mask].squeeze(1)
                else:
                    v_mu_data = torch.gather(
                        p_mu, 0, dof_indices
                    ).squeeze() + self.gaussians.opacity_rbf_mu[mask].mean(dim=-1)
                if len(v_mu_data) > 0:
                    v_mu_obj.data = v_mu_data
                    v_mu_obj.mean = v_mu_data.mean().item()
                    v_mu_obj.min = v_mu_data.min().item()
                    v_mu_obj.max = v_mu_data.max().item()
                x = np.linspace(self.time_range[0], self.time_range[1], 200)
                self.plot_data["temporal_func"][dof] = {
                    "x": x,
                    "y": self.gaussians.eval_temporal_func(
                        x, mu=v_mu_obj.mean, sigma=v_sigma_obj.mean
                    ),
                }
            self.plot_data["hist_config"]["n_bins"] = n_bins
            self.plot_data["active_guassians"] = mask.sum().item()
            duration = (
                self.gaussians.temporal_activation_range[:, 1]
                - self.gaussians.temporal_activation_range[:, 0]
            )
            self.plot_data["avg_duration"] = duration[mask].mean().item()

    def _render_motion_model_ui(self):
        if implot.begin_plot(
            "Average motion model temporal function",
            size=hello_imgui.em_to_vec2(20, 20),
        ):
            implot.setup_axes(
                "t",
                "phi(t)",
                implot.AxisFlags_.auto_fit,
                implot.AxisFlags_.auto_fit,
            )
            for dof in self.plot_data["temporal_func"].keys():
                implot.plot_line(
                    f"phi_{dof}(t)",
                    self.plot_data["temporal_func"][dof]["x"],
                    self.plot_data["temporal_func"][dof]["y"],
                )
            implot.end_plot()
        # imgui.same_line()
        # if implot.begin_plot()

    def _render_statistics_ui(self):
        if imgui.begin_tab_bar("Histograms"):
            for category_name, histograms in self.plot_data["hist"].items():
                cat_title = category_name.replace("_", " ").title()
                active, _ = imgui.begin_tab_item(cat_title)
                if active:
                    if implot.begin_plot(
                        cat_title,
                        size=hello_imgui.em_to_vec2(40, 20),
                    ):
                        implot.setup_axes(
                            "",
                            "",
                            implot.AxisFlags_.auto_fit,
                            implot.AxisFlags_.auto_fit,
                        )
                        implot.set_next_fill_style(implot.AUTO_COL, 0.5)
                        for hist_name, hist_data in histograms.items():
                            hist_title = hist_name.replace("_", " ").title()
                            implot.plot_histogram(
                                hist_title,
                                hist_data.data,
                                bins=self.plot_data["hist_config"]["n_bins"],
                                bar_scale=1.0,
                                range=implot.Range(),
                                flags=hist_data.hist_flags,
                            )
                        implot.end_plot()
                        imgui.same_line()
                        if imgui.begin_table("Stats", 4):
                            for hist_name, hist_data in histograms.items():
                                hist_title = hist_name.replace("_", " ").title()
                                imgui.table_next_row()
                                imgui.table_set_column_index(0)
                                imgui.text(hist_title)
                                imgui.table_set_column_index(1)
                                imgui.text(f"Mean: {hist_data.mean:.4f}")
                                imgui.table_set_column_index(2)
                                imgui.text(f"Min: {hist_data.min:.4f}")
                                imgui.table_set_column_index(3)
                                imgui.text(f"Max: {hist_data.max:.4f}")
                            imgui.end_table()
                    imgui.end_tab_item()
            imgui.end_tab_bar()

    def render_ui(self):
        def millify(n):
            millnames = ["", " K", " M", " B", " T"]
            n = float(n)
            millidx = max(
                0,
                min(
                    len(millnames) - 1,
                    int(math.floor(0 if n == 0 else math.log10(abs(n)) / 3)),
                ),
            )

            return "{:.2f}{}".format(n / 10 ** (3 * millidx), millnames[millidx])

        imgui.new_frame()
        if imgui.begin("Inspection", True):
            imgui.text(f"Timestamp: {self.viewpoint_cam.timestamp:.2f}s")
            imgui.text(
                f"Active Gaussians: {millify(self.plot_data['active_guassians'])}/{millify(self.gaussians.xyz.shape[0])}"
            )
            imgui.text(f"Average duration: {self.plot_data['avg_duration']:.2f}s")
            _, self.paused = imgui.checkbox("Pause", self.paused)
            imgui.same_line()
            _, self.time_speed = imgui.slider_float(
                "Time speed", self.time_speed, 0.01, 10.0
            )
            imgui.same_line()
            if imgui.button("Reset"):
                self.time_speed = 1

            _, self.p_sigma_range = imgui.slider_float2(
                "position sigma range",
                self.p_sigma_range,
                0.0,
                10.0,
            )
            _, self.opa_sigma_range = imgui.slider_float2(
                "opa sigma range",
                self.opa_sigma_range,
                0.0,
                5.0,
            )
            _, self.vel_norm_range = imgui.slider_float2(
                "velocity norm range",
                self.vel_norm_range,
                0.0,
                1.0,
            )
            _, self.enable_max_op_sigma = imgui.checkbox(
                "Max opacity sigma", self.enable_max_op_sigma
            )
            _, self.enable_max_vel_sigma = imgui.checkbox(
                "Max velocity sigma", self.enable_max_vel_sigma
            )
            _, self.enable_max_vel_norm = imgui.checkbox(
                "Max velocity norm", self.enable_max_vel_norm
            )

            _, self.dof_filter_id = imgui.combo(
                "DoF to collect",
                self.dof_filter_id,
                [str(i) for i in range(1, self.gaussians.p_dof.max() + 1)],
            )
            if imgui.collapsing_header("Motion model"):
                self._render_motion_model_ui()
            if imgui.collapsing_header("Model statistics"):
                self._render_statistics_ui()
        imgui.end()
        imgui.render()
        self.imgui.render(imgui.get_draw_data())

    @property
    def custom_mask(self) -> Optional[torch.Tensor]:
        if self.gaussians.opacity_mode == "gaussian":
            mask = (
                torch.exp(self.gaussians.opacity_rbf_sigma) >= self.opa_sigma_range[0]
            ).squeeze()
            if self.enable_max_op_sigma:
                mask = torch.logical_and(
                    mask,
                    (
                        torch.exp(self.gaussians.opacity_rbf_sigma)
                        <= self.opa_sigma_range[1]
                    ).squeeze(),
                )
        else:
            mask = (
                self.gaussians.opacity_rbf_mu.mean(dim=-1, keepdim=True)
                >= self.opa_sigma_range[0]
            ).squeeze()
        indices = self.gaussians.position_indices
        p_sigma = self.gaussians.position_rbf_sigma
        p_vel = self.gaussians.position_vel
        dof_indices = indices[:, 0]
        dof_indices = dof_indices[dof_indices > -1].unsqueeze(-1)
        gaussian_p_sigma = torch.gather(p_sigma, 0, dof_indices).exp()
        gaussian_p_norm = torch.gather(p_vel, 0, dof_indices).norm(dim=-1).squeeze()
        mask = torch.logical_and(
            mask,
            (gaussian_p_sigma >= self.p_sigma_range[0]).squeeze(),
        )
        mask = torch.logical_and(
            mask,
            (gaussian_p_norm >= self.vel_norm_range[0]).squeeze(),
        )
        if self.enable_max_vel_sigma:
            mask = torch.logical_and(
                mask,
                (gaussian_p_sigma <= self.p_sigma_range[1]).squeeze(),
            )
        if self.enable_max_vel_norm:
            mask = torch.logical_and(
                mask,
                (gaussian_p_norm <= self.vel_norm_range[1]).squeeze(),
            )
        return mask

    @property
    def temporal_mask(self) -> torch.Tensor:
        return torch.logical_and(
            self.viewpoint_cam.timestamp
            >= self.gaussians.temporal_activation_range[:, 0],
            self.viewpoint_cam.timestamp
            <= self.gaussians.temporal_activation_range[:, 1],
        )

    def on_resize(self, width: int, height: int):
        self.imgui.resize(width, height)


if __name__ == "__main__":
    mglw.setup_basic_logging(20)  # INFO level
    window_cls = mglw.get_local_window_cls("glfw")  # or 'glfw', 'sdl2'
    window = window_cls(
        title="Radiance View",
        size=(1280, 720),
        fullscreen=False,
        resizable=True,
        gl_version=(3, 3),
        vsync=True,
    )
    window.config = RadianceView(sys.argv[1:], ctx=window.ctx, wnd=window)
    window.run()
