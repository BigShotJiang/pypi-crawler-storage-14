VIEWER_SNAKE_NAME = "gaussian_inspector"
STUBS_FOLDER_NAME = "gaussian_inspector_stubs"

def get_viewer_name() -> str:
    return VIEWER_SNAKE_NAME.title()
