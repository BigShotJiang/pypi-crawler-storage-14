# FastAPI example

An example of how to use the library with FastAPI
