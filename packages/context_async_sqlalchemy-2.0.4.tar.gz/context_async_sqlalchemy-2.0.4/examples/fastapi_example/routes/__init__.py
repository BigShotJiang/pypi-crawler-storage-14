"""
A module that contains all the application handlers.
"""
