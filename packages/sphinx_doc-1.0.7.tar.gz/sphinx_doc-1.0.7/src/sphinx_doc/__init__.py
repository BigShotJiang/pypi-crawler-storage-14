"""
SV Sphinx Doc - Automated Sphinx documentation generator for SystemVerilog and Python UVM testbenches.
"""

__version__ = "1.0.7"
__author__ = "Sanjay Singh"
__email__ = "your.email@example.com"

from .parser import SVParser
from .generator import RSTGenerator, DocGenerator

__all__ = ["SVParser", "RSTGenerator", "DocGenerator"]
