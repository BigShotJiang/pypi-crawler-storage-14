import unittest
from unittest.mock import patch, MagicMock
from hiplis import Hiplis
from juham_automation import HeatingOptimizer, WaterCirculator



class TestHiplis(unittest.TestCase):

    @patch("masterpiece.Application.load_configuration")
    @patch("hiplis.Hiplis.load_plugins")
    def setUp(self, mock_load_plugins, mock_load_config):
        self.app = Hiplis("test_hiplis")

    def test_initialization(self):
        self.assertEqual(self.app.name, "test_hiplis")


    @patch("hiplis.Hiplis.run_forever")
    @patch(
        "masterpiece.application.Application.parse_args"
    )  # Mock argparse to prevent SystemExit
    def test_main_function(self, mock_parse_args, mock_run_forever):
        with patch("masterpiece.Application.register_plugin_group") as mock_register:
            with patch("hiplis.Hiplis.init_app_id") as mock_init:
                from hiplis import main

                main()
                mock_init.assert_called_once()
                mock_register.assert_called_once()
                mock_run_forever.assert_called_once()


if __name__ == "__main__":
    unittest.main()
