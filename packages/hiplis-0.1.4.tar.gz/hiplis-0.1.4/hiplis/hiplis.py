from typing_extensions import override

from masterpiece import Application

from juham_automation import JApp


class Hiplis(JApp):
    """Hiplis home automation application."""

    def __init__(self, name: str = "hiplis") -> None:
        """Creates home automation application with the given name.
        If --enable_plugins is False create hard coded configuration
        by calling instantiate_classes() method.

        Args:
            name (str): name for the application
        """
        super().__init__(name)
        self.instantiate_classes()

    @override
    def instantiate_classes(self) -> None:
        super().instantiate_classes()

        #
        # Create sensors
        #

        # generate simulated energy meter readings
        #self.add(PowerMeterSimulator("powerconsumption"))

        # living room, shelly motion sensor with temperature and more
        # self.add(ShellyMotionSimulator("livingroom"))



def main() -> None:
    id: str = "hiplis"
    Hiplis.init_app_id(id)
    Application.register_plugin_group(id)
    Hiplis.load_plugins()
    Application.load_configuration()

    app = Hiplis(id)
    app.install_plugins()

    # app.serialize()
    # show the instance hierarchy
    app.print()

    # start the network loops
    app.run_forever()


if __name__ == "__main__":
    main()
