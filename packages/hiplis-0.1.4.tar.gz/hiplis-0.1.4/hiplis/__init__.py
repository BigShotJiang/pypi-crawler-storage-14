"""
Description
===========

Hiplis home automation application

"""

from .hiplis import Hiplis
from .hiplis import main

__all__ = [ "Hiplis", "main"]
