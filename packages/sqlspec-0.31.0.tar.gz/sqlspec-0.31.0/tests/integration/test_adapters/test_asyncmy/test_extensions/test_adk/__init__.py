"""Tests for AsyncMY ADK store."""
