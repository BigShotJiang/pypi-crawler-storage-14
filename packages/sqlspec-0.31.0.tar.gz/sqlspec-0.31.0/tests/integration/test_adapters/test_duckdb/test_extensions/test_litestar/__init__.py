"""Tests for DuckDB Litestar integration."""
