"""Tests for DuckDB extensions."""
