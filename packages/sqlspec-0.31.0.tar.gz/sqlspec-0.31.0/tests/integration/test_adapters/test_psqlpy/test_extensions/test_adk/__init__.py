"""Tests for Psqlpy ADK extension."""
