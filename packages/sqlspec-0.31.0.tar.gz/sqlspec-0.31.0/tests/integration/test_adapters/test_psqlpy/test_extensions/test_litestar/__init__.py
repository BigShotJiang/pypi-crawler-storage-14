"""Tests for psqlpy litestar integration."""
