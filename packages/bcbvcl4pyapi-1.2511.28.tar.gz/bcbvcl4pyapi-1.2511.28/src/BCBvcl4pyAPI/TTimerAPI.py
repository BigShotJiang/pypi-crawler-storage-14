import threading
import time

class TTimer:
    def __init__(self, Interval=1000, Enabled=False, OnTimer=None):
        """
        Interval : 觸發間隔ms.（毫秒）
        Enabled  : 是否啟動定時器
        OnTimer  : 事件回呼函式 (void func())
        """
        self.Interval = Interval
        self.Enabled = Enabled
        self.OnTimer = OnTimer
        self._thread = None
        self._stop_event = threading.Event()

        # === 新增：防止重入 ===
        self._callback_lock = threading.Lock()

        if self.Enabled:
            self.Start()

    # ------------------------------------------------------
    def Start(self):
        """啟動定時器"""
        if self._thread and self._thread.is_alive():
            self.Enabled = True
            return  # 已在執行中
        self.Enabled = True
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    # ------------------------------------------------------
    def Stop(self):
        """停止定時器"""
        self.Enabled = False
        self._stop_event.set()

    # ------------------------------------------------------
    def _run(self):
        """內部執行迴圈"""
        interval = self.Interval / 1000.0

        next_time = time.perf_counter()
        while not self._stop_event.is_set():
            now = time.perf_counter()

            # 到時間了才執行
            if now >= next_time:
                next_time += interval

                # 如果 Timer disabled → 不觸發這次事件
                if not self.Enabled:
                    continue

                # ===== 防重入 =====
                if not self._callback_lock.acquire(blocking=False):
                    continue  # 上一個事件還沒跑完 → 跳過這次

                try:
                    # 即使事件裡 Enabled 變 False，
                    # 這次事件仍會跑完（模擬 BCB 行為）
                    if self.OnTimer:
                        self.OnTimer()
                except Exception as e:
                    print(f"[TTimer Error] {e}")
                finally:
                    self._callback_lock.release()

            time.sleep(0.0005)  # 減少 CPU 負擔

    # ------------------------------------------------------
    def Execute(self):
        """封裝主程式迴圈（模擬應用程式主執行緒）"""
        print("TTimer is running... Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(0.1)
        except KeyboardInterrupt:
            self.Stop()
            print("TTimer stopped.")
        except Exception as e:
            self.Stop()
            print(f"[TTimer MainLoop Error] {e}")
        finally:
            self.Stop()

    # ------------------------------------------------------
    def __del__(self):
        self.Stop()


# ================================================================================
# [使用範例]
import time
#from TTimer import TTimer  # 假設存成 TTimer.py

Timer1: TTimer;
Timer2: TTimer;

def OnTimerEvent():
    mi_c: int;

    Timer1.Enabled = False;

    for mi_c in range(1,10000):
        pass;       
    
    print(f"[1] Tick: {time.time():.6f}")
    Timer1.Enabled = True;


def OnTimerEvent2():
    mi_c: int;

    Timer2.Enabled = False;

    for mi_c in range(1,10000):
        pass;       

    print(f"[2] Tick: {time.time():.6f}")

    Timer2.Enabled = True;


# ================================================================================
if __name__ == "__main__":
    Timer1 = TTimer(Interval=5, Enabled=True, OnTimer=OnTimerEvent)
    Timer2 = TTimer(Interval=5, Enabled=True, OnTimer=OnTimerEvent2)

    print("Timers running... Press Ctrl+C to stop.")
    try:
        while True:
            print("****** Main Loop ******");
            time.sleep(0.1)
    except KeyboardInterrupt:
        Timer1.Stop()
        Timer2.Stop()