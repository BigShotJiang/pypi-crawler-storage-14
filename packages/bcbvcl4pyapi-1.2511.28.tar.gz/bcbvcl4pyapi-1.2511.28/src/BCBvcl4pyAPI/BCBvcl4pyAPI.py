
from typing import Generic, TypeVar, List, Any, Iterator, Optional, Iterable, Callable

T = TypeVar("T")

# --------------------------------------------------------
# TStringList (含簡單 Objects 支援)
# --------------------------------------------------------
class TStringList:
    def __init__(self):
        self.items: List[str] = []
        self._objects: List[Any] = []

    def Add(self, value: str, obj: Any = None) -> int:
        """回傳新加入項目的索引 (像 BCB 的 Add 回傳 index)"""
        self.items.append(value)
        self._objects.append(obj)
        return len(self.items) - 1

    def Insert(self, index: int, value: str, obj: Any = None):
        self.items.insert(index, value)
        self._objects.insert(index, obj)

    def Delete(self, index: int):
        self.items.pop(index)
        self._objects.pop(index)

    def Clear(self):
        self.items.clear()
        self._objects.clear()

    def Sort(self):
        # 排序時一併保留 objects 對應關係
        zipped = list(zip(self.items, self._objects))
        zipped.sort(key=lambda pair: pair[0])
        if zipped:
            self.items, self._objects = map(list, zip(*zipped))
        else:
            self.items, self._objects = [], []

    def IndexOf(self, value: str) -> int:
        try:
            return self.items.index(value)
        except ValueError:
            return -1

    def Count(self) -> int:
        """與 BCB 的 Count() 類似"""
        return len(self.items)

    # Objects 存取（模擬 TStringList.Objects[index]）
    def Objects(self, index: int) -> Any:
        return self._objects[index]

    def SetObject(self, index: int, obj: Any):
        self._objects[index] = obj

    def __getitem__(self, index: int) -> str:
        return self.items[index]

    def __setitem__(self, index: int, value: str):
        self.items[index] = value

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self) -> Iterator[str]:
        return iter(self.items)

    def __repr__(self):
        return f"TStringList({self.items})"


# --------------------------------------------------------
# TList<T>
# --------------------------------------------------------
class TList(Generic[T]):
    def __init__(self):
        self.items: List[T] = []

    def Add(self, value: T) -> int:
        self.items.append(value)
        return len(self.items) - 1

    def Delete(self, index: int):
        self.items.pop(index)

    def Clear(self):
        self.items.clear()

    def Count(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int) -> T:
        return self.items[index]

    def __setitem__(self, index: int, value: T):
        self.items[index] = value

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self) -> Iterator[T]:
        return iter(self.items)

    def __repr__(self):
        return f"TList({self.items})"


# --------------------------------------------------------
# DynamicArray<T>
# --------------------------------------------------------
class DynamicArray(Generic[T]):
    """
    類似 BCB/Delphi DynamicArray 的實作。
    提供 SetLength / Length 與常見的動態陣列操作。
    """

    def __init__(self, initial: Optional[Iterable[T]] = None):
        self.items: List[T] = list(initial) if initial is not None else []

    # ------------------------
    # 長度相關
    # ------------------------
    def Length(self) -> int:
        """回傳目前元素個數（和 len(self) 一致）"""
        return len(self.items)

    def SetLength(self, new_length: int, default: Optional[T] = None) -> None:
        """
        設定陣列長度（類似 Delphi SetLength）。
        - new_length < current -> 截斷
        - new_length > current -> 以 default 填充新元素（若 default 為 None，則填 None）
        """
        if new_length < 0:
            raise ValueError("new_length must be >= 0")
        cur = len(self.items)
        if new_length < cur:
            # truncate
            del self.items[new_length:]
        elif new_length > cur:
            self.items.extend([default] * (new_length - cur))

    # ------------------------
    # 新增 / 插入 / 刪除
    # ------------------------
    def Add(self, value: T) -> int:
        """加入到尾端，回傳新增項目的 index（和 BCB Add 行為相符）"""
        self.items.append(value)
        return len(self.items) - 1

    def AddRange(self, values: Iterable[T]) -> None:
        """加入一組值到尾端"""
        self.items.extend(values)

    def Insert(self, index: int, value: T) -> None:
        """在 index 位置插入（支援負索引）。若 index 大於長度則 append。"""
        if index < 0:
            # 讓負索引像 Python 一樣
            index = max(0, len(self.items) + index)
        if index >= len(self.items):
            self.items.append(value)
        else:
            self.items.insert(index, value)

    def InsertRange(self, index: int, values: Iterable[T]) -> None:
        """在 index 插入多個值"""
        if index < 0:
            index = max(0, len(self.items) + index)
        if index >= len(self.items):
            self.items.extend(values)
            return
        for i, v in enumerate(values):
            self.items.insert(index + i, v)

    def Delete(self, index: int) -> None:
        """刪除 index 的元素（支援負索引）"""
        self.items.pop(index)

    def DeleteRange(self, start: int, count: int) -> None:
        """從 start 刪除 count 個元素（count <= 0 等同無動作）"""
        if count <= 0:
            return
        if start < 0:
            start = max(0, len(self.items) + start)
        end = start + count
        del self.items[start:end]

    def Pop(self, index: int = -1) -> T:
        """彈出（並回傳）指定索引或預設最後一個元素"""
        return self.items.pop(index)

    def Clear(self) -> None:
        """清空陣列"""
        self.items.clear()

    # ------------------------
    # 查詢 / 工具
    # ------------------------
    def IndexOf(self, value: T, start: int = 0) -> int:
        """找 value 的索引，找不到回傳 -1（支援 start）"""
        try:
            return self.items.index(value, start)
        except ValueError:
            return -1

    def Contains(self, value: T) -> bool:
        return value in self.items

    def ToList(self) -> List[T]:
        """回傳標準 list 的淺複本"""
        return list(self.items)

    def FromList(self, src: Iterable[T]) -> None:
        """以 src 取代目前內容"""
        self.items = list(src)

    def Copy(self) -> "DynamicArray[T]":
        """回傳一個淺複本的 DynamicArray"""
        return DynamicArray(self.items.copy())

    def Swap(self, i: int, j: int) -> None:
        """交換兩個 index 的值"""
        self.items[i], self.items[j] = self.items[j], self.items[i]

    def Reverse(self) -> None:
        """反轉內容（in-place）"""
        self.items.reverse()

    def Sort(self, key: Optional[Callable[[T], Any]] = None, reverse: bool = False) -> None:
        """依 key 排序（in-place）"""
        self.items.sort(key=key, reverse=reverse)

    # ------------------------
    # dunder / 迭代
    # ------------------------
    def __getitem__(self, index: int) -> T:
        return self.items[index]

    def __setitem__(self, index: int, value: T) -> None:
        self.items[index] = value

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self) -> Iterator[T]:
        return iter(self.items)

    def __repr__(self) -> str:
        return f"DynamicArray({self.items})"
    
# ================================================================================    
if __name__ == "__main__":
    a = DynamicArray([1,2,3])
    print(a.Length())    # 3
    a.Add(4)             # [1,2,3,4]
    a.SetLength(6, 0)    # [1,2,3,4,0,0]
    print(a.ToList())
    a.Delete(1)          # remove index 1 -> [1,3,4,0,0]
    a.Insert(1, 99)      # [1,99,3,4,0,0]
    print(a.IndexOf(3))  # 2
    a.DeleteRange(2, 3)  # delete three items from index 2 -> [1,99]
    a.AddRange([7,8,9])
    print(len(a))        # 5  (支援 len())
    print(a)             # DynamicArray([1, 99, 7, 8, 9])    