#BCBvcl4pyAPI Classes

## History of version
Version 1.2511.28: 2025/11/28<BR>
Add manay function for DynamicArray<> class

Version 1.2511.25: 2025/11/25<BR>
TTimer class:Fixed re-entry problem.

Version 1.2510.28: 2025/10/28<BR>
HyperDynamicAPI: Add ToList() function for convert to python list.

Version 0.10.21: 2025/10/21<BR>
Add TTimer object class. (TTimerAPI) Multi thread ver.

Version 0.1.10: 2025/10/09<BR>
Fixed the error of not releasing native classes in TMrmoryStreamPI and TIniFileAPI-<Final>.

Version 0.1.9: 2025/10/09<BR>
Fixed the error of not releasing native classes in TMrmoryStreamPI and TIniFileAPI.

Version 0.1.7a: 2025/10/09<BR>
Fixed the error of not releasing native classes in TMrmoryStreamPI and TIniFileAPI.

Version 0.1.7: 2025/10/09<BR>
Add the TMemoryStream, TIniFiles class

Version 0.1.6: 2025/10/08<BR>
Add the AnsiString class 

Version 0.1.5: 2025/09/20<BR>
Add the HyperDynamicArray class to provide large memory access functionality.<BR>

Version 0.1.3: 2025/09/19<BR>
Mainly fixed the issue where Packages could not be found after an update.<BR>
