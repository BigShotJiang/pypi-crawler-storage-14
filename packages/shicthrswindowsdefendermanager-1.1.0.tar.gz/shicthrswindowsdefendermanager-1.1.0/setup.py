from setuptools import setup, find_packages

setup(name='SHICTHRSWindowsDefenderManager',
      version='1.1.0',
      description='SHICTHRS Windows Defender Manager enable/disable Windows Defender',
      url='https://github.com/JNTMTMTM/SHICTHRS_WindowsDefenderManager',
      author='SHICTHRS',
      author_email='contact@shicthrs.com',
      license='GPL-3.0',
      packages=find_packages(),
      include_package_data=True,
      install_requires=['colorama==0.4.6'],
      zip_safe=False)
