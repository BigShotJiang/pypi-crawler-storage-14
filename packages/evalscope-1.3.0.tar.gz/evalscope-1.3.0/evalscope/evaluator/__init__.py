# Copyright (c) Alibaba, Inc. and its affiliates.

from .evaluator import DefaultEvaluator
