# Copyright (c) Alibaba, Inc. and its affiliates.

from evalscope.backend.opencompass.backend_manager import OpenCompassBackendManager
