# Getting Started with pyaddons

__version__: `0.4.1b0`

Misc additional utilities used on many of my scripts and repositories, individually not big enough to warrant a repository so all lumped together.

There is [online](https://cfinan.gitlab.io/pyaddons/index.html) documentation for pyaddons.

## Installation instructions

### pip install
At present, no packages exist yet on PyPy. Therefore, for pip install you should clone this repository and then `cd` to the root of the repository.

```
pip install cfin-pyaddons
```

### Installation using conda
A conda build is also available for Python v3.8/v3.9/v3.10 on linux-64/osX-64. Although please note that all development and testing is performed in linux-64 (Python v3.9).
```
conda install -c conda-forge -c cfin -c bioconda cfin-pyaddons
```

### Installing companion bash scripts
In addition to the Python command-line scripts that are available when the package is installed. There are also some bash scripts located in ``./resources/bin``. Please note these will not be installed when you install via clone & pip or a conda install. If using conda you will have to clone the repo. With either install method you will need to add the ``./resources/bin`` directory to your PATH.

These scripts will require two bash libraries to be in your PATH.

1. ``shflags`` - `This <https://github.com/kward/shflags>`_ is to manage bash command line arguments.
2. ``bash-helpers`` - `This <https://gitlab.com/cfinan/bash-helpers>`_ wraps some handle bash functions.

For more information on what is available see the [bash script](https://cfinan.gitlab.io/pyaddons/scripts/bin_scripts.html) documentation.
