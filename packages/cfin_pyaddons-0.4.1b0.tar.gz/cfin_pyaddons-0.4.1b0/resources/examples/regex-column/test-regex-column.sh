#!/bin/bash
cut -f1,2 test.txt | regex-column -C productname productname -R '(?P<amount>\d+)\s*(?P<unit>[a-zA-Z]+)' '(?P<prodcode>\d+-\d+)' | peep
