from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.document import Document
from prompt_toolkit.validation import Validator, ValidationError


class RegionCompleter(WordCompleter):
    """阿里云区域补全器，继承 WordCompleter 并支持模糊匹配"""

    # 阿里云区域显示名称映射
    REGION_DISPLAY = {
        # China Mainland
        "cn-shenzhen (Shenzhen)": "cn-shenzhen",
        "cn-hangzhou (Hangzhou)": "cn-hangzhou",
        "cn-beijing (Beijing)": "cn-beijing",
        "cn-shanghai (Shanghai)": "cn-shanghai",
        "cn-qingdao (Qingdao)": "cn-qingdao",
        "cn-zhangjiakou (Zhangjiakou)": "cn-zhangjiakou",
        "cn-huhehaote (Hohhot)": "cn-huhehaote",
        "cn-wulanchabu (Ulanqab)": "cn-wulanchabu",
        "cn-chengdu (Chengdu)": "cn-chengdu",
        "cn-heyuan (Heyuan)": "cn-heyuan",
        "cn-guangzhou (Guangzhou)": "cn-guangzhou",
        "cn-fuzhou (Fuzhou)": "cn-fuzhou",
        "cn-wuhan-lr (Wuhan)": "cn-wuhan-lr",
        "cn-nanjing (Nanjing)": "cn-nanjing",
        # Asia Pacific
        "ap-southeast-1 (Singapore)": "ap-southeast-1",
        "ap-southeast-2 (Sydney)": "ap-southeast-2",
        "ap-southeast-3 (Kuala Lumpur)": "ap-southeast-3",
        "ap-southeast-5 (Jakarta)": "ap-southeast-5",
        "ap-northeast-1 (Tokyo)": "ap-northeast-1",
        "ap-south-1 (Mumbai)": "ap-south-1",
        # US
        "us-east-1 (Virginia)": "us-east-1",
        "us-west-1 (Silicon Valley)": "us-west-1",
        # Europe
        "eu-west-1 (London)": "eu-west-1",
        "eu-central-1 (Frankfurt)": "eu-central-1"
    }

    def __init__(self):
        # 调用父类构造函数，传入区域列表和显示名称
        super().__init__(
            words=list(self.REGION_DISPLAY.values()),
            display_dict=self.REGION_DISPLAY,  # 添加显示名称映射
            ignore_case=True,  # 忽略大小写
            sentence=False,    # 不是句子补全
            match_middle=True  # 允许匹配中间部分
        )
    
    def get_valid_regions(self):
        """返回所有有效的区域名称列表"""
        return list(self.REGION_DISPLAY.values())


class RegionValidator(Validator):
    """验证器：确保用户输入的区域名称有效"""
    
    def __init__(self, completer: RegionCompleter):
        self.completer = completer
        self.valid_regions = completer.get_valid_regions()
    
    def validate(self, document: Document):
        """验证用户输入是否为有效的区域名称"""
        text = document.text.strip()
        
        if text and text not in self.valid_regions:
            raise ValidationError(
                message=f"无效的区域名称。请从补全列表中选择有效的区域。",
                cursor_position=len(text)
            )
    


if __name__ == "__main__":
    # 使用示例：演示 RegionCompleter 的模糊补全功能
    from prompt_toolkit import prompt
    
    print("=== 阿里云区域选择器示例 ===")
    print("提示：输入区域名称的部分字符，支持模糊匹配")
    print("例如：输入 'sh' 可以匹配 'cn-shanghai', 'cn-shenzhen' 等")
    print("按 Tab 键查看补全建议，Ctrl+C 退出\n")
    
    # 创建补全器（WordCompleter 自带模糊匹配功能）
    completer = RegionCompleter()
    validator = RegionValidator(completer)
    
    try:
        while True:
            # 使用 prompt_toolkit 提供交互式输入，带自动补全和验证
            user_input = prompt(
                "请选择区域: ",
                completer=completer,  # 直接使用 RegionCompleter，保留 display_dict 效果
                validator=validator,
                validate_while_typing=False,  # 仅在提交时验证，避免输入过程中频繁提示错误
                complete_while_typing=True,  # 输入时实时显示补全建议
            )
            
            if user_input:
                print(f"✓ 您选择的区域是: {user_input}\n")
            else:
                print("未输入任何内容\n")
                
    except KeyboardInterrupt:
        print("\n\n程序已退出")