# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPlans:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.create()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.create(
            amount=0,
            currency="currency",
            interval_day=0,
            title="title",
            authorization="Authorization",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: NowpaymentClient) -> None:
        response = client.subscriptions.plans.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: NowpaymentClient) -> None:
        with client.subscriptions.plans.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.retrieve(
            plan_id="plan-id",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_with_all_params(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.retrieve(
            plan_id="plan-id",
            x_api_key="x-api-key",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: NowpaymentClient) -> None:
        response = client.subscriptions.plans.with_raw_response.retrieve(
            plan_id="plan-id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: NowpaymentClient) -> None:
        with client.subscriptions.plans.with_streaming_response.retrieve(
            plan_id="plan-id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `plan_id` but received ''"):
            client.subscriptions.plans.with_raw_response.retrieve(
                plan_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.update(
            plan_id="plan-id",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.update(
            plan_id="plan-id",
            amount=0,
            currency="currency",
            interval_day=0,
            title="title",
            authorization="Authorization",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: NowpaymentClient) -> None:
        response = client.subscriptions.plans.with_raw_response.update(
            plan_id="plan-id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: NowpaymentClient) -> None:
        with client.subscriptions.plans.with_streaming_response.update(
            plan_id="plan-id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `plan_id` but received ''"):
            client.subscriptions.plans.with_raw_response.update(
                plan_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.list()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: NowpaymentClient) -> None:
        plan = client.subscriptions.plans.list(
            limit=0,
            offset=0,
            x_api_key="x-api-key",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: NowpaymentClient) -> None:
        response = client.subscriptions.plans.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: NowpaymentClient) -> None:
        with client.subscriptions.plans.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True


class TestAsyncPlans:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.create()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.create(
            amount=0,
            currency="currency",
            interval_day=0,
            title="title",
            authorization="Authorization",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.subscriptions.plans.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = await response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.subscriptions.plans.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = await response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.retrieve(
            plan_id="plan-id",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.retrieve(
            plan_id="plan-id",
            x_api_key="x-api-key",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.subscriptions.plans.with_raw_response.retrieve(
            plan_id="plan-id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = await response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.subscriptions.plans.with_streaming_response.retrieve(
            plan_id="plan-id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = await response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `plan_id` but received ''"):
            await async_client.subscriptions.plans.with_raw_response.retrieve(
                plan_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.update(
            plan_id="plan-id",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.update(
            plan_id="plan-id",
            amount=0,
            currency="currency",
            interval_day=0,
            title="title",
            authorization="Authorization",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.subscriptions.plans.with_raw_response.update(
            plan_id="plan-id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = await response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.subscriptions.plans.with_streaming_response.update(
            plan_id="plan-id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = await response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `plan_id` but received ''"):
            await async_client.subscriptions.plans.with_raw_response.update(
                plan_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.list()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        plan = await async_client.subscriptions.plans.list(
            limit=0,
            offset=0,
            x_api_key="x-api-key",
        )
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.subscriptions.plans.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        plan = await response.parse()
        assert plan is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.subscriptions.plans.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            plan = await response.parse()
            assert plan is None

        assert cast(Any, response.is_closed) is True
