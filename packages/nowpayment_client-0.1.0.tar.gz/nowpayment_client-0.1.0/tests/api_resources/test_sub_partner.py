# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSubPartner:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.list()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.list(
            id=0,
            limit=0,
            offset=0,
            order="order",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_deposit(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_deposit()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_deposit_with_all_params(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_deposit(
            amount=0,
            currency="currency",
            sub_partner_id="sub_partner_id",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_deposit(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.create_deposit()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_deposit(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.create_deposit() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_payment(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_payment()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_payment_with_all_params(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_payment(
            amount=0,
            currency="currency",
            ipn_callback_url="ipn_callback_url",
            is_fee_paid_by_user=True,
            is_fixed_rate=True,
            sub_partner_id="sub_partner_id",
            authorization="Authorization",
            x_api_key="x-api-key",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_payment(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.create_payment()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_payment(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.create_payment() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_transfer(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_transfer()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_transfer_with_all_params(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_transfer(
            amount=0,
            currency="currency",
            from_id="from_id",
            to_id="to_id",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_transfer(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.create_transfer()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_transfer(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.create_transfer() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_write_off(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_write_off()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_write_off_with_all_params(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.create_write_off(
            amount=0,
            currency="currency",
            sub_partner_id="sub_partner_id",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_write_off(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.create_write_off()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_write_off(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.create_write_off() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_payments(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.list_payments()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_payments_with_all_params(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.list_payments(
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_payments(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.list_payments()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_payments(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.list_payments() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_transfers(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.list_transfers()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_transfers_with_all_params(self, client: NowpaymentClient) -> None:
        sub_partner = client.sub_partner.list_transfers(
            id=0,
            limit=0,
            offset=0,
            order="order",
            status="status",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_transfers(self, client: NowpaymentClient) -> None:
        response = client.sub_partner.with_raw_response.list_transfers()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_transfers(self, client: NowpaymentClient) -> None:
        with client.sub_partner.with_streaming_response.list_transfers() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True


class TestAsyncSubPartner:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.list()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.list(
            id=0,
            limit=0,
            offset=0,
            order="order",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_deposit(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_deposit()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_deposit_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_deposit(
            amount=0,
            currency="currency",
            sub_partner_id="sub_partner_id",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_deposit(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.create_deposit()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_deposit(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.create_deposit() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_payment(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_payment()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_payment_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_payment(
            amount=0,
            currency="currency",
            ipn_callback_url="ipn_callback_url",
            is_fee_paid_by_user=True,
            is_fixed_rate=True,
            sub_partner_id="sub_partner_id",
            authorization="Authorization",
            x_api_key="x-api-key",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_payment(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.create_payment()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_payment(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.create_payment() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_transfer(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_transfer()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_transfer_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_transfer(
            amount=0,
            currency="currency",
            from_id="from_id",
            to_id="to_id",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_transfer(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.create_transfer()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_transfer(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.create_transfer() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_write_off(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_write_off()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_write_off_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.create_write_off(
            amount=0,
            currency="currency",
            sub_partner_id="sub_partner_id",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_write_off(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.create_write_off()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_write_off(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.create_write_off() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_payments(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.list_payments()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_payments_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.list_payments(
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_payments(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.list_payments()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_payments(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.list_payments() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_transfers(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.list_transfers()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_transfers_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        sub_partner = await async_client.sub_partner.list_transfers(
            id=0,
            limit=0,
            offset=0,
            order="order",
            status="status",
            authorization="Authorization",
        )
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_transfers(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.sub_partner.with_raw_response.list_transfers()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sub_partner = await response.parse()
        assert sub_partner is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_transfers(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.sub_partner.with_streaming_response.list_transfers() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sub_partner = await response.parse()
            assert sub_partner is None

        assert cast(Any, response.is_closed) is True
