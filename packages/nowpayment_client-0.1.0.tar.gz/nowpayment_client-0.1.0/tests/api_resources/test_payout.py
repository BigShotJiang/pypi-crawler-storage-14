# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client.types import (
    PayoutListResponse,
    PayoutCreateResponse,
    PayoutGetFeeEstimateResponse,
    PayoutRetrieveStatusResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPayout:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: NowpaymentClient) -> None:
        payout = client.payout.create()
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: NowpaymentClient) -> None:
        payout = client.payout.create(
            ipn_callback_url="https://example.com",
            payout_description="payout_description",
            withdrawals=[
                {
                    "address": "address",
                    "amount": 0,
                    "currency": "currency",
                    "ipn_callback_url": "https://example.com",
                }
            ],
            authorization="Authorization",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutCreateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: NowpaymentClient) -> None:
        payout = client.payout.list()
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: NowpaymentClient) -> None:
        payout = client.payout.list(
            batch_id=0,
            date_from="date_from",
            date_to="date_to",
            limit=0,
            order="order",
            order_by="order_by",
            page=0,
            status="status",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutListResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_fee_estimate(self, client: NowpaymentClient) -> None:
        payout = client.payout.get_fee_estimate()
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_fee_estimate_with_all_params(self, client: NowpaymentClient) -> None:
        payout = client.payout.get_fee_estimate(
            amount=0,
            currency="currency",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_fee_estimate(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.get_fee_estimate()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_fee_estimate(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.get_fee_estimate() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_status(self, client: NowpaymentClient) -> None:
        payout = client.payout.retrieve_status(
            payout_id="payout_id",
        )
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_status_with_all_params(self, client: NowpaymentClient) -> None:
        payout = client.payout.retrieve_status(
            payout_id="payout_id",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve_status(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.retrieve_status(
            payout_id="payout_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_status(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.retrieve_status(
            payout_id="payout_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve_status(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payout_id` but received ''"):
            client.payout.with_raw_response.retrieve_status(
                payout_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_validate_address(self, client: NowpaymentClient) -> None:
        payout = client.payout.validate_address()
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_validate_address_with_all_params(self, client: NowpaymentClient) -> None:
        payout = client.payout.validate_address(
            x_api_key="x-api-key",
        )
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_validate_address(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.validate_address()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_validate_address(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.validate_address() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert payout is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_verify(self, client: NowpaymentClient) -> None:
        payout = client.payout.verify(
            batch_withdrawal_id="batch-withdrawal-id",
        )
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_verify_with_all_params(self, client: NowpaymentClient) -> None:
        payout = client.payout.verify(
            batch_withdrawal_id="batch-withdrawal-id",
            verification_code="verification_code",
            authorization="Authorization",
            x_api_key="x-api-key",
        )
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_verify(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.verify(
            batch_withdrawal_id="batch-withdrawal-id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_verify(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.verify(
            batch_withdrawal_id="batch-withdrawal-id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert payout is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_verify(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `batch_withdrawal_id` but received ''"):
            client.payout.with_raw_response.verify(
                batch_withdrawal_id="",
            )


class TestAsyncPayout:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.create()
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.create(
            ipn_callback_url="https://example.com",
            payout_description="payout_description",
            withdrawals=[
                {
                    "address": "address",
                    "amount": 0,
                    "currency": "currency",
                    "ipn_callback_url": "https://example.com",
                }
            ],
            authorization="Authorization",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutCreateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.list()
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.list(
            batch_id=0,
            date_from="date_from",
            date_to="date_to",
            limit=0,
            order="order",
            order_by="order_by",
            page=0,
            status="status",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutListResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_fee_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.get_fee_estimate()
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_fee_estimate_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.get_fee_estimate(
            amount=0,
            currency="currency",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_fee_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.get_fee_estimate()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_fee_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.get_fee_estimate() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.retrieve_status(
            payout_id="payout_id",
        )
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_status_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.retrieve_status(
            payout_id="payout_id",
            x_api_key="x-api-key",
        )
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.retrieve_status(
            payout_id="payout_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.retrieve_status(
            payout_id="payout_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payout_id` but received ''"):
            await async_client.payout.with_raw_response.retrieve_status(
                payout_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_validate_address(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.validate_address()
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_validate_address_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.validate_address(
            x_api_key="x-api-key",
        )
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_validate_address(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.validate_address()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_validate_address(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.validate_address() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert payout is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_verify(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.verify(
            batch_withdrawal_id="batch-withdrawal-id",
        )
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_verify_with_all_params(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.verify(
            batch_withdrawal_id="batch-withdrawal-id",
            verification_code="verification_code",
            authorization="Authorization",
            x_api_key="x-api-key",
        )
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_verify(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.verify(
            batch_withdrawal_id="batch-withdrawal-id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert payout is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_verify(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.verify(
            batch_withdrawal_id="batch-withdrawal-id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert payout is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_verify(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `batch_withdrawal_id` but received ''"):
            await async_client.payout.with_raw_response.verify(
                batch_withdrawal_id="",
            )
