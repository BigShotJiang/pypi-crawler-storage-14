# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutRequestPayoutResponse", "Result"]


class Result(BaseModel):
    id: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    crypto_currency_amount: Optional[str] = FieldInfo(alias="cryptoCurrencyAmount", default=None)

    crypto_currency_code: Optional[str] = FieldInfo(alias="cryptoCurrencyCode", default=None)

    error: Optional[object] = None

    fiat_account_code: Optional[str] = FieldInfo(alias="fiatAccountCode", default=None)

    fiat_account_number: Optional[str] = FieldInfo(alias="fiatAccountNumber", default=None)

    fiat_amount: Optional[object] = FieldInfo(alias="fiatAmount", default=None)

    fiat_currency_code: Optional[str] = FieldInfo(alias="fiatCurrencyCode", default=None)

    payout_description: Optional[object] = FieldInfo(alias="payoutDescription", default=None)

    provider: Optional[str] = None

    request_id: Optional[object] = FieldInfo(alias="requestId", default=None)

    status: Optional[str] = None

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class FiatPayoutRequestPayoutResponse(BaseModel):
    result: Optional[Result] = None
