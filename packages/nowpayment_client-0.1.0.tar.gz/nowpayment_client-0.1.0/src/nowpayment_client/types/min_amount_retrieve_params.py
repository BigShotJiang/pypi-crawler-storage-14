# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["MinAmountRetrieveParams"]


class MinAmountRetrieveParams(TypedDict, total=False):
    currency_from: str
    """(Required) Payin currency"""

    currency_to: str
    """(Required) Outcome currency"""

    fiat_equivalent: str
    """
    (Optional) Mentioning ticker of any supported fiat currency you can get fiat
    equivalent of calculated minimal amount
    """

    is_fee_paid_by_user: str
    """(Optional) Set this as true if you're using fee paid by user flow"""

    is_fixed_rate: str
    """(Optional) Set this as true if you're using fixed rate flow"""

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
