# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentCreateParams"]


class PaymentCreateParams(TypedDict, total=False):
    ipn_callback_url: str

    is_fee_paid_by_user: bool

    is_fixed_rate: bool

    order_description: str

    order_id: str

    pay_currency: str

    price_amount: float

    price_currency: str

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
