# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SubPartnerCreatePaymentParams"]


class SubPartnerCreatePaymentParams(TypedDict, total=False):
    amount: int

    currency: str

    ipn_callback_url: str

    is_fee_paid_by_user: bool

    is_fixed_rate: bool

    sub_partner_id: str

    authorization: Annotated[str, PropertyInfo(alias="Authorization")]

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
