# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SubPartnerListTransfersParams"]


class SubPartnerListTransfersParams(TypedDict, total=False):
    id: int
    """int or array of int (optional)"""

    limit: int
    """(optional) default 10"""

    offset: int
    """(optional) default 0"""

    order: str
    """ASC / DESC (optional) default ASC"""

    status: str
    """string or array of string "WAITING"/"CREATED"/"FINISHED"/"REJECTED" (optional)"""

    authorization: Annotated[str, PropertyInfo(alias="Authorization")]
