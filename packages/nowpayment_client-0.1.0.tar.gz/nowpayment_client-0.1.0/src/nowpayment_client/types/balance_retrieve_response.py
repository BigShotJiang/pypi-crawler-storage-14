# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["BalanceRetrieveResponse", "Eth", "Trx", "Xmr"]


class Eth(BaseModel):
    amount: Optional[float] = None

    pending_amount: Optional[int] = FieldInfo(alias="pendingAmount", default=None)


class Trx(BaseModel):
    amount: Optional[int] = None

    pending_amount: Optional[int] = FieldInfo(alias="pendingAmount", default=None)


class Xmr(BaseModel):
    amount: Optional[int] = None

    pending_amount: Optional[int] = FieldInfo(alias="pendingAmount", default=None)


class BalanceRetrieveResponse(BaseModel):
    eth: Optional[Eth] = None

    trx: Optional[Trx] = None

    xmr: Optional[Xmr] = None
