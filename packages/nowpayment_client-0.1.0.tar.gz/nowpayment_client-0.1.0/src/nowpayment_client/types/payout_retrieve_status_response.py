# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import TypeAlias

from .._models import BaseModel

__all__ = ["PayoutRetrieveStatusResponse", "PayoutRetrieveStatusResponseItem"]


class PayoutRetrieveStatusResponseItem(BaseModel):
    id: Optional[str] = None

    address: Optional[str] = None

    amount: Optional[str] = None

    batch_withdrawal_id: Optional[str] = None

    created_at: Optional[datetime] = None

    currency: Optional[str] = None

    error: Optional[object] = None

    extra_id: Optional[object] = None

    hash: Optional[object] = None

    ipn_callback_url: Optional[object] = None

    is_request_payouts: Optional[bool] = None

    payout_description: Optional[object] = None

    requested_at: Optional[object] = None

    status: Optional[str] = None

    unique_external_id: Optional[object] = None

    updated_at: Optional[object] = None


PayoutRetrieveStatusResponse: TypeAlias = List[PayoutRetrieveStatusResponseItem]
