# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutListFiatCurrenciesResponse", "Result"]


class Result(BaseModel):
    currency_code: Optional[str] = FieldInfo(alias="currencyCode", default=None)

    enabled: Optional[bool] = None

    provider: Optional[str] = None


class FiatPayoutListFiatCurrenciesResponse(BaseModel):
    result: Optional[List[Result]] = None
