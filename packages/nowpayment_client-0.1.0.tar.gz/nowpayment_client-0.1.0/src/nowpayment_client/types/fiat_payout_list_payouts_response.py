# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutListPayoutsResponse", "Result", "ResultRow"]


class ResultRow(BaseModel):
    id: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    crypto_currency_amount: Optional[str] = FieldInfo(alias="cryptoCurrencyAmount", default=None)

    crypto_currency_code: Optional[str] = FieldInfo(alias="cryptoCurrencyCode", default=None)

    error: Optional[object] = None

    fiat_account_code: Optional[str] = FieldInfo(alias="fiatAccountCode", default=None)

    fiat_account_number: Optional[str] = FieldInfo(alias="fiatAccountNumber", default=None)

    fiat_amount: Optional[str] = FieldInfo(alias="fiatAmount", default=None)

    fiat_currency_code: Optional[str] = FieldInfo(alias="fiatCurrencyCode", default=None)

    payout_description: Optional[object] = FieldInfo(alias="payoutDescription", default=None)

    provider: Optional[str] = None

    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)

    status: Optional[str] = None

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class Result(BaseModel):
    rows: Optional[List[ResultRow]] = None


class FiatPayoutListPayoutsResponse(BaseModel):
    result: Optional[Result] = None
