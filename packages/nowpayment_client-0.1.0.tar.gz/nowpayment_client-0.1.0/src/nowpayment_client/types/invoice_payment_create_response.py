# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["InvoicePaymentCreateResponse"]


class InvoicePaymentCreateResponse(BaseModel):
    amount_received: Optional[object] = None

    burning_percent: Optional[object] = None

    created_at: Optional[datetime] = None

    expiration_estimate_date: Optional[datetime] = None

    ipn_callback_url: Optional[str] = None

    network: Optional[str] = None

    network_precision: Optional[int] = None

    order_description: Optional[str] = None

    order_id: Optional[str] = None

    pay_address: Optional[str] = None

    pay_amount: Optional[float] = None

    pay_currency: Optional[str] = None

    payin_extra_id: Optional[object] = None

    payment_id: Optional[str] = None

    payment_status: Optional[str] = None

    price_amount: Optional[float] = None

    price_currency: Optional[str] = None

    purchase_id: Optional[str] = None

    smart_contract: Optional[str] = None

    time_limit: Optional[object] = None

    updated_at: Optional[datetime] = None
