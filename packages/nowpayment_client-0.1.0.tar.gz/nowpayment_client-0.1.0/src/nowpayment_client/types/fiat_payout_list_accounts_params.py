# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["FiatPayoutListAccountsParams"]


class FiatPayoutListAccountsParams(TypedDict, total=False):
    id: str

    currency: str

    date_from: Annotated[str, PropertyInfo(alias="dateFrom")]

    date_to: Annotated[str, PropertyInfo(alias="dateTo")]

    filter: str

    limit: str

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]

    page: str

    provider: str

    sort_by: Annotated[str, PropertyInfo(alias="sortBy")]

    authorization: Annotated[str, PropertyInfo(alias="Authorization")]
