# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["FiatPayoutCreateAccountParams", "Fields"]


class FiatPayoutCreateAccountParams(TypedDict, total=False):
    country_code: Annotated[str, PropertyInfo(alias="countryCode")]

    currency: str

    fields: Fields

    payment_code: Annotated[str, PropertyInfo(alias="paymentCode")]

    provider: str

    authorization: Annotated[str, PropertyInfo(alias="Authorization")]

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]


class Fields(TypedDict, total=False):
    account_number: Annotated[str, PropertyInfo(alias="accountNumber")]

    country: str

    iban: str
