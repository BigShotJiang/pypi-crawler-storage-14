# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PayoutCreateParams", "Withdrawal"]


class PayoutCreateParams(TypedDict, total=False):
    ipn_callback_url: str

    payout_description: str

    withdrawals: Iterable[Withdrawal]

    authorization: Annotated[str, PropertyInfo(alias="Authorization")]

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]


class Withdrawal(TypedDict, total=False):
    address: str

    amount: int

    currency: str

    ipn_callback_url: str
