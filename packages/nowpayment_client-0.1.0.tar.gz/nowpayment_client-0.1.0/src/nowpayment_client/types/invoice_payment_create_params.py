# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["InvoicePaymentCreateParams"]


class InvoicePaymentCreateParams(TypedDict, total=False):
    customer_email: str

    iid: str

    order_description: str

    pay_currency: str

    payout_address: str

    payout_currency: str

    payout_extra_id: object

    purchase_id: str

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
