# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PayoutListParams"]


class PayoutListParams(TypedDict, total=False):
    batch_id: int

    date_from: str

    date_to: str

    limit: int

    order: str

    order_by: str

    page: int

    status: str

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
