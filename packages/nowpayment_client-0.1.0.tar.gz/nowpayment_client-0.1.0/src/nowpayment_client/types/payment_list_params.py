# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentListParams"]


class PaymentListParams(TypedDict, total=False):
    date_from: Annotated[str, PropertyInfo(alias="dateFrom")]
    """Parameters for filtering items by certain dates"""

    date_to: Annotated[str, PropertyInfo(alias="dateTo")]
    """Parameters for filtering items by certain dates"""

    invoice_id: Annotated[int, PropertyInfo(alias="invoiceId")]
    """Filtering items by certain invoice ID"""

    limit: int
    """The limit of items listed in one page of response body.

    Possible values: from 1 to 500
    """

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Set the order of listed items. It can be 'asc' or 'desc'"""

    page: int
    """
    If amount of items is more than specified in 'limit' parameter, you can switch
    pages with this one. Possible values: from 0 to last existing page number digit.
    """

    sort_by: Annotated[str, PropertyInfo(alias="sortBy")]
    """Sorting by a certain parameter value"""

    authorization: Annotated[str, PropertyInfo(alias="Authorization")]

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
