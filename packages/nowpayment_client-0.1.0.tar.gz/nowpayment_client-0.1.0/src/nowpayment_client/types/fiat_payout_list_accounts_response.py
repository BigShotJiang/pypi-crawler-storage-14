# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutListAccountsResponse", "Result", "ResultRow", "ResultRowProviderAccountInfo"]


class ResultRowProviderAccountInfo(BaseModel):
    account_number: Optional[str] = FieldInfo(alias="accountNumber", default=None)

    currency: Optional[str] = None

    display_name: Optional[str] = FieldInfo(alias="displayName", default=None)

    payment_code: Optional[str] = FieldInfo(alias="paymentCode", default=None)


class ResultRow(BaseModel):
    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    fiat_currency_code: Optional[str] = FieldInfo(alias="fiatCurrencyCode", default=None)

    provider: Optional[str] = None

    provider_account_info: Optional[ResultRowProviderAccountInfo] = FieldInfo(alias="providerAccountInfo", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class Result(BaseModel):
    rows: Optional[List[ResultRow]] = None


class FiatPayoutListAccountsResponse(BaseModel):
    result: Optional[Result] = None
