# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SubscriptionCreateParams"]


class SubscriptionCreateParams(TypedDict, total=False):
    email: str

    sub_partner_id: int

    subscription_plan_id: int

    authorization: Annotated[str, PropertyInfo(alias="Authorization")]

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
