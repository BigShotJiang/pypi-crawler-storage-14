# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SubscriptionListParams"]


class SubscriptionListParams(TypedDict, total=False):
    is_active: bool
    """true / false"""

    limit: int

    offset: int

    status: str
    """\"WAITING_PAY" / "PAID" / "PARTIALLY_PAID" / "EXPIRED" """

    subscription_plan_id: int

    x_api_key: Annotated[str, PropertyInfo(alias="x-api-key")]
