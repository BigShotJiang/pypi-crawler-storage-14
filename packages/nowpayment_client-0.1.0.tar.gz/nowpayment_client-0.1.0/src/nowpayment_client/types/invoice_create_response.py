# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["InvoiceCreateResponse"]


class InvoiceCreateResponse(BaseModel):
    id: Optional[str] = None

    cancel_url: Optional[str] = None

    created_at: Optional[datetime] = None

    invoice_url: Optional[str] = None

    ipn_callback_url: Optional[str] = None

    order_description: Optional[str] = None

    order_id: Optional[str] = None

    pay_currency: Optional[object] = None

    price_amount: Optional[str] = None

    price_currency: Optional[str] = None

    success_url: Optional[str] = None

    updated_at: Optional[datetime] = None
