# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "FiatPayoutCreateAccountResponse",
    "Result",
    "ResultProviderAccountInfo",
    "ResultProviderAccountInfoMetaData",
]


class ResultProviderAccountInfoMetaData(BaseModel):
    iban: Optional[str] = None

    number: Optional[str] = None

    swiftbic: Optional[str] = None

    vendor: Optional[str] = None


class ResultProviderAccountInfo(BaseModel):
    api_v: Optional[int] = FieldInfo(alias="__v", default=None)

    api_id: Optional[str] = FieldInfo(alias="_id", default=None)

    account_number: Optional[str] = FieldInfo(alias="accountNumber", default=None)

    country: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    currency: Optional[str] = None

    display_name: Optional[str] = FieldInfo(alias="displayName", default=None)

    last4_digits: Optional[str] = FieldInfo(alias="last4Digits", default=None)

    logo: Optional[str] = None

    meta_data: Optional[ResultProviderAccountInfoMetaData] = FieldInfo(alias="metaData", default=None)

    pa_id: Optional[str] = FieldInfo(alias="paId", default=None)

    payment_code: Optional[str] = FieldInfo(alias="paymentCode", default=None)

    status: Optional[str] = None

    type: Optional[str] = None

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)

    user_id: Optional[str] = FieldInfo(alias="userId", default=None)


class Result(BaseModel):
    id: Optional[str] = None

    country_code: Optional[str] = FieldInfo(alias="countryCode", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    fiat_currency_code: Optional[str] = FieldInfo(alias="fiatCurrencyCode", default=None)

    partner_id: Optional[str] = FieldInfo(alias="partnerId", default=None)

    provider: Optional[str] = None

    provider_account_id: Optional[str] = FieldInfo(alias="providerAccountId", default=None)

    provider_account_info: Optional[ResultProviderAccountInfo] = FieldInfo(alias="providerAccountInfo", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class FiatPayoutCreateAccountResponse(BaseModel):
    result: Optional[Result] = None
