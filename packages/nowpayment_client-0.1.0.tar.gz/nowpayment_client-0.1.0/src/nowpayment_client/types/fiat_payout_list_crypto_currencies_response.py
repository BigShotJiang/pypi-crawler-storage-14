# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutListCryptoCurrenciesResponse", "Result"]


class Result(BaseModel):
    currency_code: Optional[str] = FieldInfo(alias="currencyCode", default=None)

    currency_network: Optional[str] = FieldInfo(alias="currencyNetwork", default=None)

    enabled: Optional[bool] = None

    provider: Optional[str] = None


class FiatPayoutListCryptoCurrenciesResponse(BaseModel):
    result: Optional[List[Result]] = None
