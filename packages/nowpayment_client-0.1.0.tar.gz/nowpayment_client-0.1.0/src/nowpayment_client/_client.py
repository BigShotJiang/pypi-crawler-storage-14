# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, Mapping
from typing_extensions import Self, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import is_given, get_async_library
from ._version import __version__
from .resources import (
    auth,
    payout,
    status,
    balance,
    invoice,
    payment,
    estimate,
    merchant,
    conversion,
    currencies,
    min_amount,
    fiat_payouts,
    full_currencies,
    invoice_payment,
    payout_withdrawal,
)
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import APIStatusError, NowpaymentClientError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)
from .resources.sub_partner import sub_partner
from .resources.subscriptions import subscriptions

__all__ = [
    "Timeout",
    "Transport",
    "ProxiesTypes",
    "RequestOptions",
    "NowpaymentClient",
    "AsyncNowpaymentClient",
    "Client",
    "AsyncClient",
]


class NowpaymentClient(SyncAPIClient):
    status: status.StatusResource
    auth: auth.AuthResource
    currencies: currencies.CurrenciesResource
    full_currencies: full_currencies.FullCurrenciesResource
    merchant: merchant.MerchantResource
    min_amount: min_amount.MinAmountResource
    invoice: invoice.InvoiceResource
    payment: payment.PaymentResource
    invoice_payment: invoice_payment.InvoicePaymentResource
    estimate: estimate.EstimateResource
    balance: balance.BalanceResource
    payout: payout.PayoutResource
    payout_withdrawal: payout_withdrawal.PayoutWithdrawalResource
    conversion: conversion.ConversionResource
    sub_partner: sub_partner.SubPartnerResource
    subscriptions: subscriptions.SubscriptionsResource
    fiat_payouts: fiat_payouts.FiatPayoutsResource
    with_raw_response: NowpaymentClientWithRawResponse
    with_streaming_response: NowpaymentClientWithStreamedResponse

    # client options
    api_key: str

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous NowpaymentClient client instance.

        This automatically infers the `api_key` argument from the `NOWPAYMENT_CLIENT_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("NOWPAYMENT_CLIENT_API_KEY")
        if api_key is None:
            raise NowpaymentClientError(
                "The api_key client option must be set either by passing api_key to the client or by setting the NOWPAYMENT_CLIENT_API_KEY environment variable"
            )
        self.api_key = api_key

        if base_url is None:
            base_url = os.environ.get("NOWPAYMENT_CLIENT_BASE_URL")
        if base_url is None:
            base_url = f"https://api.example.com"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self.status = status.StatusResource(self)
        self.auth = auth.AuthResource(self)
        self.currencies = currencies.CurrenciesResource(self)
        self.full_currencies = full_currencies.FullCurrenciesResource(self)
        self.merchant = merchant.MerchantResource(self)
        self.min_amount = min_amount.MinAmountResource(self)
        self.invoice = invoice.InvoiceResource(self)
        self.payment = payment.PaymentResource(self)
        self.invoice_payment = invoice_payment.InvoicePaymentResource(self)
        self.estimate = estimate.EstimateResource(self)
        self.balance = balance.BalanceResource(self)
        self.payout = payout.PayoutResource(self)
        self.payout_withdrawal = payout_withdrawal.PayoutWithdrawalResource(self)
        self.conversion = conversion.ConversionResource(self)
        self.sub_partner = sub_partner.SubPartnerResource(self)
        self.subscriptions = subscriptions.SubscriptionsResource(self)
        self.fiat_payouts = fiat_payouts.FiatPayoutsResource(self)
        self.with_raw_response = NowpaymentClientWithRawResponse(self)
        self.with_streaming_response = NowpaymentClientWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncNowpaymentClient(AsyncAPIClient):
    status: status.AsyncStatusResource
    auth: auth.AsyncAuthResource
    currencies: currencies.AsyncCurrenciesResource
    full_currencies: full_currencies.AsyncFullCurrenciesResource
    merchant: merchant.AsyncMerchantResource
    min_amount: min_amount.AsyncMinAmountResource
    invoice: invoice.AsyncInvoiceResource
    payment: payment.AsyncPaymentResource
    invoice_payment: invoice_payment.AsyncInvoicePaymentResource
    estimate: estimate.AsyncEstimateResource
    balance: balance.AsyncBalanceResource
    payout: payout.AsyncPayoutResource
    payout_withdrawal: payout_withdrawal.AsyncPayoutWithdrawalResource
    conversion: conversion.AsyncConversionResource
    sub_partner: sub_partner.AsyncSubPartnerResource
    subscriptions: subscriptions.AsyncSubscriptionsResource
    fiat_payouts: fiat_payouts.AsyncFiatPayoutsResource
    with_raw_response: AsyncNowpaymentClientWithRawResponse
    with_streaming_response: AsyncNowpaymentClientWithStreamedResponse

    # client options
    api_key: str

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncNowpaymentClient client instance.

        This automatically infers the `api_key` argument from the `NOWPAYMENT_CLIENT_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("NOWPAYMENT_CLIENT_API_KEY")
        if api_key is None:
            raise NowpaymentClientError(
                "The api_key client option must be set either by passing api_key to the client or by setting the NOWPAYMENT_CLIENT_API_KEY environment variable"
            )
        self.api_key = api_key

        if base_url is None:
            base_url = os.environ.get("NOWPAYMENT_CLIENT_BASE_URL")
        if base_url is None:
            base_url = f"https://api.example.com"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self.status = status.AsyncStatusResource(self)
        self.auth = auth.AsyncAuthResource(self)
        self.currencies = currencies.AsyncCurrenciesResource(self)
        self.full_currencies = full_currencies.AsyncFullCurrenciesResource(self)
        self.merchant = merchant.AsyncMerchantResource(self)
        self.min_amount = min_amount.AsyncMinAmountResource(self)
        self.invoice = invoice.AsyncInvoiceResource(self)
        self.payment = payment.AsyncPaymentResource(self)
        self.invoice_payment = invoice_payment.AsyncInvoicePaymentResource(self)
        self.estimate = estimate.AsyncEstimateResource(self)
        self.balance = balance.AsyncBalanceResource(self)
        self.payout = payout.AsyncPayoutResource(self)
        self.payout_withdrawal = payout_withdrawal.AsyncPayoutWithdrawalResource(self)
        self.conversion = conversion.AsyncConversionResource(self)
        self.sub_partner = sub_partner.AsyncSubPartnerResource(self)
        self.subscriptions = subscriptions.AsyncSubscriptionsResource(self)
        self.fiat_payouts = fiat_payouts.AsyncFiatPayoutsResource(self)
        self.with_raw_response = AsyncNowpaymentClientWithRawResponse(self)
        self.with_streaming_response = AsyncNowpaymentClientWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class NowpaymentClientWithRawResponse:
    def __init__(self, client: NowpaymentClient) -> None:
        self.status = status.StatusResourceWithRawResponse(client.status)
        self.auth = auth.AuthResourceWithRawResponse(client.auth)
        self.currencies = currencies.CurrenciesResourceWithRawResponse(client.currencies)
        self.full_currencies = full_currencies.FullCurrenciesResourceWithRawResponse(client.full_currencies)
        self.merchant = merchant.MerchantResourceWithRawResponse(client.merchant)
        self.min_amount = min_amount.MinAmountResourceWithRawResponse(client.min_amount)
        self.invoice = invoice.InvoiceResourceWithRawResponse(client.invoice)
        self.payment = payment.PaymentResourceWithRawResponse(client.payment)
        self.invoice_payment = invoice_payment.InvoicePaymentResourceWithRawResponse(client.invoice_payment)
        self.estimate = estimate.EstimateResourceWithRawResponse(client.estimate)
        self.balance = balance.BalanceResourceWithRawResponse(client.balance)
        self.payout = payout.PayoutResourceWithRawResponse(client.payout)
        self.payout_withdrawal = payout_withdrawal.PayoutWithdrawalResourceWithRawResponse(client.payout_withdrawal)
        self.conversion = conversion.ConversionResourceWithRawResponse(client.conversion)
        self.sub_partner = sub_partner.SubPartnerResourceWithRawResponse(client.sub_partner)
        self.subscriptions = subscriptions.SubscriptionsResourceWithRawResponse(client.subscriptions)
        self.fiat_payouts = fiat_payouts.FiatPayoutsResourceWithRawResponse(client.fiat_payouts)


class AsyncNowpaymentClientWithRawResponse:
    def __init__(self, client: AsyncNowpaymentClient) -> None:
        self.status = status.AsyncStatusResourceWithRawResponse(client.status)
        self.auth = auth.AsyncAuthResourceWithRawResponse(client.auth)
        self.currencies = currencies.AsyncCurrenciesResourceWithRawResponse(client.currencies)
        self.full_currencies = full_currencies.AsyncFullCurrenciesResourceWithRawResponse(client.full_currencies)
        self.merchant = merchant.AsyncMerchantResourceWithRawResponse(client.merchant)
        self.min_amount = min_amount.AsyncMinAmountResourceWithRawResponse(client.min_amount)
        self.invoice = invoice.AsyncInvoiceResourceWithRawResponse(client.invoice)
        self.payment = payment.AsyncPaymentResourceWithRawResponse(client.payment)
        self.invoice_payment = invoice_payment.AsyncInvoicePaymentResourceWithRawResponse(client.invoice_payment)
        self.estimate = estimate.AsyncEstimateResourceWithRawResponse(client.estimate)
        self.balance = balance.AsyncBalanceResourceWithRawResponse(client.balance)
        self.payout = payout.AsyncPayoutResourceWithRawResponse(client.payout)
        self.payout_withdrawal = payout_withdrawal.AsyncPayoutWithdrawalResourceWithRawResponse(
            client.payout_withdrawal
        )
        self.conversion = conversion.AsyncConversionResourceWithRawResponse(client.conversion)
        self.sub_partner = sub_partner.AsyncSubPartnerResourceWithRawResponse(client.sub_partner)
        self.subscriptions = subscriptions.AsyncSubscriptionsResourceWithRawResponse(client.subscriptions)
        self.fiat_payouts = fiat_payouts.AsyncFiatPayoutsResourceWithRawResponse(client.fiat_payouts)


class NowpaymentClientWithStreamedResponse:
    def __init__(self, client: NowpaymentClient) -> None:
        self.status = status.StatusResourceWithStreamingResponse(client.status)
        self.auth = auth.AuthResourceWithStreamingResponse(client.auth)
        self.currencies = currencies.CurrenciesResourceWithStreamingResponse(client.currencies)
        self.full_currencies = full_currencies.FullCurrenciesResourceWithStreamingResponse(client.full_currencies)
        self.merchant = merchant.MerchantResourceWithStreamingResponse(client.merchant)
        self.min_amount = min_amount.MinAmountResourceWithStreamingResponse(client.min_amount)
        self.invoice = invoice.InvoiceResourceWithStreamingResponse(client.invoice)
        self.payment = payment.PaymentResourceWithStreamingResponse(client.payment)
        self.invoice_payment = invoice_payment.InvoicePaymentResourceWithStreamingResponse(client.invoice_payment)
        self.estimate = estimate.EstimateResourceWithStreamingResponse(client.estimate)
        self.balance = balance.BalanceResourceWithStreamingResponse(client.balance)
        self.payout = payout.PayoutResourceWithStreamingResponse(client.payout)
        self.payout_withdrawal = payout_withdrawal.PayoutWithdrawalResourceWithStreamingResponse(
            client.payout_withdrawal
        )
        self.conversion = conversion.ConversionResourceWithStreamingResponse(client.conversion)
        self.sub_partner = sub_partner.SubPartnerResourceWithStreamingResponse(client.sub_partner)
        self.subscriptions = subscriptions.SubscriptionsResourceWithStreamingResponse(client.subscriptions)
        self.fiat_payouts = fiat_payouts.FiatPayoutsResourceWithStreamingResponse(client.fiat_payouts)


class AsyncNowpaymentClientWithStreamedResponse:
    def __init__(self, client: AsyncNowpaymentClient) -> None:
        self.status = status.AsyncStatusResourceWithStreamingResponse(client.status)
        self.auth = auth.AsyncAuthResourceWithStreamingResponse(client.auth)
        self.currencies = currencies.AsyncCurrenciesResourceWithStreamingResponse(client.currencies)
        self.full_currencies = full_currencies.AsyncFullCurrenciesResourceWithStreamingResponse(client.full_currencies)
        self.merchant = merchant.AsyncMerchantResourceWithStreamingResponse(client.merchant)
        self.min_amount = min_amount.AsyncMinAmountResourceWithStreamingResponse(client.min_amount)
        self.invoice = invoice.AsyncInvoiceResourceWithStreamingResponse(client.invoice)
        self.payment = payment.AsyncPaymentResourceWithStreamingResponse(client.payment)
        self.invoice_payment = invoice_payment.AsyncInvoicePaymentResourceWithStreamingResponse(client.invoice_payment)
        self.estimate = estimate.AsyncEstimateResourceWithStreamingResponse(client.estimate)
        self.balance = balance.AsyncBalanceResourceWithStreamingResponse(client.balance)
        self.payout = payout.AsyncPayoutResourceWithStreamingResponse(client.payout)
        self.payout_withdrawal = payout_withdrawal.AsyncPayoutWithdrawalResourceWithStreamingResponse(
            client.payout_withdrawal
        )
        self.conversion = conversion.AsyncConversionResourceWithStreamingResponse(client.conversion)
        self.sub_partner = sub_partner.AsyncSubPartnerResourceWithStreamingResponse(client.sub_partner)
        self.subscriptions = subscriptions.AsyncSubscriptionsResourceWithStreamingResponse(client.subscriptions)
        self.fiat_payouts = fiat_payouts.AsyncFiatPayoutsResourceWithStreamingResponse(client.fiat_payouts)


Client = NowpaymentClient

AsyncClient = AsyncNowpaymentClient
