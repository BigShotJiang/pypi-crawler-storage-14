# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable

import httpx

from ..types import payout_list_params, payout_create_params, payout_verify_params, payout_get_fee_estimate_params
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.payout_list_response import PayoutListResponse
from ..types.payout_create_response import PayoutCreateResponse
from ..types.payout_retrieve_status_response import PayoutRetrieveStatusResponse
from ..types.payout_get_fee_estimate_response import PayoutGetFeeEstimateResponse

__all__ = ["PayoutResource", "AsyncPayoutResource"]


class PayoutResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PayoutResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return PayoutResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PayoutResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return PayoutResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        ipn_callback_url: str | Omit = omit,
        payout_description: str | Omit = omit,
        withdrawals: Iterable[payout_create_params.Withdrawal] | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutCreateResponse:
        """This method is used for crypto payouts only.

        Please note that payouts can be
        requested only using a whitelisted IP address, and to whitelisted wallet
        addresses. It's a security measure enabled for each partner account by default.

        You can whitelist both of these anytime in your NOWPayments personal account by
        visiting 'Whitelist' section in 'Settings'.

        You need to provide your data as a JSON-object payload. Next is a description of
        the required request fields:

        - address (required) - the address where you want to send funds;
        - currency (required) - payout currency;
        - amount (required) - amount of the payout. **Must not exceed 6 decimals** (i.e.
          0.123456);
        - extra_id (optional) - memo, destination tag, etc.
        - ipn_callback_url(optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io). Please
          note: you can either set ipn_callback_url for each individual payout, or for
          all payouts in a batch (see example). **In both cases IPNs will be sent for
          each payout separately;**
        - payout_description(optional) - a description of the payout. You can set it for
          all payouts in a batch;
        - unique_external_id(optional) - a unique external identifier;
        - fiat_amount(optional) - used for setting the payout amount in fiat equivalent.
          **Overrides "amount" parameter;**
        - fiat_currency (optional) - used for determining fiat currency to get the fiat
          equivalent for. **Required for "fiat_amount" parameter to work. DOES NOT
          override "currency" parameter. Payouts are made in crypto only, no fiat
          payouts are available;**

        Here is the list of the available payout statuses:

        - creating;
        - waiting;
        - processing;
        - sending;
        - finished;
        - failed;
        - rejected;

        Please note that in some cases 'Failed' payouts may be processed after your
        confirmation, so please check this possibility with the support team beforer
        recreating the payout.

        Please, take note that you may request a single payout, but it still should be
        formatted as an array with the single element.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/v1/payout",
            body=maybe_transform(
                {
                    "ipn_callback_url": ipn_callback_url,
                    "payout_description": payout_description,
                    "withdrawals": withdrawals,
                },
                payout_create_params.PayoutCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PayoutCreateResponse,
        )

    def list(
        self,
        *,
        batch_id: int | Omit = omit,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        limit: int | Omit = omit,
        order: str | Omit = omit,
        order_by: str | Omit = omit,
        page: int | Omit = omit,
        status: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutListResponse:
        """
        This endpoint allows you to get a list of your payouts.

        The list of available parameters:

        - batch_id: batch ID of enlisted payouts;
        - status: the statuses of enlisted payouts;
        - order_by: can be id, batchId, dateCreated, dateRequested, dateUpdated,
          currency, status;
        - order: 'asc' or 'desc' order;
        - date_from: beginning date of the requested payouts;
        - date_to: ending date of the requested payouts;
        - limit: a number of results to show;
        - page: the current page;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._get(
            "/v1/payout",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "batch_id": batch_id,
                        "date_from": date_from,
                        "date_to": date_to,
                        "limit": limit,
                        "order": order,
                        "order_by": order_by,
                        "page": page,
                        "status": status,
                    },
                    payout_list_params.PayoutListParams,
                ),
            ),
            cast_to=PayoutListResponse,
        )

    def get_fee_estimate(
        self,
        *,
        amount: int | Omit = omit,
        currency: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutGetFeeEstimateResponse:
        """
        This endpoint will show you the estimated amount of network fee for payout.

        Please note that:

        - This endpoint will show you the fee estimate for the moment of the request is
          done. Fee itself is dynamic and may change over a brief moment of time.
        - The fee depends on the blockchain itself and its congestion. We cannot affect
          it in any way nor control or hold it.
        - The actual fee will be calcualated at the moment of payout processing. Please
          be aware that it can differ from estimate.

        Args:
          amount: The desired amount of your payout

          currency: The coin ticker of your payout

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._get(
            "/v1/payout/fee",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "amount": amount,
                        "currency": currency,
                    },
                    payout_get_fee_estimate_params.PayoutGetFeeEstimateParams,
                ),
            ),
            cast_to=PayoutGetFeeEstimateResponse,
        )

    def retrieve_status(
        self,
        payout_id: str,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutRetrieveStatusResponse:
        """Get the actual information about the payout.

        You need to provide the ID of the
        payout in the request.

        NOTE! You should make the get payout status request with the same API key that
        you used in the creat_payout request.

        Here is the list of available statuses:

        - creating;
        - processing;
        - sending;
        - finished;
        - failed;
        - rejected;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payout_id:
            raise ValueError(f"Expected a non-empty value for `payout_id` but received {payout_id!r}")
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._get(
            f"/v1/payout/{payout_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PayoutRetrieveStatusResponse,
        )

    def validate_address(
        self,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This endpoint allows you to check if your payout address is valid and funds can
        be received there.

        Available parameters:

        - address - the payout address;
        - currency - the ticker of payout currency;
        - (optional) extra_id - memo or destination tag, if applicable;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._post(
            "/v1/payout/validate-address",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def verify(
        self,
        batch_withdrawal_id: str,
        *,
        verification_code: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """This method is required to verify payouts by using your 2FA code.


        You’ll have 10 attempts to verify the payout. If it is not verified after 10
        attempts, the payout will remain in ‘creating’ status.
        Payout will be processed only when it is verified.

        If you have 2FA app enabled in your dashboard, payouts will accept 2FA code from
        your app. Otherwise the code for payouts validation will be sent to your
        registration email.

        Please take a note that unverified payouts will be automatically rejected in an
        hour after creation.

        Next is a description of the required request fields:

        - :batch-withdrawal-id - payout id you received in `2. Create payout` method;
        - verification_code - 2fa code you received with your Google Auth app or via
          email;

        In order to establish an automatic verification of payouts, you should switch
        2FA through the application.
        There are several libraries for different frameworks aimed on generating 2FA
        codes based on a secret key from your account settings, for example, Speakeasy
        for JavaScript.
        We do not recommend to change any default settings.

        ```
        const 2faVerificationCode = speakeasy.totp({
              your_2fa_secret_key,
              encoding: 'base32',
        })

        ```

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not batch_withdrawal_id:
            raise ValueError(
                f"Expected a non-empty value for `batch_withdrawal_id` but received {batch_withdrawal_id!r}"
            )
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            f"/v1/payout/{batch_withdrawal_id}/verify",
            body=maybe_transform({"verification_code": verification_code}, payout_verify_params.PayoutVerifyParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncPayoutResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPayoutResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncPayoutResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPayoutResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncPayoutResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        ipn_callback_url: str | Omit = omit,
        payout_description: str | Omit = omit,
        withdrawals: Iterable[payout_create_params.Withdrawal] | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutCreateResponse:
        """This method is used for crypto payouts only.

        Please note that payouts can be
        requested only using a whitelisted IP address, and to whitelisted wallet
        addresses. It's a security measure enabled for each partner account by default.

        You can whitelist both of these anytime in your NOWPayments personal account by
        visiting 'Whitelist' section in 'Settings'.

        You need to provide your data as a JSON-object payload. Next is a description of
        the required request fields:

        - address (required) - the address where you want to send funds;
        - currency (required) - payout currency;
        - amount (required) - amount of the payout. **Must not exceed 6 decimals** (i.e.
          0.123456);
        - extra_id (optional) - memo, destination tag, etc.
        - ipn_callback_url(optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io). Please
          note: you can either set ipn_callback_url for each individual payout, or for
          all payouts in a batch (see example). **In both cases IPNs will be sent for
          each payout separately;**
        - payout_description(optional) - a description of the payout. You can set it for
          all payouts in a batch;
        - unique_external_id(optional) - a unique external identifier;
        - fiat_amount(optional) - used for setting the payout amount in fiat equivalent.
          **Overrides "amount" parameter;**
        - fiat_currency (optional) - used for determining fiat currency to get the fiat
          equivalent for. **Required for "fiat_amount" parameter to work. DOES NOT
          override "currency" parameter. Payouts are made in crypto only, no fiat
          payouts are available;**

        Here is the list of the available payout statuses:

        - creating;
        - waiting;
        - processing;
        - sending;
        - finished;
        - failed;
        - rejected;

        Please note that in some cases 'Failed' payouts may be processed after your
        confirmation, so please check this possibility with the support team beforer
        recreating the payout.

        Please, take note that you may request a single payout, but it still should be
        formatted as an array with the single element.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/v1/payout",
            body=await async_maybe_transform(
                {
                    "ipn_callback_url": ipn_callback_url,
                    "payout_description": payout_description,
                    "withdrawals": withdrawals,
                },
                payout_create_params.PayoutCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PayoutCreateResponse,
        )

    async def list(
        self,
        *,
        batch_id: int | Omit = omit,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        limit: int | Omit = omit,
        order: str | Omit = omit,
        order_by: str | Omit = omit,
        page: int | Omit = omit,
        status: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutListResponse:
        """
        This endpoint allows you to get a list of your payouts.

        The list of available parameters:

        - batch_id: batch ID of enlisted payouts;
        - status: the statuses of enlisted payouts;
        - order_by: can be id, batchId, dateCreated, dateRequested, dateUpdated,
          currency, status;
        - order: 'asc' or 'desc' order;
        - date_from: beginning date of the requested payouts;
        - date_to: ending date of the requested payouts;
        - limit: a number of results to show;
        - page: the current page;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._get(
            "/v1/payout",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "batch_id": batch_id,
                        "date_from": date_from,
                        "date_to": date_to,
                        "limit": limit,
                        "order": order,
                        "order_by": order_by,
                        "page": page,
                        "status": status,
                    },
                    payout_list_params.PayoutListParams,
                ),
            ),
            cast_to=PayoutListResponse,
        )

    async def get_fee_estimate(
        self,
        *,
        amount: int | Omit = omit,
        currency: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutGetFeeEstimateResponse:
        """
        This endpoint will show you the estimated amount of network fee for payout.

        Please note that:

        - This endpoint will show you the fee estimate for the moment of the request is
          done. Fee itself is dynamic and may change over a brief moment of time.
        - The fee depends on the blockchain itself and its congestion. We cannot affect
          it in any way nor control or hold it.
        - The actual fee will be calcualated at the moment of payout processing. Please
          be aware that it can differ from estimate.

        Args:
          amount: The desired amount of your payout

          currency: The coin ticker of your payout

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._get(
            "/v1/payout/fee",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "amount": amount,
                        "currency": currency,
                    },
                    payout_get_fee_estimate_params.PayoutGetFeeEstimateParams,
                ),
            ),
            cast_to=PayoutGetFeeEstimateResponse,
        )

    async def retrieve_status(
        self,
        payout_id: str,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutRetrieveStatusResponse:
        """Get the actual information about the payout.

        You need to provide the ID of the
        payout in the request.

        NOTE! You should make the get payout status request with the same API key that
        you used in the creat_payout request.

        Here is the list of available statuses:

        - creating;
        - processing;
        - sending;
        - finished;
        - failed;
        - rejected;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payout_id:
            raise ValueError(f"Expected a non-empty value for `payout_id` but received {payout_id!r}")
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._get(
            f"/v1/payout/{payout_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PayoutRetrieveStatusResponse,
        )

    async def validate_address(
        self,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This endpoint allows you to check if your payout address is valid and funds can
        be received there.

        Available parameters:

        - address - the payout address;
        - currency - the ticker of payout currency;
        - (optional) extra_id - memo or destination tag, if applicable;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._post(
            "/v1/payout/validate-address",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def verify(
        self,
        batch_withdrawal_id: str,
        *,
        verification_code: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """This method is required to verify payouts by using your 2FA code.


        You’ll have 10 attempts to verify the payout. If it is not verified after 10
        attempts, the payout will remain in ‘creating’ status.
        Payout will be processed only when it is verified.

        If you have 2FA app enabled in your dashboard, payouts will accept 2FA code from
        your app. Otherwise the code for payouts validation will be sent to your
        registration email.

        Please take a note that unverified payouts will be automatically rejected in an
        hour after creation.

        Next is a description of the required request fields:

        - :batch-withdrawal-id - payout id you received in `2. Create payout` method;
        - verification_code - 2fa code you received with your Google Auth app or via
          email;

        In order to establish an automatic verification of payouts, you should switch
        2FA through the application.
        There are several libraries for different frameworks aimed on generating 2FA
        codes based on a secret key from your account settings, for example, Speakeasy
        for JavaScript.
        We do not recommend to change any default settings.

        ```
        const 2faVerificationCode = speakeasy.totp({
              your_2fa_secret_key,
              encoding: 'base32',
        })

        ```

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not batch_withdrawal_id:
            raise ValueError(
                f"Expected a non-empty value for `batch_withdrawal_id` but received {batch_withdrawal_id!r}"
            )
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            f"/v1/payout/{batch_withdrawal_id}/verify",
            body=await async_maybe_transform(
                {"verification_code": verification_code}, payout_verify_params.PayoutVerifyParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class PayoutResourceWithRawResponse:
    def __init__(self, payout: PayoutResource) -> None:
        self._payout = payout

        self.create = to_raw_response_wrapper(
            payout.create,
        )
        self.list = to_raw_response_wrapper(
            payout.list,
        )
        self.get_fee_estimate = to_raw_response_wrapper(
            payout.get_fee_estimate,
        )
        self.retrieve_status = to_raw_response_wrapper(
            payout.retrieve_status,
        )
        self.validate_address = to_raw_response_wrapper(
            payout.validate_address,
        )
        self.verify = to_raw_response_wrapper(
            payout.verify,
        )


class AsyncPayoutResourceWithRawResponse:
    def __init__(self, payout: AsyncPayoutResource) -> None:
        self._payout = payout

        self.create = async_to_raw_response_wrapper(
            payout.create,
        )
        self.list = async_to_raw_response_wrapper(
            payout.list,
        )
        self.get_fee_estimate = async_to_raw_response_wrapper(
            payout.get_fee_estimate,
        )
        self.retrieve_status = async_to_raw_response_wrapper(
            payout.retrieve_status,
        )
        self.validate_address = async_to_raw_response_wrapper(
            payout.validate_address,
        )
        self.verify = async_to_raw_response_wrapper(
            payout.verify,
        )


class PayoutResourceWithStreamingResponse:
    def __init__(self, payout: PayoutResource) -> None:
        self._payout = payout

        self.create = to_streamed_response_wrapper(
            payout.create,
        )
        self.list = to_streamed_response_wrapper(
            payout.list,
        )
        self.get_fee_estimate = to_streamed_response_wrapper(
            payout.get_fee_estimate,
        )
        self.retrieve_status = to_streamed_response_wrapper(
            payout.retrieve_status,
        )
        self.validate_address = to_streamed_response_wrapper(
            payout.validate_address,
        )
        self.verify = to_streamed_response_wrapper(
            payout.verify,
        )


class AsyncPayoutResourceWithStreamingResponse:
    def __init__(self, payout: AsyncPayoutResource) -> None:
        self._payout = payout

        self.create = async_to_streamed_response_wrapper(
            payout.create,
        )
        self.list = async_to_streamed_response_wrapper(
            payout.list,
        )
        self.get_fee_estimate = async_to_streamed_response_wrapper(
            payout.get_fee_estimate,
        )
        self.retrieve_status = async_to_streamed_response_wrapper(
            payout.retrieve_status,
        )
        self.validate_address = async_to_streamed_response_wrapper(
            payout.validate_address,
        )
        self.verify = async_to_streamed_response_wrapper(
            payout.verify,
        )
