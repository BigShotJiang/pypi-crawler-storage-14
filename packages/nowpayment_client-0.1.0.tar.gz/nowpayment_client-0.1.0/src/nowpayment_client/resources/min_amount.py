# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import min_amount_retrieve_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.min_amount_retrieve_response import MinAmountRetrieveResponse

__all__ = ["MinAmountResource", "AsyncMinAmountResource"]


class MinAmountResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> MinAmountResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return MinAmountResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MinAmountResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return MinAmountResourceWithStreamingResponse(self)

    def retrieve(
        self,
        *,
        currency_from: str | Omit = omit,
        currency_to: str | Omit = omit,
        fiat_equivalent: str | Omit = omit,
        is_fee_paid_by_user: str | Omit = omit,
        is_fixed_rate: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MinAmountRetrieveResponse:
        """
        Get the minimum payment amount for a specific pair.

        You can provide both currencies in the pair or just currency_from, and we will
        calculate the minimum payment amount for currency_from and currency which you
        have specified as the outcome in the Payment Settings.

        You can also specify one of the fiat currencies in the currency_from. In this
        case, the minimum payment will be calculated in this fiat currency.

        You can also add field fiat_equivalent (optional field) to get the fiat
        equivalent of the minimum amount.

        "is_fixed_rate", and "is_fee_paid_by_user" parameters allows you to see current
        minimum amounts for corresponsing flows (it may differ from the standard flow!)

        In the case of several outcome wallets we will calculate the minimum amount in
        the same way we route your payment to a specific wallet.

        #### SUCCESSFUL RESPONSE FIELDS

        | **Name**        | **Type** | **Description**                                                  |
        | --------------- | -------- | ---------------------------------------------------------------- |
        | currency_from   | String   | Payin currency                                                   |
        | currency_to     | String   | Outcome currency                                                 |
        | min_amount      | Float    | Minimal amount for payment using mentioned currencies            |
        | fiat_equivalent | Float    | (Optional) Get the fiat equivalent for calculated minimal amount |

        Args:
          currency_from: (Required) Payin currency

          currency_to: (Required) Outcome currency

          fiat_equivalent: (Optional) Mentioning ticker of any supported fiat currency you can get fiat
              equivalent of calculated minimal amount

          is_fee_paid_by_user: (Optional) Set this as true if you're using fee paid by user flow

          is_fixed_rate: (Optional) Set this as true if you're using fixed rate flow

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._get(
            "/v1/min-amount",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "currency_from": currency_from,
                        "currency_to": currency_to,
                        "fiat_equivalent": fiat_equivalent,
                        "is_fee_paid_by_user": is_fee_paid_by_user,
                        "is_fixed_rate": is_fixed_rate,
                    },
                    min_amount_retrieve_params.MinAmountRetrieveParams,
                ),
            ),
            cast_to=MinAmountRetrieveResponse,
        )


class AsyncMinAmountResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncMinAmountResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncMinAmountResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMinAmountResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncMinAmountResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        *,
        currency_from: str | Omit = omit,
        currency_to: str | Omit = omit,
        fiat_equivalent: str | Omit = omit,
        is_fee_paid_by_user: str | Omit = omit,
        is_fixed_rate: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MinAmountRetrieveResponse:
        """
        Get the minimum payment amount for a specific pair.

        You can provide both currencies in the pair or just currency_from, and we will
        calculate the minimum payment amount for currency_from and currency which you
        have specified as the outcome in the Payment Settings.

        You can also specify one of the fiat currencies in the currency_from. In this
        case, the minimum payment will be calculated in this fiat currency.

        You can also add field fiat_equivalent (optional field) to get the fiat
        equivalent of the minimum amount.

        "is_fixed_rate", and "is_fee_paid_by_user" parameters allows you to see current
        minimum amounts for corresponsing flows (it may differ from the standard flow!)

        In the case of several outcome wallets we will calculate the minimum amount in
        the same way we route your payment to a specific wallet.

        #### SUCCESSFUL RESPONSE FIELDS

        | **Name**        | **Type** | **Description**                                                  |
        | --------------- | -------- | ---------------------------------------------------------------- |
        | currency_from   | String   | Payin currency                                                   |
        | currency_to     | String   | Outcome currency                                                 |
        | min_amount      | Float    | Minimal amount for payment using mentioned currencies            |
        | fiat_equivalent | Float    | (Optional) Get the fiat equivalent for calculated minimal amount |

        Args:
          currency_from: (Required) Payin currency

          currency_to: (Required) Outcome currency

          fiat_equivalent: (Optional) Mentioning ticker of any supported fiat currency you can get fiat
              equivalent of calculated minimal amount

          is_fee_paid_by_user: (Optional) Set this as true if you're using fee paid by user flow

          is_fixed_rate: (Optional) Set this as true if you're using fixed rate flow

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._get(
            "/v1/min-amount",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "currency_from": currency_from,
                        "currency_to": currency_to,
                        "fiat_equivalent": fiat_equivalent,
                        "is_fee_paid_by_user": is_fee_paid_by_user,
                        "is_fixed_rate": is_fixed_rate,
                    },
                    min_amount_retrieve_params.MinAmountRetrieveParams,
                ),
            ),
            cast_to=MinAmountRetrieveResponse,
        )


class MinAmountResourceWithRawResponse:
    def __init__(self, min_amount: MinAmountResource) -> None:
        self._min_amount = min_amount

        self.retrieve = to_raw_response_wrapper(
            min_amount.retrieve,
        )


class AsyncMinAmountResourceWithRawResponse:
    def __init__(self, min_amount: AsyncMinAmountResource) -> None:
        self._min_amount = min_amount

        self.retrieve = async_to_raw_response_wrapper(
            min_amount.retrieve,
        )


class MinAmountResourceWithStreamingResponse:
    def __init__(self, min_amount: MinAmountResource) -> None:
        self._min_amount = min_amount

        self.retrieve = to_streamed_response_wrapper(
            min_amount.retrieve,
        )


class AsyncMinAmountResourceWithStreamingResponse:
    def __init__(self, min_amount: AsyncMinAmountResource) -> None:
        self._min_amount = min_amount

        self.retrieve = async_to_streamed_response_wrapper(
            min_amount.retrieve,
        )
