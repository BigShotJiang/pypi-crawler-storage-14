# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import strip_not_given
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options

__all__ = ["ConversionResource", "AsyncConversionResource"]


class ConversionResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ConversionResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return ConversionResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ConversionResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return ConversionResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This endpoint allows you to create conversions within your custody account.

        Parameters:

        - amount(required) - the amount of your conversion;
        - from_currency(required) - the currency you're converting your funds from;
        - to_currency(required) - the currency you're converting your funds to;

        The list of available statuses:

        - WAITING - the conversion is created and waiting to be executed;
        - PROCESSING - the conversion is in processing;
        - FINISHED - the conversion is completed;
        - REJECTED - for some reason, conversion failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._post(
            "/v1/conversion",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        conversion_id: str,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This method allows you to check the status of a certain conversion.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not conversion_id:
            raise ValueError(f"Expected a non-empty value for `conversion_id` but received {conversion_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            f"/v1/conversion/{conversion_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This endpoint returns you the list of your conversions with the essential info
        for each one.

        You can query only for certain conversions using the following parameters to
        filter the result:

        - id: int or array of int (optional) - filter by id of the conversion;
        - status: string or array of string(optional) - filter conversions by certain
          status;
        - from_currency: string(optional) - filter by initial currency of the
          conversion;
        - to_currency: string(optional), - filter by outcome currency of the conversion;
        - created_at_from: Date(optional), - filter by date;
        - created_at_to: Date(optional) - filter by date;
        - limit: (optional) default 10 - set the limit of shown results;
        - offset: (optional) default 0;
        - order: ASC / DESC (optional) - set the sorting order of provided data;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/conversion",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncConversionResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncConversionResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncConversionResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncConversionResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncConversionResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This endpoint allows you to create conversions within your custody account.

        Parameters:

        - amount(required) - the amount of your conversion;
        - from_currency(required) - the currency you're converting your funds from;
        - to_currency(required) - the currency you're converting your funds to;

        The list of available statuses:

        - WAITING - the conversion is created and waiting to be executed;
        - PROCESSING - the conversion is in processing;
        - FINISHED - the conversion is completed;
        - REJECTED - for some reason, conversion failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._post(
            "/v1/conversion",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        conversion_id: str,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This method allows you to check the status of a certain conversion.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not conversion_id:
            raise ValueError(f"Expected a non-empty value for `conversion_id` but received {conversion_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            f"/v1/conversion/{conversion_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def list(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This endpoint returns you the list of your conversions with the essential info
        for each one.

        You can query only for certain conversions using the following parameters to
        filter the result:

        - id: int or array of int (optional) - filter by id of the conversion;
        - status: string or array of string(optional) - filter conversions by certain
          status;
        - from_currency: string(optional) - filter by initial currency of the
          conversion;
        - to_currency: string(optional), - filter by outcome currency of the conversion;
        - created_at_from: Date(optional), - filter by date;
        - created_at_to: Date(optional) - filter by date;
        - limit: (optional) default 10 - set the limit of shown results;
        - offset: (optional) default 0;
        - order: ASC / DESC (optional) - set the sorting order of provided data;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/conversion",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class ConversionResourceWithRawResponse:
    def __init__(self, conversion: ConversionResource) -> None:
        self._conversion = conversion

        self.create = to_raw_response_wrapper(
            conversion.create,
        )
        self.retrieve = to_raw_response_wrapper(
            conversion.retrieve,
        )
        self.list = to_raw_response_wrapper(
            conversion.list,
        )


class AsyncConversionResourceWithRawResponse:
    def __init__(self, conversion: AsyncConversionResource) -> None:
        self._conversion = conversion

        self.create = async_to_raw_response_wrapper(
            conversion.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            conversion.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            conversion.list,
        )


class ConversionResourceWithStreamingResponse:
    def __init__(self, conversion: ConversionResource) -> None:
        self._conversion = conversion

        self.create = to_streamed_response_wrapper(
            conversion.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            conversion.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            conversion.list,
        )


class AsyncConversionResourceWithStreamingResponse:
    def __init__(self, conversion: AsyncConversionResource) -> None:
        self._conversion = conversion

        self.create = async_to_streamed_response_wrapper(
            conversion.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            conversion.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            conversion.list,
        )
