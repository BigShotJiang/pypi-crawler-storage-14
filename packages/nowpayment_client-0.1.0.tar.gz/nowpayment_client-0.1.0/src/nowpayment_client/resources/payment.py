# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import payment_list_params, payment_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.payment_create_response import PaymentCreateResponse
from ..types.payment_update_estimate_response import PaymentUpdateEstimateResponse

__all__ = ["PaymentResource", "AsyncPaymentResource"]


class PaymentResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return PaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return PaymentResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        ipn_callback_url: str | Omit = omit,
        is_fee_paid_by_user: bool | Omit = omit,
        is_fixed_rate: bool | Omit = omit,
        order_description: str | Omit = omit,
        order_id: str | Omit = omit,
        pay_currency: str | Omit = omit,
        price_amount: float | Omit = omit,
        price_currency: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateResponse:
        """Creates payment.

        With this method, your customer will be able to complete the
        payment without leaving your website.

        Be sure to consider the details of **repeated and wrong-asset deposits from
        'Repeated Deposits and Wrong-Asset Deposits' section** when processing payments.

        **Data must be sent as a JSON-object payload.**
        Required request fields:

        - price_amount (required) - the fiat equivalent of the price to be paid in
          crypto. If the pay_amount parameter is left empty, our system will
          automatically convert this fiat price into its crypto equivalent. Please note
          that this does not enable fiat payments, only provides a fiat price for yours
          and the customer’s convenience and information. **NOTE: Some of the assets
          (KISHU, NWC, FTT, CHR, XYM, SRK, KLV, SUPER, OM, XCUR, NOW, SHIB, SAND, MATIC,
          CTSI, MANA, FRONT, FTM, DAO, LGCY), have a maximum price amount of \\~~$2000;**
        - price_currency (required) - the fiat currency in which the price_amount is
          specified (usd, eur, etc);
        - pay_amount (optional) - the amount that users have to pay for the order stated
          in crypto. You can either specify it yourself, or we will automatically
          convert the amount you indicated in price_amount;
        - pay_currency (required) - the crypto currency in which the pay_amount is
          specified (btc, eth, etc), or one of available fiat currencies if it's enabled
          for your account (USD, EUR, ILS, GBP, AUD, RON);
           **NOTE: some of the currencies require a Memo, Destination Tag, etc., to complete
          a payment (AVA, EOS, BNBMAINNET, XLM, XRP). This is unique for each payment. This
          ID is received in “payin_extra_id” parameter of the response. Payments made without
          "payin_extra_id" cannot be detected automatically;**
        - ipn_callback_url (optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io);
        - order_id (optional) - inner store order ID, e.g. "RGDBP-21314";
        - order_description (optional) - inner store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - payout_address (optional) - usually the funds will go to the address you
          specify in your Personal account. In case you want to receive funds on another
          address, you can specify it in this parameter;
        - payout_currency (optional) - currency of your external payout_address,
          required when payout_adress is specified;
        - payout_extra_id(optional) - extra id or memo or tag for external
          payout_address;
        - is_fixed_rate(optional) - boolean, can be **true** or **false**. Required for
          fixed-rate exchanges;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired".
        - is_fee_paid_by_user(optional) - boolean, can be **true** or **false**.
          Required for fixed-rate exchanges with all fees paid by users;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired". The fee paid
          by user payment can be only fixed rate. If you disable fixed rate during payment
          creation process, this flag would enforce fixed_rate to be true;

        Here the list of available statuses of payment:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
           **Please note:** each currency has its own amount of confirmations required to
          start the processing.
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent less than the actual price.
          Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        **Please note: when you're creating a fiat2crypto payment you also should
        include additional header to your request - "origin-ip : xxx", where xxx is your
        customer IP address.**

        #### SUCCESSFUL RESPONSE FIELDS

        | **Name**                   | **Type** | **Description**                                                                                                                         |
        | -------------------------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------- |
        | payment_id                 | String   | Payment ID you can refer to                                                                                                             |
        | payment_status             | String   | Current status of the payment. On creation it supposed to be 'waiting'                                                                  |
        | pay_address                | String   | Address which is meant for customer to make a deposit to.                                                                               |
        | price_amount               | Float    | The amount you set as a price,                                                                                                          |
        | price_currency             | String   | Ticker of base currency                                                                                                                 |
        | pay_amount                 | Float    | Amount customer is meant to pay.                                                                                                        |
        | pay_currency               | String   | Deposit currency.                                                                                                                       |
        | order_id                   | String   | Order ID is a string for your internal identifier you can enter upon payment creation.                                                  |
        | order_description          | String   | Order description is a string for your convenience to describe anything about the payment for your own reference.                       |
        | ipn_callback_url           | String   | Link to your endpoint for IPN notifications catching                                                                                    |
        | created_at                 | String   | Time of payment creation                                                                                                                |
        | updated_at                 | String   | Time of latest payment information update                                                                                               |
        | purchase_id                | String   | Special identifier for handling partially_paid payments                                                                                 |
        | amount_received            | Float    | Estimate for amount you're intended to receive if customer would deposit full amount.                                                   |
        | payin_extra_id             | String   | (Optional) Deposit address' memo, if applied                                                                                            |
        | smart_contract             | String   |                                                                                                                                         |
        | network                    | String   | Network of deposit                                                                                                                      |
        | network_precision          | String   |                                                                                                                                         |
        | time_limit                 | String   |                                                                                                                                         |
        | expiration_estimate_date   | String   |                                                                                                                                         |
        | is_fixed_rate              | String   | This parameter is 'True' if Fixed Rate option is enabled and 'false' if it's disabled                                                   |
        | is_fee_paid_by_user        | String   | This parameter is 'True' if Fee Paid By User option is enabled and 'false' if it's disabled                                             |
        | valid_until                | String   | This parameter indicated when payment go expired.                                                                                       |
        | type                       | String   | Type of payment. It can be either crypto2crypto or fiat2crypto                                                                          |
        | redirectData: redirect_url | String   | (Optional) If you're using fiat2crypto flow, this parameter will appear with link to our fiat2crypto processing provider web interface. |

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._post(
            "/v1/payment",
            body=maybe_transform(
                {
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "order_description": order_description,
                    "order_id": order_id,
                    "pay_currency": pay_currency,
                    "price_amount": price_amount,
                    "price_currency": price_currency,
                },
                payment_create_params.PaymentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateResponse,
        )

    def retrieve(
        self,
        payment_id: str,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """Get the actual information about the payment.

        You need to provide the ID of the
        payment in the request.

        NOTE! You should make the get payment status request with the same API key that
        you used in the create payment request.
        Here is the list of available statuses:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - refunded - the funds were refunded back to the user;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        Additional info:

        - outcome_amount - this parameter shows the amount that will be (or is already)
          received on your Outcome Wallet once the transaction is settled;
        - outcome_currency - this parameter shows the currency in which the transaction
          will be settled;
        - invoice_id - this parameter shows invoice ID from which the payment was
          created;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_id:
            raise ValueError(f"Expected a non-empty value for `payment_id` but received {payment_id!r}")
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._get(
            f"/v1/payment/{payment_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )

    def list(
        self,
        *,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        invoice_id: int | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        page: int | Omit = omit,
        sort_by: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """Returns the entire list of all transactions created with certain API key.


        The list of optional parameters:

        - limit - number of records in one page. (possible values: from 1 to 500);
        - page - the page number you want to get (possible values: from 0 to **page
          count - 1**);
        - invoiceId - filtering payments by certain invoice ID;
        - sortBy - sort the received list by a paramenter. Set to **created_at** by
          default (possible values: payment_id, payment_status, pay_address,
          price_amount, price_currency, pay_amount, actually_paid, pay_currency,
          order_id, order_description, purchase_id, outcome_amount, outcome_currency);
        - orderBy - display the list in ascending or descending order. Set to **asc** by
          default (possible values: asc, desc);
        - dateFrom - select the displayed period start date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);
        - dateTo - select the displayed period end date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);

        Args:
          date_from: Parameters for filtering items by certain dates

          date_to: Parameters for filtering items by certain dates

          invoice_id: Filtering items by certain invoice ID

          limit: The limit of items listed in one page of response body. Possible values: from 1
              to 500

          order_by: Set the order of listed items. It can be 'asc' or 'desc'

          page: If amount of items is more than specified in 'limit' parameter, you can switch
              pages with this one. Possible values: from 0 to last existing page number digit.

          sort_by: Sorting by a certain parameter value

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/v1/payment/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "date_from": date_from,
                        "date_to": date_to,
                        "invoice_id": invoice_id,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "sort_by": sort_by,
                    },
                    payment_list_params.PaymentListParams,
                ),
            ),
            cast_to=object,
        )

    def update_estimate(
        self,
        id: str,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentUpdateEstimateResponse:
        """
        This endpoint is required to get the current estimate on the payment and update
        the current estimate.
        Please note! Calling this estimate before `expiration_estimate_date` will return
        the current estimate, it won’t be updated.

        `:id` - payment ID, for which you want to get the estimate

        Response:
        `id` - payment ID
        `token_id` - id of api key used to create this payment (please discard this
        parameter)
        `pay_amount` - payment estimate, the exact amount the user will have to send to
        complete the payment
        `expiration_estimate_date` - expiration date of this estimate

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._post(
            f"/v1/payment/{id}/update-merchant-estimate",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentUpdateEstimateResponse,
        )


class AsyncPaymentResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncPaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncPaymentResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        ipn_callback_url: str | Omit = omit,
        is_fee_paid_by_user: bool | Omit = omit,
        is_fixed_rate: bool | Omit = omit,
        order_description: str | Omit = omit,
        order_id: str | Omit = omit,
        pay_currency: str | Omit = omit,
        price_amount: float | Omit = omit,
        price_currency: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateResponse:
        """Creates payment.

        With this method, your customer will be able to complete the
        payment without leaving your website.

        Be sure to consider the details of **repeated and wrong-asset deposits from
        'Repeated Deposits and Wrong-Asset Deposits' section** when processing payments.

        **Data must be sent as a JSON-object payload.**
        Required request fields:

        - price_amount (required) - the fiat equivalent of the price to be paid in
          crypto. If the pay_amount parameter is left empty, our system will
          automatically convert this fiat price into its crypto equivalent. Please note
          that this does not enable fiat payments, only provides a fiat price for yours
          and the customer’s convenience and information. **NOTE: Some of the assets
          (KISHU, NWC, FTT, CHR, XYM, SRK, KLV, SUPER, OM, XCUR, NOW, SHIB, SAND, MATIC,
          CTSI, MANA, FRONT, FTM, DAO, LGCY), have a maximum price amount of \\~~$2000;**
        - price_currency (required) - the fiat currency in which the price_amount is
          specified (usd, eur, etc);
        - pay_amount (optional) - the amount that users have to pay for the order stated
          in crypto. You can either specify it yourself, or we will automatically
          convert the amount you indicated in price_amount;
        - pay_currency (required) - the crypto currency in which the pay_amount is
          specified (btc, eth, etc), or one of available fiat currencies if it's enabled
          for your account (USD, EUR, ILS, GBP, AUD, RON);
           **NOTE: some of the currencies require a Memo, Destination Tag, etc., to complete
          a payment (AVA, EOS, BNBMAINNET, XLM, XRP). This is unique for each payment. This
          ID is received in “payin_extra_id” parameter of the response. Payments made without
          "payin_extra_id" cannot be detected automatically;**
        - ipn_callback_url (optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io);
        - order_id (optional) - inner store order ID, e.g. "RGDBP-21314";
        - order_description (optional) - inner store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - payout_address (optional) - usually the funds will go to the address you
          specify in your Personal account. In case you want to receive funds on another
          address, you can specify it in this parameter;
        - payout_currency (optional) - currency of your external payout_address,
          required when payout_adress is specified;
        - payout_extra_id(optional) - extra id or memo or tag for external
          payout_address;
        - is_fixed_rate(optional) - boolean, can be **true** or **false**. Required for
          fixed-rate exchanges;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired".
        - is_fee_paid_by_user(optional) - boolean, can be **true** or **false**.
          Required for fixed-rate exchanges with all fees paid by users;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired". The fee paid
          by user payment can be only fixed rate. If you disable fixed rate during payment
          creation process, this flag would enforce fixed_rate to be true;

        Here the list of available statuses of payment:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
           **Please note:** each currency has its own amount of confirmations required to
          start the processing.
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent less than the actual price.
          Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        **Please note: when you're creating a fiat2crypto payment you also should
        include additional header to your request - "origin-ip : xxx", where xxx is your
        customer IP address.**

        #### SUCCESSFUL RESPONSE FIELDS

        | **Name**                   | **Type** | **Description**                                                                                                                         |
        | -------------------------- | -------- | --------------------------------------------------------------------------------------------------------------------------------------- |
        | payment_id                 | String   | Payment ID you can refer to                                                                                                             |
        | payment_status             | String   | Current status of the payment. On creation it supposed to be 'waiting'                                                                  |
        | pay_address                | String   | Address which is meant for customer to make a deposit to.                                                                               |
        | price_amount               | Float    | The amount you set as a price,                                                                                                          |
        | price_currency             | String   | Ticker of base currency                                                                                                                 |
        | pay_amount                 | Float    | Amount customer is meant to pay.                                                                                                        |
        | pay_currency               | String   | Deposit currency.                                                                                                                       |
        | order_id                   | String   | Order ID is a string for your internal identifier you can enter upon payment creation.                                                  |
        | order_description          | String   | Order description is a string for your convenience to describe anything about the payment for your own reference.                       |
        | ipn_callback_url           | String   | Link to your endpoint for IPN notifications catching                                                                                    |
        | created_at                 | String   | Time of payment creation                                                                                                                |
        | updated_at                 | String   | Time of latest payment information update                                                                                               |
        | purchase_id                | String   | Special identifier for handling partially_paid payments                                                                                 |
        | amount_received            | Float    | Estimate for amount you're intended to receive if customer would deposit full amount.                                                   |
        | payin_extra_id             | String   | (Optional) Deposit address' memo, if applied                                                                                            |
        | smart_contract             | String   |                                                                                                                                         |
        | network                    | String   | Network of deposit                                                                                                                      |
        | network_precision          | String   |                                                                                                                                         |
        | time_limit                 | String   |                                                                                                                                         |
        | expiration_estimate_date   | String   |                                                                                                                                         |
        | is_fixed_rate              | String   | This parameter is 'True' if Fixed Rate option is enabled and 'false' if it's disabled                                                   |
        | is_fee_paid_by_user        | String   | This parameter is 'True' if Fee Paid By User option is enabled and 'false' if it's disabled                                             |
        | valid_until                | String   | This parameter indicated when payment go expired.                                                                                       |
        | type                       | String   | Type of payment. It can be either crypto2crypto or fiat2crypto                                                                          |
        | redirectData: redirect_url | String   | (Optional) If you're using fiat2crypto flow, this parameter will appear with link to our fiat2crypto processing provider web interface. |

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._post(
            "/v1/payment",
            body=await async_maybe_transform(
                {
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "order_description": order_description,
                    "order_id": order_id,
                    "pay_currency": pay_currency,
                    "price_amount": price_amount,
                    "price_currency": price_currency,
                },
                payment_create_params.PaymentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateResponse,
        )

    async def retrieve(
        self,
        payment_id: str,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """Get the actual information about the payment.

        You need to provide the ID of the
        payment in the request.

        NOTE! You should make the get payment status request with the same API key that
        you used in the create payment request.
        Here is the list of available statuses:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - refunded - the funds were refunded back to the user;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        Additional info:

        - outcome_amount - this parameter shows the amount that will be (or is already)
          received on your Outcome Wallet once the transaction is settled;
        - outcome_currency - this parameter shows the currency in which the transaction
          will be settled;
        - invoice_id - this parameter shows invoice ID from which the payment was
          created;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_id:
            raise ValueError(f"Expected a non-empty value for `payment_id` but received {payment_id!r}")
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._get(
            f"/v1/payment/{payment_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )

    async def list(
        self,
        *,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        invoice_id: int | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        page: int | Omit = omit,
        sort_by: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """Returns the entire list of all transactions created with certain API key.


        The list of optional parameters:

        - limit - number of records in one page. (possible values: from 1 to 500);
        - page - the page number you want to get (possible values: from 0 to **page
          count - 1**);
        - invoiceId - filtering payments by certain invoice ID;
        - sortBy - sort the received list by a paramenter. Set to **created_at** by
          default (possible values: payment_id, payment_status, pay_address,
          price_amount, price_currency, pay_amount, actually_paid, pay_currency,
          order_id, order_description, purchase_id, outcome_amount, outcome_currency);
        - orderBy - display the list in ascending or descending order. Set to **asc** by
          default (possible values: asc, desc);
        - dateFrom - select the displayed period start date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);
        - dateTo - select the displayed period end date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);

        Args:
          date_from: Parameters for filtering items by certain dates

          date_to: Parameters for filtering items by certain dates

          invoice_id: Filtering items by certain invoice ID

          limit: The limit of items listed in one page of response body. Possible values: from 1
              to 500

          order_by: Set the order of listed items. It can be 'asc' or 'desc'

          page: If amount of items is more than specified in 'limit' parameter, you can switch
              pages with this one. Possible values: from 0 to last existing page number digit.

          sort_by: Sorting by a certain parameter value

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/v1/payment/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "date_from": date_from,
                        "date_to": date_to,
                        "invoice_id": invoice_id,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "sort_by": sort_by,
                    },
                    payment_list_params.PaymentListParams,
                ),
            ),
            cast_to=object,
        )

    async def update_estimate(
        self,
        id: str,
        *,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentUpdateEstimateResponse:
        """
        This endpoint is required to get the current estimate on the payment and update
        the current estimate.
        Please note! Calling this estimate before `expiration_estimate_date` will return
        the current estimate, it won’t be updated.

        `:id` - payment ID, for which you want to get the estimate

        Response:
        `id` - payment ID
        `token_id` - id of api key used to create this payment (please discard this
        parameter)
        `pay_amount` - payment estimate, the exact amount the user will have to send to
        complete the payment
        `expiration_estimate_date` - expiration date of this estimate

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._post(
            f"/v1/payment/{id}/update-merchant-estimate",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentUpdateEstimateResponse,
        )


class PaymentResourceWithRawResponse:
    def __init__(self, payment: PaymentResource) -> None:
        self._payment = payment

        self.create = to_raw_response_wrapper(
            payment.create,
        )
        self.retrieve = to_raw_response_wrapper(
            payment.retrieve,
        )
        self.list = to_raw_response_wrapper(
            payment.list,
        )
        self.update_estimate = to_raw_response_wrapper(
            payment.update_estimate,
        )


class AsyncPaymentResourceWithRawResponse:
    def __init__(self, payment: AsyncPaymentResource) -> None:
        self._payment = payment

        self.create = async_to_raw_response_wrapper(
            payment.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            payment.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            payment.list,
        )
        self.update_estimate = async_to_raw_response_wrapper(
            payment.update_estimate,
        )


class PaymentResourceWithStreamingResponse:
    def __init__(self, payment: PaymentResource) -> None:
        self._payment = payment

        self.create = to_streamed_response_wrapper(
            payment.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            payment.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            payment.list,
        )
        self.update_estimate = to_streamed_response_wrapper(
            payment.update_estimate,
        )


class AsyncPaymentResourceWithStreamingResponse:
    def __init__(self, payment: AsyncPaymentResource) -> None:
        self._payment = payment

        self.create = async_to_streamed_response_wrapper(
            payment.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            payment.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            payment.list,
        )
        self.update_estimate = async_to_streamed_response_wrapper(
            payment.update_estimate,
        )
