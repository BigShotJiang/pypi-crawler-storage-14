# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import invoice_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.invoice_create_response import InvoiceCreateResponse

__all__ = ["InvoiceResource", "AsyncInvoiceResource"]


class InvoiceResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> InvoiceResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return InvoiceResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> InvoiceResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return InvoiceResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        cancel_url: str | Omit = omit,
        ipn_callback_url: str | Omit = omit,
        is_fee_paid_by_user: bool | Omit = omit,
        is_fixed_rate: bool | Omit = omit,
        order_description: str | Omit = omit,
        order_id: str | Omit = omit,
        partially_paid_url: str | Omit = omit,
        price_amount: int | Omit = omit,
        price_currency: str | Omit = omit,
        success_url: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InvoiceCreateResponse:
        """Creates a payment link.

        With this method, the customer is required to follow the
        generated url to complete the payment. **Data must be sent as a JSON-object
        payload.**

        Request fields:

        - price_amount (required) - the amount that users have to pay for the order
          stated in fiat currency. In case you do not indicate the price in crypto, our
          system will automatically convert this fiat amount into its crypto equivalent.
          **NOTE: Some of the assets (KISHU, NWC, FTT, CHR, XYM, SRK, KLV, SUPER, OM,
          XCUR, NOW, SHIB, SAND, MATIC, CTSI, MANA, FRONT, FTM, DAO, LGCY), have a
          maximum price limit of \\~~$2000;**
        - price_currency (required) - the fiat currency in which the price_amount is
          specified (usd, eur, etc);
        - pay_currency (optional) - the specified crypto currency (btc, eth, etc), or
          one of available fiat currencies if it's enabled for your account (USD, EUR,
          ILS, GBP, AUD, RON);
           If not specified, can be chosen on the invoice_url
        - ipn_callback_url (optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io);
        - order_id (optional) - internal store order ID, e.g. "RGDBP-21314";
        - order_description (optional) - internal store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - success_url(optional) - url where the customer will be redirected after
          successful payment;
        - cancel_url(optional) - url where the customer will be redirected after failed
          payment;
        - is_fixed_rate(optional) - boolean, can be **true** or **false**. Required for
          fixed-rate exchanges;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired";
        - is_fee_paid_by_user(optional) - boolean, can be **true** or **false**.
          Required for fixed-rate exchanges with all fees paid by users;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired";

        #### SUCCESSFUL RESPONSE FIELDS

        | **Name**            | **Type** | **Description**                                                                                          |
        | ------------------- | -------- | -------------------------------------------------------------------------------------------------------- |
        | id                  | String   | Invoice ID                                                                                               |
        | token_id            | String   | Internal identifier                                                                                      |
        | order_id            | String   | Order ID specified in request                                                                            |
        | order_description   | String   | Order description specified in request                                                                   |
        | price_amount        | String   | Base price in fiat                                                                                       |
        | price_currency      | String   | Ticker of base fiat currency                                                                             |
        | pay_currency        | String   | Currency your customer will pay with. If it's 'null' your customer can choose currency in web interface. |
        | ipn_callback_url    | String   | Link to your endpoint for IPN notifications catching                                                     |
        | invoice_url         | String   | Link to the payment page that you can share with your customer                                           |
        | success_url         | String   | Customer will be redirected to this link once the payment is finished                                    |
        | cancel_url          | String   | Customer will be redirected to this link if the payment fails                                            |
        | partially_paid_url  | String   | Customer will be redirected to this link if the payment gets partially paid status                       |
        | payout_currency     | String   | Ticker of payout currency                                                                                |
        | created_at          | String   | Time of invoice creation                                                                                 |
        | updated_at          | String   | Time of latest invoice information update                                                                |
        | is_fixed_rate       | Boolean  | This parameter is 'True' if Fixed Rate option is enabled and 'false' if it's disabled                    |
        | is_fee_paid_by_user | Boolean  | This parameter is 'True' if Fee Paid By User option is enabled and 'false' if it's disabled              |

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return self._post(
            "/v1/invoice",
            body=maybe_transform(
                {
                    "cancel_url": cancel_url,
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "order_description": order_description,
                    "order_id": order_id,
                    "partially_paid_url": partially_paid_url,
                    "price_amount": price_amount,
                    "price_currency": price_currency,
                    "success_url": success_url,
                },
                invoice_create_params.InvoiceCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InvoiceCreateResponse,
        )


class AsyncInvoiceResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncInvoiceResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncInvoiceResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncInvoiceResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncInvoiceResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        cancel_url: str | Omit = omit,
        ipn_callback_url: str | Omit = omit,
        is_fee_paid_by_user: bool | Omit = omit,
        is_fixed_rate: bool | Omit = omit,
        order_description: str | Omit = omit,
        order_id: str | Omit = omit,
        partially_paid_url: str | Omit = omit,
        price_amount: int | Omit = omit,
        price_currency: str | Omit = omit,
        success_url: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InvoiceCreateResponse:
        """Creates a payment link.

        With this method, the customer is required to follow the
        generated url to complete the payment. **Data must be sent as a JSON-object
        payload.**

        Request fields:

        - price_amount (required) - the amount that users have to pay for the order
          stated in fiat currency. In case you do not indicate the price in crypto, our
          system will automatically convert this fiat amount into its crypto equivalent.
          **NOTE: Some of the assets (KISHU, NWC, FTT, CHR, XYM, SRK, KLV, SUPER, OM,
          XCUR, NOW, SHIB, SAND, MATIC, CTSI, MANA, FRONT, FTM, DAO, LGCY), have a
          maximum price limit of \\~~$2000;**
        - price_currency (required) - the fiat currency in which the price_amount is
          specified (usd, eur, etc);
        - pay_currency (optional) - the specified crypto currency (btc, eth, etc), or
          one of available fiat currencies if it's enabled for your account (USD, EUR,
          ILS, GBP, AUD, RON);
           If not specified, can be chosen on the invoice_url
        - ipn_callback_url (optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io);
        - order_id (optional) - internal store order ID, e.g. "RGDBP-21314";
        - order_description (optional) - internal store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - success_url(optional) - url where the customer will be redirected after
          successful payment;
        - cancel_url(optional) - url where the customer will be redirected after failed
          payment;
        - is_fixed_rate(optional) - boolean, can be **true** or **false**. Required for
          fixed-rate exchanges;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired";
        - is_fee_paid_by_user(optional) - boolean, can be **true** or **false**.
          Required for fixed-rate exchanges with all fees paid by users;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired";

        #### SUCCESSFUL RESPONSE FIELDS

        | **Name**            | **Type** | **Description**                                                                                          |
        | ------------------- | -------- | -------------------------------------------------------------------------------------------------------- |
        | id                  | String   | Invoice ID                                                                                               |
        | token_id            | String   | Internal identifier                                                                                      |
        | order_id            | String   | Order ID specified in request                                                                            |
        | order_description   | String   | Order description specified in request                                                                   |
        | price_amount        | String   | Base price in fiat                                                                                       |
        | price_currency      | String   | Ticker of base fiat currency                                                                             |
        | pay_currency        | String   | Currency your customer will pay with. If it's 'null' your customer can choose currency in web interface. |
        | ipn_callback_url    | String   | Link to your endpoint for IPN notifications catching                                                     |
        | invoice_url         | String   | Link to the payment page that you can share with your customer                                           |
        | success_url         | String   | Customer will be redirected to this link once the payment is finished                                    |
        | cancel_url          | String   | Customer will be redirected to this link if the payment fails                                            |
        | partially_paid_url  | String   | Customer will be redirected to this link if the payment gets partially paid status                       |
        | payout_currency     | String   | Ticker of payout currency                                                                                |
        | created_at          | String   | Time of invoice creation                                                                                 |
        | updated_at          | String   | Time of latest invoice information update                                                                |
        | is_fixed_rate       | Boolean  | This parameter is 'True' if Fixed Rate option is enabled and 'false' if it's disabled                    |
        | is_fee_paid_by_user | Boolean  | This parameter is 'True' if Fee Paid By User option is enabled and 'false' if it's disabled              |

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"x-api-key": x_api_key}), **(extra_headers or {})}
        return await self._post(
            "/v1/invoice",
            body=await async_maybe_transform(
                {
                    "cancel_url": cancel_url,
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "order_description": order_description,
                    "order_id": order_id,
                    "partially_paid_url": partially_paid_url,
                    "price_amount": price_amount,
                    "price_currency": price_currency,
                    "success_url": success_url,
                },
                invoice_create_params.InvoiceCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InvoiceCreateResponse,
        )


class InvoiceResourceWithRawResponse:
    def __init__(self, invoice: InvoiceResource) -> None:
        self._invoice = invoice

        self.create = to_raw_response_wrapper(
            invoice.create,
        )


class AsyncInvoiceResourceWithRawResponse:
    def __init__(self, invoice: AsyncInvoiceResource) -> None:
        self._invoice = invoice

        self.create = async_to_raw_response_wrapper(
            invoice.create,
        )


class InvoiceResourceWithStreamingResponse:
    def __init__(self, invoice: InvoiceResource) -> None:
        self._invoice = invoice

        self.create = to_streamed_response_wrapper(
            invoice.create,
        )


class AsyncInvoiceResourceWithStreamingResponse:
    def __init__(self, invoice: AsyncInvoiceResource) -> None:
        self._invoice = invoice

        self.create = async_to_streamed_response_wrapper(
            invoice.create,
        )
