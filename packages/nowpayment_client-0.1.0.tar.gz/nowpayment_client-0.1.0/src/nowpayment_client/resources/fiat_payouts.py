# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import (
    fiat_payout_list_payouts_params,
    fiat_payout_list_accounts_params,
    fiat_payout_create_account_params,
    fiat_payout_request_payout_params,
    fiat_payout_list_payment_methods_params,
    fiat_payout_list_crypto_currencies_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.fiat_payout_list_payouts_response import FiatPayoutListPayoutsResponse
from ..types.fiat_payout_list_accounts_response import FiatPayoutListAccountsResponse
from ..types.fiat_payout_create_account_response import FiatPayoutCreateAccountResponse
from ..types.fiat_payout_list_providers_response import FiatPayoutListProvidersResponse
from ..types.fiat_payout_request_payout_response import FiatPayoutRequestPayoutResponse
from ..types.fiat_payout_list_fiat_currencies_response import FiatPayoutListFiatCurrenciesResponse
from ..types.fiat_payout_list_crypto_currencies_response import FiatPayoutListCryptoCurrenciesResponse

__all__ = ["FiatPayoutsResource", "AsyncFiatPayoutsResource"]


class FiatPayoutsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> FiatPayoutsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return FiatPayoutsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FiatPayoutsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return FiatPayoutsResourceWithStreamingResponse(self)

    def create_account(
        self,
        *,
        country_code: str | Omit = omit,
        currency: str | Omit = omit,
        fields: fiat_payout_create_account_params.Fields | Omit = omit,
        payment_code: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutCreateAccountResponse:
        """
        With this endpoint you can submit your account information for further cashout
        in there.

        Please note that all parameters are mandatory and cannot be overwritten. Please
        be careful white submitting the data.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/v1/fiat-payouts/account",
            body=maybe_transform(
                {
                    "country_code": country_code,
                    "currency": currency,
                    "fields": fields,
                    "payment_code": payment_code,
                    "provider": provider,
                },
                fiat_payout_create_account_params.FiatPayoutCreateAccountParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutCreateAccountResponse,
        )

    def list_accounts(
        self,
        *,
        id: str | Omit = omit,
        currency: str | Omit = omit,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        filter: str | Omit = omit,
        limit: str | Omit = omit,
        order_by: str | Omit = omit,
        page: str | Omit = omit,
        provider: str | Omit = omit,
        sort_by: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListAccountsResponse:
        """
        This endpoint shows you a list of already submitted accounts you've created
        before.

        You can filter the output by any of presented parameters. These are completely
        optional for using this endpoint.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/fiat-payouts/accounts",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id": id,
                        "currency": currency,
                        "date_from": date_from,
                        "date_to": date_to,
                        "filter": filter,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "provider": provider,
                        "sort_by": sort_by,
                    },
                    fiat_payout_list_accounts_params.FiatPayoutListAccountsParams,
                ),
            ),
            cast_to=FiatPayoutListAccountsResponse,
        )

    def list_crypto_currencies(
        self,
        *,
        currency: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListCryptoCurrenciesResponse:
        """
        This endpoint shows you the list of available crypto currencies for your
        cashout.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/fiat-payouts/crypto-currencies",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "currency": currency,
                        "provider": provider,
                    },
                    fiat_payout_list_crypto_currencies_params.FiatPayoutListCryptoCurrenciesParams,
                ),
            ),
            cast_to=FiatPayoutListCryptoCurrenciesResponse,
        )

    def list_fiat_currencies(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListFiatCurrenciesResponse:
        """
        This endpoint shows you the list of available fiat currencies.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/fiat-payouts/fiat-currencies",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutListFiatCurrenciesResponse,
        )

    def list_payment_methods(
        self,
        *,
        currency: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        This endpoint shows you the list of available payment methods for chosen
        provider and currency.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/fiat-payouts/payment-methods",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "currency": currency,
                        "provider": provider,
                    },
                    fiat_payout_list_payment_methods_params.FiatPayoutListPaymentMethodsParams,
                ),
            ),
            cast_to=object,
        )

    def list_payouts(
        self,
        *,
        id: str | Omit = omit,
        crypto_currency: str | Omit = omit,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        fiat_currency: str | Omit = omit,
        filter: str | Omit = omit,
        limit: str | Omit = omit,
        order_by: str | Omit = omit,
        page: str | Omit = omit,
        provider: str | Omit = omit,
        provider_payout_id: str | Omit = omit,
        request_id: str | Omit = omit,
        sort_by: str | Omit = omit,
        status: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListPayoutsResponse:
        """
        This enpoint shows you the list of previously created payouts from your account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/fiat-payouts",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id": id,
                        "crypto_currency": crypto_currency,
                        "date_from": date_from,
                        "date_to": date_to,
                        "fiat_currency": fiat_currency,
                        "filter": filter,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "provider": provider,
                        "provider_payout_id": provider_payout_id,
                        "request_id": request_id,
                        "sort_by": sort_by,
                        "status": status,
                    },
                    fiat_payout_list_payouts_params.FiatPayoutListPayoutsParams,
                ),
            ),
            cast_to=FiatPayoutListPayoutsResponse,
        )

    def list_providers(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListProvidersResponse:
        """
        This endpoint shows you the list of available providers for your cashout.
        Choosing one of them is needed for further steps.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/fiat-payouts/providers",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutListProvidersResponse,
        )

    def request_payout(
        self,
        *,
        amount: int | Omit = omit,
        crypto_currency: str | Omit = omit,
        fiat_currency: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutRequestPayoutResponse:
        """
        This endpoint is meant to request the payout.

        Available statuses for payout:

        CREATING - the payout has been created and queued to be executed soon ;

        CONVERTING - (for any payout currency except USDTTRC20) your payout is being
        converted to USDTTRC20;

        DEPOSITING - payout amount is being sent to chosen service provider for further
        processing ;

        PROCESSING - payout is being processied at this stage;

        FINISHED - payout has been executed;

        FAILED - something went wrong. Most likely you can find out what exactly by
        reading error parameter;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/v1/fiat-payouts",
            body=maybe_transform(
                {
                    "amount": amount,
                    "crypto_currency": crypto_currency,
                    "fiat_currency": fiat_currency,
                    "provider": provider,
                },
                fiat_payout_request_payout_params.FiatPayoutRequestPayoutParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutRequestPayoutResponse,
        )


class AsyncFiatPayoutsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncFiatPayoutsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncFiatPayoutsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFiatPayoutsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncFiatPayoutsResourceWithStreamingResponse(self)

    async def create_account(
        self,
        *,
        country_code: str | Omit = omit,
        currency: str | Omit = omit,
        fields: fiat_payout_create_account_params.Fields | Omit = omit,
        payment_code: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutCreateAccountResponse:
        """
        With this endpoint you can submit your account information for further cashout
        in there.

        Please note that all parameters are mandatory and cannot be overwritten. Please
        be careful white submitting the data.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/v1/fiat-payouts/account",
            body=await async_maybe_transform(
                {
                    "country_code": country_code,
                    "currency": currency,
                    "fields": fields,
                    "payment_code": payment_code,
                    "provider": provider,
                },
                fiat_payout_create_account_params.FiatPayoutCreateAccountParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutCreateAccountResponse,
        )

    async def list_accounts(
        self,
        *,
        id: str | Omit = omit,
        currency: str | Omit = omit,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        filter: str | Omit = omit,
        limit: str | Omit = omit,
        order_by: str | Omit = omit,
        page: str | Omit = omit,
        provider: str | Omit = omit,
        sort_by: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListAccountsResponse:
        """
        This endpoint shows you a list of already submitted accounts you've created
        before.

        You can filter the output by any of presented parameters. These are completely
        optional for using this endpoint.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/fiat-payouts/accounts",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "id": id,
                        "currency": currency,
                        "date_from": date_from,
                        "date_to": date_to,
                        "filter": filter,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "provider": provider,
                        "sort_by": sort_by,
                    },
                    fiat_payout_list_accounts_params.FiatPayoutListAccountsParams,
                ),
            ),
            cast_to=FiatPayoutListAccountsResponse,
        )

    async def list_crypto_currencies(
        self,
        *,
        currency: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListCryptoCurrenciesResponse:
        """
        This endpoint shows you the list of available crypto currencies for your
        cashout.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/fiat-payouts/crypto-currencies",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "currency": currency,
                        "provider": provider,
                    },
                    fiat_payout_list_crypto_currencies_params.FiatPayoutListCryptoCurrenciesParams,
                ),
            ),
            cast_to=FiatPayoutListCryptoCurrenciesResponse,
        )

    async def list_fiat_currencies(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListFiatCurrenciesResponse:
        """
        This endpoint shows you the list of available fiat currencies.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/fiat-payouts/fiat-currencies",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutListFiatCurrenciesResponse,
        )

    async def list_payment_methods(
        self,
        *,
        currency: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        This endpoint shows you the list of available payment methods for chosen
        provider and currency.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/fiat-payouts/payment-methods",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "currency": currency,
                        "provider": provider,
                    },
                    fiat_payout_list_payment_methods_params.FiatPayoutListPaymentMethodsParams,
                ),
            ),
            cast_to=object,
        )

    async def list_payouts(
        self,
        *,
        id: str | Omit = omit,
        crypto_currency: str | Omit = omit,
        date_from: str | Omit = omit,
        date_to: str | Omit = omit,
        fiat_currency: str | Omit = omit,
        filter: str | Omit = omit,
        limit: str | Omit = omit,
        order_by: str | Omit = omit,
        page: str | Omit = omit,
        provider: str | Omit = omit,
        provider_payout_id: str | Omit = omit,
        request_id: str | Omit = omit,
        sort_by: str | Omit = omit,
        status: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListPayoutsResponse:
        """
        This enpoint shows you the list of previously created payouts from your account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/fiat-payouts",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "id": id,
                        "crypto_currency": crypto_currency,
                        "date_from": date_from,
                        "date_to": date_to,
                        "fiat_currency": fiat_currency,
                        "filter": filter,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "provider": provider,
                        "provider_payout_id": provider_payout_id,
                        "request_id": request_id,
                        "sort_by": sort_by,
                        "status": status,
                    },
                    fiat_payout_list_payouts_params.FiatPayoutListPayoutsParams,
                ),
            ),
            cast_to=FiatPayoutListPayoutsResponse,
        )

    async def list_providers(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutListProvidersResponse:
        """
        This endpoint shows you the list of available providers for your cashout.
        Choosing one of them is needed for further steps.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/fiat-payouts/providers",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutListProvidersResponse,
        )

    async def request_payout(
        self,
        *,
        amount: int | Omit = omit,
        crypto_currency: str | Omit = omit,
        fiat_currency: str | Omit = omit,
        provider: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FiatPayoutRequestPayoutResponse:
        """
        This endpoint is meant to request the payout.

        Available statuses for payout:

        CREATING - the payout has been created and queued to be executed soon ;

        CONVERTING - (for any payout currency except USDTTRC20) your payout is being
        converted to USDTTRC20;

        DEPOSITING - payout amount is being sent to chosen service provider for further
        processing ;

        PROCESSING - payout is being processied at this stage;

        FINISHED - payout has been executed;

        FAILED - something went wrong. Most likely you can find out what exactly by
        reading error parameter;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/v1/fiat-payouts",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "crypto_currency": crypto_currency,
                    "fiat_currency": fiat_currency,
                    "provider": provider,
                },
                fiat_payout_request_payout_params.FiatPayoutRequestPayoutParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FiatPayoutRequestPayoutResponse,
        )


class FiatPayoutsResourceWithRawResponse:
    def __init__(self, fiat_payouts: FiatPayoutsResource) -> None:
        self._fiat_payouts = fiat_payouts

        self.create_account = to_raw_response_wrapper(
            fiat_payouts.create_account,
        )
        self.list_accounts = to_raw_response_wrapper(
            fiat_payouts.list_accounts,
        )
        self.list_crypto_currencies = to_raw_response_wrapper(
            fiat_payouts.list_crypto_currencies,
        )
        self.list_fiat_currencies = to_raw_response_wrapper(
            fiat_payouts.list_fiat_currencies,
        )
        self.list_payment_methods = to_raw_response_wrapper(
            fiat_payouts.list_payment_methods,
        )
        self.list_payouts = to_raw_response_wrapper(
            fiat_payouts.list_payouts,
        )
        self.list_providers = to_raw_response_wrapper(
            fiat_payouts.list_providers,
        )
        self.request_payout = to_raw_response_wrapper(
            fiat_payouts.request_payout,
        )


class AsyncFiatPayoutsResourceWithRawResponse:
    def __init__(self, fiat_payouts: AsyncFiatPayoutsResource) -> None:
        self._fiat_payouts = fiat_payouts

        self.create_account = async_to_raw_response_wrapper(
            fiat_payouts.create_account,
        )
        self.list_accounts = async_to_raw_response_wrapper(
            fiat_payouts.list_accounts,
        )
        self.list_crypto_currencies = async_to_raw_response_wrapper(
            fiat_payouts.list_crypto_currencies,
        )
        self.list_fiat_currencies = async_to_raw_response_wrapper(
            fiat_payouts.list_fiat_currencies,
        )
        self.list_payment_methods = async_to_raw_response_wrapper(
            fiat_payouts.list_payment_methods,
        )
        self.list_payouts = async_to_raw_response_wrapper(
            fiat_payouts.list_payouts,
        )
        self.list_providers = async_to_raw_response_wrapper(
            fiat_payouts.list_providers,
        )
        self.request_payout = async_to_raw_response_wrapper(
            fiat_payouts.request_payout,
        )


class FiatPayoutsResourceWithStreamingResponse:
    def __init__(self, fiat_payouts: FiatPayoutsResource) -> None:
        self._fiat_payouts = fiat_payouts

        self.create_account = to_streamed_response_wrapper(
            fiat_payouts.create_account,
        )
        self.list_accounts = to_streamed_response_wrapper(
            fiat_payouts.list_accounts,
        )
        self.list_crypto_currencies = to_streamed_response_wrapper(
            fiat_payouts.list_crypto_currencies,
        )
        self.list_fiat_currencies = to_streamed_response_wrapper(
            fiat_payouts.list_fiat_currencies,
        )
        self.list_payment_methods = to_streamed_response_wrapper(
            fiat_payouts.list_payment_methods,
        )
        self.list_payouts = to_streamed_response_wrapper(
            fiat_payouts.list_payouts,
        )
        self.list_providers = to_streamed_response_wrapper(
            fiat_payouts.list_providers,
        )
        self.request_payout = to_streamed_response_wrapper(
            fiat_payouts.request_payout,
        )


class AsyncFiatPayoutsResourceWithStreamingResponse:
    def __init__(self, fiat_payouts: AsyncFiatPayoutsResource) -> None:
        self._fiat_payouts = fiat_payouts

        self.create_account = async_to_streamed_response_wrapper(
            fiat_payouts.create_account,
        )
        self.list_accounts = async_to_streamed_response_wrapper(
            fiat_payouts.list_accounts,
        )
        self.list_crypto_currencies = async_to_streamed_response_wrapper(
            fiat_payouts.list_crypto_currencies,
        )
        self.list_fiat_currencies = async_to_streamed_response_wrapper(
            fiat_payouts.list_fiat_currencies,
        )
        self.list_payment_methods = async_to_streamed_response_wrapper(
            fiat_payouts.list_payment_methods,
        )
        self.list_payouts = async_to_streamed_response_wrapper(
            fiat_payouts.list_payouts,
        )
        self.list_providers = async_to_streamed_response_wrapper(
            fiat_payouts.list_providers,
        )
        self.request_payout = async_to_streamed_response_wrapper(
            fiat_payouts.request_payout,
        )
