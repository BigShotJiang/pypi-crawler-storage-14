# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ...types import (
    sub_partner_list_params,
    sub_partner_create_deposit_params,
    sub_partner_create_payment_params,
    sub_partner_list_transfers_params,
    sub_partner_create_transfer_params,
    sub_partner_create_write_off_params,
)
from .balance import (
    BalanceResource,
    AsyncBalanceResource,
    BalanceResourceWithRawResponse,
    AsyncBalanceResourceWithRawResponse,
    BalanceResourceWithStreamingResponse,
    AsyncBalanceResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, strip_not_given, async_maybe_transform
from .transfer import (
    TransferResource,
    AsyncTransferResource,
    TransferResourceWithRawResponse,
    AsyncTransferResourceWithRawResponse,
    TransferResourceWithStreamingResponse,
    AsyncTransferResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options

__all__ = ["SubPartnerResource", "AsyncSubPartnerResource"]


class SubPartnerResource(SyncAPIResource):
    @cached_property
    def balance(self) -> BalanceResource:
        return BalanceResource(self._client)

    @cached_property
    def transfer(self) -> TransferResource:
        return TransferResource(self._client)

    @cached_property
    def with_raw_response(self) -> SubPartnerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return SubPartnerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SubPartnerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return SubPartnerResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        id: int | Omit = omit,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        order: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This method returns the entire list of your customers.

        Args:
          id: int or array of int (optional)

          limit: (optional) default 10

          offset: (optional) default 0

          order: ASC / DESC (optional) default ASC

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/sub-partner",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id": id,
                        "limit": limit,
                        "offset": offset,
                        "order": order,
                    },
                    sub_partner_list_params.SubPartnerListParams,
                ),
            ),
            cast_to=NoneType,
        )

    def create_deposit(
        self,
        *,
        amount: float | Omit = omit,
        currency: str | Omit = omit,
        sub_partner_id: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This is a method for transferring funds from your master account to a customer's
        one.
        The actual information about the transfer's status can be obtained via
        `Get transfer` method.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._post(
            "/v1/sub-partner/deposit",
            body=maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "sub_partner_id": sub_partner_id,
                },
                sub_partner_create_deposit_params.SubPartnerCreateDepositParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def create_payment(
        self,
        *,
        amount: int | Omit = omit,
        currency: str | Omit = omit,
        ipn_callback_url: str | Omit = omit,
        is_fee_paid_by_user: bool | Omit = omit,
        is_fixed_rate: bool | Omit = omit,
        sub_partner_id: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """This method allows you to top up a customer account with a general payment.


        You can check the actual payment status by using GET 9 `Get payment status`
        request.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/v1/sub-partner/payment",
            body=maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "sub_partner_id": sub_partner_id,
                },
                sub_partner_create_payment_params.SubPartnerCreatePaymentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def create_transfer(
        self,
        *,
        amount: float | Omit = omit,
        currency: str | Omit = omit,
        from_id: str | Omit = omit,
        to_id: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """This method allows creating transfers between users' accounts.


        You can check the transfer's status using `Get transfer` method.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._post(
            "/v1/sub-partner/transfer",
            body=maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "from_id": from_id,
                    "to_id": to_id,
                },
                sub_partner_create_transfer_params.SubPartnerCreateTransferParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def create_write_off(
        self,
        *,
        amount: float | Omit = omit,
        currency: str | Omit = omit,
        sub_partner_id: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        With this method you can withdraw funds from a customer's account and transfer
        them to your master account.

        The actual status of the transaction can be checked with `Get transfer` method.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._post(
            "/v1/sub-partner/write-off",
            body=maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "sub_partner_id": sub_partner_id,
                },
                sub_partner_create_write_off_params.SubPartnerCreateWriteOffParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_payments(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This method allows you to get the list of all payments generated for a
        particular customer.

        Request params:

        limit - amount of listed results
        page - set the offset for listed results
        id - filter by payment ID
        pay_currency - filter by deposit currency
        status - filter by status
        sub_partner_id - filter by sub-partner ID;
        date_from - filter by date (from);
        date_to - filter by date (to);
        orderBy - set the order for listed results (asc, desc);
        sortBy - sort results by 'id', 'status', 'pay_currency', 'created_at',
        'updated_at';

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/sub-partner/payments",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_transfers(
        self,
        *,
        id: int | Omit = omit,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        order: str | Omit = omit,
        status: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Returns the entire list of transfers created by your customers.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          id: int or array of int (optional)

          limit: (optional) default 10

          offset: (optional) default 0

          order: ASC / DESC (optional) default ASC

          status: string or array of string "WAITING"/"CREATED"/"FINISHED"/"REJECTED" (optional)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return self._get(
            "/v1/sub-partner/transfers",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id": id,
                        "limit": limit,
                        "offset": offset,
                        "order": order,
                        "status": status,
                    },
                    sub_partner_list_transfers_params.SubPartnerListTransfersParams,
                ),
            ),
            cast_to=NoneType,
        )


class AsyncSubPartnerResource(AsyncAPIResource):
    @cached_property
    def balance(self) -> AsyncBalanceResource:
        return AsyncBalanceResource(self._client)

    @cached_property
    def transfer(self) -> AsyncTransferResource:
        return AsyncTransferResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSubPartnerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncSubPartnerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSubPartnerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncSubPartnerResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        id: int | Omit = omit,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        order: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This method returns the entire list of your customers.

        Args:
          id: int or array of int (optional)

          limit: (optional) default 10

          offset: (optional) default 0

          order: ASC / DESC (optional) default ASC

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/sub-partner",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "id": id,
                        "limit": limit,
                        "offset": offset,
                        "order": order,
                    },
                    sub_partner_list_params.SubPartnerListParams,
                ),
            ),
            cast_to=NoneType,
        )

    async def create_deposit(
        self,
        *,
        amount: float | Omit = omit,
        currency: str | Omit = omit,
        sub_partner_id: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This is a method for transferring funds from your master account to a customer's
        one.
        The actual information about the transfer's status can be obtained via
        `Get transfer` method.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._post(
            "/v1/sub-partner/deposit",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "sub_partner_id": sub_partner_id,
                },
                sub_partner_create_deposit_params.SubPartnerCreateDepositParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def create_payment(
        self,
        *,
        amount: int | Omit = omit,
        currency: str | Omit = omit,
        ipn_callback_url: str | Omit = omit,
        is_fee_paid_by_user: bool | Omit = omit,
        is_fixed_rate: bool | Omit = omit,
        sub_partner_id: str | Omit = omit,
        authorization: str | Omit = omit,
        x_api_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """This method allows you to top up a customer account with a general payment.


        You can check the actual payment status by using GET 9 `Get payment status`
        request.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {
            **strip_not_given(
                {
                    "Authorization": authorization,
                    "x-api-key": x_api_key,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/v1/sub-partner/payment",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "sub_partner_id": sub_partner_id,
                },
                sub_partner_create_payment_params.SubPartnerCreatePaymentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def create_transfer(
        self,
        *,
        amount: float | Omit = omit,
        currency: str | Omit = omit,
        from_id: str | Omit = omit,
        to_id: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """This method allows creating transfers between users' accounts.


        You can check the transfer's status using `Get transfer` method.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._post(
            "/v1/sub-partner/transfer",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "from_id": from_id,
                    "to_id": to_id,
                },
                sub_partner_create_transfer_params.SubPartnerCreateTransferParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def create_write_off(
        self,
        *,
        amount: float | Omit = omit,
        currency: str | Omit = omit,
        sub_partner_id: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        With this method you can withdraw funds from a customer's account and transfer
        them to your master account.

        The actual status of the transaction can be checked with `Get transfer` method.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._post(
            "/v1/sub-partner/write-off",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "currency": currency,
                    "sub_partner_id": sub_partner_id,
                },
                sub_partner_create_write_off_params.SubPartnerCreateWriteOffParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def list_payments(
        self,
        *,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        This method allows you to get the list of all payments generated for a
        particular customer.

        Request params:

        limit - amount of listed results
        page - set the offset for listed results
        id - filter by payment ID
        pay_currency - filter by deposit currency
        status - filter by status
        sub_partner_id - filter by sub-partner ID;
        date_from - filter by date (from);
        date_to - filter by date (to);
        orderBy - set the order for listed results (asc, desc);
        sortBy - sort results by 'id', 'status', 'pay_currency', 'created_at',
        'updated_at';

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/sub-partner/payments",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def list_transfers(
        self,
        *,
        id: int | Omit = omit,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        order: str | Omit = omit,
        status: str | Omit = omit,
        authorization: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Returns the entire list of transfers created by your customers.

        The list of available statuses:

        - CREATED - the transfer is being created;
        - WAITING - the transfer is waiting for payment;
        - FINISHED - the transfer is completed;
        - REJECTED - for some reason, transaction failed;

        Args:
          id: int or array of int (optional)

          limit: (optional) default 10

          offset: (optional) default 0

          order: ASC / DESC (optional) default ASC

          status: string or array of string "WAITING"/"CREATED"/"FINISHED"/"REJECTED" (optional)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers = {**strip_not_given({"Authorization": authorization}), **(extra_headers or {})}
        return await self._get(
            "/v1/sub-partner/transfers",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "id": id,
                        "limit": limit,
                        "offset": offset,
                        "order": order,
                        "status": status,
                    },
                    sub_partner_list_transfers_params.SubPartnerListTransfersParams,
                ),
            ),
            cast_to=NoneType,
        )


class SubPartnerResourceWithRawResponse:
    def __init__(self, sub_partner: SubPartnerResource) -> None:
        self._sub_partner = sub_partner

        self.list = to_raw_response_wrapper(
            sub_partner.list,
        )
        self.create_deposit = to_raw_response_wrapper(
            sub_partner.create_deposit,
        )
        self.create_payment = to_raw_response_wrapper(
            sub_partner.create_payment,
        )
        self.create_transfer = to_raw_response_wrapper(
            sub_partner.create_transfer,
        )
        self.create_write_off = to_raw_response_wrapper(
            sub_partner.create_write_off,
        )
        self.list_payments = to_raw_response_wrapper(
            sub_partner.list_payments,
        )
        self.list_transfers = to_raw_response_wrapper(
            sub_partner.list_transfers,
        )

    @cached_property
    def balance(self) -> BalanceResourceWithRawResponse:
        return BalanceResourceWithRawResponse(self._sub_partner.balance)

    @cached_property
    def transfer(self) -> TransferResourceWithRawResponse:
        return TransferResourceWithRawResponse(self._sub_partner.transfer)


class AsyncSubPartnerResourceWithRawResponse:
    def __init__(self, sub_partner: AsyncSubPartnerResource) -> None:
        self._sub_partner = sub_partner

        self.list = async_to_raw_response_wrapper(
            sub_partner.list,
        )
        self.create_deposit = async_to_raw_response_wrapper(
            sub_partner.create_deposit,
        )
        self.create_payment = async_to_raw_response_wrapper(
            sub_partner.create_payment,
        )
        self.create_transfer = async_to_raw_response_wrapper(
            sub_partner.create_transfer,
        )
        self.create_write_off = async_to_raw_response_wrapper(
            sub_partner.create_write_off,
        )
        self.list_payments = async_to_raw_response_wrapper(
            sub_partner.list_payments,
        )
        self.list_transfers = async_to_raw_response_wrapper(
            sub_partner.list_transfers,
        )

    @cached_property
    def balance(self) -> AsyncBalanceResourceWithRawResponse:
        return AsyncBalanceResourceWithRawResponse(self._sub_partner.balance)

    @cached_property
    def transfer(self) -> AsyncTransferResourceWithRawResponse:
        return AsyncTransferResourceWithRawResponse(self._sub_partner.transfer)


class SubPartnerResourceWithStreamingResponse:
    def __init__(self, sub_partner: SubPartnerResource) -> None:
        self._sub_partner = sub_partner

        self.list = to_streamed_response_wrapper(
            sub_partner.list,
        )
        self.create_deposit = to_streamed_response_wrapper(
            sub_partner.create_deposit,
        )
        self.create_payment = to_streamed_response_wrapper(
            sub_partner.create_payment,
        )
        self.create_transfer = to_streamed_response_wrapper(
            sub_partner.create_transfer,
        )
        self.create_write_off = to_streamed_response_wrapper(
            sub_partner.create_write_off,
        )
        self.list_payments = to_streamed_response_wrapper(
            sub_partner.list_payments,
        )
        self.list_transfers = to_streamed_response_wrapper(
            sub_partner.list_transfers,
        )

    @cached_property
    def balance(self) -> BalanceResourceWithStreamingResponse:
        return BalanceResourceWithStreamingResponse(self._sub_partner.balance)

    @cached_property
    def transfer(self) -> TransferResourceWithStreamingResponse:
        return TransferResourceWithStreamingResponse(self._sub_partner.transfer)


class AsyncSubPartnerResourceWithStreamingResponse:
    def __init__(self, sub_partner: AsyncSubPartnerResource) -> None:
        self._sub_partner = sub_partner

        self.list = async_to_streamed_response_wrapper(
            sub_partner.list,
        )
        self.create_deposit = async_to_streamed_response_wrapper(
            sub_partner.create_deposit,
        )
        self.create_payment = async_to_streamed_response_wrapper(
            sub_partner.create_payment,
        )
        self.create_transfer = async_to_streamed_response_wrapper(
            sub_partner.create_transfer,
        )
        self.create_write_off = async_to_streamed_response_wrapper(
            sub_partner.create_write_off,
        )
        self.list_payments = async_to_streamed_response_wrapper(
            sub_partner.list_payments,
        )
        self.list_transfers = async_to_streamed_response_wrapper(
            sub_partner.list_transfers,
        )

    @cached_property
    def balance(self) -> AsyncBalanceResourceWithStreamingResponse:
        return AsyncBalanceResourceWithStreamingResponse(self._sub_partner.balance)

    @cached_property
    def transfer(self) -> AsyncTransferResourceWithStreamingResponse:
        return AsyncTransferResourceWithStreamingResponse(self._sub_partner.transfer)
