# Status

Types:

```python
from nowpayment_client.types import StatusRetrieveResponse
```

Methods:

- <code title="get /v1/status">client.status.<a href="./src/nowpayment_client/resources/status.py">retrieve</a>() -> <a href="./src/nowpayment_client/types/status_retrieve_response.py">StatusRetrieveResponse</a></code>

# Auth

Types:

```python
from nowpayment_client.types import AuthAuthenticateResponse
```

Methods:

- <code title="post /v1/auth">client.auth.<a href="./src/nowpayment_client/resources/auth.py">authenticate</a>(\*\*<a href="src/nowpayment_client/types/auth_authenticate_params.py">params</a>) -> <a href="./src/nowpayment_client/types/auth_authenticate_response.py">AuthAuthenticateResponse</a></code>

# Currencies

Types:

```python
from nowpayment_client.types import CurrencyListResponse
```

Methods:

- <code title="get /v1/currencies">client.currencies.<a href="./src/nowpayment_client/resources/currencies.py">list</a>(\*\*<a href="src/nowpayment_client/types/currency_list_params.py">params</a>) -> <a href="./src/nowpayment_client/types/currency_list_response.py">CurrencyListResponse</a></code>

# FullCurrencies

Methods:

- <code title="get /v1/full-currencies">client.full_currencies.<a href="./src/nowpayment_client/resources/full_currencies.py">list</a>() -> object</code>

# Merchant

Types:

```python
from nowpayment_client.types import MerchantListCoinsResponse
```

Methods:

- <code title="get /v1/merchant/coins">client.merchant.<a href="./src/nowpayment_client/resources/merchant.py">list_coins</a>() -> <a href="./src/nowpayment_client/types/merchant_list_coins_response.py">MerchantListCoinsResponse</a></code>

# MinAmount

Types:

```python
from nowpayment_client.types import MinAmountRetrieveResponse
```

Methods:

- <code title="get /v1/min-amount">client.min_amount.<a href="./src/nowpayment_client/resources/min_amount.py">retrieve</a>(\*\*<a href="src/nowpayment_client/types/min_amount_retrieve_params.py">params</a>) -> <a href="./src/nowpayment_client/types/min_amount_retrieve_response.py">MinAmountRetrieveResponse</a></code>

# Invoice

Types:

```python
from nowpayment_client.types import InvoiceCreateResponse
```

Methods:

- <code title="post /v1/invoice">client.invoice.<a href="./src/nowpayment_client/resources/invoice.py">create</a>(\*\*<a href="src/nowpayment_client/types/invoice_create_params.py">params</a>) -> <a href="./src/nowpayment_client/types/invoice_create_response.py">InvoiceCreateResponse</a></code>

# Payment

Types:

```python
from nowpayment_client.types import PaymentCreateResponse, PaymentUpdateEstimateResponse
```

Methods:

- <code title="post /v1/payment">client.payment.<a href="./src/nowpayment_client/resources/payment.py">create</a>(\*\*<a href="src/nowpayment_client/types/payment_create_params.py">params</a>) -> <a href="./src/nowpayment_client/types/payment_create_response.py">PaymentCreateResponse</a></code>
- <code title="get /v1/payment/{payment_id}">client.payment.<a href="./src/nowpayment_client/resources/payment.py">retrieve</a>(payment_id) -> object</code>
- <code title="get /v1/payment/">client.payment.<a href="./src/nowpayment_client/resources/payment.py">list</a>(\*\*<a href="src/nowpayment_client/types/payment_list_params.py">params</a>) -> object</code>
- <code title="post /v1/payment/{id}/update-merchant-estimate">client.payment.<a href="./src/nowpayment_client/resources/payment.py">update_estimate</a>(id) -> <a href="./src/nowpayment_client/types/payment_update_estimate_response.py">PaymentUpdateEstimateResponse</a></code>

# InvoicePayment

Types:

```python
from nowpayment_client.types import InvoicePaymentCreateResponse
```

Methods:

- <code title="post /v1/invoice-payment">client.invoice_payment.<a href="./src/nowpayment_client/resources/invoice_payment.py">create</a>(\*\*<a href="src/nowpayment_client/types/invoice_payment_create_params.py">params</a>) -> <a href="./src/nowpayment_client/types/invoice_payment_create_response.py">InvoicePaymentCreateResponse</a></code>

# Estimate

Types:

```python
from nowpayment_client.types import EstimateCalculateResponse
```

Methods:

- <code title="get /v1/estimate">client.estimate.<a href="./src/nowpayment_client/resources/estimate.py">calculate</a>(\*\*<a href="src/nowpayment_client/types/estimate_calculate_params.py">params</a>) -> <a href="./src/nowpayment_client/types/estimate_calculate_response.py">EstimateCalculateResponse</a></code>

# Balance

Types:

```python
from nowpayment_client.types import BalanceRetrieveResponse
```

Methods:

- <code title="get /v1/balance">client.balance.<a href="./src/nowpayment_client/resources/balance.py">retrieve</a>() -> <a href="./src/nowpayment_client/types/balance_retrieve_response.py">BalanceRetrieveResponse</a></code>

# Payout

Types:

```python
from nowpayment_client.types import (
    PayoutCreateResponse,
    PayoutListResponse,
    PayoutGetFeeEstimateResponse,
    PayoutRetrieveStatusResponse,
)
```

Methods:

- <code title="post /v1/payout">client.payout.<a href="./src/nowpayment_client/resources/payout.py">create</a>(\*\*<a href="src/nowpayment_client/types/payout_create_params.py">params</a>) -> <a href="./src/nowpayment_client/types/payout_create_response.py">PayoutCreateResponse</a></code>
- <code title="get /v1/payout">client.payout.<a href="./src/nowpayment_client/resources/payout.py">list</a>(\*\*<a href="src/nowpayment_client/types/payout_list_params.py">params</a>) -> <a href="./src/nowpayment_client/types/payout_list_response.py">PayoutListResponse</a></code>
- <code title="get /v1/payout/fee">client.payout.<a href="./src/nowpayment_client/resources/payout.py">get_fee_estimate</a>(\*\*<a href="src/nowpayment_client/types/payout_get_fee_estimate_params.py">params</a>) -> <a href="./src/nowpayment_client/types/payout_get_fee_estimate_response.py">PayoutGetFeeEstimateResponse</a></code>
- <code title="get /v1/payout/{payout_id}">client.payout.<a href="./src/nowpayment_client/resources/payout.py">retrieve_status</a>(payout_id) -> <a href="./src/nowpayment_client/types/payout_retrieve_status_response.py">PayoutRetrieveStatusResponse</a></code>
- <code title="post /v1/payout/validate-address">client.payout.<a href="./src/nowpayment_client/resources/payout.py">validate_address</a>() -> None</code>
- <code title="post /v1/payout/{batch-withdrawal-id}/verify">client.payout.<a href="./src/nowpayment_client/resources/payout.py">verify</a>(batch_withdrawal_id, \*\*<a href="src/nowpayment_client/types/payout_verify_params.py">params</a>) -> None</code>

# PayoutWithdrawal

Types:

```python
from nowpayment_client.types import PayoutWithdrawalRetrieveMinAmountResponse
```

Methods:

- <code title="get /v1/payout-withdrawal/min-amount/{coin}">client.payout_withdrawal.<a href="./src/nowpayment_client/resources/payout_withdrawal.py">retrieve_min_amount</a>(coin) -> <a href="./src/nowpayment_client/types/payout_withdrawal_retrieve_min_amount_response.py">PayoutWithdrawalRetrieveMinAmountResponse</a></code>

# Conversion

Methods:

- <code title="post /v1/conversion">client.conversion.<a href="./src/nowpayment_client/resources/conversion.py">create</a>() -> None</code>
- <code title="get /v1/conversion/{conversion_id}">client.conversion.<a href="./src/nowpayment_client/resources/conversion.py">retrieve</a>(conversion_id) -> None</code>
- <code title="get /v1/conversion">client.conversion.<a href="./src/nowpayment_client/resources/conversion.py">list</a>() -> None</code>

# SubPartner

Methods:

- <code title="get /v1/sub-partner">client.sub_partner.<a href="./src/nowpayment_client/resources/sub_partner/sub_partner.py">list</a>(\*\*<a href="src/nowpayment_client/types/sub_partner_list_params.py">params</a>) -> None</code>
- <code title="post /v1/sub-partner/deposit">client.sub_partner.<a href="./src/nowpayment_client/resources/sub_partner/sub_partner.py">create_deposit</a>(\*\*<a href="src/nowpayment_client/types/sub_partner_create_deposit_params.py">params</a>) -> None</code>
- <code title="post /v1/sub-partner/payment">client.sub_partner.<a href="./src/nowpayment_client/resources/sub_partner/sub_partner.py">create_payment</a>(\*\*<a href="src/nowpayment_client/types/sub_partner_create_payment_params.py">params</a>) -> None</code>
- <code title="post /v1/sub-partner/transfer">client.sub_partner.<a href="./src/nowpayment_client/resources/sub_partner/sub_partner.py">create_transfer</a>(\*\*<a href="src/nowpayment_client/types/sub_partner_create_transfer_params.py">params</a>) -> None</code>
- <code title="post /v1/sub-partner/write-off">client.sub_partner.<a href="./src/nowpayment_client/resources/sub_partner/sub_partner.py">create_write_off</a>(\*\*<a href="src/nowpayment_client/types/sub_partner_create_write_off_params.py">params</a>) -> None</code>
- <code title="get /v1/sub-partner/payments">client.sub_partner.<a href="./src/nowpayment_client/resources/sub_partner/sub_partner.py">list_payments</a>() -> None</code>
- <code title="get /v1/sub-partner/transfers">client.sub_partner.<a href="./src/nowpayment_client/resources/sub_partner/sub_partner.py">list_transfers</a>(\*\*<a href="src/nowpayment_client/types/sub_partner_list_transfers_params.py">params</a>) -> None</code>

## Balance

Methods:

- <code title="post /v1/sub-partner/balance">client.sub_partner.balance.<a href="./src/nowpayment_client/resources/sub_partner/balance.py">create</a>(\*\*<a href="src/nowpayment_client/types/sub_partner/balance_create_params.py">params</a>) -> None</code>
- <code title="get /v1/sub-partner/balance/{id}">client.sub_partner.balance.<a href="./src/nowpayment_client/resources/sub_partner/balance.py">retrieve</a>(id) -> None</code>

## Transfer

Methods:

- <code title="get /v1/sub-partner/transfer/{id}">client.sub_partner.transfer.<a href="./src/nowpayment_client/resources/sub_partner/transfer.py">retrieve</a>(id) -> None</code>

# Subscriptions

Methods:

- <code title="post /v1/subscriptions">client.subscriptions.<a href="./src/nowpayment_client/resources/subscriptions/subscriptions.py">create</a>(\*\*<a href="src/nowpayment_client/types/subscription_create_params.py">params</a>) -> None</code>
- <code title="get /v1/subscriptions/{sub_id}">client.subscriptions.<a href="./src/nowpayment_client/resources/subscriptions/subscriptions.py">retrieve</a>(sub_id) -> None</code>
- <code title="get /v1/subscriptions">client.subscriptions.<a href="./src/nowpayment_client/resources/subscriptions/subscriptions.py">list</a>(\*\*<a href="src/nowpayment_client/types/subscription_list_params.py">params</a>) -> None</code>
- <code title="delete /v1/subscriptions/{sub_id}">client.subscriptions.<a href="./src/nowpayment_client/resources/subscriptions/subscriptions.py">delete</a>(sub_id, \*\*<a href="src/nowpayment_client/types/subscription_delete_params.py">params</a>) -> None</code>

## Plans

Methods:

- <code title="post /v1/subscriptions/plans">client.subscriptions.plans.<a href="./src/nowpayment_client/resources/subscriptions/plans.py">create</a>(\*\*<a href="src/nowpayment_client/types/subscriptions/plan_create_params.py">params</a>) -> None</code>
- <code title="get /v1/subscriptions/plans/{plan-id}">client.subscriptions.plans.<a href="./src/nowpayment_client/resources/subscriptions/plans.py">retrieve</a>(plan_id) -> None</code>
- <code title="patch /v1/subscriptions/plans/{plan-id}">client.subscriptions.plans.<a href="./src/nowpayment_client/resources/subscriptions/plans.py">update</a>(plan_id, \*\*<a href="src/nowpayment_client/types/subscriptions/plan_update_params.py">params</a>) -> None</code>
- <code title="get /v1/subscriptions/plans">client.subscriptions.plans.<a href="./src/nowpayment_client/resources/subscriptions/plans.py">list</a>(\*\*<a href="src/nowpayment_client/types/subscriptions/plan_list_params.py">params</a>) -> None</code>

# FiatPayouts

Types:

```python
from nowpayment_client.types import (
    FiatPayoutCreateAccountResponse,
    FiatPayoutListAccountsResponse,
    FiatPayoutListCryptoCurrenciesResponse,
    FiatPayoutListFiatCurrenciesResponse,
    FiatPayoutListPayoutsResponse,
    FiatPayoutListProvidersResponse,
    FiatPayoutRequestPayoutResponse,
)
```

Methods:

- <code title="post /v1/fiat-payouts/account">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">create_account</a>(\*\*<a href="src/nowpayment_client/types/fiat_payout_create_account_params.py">params</a>) -> <a href="./src/nowpayment_client/types/fiat_payout_create_account_response.py">FiatPayoutCreateAccountResponse</a></code>
- <code title="get /v1/fiat-payouts/accounts">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">list_accounts</a>(\*\*<a href="src/nowpayment_client/types/fiat_payout_list_accounts_params.py">params</a>) -> <a href="./src/nowpayment_client/types/fiat_payout_list_accounts_response.py">FiatPayoutListAccountsResponse</a></code>
- <code title="get /v1/fiat-payouts/crypto-currencies">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">list_crypto_currencies</a>(\*\*<a href="src/nowpayment_client/types/fiat_payout_list_crypto_currencies_params.py">params</a>) -> <a href="./src/nowpayment_client/types/fiat_payout_list_crypto_currencies_response.py">FiatPayoutListCryptoCurrenciesResponse</a></code>
- <code title="get /v1/fiat-payouts/fiat-currencies">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">list_fiat_currencies</a>() -> <a href="./src/nowpayment_client/types/fiat_payout_list_fiat_currencies_response.py">FiatPayoutListFiatCurrenciesResponse</a></code>
- <code title="get /v1/fiat-payouts/payment-methods">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">list_payment_methods</a>(\*\*<a href="src/nowpayment_client/types/fiat_payout_list_payment_methods_params.py">params</a>) -> object</code>
- <code title="get /v1/fiat-payouts">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">list_payouts</a>(\*\*<a href="src/nowpayment_client/types/fiat_payout_list_payouts_params.py">params</a>) -> <a href="./src/nowpayment_client/types/fiat_payout_list_payouts_response.py">FiatPayoutListPayoutsResponse</a></code>
- <code title="get /v1/fiat-payouts/providers">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">list_providers</a>() -> <a href="./src/nowpayment_client/types/fiat_payout_list_providers_response.py">FiatPayoutListProvidersResponse</a></code>
- <code title="post /v1/fiat-payouts">client.fiat_payouts.<a href="./src/nowpayment_client/resources/fiat_payouts.py">request_payout</a>(\*\*<a href="src/nowpayment_client/types/fiat_payout_request_payout_params.py">params</a>) -> <a href="./src/nowpayment_client/types/fiat_payout_request_payout_response.py">FiatPayoutRequestPayoutResponse</a></code>
