# Seeds directory

`seed_users.csv` ships with the demo and feeds the staging model. Extend or replace it with your own CSV or Parquet files when experimenting.
