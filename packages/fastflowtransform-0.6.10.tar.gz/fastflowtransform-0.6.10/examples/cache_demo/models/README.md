# Models directory

Place SQL (`*.ff.sql`) and Python (`*.ff.py`) models here.
See docs/Config_and_Macros.md for modeling guidance and config options.
