# Seeds directory

Add CSV or Parquet files for reproducible seeds.
Usage examples are covered in docs/Quickstart.md and docs/Config_and_Macros.md#13-seeds-sources-and-dependencies.
