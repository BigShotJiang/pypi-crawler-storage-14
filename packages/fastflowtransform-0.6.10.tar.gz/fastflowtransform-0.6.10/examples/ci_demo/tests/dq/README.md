# Data quality tests

Store custom data-quality tests that run via `fft test` (docs/Data_Quality_Tests.md).
Use this directory for schema-bound tests separate from unit specs.
