"""Module for GreatStar quirks implementations."""

IMAGIC = "iMagic by GreatStar"
