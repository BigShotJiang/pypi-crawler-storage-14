"""Module for Sengled quirks implementations."""
