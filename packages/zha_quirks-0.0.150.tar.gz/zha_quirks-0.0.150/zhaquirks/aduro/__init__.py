"""ADUROLIGHT module for custom device handlers."""
