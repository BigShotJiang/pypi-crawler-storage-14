"""Module for HZC quirks implementations."""
