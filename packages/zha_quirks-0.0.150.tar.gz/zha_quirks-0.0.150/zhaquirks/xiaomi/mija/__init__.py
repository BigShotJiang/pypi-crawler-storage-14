"""Module for Xiaomi Mija implementations."""
