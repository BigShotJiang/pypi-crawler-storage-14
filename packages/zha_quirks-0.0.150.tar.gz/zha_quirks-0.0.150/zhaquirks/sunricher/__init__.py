"""Module for Sunricher devices."""
