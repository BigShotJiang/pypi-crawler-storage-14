"""Module for Aurora devices."""
