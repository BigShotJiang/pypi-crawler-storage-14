"""Module for Third Reality quirks."""

THIRD_REALITY = "Third Reality, Inc"
