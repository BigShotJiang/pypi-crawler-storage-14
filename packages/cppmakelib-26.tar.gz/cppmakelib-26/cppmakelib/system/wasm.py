class Wasm:
    name              = "wasm"
    executable_suffix = ".js"
    static_suffix     = ".a"
    shared_suffix     = ""
    compiler_path     = "em++"
