from .explainer import CONFETTI

__all__ = ["CONFETTI"]
