"""Unit tests for :mod:`esmf_regrid._esmf_sdo`."""
