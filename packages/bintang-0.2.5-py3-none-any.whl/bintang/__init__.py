# import core functions so it's accessable bintang.<func()>
from .core import get_similar_values
from .core import match
from .core import get_fuzzy_ratio
from .core import get_wb_type_toread
from .core import get_wb_type_towrite
# import Bintang class so it's visible via bintang.Bintang()
from .core import Bintang