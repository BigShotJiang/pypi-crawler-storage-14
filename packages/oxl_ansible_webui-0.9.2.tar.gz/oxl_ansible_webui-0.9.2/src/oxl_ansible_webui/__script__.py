# pylint: disable=W0611

from .__main__ import entrypoint as main
from .cli import main as cli
from .manage import main as manage
