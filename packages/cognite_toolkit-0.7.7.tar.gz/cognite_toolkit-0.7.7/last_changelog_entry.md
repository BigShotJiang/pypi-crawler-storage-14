## Changelog 

### Fixed

- The command `cdf data upload dir` no longer fails with `ValueError:
Invalid pattern: ...`