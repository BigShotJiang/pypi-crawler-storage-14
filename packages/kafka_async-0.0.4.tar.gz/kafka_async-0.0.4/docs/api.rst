API Reference
=============

.. py:currentmodule:: kafka_async

.. autoclass:: Producer
   :members:
   :undoc-members:

.. autoclass:: Consumer
   :members:
   :undoc-members:

.. autoclass:: AdminClient
   :members:
   :undoc-members:

.. autoclass:: FuturesDict
   :members:
   :undoc-members:
