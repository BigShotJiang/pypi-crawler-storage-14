.. include:: ../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :hidden:

   self
   api
