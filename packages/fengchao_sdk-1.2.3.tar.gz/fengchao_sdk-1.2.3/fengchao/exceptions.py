# -*- coding: utf-8 -*-
"""
异常定义
"""


class QunKongError(Exception):
    """SDK基础异常"""
    pass


class AuthError(QunKongError):
    """认证错误"""
    pass


class ConnectionError(QunKongError):
    """连接错误"""
    pass


class DeviceNotFoundError(QunKongError):
    """设备未找到"""
    pass


class TimeoutError(QunKongError):
    """操作超时"""
    pass


class ElementNotFoundError(QunKongError):
    """元素未找到"""
    pass


class MethodNotSupportedError(QunKongError):
    """方法不支持"""
    pass
