import asyncio
from typing import AsyncGenerator

import grpc

from geodrive.logging import get_logger
from ..commands import RoverCommands
from .base import BaseCommunicator
from ..generated import (
    RoverServiceStub,
    DifferentialCommand,
    LedCustomCommand,
    VelocityCommand,
    TelemetryData,
    GotoProgress,
    GotoCommand,
    BatteryData,
    RoverStatus,
    LedCommand,
    CommandAck,
    GotoAck,
    Empty
)

logger = get_logger("gRPC-communicator")


class AsyncGRPCCommunicator(BaseCommunicator):
    """
    Асинхронный gRPC клиент для управления ровером.

    Обеспечивает двустороннюю связь с роботом через gRPC протокол.
    Поддерживает отправку команд, получение телеметрии и потоковую передачу данных.

    :param host: IP-адрес или hostname ровера. По умолчанию "localhost"
    :type host: str
    :param port: Порт gRPC сервера. По умолчанию 5656
    :type port: int
    """

    def __init__(self, host: str = "localhost", port: int = 5656):
        super().__init__()
        self.host: str = host
        self.port: int = port
        self.channel: grpc.aio.Channel | None = None
        self.stub: RoverServiceStub | None = None
        self._is_connected: bool = False

        self._health_check = asyncio.Event()
        self._health_check_task: asyncio.Task | None = None
        self._health_check_interval: float = 0.5
        self._request_timeout = 0.5

    @property
    def is_connected(self) -> bool:
        """
        Проверить подключение к роверу.

        :return: True если подключение активно
        :rtype: bool
        """
        return self._is_connected

    async def _check_connection(self):
        """
        Проверка соединения
        """
        request = Empty()
        return await self.stub.get_status(request)

    async def _safe_grpc_call(self, coro, timeout: float = None):
        """Безопасный вызов с таймаутом"""
        if timeout is None:
            timeout = self._request_timeout

        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            self._is_connected = False
            raise ConnectionError(f"Request timed out after {timeout} seconds")
        except grpc.aio.AioRpcError as e:
            self._is_connected = False
            raise ConnectionError(f"gRPC error: {e.code()} - {e.details()}")
        except Exception as e:
            self._is_connected = False
            raise ConnectionError(f"Connection error: {e}")

    async def connect(self, inf_trying: bool = False) -> bool:
        """
        Установить соединение с ровером.

        Выполняет подключение к gRPC серверу ровера и проверяет доступность.

        :param inf_trying: Пытается подключиться пока не подключится, при True.
        :return: True если подключение успешно, False в случае ошибки
        :rtype: bool
        """
        while True:
            try:
                self.channel = grpc.aio.insecure_channel(f"{self.host}:{self.port}")
                self.stub = RoverServiceStub(self.channel)

                await asyncio.wait_for(
                    self._check_connection(),
                    timeout=5.0
                )

                self._is_connected = True

                if self._health_check_task is None:
                    self._health_check.set()
                    self._health_check_task = asyncio.create_task(
                        self._health_check_loop()
                    )

                return True

            except Exception:
                await self.disconnect()
                if not inf_trying:
                    return False
                await asyncio.sleep(3)

    async def disconnect(self):
        """
        Отключиться от ровера
        """
        if self._health_check_task:
            self._health_check.clear()
            self._health_check_task.cancel()
            try:
                await self._health_check_task
            except asyncio.CancelledError:
                pass
            self._health_check_task = None

        if self.channel:
            await self.channel.close()
            self.channel = None
            self.stub = None
            self._is_connected = False

    async def send_command(
            self,
            command: RoverCommands,
            **kwargs
    ) -> CommandAck:
        """
        Отправить команду роверу.

        :param command: Тип команды из RoverCommands
        :type command: RoverCommands
        :param kwargs: Параметры команды
        :return: Результат выполнения команды
        :rtype: CommandAck
        """
        request = Empty()
        coro = None

        match command:
            case RoverCommands.SET_VELOCITY:
                request = VelocityCommand(**kwargs)
                coro = self.stub.set_velocity(request)
            case RoverCommands.SET_DIFF_SPEED:
                request = DifferentialCommand(**kwargs)
                coro = self.stub.set_differential_speed(request)
            case RoverCommands.LED_CONTROL:
                request = LedCommand(**kwargs)
                coro = self.stub.led_control(request)
            case RoverCommands.LED_CUSTOM:
                request = LedCustomCommand(**kwargs)
                coro = self.stub.led_custom(request)
            case RoverCommands.STOP:
                coro = self.stub.stop(request)
            case RoverCommands.EMERGENCY_STOP:
                coro = self.stub.emergency_stop(request)
            case RoverCommands.GOTO_CANCEL:
                coro = self.stub.goto_cancel(request)
            case RoverCommands.BEEP:
                coro = self.stub.beep(request)
            case RoverCommands.MOO:
                coro = self.stub.moo(request)
            case _:
                pass
        if coro:
            return await self._safe_grpc_call(coro)
        return CommandAck(success=False, message="No command specified")

    async def get_status(self) -> RoverStatus:
        """
        Получить текущий статус ровера.

        :return: Объект статуса ровера
        :rtype: RoverStatus
        """
        return await self._safe_grpc_call(self.stub.get_status(Empty()))

    async def get_battery_status(self) -> BatteryData:
        """
        Получить данные о заряде батареи ровера.

        Возвращает данные о заряде батареи ровера.

        :return: Статус батареи с полями voltage и percentage
        :rtype: int
        """
        return await self._safe_grpc_call(self.stub.get_battery_status(Empty()))

    async def get_telemetry(self) -> TelemetryData:
        """
        Получить телеметрию ровера.

        Возвращает данные о положении, скорости и углах эйлера ровера.

        :return: Объект телеметрии
        :rtype: TelemetryData
        """
        return await self._safe_grpc_call(self.stub.get_telemetry(Empty()))

    async def stream_telemetry(self) -> AsyncGenerator[TelemetryData, None]:
        """
        Получить поток телеметрии в реальном времени.

        :return: Асинхронный генератор объектов TelemetryData
        :rtype: AsyncGenerator[TelemetryData, None]
        """
        request = Empty()
        try:
            async for response in self.stub.stream_telemetry(request):
                yield response
        except (grpc.aio.AioRpcError, Exception) as e:
            self._is_connected = False
            raise ConnectionError(f"Stream telemetry error: {e}")

    async def rc_stream(self, command_generator) -> AsyncGenerator[CommandAck, None]:
        """
        Безопасный RC стрим с обработкой ошибок
        """
        try:
            async for ack in self.stub.stream_rc_channels(command_generator):
                yield ack
        except grpc.aio.AioRpcError as e:
            raise ConnectionError(f"RC stream gRPC error: {e.code()} - {e.details()}")
        except Exception as e:
            raise ConnectionError(f"RC stream error: {e}")

    async def goto(
            self,
            x: float,
            y: float,
            yaw: float | None
    ) -> GotoAck:
        request = GotoCommand(target_x=x, target_y=y, target_yaw=yaw)
        return await self._safe_grpc_call(self.stub.goto(request))

    async def goto_stream_position(
            self,
            x: float,
            y: float,
            yaw: float | None=None
    ) -> AsyncGenerator[GotoProgress, None]:
        command = GotoCommand(target_x=x, target_y=y)
        if yaw is not None:
            command.target_yaw = yaw
        progress_stream = self.stub.goto_stream_position(command)

        async for progress in progress_stream:
            yield progress

    async def _health_check_loop(self):
        while self._health_check.is_set():
            try:
                if self.stub:
                    await asyncio.wait_for(
                        self.stub.get_status(Empty()),
                        timeout=1.0
                    )
                    self._is_connected = True
                else:
                    self._is_connected = False
            except (grpc.aio.AioRpcError, asyncio.TimeoutError, Exception):
                self._is_connected = False

            await asyncio.sleep(self._health_check_interval)
