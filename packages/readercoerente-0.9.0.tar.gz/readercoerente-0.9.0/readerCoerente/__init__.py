from .main import File, multipleFiles, detrend, read_config
