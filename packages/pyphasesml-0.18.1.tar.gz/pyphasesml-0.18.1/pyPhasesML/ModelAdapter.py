from .Model import Model


class ModelAdapter(Model):
    def initAdapter(self):
        pass
