import time
import hashlib
import requests
import threading
from typing import Optional, Dict, Any

# --- IMPORT ADAPTERS ---
try:
    from .brokers.alpaca import AlpacaAdapter
    from .brokers.ccxt_adapter import CCXTAdapter
    from .brokers.zerodha import ZerodhaAdapter
    from .brokers.angel_one import AngelOneAdapter
    from .brokers.ibkr import IBKRAdapter
except ImportError:
    pass  # Ignore missing adapters for now

from .ai_brain import AIBrain


class PnLWatchdog:
    """
    The central Watchdog class.
    Acts as a Factory to load the correct Broker Adapter and AI Brain.
    """

    def __init__(self, broker: str = "alpaca", pro_key: str = None, opt_in: bool = False, **kwargs):
        self.pro_key = pro_key  # The Gateway to Paid features
        self.opt_in = opt_in    # The Community Flag for anonymous data sharing

        # Production API URL
        self.api_url = "https://api.pnlwatchdog.com/v1"

        self.broker = broker.lower()
        self.brain = AIBrain()

        # Extract common arguments safely
        api_key = kwargs.get("api_key")
        api_secret = kwargs.get("api_secret")
        paper = kwargs.get("paper", True)

        # --- ADAPTER FACTORY LOGIC ---

        # 1. US STOCKS (Alpaca)
        if self.broker == "alpaca":
            self.adapter = AlpacaAdapter(api_key, api_secret, paper)

        # 2. INDIA (Zerodha)
        elif self.broker == "zerodha":
            self.adapter = ZerodhaAdapter(api_key, kwargs.get("access_token"))

        # 3. INDIA (Angel One)
        elif self.broker == "angel":
            self.adapter = AngelOneAdapter(
                api_key,
                kwargs.get("client_code"),
                kwargs.get("password"),
                kwargs.get("totp")
            )

        # 4. GLOBAL (Interactive Brokers)
        elif self.broker == "ibkr":
            self.adapter = IBKRAdapter(
                host=kwargs.get("host", '127.0.0.1'),
                port=kwargs.get("port", 7497)
            )

        # 5. CRYPTO (Binance, Kraken, Coinbase via CCXT)
        else:
            # This handles 'binance', 'bybit', etc.
            self.adapter = CCXTAdapter(self.broker, api_key, api_secret, paper)

    def check_order(self, symbol: str, side: str, qty: float, lookback_seconds: int = 60) -> bool:
        """
        Polls the broker to see if a matching trade occurred.
        """
        try:
            clean_symbol = self.adapter.normalize_symbol(symbol)
            orders = self.adapter.get_recent_orders(
                clean_symbol, lookback_seconds)

            for order in orders:
                # Fuzzy match on float qty
                is_qty_match = abs(
                    float(order['qty']) - float(qty)) < 0.00000001

                if (order['symbol'] == clean_symbol and
                    order['side'] == side and
                        is_qty_match):
                    return True

            return False
        except Exception as e:
            print(f"❌ Watchdog Check Error: {e}")
            return False

    def check_slippage(self, symbol: str, expected_price: float, filled_qty: float, threshold_cents: float = 5.0):
        """
        Alerts if the execution price was significantly worse than expected.
        """
        try:
            clean_symbol = self.adapter.normalize_symbol(symbol)
            orders = self.adapter.get_recent_orders(
                clean_symbol, lookback_seconds=60)

            matched_order = None
            for o in orders:
                if abs(float(o['qty']) - filled_qty) < 0.00000001:
                    matched_order = o
                    break

            if not matched_order:
                return

            fill_price = float(matched_order.get('price', 0.0))
            if fill_price == 0:
                return

            slippage = abs(fill_price - expected_price)

            if slippage > (threshold_cents / 100):
                print(
                    f"⚠️ HIGH SLIPPAGE on {clean_symbol}: Expected ${expected_price}, Got ${fill_price}. Diff: ${slippage:.2f}")
            else:
                print(f"✅ Slippage OK: ${slippage:.2f}")

        except Exception as e:
            print(f"❌ Slippage Check Error: {e}")

    def check_and_analyze(self, symbol: str, side: str, qty: float, expected_price: float) -> bool:
        """
        The AI-Powered Super Check: Verification + Metrics + AI Anomaly Detection + Cloud Sync.
        """
        try:
            clean_symbol = self.adapter.normalize_symbol(symbol)
            orders = self.adapter.get_recent_orders(
                clean_symbol, lookback_seconds=60)

            # 1. VERIFICATION
            matched_order = None
            for o in orders:
                if (o['symbol'] == clean_symbol and
                    o['side'] == side and
                        abs(float(o['qty']) - qty) < 0.00000001):
                    matched_order = o
                    break

            if not matched_order:
                print(f"🚨 CRITICAL: Trade MISSING for {symbol}!")
                return False

            # 2. METRICS
            fill_price = float(matched_order.get('price', expected_price))
            slippage = abs(fill_price - expected_price)

            order_ts = matched_order.get('timestamp', time.time() * 1000)
            latency_ms = max(0, (time.time() * 1000) - order_ts)

            print(
                f"📊 Analysis: Slippage=${slippage:.2f} | Latency={latency_ms:.0f}ms")

            # 3. AI BRAIN
            self.brain.learn(slippage, latency_ms)
            ai_report = self.brain.analyze(slippage, latency_ms)

            # Determine status based on AI report
            status = "anomaly" if ai_report["is_anomaly"] else "verified"

            if ai_report["is_anomaly"]:
                reasons = ", ".join(ai_report["reasons"])
                print(f"🤖 AI ALERT: Unusual execution detected! ({reasons})")

            # 4. CLOUD SYNC (Pro & Community)
            # Use threading so the user's bot isn't blocked by network requests

            # A. PRO UPLOAD (Private Log - Full Data)
            if self.pro_key:
                threading.Thread(target=self._upload_log, args=({
                    "symbol": symbol,
                    "side": side,
                    "qty": qty,
                    "broker": self.broker,
                    "latency_ms": latency_ms,
                    "slippage": slippage,
                    "status": status
                },)).start()

            # B. COMMUNITY UPLOAD (Anonymous Telemetry - Sanitized Data)
            elif self.opt_in:
                threading.Thread(target=self._upload_telemetry, args=({
                    "symbol": symbol,  # Will be hashed inside _upload_telemetry
                    "broker": self.broker,
                    "latency_ms": latency_ms,
                    "slippage": slippage,
                    "status": status
                },)).start()

            return True

        except Exception as e:
            print(f"❌ Watchdog Error: {e}")
            return False

    def _sanitize_payload(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Protects User Alpha.
        Removes sensitive trade details (Size, Side, Asset Name) before sending to Cloud.
        """
        # 1. Hash the Symbol (We can track 'Asset X' stats without knowing it's AAPL)
        if 'symbol' in data:
            encrypted_symbol = hashlib.sha256(
                data['symbol'].encode()).hexdigest()
        else:
            encrypted_symbol = "unknown"

        return {
            "symbol_hash": encrypted_symbol,  # Anonymized
            "broker": data['broker'],        # Safe (Infrastructure)
            "latency_ms": data['latency_ms'],  # Safe (The core value)
            "slippage": data['slippage'],    # Safe (Quality metric)
            "status": data['status']         # Safe (Health check)
            # STRIPPED: Side (Buy/Sell), Qty (Size), Price (Level)
        }

    def _upload_log(self, data):
        """Sends PRIVATE data to your SaaS backend (Pro Users only)"""
        try:
            headers = {"x-pro-key": self.pro_key}
            requests.post(f"{self.api_url}/log_trade",
                          json=data, headers=headers, timeout=2)
        except Exception as e:
            print(f"⚠️ Cloud Sync Failed: {e}")

    def _upload_telemetry(self, data):
        """Sends ANONYMOUS health stats to the global map (Free Users)"""
        try:
            # Sanitize the data first!
            safe_data = self._sanitize_payload(data)

            # No headers needed for public telemetry endpoint
            requests.post(f"{self.api_url}/telemetry",
                          json=safe_data, timeout=2)
        except Exception:
            pass  # Fail silently, never crash the bot
