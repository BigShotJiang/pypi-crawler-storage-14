event_funcs = ['server_config', 'push', 'pull', 'remove', 'run_local', 'run_serverside', 'call', 'loop']
call_conditions = ['init', 'before', 'before-deploy', 'after', 'after-deploy', 'after-sucess', 'after-failure', 'call']
    