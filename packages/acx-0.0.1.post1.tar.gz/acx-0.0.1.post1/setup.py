from setuptools import setup

setup(
    name="acx",
    version="0.0.1.post1",
    description="Reserved package name for upcoming ACX framework by AryCodes.",
    packages=["acx"],
    entry_points={
        "console_scripts": [
            "acx=acx.cli:main",
        ]
    }
)
