def main():
    print("ACX CLI is working!")
