# ACL Access Control Library

ACL Access Control is a lightweight but powerful Access Control List (ACL) and dynamic permission evaluation library designed for **FastAPI** and **SQLAlchemy** applications.  
It supports:

- Role → Permission relationship
- User → Roles membership
- ACL entity filtering by:
  - User level
  - Group level
  - Account level
- Dynamic SQL ACL repository
- Custom permission handlers
- Pluggable and DB-agnostic architecture

---

## 🚀 Installation

```bash
pip install acl-access-control
