# acl/models/group.py
import uuid
from sqlalchemy import Integer, String, ForeignKey
from sqlalchemy.orm import relationship, Mapped, mapped_column
from acl.db_base import Base

UUID_STR = String(36)

class IkonGroup(Base):
    __tablename__ = "ikon_groups"

    id: Mapped[str] = mapped_column(UUID_STR, primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), nullable=False)

    ikon_group_memberships: Mapped[list["IkonGroupMembership"]] = relationship(
        "IkonGroupMembership",
        back_populates="group",
        cascade="all, delete-orphan",
    )


class IkonGroupMembership(Base):
    __tablename__ = "ikon_group_memberships"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(UUID_STR, nullable=False)
    account_id: Mapped[str] = mapped_column(UUID_STR, nullable=False)
    group_id: Mapped[str] = mapped_column(UUID_STR, ForeignKey("ikon_groups.id"))

    group: Mapped[IkonGroup] = relationship("IkonGroup", back_populates="ikon_group_memberships")
