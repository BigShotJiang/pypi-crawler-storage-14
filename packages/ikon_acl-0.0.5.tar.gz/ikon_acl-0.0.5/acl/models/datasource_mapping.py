# acl/models/datasource_mapping.py
from sqlalchemy.orm import mapped_column, Mapped
from sqlalchemy import Integer, String
from acl.db_base import Base

class EntityDatasourceMapping(Base):
    __tablename__ = "entity_datasource_mappings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    datasource: Mapped[str] = mapped_column(String(50), nullable=False)  # e.g. SQL
    entity: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
