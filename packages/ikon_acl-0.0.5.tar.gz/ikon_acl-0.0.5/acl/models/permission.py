# acl/models/permission.py
from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from acl.db_base import Base

class Permission(Base):
    __tablename__ = "permissions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)

    def __repr__(self) -> str:
        return f"<Permission(id={self.id}, name={self.name})>"
