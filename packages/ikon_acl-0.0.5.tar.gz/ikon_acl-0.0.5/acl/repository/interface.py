# acl/repository/interface.py
from typing import Dict, Any, List, Optional, Type
from sqlalchemy.orm import Session


class DynamicAclRepository:
    """
    Interface for ACL repository implementations
    """

    def get_entities(
        self,
        db: Session,
        entity_class: Type[Any],
        entity_table_name: str,
        sql_query: Optional[str],
        filters: Optional[Dict[str, Any]],
        pagination: Optional[Dict[str, int]],
        current_user: str,
        account_id: str,
    ) -> List[Any]:
        raise NotImplementedError("Subclasses must implement get_entities()")
