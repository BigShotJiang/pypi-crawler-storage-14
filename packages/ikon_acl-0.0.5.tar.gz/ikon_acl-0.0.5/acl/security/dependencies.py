# acl/security/dependencies.py
from fastapi import Header
from sqlalchemy.orm import Session
from db import SessionLocal  # app using the library must supply its own db.py


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


async def get_current_user_id(x_user_id: str = Header(...)) -> str:
    """In real implementation decode JWT; here header carries UUID."""
    return x_user_id


async def get_current_account_id(x_account_id: str = Header(...)) -> str:
    return x_account_id
