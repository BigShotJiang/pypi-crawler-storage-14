# acl/security/permission_handler.py
from typing import Protocol, Any


class PermissionHandler(Protocol):
    def has_permission(self, authentication: Any, target: Any | None = None) -> bool:
        ...


permission_handler_registry: dict[str, PermissionHandler] = {}


def register_permission_handler(name: str, handler: PermissionHandler) -> None:
    permission_handler_registry[name] = handler
