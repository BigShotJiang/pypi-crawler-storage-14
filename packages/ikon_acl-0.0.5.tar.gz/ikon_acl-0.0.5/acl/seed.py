# seed_permissions.py
from sqlalchemy.orm import Session

from acl.models import Permission


def seed_default_permissions(db: Session) -> None:
    defaults = ["CREATE", "READ", "WRITE", "DELETE"]
    for name in defaults:
        existing = db.query(Permission).filter_by(name=name).first()
        if not existing:
            db.add(Permission(name=name))
    db.commit()
    print("Default permissions loaded.")
