""" recommended.py, Tools recommended to pip install, best to just copy ones you care
                    about.
"""
import sys

from typing import TextIO

def display_recs(file: TextIO = None) -> None:
    if not file:
        file = sys.stdout
    print('sudo apt install nvim', file=file)
    print(file=file)
    print('sudo apt install fzf', file=file)
    print('sudo apt install diff-so-fancy', file=file)
    print('sudo apt install vimdiff  # This may not be real and may come with vim for free', file=file)
