import sys

from typing import TextIO

def authorized_keys(host: str = 'myhost', file: TextIO = None) -> None:
    print('# Generate key', file=file)
    print('ssh-keygen', file=file)
    print('# Ssh into remote host', file=file)
    print(f'ssh {host}', file=file)
    
    print('mkdir -p ~/.ssh/', file=file)
    print('# copy local public key and add to authorized_keys', file=file)
    print(f'echo <local>~/.ssh/id_rsa.pub >> <remote>~/.ssh/authorized_keys', file=file)
