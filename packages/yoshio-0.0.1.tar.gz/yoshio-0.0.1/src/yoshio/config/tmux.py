""" tmux.py
"""


TMUXCONF = """
# General Options
set -g default-terminal "screen-256color" # Use 256 color support
setw -g mode-keys vi                     # Use vi style key bindings in copy mode
set -g history-limit 10000               # Increase history for long outputs

# Appearance
set -g status on                         # Enable status bar
set -g status-interval 2                 # Set update interval for status bar
set -g status-justify left               # Left-justify window lists
set -g status-bg black                   # Status bar background color
set -g status-fg white                   # Status bar foreground color
setw -g window-status-current-bg blue    # Current window background color in status bar

# Key Bindings (Keeping Ctrl+B as the prefix)
bind r source-file ~/.tmux.conf \; display "Config Reloaded!"  # Reload config
bind | split-window -h                   # Split panes horizontally
bind - split-window -v                   # Split panes vertically
unbind '"'                               # Remove default vertical split key
unbind %                                 # Remove default horizontal split key

# Mouse Support (tmux 2.1 and above)
set -g mouse on                          # Enable mouse support

# Set window title automatically
setw -g automatic-rename on
set-option -g set-titles on

# Activity Monitoring for Long-running Tasks
setw -g monitor-activity on
set -g visual-activity on
setw -g monitor-silence 30               # Alert after 30 seconds of silence
set -g visual-silence on

# Command Prompt
set -g command-prompt "Enter command: "

# Pane Resizing Shortcuts
bind -r H resize-pane -L 10              # Resize pane left
bind -r J resize-pane -D 10              # Resize pane down
bind -r K resize-pane -U 10              # Resize pane up
bind -r L resize-pane -R 10              # Resize pane right

# Status Bar Customization
set -g status-right "Load:#[fg=yellow]#{{load_average}} | %Y-%m-%d %H:%M "
set -g status-right-length 50

# Pane Border Styling
set -g pane-border-style fg=green
set -g pane-active-border-style fg=blue

# Notifications for Completed Tasks
set-hook -g pane-exited 'display "Task in pane #{{pane_id}} completed"'
"""
