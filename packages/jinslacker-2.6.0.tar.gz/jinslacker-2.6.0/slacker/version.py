#!/usr/bin/env python3

"""Set version."""

__version__ = '2.6.0'

if __name__ == '__main__':
    print(__version__)
