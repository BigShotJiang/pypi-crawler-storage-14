import xml.etree.ElementTree as ET

ET.register_namespace("fews", "http://www.wldelft.nl/fews")
ET.register_namespace("pi", "http://www.wldelft.nl/fews/PI")
