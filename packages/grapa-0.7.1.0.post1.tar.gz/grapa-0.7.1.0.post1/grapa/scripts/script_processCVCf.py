# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 23:57:53 2017

@author: Romain Carron
Copyright (c) 2025, Empa, Laboratory for Thin Films and Photovoltaics, Romain Carron
"""

import os
import sys
import copy
import warnings
from typing import Optional
from enum import Enum

import numpy as np
import matplotlib.pyplot as plt

path = os.path.normpath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
)
if path not in sys.path:
    sys.path.append(path)

from grapa.graph import Graph
from grapa.utils.parser_dispatcher import file_read_first3lines
from grapa.curve import Curve
from grapa.colorscale import Colorscale
from grapa.curve_image import Curve_Image
from grapa.mathModule import roundSignificant

from grapa.datatypes.graphCf import GraphCf
from grapa.datatypes.graphCV import GraphCV
from grapa.datatypes.curveCV import CurveCV
from grapa.datatypes.curveArrhenius import CurveArrheniusExtrapolToZero, CurveArrhenius


class LegendChoice(Enum):
    """Possibilities for show/hide legends"""

    NONE = "none"
    MINMAX = "minmax"
    ALL = "all"
    AUTO = "auto"


def mask_undesired_legends(graph: Graph, legend: LegendChoice):
    """
    mask undesired legends in Graph object
    legend: possible values: 'no', 'minmax', 'all'
    """
    if legend == LegendChoice.ALL:
        pass
    elif legend == LegendChoice.NONE:
        for curve in graph:
            curve.update({"labelhide": 1})
    else:  # legend == LegendChoice.MINMAX:
        for c in range(1, len(graph) - 1):
            graph[c].update({"labelhide": 1})


def _set_xlim(graph, keyword="tight"):
    if keyword != "tight":
        print("processCV Cf _set_xlim unknown keyword")
    xlim = [np.inf, -np.inf]
    for curve in graph:
        xlim = [min(xlim[0], min(curve.x())), max(xlim[1], max(curve.x()))]
    graph.update({"xlim": xlim})


def script_processCV(
    folder,
    legend: LegendChoice = LegendChoice.AUTO,  # "auto",
    ROIfit=None,
    ROIsmart=None,
    pltClose=True,
    newGraphKwargs: Optional[dict] = None,
):
    """Script process CV files in folder

    :param legend: possible values: 'none', 'minmax', 'all'
    """
    print("Script process C-V")
    if ROIfit is None:
        ROIfit = CurveCV.CST_MottSchottky_Vlim_def
    if ROIsmart is None:
        ROIsmart = CurveCV.CST_MottSchottky_Vlim_adaptative
    if newGraphKwargs is None:
        newGraphKwargs = {}
    ngkwargs = copy.deepcopy(newGraphKwargs)
    ngkwargs.update({"silent": True})

    DEFAULT_T = 300

    WARNINGS = []

    graph = Graph("", **ngkwargs)
    graph_phase = Graph("", **ngkwargs)
    graph_vbi = Graph("", **ngkwargs)
    # list possible files
    listdir = UtilsCv.listdir(folder)
    if len(listdir) == 0:
        print("Found no suitable file in folder", folder)
        return Graph("", **ngkwargs)

    # open all data files
    for file in listdir:
        print(file)
        #        with warnings.catch_warnings():
        with warnings.catch_warnings(record=True) as w:
            graph_tmp = Graph(
                os.path.join(folder, file),
                complement={"_CVLoadPhase": True},
                **ngkwargs
            )
        if len(w) > 0:
            for _ in w:
                WARNINGS.append(str(_.message))

        graph.append(graph_tmp[0])
        if len(graph) == 0:  # for graph cosmetics
            graph.update(graph_tmp.get_attributes())
        if len(graph_tmp) > 1:
            graph_phase.append(graph_tmp[1])
        else:
            graph_phase.append(Curve([[0], [0]], {}))

    # ThW admittance colorscale
    colorscale_thw = Colorscale(np.array([[1, 0.43, 0], [0, 0, 1]]), invert=True)
    graph.colorize(colorscale_thw)
    graph_phase.colorize(colorscale_thw)

    lbl = graph[-1].attr("label").replace(" K", "K").split(" ")
    lb0 = graph[0].attr("label").replace(" K", "K").split(" ")
    joined = " ".join(lbl[:-1])
    joine0 = " ".join(lb0[:-1])
    legendifauto = LegendChoice.ALL if joined != joine0 else LegendChoice.MINMAX
    if len(lbl) > 1:
        graph.update({"title": joined})
        graph_phase.update({"title": joined})
        if (
            legendifauto == LegendChoice.NONE
        ):  # later, will also remove most text of legend
            graph.replace_labels(joined, "")
            graph_phase.replace_labels(joined, "")
    graph_phase.update(
        {
            "xlabel": graph.attr("xlabel"),
            "ylabel": graph.formatAxisLabel("Impedance phase [°]"),
        }
    )
    # mask undesired legends
    if legend == LegendChoice.AUTO:
        legend = legendifauto
    mask_undesired_legends(graph, legend)
    mask_undesired_legends(graph_phase, legend)
    # set xlim
    _set_xlim(graph, "tight")
    _set_xlim(graph_phase, "tight")

    labels = graph.attr("xlabel"), graph.attr("ylabel")
    presets = UtilsCv.presets(graph, labels)

    # save
    plotargs = {}  # {'ifExport': False, 'ifSave': False}
    filesave = os.path.join(folder, graph.attr("title").replace(" ", "_") + "_")
    # graphIO.filesave_default(self)

    # default graph: C vs log(f)
    UtilsCv.plot_cv(graph, filesave, plotargs, pltClose, presets)
    # graph 2: Mott Schottky
    UtilsCv.plot_ms(graph, filesave, plotargs, pltClose, presets)
    # graph 3: N vs V
    UtilsCv.plot_nv(graph, filesave, plotargs, pltClose, presets)

    # graph 4: N vs depth
    # add doping V=0
    curves = []
    for curve in graph:
        # check that temperature is set
        if curve.attr("temperature [k]") == "":
            msg = "WARNING processCV file {} temperature [k] not found, set to {} K."
            msgfrm = msg.format(os.path.basename(curve.attr("filename")), DEFAULT_T)
            print(msgfrm)
            WARNINGS.append(msgfrm)
            curve.update({"temperature [k]": DEFAULT_T})
        # do required stuff
        tmp = curve.CurveCV_0V()
        if tmp is not False:
            tmp.update({"label": tmp.attr("label") + " Ncv @ 0V"})
            curves.append(tmp)
    graph.append(curves)

    UtilsCv.plot_nx(graph, filesave, plotargs, pltClose, presets)

    # save V=0 doping values
    n0v_t, n0v_n = [], []
    for curve in curves:
        n_values = curve.y(alter=presets["Nxlog"]["alter"][1])
        n0v_t.append(curve.attr("temperature [k]"))
        n0v_n.append(n_values[2])
    curve_n0v = Curve(
        [n0v_t, n0v_n],
        {
            "label": "N$_\\mathrm{CV}$ (0V)",
            "linestyle": "none",
            "linespec": "s",
            "markeredgewidth": 0,
            "color": "b",
        },
    )
    for c in range(len(graph) - 1, -1, -1):  # remove unnecessary curves
        if graph[c] in curves:
            graph.curve_delete(c)

    # Fit Mott-Schottky curves
    ncvminmax0 = [np.inf, -np.inf]
    ncvminmax1 = [np.inf, -np.inf]
    graph_vbi.append(Curve([[], []], CurveArrheniusExtrapolToZero.attr))
    graph_vbi.append(Curve([[], []], {"linestyle": "none"}))
    graph_vbi.append(Curve([[], []], CurveArrheniusExtrapolToZero.attr))
    graph_vbi.append(Curve([[], []], {"linestyle": "none"}))
    graph_vbi.append(curve_n0v)
    graph_smart = Graph("", **ngkwargs)
    num_curves = len(graph)
    for c in range(num_curves):  # number of Curves in graph will change
        cu: CurveCV = graph[c]
        cu.update({"linewidth": 0.25})
        new = cu.CurveCV_fitVbiN(ROIfit, silent=True)
        smart = cu.CurveCV_fitVbiN(
            cu.smartVlim_MottSchottky(Vlim=ROIsmart), silent=True
        )
        if isinstance(new, CurveCV):
            graph.append(new)
            graph[-1].update({"linespec": "--", "color": cu.attr("color")})
            vbi = new.attr("_popt")[0]
            ncv = new.attr("_popt")[1]
            graph_vbi[0].appendPoints([cu.attr("temperature [k]")], [vbi])
            graph_vbi[1].appendPoints([cu.attr("temperature [k]")], [ncv])
            ncvminmax0 = [min(ncvminmax0[0], ncv), max(ncvminmax0[1], ncv)]
        if isinstance(smart, CurveCV):
            graph_smart.append(smart)
            graph_smart[-1].update({"linespec": "--", "color": cu.attr("color")})
            vbi = smart.attr("_popt")[0]
            ncv = smart.attr("_popt")[1]
            graph_vbi[2].appendPoints([cu.attr("temperature [k]")], [vbi])
            graph_vbi[3].appendPoints([cu.attr("temperature [k]")], [ncv])
            ncvminmax1 = [min(ncvminmax1[0], ncv), max(ncvminmax1[1], ncv)]

    UtilsCv.plot_vbi(graph_vbi, filesave, plotargs, pltClose, presets)
    # Mott schottky, then N vs V, with fit curves - same Vlim
    UtilsCv.plot_savevlim(
        graph, filesave, plotargs, pltClose, presets, ncvminmax0, ROIfit
    )
    # Mott-Schottky, then N vs V, with fit lines - adaptative ROI
    for i in range(len(graph) - 1, num_curves - 1, -1):
        graph.curve_delete(i)
    graph.merge(graph_smart)
    UtilsCv.plot_adaptative(graph, filesave, plotargs, pltClose, presets, ncvminmax1)
    UtilsCv.plot_phase(graph_phase, filesave, plotargs, pltClose)
    graph.update({"legendtitle": "", "ylim": [0.5 * ncvminmax1[0], 5 * ncvminmax1[1]]})

    if len(WARNINGS) > 0:
        msg = "Enf of process C-V. Got warnings along the way. See above or summary"
        print(msg)
        for msg in WARNINGS:
            print(msg)
    else:
        print("End of process C-V, successful.")
    return graph


class UtilsCv:
    """Utility functions related to script CV"""

    @staticmethod
    def presets(graph: Graph, labels: tuple):
        """preset to configure output graphs of CV script"""
        presets = {}
        presets["default"] = {
            "ylim": [0, np.nan],
            "alter": "",
            "typeplot": "",
            "xlabel": labels[0],
            "ylabel": labels[1],
            "subplots_adjust": [0.16, 0.15],
        }
        presets["MS"] = {
            "ylim": "",
            "alter": ["", "CurveCV.y_ym2"],
            "typeplot": "",
            "ylabel": graph.formatAxisLabel(["1 / C$^2$", "", "nF$^{-2}$ cm$^{4}$"]),
            "xlabel": labels[0],
        }
        presets["NV"] = {
            "ylim": [0, np.nan],
            "typeplot": "",
            "alter": ["", "CurveCV.y_CV_Napparent"],
            "ylabel": graph.formatAxisLabel(
                ["Apparent doping density", "N_{CV}", "cm$^{-3}$"]
            ),
            "xlabel": labels[0],
        }
        presets["NVlog"] = copy.deepcopy(presets["NV"])
        presets["NVlog"].update({"ylim": "", "typeplot": "semilogy"})
        presets["Nx"] = {
            "ylim": [0, np.nan],
            "xlim": "",
            "alter": ["CurveCV.x_CVdepth_nm", "CurveCV.y_CV_Napparent"],
            "typeplot": "",
            "ylabel": graph.formatAxisLabel(
                ["Apparent doping density", "N_{CV}", "cm$^{-3}$"]
            ),
            "xlabel": graph.formatAxisLabel(["Apparent depth", "d", "nm"]),
        }
        presets["Nxlog"] = copy.deepcopy(presets["Nx"])
        presets["Nxlog"].update({"ylim": "", "typeplot": "semilogy"})
        return presets

    @staticmethod
    def listdir(folder):
        listdir = []
        for file in os.listdir(folder):
            if os.path.isfile(os.path.join(folder, file)):
                file_name, file_ext = os.path.splitext(file)
                file_ext = file_ext.lower()
                line1, line2, line3 = file_read_first3lines(os.path.join(folder, file))
                if GraphCV.isFileReadable(
                    file_name, file_ext, line1=line1, line2=line2, line3=line3
                ):
                    listdir.append(file)
        listdir.sort()
        return listdir

    @staticmethod
    def plot_phase(graph_phase: Graph, filesave, plotkwargs, pltclose):
        # graph phase
        graph_phase.update({"alter": "", "ylim": [0, 90]})
        f = graph_phase[0].x()
        curve = Curve(
            [[min(f), max(f)], [20, 20]],
            {"color": [1, 0, 0], "linewidth": 2, "linespec": "--"},
        )
        graph_phase.append(curve)
        graph_phase.plot(filesave=filesave + "phase", **plotkwargs)
        if pltclose:
            plt.close()

    @staticmethod
    def plot_adaptative(
        graph: Graph, filesave, plotkwargs, pltclose, presets, ncvminmax1
    ):
        graph.update(presets["MS"])
        graph.update({"legendtitle": "Mott-Schottky fit (adaptative Vlim)"})
        graph.plot(filesave=filesave + "MottSchottkyAdaptative", **plotkwargs)
        if pltclose:
            plt.close()
        graph.update(presets["NVlog"])
        graph.update({"ylim": [0.75 * ncvminmax1[0], 2.2 * ncvminmax1[1]]})
        graph.plot(filesave=filesave + "NVlogAdaptative", **plotkwargs)
        if pltclose:
            plt.close()

    @staticmethod
    def plot_savevlim(
        graph: Graph, filesave, plotkwargs, pltclose, presets, ncvminmax0, roifit
    ):
        graph.update(presets["MS"])
        graph.update({"legendtitle": "Mott-Schottky fit (same Vlim)"})
        graph.update({"axvline": roifit})
        graph.plot(filesave=filesave + "MottSchottkySameVlim", **plotkwargs)
        if pltclose:
            plt.close()
        graph.update(presets["NVlog"])
        graph.update({"ylim": [0.75 * ncvminmax0[0], 2.2 * ncvminmax0[1]]})
        graph.plot(filesave=filesave + "NVlogSameVlim", **plotkwargs)
        if pltclose:
            plt.close()
        graph.update({"axvline": "", "legendtitle": ""})

    @staticmethod
    def plot_vbi(graph_vbi: Graph, filesave, plotkwargs, pltclose, presets):
        graph_vbi.update({"legendtitle": "Mott-Schottky fit"})
        graph_vbi[0].update(
            {
                "linespec": "o",
                "color": "k",
                "label": "Built-in voltage (same Vlim)",
                "markeredgewidth": 0,
            }
        )
        graph_vbi[1].update(
            {"linespec": "x", "color": "k", "label": "N$_\\mathrm{CV}$ (same Vlim)"}
        )
        graph_vbi[2].update(
            {
                "linespec": "o",
                "color": "r",
                "label": "Built-in voltage (adaptative Vlim)",
                "markeredgewidth": 0,
            }
        )
        graph_vbi[3].update(
            {
                "linespec": "x",
                "color": "r",
                "label": "N$_\\mathrm{CV}$ (adaptative Vlim)",
            }
        )
        graph_vbi.update(
            {
                "xlabel": graph_vbi.formatAxisLabel(["Temperature", "T", "K"]),
                "ylabel": graph_vbi.formatAxisLabel(
                    ["Built-in voltage", "V_{bi}", "V"]
                ),
            }
        )
        graph_vbi.plot(filesave=filesave + "VbiT", **plotkwargs)
        if pltclose:
            plt.close()
        for curve in graph_vbi:
            curve.visible(not curve.visible())
        graph_vbi.update(
            {
                "xlabel": graph_vbi.formatAxisLabel(["Temperature", "T", "K"]),
                "ylabel": presets["NV"]["ylabel"],
                "typeplot": "semilogy",
            }
        )
        graph_vbi.plot(filesave=filesave + "NcvT", **plotkwargs)
        if pltclose:
            plt.close()

    @staticmethod
    def plot_nx(graph: Graph, filesave, plotkwargs, pltclose, presets):
        graph.update(presets["Nx"])
        graph.plot(filesave=filesave + "Ndepth", **plotkwargs)
        if pltclose:
            plt.close()
        graph.update(presets["Nxlog"])
        graph.plot(filesave=filesave + "Ndepthlog", **plotkwargs)
        if pltclose:
            plt.close()

    @staticmethod
    def plot_nv(graph: Graph, filesave, plotkwargs, pltclose, presets):
        graph.update(presets["NV"])
        graph.plot(filesave=filesave + "NV", **plotkwargs)
        if pltclose:
            plt.close()
        graph.update(presets["NVlog"])
        graph.plot(filesave=filesave + "NVlog", **plotkwargs)
        if pltclose:
            plt.close()

    @staticmethod
    def plot_ms(graph: Graph, filesave, plotkwargs, pltclose, presets):
        graph.update(presets["MS"])
        graph.plot(filesave=filesave + "MottSchottky", **plotkwargs)
        if pltclose:
            plt.close()

    @staticmethod
    def plot_cv(graph: Graph, filesave, plotkwargs, pltclose, presets):
        graph.update(presets["default"])
        graph.plot(filesave=filesave + "CV", **plotkwargs)
        if pltclose:
            plt.close()


def script_processCf(
    folder,
    legend: LegendChoice = LegendChoice.MINMAX,
    pltClose=True,
    newGraphKwargs: Optional[dict] = None,
):
    """
    legend: possible values: 'none', 'minmax', 'all'
    """
    print("Script process C-f")
    if newGraphKwargs is None:
        newGraphKwargs = {}
    newGraphKwargs = copy.deepcopy(newGraphKwargs)
    newGraphKwargs.update({"silent": True})
    graph = Graph("", **newGraphKwargs)
    graph_phase = Graph("", **newGraphKwargs)
    graph_nyqui = Graph("", **newGraphKwargs)
    graph_bode = Graph("", **newGraphKwargs)

    # list possible files
    listdir = []
    for file in os.listdir(folder):
        if os.path.isfile(os.path.join(folder, file)):
            filename, fileext = os.path.splitext(file)
            fileext = fileext.lower()
            line1, line2, line3 = file_read_first3lines(os.path.join(folder, file))
            if GraphCf.isFileReadable(
                filename, fileext, line1=line1, line2=line2, line3=line3
            ):
                listdir.append(file)
    if len(listdir) == 0:
        print("Found no suitable file in folder", folder)
        return None
    listdir.sort()

    # open all data files
    for file in listdir:
        print(file)
        graph_tmp = Graph(
            os.path.join(folder, file),
            complement={"_CfLoadPhase": True, "_CfLoadNyquist": True},
            **newGraphKwargs
        )
        if len(graph) == 0:
            graph.update(graph_tmp.get_attributes())
        graph.append(graph_tmp[0])  # append C-f

        if len(graph_tmp) > 1:
            dataz, dataphase = None, None
            for curve in graph_tmp:
                if curve.attr("_CfPhase", False):
                    graph_phase.append(curve)
                    dataphase = curve.x(), curve.y()
                    graph_bode.append(
                        Curve([curve.x(), curve.y()], curve.get_attributes())
                    )
                    graph_bode[-1].update({"ax_twinx": 1, "linespec": "--"})
                if curve.attr("_CfNyquist", False):
                    graph_nyqui.append(curve)
                    dataz = curve.x(), curve.y()
            if dataz is not None and dataphase is not None:
                graph_bode.append(
                    Curve(
                        [dataphase[0], np.sqrt(dataz[0] ** 2 + dataz[1] ** 2)],
                        graph_tmp[0].get_attributes(),
                    )
                )
                graph_bode[-1].update({"label": ""})

    # colorize curves
    colorscale_thw = Colorscale(np.array([[1, 0.43, 0], [0, 0, 1]]), invert=True)
    graph.colorize(colorscale_thw)
    graph_phase.colorize(colorscale_thw)
    graph_nyqui.colorize(colorscale_thw)
    graph_bode.colorize(colorscale_thw, sameIfEmptyLabel=True)
    # title, labels
    lbl = graph[-1].attr("label").replace(" K", "K").split(" ")
    if len(lbl) > 1:
        # title
        graph.update({"title": " ".join(lbl[:-1])})
        graph_phase.update({"title": " ".join(lbl[:-1])})
        graph_nyqui.update({"title": " ".join(lbl[:-1])})
        graph_bode.update({"title": " ".join(lbl[:-1])})
        # labels
        graph.replace_labels(" ".join(lbl[:-1]), "")
        graph_phase.replace_labels(" ".join(lbl[:-1]), "")
    for curve in graph_nyqui:
        curve.update({"label": "{:.0f} K".format(curve.attr("temperature [k]"))})
    for curve in graph_bode:
        phaseorz = "phase" if curve.attr("_cfphase") else "|z|"
        temperature = curve.attr("temperature [k]")
        curve.update({"label": "{:.0f} K {}".format(temperature, phaseorz)})
    # mask undesired legends
    mask_undesired_legends(graph, legend)
    mask_undesired_legends(graph_phase, legend)
    mask_undesired_legends(graph_nyqui, legend)
    mask_undesired_legends(graph_bode, legend)
    # set xlim
    _set_xlim(graph, "tight")
    _set_xlim(graph_phase, "tight")
    _set_xlim(graph_nyqui, "tight")
    _set_xlim(graph_bode, "tight")

    # save
    filesave = os.path.join(
        folder, graph.attr("title").replace(" ", "_") + "_"
    )  # graphIO.filesave_default(self)
    plotargs = {}  # {'ifExport': False, 'ifSave': False}
    graphattr = {}
    for attr in ["alter", "typeplot", "xlim", "ylim", "xlabel", "ylabel"]:
        graphattr.update({attr: graph.attr(attr)})

    # default graph: C vs log(f)
    graph.update({"ylim": [0, np.nan]})
    graph.plot(filesave=filesave + "Clogf", **plotargs)
    if pltClose:
        plt.close()

    # graph 2: derivative
    graph.update({"alter": ["", "CurveCf.y_mdCdlnf"], "typeplot": "semilogx"})
    graph.update(
        {"ylim": [0, np.nan], "ylabel": "Derivative - f dC/df"}
    )  # same math as d Capacitance / d ln(f)
    graph.plot(filesave=filesave + "deriv", **plotargs)
    if pltClose:
        plt.close()

    # graph 3: derivative, zoomed-in
    graph.update({"alter": ["", "CurveCf.y_mdCdlnf"], "typeplot": "semilogx"})
    graph.update({"ylim": [0, 1.5 * max(graph[0].y(alter="CurveCf.y_mdCdlnf"))]})
    graph.plot(filesave=filesave + "derivZoom", **plotargs)
    if pltClose:
        plt.close()

    # graph 4: phase
    graph_phase.update(
        {
            "xlabel": graph.attr("xlabel"),
            "ylabel": graph_phase.formatAxisLabel("Impedance phase [°]"),
            "alter": "",
            "typeplot": "semilogx",
            "ylim": [0, 90],
        }
    )
    f = graph_phase[0].x()
    graph_phase.append(
        Curve(
            [[min(f), max(f)], [20, 20]],
            {"color": [1, 0, 0], "linewidth": 2, "linespec": "--"},
        )
    )
    graph_phase.plot(filesave=filesave + "phase", **plotargs)
    if pltClose:
        plt.close()

    # graph 5: Nyquist
    graph_nyqui.update(
        {
            "alter": "",
            "xlabel": graph_nyqui.formatAxisLabel(GraphCf.AXISLABELSNYQUIST[0]),
            "ylabel": graph_nyqui.formatAxisLabel(GraphCf.AXISLABELSNYQUIST[1]),
        }
    )
    # Nyquist limits
    limmaxx, limmaxy = -np.inf, -np.inf
    for curve in graph_nyqui:
        limmaxx = max(limmaxx, max(curve.x()))
        limmaxy = max(limmaxy, max(curve.y()))
    limmax = max(limmaxx, limmaxy)
    upd = {  # default: square plot
        "xlim": [0, limmax],
        "ylim": [0, limmax],
        "subplots_adjust": [0.15, 0.15, 0.95, 0.95],
        "figsize": [5, 5],
    }
    if limmaxy <= 0.5 * limmaxx:  # if data fit into a 2:1 rectangle
        upd.update(
            {
                "ylim": [0, limmax * 0.5],
                "subplots_adjust": [0.15, 0.15, 0.95, 0.95],
                "figsize": [8, 4],
            }
        )
    graph_nyqui.update(upd)
    graph_nyqui.plot(filesave=filesave + "Nyquist", **plotargs)
    if pltClose:
        plt.close()

    # graph 6: image derivative, omega (aka f) vs T (or rather arrhenius)
    graph_image = Graph()
    x = [1] + list(graph[0].x() * 2 * np.pi)  # convert frequency into omega
    matrix = [x]
    tempmin, tempmax = np.inf, -np.inf
    for curve in graph:
        temperature = curve.attr("temperature", None)
        if temperature is None:
            temperature = curve.attr("temperature [k]", None)
        if temperature is None:
            msg = "Script Cf, image, cannot identify Temperature. File ignored. {}"
            print(msg.format(curve.get_attributes()))
            continue

        tempmin, tempmax = min(tempmin, temperature), max(tempmax, temperature)
        y = [temperature] + list(curve.y(alter="CurveCf.y_mdCdlnf"))
        if len(x) != len(y):
            msg = (
                "WARNING data curve {} not consistent number of points throughout "
                "the input files! File ignored. {}"
            )
            print(msg.format(temperature, curve.attr("filename")))
            continue  # do not work with the data
        matrix.append(y)

    matrix = np.array(matrix)
    if matrix.shape[0] > 1:  # enough datapoints
        # format data
        for line in range(1, matrix.shape[1]):
            freq = matrix[0, line] / 2 / np.pi
            graph_image.append(
                Curve_Image([matrix[:, 0], matrix[:, line]], {"frequency [Hz]": freq})
            )
        # levels -> int value does not seem to work (matplotlib version?)
        m, M = np.inf, -np.inf
        for curve in graph_image:
            m = min(m, np.min(curve.y()[1:]))
            M = max(M, np.max(curve.y()[1:]))
        space = roundSignificant(M / 15, 1)
        levels = list(np.arange(0, M * 1.5, space))
        for i in range(len(levels) - 2, -1, -1):
            if levels[i] > M:
                del levels[-1]
            else:
                break
        if len(levels) > 1 and levels[0] > levels[1]:
            del levels[0]
        # graph size - identical pixel unit size for all image in terms of Delta T
        # and Delta ln(f)
        omegamin, omegamax = np.min(matrix[0, 1:]), np.max(matrix[0, 1:])
        tempdelta = (1000 / tempmin - 1000 / tempmax) * 1
        if tempdelta > 0:
            fdelta = (np.log10(omegamax) - np.log10(omegamin)) * 1
            subadj = [0.8, 0.5, 0.8 + tempdelta, 0.5 + fdelta, "abs"]
            graph_image.update(
                {"subplots_adjust": subadj, "figsize": [3 + tempdelta, 1 + fdelta]}
            )
        else:
            print("script Cf, image, Warning T delta <=0, cannot properly scale image.")
        # ticks
        xtickslabels = [[], []]
        values_base = [400, 350, 300, 250, 200, 170, 150, 130, 115, 100, 80, 60, 50, 40]
        for value in values_base:
            xtickslabels[0].append(1000 / value)
            xtickslabels[1].append(value)
        for value in np.arange(np.min(values_base), np.max(values_base), 10):
            if value not in xtickslabels[1]:
                xtickslabels[0].append(1000 / value)
                xtickslabels[1].append("")
        # display image as desired
        attrs = {
            "typeplot": "semilogy",
            "alter": ["CurveArrhenius.x_1000overK", ""],
            "ylim": [omegamin, omegamax],
            "twinx_ylim": [omegamin / 2 / np.pi, omegamax / 2 / np.pi],
            "ylabel": graph_image.formatAxisLabel(
                ["Angular frequency $\\omega$", "", "s$^{-1}$"]
            ),
            "twinx_ylabel": graph.attr("xlabel"),
            "xlabel": graph_image.formatAxisLabel(["Temperature", "T", "K"]),
            "twiny_xlabel": graph_image.formatAxisLabel(
                ["1000/Temperature", "", "1000/K"]
            ),
            "xlim": [tempmax, tempmin],
            "twiny_xlim": [tempmax, tempmin],
            "xtickslabels": xtickslabels,
        }
        graph_image.update(attrs)
        graph_image[0].update(
            {
                "datafile_xy1rowcol": 1,
                "cmap": "magma_r",
                "type": "contourf",
                "colorbar": {
                    "label": graph.attr("ylabel"),  # '-dC / dln(f)',
                    "adjust": [1.18, 0, 0.05, 1, "ax"],
                },
                "levels": levels,
                "extend": "both",
            }
        )
        # For secondary axes
        attx = {"ax_twinx": 1, "labelhide": 1, "label": "Ax twinx", "type": "semilogy"}
        atty = {"ax_twiny": 1, "labelhide": 1, "label": "Ax twiny"}
        graph_image.append(Curve([[1], [1]], attx))
        graph_image.append(Curve([[1], [1]], atty))
        # Fit curve to play with
        image_fit_data = [[100, 150, 200, 250, 300, 350], [1, 1, 1, 1, 1, 1]]
        image_fit_attr = {
            "_arrhenius_variant": "Cfdefault",
            "_fitfunc": "func_Arrhenius",
            "_popt": [0.15, 1e8],
            "_fitroi": [3, 10],
            "color": "k",
            "curve": "Curve Arrhenius",
            "label": "Fit curve to toy with",
            "labelhide": 1,
            "linestyle": "none",
        }
        graph_image.append(CurveArrhenius(image_fit_data, image_fit_attr))
        graph_image[-1].updateFitParam(*graph_image[-1].attr("_popt"))
        # plot
        graph_image.plot(filesave=filesave + "image", **plotargs)
        # if pltClose:
        #    plt.close()

    # graph 7: f vs apparent doping
    graph.update(
        {
            "alter": ["CurveCV.x_CVdepth_nm", "x"],
            "typeplot": "semilogy",
            "xlabel": graph.formatAxisLabel(["Apparent depth", "d", "nm"]),
            "ylabel": graph.formatAxisLabel(["Frequency", "f", "Hz"]),
            "xlim": "",
            "ylim": "",
        }
    )
    graph.plot(filesave=filesave + "apparentDepth", **plotargs)
    if pltClose:
        plt.close()

    # Bode plot
    graph_bode.update(
        {
            "xlabel": graph.attr("ylabel"),
            "ylabel": "Modulus |Z| [Ohm]",
            "typeplot": "loglog",
            "twinx_ylabel": graph_nyqui.formatAxisLabel("Impedance phase [°]"),
            "twinx_ylim": [0, 90],
            "subplots_adjust": [0.15, 0.15],
        }
    )
    if len(graph_bode) > 1:
        graph_bode[0].update({"labelhide": 1})
        graph_bode[1].update({"labelhide": ""})
    graph_bode.plot(filesave=filesave + "Bode", **plotargs)
    if pltClose:
        plt.close()

    # restore initial graph
    graph.update(graphattr)
    if pltClose:
        plt.close()
    print(
        "Tip for next step: pick inflection points for different T, then the fit "
        "activation energy."
    )
    print("End of process C-f.")
    return graph_image


def execute_standalone():
    """For test purposes"""
    folder = "./../examples/Cf/"
    # graph = script_processCf(folder, pltClose=False)

    folder = "./../examples/CV/"
    folder = r"C:\Users\car\Desktop\CVtest"
    graph = script_processCV(folder, ROIfit=[0.15, 0.3], pltClose=True)

    plt.show()


if __name__ == "__main__":
    execute_standalone()
