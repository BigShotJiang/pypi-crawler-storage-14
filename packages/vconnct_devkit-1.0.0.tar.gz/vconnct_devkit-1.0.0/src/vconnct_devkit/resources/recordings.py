"""
Recordings API resource for accessing room recordings.

This module provides the Recordings resource class for retrieving
video/audio recordings from completed rooms.

Example:
    Getting recording URLs for a room::

        recording = client.recordings.get_recording("room-123")
        print(f"Recording URL: {recording.url}")

    Getting URLs as a list::

        urls = client.recordings.get_recording_urls("room-123")
        for url in urls:
            print(f"Download: {url}")
"""

from .base import BaseResource
from ..types import RecordingData, RecordingResponse


class Recordings(BaseResource):
    """
    Recordings API resource for accessing room recordings.

    This resource provides methods for retrieving recordings from
    completed video/audio conferencing rooms.

    Access this resource via ``client.recordings``.

    Example:
        >>> recording = client.recordings.get_recording("room-123")
        >>> print(recording.url)
    """

    def get_recording(self, room_id: str) -> RecordingData:
        """
        Get recording data for a specific room.

        Retrieves the recording information including download URLs
        for a completed room that had recording enabled.

        Args:
            room_id: The unique identifier of the room to get recordings for.

        Returns:
            RecordingData: Recording data object containing:
                - ``url``: Comma-separated string of recording URLs.
                - Additional metadata about the recording.

        Raises:
            NotFoundError: If the room doesn't exist or has no recordings.
            AuthError: If authentication fails.

        Example:
            >>> recording = client.recordings.get_recording("room-123-abc")
            >>> print(f"Recording available at: {recording.url}")
        """
        response = self._client.get("recordings/get_record", {"room_id": room_id})
        parsed = RecordingResponse.from_dict(response)
        return parsed.data

    def get_recording_urls(self, room_id: str) -> list[str]:
        """
        Get recording URLs as a list.

        Convenience method that returns individual recording URLs
        as a list instead of a comma-separated string.

        Args:
            room_id: The unique identifier of the room to get recordings for.

        Returns:
            list[str]: List of recording download URLs. Empty list if no
                recordings are available.

        Raises:
            NotFoundError: If the room doesn't exist or has no recordings.
            AuthError: If authentication fails.

        Example:
            >>> urls = client.recordings.get_recording_urls("room-123-abc")
            >>> for i, url in enumerate(urls, 1):
            ...     print(f"Recording {i}: {url}")
        """
        data = self.get_recording(room_id)
        return [url.strip() for url in data.url.split(",") if url.strip()]
