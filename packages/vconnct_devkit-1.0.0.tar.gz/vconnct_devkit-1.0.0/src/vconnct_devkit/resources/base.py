"""
Base resource class for all API resources.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import VCloudClient


class BaseResource:
    """Base class for all API resources."""

    def __init__(self, client: "VCloudClient") -> None:
        self._client = client
