"""
Rooms API resource for managing video/audio rooms.

This module provides the Rooms resource class for creating, managing, and
querying video and audio conferencing rooms.

Example:
    Creating a quick video room::

        room = client.rooms.create_quick_video_room({
            "project_id": "your-project-id",
            "name": "Team Meeting",
            "max_participants": 10,
        })
        print(f"Join URL: {room.final_link}")

    Fetching past rooms::

        past = client.rooms.fetch_past_rooms({
            "project_id": "your-project-id",
            "room_ids": ["room-id-1", "room-id-2"],
        })
        for room in past.rooms:
            print(f"Room: {room.room_title}, Ended: {room.ended}")
"""

from typing import Any, Union

from .base import BaseResource
from ..types import (
    CreateQuickRoomParams,
    CreateScheduleRoomParams,
    CreateRoomResponse,
    FetchPastRoomsParams,
    FetchPastRoomsResponse,
    InvitationLinkParams,
    InvitationLinkResponse,
    GetActiveRoomResponse,
    GetActiveRoomsResponse,
    EndRoomResponse,
    StartScheduleRoomParams,
)


class Rooms(BaseResource):
    """
    Rooms API resource for managing video/audio conferencing rooms.

    This resource provides methods for:
    - Creating instant (quick) video/audio rooms
    - Creating scheduled video/audio rooms
    - Starting scheduled rooms
    - Fetching active and past room information
    - Creating invitation links
    - Ending active rooms

    Access this resource via ``client.rooms``.

    Example:
        >>> room = client.rooms.create_quick_video_room({
        ...     "project_id": "your-project-id",
        ...     "name": "My Meeting",
        ... })
        >>> print(room.final_link)
    """

    def create_quick_audio_room(
        self,
        params: Union[CreateQuickRoomParams, dict[str, Any]],
    ) -> CreateRoomResponse:
        """
        Create a quick (instant) audio-only room.

        Creates an immediately available audio conferencing room that participants
        can join right away.

        Args:
            params: Room creation parameters. Can be a CreateQuickRoomParams
                dataclass or a dictionary with the following keys:

                - ``project_id`` (str, required): Your project ID.
                - ``name`` (str, optional): Display name for the room.
                - ``client_room_id`` (str, optional): Your custom room identifier.
                - ``max_participants`` (int, optional): Maximum number of participants.
                - ``empty_timeout`` (int, optional): Seconds before empty room closes.
                - ``metadata`` (dict, optional): Custom key-value metadata.

        Returns:
            CreateRoomResponse: Response containing:
                - ``room_id``: The unique room identifier.
                - ``final_link``: The URL for participants to join.
                - ``moderator_link``: The URL for the moderator to join.

        Raises:
            ValidationError: If required parameters are missing or invalid.
            AuthError: If authentication fails.

        Example:
            >>> room = client.rooms.create_quick_audio_room({
            ...     "project_id": "your-project-id",
            ...     "name": "Audio Conference",
            ...     "max_participants": 20,
            ... })
            >>> print(f"Join: {room.final_link}")
        """
        body = params.to_dict() if isinstance(params, CreateQuickRoomParams) else params
        response = self._client.post("rooms/create_quick_audio_room", body)
        return CreateRoomResponse.from_dict(response)

    def create_quick_video_room(
        self,
        params: Union[CreateQuickRoomParams, dict[str, Any]],
    ) -> CreateRoomResponse:
        """
        Create a quick (instant) video room.

        Creates an immediately available video conferencing room that participants
        can join right away with video and audio capabilities.

        Args:
            params: Room creation parameters. Can be a CreateQuickRoomParams
                dataclass or a dictionary with the following keys:

                - ``project_id`` (str, required): Your project ID.
                - ``name`` (str, optional): Display name for the room.
                - ``client_room_id`` (str, optional): Your custom room identifier.
                - ``max_participants`` (int, optional): Maximum number of participants.
                - ``empty_timeout`` (int, optional): Seconds before empty room closes.
                - ``metadata`` (dict, optional): Custom key-value metadata.

        Returns:
            CreateRoomResponse: Response containing:
                - ``room_id``: The unique room identifier.
                - ``final_link``: The URL for participants to join.
                - ``moderator_link``: The URL for the moderator to join.

        Raises:
            ValidationError: If required parameters are missing or invalid.
            AuthError: If authentication fails.

        Example:
            >>> room = client.rooms.create_quick_video_room({
            ...     "project_id": "your-project-id",
            ...     "name": "Team Standup",
            ...     "max_participants": 10,
            ...     "metadata": {"department": "Engineering"},
            ... })
            >>> print(f"Room ID: {room.room_id}")
            >>> print(f"Join URL: {room.final_link}")
        """
        body = params.to_dict() if isinstance(params, CreateQuickRoomParams) else params
        response = self._client.post("rooms/create_quick_video_room", body)
        return CreateRoomResponse.from_dict(response)

    def create_schedule_audio_room(
        self,
        params: Union[CreateScheduleRoomParams, dict[str, Any]],
    ) -> CreateRoomResponse:
        """
        Create a scheduled audio room for a future time.

        Creates a room that will be available at a scheduled time. The room
        must be started using ``start_scheduled_room()`` when ready.

        Args:
            params: Room creation parameters. Can be a CreateScheduleRoomParams
                dataclass or a dictionary with the following keys:

                - ``project_id`` (str, required): Your project ID.
                - ``name`` (str, optional): Display name for the room.
                - ``client_room_id`` (str, optional): Your custom room identifier.
                - ``max_participants`` (int, optional): Maximum number of participants.
                - ``empty_timeout`` (int, optional): Seconds before empty room closes.
                - ``scheduled_time`` (str, optional): ISO 8601 scheduled start time.
                - ``metadata`` (dict, optional): Custom key-value metadata.

        Returns:
            CreateRoomResponse: Response containing the room_id and links.

        Raises:
            ValidationError: If required parameters are missing or invalid.
            AuthError: If authentication fails.

        Example:
            >>> room = client.rooms.create_schedule_audio_room({
            ...     "project_id": "your-project-id",
            ...     "name": "Weekly Call",
            ...     "scheduled_time": "2024-01-15T10:00:00Z",
            ... })
        """
        body = params.to_dict() if isinstance(params, CreateScheduleRoomParams) else params
        response = self._client.post("rooms/create_schedule_audio_room", body)
        return CreateRoomResponse.from_dict(response)

    def create_schedule_video_room(
        self,
        params: Union[CreateScheduleRoomParams, dict[str, Any]],
    ) -> CreateRoomResponse:
        """
        Create a scheduled video room for a future time.

        Creates a video room that will be available at a scheduled time. The room
        must be started using ``start_scheduled_room()`` when ready.

        Args:
            params: Room creation parameters. Can be a CreateScheduleRoomParams
                dataclass or a dictionary with the following keys:

                - ``project_id`` (str, required): Your project ID.
                - ``name`` (str, optional): Display name for the room.
                - ``client_room_id`` (str, optional): Your custom room identifier.
                - ``max_participants`` (int, optional): Maximum number of participants.
                - ``empty_timeout`` (int, optional): Seconds before empty room closes.
                - ``scheduled_time`` (str, optional): ISO 8601 scheduled start time.
                - ``metadata`` (dict, optional): Custom key-value metadata.

        Returns:
            CreateRoomResponse: Response containing the room_id and links.

        Raises:
            ValidationError: If required parameters are missing or invalid.
            AuthError: If authentication fails.

        Example:
            >>> room = client.rooms.create_schedule_video_room({
            ...     "project_id": "your-project-id",
            ...     "name": "Team Meeting",
            ...     "scheduled_time": "2024-01-20T14:00:00Z",
            ...     "max_participants": 15,
            ... })
        """
        body = params.to_dict() if isinstance(params, CreateScheduleRoomParams) else params
        response = self._client.post("rooms/create_schedule_video_room", body)
        return CreateRoomResponse.from_dict(response)

    def start_scheduled_room(
        self,
        params: Union[StartScheduleRoomParams, dict[str, Any]],
    ) -> CreateRoomResponse:
        """
        Start a previously scheduled room.

        Activates a scheduled room so participants can join. Call this when
        you're ready to begin the meeting.

        Args:
            params: Start room parameters. Can be a StartScheduleRoomParams
                dataclass or a dictionary with the following keys:

                - ``room_id`` (str, required): The scheduled room's ID.
                - ``project_id`` (str, optional): Your project ID.

        Returns:
            CreateRoomResponse: Response containing updated room information
                including the active join links.

        Raises:
            ValidationError: If the room_id is invalid.
            NotFoundError: If the scheduled room doesn't exist.
            AuthError: If authentication fails.

        Example:
            >>> # First create a scheduled room
            >>> scheduled = client.rooms.create_schedule_video_room({...})
            >>> # Later, when ready to start
            >>> active = client.rooms.start_scheduled_room({
            ...     "room_id": scheduled.room_id,
            ... })
            >>> print(f"Room is now live: {active.final_link}")
        """
        body = params.to_dict() if isinstance(params, StartScheduleRoomParams) else params
        response = self._client.post("rooms/start_schedule_room", body)
        return CreateRoomResponse.from_dict(response)

    def get_active_room_info(self, room_id: str) -> GetActiveRoomResponse:
        """
        Get information about a specific active room.

        Retrieves the current status and details of an active (ongoing) room.

        Args:
            room_id: The unique identifier of the room to query.

        Returns:
            GetActiveRoomResponse: Response containing:
                - ``status``: Whether the request was successful.
                - ``room``: Room details including status and moderator info.

        Raises:
            NotFoundError: If the room doesn't exist or is not active.
            AuthError: If authentication fails.

        Example:
            >>> info = client.rooms.get_active_room_info("room-123-abc")
            >>> print(f"Room status: {info.room.status}")
            >>> print(f"Moderator: {info.room.moderator_id}")
        """
        response = self._client.get("rooms/get_active_room_info", {"room_id": room_id})
        return GetActiveRoomResponse.from_dict(response)

    def get_all_active_rooms(self) -> GetActiveRoomsResponse:
        """
        Get information about all currently active rooms.

        Retrieves a list of all rooms that are currently in progress
        across your project.

        Returns:
            GetActiveRoomsResponse: Response containing:
                - ``status``: Whether the request was successful.
                - ``rooms``: List of active room information.

        Raises:
            AuthError: If authentication fails.

        Example:
            >>> active = client.rooms.get_all_active_rooms()
            >>> print(f"Currently active: {len(active.rooms)} rooms")
            >>> for room in active.rooms:
            ...     print(f"  - {room.room_id}: {room.status}")
        """
        response = self._client.get("rooms/get_active_rooms_info")
        return GetActiveRoomsResponse.from_dict(response)

    def fetch_past_rooms(
        self,
        params: Union[FetchPastRoomsParams, dict[str, Any]],
    ) -> FetchPastRoomsResponse:
        """
        Fetch past/historical rooms.

        Retrieves information about rooms that have ended, including
        their duration, participant count, and other metadata.

        Args:
            params: Fetch parameters. Can be a FetchPastRoomsParams
                dataclass or a dictionary with the following keys:

                - ``project_id`` (str, required): Your project ID.
                - ``room_ids`` (list[str], required): List of room IDs to fetch.
                - ``from_`` (int, optional): Pagination offset.
                - ``limit`` (int, optional): Maximum results to return.
                - ``order_by`` (str, optional): Sort order ("ASC" or "DESC").

        Returns:
            FetchPastRoomsResponse: Response containing:
                - ``status``: Whether the request was successful.
                - ``rooms``: List of past room information including
                  created/ended times, participant counts, etc.

        Raises:
            ValidationError: If required parameters are missing.
            AuthError: If authentication fails.

        Example:
            >>> past = client.rooms.fetch_past_rooms({
            ...     "project_id": "your-project-id",
            ...     "room_ids": ["room-1", "room-2"],
            ...     "limit": 10,
            ... })
            >>> for room in past.rooms:
            ...     print(f"{room.room_title}: {room.created} - {room.ended}")
        """
        body = params.to_dict() if isinstance(params, FetchPastRoomsParams) else params
        response = self._client.post("rooms/fetch_past_rooms", body)
        return FetchPastRoomsResponse.from_dict(response)

    def create_invitation_link(
        self,
        params: Union[InvitationLinkParams, dict[str, Any]],
    ) -> InvitationLinkResponse:
        """
        Create an invitation link for a room.

        Generates a unique invitation URL that can be shared with
        participants to join a specific room.

        Args:
            params: Invitation parameters. Can be an InvitationLinkParams
                dataclass or a dictionary with the following keys:

                - ``room_id`` (str, required): The room to create a link for.
                - ``participant_name`` (str, optional): Pre-fill participant name.
                - ``role`` (str, optional): Participant role (e.g., "moderator").

        Returns:
            InvitationLinkResponse: Response containing:
                - ``invitation_link``: The generated invitation URL.

        Raises:
            NotFoundError: If the room doesn't exist.
            AuthError: If authentication fails.

        Example:
            >>> invite = client.rooms.create_invitation_link({
            ...     "room_id": "room-123",
            ...     "participant_name": "John Doe",
            ... })
            >>> print(f"Share this link: {invite.invitation_link}")
        """
        body = params.to_dict() if isinstance(params, InvitationLinkParams) else params
        response = self._client.post("rooms/create_invitation_link", body)
        return InvitationLinkResponse.from_dict(response)

    def end_room(self, room_id: str) -> EndRoomResponse:
        """
        End an active room.

        Immediately terminates an ongoing room, disconnecting all
        participants.

        Args:
            room_id: The unique identifier of the room to end.

        Returns:
            EndRoomResponse: Response confirming the room was ended.

        Raises:
            NotFoundError: If the room doesn't exist or is not active.
            AuthError: If authentication fails.

        Example:
            >>> result = client.rooms.end_room("room-123-abc")
            >>> print("Room ended successfully")
        """
        response = self._client.post("rooms/end_room", {"room_id": room_id})
        return EndRoomResponse.from_dict(response)
