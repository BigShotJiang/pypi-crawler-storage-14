"""
Analytics API resource for accessing room analytics.

This module provides the Analytics resource class for retrieving
detailed analytics and metrics from completed rooms.

Example:
    Getting analytics for a room::

        analytics = client.analytics.get_analytics("room-123")
        print(f"Total participants: {analytics.get('participants_count')}")
        print(f"Duration: {analytics.get('duration')} seconds")
"""

from typing import Any

from .base import BaseResource
from ..types import AnalyticsResponse


class Analytics(BaseResource):
    """
    Analytics API resource for accessing room analytics.

    This resource provides methods for retrieving detailed analytics
    and usage metrics from completed video/audio conferencing rooms.

    Access this resource via ``client.analytics``.

    Example:
        >>> data = client.analytics.get_analytics("room-123")
        >>> print(f"Duration: {data.get('duration')}")
    """

    def get_analytics(self, room_id: str) -> dict[str, Any]:
        """
        Get analytics data for a specific room.

        Retrieves detailed analytics and metrics for a completed room,
        including participant information, duration, and usage statistics.

        Args:
            room_id: The unique identifier of the room to get analytics for.

        Returns:
            dict[str, Any]: Analytics data dictionary containing metrics such as:
                - Participant count and details
                - Room duration
                - Join/leave timestamps
                - Media usage statistics
                - And other room-specific metrics

        Raises:
            NotFoundError: If the room doesn't exist or has no analytics.
            AuthError: If authentication fails.

        Example:
            >>> analytics = client.analytics.get_analytics("room-123-abc")
            >>> print(f"Participants: {analytics.get('participants_count')}")
            >>> print(f"Duration: {analytics.get('duration')} seconds")
            >>> for participant in analytics.get('participants', []):
            ...     print(f"  - {participant.get('name')}")
        """
        response = self._client.get("analytics/get_analytics", {"room_id": room_id})
        parsed = AnalyticsResponse.from_dict(response)
        return parsed.data
