"""
Branding API resource for managing project branding.

This module provides the Branding resource class for uploading and
managing project logos and branding assets.

Example:
    Creating branding with a logo::

        with open("logo.png", "rb") as f:
            result = client.branding.create({
                "project_id": "your-project-id",
                "logo": f,
            })
        print(f"Branding created: {result.status}")

    Updating branding::

        with open("new-logo.png", "rb") as f:
            result = client.branding.update({
                "project_id": "your-project-id",
                "logo": f,
            })
"""

from typing import Any, Union

from .base import BaseResource
from ..types import BrandingParams, BrandingResponse


class Branding(BaseResource):
    """
    Branding API resource for managing project branding.

    This resource provides methods for creating and updating project
    branding assets including logos and favicons for your video
    conferencing rooms.

    Access this resource via ``client.branding``.

    Supported image types:
        - ``logo``: Main logo displayed in light mode
        - ``dark_logo``: Logo for dark mode/theme
        - ``mobile_logo``: Logo optimized for mobile devices
        - ``mobile_dark_logo``: Mobile logo for dark mode
        - ``fav_icon``: Favicon/browser tab icon

    Example:
        >>> with open("logo.png", "rb") as f:
        ...     result = client.branding.create({
        ...         "project_id": "your-project-id",
        ...         "logo": f,
        ...     })
    """

    def _build_form_data(
        self, params: Union[BrandingParams, dict[str, Any]]
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """
        Build form data and files from branding parameters.

        Internal method that converts BrandingParams or dict into
        the format required for multipart form upload.

        Args:
            params: Branding parameters as BrandingParams dataclass or dict.

        Returns:
            tuple[dict, dict]: A tuple of (data dict, files dict) where:
                - data: Contains the project_id
                - files: Contains the image file references
        """
        if isinstance(params, BrandingParams):
            data = {"project_id": params.project_id}
            files = {}

            if params.logo is not None:
                files["logo"] = ("logo", params.logo)
            if params.dark_logo is not None:
                files["dark_logo"] = ("dark_logo", params.dark_logo)
            if params.mobile_logo is not None:
                files["mobile_logo"] = ("mobile_logo", params.mobile_logo)
            if params.mobile_dark_logo is not None:
                files["mobile_dark_logo"] = ("mobile_dark_logo", params.mobile_dark_logo)
            if params.fav_icon is not None:
                files["fav_icon"] = ("fav_icon", params.fav_icon)

            return data, files
        else:
            # params is a dict
            data = {"project_id": params.get("project_id", "")}
            files = {}

            for key in ["logo", "dark_logo", "mobile_logo", "mobile_dark_logo", "fav_icon"]:
                if key in params and params[key] is not None:
                    files[key] = (key, params[key])

            return data, files

    def create(self, params: Union[BrandingParams, dict[str, Any]]) -> BrandingResponse:
        """
        Create branding for a project.

        Uploads initial branding assets (logos, favicon) for a project.
        Use this method when setting up branding for the first time.

        Args:
            params: Branding parameters. Can be a BrandingParams dataclass
                or a dictionary with the following keys:

                - ``project_id`` (str, required): Your project ID.
                - ``logo`` (file-like, optional): Main logo image file.
                - ``dark_logo`` (file-like, optional): Dark mode logo.
                - ``mobile_logo`` (file-like, optional): Mobile logo.
                - ``mobile_dark_logo`` (file-like, optional): Mobile dark logo.
                - ``fav_icon`` (file-like, optional): Favicon image.

        Returns:
            BrandingResponse: Response confirming branding was created.

        Raises:
            ValidationError: If project_id is missing or files are invalid.
            AuthError: If authentication fails.

        Example:
            >>> with open("logo.png", "rb") as logo, open("favicon.ico", "rb") as fav:
            ...     result = client.branding.create({
            ...         "project_id": "your-project-id",
            ...         "logo": logo,
            ...         "fav_icon": fav,
            ...     })
            >>> print(f"Branding created successfully")
        """
        data, files = self._build_form_data(params)
        response = self._client.post_form("branding", data, files)
        return BrandingResponse.from_dict(response)

    def update(self, params: Union[BrandingParams, dict[str, Any]]) -> BrandingResponse:
        """
        Update branding for a project.

        Updates existing branding assets for a project. Only the
        provided images will be updated; others remain unchanged.

        Args:
            params: Branding parameters. Can be a BrandingParams dataclass
                or a dictionary with the following keys:

                - ``project_id`` (str, required): Your project ID.
                - ``logo`` (file-like, optional): New main logo image.
                - ``dark_logo`` (file-like, optional): New dark mode logo.
                - ``mobile_logo`` (file-like, optional): New mobile logo.
                - ``mobile_dark_logo`` (file-like, optional): New mobile dark logo.
                - ``fav_icon`` (file-like, optional): New favicon image.

        Returns:
            BrandingResponse: Response confirming branding was updated.

        Raises:
            ValidationError: If project_id is missing or files are invalid.
            NotFoundError: If the project has no existing branding.
            AuthError: If authentication fails.

        Example:
            >>> with open("new-logo.png", "rb") as f:
            ...     result = client.branding.update({
            ...         "project_id": "your-project-id",
            ...         "logo": f,
            ...     })
            >>> print(f"Logo updated successfully")
        """
        data, files = self._build_form_data(params)
        response = self._client.patch_form("branding", data, files)
        return BrandingResponse.from_dict(response)
