"""
VConnct SDK error classes.
"""

from typing import Any, Optional


class VConnctError(Exception):
    """Base error class for all VConnct SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Any] = None,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response

    def __str__(self) -> str:
        return self.message


class AuthError(VConnctError):
    """Thrown when authentication fails (invalid API key or signature)."""

    def __init__(
        self, message: str = "Authentication failed: Invalid API key or signature"
    ):
        super().__init__(message, status_code=401)


class ValidationError(VConnctError):
    """Thrown when request validation fails."""

    def __init__(
        self,
        message: str,
        fields: Optional[dict[str, str]] = None,
    ):
        super().__init__(message, status_code=400)
        self.fields = fields


class NotFoundError(VConnctError):
    """Thrown when a requested resource is not found."""

    def __init__(self, message: str, details: Optional[Any] = None):
        super().__init__(message, status_code=404, response=details)
        self.details = details


class RateLimitError(VConnctError):
    """Thrown when rate limit is exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[int] = None,
    ):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


# Backwards compatibility alias
VCloudError = VConnctError
