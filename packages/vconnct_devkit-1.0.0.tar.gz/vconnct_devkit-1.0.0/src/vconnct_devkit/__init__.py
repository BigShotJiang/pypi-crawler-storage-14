"""
VConnct DevKit - Official Python SDK for the VConnct v4 API.

Build video and audio conferencing applications with ease.

Website: https://vconnct.me/
Documentation: https://guide.vconnct.com/
"""

from .client import VConnctClient
from .errors import (
    VConnctError,
    VCloudError,  # Backwards compatibility
    AuthError,
    ValidationError,
    NotFoundError,
    RateLimitError,
)
from .types import (
    VConnctConfig,
    VCloudConfig,  # Backwards compatibility
    RoomMetadata,
    CreateQuickRoomParams,
    CreateScheduleRoomParams,
    FetchPastRoomsParams,
    InvitationLinkParams,
    StartScheduleRoomParams,
    CreateRoomResponse,
    ActiveRoomInfo,
    GetActiveRoomResponse,
    GetActiveRoomsResponse,
    FetchPastRoomsResponse,
    InvitationLinkResponse,
    EndRoomResponse,
    RecordingData,
    RecordingResponse,
    AnalyticsResponse,
    BrandingParams,
    BrandingResponse,
)
from .resources import Rooms, Recordings, Analytics, Branding

__version__ = "1.0.0"

# Backwards compatibility alias
VCloudClient = VConnctClient

__all__ = [
    # Client
    "VConnctClient",
    "VCloudClient",  # Backwards compatibility
    # Errors
    "VConnctError",
    "VCloudError",  # Backwards compatibility
    "AuthError",
    "ValidationError",
    "NotFoundError",
    "RateLimitError",
    # Config
    "VConnctConfig",
    "VCloudConfig",  # Backwards compatibility
    # Room types
    "RoomMetadata",
    "CreateQuickRoomParams",
    "CreateScheduleRoomParams",
    "FetchPastRoomsParams",
    "InvitationLinkParams",
    "StartScheduleRoomParams",
    "CreateRoomResponse",
    "ActiveRoomInfo",
    "GetActiveRoomResponse",
    "GetActiveRoomsResponse",
    "FetchPastRoomsResponse",
    "InvitationLinkResponse",
    "EndRoomResponse",
    # Recording types
    "RecordingData",
    "RecordingResponse",
    # Analytics types
    "AnalyticsResponse",
    # Branding types
    "BrandingParams",
    "BrandingResponse",
    # Resources (for advanced usage)
    "Rooms",
    "Recordings",
    "Analytics",
    "Branding",
]
