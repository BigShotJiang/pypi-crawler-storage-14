"""
VConnct API client for interacting with the VConnct v4 API.

This module provides the main client class for authenticating and making
requests to the VConnct video conferencing API.

Example:
    Basic usage::

        from vconnct_devkit import VConnctClient

        client = VConnctClient(
            api_key="your-api-key",
            secret_key="your-secret-key",
        )

        # Create a video room
        room = client.rooms.create_quick_video_room({
            "project_id": "your-project-id",
            "name": "My Meeting",
        })
        print(f"Join URL: {room.final_link}")

    Using context manager::

        with VConnctClient(api_key="...", secret_key="...") as client:
            rooms = client.rooms.fetch_past_rooms({
                "project_id": "your-project-id",
                "room_ids": ["room-id-1", "room-id-2"],
            })
"""

from __future__ import annotations

import base64
import hashlib
import hmac
from typing import Any, Optional, cast

import httpx

from .errors import (
    AuthError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    VConnctError,
)
from .resources.rooms import Rooms
from .resources.recordings import Recordings
from .resources.analytics import Analytics
from .resources.branding import Branding
from .types import VConnctConfig


DEFAULT_BASE_URL = "https://v.cloudapi.vconnct.me/api/v4"
DEFAULT_TIMEOUT = 30.0


class VConnctClient:
    """
    VConnct API client for interacting with the VConnct v4 API.

    This client provides access to all VConnct API resources including rooms,
    recordings, analytics, and branding management.

    Attributes:
        rooms (Rooms): Access to room management operations (create, fetch, update rooms).
        recordings (Recordings): Access to recording retrieval operations.
        analytics (Analytics): Access to room analytics data.
        branding (Branding): Access to project branding/logo management.

    Example:
        >>> client = VConnctClient(
        ...     api_key="your-api-key",
        ...     secret_key="your-secret-key",
        ... )
        >>> room = client.rooms.create_quick_video_room({
        ...     "project_id": "your-project-id",
        ...     "name": "Team Meeting",
        ... })
        >>> print(room.final_link)
    """

    def __init__(
        self,
        api_key: str,
        secret_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        """
        Initialize the VConnct client.

        Args:
            api_key: Your VConnct API key obtained from the dashboard.
            secret_key: Your secret key for HMAC SHA256 request signing.
            base_url: API base URL. Defaults to 'https://v.cloudapi.vconnct.me/api/v4'.
            timeout: Request timeout in seconds. Defaults to 30.0.

        Raises:
            httpx.ConnectError: If unable to connect to the API server.

        Example:
            >>> client = VConnctClient(
            ...     api_key="b26e5d02-4579-4164-9cec-563557801286",
            ...     secret_key="85804f4b-d5ef-4609-a39a-37395981150d",
            ... )
        """
        self._api_key = api_key
        self._secret_key = secret_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

        # Extract base path from URL (e.g., /api/v4)
        from urllib.parse import urlparse

        parsed = urlparse(base_url)
        self._base_path = parsed.path.rstrip("/")

        # Create HTTP client
        self._http_client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers={"Content-Type": "application/json"},
        )

        # Initialize resources
        self.rooms = Rooms(self)
        self.recordings = Recordings(self)
        self.analytics = Analytics(self)
        self.branding = Branding(self)

    @classmethod
    def from_config(cls, config: VConnctConfig) -> "VConnctClient":
        """
        Create a VConnctClient instance from a VConnctConfig object.

        Args:
            config: A VConnctConfig dataclass containing api_key, secret_key,
                and optional base_url and timeout settings.

        Returns:
            VConnctClient: A new client instance configured with the provided settings.

        Example:
            >>> from vconnct_devkit.types import VConnctConfig
            >>> config = VConnctConfig(
            ...     api_key="your-api-key",
            ...     secret_key="your-secret-key",
            ... )
            >>> client = VConnctClient.from_config(config)
        """
        return cls(
            api_key=config.api_key,
            secret_key=config.secret_key,
            base_url=config.base_url,
            timeout=config.timeout,
        )

    def _generate_signature(self, payload: str) -> str:
        """
        Generate HMAC SHA256 signature for the given payload (Base64 encoded).

        Args:
            payload: The string to sign

        Returns:
            Base64 encoded HMAC SHA256 signature
        """
        # Normalize: replace CRLF with LF and trim
        normalized = payload.replace("\r\n", "\n").strip()

        signature = hmac.new(
            self._secret_key.encode("utf-8"),
            normalized.encode("utf-8"),
            hashlib.sha256,
        ).digest()

        return base64.b64encode(signature).decode("utf-8")

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response and raise appropriate errors."""
        if response.is_success:
            return cast(dict[str, Any], response.json())

        try:
            body = response.json()
        except Exception:
            body = {}

        message = body.get("message") or body.get("error") or body.get("msg") or "Request failed"

        if response.status_code == 401:
            raise AuthError(message)
        elif response.status_code == 400:
            raise ValidationError(message)
        elif response.status_code == 404:
            raise NotFoundError(message or "Resource not found", body)
        elif response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                message,
                int(retry_after) if retry_after else None,
            )
        else:
            raise VConnctError(message, response.status_code, body)

    def get(
        self,
        path: str,
        params: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Make a GET request.

        Args:
            path: API endpoint path
            params: Query parameters

        Returns:
            API response as dictionary
        """
        # Filter out None values
        filtered_params = {}
        if params:
            filtered_params = {k: str(v) for k, v in params.items() if v is not None}

        # Build full path for signing
        query_string = "&".join(f"{k}={v}" for k, v in sorted(filtered_params.items()))
        full_path = f"{self._base_path}/{path}"
        if query_string:
            full_path = f"{full_path}?{query_string}"

        signature = self._generate_signature(full_path)

        response = self._http_client.get(
            path,
            params=filtered_params if filtered_params else None,
            headers={
                "key": self._api_key,
                "hash-signature": signature,
            },
        )

        return self._handle_response(response)

    def post(
        self,
        path: str,
        body: Any,
    ) -> dict[str, Any]:
        """
        Make a POST request with JSON body.

        Args:
            path: API endpoint path
            body: Request body (will be JSON encoded)

        Returns:
            API response as dictionary
        """
        import json

        # Use compact JSON (no spaces) to match JavaScript's JSON.stringify()
        json_body = json.dumps(body, separators=(",", ":"))
        signature = self._generate_signature(json_body)

        response = self._http_client.post(
            path,
            content=json_body,
            headers={
                "key": self._api_key,
                "hash-signature": signature,
                "Content-Type": "application/json",
            },
        )

        return self._handle_response(response)

    def patch(
        self,
        path: str,
        body: Any,
    ) -> dict[str, Any]:
        """
        Make a PATCH request with JSON body.

        Args:
            path: API endpoint path
            body: Request body (will be JSON encoded)

        Returns:
            API response as dictionary
        """
        import json

        # Use compact JSON (no spaces) to match JavaScript's JSON.stringify()
        json_body = json.dumps(body, separators=(",", ":"))
        signature = self._generate_signature(json_body)

        response = self._http_client.patch(
            path,
            content=json_body,
            headers={
                "key": self._api_key,
                "hash-signature": signature,
                "Content-Type": "application/json",
            },
        )

        return self._handle_response(response)

    def post_form(
        self,
        path: str,
        data: dict[str, Any],
        files: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Make a POST request with multipart form data.

        Args:
            path: API endpoint path
            data: Form data fields
            files: Files to upload

        Returns:
            API response as dictionary
        """
        project_id = data.get("project_id", "")
        signature = self._generate_signature(str(project_id))

        response = self._http_client.post(
            path,
            data=data,
            files=files,
            headers={
                "key": self._api_key,
                "hash-signature": signature,
            },
        )

        return self._handle_response(response)

    def patch_form(
        self,
        path: str,
        data: dict[str, Any],
        files: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Make a PATCH request with multipart form data.

        Args:
            path: API endpoint path
            data: Form data fields
            files: Files to upload

        Returns:
            API response as dictionary
        """
        project_id = data.get("project_id", "")
        signature = self._generate_signature(str(project_id))

        response = self._http_client.patch(
            path,
            data=data,
            files=files,
            headers={
                "key": self._api_key,
                "hash-signature": signature,
            },
        )

        return self._handle_response(response)

    def close(self) -> None:
        """
        Close the HTTP client and release resources.

        This method should be called when you're done using the client to
        properly close the underlying HTTP connection pool.

        Note:
            If using the client as a context manager (with statement),
            this is called automatically.

        Example:
            >>> client = VConnctClient(api_key="...", secret_key="...")
            >>> # ... use client ...
            >>> client.close()
        """
        self._http_client.close()

    def __enter__(self) -> "VConnctClient":
        """
        Enter the context manager.

        Returns:
            VConnctClient: The client instance.

        Example:
            >>> with VConnctClient(api_key="...", secret_key="...") as client:
            ...     room = client.rooms.create_quick_video_room({...})
        """
        return self

    def __exit__(self, *args: Any) -> None:
        """
        Exit the context manager and close the client.

        This automatically calls close() to release HTTP resources.
        """
        self.close()
