"""
VConnct SDK type definitions.

This module contains all dataclass definitions used for API requests and responses.
These types provide strong typing support for IDE autocompletion and validation.

Example:
    Using typed parameters::

        from vconnct_devkit.types import CreateQuickRoomParams, RoomMetadata

        params = CreateQuickRoomParams(
            project_id="your-project-id",
            client_room_id="meeting-001",
            name="Team Standup",
            max_participants=10,
            metadata=RoomMetadata(
                room_title="Daily Standup",
                welcome_message="Welcome to the meeting!",
            ),
        )
        room = client.rooms.create_quick_video_room(params)

    Or using dictionaries::

        room = client.rooms.create_quick_video_room({
            "project_id": "your-project-id",
            "client_room_id": "meeting-001",
            "name": "Team Standup",
        })
"""

from dataclasses import dataclass, field
from typing import Any, Literal, Optional, Union


@dataclass
class VConnctConfig:
    """
    Configuration for VConnctClient.

    Use this dataclass to configure the VConnct client with your credentials
    and optional settings.

    Attributes:
        api_key: Your VConnct API key from the dashboard.
        secret_key: Your secret key for HMAC request signing.
        base_url: API base URL. Defaults to production API.
        timeout: Request timeout in seconds. Defaults to 30.0.

    Example:
        >>> config = VConnctConfig(
        ...     api_key="your-api-key",
        ...     secret_key="your-secret-key",
        ... )
        >>> client = VConnctClient.from_config(config)
    """

    api_key: str
    secret_key: str
    base_url: str = "https://v.cloudapi.vconnct.me/api/v4"
    timeout: float = 30.0


# Backwards compatibility alias
VCloudConfig = VConnctConfig


# Room Types


@dataclass
class RoomMetadata:
    """
    Room metadata containing display information.

    Used to customize the room's appearance with a title and welcome message.

    Attributes:
        room_title: Title displayed in the room header.
        welcome_message: Message shown to participants when joining.

    Example:
        >>> metadata = RoomMetadata(
        ...     room_title="Team Meeting",
        ...     welcome_message="Welcome! Please mute when not speaking.",
        ... )
    """

    room_title: str
    welcome_message: str


@dataclass
class CreateQuickRoomParams:
    """
    Parameters for creating a quick (instant) room.

    Use this dataclass when you want type safety and IDE autocompletion
    for room creation. Alternatively, pass a plain dictionary.

    Attributes:
        project_id: Your VCloud project ID (required).
        client_room_id: Your custom identifier for this room (required).
        name: Display name for the room.
        moderator_id: ID of the room moderator.
        max_participants: Maximum allowed participants (e.g., 10, 50, 100).
        empty_timeout: Seconds before an empty room auto-closes.
        metadata: Room display metadata (title and welcome message).

    Example:
        >>> params = CreateQuickRoomParams(
        ...     project_id="proj-123",
        ...     client_room_id="meeting-001",
        ...     name="Sprint Planning",
        ...     max_participants=15,
        ...     empty_timeout=300,
        ... )
        >>> room = client.rooms.create_quick_video_room(params)
    """

    project_id: str
    client_room_id: str
    name: Optional[str] = None
    moderator_id: Optional[str] = None
    max_participants: Optional[Union[int, str]] = None
    empty_timeout: Optional[Union[int, str]] = None
    metadata: Optional[RoomMetadata] = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to dictionary for API request.

        Returns:
            dict[str, Any]: Dictionary representation suitable for JSON serialization.
        """
        data: dict[str, Any] = {
            "project_id": self.project_id,
            "client_room_id": self.client_room_id,
        }
        if self.name is not None:
            data["name"] = self.name
        if self.moderator_id is not None:
            data["moderator_id"] = self.moderator_id
        if self.max_participants is not None:
            data["max_participants"] = self.max_participants
        if self.empty_timeout is not None:
            data["empty_timeout"] = self.empty_timeout
        if self.metadata is not None:
            data["metadata"] = {
                "room_title": self.metadata.room_title,
                "welcome_message": self.metadata.welcome_message,
            }
        return data


@dataclass
class CreateScheduleRoomParams(CreateQuickRoomParams):
    """
    Parameters for creating a scheduled room.

    Extends CreateQuickRoomParams with scheduling-specific fields.
    Scheduled rooms must be started with ``start_scheduled_room()`` before use.

    Attributes:
        project_id: Your VCloud project ID (required).
        client_room_id: Your custom identifier for this room (required).
        start_at: ISO 8601 datetime string for scheduled start time.
        empty_timeout: Seconds before an empty room auto-closes (default: 300).
        name: Display name for the room.
        moderator_id: ID of the room moderator.
        max_participants: Maximum allowed participants.
        metadata: Room display metadata.

    Example:
        >>> params = CreateScheduleRoomParams(
        ...     project_id="proj-123",
        ...     client_room_id="meeting-002",
        ...     name="Weekly Review",
        ...     start_at="2024-01-20T14:00:00Z",
        ... )
        >>> room = client.rooms.create_schedule_video_room(params)
    """

    start_at: str = ""
    empty_timeout: Union[int, str] = 300

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to dictionary for API request.

        Returns:
            dict[str, Any]: Dictionary representation including schedule fields.
        """
        data = super().to_dict()
        data["start_at"] = self.start_at
        data["empty_timeout"] = self.empty_timeout
        return data


@dataclass
class FetchPastRoomsParams:
    """
    Parameters for fetching past/historical rooms.

    Use this to retrieve information about completed rooms.

    Attributes:
        project_id: Your VCloud project ID (required).
        room_ids: List of room IDs to fetch (required).
        from_: Pagination offset (0-indexed).
        limit: Maximum number of results to return.
        order_by: Sort order - "ASC" for oldest first, "DESC" for newest first.

    Example:
        >>> params = FetchPastRoomsParams(
        ...     project_id="proj-123",
        ...     room_ids=["room-1", "room-2", "room-3"],
        ...     limit=10,
        ...     order_by="DESC",
        ... )
        >>> past = client.rooms.fetch_past_rooms(params)
    """

    project_id: str
    room_ids: list[str]
    from_: Optional[int] = None
    limit: Optional[int] = None
    order_by: Optional[Literal["ASC", "DESC"]] = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to dictionary for API request.

        Returns:
            dict[str, Any]: Dictionary representation for the API.
        """
        data: dict[str, Any] = {
            "project_id": self.project_id,
            "room_ids": self.room_ids,
        }
        if self.from_ is not None:
            data["from"] = self.from_
        if self.limit is not None:
            data["limit"] = self.limit
        if self.order_by is not None:
            data["order_by"] = self.order_by
        return data


@dataclass
class InvitationLinkParams:
    """
    Parameters for creating an invitation link.

    Use this to generate personalized invitation URLs for participants.

    Attributes:
        room_id: The room ID to create an invitation for (required).
        user_id: Identifier for the invited user (required).
        role: Participant role - "admin" for moderator, "viewer" for regular participant.

    Example:
        >>> params = InvitationLinkParams(
        ...     room_id="room-123",
        ...     user_id="user-456",
        ...     role="viewer",
        ... )
        >>> invite = client.rooms.create_invitation_link(params)
    """

    room_id: str
    user_id: str
    role: Literal["admin", "viewer"]

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to dictionary for API request.

        Returns:
            dict[str, Any]: Dictionary representation for the API.
        """
        return {
            "room_id": self.room_id,
            "user_id": self.user_id,
            "role": self.role,
        }


@dataclass
class StartScheduleRoomParams:
    """
    Parameters for starting a scheduled room.

    Use this to activate a previously scheduled room.

    Attributes:
        room_id: The scheduled room's ID to start (required).
        name: Optional new name for the room when starting.

    Example:
        >>> params = StartScheduleRoomParams(room_id="room-123")
        >>> active = client.rooms.start_scheduled_room(params)
    """

    room_id: str
    name: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to dictionary for API request.

        Returns:
            dict[str, Any]: Dictionary representation for the API.
        """
        data: dict[str, Any] = {"room_id": self.room_id}
        if self.name is not None:
            data["name"] = self.name
        return data


@dataclass
class CreateRoomResponse:
    """
    Response from room creation endpoints.

    Contains the created room's information including join URLs.

    Attributes:
        room_id: Unique identifier for the created room.
        status: Whether the creation was successful.
        final_link: URL for participants to join the room.
        name: The room's display name.
        client_room_id: Your custom room identifier.
        moderator_id: ID of the room moderator.
        max_participants: Maximum allowed participants.
        empty_timeout: Seconds before empty room closes.
        metadata: Room display metadata.

    Example:
        >>> room = client.rooms.create_quick_video_room({...})
        >>> print(f"Room ID: {room.room_id}")
        >>> print(f"Join URL: {room.final_link}")
    """

    room_id: str
    status: bool
    final_link: Optional[str] = None
    name: Optional[str] = None
    client_room_id: Optional[str] = None
    moderator_id: Optional[str] = None
    max_participants: Optional[int] = None
    empty_timeout: Optional[int] = None
    metadata: Optional[RoomMetadata] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CreateRoomResponse":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            CreateRoomResponse: Parsed response object.
        """
        metadata = None
        if data.get("metadata"):
            metadata = RoomMetadata(
                room_title=data["metadata"].get("room_title", ""),
                welcome_message=data["metadata"].get("welcome_message", ""),
            )
        return cls(
            room_id=data["room_id"],
            status=data["status"],
            final_link=data.get("final_link"),
            name=data.get("name"),
            client_room_id=data.get("client_room_id"),
            moderator_id=data.get("moderator_id"),
            max_participants=data.get("max_participants"),
            empty_timeout=data.get("empty_timeout"),
            metadata=metadata,
        )


@dataclass
class ActiveRoomInfo:
    """
    Information about an active or past room.

    Contains details about a room's status, timing, and participants.

    Attributes:
        room_id: Unique identifier for the room.
        status: Current room status (for active rooms).
        moderator_id: ID of the room moderator.
        room_sid: Internal session ID (sid field from API).
        room_title: Display title of the room.
        created: ISO timestamp when room was created.
        ended: ISO timestamp when room ended (for past rooms).
        joined_participants: Number of participants who joined.
        analytics_file_id: ID for retrieving analytics data.
        webhook_url: Configured webhook URL.
        is_running: Whether the room is currently active.
        is_recording: Whether the room is being recorded.
        creation_time: Unix timestamp of creation.
        metadata: Room metadata as JSON string.

    Example:
        >>> info = client.rooms.get_active_room_info("room-123")
        >>> print(f"Status: {info.room.status}")
        >>> print(f"Moderator: {info.room.moderator_id}")
    """

    room_id: str
    status: Optional[str] = None
    moderator_id: Optional[str] = None
    room_sid: Optional[str] = None
    room_title: Optional[str] = None
    created: Optional[str] = None
    ended: Optional[str] = None
    joined_participants: Optional[str] = None
    analytics_file_id: Optional[str] = None
    webhook_url: Optional[str] = None
    is_running: Optional[int] = None
    is_recording: Optional[int] = None
    creation_time: Optional[str] = None
    metadata: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ActiveRoomInfo":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            ActiveRoomInfo: Parsed room information.
        """
        return cls(
            room_id=data["room_id"],
            status=data.get("status"),
            moderator_id=data.get("moderator_id"),
            room_sid=data.get("room_sid") or data.get("sid"),
            room_title=data.get("room_title"),
            created=data.get("created"),
            ended=data.get("ended"),
            joined_participants=data.get("joined_participants"),
            analytics_file_id=data.get("analytics_file_id"),
            webhook_url=data.get("webhook_url"),
            is_running=data.get("is_running"),
            is_recording=data.get("is_recording"),
            creation_time=data.get("creation_time"),
            metadata=data.get("metadata"),
        )


@dataclass
class GetActiveRoomResponse:
    """
    Response from get active room info endpoint.

    Attributes:
        status: Whether the request was successful.
        room: Detailed room information.
        msg: Optional message from the API.
        participants_info: List of participant information.

    Example:
        >>> response = client.rooms.get_active_room_info("room-123")
        >>> if response.status:
        ...     print(f"Room: {response.room.room_title}")
    """

    status: bool
    room: ActiveRoomInfo
    msg: Optional[str] = None
    participants_info: Optional[list[dict[str, Any]]] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GetActiveRoomResponse":
        """
        Create from API response dictionary.

        Handles the API response structure: {result: {room_info: {...}}}

        Args:
            data: Raw API response dictionary.

        Returns:
            GetActiveRoomResponse: Parsed response object.
        """
        # Handle nested structure: {"result": {"room_info": {...}}}
        room_data = None
        participants_info = None

        if "result" in data and isinstance(data["result"], dict):
            result = data["result"]
            if "room_info" in result:
                room_data = result["room_info"]
            participants_info = result.get("participants_info")
        elif "room" in data:
            room_data = data["room"]

        if room_data is None:
            raise ValueError("No room data found in response")

        return cls(
            status=data["status"],
            room=ActiveRoomInfo.from_dict(room_data),
            msg=data.get("msg"),
            participants_info=participants_info,
        )


@dataclass
class GetActiveRoomsResponse:
    """
    Response from get all active rooms endpoint.

    Attributes:
        status: Whether the request was successful.
        rooms: List of currently active rooms.
        msg: Optional message from the API.

    Example:
        >>> response = client.rooms.get_all_active_rooms()
        >>> print(f"Active rooms: {len(response.rooms)}")
        >>> for room in response.rooms:
        ...     print(f"  - {room.room_id}")
    """

    status: bool
    rooms: list[ActiveRoomInfo]
    msg: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GetActiveRoomsResponse":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            GetActiveRoomsResponse: Parsed response object.
        """
        return cls(
            status=data["status"],
            rooms=[ActiveRoomInfo.from_dict(r) for r in data.get("rooms", [])],
            msg=data.get("msg"),
        )


@dataclass
class FetchPastRoomsResponse:
    """
    Response from fetch past rooms endpoint.

    Contains historical room data including timing and participant info.

    Attributes:
        status: Whether the request was successful.
        msg: Optional message from the API.
        rooms: List of past room information.
        result: Alternative field for room list (API compatibility).

    Example:
        >>> response = client.rooms.fetch_past_rooms({...})
        >>> for room in response.rooms or []:
        ...     print(f"{room.room_title}: {room.created} - {room.ended}")
    """

    status: bool
    msg: Optional[str] = None
    rooms: Optional[list[ActiveRoomInfo]] = None
    result: Optional[list[ActiveRoomInfo]] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FetchPastRoomsResponse":
        """
        Create from API response dictionary.

        Handles both direct room arrays and nested structures.

        Args:
            data: Raw API response dictionary.

        Returns:
            FetchPastRoomsResponse: Parsed response object.
        """
        rooms = None
        rooms_data = data.get("rooms")
        if rooms_data:
            # Handle nested structure: {"rooms": {"rooms_list": [...]}}
            if isinstance(rooms_data, dict) and "rooms_list" in rooms_data:
                rooms = [ActiveRoomInfo.from_dict(r) for r in rooms_data["rooms_list"]]
            elif isinstance(rooms_data, list):
                rooms = [ActiveRoomInfo.from_dict(r) for r in rooms_data]
        result = None
        if data.get("result"):
            result = [ActiveRoomInfo.from_dict(r) for r in data["result"]]
        return cls(
            status=data["status"],
            msg=data.get("msg"),
            rooms=rooms,
            result=result,
        )


@dataclass
class InvitationLinkResponse:
    """
    Response from create invitation link endpoint.

    Attributes:
        invitation_link: The generated invitation URL.
        invitation_url: Alternative field for invitation URL.
        status: Whether the request was successful.

    Example:
        >>> response = client.rooms.create_invitation_link({...})
        >>> print(f"Share this link: {response.invitation_link}")
    """

    invitation_link: Optional[str] = None
    invitation_url: Optional[str] = None
    status: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "InvitationLinkResponse":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            InvitationLinkResponse: Parsed response object.
        """
        return cls(
            invitation_link=data.get("invitation_link"),
            invitation_url=data.get("invitation_url"),
            status=data.get("status"),
        )


@dataclass
class EndRoomResponse:
    """
    Response from end room endpoint.

    Attributes:
        ended: Whether the room was successfully ended.
        status: Whether the request was successful.
        msg: Optional message from the API.

    Example:
        >>> response = client.rooms.end_room("room-123")
        >>> if response.ended:
        ...     print("Room ended successfully")
    """

    ended: Optional[bool] = None
    status: Optional[bool] = None
    msg: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EndRoomResponse":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            EndRoomResponse: Parsed response object.
        """
        return cls(
            ended=data.get("ended"),
            status=data.get("status"),
            msg=data.get("msg"),
        )


# Recording Types


@dataclass
class RecordingData:
    """
    Recording data returned from API.

    Contains URLs for downloading room recordings.

    Attributes:
        url: Comma-separated string of recording URLs.
        room_id: The room ID this recording belongs to.

    Example:
        >>> data = client.recordings.get_recording("room-123")
        >>> urls = data.url.split(",")
        >>> for url in urls:
        ...     print(f"Download: {url.strip()}")
    """

    url: str
    room_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RecordingData":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            RecordingData: Parsed recording data.
        """
        return cls(
            url=data.get("url", ""),
            room_id=data.get("room_id"),
        )


@dataclass
class RecordingResponse:
    """
    Response from recording endpoint.

    Attributes:
        data: Recording data containing URLs.
        status: Whether the request was successful.

    Example:
        >>> response = client.recordings.get_recording("room-123")
        >>> print(f"Recording URL: {response.data.url}")
    """

    data: RecordingData
    status: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RecordingResponse":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            RecordingResponse: Parsed response object.
        """
        return cls(
            data=RecordingData.from_dict(data.get("data", {})),
            status=data.get("status"),
        )


# Analytics Types


@dataclass
class AnalyticsResponse:
    """
    Response from analytics endpoint.

    Contains detailed room analytics and usage metrics.

    Attributes:
        data: Dictionary containing analytics metrics.
        status: Whether the request was successful.

    Example:
        >>> response = client.analytics.get_analytics("room-123")
        >>> print(f"Duration: {response.data.get('duration')}")
        >>> print(f"Participants: {response.data.get('participants_count')}")
    """

    data: dict[str, Any]
    status: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AnalyticsResponse":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            AnalyticsResponse: Parsed response object.
        """
        return cls(
            data=data.get("data", {}),
            status=data.get("status"),
        )


# Branding Types


@dataclass
class BrandingParams:
    """
    Parameters for branding operations.

    Use this to upload logos and branding assets for your project.

    Attributes:
        project_id: Your VCloud project ID (required).
        logo: Main logo image (file-like object or bytes).
        dark_logo: Logo for dark mode/theme.
        mobile_logo: Logo optimized for mobile devices.
        mobile_dark_logo: Mobile logo for dark mode.
        fav_icon: Favicon/browser tab icon.

    Example:
        >>> with open("logo.png", "rb") as f:
        ...     params = BrandingParams(
        ...         project_id="proj-123",
        ...         logo=f,
        ...     )
        ...     client.branding.create(params)
    """

    project_id: str
    logo: Optional[Union[bytes, Any]] = None  # bytes or file-like object
    dark_logo: Optional[Union[bytes, Any]] = None
    mobile_logo: Optional[Union[bytes, Any]] = None
    mobile_dark_logo: Optional[Union[bytes, Any]] = None
    fav_icon: Optional[Union[bytes, Any]] = None


@dataclass
class BrandingResponse:
    """
    Response from branding endpoint.

    Attributes:
        status: Whether the operation was successful.
        message: Optional message from the API.

    Example:
        >>> response = client.branding.create({...})
        >>> if response.status:
        ...     print("Branding updated successfully")
    """

    status: bool
    message: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BrandingResponse":
        """
        Create from API response dictionary.

        Args:
            data: Raw API response dictionary.

        Returns:
            BrandingResponse: Parsed response object.
        """
        return cls(
            status=data.get("status", False),
            message=data.get("message"),
        )
