"""Utility functions to load or generate data sets."""

from .pw_constant import pw_constant
from .pw_linear import pw_linear
from .pw_normal import pw_normal
from .pw_wavy import pw_wavy
