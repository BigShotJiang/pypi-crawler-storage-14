"""Tests for the Atlas Command HTTP client."""

from __future__ import annotations

import json
from datetime import datetime, timezone

import httpx
import pytest
from atlas_asset_ws_client import AtlasCommandHttpClient


def build_client(json_map: dict[tuple[str, str], tuple[int, dict]]) -> AtlasCommandHttpClient:
    async def handler(request: httpx.Request) -> httpx.Response:
        key = (request.method, request.url.path)
        if key not in json_map:
            return httpx.Response(404)
        status_code, payload = json_map[key]
        return httpx.Response(status_code, json=payload)

    transport = httpx.MockTransport(handler)
    return AtlasCommandHttpClient("http://atlas.local", transport=transport)


@pytest.mark.asyncio
async def test_list_entities_calls_endpoint():
    payload = [{"entity_id": "one"}]
    client = build_client({("GET", "/entities"): (200, payload)})
    async with client:
        result = await client.list_entities()
    assert result == payload


@pytest.mark.asyncio
async def test_create_entity_posts_payload():
    captured: dict[str, httpx.Request] = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        return httpx.Response(200, json={"entity_id": "asset-1"})

    client = AtlasCommandHttpClient(
        "http://atlas.local",
        transport=httpx.MockTransport(handler),
        token="secret",
    )
    async with client:
        entity = await client.create_entity(entity_id="asset-1", entity_type="asset", alias="demo")

    assert entity["entity_id"] == "asset-1"
    req = captured["request"]
    assert req.headers["authorization"] == "Bearer secret"
    assert json.loads(req.content)["alias"] == "demo"


@pytest.mark.asyncio
async def test_get_changed_since_passes_params():
    since = datetime(2025, 1, 1, tzinfo=timezone.utc).isoformat()

    async def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.params["since"] == since
        assert request.url.params["limit_per_type"] == "10"
        return httpx.Response(200, json={"entities": [], "tasks": [], "objects": []})

    client = AtlasCommandHttpClient(
        "http://atlas.local",
        transport=httpx.MockTransport(handler),
    )
    async with client:
        snapshot = await client.get_changed_since(since, limit_per_type=10)
    assert snapshot == {"entities": [], "tasks": [], "objects": []}
