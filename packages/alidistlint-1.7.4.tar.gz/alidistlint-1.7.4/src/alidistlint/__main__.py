"""Run alidistlint as a script."""
from alidistlint.run import main
main()
