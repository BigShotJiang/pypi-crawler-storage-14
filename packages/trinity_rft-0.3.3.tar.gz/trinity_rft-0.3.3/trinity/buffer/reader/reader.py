from trinity.utils.registry import Registry

READER = Registry("reader")
