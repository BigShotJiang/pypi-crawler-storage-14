from trinity.buffer.selector.selector import SELECTORS

__all__ = [
    "SELECTORS",
]
