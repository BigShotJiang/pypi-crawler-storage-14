from trinity.algorithm.kl_fn.kl_fn import KL_FN, KLFn

__all__ = ["KLFn", "KL_FN"]
