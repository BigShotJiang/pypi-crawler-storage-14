from trinity.algorithm.entropy_loss_fn.entropy_loss_fn import (
    ENTROPY_LOSS_FN,
    EntropyLossFn,
)

__all__ = [
    "EntropyLossFn",
    "ENTROPY_LOSS_FN",
]
