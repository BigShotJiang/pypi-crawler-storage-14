"""
uv_easy - uv를 더 쉽게 사용하기 위한 도구
"""

__version__ = "0.2.5"  # pyproject.toml과 동기화 필요
