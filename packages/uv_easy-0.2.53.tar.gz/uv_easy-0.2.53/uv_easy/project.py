"""
프로젝트 초기화 및 생성 관련 기능
"""

import sys
from pathlib import Path
from typing import Literal

import click

from .utils import get_pyproject_path, load_toml, save_toml


def setup_pypi_urls() -> None:
    """pyproject.toml에 PyPI 배포를 위한 project.urls를 추가합니다."""
    # load_toml은 기본적으로 pyproject.toml을 읽습니다.
    try:
        data = load_toml()

        # project.urls가 이미 있는지 확인
        if "urls" in data.get("project", {}):
            click.echo("⚠️  project.urls가 이미 존재합니다.")
            click.echo("현재 URLs:")
            for key, value in data["project"]["urls"].items():
                click.echo(f"  {key}: {value}")

            if not click.confirm("기존 URLs를 덮어쓰시겠습니까?"):
                click.echo("작업이 취소되었습니다.")
                return

        # 기본 URLs 추가
        project_name = data["project"]["name"]
        default_urls = {
            "Homepage": f"https://github.com/hakunamta00700/{project_name}",
            "Repository": f"https://github.com/hakunamta00700/{project_name}",
            "Issues": f"https://github.com/hakunamta00700/{project_name}/issues",
            "Documentation": f"https://github.com/hakunamta00700/{project_name}#readme",
        }

        # project.urls 추가
        if "project" not in data:
            data["project"] = {}

        data["project"]["urls"] = default_urls

        save_toml(data)

        click.echo("✅ PyPI 배포를 위한 URLs가 추가되었습니다:")
        for key, value in default_urls.items():
            click.echo(f"  {key}: {value}")

        click.echo("\n💡 다음 단계:")
        click.echo("1. GitHub 저장소가 생성되었는지 확인하세요")
        click.echo("2. uv_easy build로 패키지를 빌드하세요")
        click.echo("3. uv_easy publish로 PyPI에 업로드하세요")

    except Exception as e:
        click.echo(f"❌ URLs 추가 중 오류가 발생했습니다: {e}", err=True)
        sys.exit(1)


def create_project_structure(
    package_name: str,
    use_cli: Literal["click", "argparse"] = "click"
) -> None:
    """
    새로운 CLI 프로젝트 구조를 생성합니다.
    """
    pyproject_path = get_pyproject_path()
    project_root = pyproject_path.parent
    package_dir = project_root / package_name
    
    # 패키지 디렉토리가 이미 존재하는지 확인
    if package_dir.exists():
        click.echo(f"❌ '{package_name}' 디렉토리가 이미 존재합니다.", err=True)
        sys.exit(1)
    
    # 패키지 디렉토리 생성
    package_dir.mkdir(parents=True, exist_ok=False)
    click.echo(f"✅ '{package_name}' 디렉토리를 생성했습니다.")
    
    # __init__.py 생성
    init_content = f'''"""
{package_name} 패키지
"""

__version__ = "0.1.0"
'''
    (package_dir / "__init__.py").write_text(init_content, encoding='utf-8')
    click.echo(f"✅ '{package_name}/__init__.py' 파일을 생성했습니다.")
    
    # __main__.py 생성
    main_content = f'''"""
{package_name} 패키지의 메인 진입점
"""

import sys
from pathlib import Path

# 패키지 루트를 sys.path에 추가하여 절대 import 가능하게 함
_package_dir = Path(__file__).parent
_project_root = _package_dir.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

# 절대 import 사용
from {package_name}.cli import main

if __name__ == "__main__":
    main()
'''
    (package_dir / "__main__.py").write_text(main_content, encoding='utf-8')
    click.echo(f"✅ '{package_name}/__main__.py' 파일을 생성했습니다.")
    
    # cli.py 생성
    if use_cli == "click":
        cli_content = f'''"""
{package_name} CLI 진입점
"""

import sys
from pathlib import Path

import click
import toml


def get_version():
    """pyproject.toml에서 버전을 읽어옵니다."""
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject_path.exists():
            with open(pyproject_path, 'r', encoding='utf-8') as f:
                data = toml.load(f)
                return data.get('project', {{}}).get('version', '0.1.0')
    except Exception:
        pass
    
    # pyproject.toml을 읽을 수 없으면 __init__.py에서 가져오기
    try:
        from . import __version__
        return __version__
    except ImportError:
        return "0.1.0"


@click.group()
def cli():
    """{package_name} CLI"""
    pass


@cli.command()
def version():
    """버전을 표시합니다."""
    version_str = get_version()
    click.echo(version_str)


def main():
    """CLI 진입점"""
    cli()
'''
    else:  # argparse
        cli_content = f'''"""
{package_name} CLI 진입점
"""

import argparse
import sys
from pathlib import Path

import toml


def get_version():
    """pyproject.toml에서 버전을 읽어옵니다."""
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject_path.exists():
            with open(pyproject_path, 'r', encoding='utf-8') as f:
                data = toml.load(f)
                return data.get('project', {{}}).get('version', '0.1.0')
    except Exception:
        pass
    
    # pyproject.toml을 읽을 수 없으면 __init__.py에서 가져오기
    try:
        from . import __version__
        return __version__
    except ImportError:
        return "0.1.0"


def create_parser():
    """argparse 파서를 생성합니다."""
    parser = argparse.ArgumentParser(
        description="{package_name} CLI",
        prog="{package_name}"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="사용 가능한 명령어")
    
    # version 명령어
    version_parser = subparsers.add_parser("version", help="버전을 표시합니다")
    
    return parser


def main():
    """CLI 진입점"""
    parser = create_parser()
    args = parser.parse_args()
    
    if args.command == "version":
        print(get_version())
    elif args.command is None:
        parser.print_help()
        sys.exit(1)
'''
    
    (package_dir / "cli.py").write_text(cli_content, encoding='utf-8')
    click.echo(f"✅ '{package_name}/cli.py' 파일을 생성했습니다 ({use_cli} 사용).")
    
    # pyproject.toml 설정 통합 업데이트
    try:
        data = load_toml(pyproject_path)
        
        # [project] 섹션 설정
        if 'project' not in data:
            data['project'] = {}
        
        if 'name' not in data['project']:
            data['project']['name'] = package_name.replace('_', '-')
        
        if 'version' not in data['project']:
            data['project']['version'] = "0.1.0"
        
        if 'requires-python' not in data['project']:
            data['project']['requires-python'] = ">=3.9"
        
        if 'dependencies' not in data['project']:
            data['project']['dependencies'] = []
        
        # CLI 라이브러리 의존성
        if use_cli == "click":
            click_dep = "click>=8.0.0"
            if not any(dep.startswith("click") for dep in data['project']['dependencies']):
                data['project']['dependencies'].append(click_dep)
        
        toml_dep = "toml>=0.10.0"
        if not any(dep.startswith("toml") for dep in data['project']['dependencies']):
            data['project']['dependencies'].append(toml_dep)
        
        # [project.scripts]
        if 'scripts' not in data['project']:
            data['project']['scripts'] = {}
        
        script_entry = f"{package_name}.cli:main"
        data['project']['scripts'][package_name] = script_entry
        
        # [project.urls]
        if 'urls' not in data['project']:
            project_name_for_url = data['project'].get('name', package_name.replace('_', '-'))
            data['project']['urls'] = {
                "Homepage": f"https://github.com/hakunamta00700/{project_name_for_url}",
                "Repository": f"https://github.com/hakunamta00700/{project_name_for_url}",
                "Issues": f"https://github.com/hakunamta00700/{project_name_for_url}/issues",
                "Documentation": f"https://github.com/hakunamta00700/{project_name_for_url}#readme"
            }
        
        # [build-system]
        if 'build-system' not in data:
            data['build-system'] = {
                'requires': ['hatchling'],
                'build-backend': 'hatchling.build'
            }
        
        # [tool.uv]
        if 'tool' not in data:
            data['tool'] = {}
        if 'uv' not in data['tool']:
            data['tool']['uv'] = {}
        data['tool']['uv']['package'] = True
        
        # [tool.hatch.build.targets.wheel]
        if 'hatch' not in data['tool']:
            data['tool']['hatch'] = {}
        if 'build' not in data['tool']['hatch']:
            data['tool']['hatch']['build'] = {}
        if 'targets' not in data['tool']['hatch']['build']:
            data['tool']['hatch']['build']['targets'] = {}
        if 'wheel' not in data['tool']['hatch']['build']['targets']:
            data['tool']['hatch']['build']['targets']['wheel'] = {}
        
        data['tool']['hatch']['build']['targets']['wheel']['packages'] = [package_name]
        
        save_toml(data)
        
        click.echo(f"✅ pyproject.toml을 완전히 설정했습니다:")
        click.echo(f"   - [project] 섹션 (name, version, dependencies)")
        click.echo(f"   - [project.scripts] 섹션 ({package_name} 스크립트 추가)")
        click.echo(f"   - [project.urls] 섹션")
        click.echo(f"   - [build-system] 섹션")
        click.echo(f"   - [tool.uv] 섹션 (package = true)")
        click.echo(f"   - [tool.hatch.build.targets.wheel] 섹션")
        click.echo(f"   실행: {package_name} version")
        
    except Exception as e:
        click.echo(f"❌ pyproject.toml 업데이트 중 오류가 발생했습니다: {e}", err=True)
        sys.exit(1)
    
    click.echo("\n💡 다음 단계:")
    click.echo("   1. uv sync로 의존성 설치")
    click.echo(f"   2. {package_name} version으로 테스트")
    click.echo("   3. uv_easy version up으로 버전 관리 시작")
    
    click.echo(f"\n✅ '{package_name}' 프로젝트 구조 생성이 완료되었습니다!")
