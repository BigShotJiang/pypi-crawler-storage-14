"""GISKit - Recipe-driven spatial data downloader.

Download spatial data for any location, any provider, anywhere.
"""

__version__ = "0.1.0-dev"

__all__ = ["__version__"]
