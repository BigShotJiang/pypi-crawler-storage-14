import torch
from diffusers import StableDiffusionXLPipeline
from PIL import Image
import base64
from io import BytesIO
from typing import Dict, Any, List

class ImageGenCapability:
    name = "image_gen"
    _pipe = None

    @staticmethod
    def descriptor() -> Dict[str, Any]:
        return {
            "name": "image_gen",
            "description": (
                "Generates images from text prompts using local SDXL (no API key required). "
                "Returns a base64-encoded PNG and plugin-only CSS/JS for rendering."
            ),
            "intents": ["image_generation", "visualization", "art", "diagram"],
            "examples": [
                "Generate a picture of a futuristic city skyline at sunset.",
                "Create a diagram showing the water cycle.",
                "Draw a cartoon cat riding a bicycle.",
            ],
            "tags": ["image", "generation", "art", "visual", "diagram", "picture"],
            "excludes": [],
        }

    @staticmethod
    def assets() -> Dict[str, List[str]]:
        css = r"""
        .image-gen-result {
            margin: 12px 0;
            text-align: center;
        }
        .image-gen-result img {
            max-width: 100%;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.12);
            background: #222;
        }
        """
        js = r"""/* No-op: rendering handled by plugin injection. */"""
        return {"css": [css], "js": [js]}

    def _get_pipe(self):
        if self._pipe is None:
            # Load SDXL model (will download weights if not present)
            self._pipe = StableDiffusionXLPipeline.from_pretrained(
                "stabilityai/stable-diffusion-xl-base-1.0",
                torch_dtype=torch.float32
            )
            # Use CUDA if available
            if torch.cuda.is_available():
                self._pipe = self._pipe.to("cuda")
        return self._pipe

    def run_once(self, args: Any, **kwargs) -> Dict[str, Any]:
        prompt = (getattr(args, "question", None) or args.get("question") or "").strip()
        hints = kwargs.get("hints") or {}
        concise = bool(hints.get("concise", False))

        try:
            pipe = self._get_pipe()
            image = pipe(prompt).images[0]
            buf = BytesIO()
            image.save(buf, format="PNG")
            image_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
        except Exception as ex:
            md = (
                f"### Image Generation Error\n"
                f"**Prompt:** {prompt}\n\n"
                f"Sorry, image generation failed: `{ex}`"
            )
            return {
                "answer": md,
                "image_base64": "",
                "meta": {
                    "capability": self.name,
                    "prompt": prompt,
                    "error": str(ex),
                },
            }

        safe_prompt = (
            prompt.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        )
        if concise:
            md = (
                f'<div class="image-gen-result">'
                f'data:image/png;base64,{image_b64}'
                f'<div class="image-gen-caption"><strong>Prompt:</strong> {safe_prompt}</div>'
                f'</div>'
            )
        else:
            md = (
                "### Generated Image\n"
                f"**Prompt:** {safe_prompt}\n\n"
                f'<div class="image-gen-result">'
                f'data:image/png;base64,{image_b64}'
                f'<div class="image-gen-caption">Rendered via local SDXL</div>'
                f'</div>'
            )

        return {
            "answer": md,
            "image_base64": image_b64,
            "meta": {
                "capability": self.name,
                "prompt": prompt,
            },
        }

    async def run_stream(self, args: Any, **kwargs):
        result = self.run_once(args, **kwargs)
        yield {"event": "generation_started", "data": {"capability": self.name}}
        yield {"event": "token", "data": result["answer"]}
        yield {"event": "generation_done", "data": {}}
        yield {"event": "done", "data": {}}

def register(registry):
    registry.register(ImageGenCapability())
