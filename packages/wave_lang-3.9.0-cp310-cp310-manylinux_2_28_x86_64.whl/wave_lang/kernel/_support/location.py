# Copyright 2025 The IREE Authors
#
# Licensed under the Apache License v2.0 with LLVM Exceptions.
# See https://llvm.org/LICENSE.txt for license information.
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

from __future__ import annotations
import inspect
import sys
from dataclasses import dataclass
from typing import List, Optional, TypeVar, Union, Callable

from ...support.location_config import LocationCaptureConfig, LocationCaptureLevel


@dataclass
class FileLineColInfo:
    """
    Location information containing the filename, line and column.
    """

    filename: str
    line: Union[int, tuple[int, int]]
    col: Union[int, tuple[int, int]]

    ContextImpl = TypeVar("ContextImpl")
    LocationImpl = TypeVar("LocationImpl")

    def _to_mlir_impl(
        self, Context: ContextImpl, Location: LocationImpl
    ) -> LocationImpl:
        assert Context.current is not None, "Must be called under MLIR context manager."

        line_is_range = isinstance(self.line, tuple)
        col_is_range = isinstance(self.col, tuple)
        if not line_is_range and not col_is_range:
            return Location.file(self.filename, self.line, self.col)
        line_start = self.line[0] if line_is_range else self.line
        line_end = self.line[1] if line_is_range else self.line
        col_start = self.col[0] if col_is_range else self.col
        col_end = self.col[1] if col_is_range else self.col
        return Location.file(self.filename, line_start, col_start, line_end, col_end)

    def to_mlir(self) -> Location:
        # Lazy import to avoid IREE dependency on module import
        from iree.compiler.ir import Context, Location

        return self._to_mlir_impl(Context, Location)

    def to_water(self) -> Location:
        # Lazy import to avoid IREE dependency on module import
        from water_mlir.water_mlir.ir import Context, Location

        return self._to_mlir_impl(Context, Location)

    @staticmethod
    def capture_current_location():
        # Need to find a part of the call stack that doesn't belong to us.
        for f in inspect.stack():
            if "wave_lang/kernel" not in f.filename:
                break
        if not f:
            f = inspect.stack()[-1]

        return FileLineColInfo.from_stack_frame(f)

    @staticmethod
    def from_stack_frame(frame: inspect.FrameInfo):
        # Column information is only available for Python >= 3.11.
        assert sys.version_info.major == 3, "Unexpected Python version"
        if sys.version_info.minor < 11:
            return FileLineColInfo(frame.filename, frame.lineno, 0)

        return FileLineColInfo(
            frame.filename,
            (frame.positions.lineno, frame.positions.end_lineno),
            (frame.positions.col_offset, frame.positions.end_col_offset),
        )


@dataclass
class StackTraceInfo:
    """
    Locations of an entire stack trace, each with FileLineColInfo.
    """

    frames: List[FileLineColInfo]

    ContextImpl = TypeVar("ContextImpl")
    LocationImpl = TypeVar("LocationImpl")

    def _to_mlir_impl(
        self, Context: ContextImpl, Location: LocationImpl
    ) -> LocationImpl:
        assert Context.current is not None, "Must be called under MLIR context manager."
        if not self.frames:
            return Location.unknown()
        if len(self.frames) == 1:
            return self.frames[0].to_mlir()
        return Location.callsite(
            self.frames[0].to_mlir(), [f.to_mlir() for f in self.frames[1:]]
        )

    def to_mlir(self) -> Location:
        # Lazy import to avoid IREE dependency on module import
        from iree.compiler.ir import Context, Location

        return self._to_mlir_impl(Context, Location)

    def to_water(self) -> Location:
        # Lazy import to avoid IREE dependency on module import
        from water_mlir.water_mlir.ir import Context, Location

        return self._to_mlir_impl(Context, Location)

    @staticmethod
    def capture_current_location(*, preserve_system_frames=False) -> "StackTraceInfo":
        # TODO: we may want to cache location info so we don't keep copying the
        # top of the stack everywhere. MLIR uniquing takes care of this when we
        # convert currently.
        frames = [
            FileLineColInfo.from_stack_frame(f)
            for f in inspect.stack()
            if "wave_lang/kernel" not in f.filename or preserve_system_frames
        ]
        return StackTraceInfo(frames)


# Define type alias to refer to this more easily.
CapturedLocation = FileLineColInfo | StackTraceInfo


def capture_location(
    location_capture_config: Optional[LocationCaptureConfig],
) -> Optional[CapturedLocation]:
    if (
        not location_capture_config
        or location_capture_config.level == LocationCaptureLevel.NONE
    ):
        return None
    if location_capture_config.level == LocationCaptureLevel.FILE_LINE_COL:
        return FileLineColInfo.capture_current_location()
    if location_capture_config.level == LocationCaptureLevel.STACK_TRACE:
        return StackTraceInfo.capture_current_location()
    if location_capture_config.level == LocationCaptureLevel.STACK_TRACE_WITH_SYSTEM:
        return StackTraceInfo.capture_current_location(preserve_system_frames=True)


def capture_function_location(
    func: Callable, location_capture_config: LocationCaptureConfig
) -> Optional[FileLineColInfo | StackTraceInfo]:
    """
    Capture location information for a specific function.

    Args:
        func: The function to capture location for
        location_capture_config: Location capture configuration

    Returns:
        Location information for the function, or None if capture is disabled
    """
    if (
        location_capture_config is None
        or location_capture_config.level == LocationCaptureLevel.NONE
    ):
        return None

    source_file = inspect.getfile(func)
    source_lines, start_line = inspect.getsourcelines(func)

    if location_capture_config.level == LocationCaptureLevel.FILE_LINE_COL:
        return FileLineColInfo(
            filename=source_file,
            line=start_line,
            col=0,  # Column info not easily available for function definitions
        )
    elif location_capture_config.level in [
        LocationCaptureLevel.STACK_TRACE,
        LocationCaptureLevel.STACK_TRACE_WITH_SYSTEM,
    ]:
        # Create a single-frame stack trace for the function
        frame_info = FileLineColInfo(filename=source_file, line=start_line, col=0)
        return StackTraceInfo(frames=[frame_info])

    return None
