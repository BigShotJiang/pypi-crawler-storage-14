import os
import requests
from typing import Any
from .logger import get_logger
from .models import TestSuiteSummary


log = get_logger(__name__)


def build_lark_message(
    summary: TestSuiteSummary, title: str, color_template: str
) -> dict[str, Any]:
    """
    Builds an interactive card message for Lark with customized title and color template

    :param summmary: TestSuiteSummary object
    :param title: custom title for the Lark interactive card
    :param color_template: color template for the Lark interactive card
    """
    _summary = (
        f"Device: {summary.device}\n"
        f"Total Tests: {summary.total_tests}\n"
        f"Failed Tests: {summary.failed_tests}\n"
        f"Duration: {summary.duration} mins\n"
        f"Overall Status: {summary.overall_status}"
    )

    msg_actioncard = {
        "msg_type": "interactive",
        "update_multi": False,
        "card": {
            "config": {"wide_screen_mode": True},
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": title,
                },
                "template": color_template,
            },
            "elements": [
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": f"{_summary}",
                    },
                },
                {"tag": "hr"},
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": "**Test Cases Details:**\n"
                        + "\n".join(
                            f"- **{case['name']}**: {case['status']}\n"
                            f"  Failure Message: **{case['failure_message'] if case['status'] == 'Error' else '-'}**"
                            for case in summary.test_cases
                        ),
                    },
                },
            ],
        },
    }

    return msg_actioncard


def send_report_to_lark(
    summary: TestSuiteSummary,
    title: str,
    color_template: str,
    webhook_url: str,
    timeout: int = 10,
) -> bool:
    """
    Sends the test report to Lark using the provided Webhook URL, all parameters are required,
    if `color_template` or `title` is not provided, default values will apply

    :param summary: summary of the test suite, this is the output from `parse_xml_report` function
    :param title: title of the interactive card in Lark
    :param color_template: color template for the interactive card in Lark
    :param webhook_url: webhook URL to send the report to Lark group
    :param timeout: timeout for the request to Lark, by default it's 10 seconds
    """
    get_webhook_url = os.getenv("LARK_URL")
    url = webhook_url or get_webhook_url
    if not url:
        log.error(
            "No URL Lark webhook provided, please set LARK_URL environment variable"
        )
        return False

    payload = build_lark_message(
        summary=summary, title=title, color_template=color_template
    )
    try:
        response = requests.post(url, json=payload, timeout=timeout)
        if response.status_code == 200:
            log.info("Lark message sent successfully")
            return True
        else:
            log.error(
                f"Failed to send Lark message with status code: {response.status_code}"
            )
            return False
    except requests.exceptions.RequestException as e:
        log.error(f"Uncaught exception while sending Lark message: {e}")
        return False
