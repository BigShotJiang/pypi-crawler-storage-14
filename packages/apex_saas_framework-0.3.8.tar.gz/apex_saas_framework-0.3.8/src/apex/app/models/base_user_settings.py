"""
User settings model stored as JSONB.
"""
from sqlalchemy import ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, declared_attr, mapped_column, relationship

from apex.app.database.base import BaseModel


class BaseUserSettings(BaseModel):
    """Abstract user settings entity."""

    __abstract__ = True

    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    preferences: Mapped[dict | None] = mapped_column(JSONB, default=dict)

    @declared_attr
    def user(cls):
        return relationship("BaseUser", back_populates="settings_profile")


__all__ = ["BaseUserSettings"]

