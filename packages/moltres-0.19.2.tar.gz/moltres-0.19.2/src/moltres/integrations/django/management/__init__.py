"""Django management commands for Moltres."""
