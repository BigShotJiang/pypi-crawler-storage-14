# Vettly Python SDK

> **Python SDK for protecting your platform from toxic content.**

Your users remember how they feel. One toxic comment, one harmful image, one bad experience - and they're gone. Vettly stops harmful content before it reaches your community.

## Why Vettly?

- **🛡️ Protect your community**  -  Block hate speech, harassment, and harmful content
- **👁️ Multi-modal coverage**  -  Text, images, and video all checked
- **⚡ Async support**  -  High-performance async/await for production apps
- **🎯 Flexible policies**  -  Strict, moderate, or permissive - you decide
- **💰 10k text + 250 image + 100 video checks/month free**  -  No credit card required

## Get Your Free API Key

1. Visit [vettly.dev](https://vettly.dev)
2. Sign up for a free account (10k text + 250 image + 100 video checks/month free)
3. Go to **API Keys** in the dashboard
4. Create and copy your API key

## Installation

```bash
pip install vettly
```

## Quick Start

```python
from vettly import ModerationClient

client = ModerationClient(api_key="your-api-key")

# Protect your users in one line
result = client.check(
    content="User-generated content here",
    policy_id="moderate"
)

if result.action == "block":
    # Harmful content blocked - your users never see it
    print("Content blocked for community safety")
elif result.flagged:
    # Queue for human review
    print("Content flagged for review")
else:
    # Safe to show your community
    print("Content is safe")
```

## The Problem

One bad experience can undo months of community building:

- **Toxic comments** drive users away - and they tell their friends
- **Harmful images** destroy trust instantly
- **No real-time protection** means users see harmful content before you can remove it

## The Solution

Vettly protects your community across all content types:

```python
# Protect text content
result = client.check(
    content="Some user comment",
    policy_id="moderate"
)

# Protect image uploads
result = client.check(
    content="https://example.com/image.jpg",
    content_type="image",
    policy_id="strict"
)

# Batch protection for efficiency
from vettly import BatchItem

results = client.batch_check(
    policy_id="moderate",
    items=[
        BatchItem(id="1", content="First message"),
        BatchItem(id="2", content="Second message"),
    ],
)
```

## Async Support

For high-performance applications:

```python
from vettly import AsyncModerationClient

async with AsyncModerationClient(api_key="your-api-key") as client:
    result = await client.check(
        content="User content",
        policy_id="moderate"
    )
```

## Framework Integration

### FastAPI

```python
from fastapi import FastAPI, HTTPException
from vettly import AsyncModerationClient

app = FastAPI()
client = AsyncModerationClient(api_key="your-api-key")

@app.post("/comments")
async def create_comment(content: str):
    result = await client.check(content=content, policy_id="moderate")

    if result.action == "block":
        raise HTTPException(status_code=403, detail="Content blocked for community safety")

    # Safe to save
    return {"status": "ok"}
```

### Django

```python
from vettly import ModerationClient

client = ModerationClient(api_key="your-api-key")

def moderate_content(content: str) -> bool:
    result = client.check(content=content, policy_id="moderate")
    return result.action != "block"
```

### Flask

```python
from flask import Flask, request, jsonify
from vettly import ModerationClient

app = Flask(__name__)
client = ModerationClient(api_key="your-api-key")

@app.route("/submit", methods=["POST"])
def submit():
    content = request.json.get("content")
    result = client.check(content=content, policy_id="moderate")

    if result.action == "block":
        return jsonify({"error": "Content blocked for community safety"}), 403

    return jsonify({"status": "ok"})
```

## Policies

| Policy | Use Case | Protection Level |
|--------|----------|------------------|
| `strict` | Schools, kids apps, enterprise | Maximum protection |
| `moderate` | Social apps, forums, comments | Balanced |
| `permissive` | Gaming, creative writing | Fewer restrictions |

## API Reference

### ModerationClient

```python
client = ModerationClient(
    api_key="your-api-key",
    api_url="https://api.vettly.dev",  # Optional
    timeout=30.0,  # Optional, in seconds
)
```

### Methods

#### `check(content, policy_id, **kwargs)`
Check content for harmful material.

```python
result = client.check(
    content="User message",
    policy_id="moderate",
    content_type="text",  # "text", "image", or "video"
    metadata={"user_id": "123"},
    user_id="user-123",
)
```

#### `batch_check(policy_id, items)`
Check multiple items in one request.

```python
from vettly import BatchItem

results = client.batch_check(
    policy_id="moderate",
    items=[
        BatchItem(id="1", content="First message"),
        BatchItem(id="2", content="Second message"),
    ],
)
```

#### `create_policy(policy_id, yaml_content)`
Create or update a protection policy.

```python
policy = client.create_policy(
    policy_id="custom-policy",
    yaml_content="""
name: Custom Policy
categories:
  - name: toxicity
    threshold: 0.7
    action: block
"""
)
```

#### `list_policies()`
List all policies.

```python
policies = client.list_policies()
```

#### `get_decision(decision_id)`
Get details of a past decision.

```python
decision = client.get_decision("dec_123")
```

#### `register_webhook(url, events)`
Get notified when harmful content is blocked.

```python
webhook = client.register_webhook(
    url="https://yoursite.com/webhooks/vettly",
    events=["decision.block", "decision.flag"],
)
```

## Error Handling

```python
from vettly import (
    ModerationClient,
    VettlyAuthError,
    VettlyRateLimitError,
    VettlyAPIError,
)

client = ModerationClient(api_key="your-api-key")

try:
    result = client.check(content="test", policy_id="moderate")
except VettlyAuthError:
    print("Invalid API key")
except VettlyRateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after} seconds")
except VettlyAPIError as e:
    print(f"API error: {e.message}")
```

## Pricing

| Plan | Text | Images | Videos | Price |
|------|------|--------|--------|-------|
| Free | 10,000/mo | 250/mo | 100/mo | $0 |
| Starter | Unlimited | 5,000/mo | 2,000/mo | $29/mo |
| Pro | Unlimited | 20,000/mo | 10,000/mo | $79/mo |
| Enterprise | Unlimited | Unlimited | Unlimited | Custom |

**Start protecting your community today. No credit card required.**

## Links

- **[Start Protecting](https://vettly.dev)**  -  Get your free API key
- [Documentation](https://docs.vettly.dev)
- [GitHub](https://github.com/brian-nextaura/vettly-docs)
