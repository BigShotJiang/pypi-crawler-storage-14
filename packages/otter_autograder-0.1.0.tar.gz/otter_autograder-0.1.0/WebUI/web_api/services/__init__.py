"""
Business logic services
"""
