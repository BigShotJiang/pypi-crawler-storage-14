from setuptools import setup

setup(
    name='rayforce',
    version='0.0.1',
    description='Alias package for rayforce-py. Please install rayforce-py instead.',
    long_description='This is a placeholder package. Please install `rayforce-py` for the actual RayforceDB Python bindings.',
    long_description_content_type='text/plain',
    author='Karim',
    license='MIT',
    install_requires=['rayforce-py'],
    python_requires='>=3.13',
    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.13',
    ],
)
