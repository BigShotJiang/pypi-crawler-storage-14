from setuptools import setup, find_packages

setup(
    name="IM-COOL-BOOY-GMAIL",
    version="1.1.1",
    author="coolbooy",
    author_email="coolbooy@gmail.com",
    description="GMAIL SECURITY ANALYZER TOOL",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=["IM_COOL_BOOY_GMAIL"],
    install_requires=[],
    keywords=["gmail security tool"],
    entry_points={
        "console_scripts": [
           "IM-COOL-BOOY-GMAIL=IM_COOL_BOOY_GMAIL.main:main"
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
    ],
    python_requires=">=3.6",
    include_package_data=True,
    package_data={"": ["*.png", "*.jpg", "*.jpeg", "*.gif"]},
)
