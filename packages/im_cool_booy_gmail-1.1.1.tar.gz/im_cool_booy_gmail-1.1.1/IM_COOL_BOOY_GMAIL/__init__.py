# IM_COOL_BOOY_GMAIL/__init__.py
from .main import main, main_function
