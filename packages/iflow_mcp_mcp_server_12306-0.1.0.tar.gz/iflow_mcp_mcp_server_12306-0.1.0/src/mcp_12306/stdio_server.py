#!/usr/bin/env python3
"""
MCP Server for 12306 with stdio transport
"""
import asyncio
import logging
from typing import Any, Dict, List, Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    CallToolRequest,
    ListToolsRequest,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource
)

from .services.station_service import StationService
from .services.ticket_service import TicketService
from .services.http_client import HttpClient

# Initialize services
station_service = StationService()
ticket_service = TicketService()
http_client = HttpClient()
ticket_service.station_service = station_service

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create MCP server
server = Server("12306-mcp-server")

@server.list_tools()
async def list_tools() -> List[Tool]:
    """List available tools"""
    return [
        Tool(
            name="query-tickets",
            description="官方12306余票/车次/座席/时刻一站式查询。输入出发站、到达站、日期，返回所有可购车次、时刻、历时、各席别余票等详细信息。支持中文名、三字码。",
            inputSchema={
                "type": "object",
                "properties": {
                    "from_station": {
                        "type": "string",
                        "description": "出发车站名称，例如：北京、上海、广州"
                    },
                    "to_station": {
                        "type": "string", 
                        "description": "到达车站名称，例如：北京、上海、广州"
                    },
                    "train_date": {
                        "type": "string",
                        "description": "出发日期，格式：YYYY-MM-DD"
                    }
                },
                "required": ["from_station", "to_station", "train_date"]
            }
        ),
        Tool(
            name="search-stations",
            description="智能模糊查站，支持中文名、拼音、简拼、三字码等多种方式，快速获取车站全名与三字码。",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "车站搜索关键词，支持：车站名称、拼音、简拼等"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "返回结果的最大数量",
                        "default": 10,
                        "minimum": 1,
                        "maximum": 50
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="query-transfer",
            description="官方中转换乘方案查询。输入出发站、到达站、日期，可选中转站/无座/学生票，自动分页抓取全部中转方案，输出每段车次、时刻、余票、等候时间、总历时等详细信息。",
            inputSchema={
                "type": "object",
                "properties": {
                    "from_station": {
                        "type": "string",
                        "description": "出发车站名称"
                    },
                    "to_station": {
                        "type": "string",
                        "description": "到达车站名称"
                    },
                    "train_date": {
                        "type": "string",
                        "description": "出发日期，格式：YYYY-MM-DD"
                    },
                    "middle_station": {
                        "type": "string",
                        "description": "指定中转站名称或三字码，可选",
                        "default": ""
                    },
                    "isShowWZ": {
                        "type": "string",
                        "description": "是否显示无座车次（Y/N），默认N",
                        "default": "N"
                    },
                    "purpose_codes": {
                        "type": "string",
                        "description": "乘客类型（00=普通，0X=学生），默认00",
                        "default": "00"
                    }
                },
                "required": ["from_station", "to_station", "train_date"]
            }
        ),
        Tool(
            name="get-station-info",
            description="获取车站详细信息，包括车站名称、三字码、地理位置等。",
            inputSchema={
                "type": "object",
                "properties": {
                    "station": {
                        "type": "string",
                        "description": "车站名称或三字码"
                    }
                },
                "required": ["station"]
            }
        ),
        Tool(
            name="get-train-route-stations",
            description="查询指定列车经停站及时刻表。",
            inputSchema={
                "type": "object",
                "properties": {
                    "train_no": {
                        "type": "string",
                        "description": "列车号，例如：G1"
                    },
                    "from_station": {
                        "type": "string",
                        "description": "出发车站名称"
                    },
                    "to_station": {
                        "type": "string",
                        "description": "到达车站名称"
                    },
                    "train_date": {
                        "type": "string",
                        "description": "出发日期，格式：YYYY-MM-DD"
                    }
                },
                "required": ["train_no", "from_station", "to_station", "train_date"]
            }
        ),
        Tool(
            name="get-current-time",
            description="获取当前时间与相对日期，帮助用户准确选择出行日期。",
            inputSchema={
                "type": "object",
                "properties": {
                    "timezone": {
                        "type": "string",
                        "description": "时区，默认Asia/Shanghai",
                        "default": "Asia/Shanghai"
                    }
                }
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent | ImageContent | EmbeddedResource]:
    """Handle tool calls"""
    try:
        if name == "query-tickets":
            from_station = arguments["from_station"]
            to_station = arguments["to_station"]
            train_date = arguments["train_date"]
            
            result = await ticket_service.query_tickets(from_station, to_station, train_date)
            return [TextContent(type="text", text=str(result))]
            
        elif name == "search-stations":
            query = arguments["query"]
            limit = arguments.get("limit", 10)
            
            result = await station_service.search_stations(query, limit)
            return [TextContent(type="text", text=str(result))]
            
        elif name == "query-transfer":
            from_station = arguments["from_station"]
            to_station = arguments["to_station"]
            train_date = arguments["train_date"]
            middle_station = arguments.get("middle_station", "")
            isShowWZ = arguments.get("isShowWZ", "N")
            purpose_codes = arguments.get("purpose_codes", "00")
            
            result = await ticket_service.query_transfer(
                from_station, to_station, train_date, 
                middle_station, isShowWZ, purpose_codes
            )
            return [TextContent(type="text", text=str(result))]
            
        elif name == "get-station-info":
            station = arguments["station"]
            result = await station_service.get_station_info(station)
            return [TextContent(type="text", text=str(result))]
            
        elif name == "get-train-route-stations":
            train_no = arguments["train_no"]
            from_station = arguments["from_station"]
            to_station = arguments["to_station"]
            train_date = arguments["train_date"]
            
            result = await ticket_service.get_train_route_stations(
                train_no, from_station, to_station, train_date
            )
            return [TextContent(type="text", text=str(result))]
            
        elif name == "get-current-time":
            from datetime import datetime
            import pytz
            timezone_str = arguments.get("timezone", "Asia/Shanghai")
            try:
                tz = pytz.timezone(timezone_str)
                now = datetime.now(tz)
            except pytz.exceptions.UnknownTimeZoneError:
                tz = pytz.timezone("Asia/Shanghai")
                now = datetime.now(tz)
            text = now.strftime("%Y-%m-%d %H:%M:%S") + f" {tz.zone}"
            return [TextContent(type="text", text=text)]
            
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
            
    except Exception as e:
        logger.error(f"Error calling tool {name}: {e}")
        return [TextContent(type="text", text=f"Error: {str(e)}")]

async def main():
    """Main entry point for stdio server"""
    # Load station data
    await station_service.load_stations()
    
    # Run the stdio server
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )

if __name__ == "__main__":
    asyncio.run(main())