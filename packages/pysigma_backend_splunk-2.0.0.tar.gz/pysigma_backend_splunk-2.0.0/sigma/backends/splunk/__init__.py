from .splunk import SplunkBackend

backends = {
    "splunk": SplunkBackend,
}
