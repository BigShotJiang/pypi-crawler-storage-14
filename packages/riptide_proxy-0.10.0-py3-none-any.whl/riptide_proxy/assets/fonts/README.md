# Kumbh Sans

Licensed under the [SIL Open Font License, Version 1.1](https://openfontlicense.org/open-font-license-official-text/).

Source: https://fonts.google.com/specimen/Kumbh+Sans
