

from alibabacloud_ecs20140526.client import Client as Ecs20140526Client
from alibabacloud_ecs20140526 import models as ecs_20140526_models
from alibabacloud_tea_util import models as util_models
from alibabacloud_tea_util.client import Client as UtilClient
import json

from ..client.client import ClientConf

class ECS(object): 
    """
    阿里云ECS服务
    """
    
    def __init__(self):
        # 使用 ClientConf 单例获取已配置好凭证的 config
        client_conf = ClientConf()
        if client_conf.config is None:
            print("配置文件不存在, 请使用ali config regen 命令生成配置文件。")
            self.__client = None
            return
        
        self.region = client_conf.region
        client_conf.config.endpoint = f'ecs.{self.region}.aliyuncs.com'
        self.__client = Ecs20140526Client(client_conf.config)
    

    
        
    
    def crpp(self):
        """
        创建按量付费实例 或者竞价实例 
        """
        if self.__client is None:
            print("ECS客户端未初始化，请先配置阿里云凭证")
            return
        
        private_dns_name_options = ecs_20140526_models.RunInstancesRequestPrivateDnsNameOptions(
            hostname_type='IpBased',
            enable_instance_id_dns_arecord=True,
            enable_instance_id_dns_aaaarecord=True,
            enable_ip_dns_arecord=True,
            enable_ip_dns_ptr_record=True
        )
        image_options = ecs_20140526_models.RunInstancesRequestImageOptions(
            login_as_non_root=True
        )
        system_disk = ecs_20140526_models.RunInstancesRequestSystemDisk(
            category='cloud_essd',
            size='30'
        )
        run_instances_request = ecs_20140526_models.RunInstancesRequest(
            instance_charge_type='PostPaid',  # 后付费实例 和PrePaid 相对
            region_id=self.region,
            v_switch_id='vsw-wz9y0k7lke0e5obyafder',
            private_ip_address='10.0.3.2',
            instance_type='ecs.e-c1m4.large',
            spot_strategy='SpotAsPriceGo', # 最优方式就是系统自动出价 
            spot_interruption_behavior='Stop',
            image_id='debian_12_9_x64_20G_alibase_20250314.vhd',
            system_disk=system_disk,
            internet_charge_type='PayByTraffic',
            internet_max_bandwidth_out=100,
            security_group_ids=[
                'sg-wz93hfiperquzquh7k92'
            ],
            password='ggmm12LPP!',
            image_options=image_options,
            instance_name='test',
            private_dns_name_options=private_dns_name_options
            
        )
        runtime = util_models.RuntimeOptions()
        try:
            # CLIENT().config.endpoint = f'ecs.{CLIENT().region}.aliyuncs.com'
            # res=Ecs20140526Client(CLIENT().config).run_instances_with_options(run_instances_request, runtime)
            res=self.__client.run_instances_with_options(run_instances_request, runtime)
            print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
        except Exception as error:
            print(error.message)
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)





    @staticmethod
    def _getecs():
        if ClientConf().config is None:
            print("ECS客户端未初始化，请先配置阿里云凭证")
            return

        describe_instances_request = ecs_20140526_models.DescribeInstancesRequest(
            region_id=ClientConf().region
        )
        runtime = util_models.RuntimeOptions()
        ClientConf().config.endpoint = f'ecs.{ClientConf().region}.aliyuncs.com'
        res=Ecs20140526Client(ClientConf().config).describe_instances_with_options(describe_instances_request, runtime)
        
        # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
        return res 



    @staticmethod
    def ls() -> None:
        """
        列出当前region下的所有ECS实例
        """
        try:
            res=ECS._getecs()
            # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))

            # 找出 res.body.Instances.Instance 当中的所有 instance 
            # 然后 针对每个 instance 列出他们的  
            #   InstanceId PublicIpAddress InstanceName InstanceType InternetChargeType 
            #   RegionId PrimaryIpAddress ImageId  SecurityGroupIds VSwitchId  VpcId
            instances = res.body.instances.instance
            for instance in instances:
                print(f"实例ID: {instance.instance_id}")
                print(f"实例状态: {instance.status}")
                print(f"公网IP: {instance.public_ip_address}")
                print(f"实例名称: {instance.instance_name}")
                print(f"实例规格: {instance.instance_type}")
                print(f"网络计费类型: {instance.internet_charge_type}")
                print(f"地域ID: {instance.region_id}")
                
                # Get primary IP address from network interfaces
                primary_ip = ""
                if instance.network_interfaces and instance.network_interfaces.network_interface:
                    primary_ip = instance.network_interfaces.network_interface[0].primary_ip_address
                print(f"主私网IP: {primary_ip}")
                
                print(f"镜像ID: {instance.image_id}")
                print(f"安全组ID: {instance.security_group_ids}")
                
                # Get VSwitch and VPC from VPC attributes
                vswitch_id = ""
                vpc_id = ""
                if instance.vpc_attributes:
                    vswitch_id = instance.vpc_attributes.v_switch_id
                    vpc_id = instance.vpc_attributes.vpc_id
                print(f"交换机ID: {vswitch_id}")
                print(f"专有网络ID: {vpc_id}")
                print("-" * 50)


        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(f"Error occurred: {str(error)}")
            # 如果是阿里云SDK的异常，尝试获取更多信息
            if hasattr(error, 'data') and error.data:
                print(f"Recommend: {error.data.get('Recommend', 'No recommendation available')}")
            UtilClient.assert_as_string(str(error))



    def delserver(self):
        client = self.__client
        delete_instance_request = ecs_20140526_models.DeleteInstanceRequest(
            instance_id='i-wz9fa9elu2hn7sz0vilu'
        )
        runtime = util_models.RuntimeOptions()
        try:
            # 复制代码运行请自行打印 API 的返回值
            res=client.delete_instance_with_options(delete_instance_request, runtime)
            return res 
        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(error.message)
            # 诊断地址
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)
    
    
    def _get_instance_type(self):
        client = self.__client
        describe_available_resource_request = ecs_20140526_models.DescribeAvailableResourceRequest(
            region_id='cn-shenzhen',
            destination_resource='InstanceType',
            instance_charge_type='PostPaid',
            spot_strategy='SpotAsPriceGo'
        )
        runtime = util_models.RuntimeOptions()
        try:
            # 复制代码运行请自行打印 API 的返回值
            res=client.describe_available_resource_with_options(describe_available_resource_request, runtime)
            # print(json.dumps(res.to_map(), indent=2, ensure_ascii=False))
            return res 
        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            print(error.message)
            # 诊断地址
            print(error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)
    
    def list_instance_types(self):
        """
        列出所有可用的实例规格类型
        返回一个包含所有可用 instance_type 的列表
        但是他会返回某个大区的 所有可用区的可用资源 
        """
        try:
            res = self._get_instance_type()
            if res is None:
                return []
            
            instance_types = []
            # 遍历可用区和资源信息
            if res.body.available_zones and res.body.available_zones.available_zone:
                for zone in res.body.available_zones.available_zone:
                    if zone.available_resources and zone.available_resources.available_resource:
                        for resource in zone.available_resources.available_resource:
                            if resource.supported_resources and resource.supported_resources.supported_resource:
                                for supported in resource.supported_resources.supported_resource:
                                    if supported.value and supported.value not in instance_types:
                                        instance_types.append(supported.value)
            
            # 打印所有可用的实例类型
            print(f"共找到 {len(instance_types)} 种可用实例规格:")
            for instance_type in sorted(instance_types):
                print(f"  - {instance_type}")
            
            return instance_types
            
        except Exception as error:
            print(f"获取实例规格失败: {str(error)}")
            if hasattr(error, 'data') and error.data:
                print(f"建议: {error.data.get('Recommend', '无')}")
            return []