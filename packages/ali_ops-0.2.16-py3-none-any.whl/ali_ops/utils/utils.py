
region_choices = {
        # China Mainland
        "cn-shenzhen": "cn-shenzhen (深圳)",
        "cn-hangzhou": "cn-hangzhou (杭州)",
        "cn-beijing": "cn-beijing (北京)",
        "cn-shanghai": "cn-shanghai (上海)",
        "cn-qingdao": "cn-qingdao (青岛)",
        "cn-zhangjiakou": "cn-zhangjiakou (张家口)",
        "cn-huhehaote": "cn-huhehaote (呼和浩特)",
        "cn-wulanchabu": "cn-wulanchabu (乌兰察布)",
        "cn-chengdu": "cn-chengdu (成都)",
        "cn-heyuan": "cn-heyuan (河源)",
        "cn-guangzhou": "cn-guangzhou (广州)",
        "cn-fuzhou": "cn-fuzhou (福州)",
        "cn-wuhan-lr": "cn-wuhan-lr (武汉)",
        "cn-nanjing": "cn-nanjing (南京)",
        # Asia Pacific
        "ap-southeast-1": "ap-southeast-1 (新加坡)",
        "ap-southeast-3": "ap-southeast-3 (马来西亚吉隆坡)",
        "ap-southeast-5": "ap-southeast-5 (印度尼西亚雅加达)",
        "ap-southeast-6": "ap-southeast-6 (菲律宾马尼拉)",
        "ap-southeast-7": "ap-southeast-7 (泰国曼谷)",
        "ap-northeast-1": "ap-northeast-1 (日本东京)",
        "ap-northeast-2": "ap-northeast-2 (韩国首尔)",
        # US
        "us-east-1": "us-east-1 (美国弗吉尼亚)",
        "us-west-1": "us-west-1 (美国硅谷)",
        # Europe
        "eu-west-1": "eu-west-1 (英国伦敦)",
        "eu-central-1": "eu-central-1 (德国法兰克福)",
        
        "na-south-1": "na-south-1 (墨西哥)",
        "me-east-1": "me-east-1 (阿联酋迪拜)",
         
    }


image_choices = {
    # Windows Server
    "wincore_2025_x64_dtc_zh-cn_40G_alibase_20251112.vhd": "Windows Server 2025 数据中心版 64位中文版（不含图形化桌面）",
    "win2025_24H2_x64_dtc_en-us_40G_uefi_alibase_20251112.vhd": "Windows Server 2025 数据中心版 64位英文UEFI版",
    "wincore_2025_x64_dtc_en-us_40G_alibase_20251112.vhd": "Windows Server 2025 数据中心版 64位英文版（不含图形化桌面）",
    "win2025_24H2_x64_dtc_zh-cn_40G_uefi_alibase_20251112.vhd": "Windows Server 2025 数据中心版 64位中文UEFI版",
    "win2025_24H2_x64_dtc_zh-cn_40G_alibase_20251112.vhd": "Windows Server 2025 数据中心版 64位中文版",
    "win2022_21H2_x64_dtc_zh-cn_40G_alibase_20251112.vhd": "Windows Server 2022 数据中心版 64位中文版",
    "win2025_24H2_x64_dtc_en-us_40G_alibase_20251112.vhd": "Windows Server 2025 数据中心版 64位英文版",
    "wincore_2022_x64_dtc_en-us_40G_alibase_20251112.vhd": "Windows Server 2022 数据中心版 64位英文版（不含图形化桌面）",
    "wincore_2022_x64_dtc_zh-cn_40G_alibase_20251112.vhd": "Windows Server 2022 数据中心版 64位中文版（不含图形化桌面）",
    "win2022_21H2_x64_dtc_en-us_40G_uefi_alibase_20251112.vhd": "Windows Server 2022 数据中心版 64位英文UEFI版",
    # Ubuntu
    "ubuntu_24_04_x64_100G_with_gpu_driver_alibase_20251109.vhd": "Ubuntu 24.04 64位 预装NVIDIA GPU驱动",
    "ubuntu_24_04_x64_20G_alibase_20251102.vhd": "Ubuntu 24.04 64位",
    "ubuntu_22_04_x64_100G_with_gpu_driver_alibase_20251109.vhd": "Ubuntu 22.04 64位 预装NVIDIA GPU驱动",
    "ubuntu_22_04_x64_20G_alibase_20251103.vhd": "Ubuntu 22.04 64位",
    "ubuntu_20_04_x64_20G_alibase_20251031.vhd": "Ubuntu 20.04 64位",
    # OpenSUSE
    "opensuse_16_0_x64_20G_alibase_20251106.vhd": "OpenSUSE 16.0 64位",
    # Debian
    "debian_13_1_arm64_20G_alibase_20251103.vhd": "Debian 13.1 64位 ARM版",
    "debian_13_1_x64_20G_alibase_20251103.vhd": "Debian 13.1 64位",
    "debian_12_12_x64_20G_alibase_20251030.vhd": "Debian 12.12 64位",
    # CentOS Stream
    "centos_stream_9_x64_20G_alibase_20251030.vhd": "CentOS Stream 9 64位",
    "centos_stream_10_x64_20G_alibase_20251031.vhd": "CentOS Stream 10 64位",
}


# instance_type_choices
# 这可以使用 DescribeAvailableResource 函数进行查询
