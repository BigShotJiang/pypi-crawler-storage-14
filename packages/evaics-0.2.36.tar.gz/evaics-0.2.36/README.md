# EVA ICS v4 SDK (Python)

EVA ICS v4 software development kit (Python)

Technical documentation: <https://info.bma.ai/en/actual/eva4/sdk/>

