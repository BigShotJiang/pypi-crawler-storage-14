# FIXED VERSION
import os
import streamlit as st
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough # Added for LCEL input mapping
from langchain_huggingface.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
# Assuming this external package is available
from chatsynth_vanshajr.retriever import ChatSynthRetriever 


def chat_preview():
    # --- State Checks ---
    if "faiss_created" not in st.session_state:
        st.warning("Please complete Steps 1 & 2 first!")
        return
    
    try:
        # Initialize session states
        if "chat_messages" not in st.session_state:
            st.session_state.chat_messages = []
            
        if "api_keys" not in st.session_state:
            st.session_state.api_keys = {"groq": "", "hf": ""}
        
        user_data = st.session_state.generated_json
        
        # --- ROBUST NAME EXTRACTION FIX ---
        # 1. Safely retrieve the 'personal_info' dictionary (default to empty dict {})
        name_dict = user_data.get("personal_info", {})
        # 2. Safely retrieve the 'name' key from 'personal_info' (default to 'User')
        # 3. Explicitly cast the result to a string (str()) to prevent the 'dict has no replace' error.
        user_name = str(name_dict.get("name", "User"))
        # ----------------------------------
        
        st.title(f"Chat with {user_name}'s AI Assistant (Preview)")
        st.sidebar.write("Get your Groq API key: https://console.groq.com/playground")
        
        # Sidebar for API key input (omitted for brevity, assume it sets keys/model_name)
        with st.sidebar:
            st.header("🔑 Temporary API Keys")
            groq_key = st.text_input("Groq API Key", type="password",
                                     value=st.session_state.api_keys["groq"], key="preview_groq_key")
            hf_token = st.text_input("HuggingFace Token", type="password",
                                     value=st.session_state.api_keys["hf"], key="preview_hf_token")
            
            st.session_state.api_keys.update({"groq": groq_key, "hf": hf_token})
            
            if not (groq_key and hf_token):
                st.warning("Enter both API keys to continue")
                return
                
            # UPDATED: Using modern and common Groq model identifiers
            model_name = st.selectbox("Model", ["llama-3.1-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"])
        
        # --- FAISS Index Loading ---
        if not os.path.exists("faiss_index"):
            st.error("FAISS index not found! Complete Step 2 first.")
            return
        
        if "faiss_vectors" not in st.session_state:
            try:
                embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
                st.session_state.faiss_vectors = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)
            except Exception as e:
                st.error(f"Error loading FAISS index: {str(e)}")
                return
        
        # --- LangChain Component Initialization ---
        llm = ChatGroq(model_name=model_name, api_key=groq_key)
        retriever = ChatSynthRetriever(st.session_state.faiss_vectors).get_retriever()

        # --- LCEL RAG Chain Creation (FIXED) ---
        prompt_template = ChatPromptTemplate.from_template("""
            You are an AI assistant created to answer questions about {name}. You are **not** {name}, but you use the provided context to give accurate responses.

            Context about {name}:
            {context}

            Conversation History:
            {history}

            **Rules:**
            1. Be respectful and professional.
            2. Answer only using the given context.
            3. If unsure, say "I don't have that information."
            4. Keep responses professional and concise.

            **User's Question:** {input}
        """)

        # Helper function to format documents for the prompt
        def format_docs(docs):
            return "\n\n".join([doc.page_content for doc in docs])

        # Define the RAG chain structure using LCEL
        chain = (
            {
                # 1. RETRIEVAL: Input (prompt) goes through retriever, then formatted for context
                "context": retriever | format_docs,
                # 2. INPUT: Input (prompt) is passed through directly
                "input": RunnablePassthrough(),
                # 3. HISTORY/NAME: History and Name are provided from the invoke call
                "history": lambda x: x.get("history", ""),
                "name": lambda x: x.get("name", user_name)
            }
            | prompt_template
            | llm
            | StrOutputParser()
        )

        # --- Chat UI and Logic ---
        for msg in st.session_state.chat_messages:
            st.chat_message(msg["role"]).write(msg["content"])
            
        if prompt := st.chat_input("Ask me anything..."):
            st.session_state.chat_messages.append({"role": "user", "content": prompt})
            st.chat_message("user").write(prompt)
            
            try:
                with st.spinner("Thinking..."):
                    
                    # Get conversation history (last 5 turns)
                    history = "\n".join(
                        [f"{msg['role']}: {msg['content']}" 
                         for msg in st.session_state.chat_messages[-5:]]
                    )
                    
                    # Invoke the LCEL chain with the necessary inputs
                    answer = chain.invoke({
                        "input": prompt,
                        "history": history,
                        "name": user_name,
                    })
                    
                    if not answer:
                         answer = "I don't have that information."
                    
                    st.session_state.chat_messages.append({
                        "role": "assistant",
                        "content": answer
                    })
                    st.chat_message("assistant").write(answer)
                    
            except Exception as e:
                st.error(f"Error: {str(e)}")
                
    except Exception as e:
        st.error(f"Preview error: {str(e)}")