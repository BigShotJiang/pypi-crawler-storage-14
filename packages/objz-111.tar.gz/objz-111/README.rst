**NAME**


|
| ``OBJZ`` - object shell
|


**SYNOPSIS**


|
| ``objz <cmd> [key=val] [key==val]``
| ``objz -cvaw [init=mod1,mod2]``
| ``objz -d`` 
| ``objz -s``
|


**DESCRIPTION**


``OBJZ`` has all you need to program a unix cli program, such as disk
perisistence for configuration files, event handler to handle the
client/server connection, deferred exception handling to not crash
on an error, etc.

``OBJZ`` contains python3 code to program objects in a functional way.
it provides an "clean namespace" Object class that only has dunder
methods, so the namespace is not cluttered with method names. This
makes storing and reading to/from json possible.

``OBJZ`` is a python3 IRC bot, it can connect to IRC, fetch and
display RSS feeds, take todo notes, keep a shopping list and log
text. You can run it under systemd for 24/7 presence in a IRC channel.

``OBJZ`` is Public Domain.


**INSTALL**


installation is done with pipx

|
| ``$ pipx install objz``
| ``$ pipx ensurepath``
|
| <new terminal>
|
| ``$ objz srv > objz.service``
| ``$ sudo mv objz.service /etc/systemd/system/``
| ``$ sudo systemctl enable objz --now``
|
| joins ``#objz`` on localhost
|


**USAGE**


use ``objz`` to control the program, default it does nothing

|
| ``$ objz``
| ``$``
|

see list of commands

|
| ``$ objz cmd``
| ``cfg,cmd,dne,dpl,err,exp,imp,log,mod,mre,nme,``
| ``pwd,rem,req,res,rss,srv,syn,tdo,thr,upt``
|

start console

|
| ``$ objz -c``
|

start console and run irc and rss clients

|
| ``$ objz -c init=irc,rss``
|

list available modules

|
| ``$ objz mod``
| ``err,flt,fnd,irc,llm,log,mbx,mdl,mod,req,rss,``
| ``rst,slg,tdo,thr,tmr,udp,upt``
|

start daemon

|
| ``$ objz -d``
| ``$``
|

start service

|
| ``$ objz -s``
| ``<runs until ctrl-c>``
|


**COMMANDS**


here is a list of available commands

|
| ``cfg`` - irc configuration
| ``cmd`` - commands
| ``dpl`` - sets display items
| ``err`` - show errors
| ``exp`` - export opml (stdout)
| ``imp`` - import opml
| ``log`` - log text
| ``mre`` - display cached output
| ``pwd`` - sasl nickserv name/pass
| ``rem`` - removes a rss feed
| ``res`` - restore deleted feeds
| ``req`` - reconsider
| ``rss`` - add a feed
| ``syn`` - sync rss feeds
| ``tdo`` - add todo item
| ``thr`` - show running threads
| ``upt`` - show uptime
|

**CONFIGURATION**


irc

|
| ``$ objz cfg server=<server>``
| ``$ objz cfg channel=<channel>``
| ``$ objz cfg nick=<nick>``
|

sasl

|
| ``$ objz pwd <nsnick> <nspass>``
| ``$ objz cfg password=<frompwd>``
|

rss

|
| ``$ objz rss <url>``
| ``$ objz dpl <url> <item1,item2>``
| ``$ objz rem <url>``
| ``$ objz nme <url> <name>``
|

opml

|
| ``$ objz exp``
| ``$ objz imp <filename>``
|


**PROGRAMMING**

|
| objz has it's user modules in the ~/.objz/mods directory so for a
| hello world command you would  edit a file in ~/.objz/mods/hello.py
| and add the following
|

::

    def hello(event):
        event.reply("hello world !!")


|
| typing the hello command would result into a nice hello world !!
|

::

    $ objz hello
    hello world !!


|
| commands run in their own thread and the program borks on exit to enable a
| short debug cycle, output gets flushed on print so exceptions appear in the
| systemd logs. modules can contain your own written python3 code.
|


**FILES**

|
| ``~/.objz``
| ``~/.local/bin/objz``
| ``~/.local/pipx/venvs/objz/*``
|

**AUTHOR**

|
| ``Bart Thate`` <``bthate@dds.nl``>
|

**COPYRIGHT**

|
| ``OBJZ`` is Public Domain.
|

