#!/usr/bin/env python3


"stub"


import setuptools


setuptools.setup(
    scripts=[
        "bin/objz",
    ])
